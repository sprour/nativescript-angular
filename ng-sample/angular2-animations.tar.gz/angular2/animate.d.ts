export * from 'angular2/src/core/metadata/animations';
