/**
 * @module
 * @description
 * Adapter allowing AngularJS v1 and Angular v2 to run side by side in the same application.
 */
export { UpgradeAdapter, UpgradeAdapterRef } from './src/upgrade/upgrade_adapter';
