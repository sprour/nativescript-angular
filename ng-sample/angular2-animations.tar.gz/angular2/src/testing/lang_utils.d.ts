export declare function getTypeOf(instance: any): any;
export declare function instantiateType(type: Function, params?: any[]): any;
