export { verifyNoBrowserErrors } from './e2e_util';
export declare function runClickBenchmark(config: any): webdriver.promise.Promise<any>;
export declare function runBenchmark(config: any): webdriver.promise.Promise<any>;
