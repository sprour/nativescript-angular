export declare var browser: protractor.IBrowser;
export declare var $: cssSelectorHelper;
export declare function clickAll(buttonSelectors: any): void;
export declare function verifyNoBrowserErrors(): void;
