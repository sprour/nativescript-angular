export declare function stringify(obj: any): string;
export declare function onError(e: any): void;
export declare function controllerKey(name: string): string;
