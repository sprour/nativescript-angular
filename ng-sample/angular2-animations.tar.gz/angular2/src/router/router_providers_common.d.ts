/**
 * The Platform agnostic ROUTER PROVIDERS
 */
export declare const ROUTER_PROVIDERS_COMMON: any[];
