export declare function deserializeGenericEvent(serializedEvent: {
    [key: string]: any;
}): {
    [key: string]: any;
};
