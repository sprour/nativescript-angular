import { Provider } from 'angular2/core';
export declare var WORKER_APP_ROUTER: (any[] | Provider)[];
