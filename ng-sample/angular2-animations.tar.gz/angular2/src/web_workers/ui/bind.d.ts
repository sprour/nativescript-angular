export declare function bind(fn: Function, scope: any): Function;
