import { MessageBasedPlatformLocation } from './platform_location';
import { BrowserPlatformLocation } from 'angular2/src/router/location/browser_platform_location';
import { Provider } from 'angular2/core';
export declare const WORKER_RENDER_ROUTER: (typeof MessageBasedPlatformLocation | typeof BrowserPlatformLocation | Provider)[];
