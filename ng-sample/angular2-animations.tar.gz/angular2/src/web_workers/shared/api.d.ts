import { OpaqueToken } from "angular2/src/core/di";
export declare const ON_WEB_WORKER: OpaqueToken;
