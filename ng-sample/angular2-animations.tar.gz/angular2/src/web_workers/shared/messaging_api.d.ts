/**
 * All channels used by angular's WebWorker components are listed here.
 * You should not use these channels in your application code.
 */
export declare const RENDERER_CHANNEL: string;
export declare const XHR_CHANNEL: string;
export declare const EVENT_CHANNEL: string;
export declare const ROUTER_CHANNEL: string;
