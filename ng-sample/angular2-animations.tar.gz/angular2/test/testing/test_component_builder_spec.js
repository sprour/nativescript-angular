'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var core_1 = require('angular2/core');
var common_1 = require('angular2/common');
var metadata_1 = require('angular2/src/core/metadata');
var ChildComp = (function () {
    function ChildComp() {
        this.childBinding = 'Child';
    }
    ChildComp = __decorate([
        metadata_1.Component({ selector: 'child-comp', template: "<span>Original {{childBinding}}</span>", directives: [] }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], ChildComp);
    return ChildComp;
})();
var MockChildComp = (function () {
    function MockChildComp() {
    }
    MockChildComp = __decorate([
        metadata_1.Component({ selector: 'child-comp', template: "<span>Mock</span>" }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], MockChildComp);
    return MockChildComp;
})();
var ParentComp = (function () {
    function ParentComp() {
    }
    ParentComp = __decorate([
        metadata_1.Component({
            selector: 'parent-comp',
            template: "Parent(<child-comp></child-comp>)",
            directives: [ChildComp]
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], ParentComp);
    return ParentComp;
})();
var MyIfComp = (function () {
    function MyIfComp() {
        this.showMore = false;
    }
    MyIfComp = __decorate([
        metadata_1.Component({
            selector: 'my-if-comp',
            template: "MyIf(<span *ngIf=\"showMore\">More</span>)",
            directives: [common_1.NgIf]
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], MyIfComp);
    return MyIfComp;
})();
var ChildChildComp = (function () {
    function ChildChildComp() {
    }
    ChildChildComp = __decorate([
        metadata_1.Component({ selector: 'child-child-comp', template: "<span>ChildChild</span>" }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], ChildChildComp);
    return ChildChildComp;
})();
var ChildWithChildComp = (function () {
    function ChildWithChildComp() {
        this.childBinding = 'Child';
    }
    ChildWithChildComp = __decorate([
        metadata_1.Component({
            selector: 'child-comp',
            template: "<span>Original {{childBinding}}(<child-child-comp></child-child-comp>)</span>",
            directives: [ChildChildComp]
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], ChildWithChildComp);
    return ChildWithChildComp;
})();
var MockChildChildComp = (function () {
    function MockChildChildComp() {
    }
    MockChildChildComp = __decorate([
        metadata_1.Component({ selector: 'child-child-comp', template: "<span>ChildChild Mock</span>" }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], MockChildChildComp);
    return MockChildChildComp;
})();
var FancyService = (function () {
    function FancyService() {
        this.value = 'real value';
    }
    return FancyService;
})();
var MockFancyService = (function (_super) {
    __extends(MockFancyService, _super);
    function MockFancyService() {
        _super.apply(this, arguments);
        this.value = 'mocked out value';
    }
    return MockFancyService;
})(FancyService);
var TestBindingsComp = (function () {
    function TestBindingsComp(fancyService) {
        this.fancyService = fancyService;
    }
    TestBindingsComp = __decorate([
        metadata_1.Component({
            selector: 'my-service-comp',
            bindings: [FancyService],
            template: "injected value: {{fancyService.value}}"
        }), 
        __metadata('design:paramtypes', [FancyService])
    ], TestBindingsComp);
    return TestBindingsComp;
})();
var TestViewBindingsComp = (function () {
    function TestViewBindingsComp(fancyService) {
        this.fancyService = fancyService;
    }
    TestViewBindingsComp = __decorate([
        metadata_1.Component({
            selector: 'my-service-comp',
            viewProviders: [FancyService],
            template: "injected value: {{fancyService.value}}"
        }), 
        __metadata('design:paramtypes', [FancyService])
    ], TestViewBindingsComp);
    return TestViewBindingsComp;
})();
function main() {
    testing_internal_1.describe('test component builder', function () {
        testing_internal_1.it('should instantiate a component with valid DOM', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(ChildComp).then(function (componentFixture) {
                componentFixture.detectChanges();
                testing_internal_1.expect(componentFixture.nativeElement).toHaveText('Original Child');
                async.done();
            });
        }));
        testing_internal_1.it('should allow changing members of the component', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(MyIfComp).then(function (componentFixture) {
                componentFixture.detectChanges();
                testing_internal_1.expect(componentFixture.nativeElement).toHaveText('MyIf()');
                componentFixture.componentInstance.showMore = true;
                componentFixture.detectChanges();
                testing_internal_1.expect(componentFixture.nativeElement).toHaveText('MyIf(More)');
                async.done();
            });
        }));
        testing_internal_1.it('should override a template', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideTemplate(MockChildComp, '<span>Mock</span>')
                .createAsync(MockChildComp)
                .then(function (componentFixture) {
                componentFixture.detectChanges();
                testing_internal_1.expect(componentFixture.nativeElement).toHaveText('Mock');
                async.done();
            });
        }));
        testing_internal_1.it('should override a view', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(ChildComp, new metadata_1.ViewMetadata({ template: '<span>Modified {{childBinding}}</span>' }))
                .createAsync(ChildComp)
                .then(function (componentFixture) {
                componentFixture.detectChanges();
                testing_internal_1.expect(componentFixture.nativeElement).toHaveText('Modified Child');
                async.done();
            });
        }));
        testing_internal_1.it('should override component dependencies', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideDirective(ParentComp, ChildComp, MockChildComp)
                .createAsync(ParentComp)
                .then(function (componentFixture) {
                componentFixture.detectChanges();
                testing_internal_1.expect(componentFixture.nativeElement).toHaveText('Parent(Mock)');
                async.done();
            });
        }));
        testing_internal_1.it("should override child component's dependencies", testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideDirective(ParentComp, ChildComp, ChildWithChildComp)
                .overrideDirective(ChildWithChildComp, ChildChildComp, MockChildChildComp)
                .createAsync(ParentComp)
                .then(function (componentFixture) {
                componentFixture.detectChanges();
                testing_internal_1.expect(componentFixture.nativeElement)
                    .toHaveText('Parent(Original Child(ChildChild Mock))');
                async.done();
            });
        }));
        testing_internal_1.it('should override a provider', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideProviders(TestBindingsComp, [core_1.provide(FancyService, { useClass: MockFancyService })])
                .createAsync(TestBindingsComp)
                .then(function (componentFixture) {
                componentFixture.detectChanges();
                testing_internal_1.expect(componentFixture.nativeElement)
                    .toHaveText('injected value: mocked out value');
                async.done();
            });
        }));
        testing_internal_1.it('should override a viewBinding', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideViewProviders(TestViewBindingsComp, [core_1.provide(FancyService, { useClass: MockFancyService })])
                .createAsync(TestViewBindingsComp)
                .then(function (componentFixture) {
                componentFixture.detectChanges();
                testing_internal_1.expect(componentFixture.nativeElement)
                    .toHaveText('injected value: mocked out value');
                async.done();
            });
        }));
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVzdF9jb21wb25lbnRfYnVpbGRlcl9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC90ZXN0aW5nL3Rlc3RfY29tcG9uZW50X2J1aWxkZXJfc3BlYy50cyJdLCJuYW1lcyI6WyJDaGlsZENvbXAiLCJDaGlsZENvbXAuY29uc3RydWN0b3IiLCJNb2NrQ2hpbGRDb21wIiwiTW9ja0NoaWxkQ29tcC5jb25zdHJ1Y3RvciIsIlBhcmVudENvbXAiLCJQYXJlbnRDb21wLmNvbnN0cnVjdG9yIiwiTXlJZkNvbXAiLCJNeUlmQ29tcC5jb25zdHJ1Y3RvciIsIkNoaWxkQ2hpbGRDb21wIiwiQ2hpbGRDaGlsZENvbXAuY29uc3RydWN0b3IiLCJDaGlsZFdpdGhDaGlsZENvbXAiLCJDaGlsZFdpdGhDaGlsZENvbXAuY29uc3RydWN0b3IiLCJNb2NrQ2hpbGRDaGlsZENvbXAiLCJNb2NrQ2hpbGRDaGlsZENvbXAuY29uc3RydWN0b3IiLCJGYW5jeVNlcnZpY2UiLCJGYW5jeVNlcnZpY2UuY29uc3RydWN0b3IiLCJNb2NrRmFuY3lTZXJ2aWNlIiwiTW9ja0ZhbmN5U2VydmljZS5jb25zdHJ1Y3RvciIsIlRlc3RCaW5kaW5nc0NvbXAiLCJUZXN0QmluZGluZ3NDb21wLmNvbnN0cnVjdG9yIiwiVGVzdFZpZXdCaW5kaW5nc0NvbXAiLCJUZXN0Vmlld0JpbmRpbmdzQ29tcC5jb25zdHJ1Y3RvciIsIm1haW4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQUEsaUNBY08sMkJBQTJCLENBQUMsQ0FBQTtBQUVuQyxxQkFBa0MsZUFBZSxDQUFDLENBQUE7QUFDbEQsdUJBQW1CLGlCQUFpQixDQUFDLENBQUE7QUFDckMseUJBQWlELDRCQUE0QixDQUFDLENBQUE7QUFFOUU7SUFLRUE7UUFBZ0JDLElBQUlBLENBQUNBLFlBQVlBLEdBQUdBLE9BQU9BLENBQUNBO0lBQUNBLENBQUNBO0lBTGhERDtRQUFDQSxvQkFBU0EsQ0FDTkEsRUFBQ0EsUUFBUUEsRUFBRUEsWUFBWUEsRUFBRUEsUUFBUUEsRUFBRUEsd0NBQXdDQSxFQUFFQSxVQUFVQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTtRQUNoR0EsaUJBQVVBLEVBQUVBOztrQkFJWkE7SUFBREEsZ0JBQUNBO0FBQURBLENBQUNBLEFBTkQsSUFNQztBQUVEO0lBQUFFO0lBR0FDLENBQUNBO0lBSEREO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxZQUFZQSxFQUFFQSxRQUFRQSxFQUFFQSxtQkFBbUJBLEVBQUNBLENBQUNBO1FBQ2xFQSxpQkFBVUEsRUFBRUE7O3NCQUVaQTtJQUFEQSxvQkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFBQUU7SUFPQUMsQ0FBQ0E7SUFQREQ7UUFBQ0Esb0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLGFBQWFBO1lBQ3ZCQSxRQUFRQSxFQUFFQSxtQ0FBbUNBO1lBQzdDQSxVQUFVQSxFQUFFQSxDQUFDQSxTQUFTQSxDQUFDQTtTQUN4QkEsQ0FBQ0E7UUFDREEsaUJBQVVBLEVBQUVBOzttQkFFWkE7SUFBREEsaUJBQUNBO0FBQURBLENBQUNBLEFBUEQsSUFPQztBQUVEO0lBQUFFO1FBT0VDLGFBQVFBLEdBQVlBLEtBQUtBLENBQUNBO0lBQzVCQSxDQUFDQTtJQVJERDtRQUFDQSxvQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsWUFBWUE7WUFDdEJBLFFBQVFBLEVBQUVBLDRDQUEwQ0E7WUFDcERBLFVBQVVBLEVBQUVBLENBQUNBLGFBQUlBLENBQUNBO1NBQ25CQSxDQUFDQTtRQUNEQSxpQkFBVUEsRUFBRUE7O2lCQUdaQTtJQUFEQSxlQUFDQTtBQUFEQSxDQUFDQSxBQVJELElBUUM7QUFFRDtJQUFBRTtJQUdBQyxDQUFDQTtJQUhERDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsa0JBQWtCQSxFQUFFQSxRQUFRQSxFQUFFQSx5QkFBeUJBLEVBQUNBLENBQUNBO1FBQzlFQSxpQkFBVUEsRUFBRUE7O3VCQUVaQTtJQUFEQSxxQkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFRRUU7UUFBZ0JDLElBQUlBLENBQUNBLFlBQVlBLEdBQUdBLE9BQU9BLENBQUNBO0lBQUNBLENBQUNBO0lBUmhERDtRQUFDQSxvQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsWUFBWUE7WUFDdEJBLFFBQVFBLEVBQUVBLCtFQUErRUE7WUFDekZBLFVBQVVBLEVBQUVBLENBQUNBLGNBQWNBLENBQUNBO1NBQzdCQSxDQUFDQTtRQUNEQSxpQkFBVUEsRUFBRUE7OzJCQUlaQTtJQUFEQSx5QkFBQ0E7QUFBREEsQ0FBQ0EsQUFURCxJQVNDO0FBRUQ7SUFBQUU7SUFHQUMsQ0FBQ0E7SUFIREQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLGtCQUFrQkEsRUFBRUEsUUFBUUEsRUFBRUEsOEJBQThCQSxFQUFDQSxDQUFDQTtRQUNuRkEsaUJBQVVBLEVBQUVBOzsyQkFFWkE7SUFBREEseUJBQUNBO0FBQURBLENBQUNBLEFBSEQsSUFHQztBQUlEO0lBQUFFO1FBQ0VDLFVBQUtBLEdBQVdBLFlBQVlBLENBQUNBO0lBQy9CQSxDQUFDQTtJQUFERCxtQkFBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDO0FBRUQ7SUFBK0JFLG9DQUFZQTtJQUEzQ0E7UUFBK0JDLDhCQUFZQTtRQUN6Q0EsVUFBS0EsR0FBV0Esa0JBQWtCQSxDQUFDQTtJQUNyQ0EsQ0FBQ0E7SUFBREQsdUJBQUNBO0FBQURBLENBQUNBLEFBRkQsRUFBK0IsWUFBWSxFQUUxQztBQUVEO0lBTUVFLDBCQUFvQkEsWUFBMEJBO1FBQTFCQyxpQkFBWUEsR0FBWkEsWUFBWUEsQ0FBY0E7SUFBR0EsQ0FBQ0E7SUFOcEREO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxpQkFBaUJBO1lBQzNCQSxRQUFRQSxFQUFFQSxDQUFDQSxZQUFZQSxDQUFDQTtZQUN4QkEsUUFBUUEsRUFBRUEsd0NBQXdDQTtTQUNuREEsQ0FBQ0E7O3lCQUdEQTtJQUFEQSx1QkFBQ0E7QUFBREEsQ0FBQ0EsQUFQRCxJQU9DO0FBRUQ7SUFNRUUsOEJBQW9CQSxZQUEwQkE7UUFBMUJDLGlCQUFZQSxHQUFaQSxZQUFZQSxDQUFjQTtJQUFHQSxDQUFDQTtJQU5wREQ7UUFBQ0Esb0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLGlCQUFpQkE7WUFDM0JBLGFBQWFBLEVBQUVBLENBQUNBLFlBQVlBLENBQUNBO1lBQzdCQSxRQUFRQSxFQUFFQSx3Q0FBd0NBO1NBQ25EQSxDQUFDQTs7NkJBR0RBO0lBQURBLDJCQUFDQTtBQUFEQSxDQUFDQSxBQVBELElBT0M7QUFHRDtJQUNFRSwyQkFBUUEsQ0FBQ0Esd0JBQXdCQSxFQUFFQTtRQUNqQyxxQkFBRSxDQUFDLCtDQUErQyxFQUMvQyx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztZQUVsRixHQUFHLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFDLGdCQUFnQjtnQkFDL0MsZ0JBQWdCLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBRWpDLHlCQUFNLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7Z0JBQ3BFLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNmLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVQLHFCQUFFLENBQUMsZ0RBQWdELEVBQ2hELHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO1lBRWxGLEdBQUcsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsZ0JBQWdCO2dCQUM5QyxnQkFBZ0IsQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDakMseUJBQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBRTVELGdCQUFnQixDQUFDLGlCQUFpQixDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7Z0JBQ25ELGdCQUFnQixDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUNqQyx5QkFBTSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFFaEUsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRVAscUJBQUUsQ0FBQyw0QkFBNEIsRUFDNUIseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7WUFFbEYsR0FBRyxDQUFDLGdCQUFnQixDQUFDLGFBQWEsRUFBRSxtQkFBbUIsQ0FBQztpQkFDbkQsV0FBVyxDQUFDLGFBQWEsQ0FBQztpQkFDMUIsSUFBSSxDQUFDLFVBQUMsZ0JBQWdCO2dCQUNyQixnQkFBZ0IsQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDakMseUJBQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBRTFELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNmLENBQUMsQ0FBQyxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVQLHFCQUFFLENBQUMsd0JBQXdCLEVBQ3hCLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO1lBRWxGLEdBQUcsQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUNULElBQUksdUJBQVksQ0FBQyxFQUFDLFFBQVEsRUFBRSx3Q0FBd0MsRUFBQyxDQUFDLENBQUM7aUJBQ25GLFdBQVcsQ0FBQyxTQUFTLENBQUM7aUJBQ3RCLElBQUksQ0FBQyxVQUFDLGdCQUFnQjtnQkFDckIsZ0JBQWdCLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ2pDLHlCQUFNLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7Z0JBRXBFLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNmLENBQUMsQ0FBQyxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVQLHFCQUFFLENBQUMsd0NBQXdDLEVBQ3hDLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO1lBRWxGLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQUUsU0FBUyxFQUFFLGFBQWEsQ0FBQztpQkFDdEQsV0FBVyxDQUFDLFVBQVUsQ0FBQztpQkFDdkIsSUFBSSxDQUFDLFVBQUMsZ0JBQWdCO2dCQUNyQixnQkFBZ0IsQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDakMseUJBQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBRWxFLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNmLENBQUMsQ0FBQyxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUdQLHFCQUFFLENBQUMsZ0RBQWdELEVBQ2hELHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO1lBRWxGLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQUUsU0FBUyxFQUFFLGtCQUFrQixDQUFDO2lCQUMzRCxpQkFBaUIsQ0FBQyxrQkFBa0IsRUFBRSxjQUFjLEVBQUUsa0JBQWtCLENBQUM7aUJBQ3pFLFdBQVcsQ0FBQyxVQUFVLENBQUM7aUJBQ3ZCLElBQUksQ0FBQyxVQUFDLGdCQUFnQjtnQkFDckIsZ0JBQWdCLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ2pDLHlCQUFNLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDO3FCQUNqQyxVQUFVLENBQUMseUNBQXlDLENBQUMsQ0FBQztnQkFFM0QsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRVAscUJBQUUsQ0FBQyw0QkFBNEIsRUFDNUIseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7WUFFbEYsR0FBRyxDQUFDLGlCQUFpQixDQUFDLGdCQUFnQixFQUNoQixDQUFDLGNBQU8sQ0FBQyxZQUFZLEVBQUUsRUFBQyxRQUFRLEVBQUUsZ0JBQWdCLEVBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3ZFLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQztpQkFDN0IsSUFBSSxDQUFDLFVBQUMsZ0JBQWdCO2dCQUNyQixnQkFBZ0IsQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDakMseUJBQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUM7cUJBQ2pDLFVBQVUsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO2dCQUNwRCxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDZixDQUFDLENBQUMsQ0FBQztRQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7UUFHUCxxQkFBRSxDQUFDLCtCQUErQixFQUMvQix5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztZQUVsRixHQUFHLENBQUMscUJBQXFCLENBQUMsb0JBQW9CLEVBQ3BCLENBQUMsY0FBTyxDQUFDLFlBQVksRUFBRSxFQUFDLFFBQVEsRUFBRSxnQkFBZ0IsRUFBQyxDQUFDLENBQUMsQ0FBQztpQkFDM0UsV0FBVyxDQUFDLG9CQUFvQixDQUFDO2lCQUNqQyxJQUFJLENBQUMsVUFBQyxnQkFBZ0I7Z0JBQ3JCLGdCQUFnQixDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUNqQyx5QkFBTSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQztxQkFDakMsVUFBVSxDQUFDLGtDQUFrQyxDQUFDLENBQUM7Z0JBQ3BELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNmLENBQUMsQ0FBQyxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNULENBQUMsQ0FBQ0EsQ0FBQ0E7QUFDTEEsQ0FBQ0E7QUFqSGUsWUFBSSxPQWlIbkIsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFzeW5jVGVzdENvbXBsZXRlcixcbiAgYmVmb3JlRWFjaCxcbiAgZGRlc2NyaWJlLFxuICB4ZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICBkaXNwYXRjaEV2ZW50LFxuICBleHBlY3QsXG4gIGlpdCxcbiAgaW5qZWN0LFxuICBiZWZvcmVFYWNoUHJvdmlkZXJzLFxuICBpdCxcbiAgeGl0LFxuICBUZXN0Q29tcG9uZW50QnVpbGRlclxufSBmcm9tICdhbmd1bGFyMi90ZXN0aW5nX2ludGVybmFsJztcblxuaW1wb3J0IHtJbmplY3RhYmxlLCBwcm92aWRlfSBmcm9tICdhbmd1bGFyMi9jb3JlJztcbmltcG9ydCB7TmdJZn0gZnJvbSAnYW5ndWxhcjIvY29tbW9uJztcbmltcG9ydCB7RGlyZWN0aXZlLCBDb21wb25lbnQsIFZpZXdNZXRhZGF0YX0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvbWV0YWRhdGEnO1xuXG5AQ29tcG9uZW50KFxuICAgIHtzZWxlY3RvcjogJ2NoaWxkLWNvbXAnLCB0ZW1wbGF0ZTogYDxzcGFuPk9yaWdpbmFsIHt7Y2hpbGRCaW5kaW5nfX08L3NwYW4+YCwgZGlyZWN0aXZlczogW119KVxuQEluamVjdGFibGUoKVxuY2xhc3MgQ2hpbGRDb21wIHtcbiAgY2hpbGRCaW5kaW5nOiBzdHJpbmc7XG4gIGNvbnN0cnVjdG9yKCkgeyB0aGlzLmNoaWxkQmluZGluZyA9ICdDaGlsZCc7IH1cbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdjaGlsZC1jb21wJywgdGVtcGxhdGU6IGA8c3Bhbj5Nb2NrPC9zcGFuPmB9KVxuQEluamVjdGFibGUoKVxuY2xhc3MgTW9ja0NoaWxkQ29tcCB7XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ3BhcmVudC1jb21wJyxcbiAgdGVtcGxhdGU6IGBQYXJlbnQoPGNoaWxkLWNvbXA+PC9jaGlsZC1jb21wPilgLFxuICBkaXJlY3RpdmVzOiBbQ2hpbGRDb21wXVxufSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIFBhcmVudENvbXAge1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdteS1pZi1jb21wJyxcbiAgdGVtcGxhdGU6IGBNeUlmKDxzcGFuICpuZ0lmPVwic2hvd01vcmVcIj5Nb3JlPC9zcGFuPilgLFxuICBkaXJlY3RpdmVzOiBbTmdJZl1cbn0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBNeUlmQ29tcCB7XG4gIHNob3dNb3JlOiBib29sZWFuID0gZmFsc2U7XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnY2hpbGQtY2hpbGQtY29tcCcsIHRlbXBsYXRlOiBgPHNwYW4+Q2hpbGRDaGlsZDwvc3Bhbj5gfSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIENoaWxkQ2hpbGRDb21wIHtcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY2hpbGQtY29tcCcsXG4gIHRlbXBsYXRlOiBgPHNwYW4+T3JpZ2luYWwge3tjaGlsZEJpbmRpbmd9fSg8Y2hpbGQtY2hpbGQtY29tcD48L2NoaWxkLWNoaWxkLWNvbXA+KTwvc3Bhbj5gLFxuICBkaXJlY3RpdmVzOiBbQ2hpbGRDaGlsZENvbXBdXG59KVxuQEluamVjdGFibGUoKVxuY2xhc3MgQ2hpbGRXaXRoQ2hpbGRDb21wIHtcbiAgY2hpbGRCaW5kaW5nOiBzdHJpbmc7XG4gIGNvbnN0cnVjdG9yKCkgeyB0aGlzLmNoaWxkQmluZGluZyA9ICdDaGlsZCc7IH1cbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdjaGlsZC1jaGlsZC1jb21wJywgdGVtcGxhdGU6IGA8c3Bhbj5DaGlsZENoaWxkIE1vY2s8L3NwYW4+YH0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBNb2NrQ2hpbGRDaGlsZENvbXAge1xufVxuXG5cblxuY2xhc3MgRmFuY3lTZXJ2aWNlIHtcbiAgdmFsdWU6IHN0cmluZyA9ICdyZWFsIHZhbHVlJztcbn1cblxuY2xhc3MgTW9ja0ZhbmN5U2VydmljZSBleHRlbmRzIEZhbmN5U2VydmljZSB7XG4gIHZhbHVlOiBzdHJpbmcgPSAnbW9ja2VkIG91dCB2YWx1ZSc7XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ215LXNlcnZpY2UtY29tcCcsXG4gIGJpbmRpbmdzOiBbRmFuY3lTZXJ2aWNlXSxcbiAgdGVtcGxhdGU6IGBpbmplY3RlZCB2YWx1ZToge3tmYW5jeVNlcnZpY2UudmFsdWV9fWBcbn0pXG5jbGFzcyBUZXN0QmluZGluZ3NDb21wIHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBmYW5jeVNlcnZpY2U6IEZhbmN5U2VydmljZSkge31cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbXktc2VydmljZS1jb21wJyxcbiAgdmlld1Byb3ZpZGVyczogW0ZhbmN5U2VydmljZV0sXG4gIHRlbXBsYXRlOiBgaW5qZWN0ZWQgdmFsdWU6IHt7ZmFuY3lTZXJ2aWNlLnZhbHVlfX1gXG59KVxuY2xhc3MgVGVzdFZpZXdCaW5kaW5nc0NvbXAge1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGZhbmN5U2VydmljZTogRmFuY3lTZXJ2aWNlKSB7fVxufVxuXG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgndGVzdCBjb21wb25lbnQgYnVpbGRlcicsIGZ1bmN0aW9uKCkge1xuICAgIGl0KCdzaG91bGQgaW5zdGFudGlhdGUgYSBjb21wb25lbnQgd2l0aCB2YWxpZCBET00nLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuXG4gICAgICAgICB0Y2IuY3JlYXRlQXN5bmMoQ2hpbGRDb21wKS50aGVuKChjb21wb25lbnRGaXh0dXJlKSA9PiB7XG4gICAgICAgICAgIGNvbXBvbmVudEZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgIGV4cGVjdChjb21wb25lbnRGaXh0dXJlLm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ09yaWdpbmFsIENoaWxkJyk7XG4gICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgYWxsb3cgY2hhbmdpbmcgbWVtYmVycyBvZiB0aGUgY29tcG9uZW50JyxcbiAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcblxuICAgICAgICAgdGNiLmNyZWF0ZUFzeW5jKE15SWZDb21wKS50aGVuKChjb21wb25lbnRGaXh0dXJlKSA9PiB7XG4gICAgICAgICAgIGNvbXBvbmVudEZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICBleHBlY3QoY29tcG9uZW50Rml4dHVyZS5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdNeUlmKCknKTtcblxuICAgICAgICAgICBjb21wb25lbnRGaXh0dXJlLmNvbXBvbmVudEluc3RhbmNlLnNob3dNb3JlID0gdHJ1ZTtcbiAgICAgICAgICAgY29tcG9uZW50Rml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgIGV4cGVjdChjb21wb25lbnRGaXh0dXJlLm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ015SWYoTW9yZSknKTtcblxuICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIG92ZXJyaWRlIGEgdGVtcGxhdGUnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuXG4gICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShNb2NrQ2hpbGRDb21wLCAnPHNwYW4+TW9jazwvc3Bhbj4nKVxuICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNb2NrQ2hpbGRDb21wKVxuICAgICAgICAgICAgIC50aGVuKChjb21wb25lbnRGaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICBjb21wb25lbnRGaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChjb21wb25lbnRGaXh0dXJlLm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ01vY2snKTtcblxuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgb3ZlcnJpZGUgYSB2aWV3JyxcbiAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcblxuICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhDaGlsZENvbXAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5ldyBWaWV3TWV0YWRhdGEoe3RlbXBsYXRlOiAnPHNwYW4+TW9kaWZpZWQge3tjaGlsZEJpbmRpbmd9fTwvc3Bhbj4nfSkpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKENoaWxkQ29tcClcbiAgICAgICAgICAgICAudGhlbigoY29tcG9uZW50Rml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgY29tcG9uZW50Rml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICBleHBlY3QoY29tcG9uZW50Rml4dHVyZS5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdNb2RpZmllZCBDaGlsZCcpO1xuXG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBvdmVycmlkZSBjb21wb25lbnQgZGVwZW5kZW5jaWVzJyxcbiAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcblxuICAgICAgICAgdGNiLm92ZXJyaWRlRGlyZWN0aXZlKFBhcmVudENvbXAsIENoaWxkQ29tcCwgTW9ja0NoaWxkQ29tcClcbiAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoUGFyZW50Q29tcClcbiAgICAgICAgICAgICAudGhlbigoY29tcG9uZW50Rml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgY29tcG9uZW50Rml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICBleHBlY3QoY29tcG9uZW50Rml4dHVyZS5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdQYXJlbnQoTW9jayknKTtcblxuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuXG4gICAgaXQoXCJzaG91bGQgb3ZlcnJpZGUgY2hpbGQgY29tcG9uZW50J3MgZGVwZW5kZW5jaWVzXCIsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG5cbiAgICAgICAgIHRjYi5vdmVycmlkZURpcmVjdGl2ZShQYXJlbnRDb21wLCBDaGlsZENvbXAsIENoaWxkV2l0aENoaWxkQ29tcClcbiAgICAgICAgICAgICAub3ZlcnJpZGVEaXJlY3RpdmUoQ2hpbGRXaXRoQ2hpbGRDb21wLCBDaGlsZENoaWxkQ29tcCwgTW9ja0NoaWxkQ2hpbGRDb21wKVxuICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhQYXJlbnRDb21wKVxuICAgICAgICAgICAgIC50aGVuKChjb21wb25lbnRGaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICBjb21wb25lbnRGaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChjb21wb25lbnRGaXh0dXJlLm5hdGl2ZUVsZW1lbnQpXG4gICAgICAgICAgICAgICAgICAgLnRvSGF2ZVRleHQoJ1BhcmVudChPcmlnaW5hbCBDaGlsZChDaGlsZENoaWxkIE1vY2spKScpO1xuXG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBvdmVycmlkZSBhIHByb3ZpZGVyJyxcbiAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcblxuICAgICAgICAgdGNiLm92ZXJyaWRlUHJvdmlkZXJzKFRlc3RCaW5kaW5nc0NvbXAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3Byb3ZpZGUoRmFuY3lTZXJ2aWNlLCB7dXNlQ2xhc3M6IE1vY2tGYW5jeVNlcnZpY2V9KV0pXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKFRlc3RCaW5kaW5nc0NvbXApXG4gICAgICAgICAgICAgLnRoZW4oKGNvbXBvbmVudEZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgIGNvbXBvbmVudEZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KGNvbXBvbmVudEZpeHR1cmUubmF0aXZlRWxlbWVudClcbiAgICAgICAgICAgICAgICAgICAudG9IYXZlVGV4dCgnaW5qZWN0ZWQgdmFsdWU6IG1vY2tlZCBvdXQgdmFsdWUnKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cblxuICAgIGl0KCdzaG91bGQgb3ZlcnJpZGUgYSB2aWV3QmluZGluZycsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG5cbiAgICAgICAgIHRjYi5vdmVycmlkZVZpZXdQcm92aWRlcnMoVGVzdFZpZXdCaW5kaW5nc0NvbXAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtwcm92aWRlKEZhbmN5U2VydmljZSwge3VzZUNsYXNzOiBNb2NrRmFuY3lTZXJ2aWNlfSldKVxuICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhUZXN0Vmlld0JpbmRpbmdzQ29tcClcbiAgICAgICAgICAgICAudGhlbigoY29tcG9uZW50Rml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgY29tcG9uZW50Rml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICBleHBlY3QoY29tcG9uZW50Rml4dHVyZS5uYXRpdmVFbGVtZW50KVxuICAgICAgICAgICAgICAgICAgIC50b0hhdmVUZXh0KCdpbmplY3RlZCB2YWx1ZTogbW9ja2VkIG91dCB2YWx1ZScpO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcbiAgfSk7XG59XG4iXX0=
 main(); 
