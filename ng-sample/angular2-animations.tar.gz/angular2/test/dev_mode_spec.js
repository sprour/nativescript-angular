'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var lang_1 = require('angular2/src/facade/lang');
function main() {
    testing_internal_1.describe('dev mode', function () {
        testing_internal_1.it('is enabled in our tests by default', function () { testing_internal_1.expect(lang_1.assertionsEnabled()).toBe(true); });
    });
    if (lang_1.IS_DART) {
        testing_internal_1.describe('checked mode', function () {
            testing_internal_1.it('is enabled in our tests', function () {
                try {
                    var s = 42;
                    testing_internal_1.expect(s).toEqual(42); // without it, dart analyzer will complain that `s` is not used.
                    throw "should not be reached";
                }
                catch (e) {
                }
            });
        });
    }
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGV2X21vZGVfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvZGV2X21vZGVfc3BlYy50cyJdLCJuYW1lcyI6WyJtYWluIl0sIm1hcHBpbmdzIjoiQUFBQSxpQ0FXTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLHFCQUF5QywwQkFBMEIsQ0FBQyxDQUFBO0FBRXBFO0lBQ0VBLDJCQUFRQSxDQUFDQSxVQUFVQSxFQUFFQTtRQUNuQkEscUJBQUVBLENBQUNBLG9DQUFvQ0EsRUFBRUEsY0FBUUEseUJBQU1BLENBQUNBLHdCQUFpQkEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDOUZBLENBQUNBLENBQUNBLENBQUNBO0lBRUhBLEVBQUVBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLENBQUNBLENBQUNBO1FBQ1pBLDJCQUFRQSxDQUFDQSxjQUFjQSxFQUFFQTtZQUN2QkEscUJBQUVBLENBQUNBLHlCQUF5QkEsRUFBRUE7Z0JBQzVCQSxJQUFJQSxDQUFDQTtvQkFDSEEsSUFBSUEsQ0FBQ0EsR0FBZ0JBLEVBQUVBLENBQUNBO29CQUN4QkEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUVBLGdFQUFnRUE7b0JBQ3hGQSxNQUFNQSx1QkFBdUJBLENBQUNBO2dCQUNoQ0EsQ0FBRUE7Z0JBQUFBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUNiQSxDQUFDQTtZQUNIQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUNMQSxDQUFDQTtBQUNIQSxDQUFDQTtBQWpCZSxZQUFJLE9BaUJuQixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXN5bmNUZXN0Q29tcGxldGVyLFxuICBiZWZvcmVFYWNoLFxuICBkZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICBleHBlY3QsXG4gIGlpdCxcbiAgaW5qZWN0LFxuICBpdCxcbiAgeGRlc2NyaWJlLFxuICB4aXRcbn0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmltcG9ydCB7YXNzZXJ0aW9uc0VuYWJsZWQsIElTX0RBUlR9IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvbGFuZyc7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgnZGV2IG1vZGUnLCAoKSA9PiB7XG4gICAgaXQoJ2lzIGVuYWJsZWQgaW4gb3VyIHRlc3RzIGJ5IGRlZmF1bHQnLCAoKSA9PiB7IGV4cGVjdChhc3NlcnRpb25zRW5hYmxlZCgpKS50b0JlKHRydWUpOyB9KTtcbiAgfSk7XG5cbiAgaWYgKElTX0RBUlQpIHtcbiAgICBkZXNjcmliZSgnY2hlY2tlZCBtb2RlJywgKCkgPT4ge1xuICAgICAgaXQoJ2lzIGVuYWJsZWQgaW4gb3VyIHRlc3RzJywgKCkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHZhciBzOiBzdHJpbmcgPSA8YW55PjQyO1xuICAgICAgICAgIGV4cGVjdChzKS50b0VxdWFsKDQyKTsgIC8vIHdpdGhvdXQgaXQsIGRhcnQgYW5hbHl6ZXIgd2lsbCBjb21wbGFpbiB0aGF0IGBzYCBpcyBub3QgdXNlZC5cbiAgICAgICAgICB0aHJvdyBcInNob3VsZCBub3QgYmUgcmVhY2hlZFwiO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG59XG4iXX0=
 main(); 
