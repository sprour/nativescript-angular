'use strict';var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var client_message_broker_1 = require('angular2/src/web_workers/shared/client_message_broker');
var testing_internal_1 = require('angular2/testing_internal');
var SpyMessageBroker = (function (_super) {
    __extends(SpyMessageBroker, _super);
    function SpyMessageBroker() {
        _super.call(this, client_message_broker_1.ClientMessageBroker);
    }
    return SpyMessageBroker;
})(testing_internal_1.SpyObject);
exports.SpyMessageBroker = SpyMessageBroker;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3BpZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L3dlYl93b3JrZXJzL3dvcmtlci9zcGllcy50cyJdLCJuYW1lcyI6WyJTcHlNZXNzYWdlQnJva2VyIiwiU3B5TWVzc2FnZUJyb2tlci5jb25zdHJ1Y3RvciJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxzQ0FBa0MsdURBQXVELENBQUMsQ0FBQTtBQUUxRixpQ0FBK0IsMkJBQTJCLENBQUMsQ0FBQTtBQUUzRDtJQUFzQ0Esb0NBQVNBO0lBQzdDQTtRQUFnQkMsa0JBQU1BLDJDQUFtQkEsQ0FBQ0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFDL0NELHVCQUFDQTtBQUFEQSxDQUFDQSxBQUZELEVBQXNDLDRCQUFTLEVBRTlDO0FBRlksd0JBQWdCLG1CQUU1QixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDbGllbnRNZXNzYWdlQnJva2VyfSBmcm9tICdhbmd1bGFyMi9zcmMvd2ViX3dvcmtlcnMvc2hhcmVkL2NsaWVudF9tZXNzYWdlX2Jyb2tlcic7XG5cbmltcG9ydCB7U3B5T2JqZWN0LCBwcm94eX0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmV4cG9ydCBjbGFzcyBTcHlNZXNzYWdlQnJva2VyIGV4dGVuZHMgU3B5T2JqZWN0IHtcbiAgY29uc3RydWN0b3IoKSB7IHN1cGVyKENsaWVudE1lc3NhZ2VCcm9rZXIpOyB9XG59XG4iXX0=