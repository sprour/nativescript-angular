import { SpyObject } from 'angular2/testing_internal';
export declare class SpyMessageBroker extends SpyObject {
    constructor();
}
