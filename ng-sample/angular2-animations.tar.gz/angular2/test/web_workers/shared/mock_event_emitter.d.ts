import { EventEmitter } from 'angular2/src/facade/async';
export declare class MockEventEmitter<T> extends EventEmitter<T> {
    private _nextFns;
    constructor();
    subscribe(generator: any): any;
    emit(value: any): void;
}
