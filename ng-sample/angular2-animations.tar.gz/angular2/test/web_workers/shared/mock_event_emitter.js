'use strict';var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var async_1 = require('angular2/src/facade/async');
var MockEventEmitter = (function (_super) {
    __extends(MockEventEmitter, _super);
    function MockEventEmitter() {
        _super.call(this);
        this._nextFns = [];
    }
    MockEventEmitter.prototype.subscribe = function (generator) {
        this._nextFns.push(generator.next);
        return new MockDisposable();
    };
    MockEventEmitter.prototype.emit = function (value) { this._nextFns.forEach(function (fn) { return fn(value); }); };
    return MockEventEmitter;
})(async_1.EventEmitter);
exports.MockEventEmitter = MockEventEmitter;
var MockDisposable = (function () {
    function MockDisposable() {
        this.isUnsubscribed = false;
    }
    MockDisposable.prototype.unsubscribe = function () { };
    return MockDisposable;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9ja19ldmVudF9lbWl0dGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC93ZWJfd29ya2Vycy9zaGFyZWQvbW9ja19ldmVudF9lbWl0dGVyLnRzIl0sIm5hbWVzIjpbIk1vY2tFdmVudEVtaXR0ZXIiLCJNb2NrRXZlbnRFbWl0dGVyLmNvbnN0cnVjdG9yIiwiTW9ja0V2ZW50RW1pdHRlci5zdWJzY3JpYmUiLCJNb2NrRXZlbnRFbWl0dGVyLmVtaXQiLCJNb2NrRGlzcG9zYWJsZSIsIk1vY2tEaXNwb3NhYmxlLmNvbnN0cnVjdG9yIiwiTW9ja0Rpc3Bvc2FibGUudW5zdWJzY3JpYmUiXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsc0JBQTJCLDJCQUEyQixDQUFDLENBQUE7QUFFdkQ7SUFBeUNBLG9DQUFlQTtJQUd0REE7UUFBZ0JDLGlCQUFPQSxDQUFDQTtRQUZoQkEsYUFBUUEsR0FBZUEsRUFBRUEsQ0FBQ0E7SUFFVEEsQ0FBQ0E7SUFFMUJELG9DQUFTQSxHQUFUQSxVQUFVQSxTQUFjQTtRQUN0QkUsSUFBSUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7UUFDbkNBLE1BQU1BLENBQUNBLElBQUlBLGNBQWNBLEVBQUVBLENBQUNBO0lBQzlCQSxDQUFDQTtJQUVERiwrQkFBSUEsR0FBSkEsVUFBS0EsS0FBVUEsSUFBSUcsSUFBSUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsVUFBQUEsRUFBRUEsSUFBSUEsT0FBQUEsRUFBRUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsRUFBVEEsQ0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDOURILHVCQUFDQTtBQUFEQSxDQUFDQSxBQVhELEVBQXlDLG9CQUFZLEVBV3BEO0FBWFksd0JBQWdCLG1CQVc1QixDQUFBO0FBRUQ7SUFBQUk7UUFDRUMsbUJBQWNBLEdBQVlBLEtBQUtBLENBQUNBO0lBRWxDQSxDQUFDQTtJQURDRCxvQ0FBV0EsR0FBWEEsY0FBcUJFLENBQUNBO0lBQ3hCRixxQkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtFdmVudEVtaXR0ZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvYXN5bmMnO1xuXG5leHBvcnQgY2xhc3MgTW9ja0V2ZW50RW1pdHRlcjxUPiBleHRlbmRzIEV2ZW50RW1pdHRlcjxUPiB7XG4gIHByaXZhdGUgX25leHRGbnM6IEZ1bmN0aW9uW10gPSBbXTtcblxuICBjb25zdHJ1Y3RvcigpIHsgc3VwZXIoKTsgfVxuXG4gIHN1YnNjcmliZShnZW5lcmF0b3I6IGFueSk6IGFueSB7XG4gICAgdGhpcy5fbmV4dEZucy5wdXNoKGdlbmVyYXRvci5uZXh0KTtcbiAgICByZXR1cm4gbmV3IE1vY2tEaXNwb3NhYmxlKCk7XG4gIH1cblxuICBlbWl0KHZhbHVlOiBhbnkpIHsgdGhpcy5fbmV4dEZucy5mb3JFYWNoKGZuID0+IGZuKHZhbHVlKSk7IH1cbn1cblxuY2xhc3MgTW9ja0Rpc3Bvc2FibGUge1xuICBpc1Vuc3Vic2NyaWJlZDogYm9vbGVhbiA9IGZhbHNlO1xuICB1bnN1YnNjcmliZSgpOiB2b2lkIHt9XG59XG4iXX0=