import { MessageBus } from 'angular2/src/web_workers/shared/message_bus';
export declare function createConnectedMessageBus(): MessageBus;
