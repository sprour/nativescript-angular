'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var dom_adapter_1 = require('angular2/src/platform/dom/dom_adapter');
var async_1 = require('angular2/src/facade/async');
var core_1 = require('angular2/core');
var common_1 = require('angular2/common');
var common_dom_1 = require('angular2/platform/common_dom');
var metadata_1 = require('angular2/src/core/metadata');
var Logger = (function () {
    function Logger() {
        this.log = [];
    }
    Logger.prototype.add = function (thing) { this.log.push(thing); };
    Logger = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], Logger);
    return Logger;
})();
var MessageDir = (function () {
    function MessageDir(logger) {
        this.logger = logger;
    }
    Object.defineProperty(MessageDir.prototype, "message", {
        set: function (newMessage) { this.logger.add(newMessage); },
        enumerable: true,
        configurable: true
    });
    MessageDir = __decorate([
        metadata_1.Directive({ selector: '[message]', inputs: ['message'] }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [Logger])
    ], MessageDir);
    return MessageDir;
})();
var ChildComp = (function () {
    function ChildComp() {
        this.childBinding = 'Original';
    }
    ChildComp = __decorate([
        metadata_1.Component({
            selector: 'child-comp',
            template: "<div class=\"child\" message=\"child\">\n               <span class=\"childnested\" message=\"nestedchild\">Child</span>\n             </div>\n             <span class=\"child\" [innerHtml]=\"childBinding\"></span>",
            directives: [MessageDir],
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], ChildComp);
    return ChildComp;
})();
var ParentComp = (function () {
    function ParentComp() {
        this.parentBinding = 'OriginalParent';
    }
    ParentComp = __decorate([
        metadata_1.Component({
            selector: 'parent-comp',
            viewProviders: [Logger],
            template: "<div class=\"parent\" message=\"parent\">\n               <span class=\"parentnested\" message=\"nestedparent\">Parent</span>\n             </div>\n             <span class=\"parent\" [innerHtml]=\"parentBinding\"></span>\n             <child-comp class=\"child-comp-class\"></child-comp>",
            directives: [ChildComp, MessageDir],
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], ParentComp);
    return ParentComp;
})();
var CustomEmitter = (function () {
    function CustomEmitter() {
        this.myevent = new async_1.EventEmitter();
    }
    CustomEmitter = __decorate([
        metadata_1.Directive({ selector: 'custom-emitter', outputs: ['myevent'] }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], CustomEmitter);
    return CustomEmitter;
})();
var EventsComp = (function () {
    function EventsComp() {
        this.clicked = false;
        this.customed = false;
    }
    EventsComp.prototype.handleClick = function () { this.clicked = true; };
    EventsComp.prototype.handleCustom = function () { this.customed = true; };
    EventsComp = __decorate([
        metadata_1.Component({
            selector: 'events-comp',
            template: "<button (click)=\"handleClick()\"></button>\n             <custom-emitter (myevent)=\"handleCustom()\"></custom-emitter>",
            directives: [CustomEmitter],
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], EventsComp);
    return EventsComp;
})();
var ConditionalContentComp = (function () {
    function ConditionalContentComp() {
        this.myBool = false;
    }
    ConditionalContentComp = __decorate([
        metadata_1.Component({
            selector: 'cond-content-comp',
            viewProviders: [Logger],
            template: "<div class=\"child\" message=\"child\" *ngIf=\"myBool\"><ng-content></ng-content></div>",
            directives: [common_1.NgIf, MessageDir],
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], ConditionalContentComp);
    return ConditionalContentComp;
})();
var ConditionalParentComp = (function () {
    function ConditionalParentComp() {
        this.parentBinding = 'OriginalParent';
    }
    ConditionalParentComp = __decorate([
        metadata_1.Component({
            selector: 'conditional-parent-comp',
            viewProviders: [Logger],
            template: "<span class=\"parent\" [innerHtml]=\"parentBinding\"></span>\n            <cond-content-comp class=\"cond-content-comp-class\">\n              <span class=\"from-parent\"></span>\n            </cond-content-comp>",
            directives: [ConditionalContentComp],
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], ConditionalParentComp);
    return ConditionalParentComp;
})();
var UsingFor = (function () {
    function UsingFor() {
        this.stuff = ['one', 'two', 'three'];
    }
    UsingFor = __decorate([
        metadata_1.Component({
            selector: 'using-for',
            viewProviders: [Logger],
            template: "<span *ngFor=\"#thing of stuff\" [innerHtml]=\"thing\"></span>\n            <ul message=\"list\">\n              <li *ngFor=\"#item of stuff\" [innerHtml]=\"item\"></li>\n            </ul>",
            directives: [common_1.NgFor, MessageDir],
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], UsingFor);
    return UsingFor;
})();
var MyDir = (function () {
    function MyDir() {
    }
    MyDir = __decorate([
        metadata_1.Directive({ selector: '[mydir]', exportAs: 'mydir' }), 
        __metadata('design:paramtypes', [])
    ], MyDir);
    return MyDir;
})();
var LocalsComp = (function () {
    function LocalsComp() {
    }
    LocalsComp = __decorate([
        metadata_1.Component({
            selector: 'locals-comp',
            template: "\n   <div mydir #alice=\"mydir\"></div>\n ",
            directives: [MyDir]
        }), 
        __metadata('design:paramtypes', [])
    ], LocalsComp);
    return LocalsComp;
})();
var BankAccount = (function () {
    function BankAccount() {
    }
    __decorate([
        metadata_1.Input(), 
        __metadata('design:type', String)
    ], BankAccount.prototype, "bank", void 0);
    __decorate([
        metadata_1.Input('account'), 
        __metadata('design:type', String)
    ], BankAccount.prototype, "id", void 0);
    BankAccount = __decorate([
        metadata_1.Component({
            selector: 'bank-account',
            template: "\n   Bank Name: {{bank}}\n   Account Id: {{id}}\n "
        }), 
        __metadata('design:paramtypes', [])
    ], BankAccount);
    return BankAccount;
})();
var TestApp = (function () {
    function TestApp() {
    }
    TestApp = __decorate([
        metadata_1.Component({
            selector: 'test-app',
            template: "\n   <bank-account bank=\"RBC\" account=\"4747\"></bank-account>\n ",
            directives: [BankAccount]
        }), 
        __metadata('design:paramtypes', [])
    ], TestApp);
    return TestApp;
})();
function main() {
    testing_internal_1.describe('debug element', function () {
        testing_internal_1.it('should list all child nodes', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(ParentComp)
                .then(function (fixture) {
                fixture.detectChanges();
                // The root component has 3 elements and 2 text node children.
                testing_internal_1.expect(fixture.debugElement.childNodes.length).toEqual(5);
                async.done();
            });
        }));
        testing_internal_1.it('should list all component child elements', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(ParentComp)
                .then(function (fixture) {
                fixture.detectChanges();
                var childEls = fixture.debugElement.children;
                // The root component has 3 elements in its view.
                testing_internal_1.expect(childEls.length).toEqual(3);
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(childEls[0].nativeElement, 'parent')).toBe(true);
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(childEls[1].nativeElement, 'parent')).toBe(true);
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(childEls[2].nativeElement, 'child-comp-class')).toBe(true);
                var nested = childEls[0].children;
                testing_internal_1.expect(nested.length).toEqual(1);
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(nested[0].nativeElement, 'parentnested')).toBe(true);
                var childComponent = childEls[2];
                var childCompChildren = childComponent.children;
                testing_internal_1.expect(childCompChildren.length).toEqual(2);
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(childCompChildren[0].nativeElement, 'child')).toBe(true);
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(childCompChildren[1].nativeElement, 'child')).toBe(true);
                var childNested = childCompChildren[0].children;
                testing_internal_1.expect(childNested.length).toEqual(1);
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(childNested[0].nativeElement, 'childnested')).toBe(true);
                async.done();
            });
        }));
        testing_internal_1.it('should list conditional component child elements', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(ConditionalParentComp)
                .then(function (fixture) {
                fixture.detectChanges();
                var childEls = fixture.debugElement.children;
                // The root component has 2 elements in its view.
                testing_internal_1.expect(childEls.length).toEqual(2);
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(childEls[0].nativeElement, 'parent')).toBe(true);
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(childEls[1].nativeElement, 'cond-content-comp-class'))
                    .toBe(true);
                var conditionalContentComp = childEls[1];
                testing_internal_1.expect(conditionalContentComp.children.length).toEqual(0);
                conditionalContentComp.componentInstance.myBool = true;
                fixture.detectChanges();
                testing_internal_1.expect(conditionalContentComp.children.length).toEqual(1);
                async.done();
            });
        }));
        testing_internal_1.it('should list child elements within viewports', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(UsingFor).then(function (fixture) {
                fixture.detectChanges();
                var childEls = fixture.debugElement.children;
                testing_internal_1.expect(childEls.length).toEqual(4);
                // The 4th child is the <ul>
                var list = childEls[3];
                testing_internal_1.expect(list.children.length).toEqual(3);
                async.done();
            });
        }));
        testing_internal_1.it('should list element attributes', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(TestApp).then(function (fixture) {
                fixture.detectChanges();
                var bankElem = fixture.debugElement.children[0];
                testing_internal_1.expect(bankElem.attributes.get('bank')).toEqual('RBC');
                testing_internal_1.expect(bankElem.attributes.get('account')).toEqual('4747');
                async.done();
            });
        }));
        testing_internal_1.it('should query child elements by css', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(ParentComp)
                .then(function (fixture) {
                fixture.detectChanges();
                var childTestEls = fixture.debugElement.queryAll(common_dom_1.By.css('child-comp'));
                testing_internal_1.expect(childTestEls.length).toBe(1);
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(childTestEls[0].nativeElement, 'child-comp-class')).toBe(true);
                async.done();
            });
        }));
        testing_internal_1.it('should query child elements by directive', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(ParentComp)
                .then(function (fixture) {
                fixture.detectChanges();
                var childTestEls = fixture.debugElement.queryAll(common_dom_1.By.directive(MessageDir));
                testing_internal_1.expect(childTestEls.length).toBe(4);
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(childTestEls[0].nativeElement, 'parent')).toBe(true);
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(childTestEls[1].nativeElement, 'parentnested')).toBe(true);
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(childTestEls[2].nativeElement, 'child')).toBe(true);
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(childTestEls[3].nativeElement, 'childnested')).toBe(true);
                async.done();
            });
        }));
        testing_internal_1.it('should list providerTokens', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(ParentComp)
                .then(function (fixture) {
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.providerTokens).toContain(Logger);
                async.done();
            });
        }));
        testing_internal_1.it('should list locals', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(LocalsComp)
                .then(function (fixture) {
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.children[0].getLocal('alice')).toBeAnInstanceOf(MyDir);
                async.done();
            });
        }));
        testing_internal_1.it('should allow injecting from the element injector', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(ParentComp)
                .then(function (fixture) {
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.children[0].inject(Logger).log)
                    .toEqual(['parent', 'nestedparent', 'child', 'nestedchild']);
                async.done();
            });
        }));
        testing_internal_1.it('should list event listeners', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(EventsComp)
                .then(function (fixture) {
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.children[0].listeners.length).toEqual(1);
                testing_internal_1.expect(fixture.debugElement.children[1].listeners.length).toEqual(1);
                async.done();
            });
        }));
        testing_internal_1.it('should trigger event handlers', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(EventsComp)
                .then(function (fixture) {
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.componentInstance.clicked).toBe(false);
                testing_internal_1.expect(fixture.debugElement.componentInstance.customed).toBe(false);
                fixture.debugElement.children[0].triggerEventHandler('click', {});
                testing_internal_1.expect(fixture.debugElement.componentInstance.clicked).toBe(true);
                fixture.debugElement.children[1].triggerEventHandler('myevent', {});
                testing_internal_1.expect(fixture.debugElement.componentInstance.customed).toBe(true);
                async.done();
            });
        }));
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVidWdfbm9kZV9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb3JlL2RlYnVnL2RlYnVnX25vZGVfc3BlYy50cyJdLCJuYW1lcyI6WyJMb2dnZXIiLCJMb2dnZXIuY29uc3RydWN0b3IiLCJMb2dnZXIuYWRkIiwiTWVzc2FnZURpciIsIk1lc3NhZ2VEaXIuY29uc3RydWN0b3IiLCJNZXNzYWdlRGlyLm1lc3NhZ2UiLCJDaGlsZENvbXAiLCJDaGlsZENvbXAuY29uc3RydWN0b3IiLCJQYXJlbnRDb21wIiwiUGFyZW50Q29tcC5jb25zdHJ1Y3RvciIsIkN1c3RvbUVtaXR0ZXIiLCJDdXN0b21FbWl0dGVyLmNvbnN0cnVjdG9yIiwiRXZlbnRzQ29tcCIsIkV2ZW50c0NvbXAuY29uc3RydWN0b3IiLCJFdmVudHNDb21wLmhhbmRsZUNsaWNrIiwiRXZlbnRzQ29tcC5oYW5kbGVDdXN0b20iLCJDb25kaXRpb25hbENvbnRlbnRDb21wIiwiQ29uZGl0aW9uYWxDb250ZW50Q29tcC5jb25zdHJ1Y3RvciIsIkNvbmRpdGlvbmFsUGFyZW50Q29tcCIsIkNvbmRpdGlvbmFsUGFyZW50Q29tcC5jb25zdHJ1Y3RvciIsIlVzaW5nRm9yIiwiVXNpbmdGb3IuY29uc3RydWN0b3IiLCJNeURpciIsIk15RGlyLmNvbnN0cnVjdG9yIiwiTG9jYWxzQ29tcCIsIkxvY2Fsc0NvbXAuY29uc3RydWN0b3IiLCJCYW5rQWNjb3VudCIsIkJhbmtBY2NvdW50LmNvbnN0cnVjdG9yIiwiVGVzdEFwcCIsIlRlc3RBcHAuY29uc3RydWN0b3IiLCJtYWluIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxpQ0FjTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLDRCQUFrQix1Q0FBdUMsQ0FBQyxDQUFBO0FBRTFELHNCQUE4RCwyQkFBMkIsQ0FBQyxDQUFBO0FBRTFGLHFCQUF5QixlQUFlLENBQUMsQ0FBQTtBQUN6Qyx1QkFBMEIsaUJBQWlCLENBQUMsQ0FBQTtBQUM1QywyQkFBaUIsOEJBQThCLENBQUMsQ0FBQTtBQUVoRCx5QkFBMEMsNEJBQTRCLENBQUMsQ0FBQTtBQUV2RTtJQUlFQTtRQUFnQkMsSUFBSUEsQ0FBQ0EsR0FBR0EsR0FBR0EsRUFBRUEsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFFaENELG9CQUFHQSxHQUFIQSxVQUFJQSxLQUFhQSxJQUFJRSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQU45Q0Y7UUFBQ0EsaUJBQVVBLEVBQUVBOztlQU9aQTtJQUFEQSxhQUFDQTtBQUFEQSxDQUFDQSxBQVBELElBT0M7QUFFRDtJQUtFRyxvQkFBWUEsTUFBY0E7UUFBSUMsSUFBSUEsQ0FBQ0EsTUFBTUEsR0FBR0EsTUFBTUEsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFFckRELHNCQUFJQSwrQkFBT0E7YUFBWEEsVUFBWUEsVUFBVUEsSUFBSUUsSUFBSUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7OztPQUFBRjtJQVAxREE7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLFdBQVdBLEVBQUVBLE1BQU1BLEVBQUVBLENBQUNBLFNBQVNBLENBQUNBLEVBQUNBLENBQUNBO1FBQ3ZEQSxpQkFBVUEsRUFBRUE7O21CQU9aQTtJQUFEQSxpQkFBQ0E7QUFBREEsQ0FBQ0EsQUFSRCxJQVFDO0FBRUQ7SUFZRUc7UUFBZ0JDLElBQUlBLENBQUNBLFlBQVlBLEdBQUdBLFVBQVVBLENBQUNBO0lBQUNBLENBQUNBO0lBWm5ERDtRQUFDQSxvQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsWUFBWUE7WUFDdEJBLFFBQVFBLEVBQUVBLHdOQUd3REE7WUFDbEVBLFVBQVVBLEVBQUVBLENBQUNBLFVBQVVBLENBQUNBO1NBQ3pCQSxDQUFDQTtRQUNEQSxpQkFBVUEsRUFBRUE7O2tCQUtaQTtJQUFEQSxnQkFBQ0E7QUFBREEsQ0FBQ0EsQUFiRCxJQWFDO0FBRUQ7SUFhRUU7UUFBZ0JDLElBQUlBLENBQUNBLGFBQWFBLEdBQUdBLGdCQUFnQkEsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFiMUREO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxhQUFhQTtZQUN2QkEsYUFBYUEsRUFBRUEsQ0FBQ0EsTUFBTUEsQ0FBQ0E7WUFDdkJBLFFBQVFBLEVBQUVBLGtTQUlvREE7WUFDOURBLFVBQVVBLEVBQUVBLENBQUNBLFNBQVNBLEVBQUVBLFVBQVVBLENBQUNBO1NBQ3BDQSxDQUFDQTtRQUNEQSxpQkFBVUEsRUFBRUE7O21CQUlaQTtJQUFEQSxpQkFBQ0E7QUFBREEsQ0FBQ0EsQUFkRCxJQWNDO0FBRUQ7SUFLRUU7UUFBZ0JDLElBQUlBLENBQUNBLE9BQU9BLEdBQUdBLElBQUlBLG9CQUFZQSxFQUFFQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUx0REQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLGdCQUFnQkEsRUFBRUEsT0FBT0EsRUFBRUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7UUFDN0RBLGlCQUFVQSxFQUFFQTs7c0JBS1pBO0lBQURBLG9CQUFDQTtBQUFEQSxDQUFDQSxBQU5ELElBTUM7QUFFRDtJQVdFRTtRQUNFQyxJQUFJQSxDQUFDQSxPQUFPQSxHQUFHQSxLQUFLQSxDQUFDQTtRQUNyQkEsSUFBSUEsQ0FBQ0EsUUFBUUEsR0FBR0EsS0FBS0EsQ0FBQ0E7SUFDeEJBLENBQUNBO0lBRURELGdDQUFXQSxHQUFYQSxjQUFnQkUsSUFBSUEsQ0FBQ0EsT0FBT0EsR0FBR0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFFdENGLGlDQUFZQSxHQUFaQSxjQUFpQkcsSUFBSUEsQ0FBQ0EsUUFBUUEsR0FBR0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFsQjFDSDtRQUFDQSxvQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsYUFBYUE7WUFDdkJBLFFBQVFBLEVBQUVBLDBIQUM4REE7WUFDeEVBLFVBQVVBLEVBQUVBLENBQUNBLGFBQWFBLENBQUNBO1NBQzVCQSxDQUFDQTtRQUNEQSxpQkFBVUEsRUFBRUE7O21CQWFaQTtJQUFEQSxpQkFBQ0E7QUFBREEsQ0FBQ0EsQUFuQkQsSUFtQkM7QUFFRDtJQUFBSTtRQVFFQyxXQUFNQSxHQUFZQSxLQUFLQSxDQUFDQTtJQUMxQkEsQ0FBQ0E7SUFUREQ7UUFBQ0Esb0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLG1CQUFtQkE7WUFDN0JBLGFBQWFBLEVBQUVBLENBQUNBLE1BQU1BLENBQUNBO1lBQ3ZCQSxRQUFRQSxFQUFFQSx5RkFBbUZBO1lBQzdGQSxVQUFVQSxFQUFFQSxDQUFDQSxhQUFJQSxFQUFFQSxVQUFVQSxDQUFDQTtTQUMvQkEsQ0FBQ0E7UUFDREEsaUJBQVVBLEVBQUVBOzsrQkFHWkE7SUFBREEsNkJBQUNBO0FBQURBLENBQUNBLEFBVEQsSUFTQztBQUVEO0lBWUVFO1FBQWdCQyxJQUFJQSxDQUFDQSxhQUFhQSxHQUFHQSxnQkFBZ0JBLENBQUNBO0lBQUNBLENBQUNBO0lBWjFERDtRQUFDQSxvQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEseUJBQXlCQTtZQUNuQ0EsYUFBYUEsRUFBRUEsQ0FBQ0EsTUFBTUEsQ0FBQ0E7WUFDdkJBLFFBQVFBLEVBQUVBLHNOQUdxQkE7WUFDL0JBLFVBQVVBLEVBQUVBLENBQUNBLHNCQUFzQkEsQ0FBQ0E7U0FDckNBLENBQUNBO1FBQ0RBLGlCQUFVQSxFQUFFQTs7OEJBSVpBO0lBQURBLDRCQUFDQTtBQUFEQSxDQUFDQSxBQWJELElBYUM7QUFFRDtJQVlFRTtRQUFnQkMsSUFBSUEsQ0FBQ0EsS0FBS0EsR0FBR0EsQ0FBQ0EsS0FBS0EsRUFBRUEsS0FBS0EsRUFBRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFaekREO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxXQUFXQTtZQUNyQkEsYUFBYUEsRUFBRUEsQ0FBQ0EsTUFBTUEsQ0FBQ0E7WUFDdkJBLFFBQVFBLEVBQUVBLDhMQUdNQTtZQUNoQkEsVUFBVUEsRUFBRUEsQ0FBQ0EsY0FBS0EsRUFBRUEsVUFBVUEsQ0FBQ0E7U0FDaENBLENBQUNBO1FBQ0RBLGlCQUFVQSxFQUFFQTs7aUJBSVpBO0lBQURBLGVBQUNBO0FBQURBLENBQUNBLEFBYkQsSUFhQztBQUVEO0lBQUFFO0lBRUFDLENBQUNBO0lBRkREO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxTQUFTQSxFQUFFQSxRQUFRQSxFQUFFQSxPQUFPQSxFQUFDQSxDQUFDQTs7Y0FFbkRBO0lBQURBLFlBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBQUFFO0lBUUFDLENBQUNBO0lBUkREO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxhQUFhQTtZQUN2QkEsUUFBUUEsRUFBRUEsNENBRVZBO1lBQ0FBLFVBQVVBLEVBQUVBLENBQUNBLEtBQUtBLENBQUNBO1NBQ3BCQSxDQUFDQTs7bUJBRURBO0lBQURBLGlCQUFDQTtBQUFEQSxDQUFDQSxBQVJELElBUUM7QUFHRDtJQUFBRTtJQVlBQyxDQUFDQTtJQUpDRDtRQUFDQSxnQkFBS0EsRUFBRUE7O09BQUNBLDZCQUFJQSxVQUFTQTtJQUN0QkE7UUFBQ0EsZ0JBQUtBLENBQUNBLFNBQVNBLENBQUNBOztPQUFDQSwyQkFBRUEsVUFBU0E7SUFUL0JBO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxjQUFjQTtZQUN4QkEsUUFBUUEsRUFBRUEsb0RBR1ZBO1NBQ0RBLENBQUNBOztvQkFNREE7SUFBREEsa0JBQUNBO0FBQURBLENBQUNBLEFBWkQsSUFZQztBQUVEO0lBQUFFO0lBUUFDLENBQUNBO0lBUkREO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxVQUFVQTtZQUNwQkEsUUFBUUEsRUFBRUEscUVBRVZBO1lBQ0FBLFVBQVVBLEVBQUVBLENBQUNBLFdBQVdBLENBQUNBO1NBQzFCQSxDQUFDQTs7Z0JBRURBO0lBQURBLGNBQUNBO0FBQURBLENBQUNBLEFBUkQsSUFRQztBQUVEO0lBQ0VFLDJCQUFRQSxDQUFDQSxlQUFlQSxFQUFFQTtRQUN4QixxQkFBRSxDQUFDLDZCQUE2QixFQUM3Qix5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztZQUNsRixHQUFHLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQztpQkFDdEIsSUFBSSxDQUFDLFVBQUMsT0FBTztnQkFDWixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBRXhCLDhEQUE4RDtnQkFDOUQseUJBQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzFELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNmLENBQUMsQ0FBQyxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVQLHFCQUFFLENBQUMsMENBQTBDLEVBQzFDLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO1lBRWxGLEdBQUcsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDO2lCQUN0QixJQUFJLENBQUMsVUFBQyxPQUFPO2dCQUNaLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFFeEIsSUFBSSxRQUFRLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUM7Z0JBRTdDLGlEQUFpRDtnQkFDakQseUJBQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNuQyx5QkFBTSxDQUFDLGlCQUFHLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3JFLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDckUseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxFQUFFLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRS9FLElBQUksTUFBTSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7Z0JBQ2xDLHlCQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakMseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxFQUFFLGNBQWMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUV6RSxJQUFJLGNBQWMsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRWpDLElBQUksaUJBQWlCLEdBQUcsY0FBYyxDQUFDLFFBQVEsQ0FBQztnQkFDaEQseUJBQU0sQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzVDLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUM3RSx5QkFBTSxDQUFDLGlCQUFHLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFFN0UsSUFBSSxXQUFXLEdBQUcsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO2dCQUNoRCx5QkFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3RDLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxhQUFhLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFFN0UsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRVAscUJBQUUsQ0FBQyxrREFBa0QsRUFDbEQseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7WUFDbEYsR0FBRyxDQUFDLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQztpQkFDakMsSUFBSSxDQUFDLFVBQUMsT0FBTztnQkFDWixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBRXhCLElBQUksUUFBUSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDO2dCQUU3QyxpREFBaUQ7Z0JBQ2pELHlCQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDbkMseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNyRSx5QkFBTSxDQUFDLGlCQUFHLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUUseUJBQXlCLENBQUMsQ0FBQztxQkFDckUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUVoQixJQUFJLHNCQUFzQixHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFekMseUJBQU0sQ0FBQyxzQkFBc0IsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUUxRCxzQkFBc0IsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO2dCQUN2RCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBRXhCLHlCQUFNLENBQUMsc0JBQXNCLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDMUQsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRVAscUJBQUUsQ0FBQyw2Q0FBNkMsRUFDN0MseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7WUFDbEYsR0FBRyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxPQUFPO2dCQUNyQyxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBRXhCLElBQUksUUFBUSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDO2dCQUM3Qyx5QkFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRW5DLDRCQUE0QjtnQkFDNUIsSUFBSSxJQUFJLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUV2Qix5QkFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUV4QyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDZixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFUCxxQkFBRSxDQUFDLGdDQUFnQyxFQUNoQyx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztZQUNsRixHQUFHLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFDLE9BQU87Z0JBQ3BDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDeEIsSUFBSSxRQUFRLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRWhELHlCQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3ZELHlCQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQzNELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNmLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVQLHFCQUFFLENBQUMsb0NBQW9DLEVBQ3BDLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO1lBQ2xGLEdBQUcsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDO2lCQUN0QixJQUFJLENBQUMsVUFBQyxPQUFPO2dCQUNaLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFFeEIsSUFBSSxZQUFZLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsZUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO2dCQUV2RSx5QkFBTSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BDLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUVuRixLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDZixDQUFDLENBQUMsQ0FBQztRQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFUCxxQkFBRSxDQUFDLDBDQUEwQyxFQUMxQyx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztZQUNsRixHQUFHLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQztpQkFDdEIsSUFBSSxDQUFDLFVBQUMsT0FBTztnQkFDWixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBRXhCLElBQUksWUFBWSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLGVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztnQkFFM0UseUJBQU0sQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwQyx5QkFBTSxDQUFDLGlCQUFHLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3pFLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDL0UseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN4RSx5QkFBTSxDQUFDLGlCQUFHLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRTlFLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNmLENBQUMsQ0FBQyxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVQLHFCQUFFLENBQUMsNEJBQTRCLEVBQzVCLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO1lBRWxGLEdBQUcsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDO2lCQUN0QixJQUFJLENBQUMsVUFBQyxPQUFPO2dCQUNaLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFFeEIseUJBQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFFOUQsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRVAscUJBQUUsQ0FBQyxvQkFBb0IsRUFDcEIseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7WUFDbEYsR0FBRyxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUM7aUJBQ3RCLElBQUksQ0FBQyxVQUFDLE9BQU87Z0JBQ1osT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUV4Qix5QkFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUVuRixLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDZixDQUFDLENBQUMsQ0FBQztRQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFUCxxQkFBRSxDQUFDLGtEQUFrRCxFQUNsRCx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztZQUVsRixHQUFHLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQztpQkFDdEIsSUFBSSxDQUFDLFVBQUMsT0FBTztnQkFDWixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBRXhCLHlCQUFNLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQztxQkFDdEQsT0FBTyxDQUFDLENBQUMsUUFBUSxFQUFFLGNBQWMsRUFBRSxPQUFPLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FBQztnQkFFakUsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRVAscUJBQUUsQ0FBQyw2QkFBNkIsRUFDN0IseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7WUFFbEYsR0FBRyxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUM7aUJBQ3RCLElBQUksQ0FBQyxVQUFDLE9BQU87Z0JBQ1osT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUV4Qix5QkFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JFLHlCQUFNLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFckUsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBR1AscUJBQUUsQ0FBQywrQkFBK0IsRUFDL0IseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7WUFFbEYsR0FBRyxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUM7aUJBQ3RCLElBQUksQ0FBQyxVQUFDLE9BQU87Z0JBQ1osT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUV4Qix5QkFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuRSx5QkFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUVwRSxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLEVBQVMsRUFBRSxDQUFDLENBQUM7Z0JBQ3pFLHlCQUFNLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRWxFLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLFNBQVMsRUFBUyxFQUFFLENBQUMsQ0FBQztnQkFDM0UseUJBQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFFbkUsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ1QsQ0FBQyxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQWxOZSxZQUFJLE9Ba05uQixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXN5bmNUZXN0Q29tcGxldGVyLFxuICBiZWZvcmVFYWNoLFxuICBkZGVzY3JpYmUsXG4gIHhkZXNjcmliZSxcbiAgZGVzY3JpYmUsXG4gIGRpc3BhdGNoRXZlbnQsXG4gIGV4cGVjdCxcbiAgaWl0LFxuICBpbmplY3QsXG4gIGJlZm9yZUVhY2hQcm92aWRlcnMsXG4gIGl0LFxuICB4aXQsXG4gIFRlc3RDb21wb25lbnRCdWlsZGVyXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5pbXBvcnQge0RPTX0gZnJvbSAnYW5ndWxhcjIvc3JjL3BsYXRmb3JtL2RvbS9kb21fYWRhcHRlcic7XG5cbmltcG9ydCB7UHJvbWlzZVdyYXBwZXIsIEV2ZW50RW1pdHRlciwgT2JzZXJ2YWJsZVdyYXBwZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvYXN5bmMnO1xuXG5pbXBvcnQge0luamVjdGFibGV9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuaW1wb3J0IHtOZ0ZvciwgTmdJZn0gZnJvbSAnYW5ndWxhcjIvY29tbW9uJztcbmltcG9ydCB7Qnl9IGZyb20gJ2FuZ3VsYXIyL3BsYXRmb3JtL2NvbW1vbl9kb20nO1xuXG5pbXBvcnQge0RpcmVjdGl2ZSwgQ29tcG9uZW50LCBJbnB1dH0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvbWV0YWRhdGEnO1xuXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBMb2dnZXIge1xuICBsb2c6IHN0cmluZ1tdO1xuXG4gIGNvbnN0cnVjdG9yKCkgeyB0aGlzLmxvZyA9IFtdOyB9XG5cbiAgYWRkKHRoaW5nOiBzdHJpbmcpIHsgdGhpcy5sb2cucHVzaCh0aGluZyk7IH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdbbWVzc2FnZV0nLCBpbnB1dHM6IFsnbWVzc2FnZSddfSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIE1lc3NhZ2VEaXIge1xuICBsb2dnZXI6IExvZ2dlcjtcblxuICBjb25zdHJ1Y3Rvcihsb2dnZXI6IExvZ2dlcikgeyB0aGlzLmxvZ2dlciA9IGxvZ2dlcjsgfVxuXG4gIHNldCBtZXNzYWdlKG5ld01lc3NhZ2UpIHsgdGhpcy5sb2dnZXIuYWRkKG5ld01lc3NhZ2UpOyB9XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2NoaWxkLWNvbXAnLFxuICB0ZW1wbGF0ZTogYDxkaXYgY2xhc3M9XCJjaGlsZFwiIG1lc3NhZ2U9XCJjaGlsZFwiPlxuICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJjaGlsZG5lc3RlZFwiIG1lc3NhZ2U9XCJuZXN0ZWRjaGlsZFwiPkNoaWxkPC9zcGFuPlxuICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiY2hpbGRcIiBbaW5uZXJIdG1sXT1cImNoaWxkQmluZGluZ1wiPjwvc3Bhbj5gLFxuICBkaXJlY3RpdmVzOiBbTWVzc2FnZURpcl0sXG59KVxuQEluamVjdGFibGUoKVxuY2xhc3MgQ2hpbGRDb21wIHtcbiAgY2hpbGRCaW5kaW5nOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IoKSB7IHRoaXMuY2hpbGRCaW5kaW5nID0gJ09yaWdpbmFsJzsgfVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdwYXJlbnQtY29tcCcsXG4gIHZpZXdQcm92aWRlcnM6IFtMb2dnZXJdLFxuICB0ZW1wbGF0ZTogYDxkaXYgY2xhc3M9XCJwYXJlbnRcIiBtZXNzYWdlPVwicGFyZW50XCI+XG4gICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInBhcmVudG5lc3RlZFwiIG1lc3NhZ2U9XCJuZXN0ZWRwYXJlbnRcIj5QYXJlbnQ8L3NwYW4+XG4gICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJwYXJlbnRcIiBbaW5uZXJIdG1sXT1cInBhcmVudEJpbmRpbmdcIj48L3NwYW4+XG4gICAgICAgICAgICAgPGNoaWxkLWNvbXAgY2xhc3M9XCJjaGlsZC1jb21wLWNsYXNzXCI+PC9jaGlsZC1jb21wPmAsXG4gIGRpcmVjdGl2ZXM6IFtDaGlsZENvbXAsIE1lc3NhZ2VEaXJdLFxufSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIFBhcmVudENvbXAge1xuICBwYXJlbnRCaW5kaW5nOiBzdHJpbmc7XG4gIGNvbnN0cnVjdG9yKCkgeyB0aGlzLnBhcmVudEJpbmRpbmcgPSAnT3JpZ2luYWxQYXJlbnQnOyB9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnY3VzdG9tLWVtaXR0ZXInLCBvdXRwdXRzOiBbJ215ZXZlbnQnXX0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBDdXN0b21FbWl0dGVyIHtcbiAgbXlldmVudDogRXZlbnRFbWl0dGVyPGFueT47XG5cbiAgY29uc3RydWN0b3IoKSB7IHRoaXMubXlldmVudCA9IG5ldyBFdmVudEVtaXR0ZXIoKTsgfVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdldmVudHMtY29tcCcsXG4gIHRlbXBsYXRlOiBgPGJ1dHRvbiAoY2xpY2spPVwiaGFuZGxlQ2xpY2soKVwiPjwvYnV0dG9uPlxuICAgICAgICAgICAgIDxjdXN0b20tZW1pdHRlciAobXlldmVudCk9XCJoYW5kbGVDdXN0b20oKVwiPjwvY3VzdG9tLWVtaXR0ZXI+YCxcbiAgZGlyZWN0aXZlczogW0N1c3RvbUVtaXR0ZXJdLFxufSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIEV2ZW50c0NvbXAge1xuICBjbGlja2VkOiBib29sZWFuO1xuICBjdXN0b21lZDogYm9vbGVhbjtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLmNsaWNrZWQgPSBmYWxzZTtcbiAgICB0aGlzLmN1c3RvbWVkID0gZmFsc2U7XG4gIH1cblxuICBoYW5kbGVDbGljaygpIHsgdGhpcy5jbGlja2VkID0gdHJ1ZTsgfVxuXG4gIGhhbmRsZUN1c3RvbSgpIHsgdGhpcy5jdXN0b21lZCA9IHRydWU7IH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY29uZC1jb250ZW50LWNvbXAnLFxuICB2aWV3UHJvdmlkZXJzOiBbTG9nZ2VyXSxcbiAgdGVtcGxhdGU6IGA8ZGl2IGNsYXNzPVwiY2hpbGRcIiBtZXNzYWdlPVwiY2hpbGRcIiAqbmdJZj1cIm15Qm9vbFwiPjxuZy1jb250ZW50PjwvbmctY29udGVudD48L2Rpdj5gLFxuICBkaXJlY3RpdmVzOiBbTmdJZiwgTWVzc2FnZURpcl0sXG59KVxuQEluamVjdGFibGUoKVxuY2xhc3MgQ29uZGl0aW9uYWxDb250ZW50Q29tcCB7XG4gIG15Qm9vbDogYm9vbGVhbiA9IGZhbHNlO1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdjb25kaXRpb25hbC1wYXJlbnQtY29tcCcsXG4gIHZpZXdQcm92aWRlcnM6IFtMb2dnZXJdLFxuICB0ZW1wbGF0ZTogYDxzcGFuIGNsYXNzPVwicGFyZW50XCIgW2lubmVySHRtbF09XCJwYXJlbnRCaW5kaW5nXCI+PC9zcGFuPlxuICAgICAgICAgICAgPGNvbmQtY29udGVudC1jb21wIGNsYXNzPVwiY29uZC1jb250ZW50LWNvbXAtY2xhc3NcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmcm9tLXBhcmVudFwiPjwvc3Bhbj5cbiAgICAgICAgICAgIDwvY29uZC1jb250ZW50LWNvbXA+YCxcbiAgZGlyZWN0aXZlczogW0NvbmRpdGlvbmFsQ29udGVudENvbXBdLFxufSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIENvbmRpdGlvbmFsUGFyZW50Q29tcCB7XG4gIHBhcmVudEJpbmRpbmc6IHN0cmluZztcbiAgY29uc3RydWN0b3IoKSB7IHRoaXMucGFyZW50QmluZGluZyA9ICdPcmlnaW5hbFBhcmVudCc7IH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAndXNpbmctZm9yJyxcbiAgdmlld1Byb3ZpZGVyczogW0xvZ2dlcl0sXG4gIHRlbXBsYXRlOiBgPHNwYW4gKm5nRm9yPVwiI3RoaW5nIG9mIHN0dWZmXCIgW2lubmVySHRtbF09XCJ0aGluZ1wiPjwvc3Bhbj5cbiAgICAgICAgICAgIDx1bCBtZXNzYWdlPVwibGlzdFwiPlxuICAgICAgICAgICAgICA8bGkgKm5nRm9yPVwiI2l0ZW0gb2Ygc3R1ZmZcIiBbaW5uZXJIdG1sXT1cIml0ZW1cIj48L2xpPlxuICAgICAgICAgICAgPC91bD5gLFxuICBkaXJlY3RpdmVzOiBbTmdGb3IsIE1lc3NhZ2VEaXJdLFxufSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIFVzaW5nRm9yIHtcbiAgc3R1ZmY6IHN0cmluZ1tdO1xuICBjb25zdHJ1Y3RvcigpIHsgdGhpcy5zdHVmZiA9IFsnb25lJywgJ3R3bycsICd0aHJlZSddOyB9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnW215ZGlyXScsIGV4cG9ydEFzOiAnbXlkaXInfSlcbmNsYXNzIE15RGlyIHtcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbG9jYWxzLWNvbXAnLFxuICB0ZW1wbGF0ZTogYFxuICAgPGRpdiBteWRpciAjYWxpY2U9XCJteWRpclwiPjwvZGl2PlxuIGAsXG4gIGRpcmVjdGl2ZXM6IFtNeURpcl1cbn0pXG5jbGFzcyBMb2NhbHNDb21wIHtcbn1cblxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdiYW5rLWFjY291bnQnLFxuICB0ZW1wbGF0ZTogYFxuICAgQmFuayBOYW1lOiB7e2Jhbmt9fVxuICAgQWNjb3VudCBJZDoge3tpZH19XG4gYFxufSlcbmNsYXNzIEJhbmtBY2NvdW50IHtcbiAgQElucHV0KCkgYmFuazogc3RyaW5nO1xuICBASW5wdXQoJ2FjY291bnQnKSBpZDogc3RyaW5nO1xuXG4gIG5vcm1hbGl6ZWRCYW5rTmFtZTogc3RyaW5nO1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICd0ZXN0LWFwcCcsXG4gIHRlbXBsYXRlOiBgXG4gICA8YmFuay1hY2NvdW50IGJhbms9XCJSQkNcIiBhY2NvdW50PVwiNDc0N1wiPjwvYmFuay1hY2NvdW50PlxuIGAsXG4gIGRpcmVjdGl2ZXM6IFtCYW5rQWNjb3VudF1cbn0pXG5jbGFzcyBUZXN0QXBwIHtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGRlc2NyaWJlKCdkZWJ1ZyBlbGVtZW50JywgZnVuY3Rpb24oKSB7XG4gICAgaXQoJ3Nob3VsZCBsaXN0IGFsbCBjaGlsZCBub2RlcycsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB0Y2IuY3JlYXRlQXN5bmMoUGFyZW50Q29tcClcbiAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgIC8vIFRoZSByb290IGNvbXBvbmVudCBoYXMgMyBlbGVtZW50cyBhbmQgMiB0ZXh0IG5vZGUgY2hpbGRyZW4uXG4gICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGROb2Rlcy5sZW5ndGgpLnRvRXF1YWwoNSk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBsaXN0IGFsbCBjb21wb25lbnQgY2hpbGQgZWxlbWVudHMnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuXG4gICAgICAgICB0Y2IuY3JlYXRlQXN5bmMoUGFyZW50Q29tcClcbiAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgIHZhciBjaGlsZEVscyA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuO1xuXG4gICAgICAgICAgICAgICAvLyBUaGUgcm9vdCBjb21wb25lbnQgaGFzIDMgZWxlbWVudHMgaW4gaXRzIHZpZXcuXG4gICAgICAgICAgICAgICBleHBlY3QoY2hpbGRFbHMubGVuZ3RoKS50b0VxdWFsKDMpO1xuICAgICAgICAgICAgICAgZXhwZWN0KERPTS5oYXNDbGFzcyhjaGlsZEVsc1swXS5uYXRpdmVFbGVtZW50LCAncGFyZW50JykpLnRvQmUodHJ1ZSk7XG4gICAgICAgICAgICAgICBleHBlY3QoRE9NLmhhc0NsYXNzKGNoaWxkRWxzWzFdLm5hdGl2ZUVsZW1lbnQsICdwYXJlbnQnKSkudG9CZSh0cnVlKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChET00uaGFzQ2xhc3MoY2hpbGRFbHNbMl0ubmF0aXZlRWxlbWVudCwgJ2NoaWxkLWNvbXAtY2xhc3MnKSkudG9CZSh0cnVlKTtcblxuICAgICAgICAgICAgICAgdmFyIG5lc3RlZCA9IGNoaWxkRWxzWzBdLmNoaWxkcmVuO1xuICAgICAgICAgICAgICAgZXhwZWN0KG5lc3RlZC5sZW5ndGgpLnRvRXF1YWwoMSk7XG4gICAgICAgICAgICAgICBleHBlY3QoRE9NLmhhc0NsYXNzKG5lc3RlZFswXS5uYXRpdmVFbGVtZW50LCAncGFyZW50bmVzdGVkJykpLnRvQmUodHJ1ZSk7XG5cbiAgICAgICAgICAgICAgIHZhciBjaGlsZENvbXBvbmVudCA9IGNoaWxkRWxzWzJdO1xuXG4gICAgICAgICAgICAgICB2YXIgY2hpbGRDb21wQ2hpbGRyZW4gPSBjaGlsZENvbXBvbmVudC5jaGlsZHJlbjtcbiAgICAgICAgICAgICAgIGV4cGVjdChjaGlsZENvbXBDaGlsZHJlbi5sZW5ndGgpLnRvRXF1YWwoMik7XG4gICAgICAgICAgICAgICBleHBlY3QoRE9NLmhhc0NsYXNzKGNoaWxkQ29tcENoaWxkcmVuWzBdLm5hdGl2ZUVsZW1lbnQsICdjaGlsZCcpKS50b0JlKHRydWUpO1xuICAgICAgICAgICAgICAgZXhwZWN0KERPTS5oYXNDbGFzcyhjaGlsZENvbXBDaGlsZHJlblsxXS5uYXRpdmVFbGVtZW50LCAnY2hpbGQnKSkudG9CZSh0cnVlKTtcblxuICAgICAgICAgICAgICAgdmFyIGNoaWxkTmVzdGVkID0gY2hpbGRDb21wQ2hpbGRyZW5bMF0uY2hpbGRyZW47XG4gICAgICAgICAgICAgICBleHBlY3QoY2hpbGROZXN0ZWQubGVuZ3RoKS50b0VxdWFsKDEpO1xuICAgICAgICAgICAgICAgZXhwZWN0KERPTS5oYXNDbGFzcyhjaGlsZE5lc3RlZFswXS5uYXRpdmVFbGVtZW50LCAnY2hpbGRuZXN0ZWQnKSkudG9CZSh0cnVlKTtcblxuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgbGlzdCBjb25kaXRpb25hbCBjb21wb25lbnQgY2hpbGQgZWxlbWVudHMnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgdGNiLmNyZWF0ZUFzeW5jKENvbmRpdGlvbmFsUGFyZW50Q29tcClcbiAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgIHZhciBjaGlsZEVscyA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuO1xuXG4gICAgICAgICAgICAgICAvLyBUaGUgcm9vdCBjb21wb25lbnQgaGFzIDIgZWxlbWVudHMgaW4gaXRzIHZpZXcuXG4gICAgICAgICAgICAgICBleHBlY3QoY2hpbGRFbHMubGVuZ3RoKS50b0VxdWFsKDIpO1xuICAgICAgICAgICAgICAgZXhwZWN0KERPTS5oYXNDbGFzcyhjaGlsZEVsc1swXS5uYXRpdmVFbGVtZW50LCAncGFyZW50JykpLnRvQmUodHJ1ZSk7XG4gICAgICAgICAgICAgICBleHBlY3QoRE9NLmhhc0NsYXNzKGNoaWxkRWxzWzFdLm5hdGl2ZUVsZW1lbnQsICdjb25kLWNvbnRlbnQtY29tcC1jbGFzcycpKVxuICAgICAgICAgICAgICAgICAgIC50b0JlKHRydWUpO1xuXG4gICAgICAgICAgICAgICB2YXIgY29uZGl0aW9uYWxDb250ZW50Q29tcCA9IGNoaWxkRWxzWzFdO1xuXG4gICAgICAgICAgICAgICBleHBlY3QoY29uZGl0aW9uYWxDb250ZW50Q29tcC5jaGlsZHJlbi5sZW5ndGgpLnRvRXF1YWwoMCk7XG5cbiAgICAgICAgICAgICAgIGNvbmRpdGlvbmFsQ29udGVudENvbXAuY29tcG9uZW50SW5zdGFuY2UubXlCb29sID0gdHJ1ZTtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICBleHBlY3QoY29uZGl0aW9uYWxDb250ZW50Q29tcC5jaGlsZHJlbi5sZW5ndGgpLnRvRXF1YWwoMSk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBsaXN0IGNoaWxkIGVsZW1lbnRzIHdpdGhpbiB2aWV3cG9ydHMnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgdGNiLmNyZWF0ZUFzeW5jKFVzaW5nRm9yKS50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgIHZhciBjaGlsZEVscyA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuO1xuICAgICAgICAgICBleHBlY3QoY2hpbGRFbHMubGVuZ3RoKS50b0VxdWFsKDQpO1xuXG4gICAgICAgICAgIC8vIFRoZSA0dGggY2hpbGQgaXMgdGhlIDx1bD5cbiAgICAgICAgICAgdmFyIGxpc3QgPSBjaGlsZEVsc1szXTtcblxuICAgICAgICAgICBleHBlY3QobGlzdC5jaGlsZHJlbi5sZW5ndGgpLnRvRXF1YWwoMyk7XG5cbiAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBsaXN0IGVsZW1lbnQgYXR0cmlidXRlcycsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB0Y2IuY3JlYXRlQXN5bmMoVGVzdEFwcCkudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgdmFyIGJhbmtFbGVtID0gZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF07XG5cbiAgICAgICAgICAgZXhwZWN0KGJhbmtFbGVtLmF0dHJpYnV0ZXMuZ2V0KCdiYW5rJykpLnRvRXF1YWwoJ1JCQycpO1xuICAgICAgICAgICBleHBlY3QoYmFua0VsZW0uYXR0cmlidXRlcy5nZXQoJ2FjY291bnQnKSkudG9FcXVhbCgnNDc0NycpO1xuICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIHF1ZXJ5IGNoaWxkIGVsZW1lbnRzIGJ5IGNzcycsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB0Y2IuY3JlYXRlQXN5bmMoUGFyZW50Q29tcClcbiAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgIHZhciBjaGlsZFRlc3RFbHMgPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5xdWVyeUFsbChCeS5jc3MoJ2NoaWxkLWNvbXAnKSk7XG5cbiAgICAgICAgICAgICAgIGV4cGVjdChjaGlsZFRlc3RFbHMubGVuZ3RoKS50b0JlKDEpO1xuICAgICAgICAgICAgICAgZXhwZWN0KERPTS5oYXNDbGFzcyhjaGlsZFRlc3RFbHNbMF0ubmF0aXZlRWxlbWVudCwgJ2NoaWxkLWNvbXAtY2xhc3MnKSkudG9CZSh0cnVlKTtcblxuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgcXVlcnkgY2hpbGQgZWxlbWVudHMgYnkgZGlyZWN0aXZlJyxcbiAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgIHRjYi5jcmVhdGVBc3luYyhQYXJlbnRDb21wKVxuICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgdmFyIGNoaWxkVGVzdEVscyA9IGZpeHR1cmUuZGVidWdFbGVtZW50LnF1ZXJ5QWxsKEJ5LmRpcmVjdGl2ZShNZXNzYWdlRGlyKSk7XG5cbiAgICAgICAgICAgICAgIGV4cGVjdChjaGlsZFRlc3RFbHMubGVuZ3RoKS50b0JlKDQpO1xuICAgICAgICAgICAgICAgZXhwZWN0KERPTS5oYXNDbGFzcyhjaGlsZFRlc3RFbHNbMF0ubmF0aXZlRWxlbWVudCwgJ3BhcmVudCcpKS50b0JlKHRydWUpO1xuICAgICAgICAgICAgICAgZXhwZWN0KERPTS5oYXNDbGFzcyhjaGlsZFRlc3RFbHNbMV0ubmF0aXZlRWxlbWVudCwgJ3BhcmVudG5lc3RlZCcpKS50b0JlKHRydWUpO1xuICAgICAgICAgICAgICAgZXhwZWN0KERPTS5oYXNDbGFzcyhjaGlsZFRlc3RFbHNbMl0ubmF0aXZlRWxlbWVudCwgJ2NoaWxkJykpLnRvQmUodHJ1ZSk7XG4gICAgICAgICAgICAgICBleHBlY3QoRE9NLmhhc0NsYXNzKGNoaWxkVGVzdEVsc1szXS5uYXRpdmVFbGVtZW50LCAnY2hpbGRuZXN0ZWQnKSkudG9CZSh0cnVlKTtcblxuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgbGlzdCBwcm92aWRlclRva2VucycsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG5cbiAgICAgICAgIHRjYi5jcmVhdGVBc3luYyhQYXJlbnRDb21wKVxuICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50LnByb3ZpZGVyVG9rZW5zKS50b0NvbnRhaW4oTG9nZ2VyKTtcblxuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgbGlzdCBsb2NhbHMnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgdGNiLmNyZWF0ZUFzeW5jKExvY2Fsc0NvbXApXG4gICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uZ2V0TG9jYWwoJ2FsaWNlJykpLnRvQmVBbkluc3RhbmNlT2YoTXlEaXIpO1xuXG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBhbGxvdyBpbmplY3RpbmcgZnJvbSB0aGUgZWxlbWVudCBpbmplY3RvcicsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG5cbiAgICAgICAgIHRjYi5jcmVhdGVBc3luYyhQYXJlbnRDb21wKVxuICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmluamVjdChMb2dnZXIpLmxvZylcbiAgICAgICAgICAgICAgICAgICAudG9FcXVhbChbJ3BhcmVudCcsICduZXN0ZWRwYXJlbnQnLCAnY2hpbGQnLCAnbmVzdGVkY2hpbGQnXSk7XG5cbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIGxpc3QgZXZlbnQgbGlzdGVuZXJzJyxcbiAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcblxuICAgICAgICAgdGNiLmNyZWF0ZUFzeW5jKEV2ZW50c0NvbXApXG4gICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0ubGlzdGVuZXJzLmxlbmd0aCkudG9FcXVhbCgxKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblsxXS5saXN0ZW5lcnMubGVuZ3RoKS50b0VxdWFsKDEpO1xuXG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG5cbiAgICBpdCgnc2hvdWxkIHRyaWdnZXIgZXZlbnQgaGFuZGxlcnMnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuXG4gICAgICAgICB0Y2IuY3JlYXRlQXN5bmMoRXZlbnRzQ29tcClcbiAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jbGlja2VkKS50b0JlKGZhbHNlKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jdXN0b21lZCkudG9CZShmYWxzZSk7XG5cbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLnRyaWdnZXJFdmVudEhhbmRsZXIoJ2NsaWNrJywgPEV2ZW50Pnt9KTtcbiAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jbGlja2VkKS50b0JlKHRydWUpO1xuXG4gICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblsxXS50cmlnZ2VyRXZlbnRIYW5kbGVyKCdteWV2ZW50JywgPEV2ZW50Pnt9KTtcbiAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jdXN0b21lZCkudG9CZSh0cnVlKTtcblxuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcbiAgfSk7XG59XG4iXX0=
 main(); 
