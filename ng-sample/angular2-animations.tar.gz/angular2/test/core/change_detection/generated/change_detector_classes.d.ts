export declare function getFactoryById(id: string): any;
