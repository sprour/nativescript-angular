export declare class TestIterable {
    list: number[];
    constructor();
}
