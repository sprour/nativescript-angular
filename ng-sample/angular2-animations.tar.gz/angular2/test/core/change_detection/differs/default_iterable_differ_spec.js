'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var default_iterable_differ_1 = require('angular2/src/core/change_detection/differs/default_iterable_differ');
var lang_1 = require('angular2/src/facade/lang');
var collection_1 = require('angular2/src/facade/collection');
var iterable_1 = require('../../../core/change_detection/iterable');
var util_1 = require('../../../core/change_detection/util');
var ItemWithId = (function () {
    function ItemWithId(id) {
        this.id = id;
    }
    ItemWithId.prototype.toString = function () { return "{id: " + this.id + "}"; };
    return ItemWithId;
})();
var ComplexItem = (function () {
    function ComplexItem(id, color) {
        this.id = id;
        this.color = color;
    }
    ComplexItem.prototype.toString = function () { return "{id: " + this.id + ", color: " + this.color + "}"; };
    return ComplexItem;
})();
function main() {
    testing_internal_1.describe('iterable differ', function () {
        testing_internal_1.describe('DefaultIterableDiffer', function () {
            var differ;
            testing_internal_1.beforeEach(function () { differ = new default_iterable_differ_1.DefaultIterableDiffer(); });
            testing_internal_1.it('should support list and iterables', function () {
                var f = new default_iterable_differ_1.DefaultIterableDifferFactory();
                testing_internal_1.expect(f.supports([])).toBeTruthy();
                testing_internal_1.expect(f.supports(new iterable_1.TestIterable())).toBeTruthy();
                testing_internal_1.expect(f.supports(new Map())).toBeFalsy();
                testing_internal_1.expect(f.supports(null)).toBeFalsy();
            });
            testing_internal_1.it('should support iterables', function () {
                var l = new iterable_1.TestIterable();
                differ.check(l);
                testing_internal_1.expect(differ.toString()).toEqual(util_1.iterableChangesAsString({ collection: [] }));
                l.list = [1];
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({ collection: ['1[null->0]'], additions: ['1[null->0]'] }));
                l.list = [2, 1];
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['2[null->0]', '1[0->1]'],
                    previous: ['1[0->1]'],
                    additions: ['2[null->0]'],
                    moves: ['1[0->1]']
                }));
            });
            testing_internal_1.it('should detect additions', function () {
                var l = [];
                differ.check(l);
                testing_internal_1.expect(differ.toString()).toEqual(util_1.iterableChangesAsString({ collection: [] }));
                l.push('a');
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({ collection: ['a[null->0]'], additions: ['a[null->0]'] }));
                l.push('b');
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({ collection: ['a', 'b[null->1]'], previous: ['a'], additions: ['b[null->1]'] }));
            });
            testing_internal_1.it('should support changing the reference', function () {
                var l = [0];
                differ.check(l);
                l = [1, 0];
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['1[null->0]', '0[0->1]'],
                    previous: ['0[0->1]'],
                    additions: ['1[null->0]'],
                    moves: ['0[0->1]']
                }));
                l = [2, 1, 0];
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['2[null->0]', '1[0->1]', '0[1->2]'],
                    previous: ['1[0->1]', '0[1->2]'],
                    additions: ['2[null->0]'],
                    moves: ['1[0->1]', '0[1->2]']
                }));
            });
            testing_internal_1.it('should handle swapping element', function () {
                var l = [1, 2];
                differ.check(l);
                collection_1.ListWrapper.clear(l);
                l.push(2);
                l.push(1);
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['2[1->0]', '1[0->1]'],
                    previous: ['1[0->1]', '2[1->0]'],
                    moves: ['2[1->0]', '1[0->1]']
                }));
            });
            testing_internal_1.it('should handle incremental swapping element', function () {
                var l = ['a', 'b', 'c'];
                differ.check(l);
                collection_1.ListWrapper.removeAt(l, 1);
                collection_1.ListWrapper.insert(l, 0, 'b');
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['b[1->0]', 'a[0->1]', 'c'],
                    previous: ['a[0->1]', 'b[1->0]', 'c'],
                    moves: ['b[1->0]', 'a[0->1]']
                }));
                collection_1.ListWrapper.removeAt(l, 1);
                l.push('a');
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['b', 'c[2->1]', 'a[1->2]'],
                    previous: ['b', 'a[1->2]', 'c[2->1]'],
                    moves: ['c[2->1]', 'a[1->2]']
                }));
            });
            testing_internal_1.it('should detect changes in list', function () {
                var l = [];
                differ.check(l);
                l.push('a');
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({ collection: ['a[null->0]'], additions: ['a[null->0]'] }));
                l.push('b');
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({ collection: ['a', 'b[null->1]'], previous: ['a'], additions: ['b[null->1]'] }));
                l.push('c');
                l.push('d');
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['a', 'b', 'c[null->2]', 'd[null->3]'],
                    previous: ['a', 'b'],
                    additions: ['c[null->2]', 'd[null->3]']
                }));
                collection_1.ListWrapper.removeAt(l, 2);
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['a', 'b', 'd[3->2]'],
                    previous: ['a', 'b', 'c[2->null]', 'd[3->2]'],
                    moves: ['d[3->2]'],
                    removals: ['c[2->null]']
                }));
                collection_1.ListWrapper.clear(l);
                l.push('d');
                l.push('c');
                l.push('b');
                l.push('a');
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['d[2->0]', 'c[null->1]', 'b[1->2]', 'a[0->3]'],
                    previous: ['a[0->3]', 'b[1->2]', 'd[2->0]'],
                    additions: ['c[null->1]'],
                    moves: ['d[2->0]', 'b[1->2]', 'a[0->3]']
                }));
            });
            testing_internal_1.it('should test string by value rather than by reference (Dart)', function () {
                var l = ['a', 'boo'];
                differ.check(l);
                var b = 'b';
                var oo = 'oo';
                l[1] = b + oo;
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({ collection: ['a', 'boo'], previous: ['a', 'boo'] }));
            });
            testing_internal_1.it('should ignore [NaN] != [NaN] (JS)', function () {
                var l = [lang_1.NumberWrapper.NaN];
                differ.check(l);
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({ collection: [lang_1.NumberWrapper.NaN], previous: [lang_1.NumberWrapper.NaN] }));
            });
            testing_internal_1.it('should detect [NaN] moves', function () {
                var l = [lang_1.NumberWrapper.NaN, lang_1.NumberWrapper.NaN];
                differ.check(l);
                collection_1.ListWrapper.insert(l, 0, 'foo');
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['foo[null->0]', 'NaN[0->1]', 'NaN[1->2]'],
                    previous: ['NaN[0->1]', 'NaN[1->2]'],
                    additions: ['foo[null->0]'],
                    moves: ['NaN[0->1]', 'NaN[1->2]']
                }));
            });
            testing_internal_1.it('should remove and add same item', function () {
                var l = ['a', 'b', 'c'];
                differ.check(l);
                collection_1.ListWrapper.removeAt(l, 1);
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['a', 'c[2->1]'],
                    previous: ['a', 'b[1->null]', 'c[2->1]'],
                    moves: ['c[2->1]'],
                    removals: ['b[1->null]']
                }));
                collection_1.ListWrapper.insert(l, 1, 'b');
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['a', 'b[null->1]', 'c[1->2]'],
                    previous: ['a', 'c[1->2]'],
                    additions: ['b[null->1]'],
                    moves: ['c[1->2]']
                }));
            });
            testing_internal_1.it('should support duplicates', function () {
                var l = ['a', 'a', 'a', 'b', 'b'];
                differ.check(l);
                collection_1.ListWrapper.removeAt(l, 0);
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['a', 'a', 'b[3->2]', 'b[4->3]'],
                    previous: ['a', 'a', 'a[2->null]', 'b[3->2]', 'b[4->3]'],
                    moves: ['b[3->2]', 'b[4->3]'],
                    removals: ['a[2->null]']
                }));
            });
            testing_internal_1.it('should support insertions/moves', function () {
                var l = ['a', 'a', 'b', 'b'];
                differ.check(l);
                collection_1.ListWrapper.insert(l, 0, 'b');
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['b[2->0]', 'a[0->1]', 'a[1->2]', 'b', 'b[null->4]'],
                    previous: ['a[0->1]', 'a[1->2]', 'b[2->0]', 'b'],
                    additions: ['b[null->4]'],
                    moves: ['b[2->0]', 'a[0->1]', 'a[1->2]']
                }));
            });
            testing_internal_1.it('should not report unnecessary moves', function () {
                var l = ['a', 'b', 'c'];
                differ.check(l);
                collection_1.ListWrapper.clear(l);
                l.push('b');
                l.push('a');
                l.push('c');
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['b[1->0]', 'a[0->1]', 'c'],
                    previous: ['a[0->1]', 'b[1->0]', 'c'],
                    moves: ['b[1->0]', 'a[0->1]']
                }));
            });
            testing_internal_1.it('should not diff immutable collections if they are the same', function () {
                // Note: Use trackBy to know if diffing happened
                var trackByCount = 0;
                var trackBy = function (index, item) {
                    trackByCount++;
                    return item;
                };
                var differ = new default_iterable_differ_1.DefaultIterableDiffer(trackBy);
                var l1 = collection_1.ListWrapper.createImmutable([1]);
                differ.check(l1);
                testing_internal_1.expect(trackByCount).toBe(1);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({ collection: ['1[null->0]'], additions: ['1[null->0]'] }));
                trackByCount = 0;
                differ.check(l1);
                testing_internal_1.expect(trackByCount).toBe(0);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({ collection: ['1'], previous: ['1'] }));
                trackByCount = 0;
                differ.check(l1);
                testing_internal_1.expect(trackByCount).toBe(0);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({ collection: ['1'], previous: ['1'] }));
            });
            testing_internal_1.describe('diff', function () {
                testing_internal_1.it('should return self when there is a change', function () { testing_internal_1.expect(differ.diff(['a', 'b'])).toBe(differ); });
                testing_internal_1.it('should return null when there is no change', function () {
                    differ.diff(['a', 'b']);
                    testing_internal_1.expect(differ.diff(['a', 'b'])).toEqual(null);
                });
                testing_internal_1.it('should treat null as an empty list', function () {
                    differ.diff(['a', 'b']);
                    testing_internal_1.expect(differ.diff(null).toString())
                        .toEqual(util_1.iterableChangesAsString({
                        previous: ['a[0->null]', 'b[1->null]'],
                        removals: ['a[0->null]', 'b[1->null]']
                    }));
                });
                testing_internal_1.it('should throw when given an invalid collection', function () {
                    testing_internal_1.expect(function () { return differ.diff("invalid"); }).toThrowErrorWith("Error trying to diff 'invalid'");
                });
            });
        });
        testing_internal_1.describe('trackBy function by id', function () {
            var differ;
            var trackByItemId = function (index, item) { return item.id; };
            var buildItemList = function (list) { return list.map(function (val) { return new ItemWithId(val); }); };
            testing_internal_1.beforeEach(function () { differ = new default_iterable_differ_1.DefaultIterableDiffer(trackByItemId); });
            testing_internal_1.it('should treat the collection as dirty if identity changes', function () {
                differ.diff(buildItemList(['a']));
                testing_internal_1.expect(differ.diff(buildItemList(['a']))).toBe(differ);
            });
            testing_internal_1.it('should treat seen records as identity changes, not additions', function () {
                var l = buildItemList(['a', 'b', 'c']);
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ["{id: a}[null->0]", "{id: b}[null->1]", "{id: c}[null->2]"],
                    additions: ["{id: a}[null->0]", "{id: b}[null->1]", "{id: c}[null->2]"]
                }));
                l = buildItemList(['a', 'b', 'c']);
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ["{id: a}", "{id: b}", "{id: c}"],
                    identityChanges: ["{id: a}", "{id: b}", "{id: c}"],
                    previous: ["{id: a}", "{id: b}", "{id: c}"]
                }));
            });
            testing_internal_1.it('should have updated properties in identity change collection', function () {
                var l = [new ComplexItem('a', 'blue'), new ComplexItem('b', 'yellow')];
                differ.check(l);
                l = [new ComplexItem('a', 'orange'), new ComplexItem('b', 'red')];
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ["{id: a, color: orange}", "{id: b, color: red}"],
                    identityChanges: ["{id: a, color: orange}", "{id: b, color: red}"],
                    previous: ["{id: a, color: orange}", "{id: b, color: red}"]
                }));
            });
            testing_internal_1.it('should track moves normally', function () {
                var l = buildItemList(['a', 'b', 'c']);
                differ.check(l);
                l = buildItemList(['b', 'a', 'c']);
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['{id: b}[1->0]', '{id: a}[0->1]', '{id: c}'],
                    identityChanges: ['{id: b}[1->0]', '{id: a}[0->1]', '{id: c}'],
                    previous: ['{id: a}[0->1]', '{id: b}[1->0]', '{id: c}'],
                    moves: ['{id: b}[1->0]', '{id: a}[0->1]']
                }));
            });
            testing_internal_1.it('should track duplicate reinsertion normally', function () {
                var l = buildItemList(['a', 'a']);
                differ.check(l);
                l = buildItemList(['b', 'a', 'a']);
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['{id: b}[null->0]', '{id: a}[0->1]', '{id: a}[1->2]'],
                    identityChanges: ['{id: a}[0->1]', '{id: a}[1->2]'],
                    previous: ['{id: a}[0->1]', '{id: a}[1->2]'],
                    moves: ['{id: a}[0->1]', '{id: a}[1->2]'],
                    additions: ['{id: b}[null->0]']
                }));
            });
            testing_internal_1.it('should track removals normally', function () {
                var l = buildItemList(['a', 'b', 'c']);
                differ.check(l);
                collection_1.ListWrapper.removeAt(l, 2);
                differ.check(l);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['{id: a}', '{id: b}'],
                    previous: ['{id: a}', '{id: b}', '{id: c}[2->null]'],
                    removals: ['{id: c}[2->null]']
                }));
            });
        });
        testing_internal_1.describe('trackBy function by index', function () {
            var differ;
            var trackByIndex = function (index, item) { return index; };
            testing_internal_1.beforeEach(function () { differ = new default_iterable_differ_1.DefaultIterableDiffer(trackByIndex); });
            testing_internal_1.it('should track removals normally', function () {
                differ.check(['a', 'b', 'c', 'd']);
                differ.check(['e', 'f', 'g', 'h']);
                differ.check(['e', 'f', 'h']);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.iterableChangesAsString({
                    collection: ['e', 'f', 'h'],
                    previous: ['e', 'f', 'h', 'h[3->null]'],
                    removals: ['h[3->null]'],
                    identityChanges: ['h']
                }));
            });
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVmYXVsdF9pdGVyYWJsZV9kaWZmZXJfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29yZS9jaGFuZ2VfZGV0ZWN0aW9uL2RpZmZlcnMvZGVmYXVsdF9pdGVyYWJsZV9kaWZmZXJfc3BlYy50cyJdLCJuYW1lcyI6WyJJdGVtV2l0aElkIiwiSXRlbVdpdGhJZC5jb25zdHJ1Y3RvciIsIkl0ZW1XaXRoSWQudG9TdHJpbmciLCJDb21wbGV4SXRlbSIsIkNvbXBsZXhJdGVtLmNvbnN0cnVjdG9yIiwiQ29tcGxleEl0ZW0udG9TdHJpbmciLCJtYWluIl0sIm1hcHBpbmdzIjoiQUFBQSxpQ0FTTywyQkFBMkIsQ0FBQyxDQUFBO0FBQ25DLHdDQUdPLG9FQUFvRSxDQUFDLENBQUE7QUFFNUUscUJBQTRCLDBCQUEwQixDQUFDLENBQUE7QUFDdkQsMkJBQTBCLGdDQUFnQyxDQUFDLENBQUE7QUFFM0QseUJBQTJCLHlDQUF5QyxDQUFDLENBQUE7QUFDckUscUJBQXNDLHFDQUFxQyxDQUFDLENBQUE7QUFFNUU7SUFDRUEsb0JBQW9CQSxFQUFVQTtRQUFWQyxPQUFFQSxHQUFGQSxFQUFFQSxDQUFRQTtJQUFHQSxDQUFDQTtJQUVsQ0QsNkJBQVFBLEdBQVJBLGNBQWFFLE1BQU1BLENBQUNBLFVBQVFBLElBQUlBLENBQUNBLEVBQUVBLE1BQUdBLENBQUFBLENBQUNBLENBQUNBO0lBQzFDRixpQkFBQ0E7QUFBREEsQ0FBQ0EsQUFKRCxJQUlDO0FBRUQ7SUFDRUcscUJBQW9CQSxFQUFVQSxFQUFVQSxLQUFhQTtRQUFqQ0MsT0FBRUEsR0FBRkEsRUFBRUEsQ0FBUUE7UUFBVUEsVUFBS0EsR0FBTEEsS0FBS0EsQ0FBUUE7SUFBR0EsQ0FBQ0E7SUFFekRELDhCQUFRQSxHQUFSQSxjQUFhRSxNQUFNQSxDQUFDQSxVQUFRQSxJQUFJQSxDQUFDQSxFQUFFQSxpQkFBWUEsSUFBSUEsQ0FBQ0EsS0FBS0EsTUFBR0EsQ0FBQUEsQ0FBQ0EsQ0FBQ0E7SUFDaEVGLGtCQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQUNFRywyQkFBUUEsQ0FBQ0EsaUJBQWlCQSxFQUFFQTtRQUMxQiwyQkFBUSxDQUFDLHVCQUF1QixFQUFFO1lBQ2hDLElBQUksTUFBTSxDQUFDO1lBRVgsNkJBQVUsQ0FBQyxjQUFRLE1BQU0sR0FBRyxJQUFJLCtDQUFxQixFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUU1RCxxQkFBRSxDQUFDLG1DQUFtQyxFQUFFO2dCQUN0QyxJQUFJLENBQUMsR0FBRyxJQUFJLHNEQUE0QixFQUFFLENBQUM7Z0JBQzNDLHlCQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNwQyx5QkFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSx1QkFBWSxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNwRCx5QkFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQzFDLHlCQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ3ZDLENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQywwQkFBMEIsRUFBRTtnQkFDN0IsSUFBSSxDQUFDLEdBQUcsSUFBSSx1QkFBWSxFQUFFLENBQUM7Z0JBRTNCLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLDhCQUF1QixDQUFDLEVBQUMsVUFBVSxFQUFFLEVBQUUsRUFBQyxDQUFDLENBQUMsQ0FBQztnQkFFN0UsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNiLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQ0osOEJBQXVCLENBQUMsRUFBQyxVQUFVLEVBQUUsQ0FBQyxZQUFZLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztnQkFFMUYsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDaEIsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3BCLE9BQU8sQ0FBQyw4QkFBdUIsQ0FBQztvQkFDL0IsVUFBVSxFQUFFLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQztvQkFDckMsUUFBUSxFQUFFLENBQUMsU0FBUyxDQUFDO29CQUNyQixTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUM7b0JBQ3pCLEtBQUssRUFBRSxDQUFDLFNBQVMsQ0FBQztpQkFDbkIsQ0FBQyxDQUFDLENBQUM7WUFDVixDQUFDLENBQUMsQ0FBQztZQUVILHFCQUFFLENBQUMseUJBQXlCLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDWCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyw4QkFBdUIsQ0FBQyxFQUFDLFVBQVUsRUFBRSxFQUFFLEVBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRTdFLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ1osTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3BCLE9BQU8sQ0FDSiw4QkFBdUIsQ0FBQyxFQUFDLFVBQVUsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFFLFNBQVMsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUUxRixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNaLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQUMsOEJBQXVCLENBQzVCLEVBQUMsVUFBVSxFQUFFLENBQUMsR0FBRyxFQUFFLFlBQVksQ0FBQyxFQUFFLFFBQVEsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLFNBQVMsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFGLENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQyx1Q0FBdUMsRUFBRTtnQkFDMUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDWixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVoQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ1gsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3BCLE9BQU8sQ0FBQyw4QkFBdUIsQ0FBQztvQkFDL0IsVUFBVSxFQUFFLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQztvQkFDckMsUUFBUSxFQUFFLENBQUMsU0FBUyxDQUFDO29CQUNyQixTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUM7b0JBQ3pCLEtBQUssRUFBRSxDQUFDLFNBQVMsQ0FBQztpQkFDbkIsQ0FBQyxDQUFDLENBQUM7Z0JBRVIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDZCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDcEIsT0FBTyxDQUFDLDhCQUF1QixDQUFDO29CQUMvQixVQUFVLEVBQUUsQ0FBQyxZQUFZLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQztvQkFDaEQsUUFBUSxFQUFFLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQztvQkFDaEMsU0FBUyxFQUFFLENBQUMsWUFBWSxDQUFDO29CQUN6QixLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDO2lCQUM5QixDQUFDLENBQUMsQ0FBQztZQUNWLENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQyxnQ0FBZ0MsRUFBRTtnQkFDbkMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ2YsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFaEIsd0JBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1YsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDVixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDcEIsT0FBTyxDQUFDLDhCQUF1QixDQUFDO29CQUMvQixVQUFVLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDO29CQUNsQyxRQUFRLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDO29CQUNoQyxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDO2lCQUM5QixDQUFDLENBQUMsQ0FBQztZQUNWLENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQyw0Q0FBNEMsRUFBRTtnQkFDL0MsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUN4QixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVoQix3QkFBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQzNCLHdCQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQzlCLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQUMsOEJBQXVCLENBQUM7b0JBQy9CLFVBQVUsRUFBRSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsR0FBRyxDQUFDO29CQUN2QyxRQUFRLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLEdBQUcsQ0FBQztvQkFDckMsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQztpQkFDOUIsQ0FBQyxDQUFDLENBQUM7Z0JBRVIsd0JBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUMzQixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNaLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQUMsOEJBQXVCLENBQUM7b0JBQy9CLFVBQVUsRUFBRSxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDO29CQUN2QyxRQUFRLEVBQUUsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQztvQkFDckMsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQztpQkFDOUIsQ0FBQyxDQUFDLENBQUM7WUFDVixDQUFDLENBQUMsQ0FBQztZQUVILHFCQUFFLENBQUMsK0JBQStCLEVBQUU7Z0JBQ2xDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDWCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVoQixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNaLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQ0osOEJBQXVCLENBQUMsRUFBQyxVQUFVLEVBQUUsQ0FBQyxZQUFZLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztnQkFFMUYsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDWixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDcEIsT0FBTyxDQUFDLDhCQUF1QixDQUM1QixFQUFDLFVBQVUsRUFBRSxDQUFDLEdBQUcsRUFBRSxZQUFZLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztnQkFFeEYsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDWixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNaLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQUMsOEJBQXVCLENBQUM7b0JBQy9CLFVBQVUsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsWUFBWSxFQUFFLFlBQVksQ0FBQztvQkFDbEQsUUFBUSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztvQkFDcEIsU0FBUyxFQUFFLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQztpQkFDeEMsQ0FBQyxDQUFDLENBQUM7Z0JBRVIsd0JBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUMzQixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDcEIsT0FBTyxDQUFDLDhCQUF1QixDQUFDO29CQUMvQixVQUFVLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLFNBQVMsQ0FBQztvQkFDakMsUUFBUSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxZQUFZLEVBQUUsU0FBUyxDQUFDO29CQUM3QyxLQUFLLEVBQUUsQ0FBQyxTQUFTLENBQUM7b0JBQ2xCLFFBQVEsRUFBRSxDQUFDLFlBQVksQ0FBQztpQkFDekIsQ0FBQyxDQUFDLENBQUM7Z0JBRVIsd0JBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JCLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ1osQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDWixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNaLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ1osTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3BCLE9BQU8sQ0FBQyw4QkFBdUIsQ0FBQztvQkFDL0IsVUFBVSxFQUFFLENBQUMsU0FBUyxFQUFFLFlBQVksRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDO29CQUMzRCxRQUFRLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQztvQkFDM0MsU0FBUyxFQUFFLENBQUMsWUFBWSxDQUFDO29CQUN6QixLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQztpQkFDekMsQ0FBQyxDQUFDLENBQUM7WUFDVixDQUFDLENBQUMsQ0FBQztZQUVILHFCQUFFLENBQUMsNkRBQTZELEVBQUU7Z0JBQ2hFLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUNyQixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVoQixJQUFJLENBQUMsR0FBRyxHQUFHLENBQUM7Z0JBQ1osSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDO2dCQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUNkLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQUMsOEJBQXVCLENBQUMsRUFBQyxVQUFVLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEVBQUUsUUFBUSxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzVGLENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQyxtQ0FBbUMsRUFBRTtnQkFDdEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxvQkFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUM1QixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDcEIsT0FBTyxDQUFDLDhCQUF1QixDQUM1QixFQUFDLFVBQVUsRUFBRSxDQUFDLG9CQUFhLENBQUMsR0FBRyxDQUFDLEVBQUUsUUFBUSxFQUFFLENBQUMsb0JBQWEsQ0FBQyxHQUFHLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztZQUM3RSxDQUFDLENBQUMsQ0FBQztZQUVILHFCQUFFLENBQUMsMkJBQTJCLEVBQUU7Z0JBQzlCLElBQUksQ0FBQyxHQUFHLENBQUMsb0JBQWEsQ0FBQyxHQUFHLEVBQUUsb0JBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDL0MsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFaEIsd0JBQVcsQ0FBQyxNQUFNLENBQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDckMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3BCLE9BQU8sQ0FBQyw4QkFBdUIsQ0FBQztvQkFDL0IsVUFBVSxFQUFFLENBQUMsY0FBYyxFQUFFLFdBQVcsRUFBRSxXQUFXLENBQUM7b0JBQ3RELFFBQVEsRUFBRSxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUM7b0JBQ3BDLFNBQVMsRUFBRSxDQUFDLGNBQWMsQ0FBQztvQkFDM0IsS0FBSyxFQUFFLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQztpQkFDbEMsQ0FBQyxDQUFDLENBQUM7WUFDVixDQUFDLENBQUMsQ0FBQztZQUVILHFCQUFFLENBQUMsaUNBQWlDLEVBQUU7Z0JBQ3BDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDeEIsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFaEIsd0JBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUMzQixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDcEIsT0FBTyxDQUFDLDhCQUF1QixDQUFDO29CQUMvQixVQUFVLEVBQUUsQ0FBQyxHQUFHLEVBQUUsU0FBUyxDQUFDO29CQUM1QixRQUFRLEVBQUUsQ0FBQyxHQUFHLEVBQUUsWUFBWSxFQUFFLFNBQVMsQ0FBQztvQkFDeEMsS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDO29CQUNsQixRQUFRLEVBQUUsQ0FBQyxZQUFZLENBQUM7aUJBQ3pCLENBQUMsQ0FBQyxDQUFDO2dCQUVSLHdCQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQzlCLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQUMsOEJBQXVCLENBQUM7b0JBQy9CLFVBQVUsRUFBRSxDQUFDLEdBQUcsRUFBRSxZQUFZLEVBQUUsU0FBUyxDQUFDO29CQUMxQyxRQUFRLEVBQUUsQ0FBQyxHQUFHLEVBQUUsU0FBUyxDQUFDO29CQUMxQixTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUM7b0JBQ3pCLEtBQUssRUFBRSxDQUFDLFNBQVMsQ0FBQztpQkFDbkIsQ0FBQyxDQUFDLENBQUM7WUFDVixDQUFDLENBQUMsQ0FBQztZQUdILHFCQUFFLENBQUMsMkJBQTJCLEVBQUU7Z0JBQzlCLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUNsQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVoQix3QkFBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQzNCLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQUMsOEJBQXVCLENBQUM7b0JBQy9CLFVBQVUsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQztvQkFDNUMsUUFBUSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxZQUFZLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQztvQkFDeEQsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQztvQkFDN0IsUUFBUSxFQUFFLENBQUMsWUFBWSxDQUFDO2lCQUN6QixDQUFDLENBQUMsQ0FBQztZQUNWLENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQyxpQ0FBaUMsRUFBRTtnQkFDcEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDN0IsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFaEIsd0JBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDOUIsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3BCLE9BQU8sQ0FBQyw4QkFBdUIsQ0FBQztvQkFDL0IsVUFBVSxFQUFFLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsR0FBRyxFQUFFLFlBQVksQ0FBQztvQkFDaEUsUUFBUSxFQUFFLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsR0FBRyxDQUFDO29CQUNoRCxTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUM7b0JBQ3pCLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDO2lCQUN6QyxDQUFDLENBQUMsQ0FBQztZQUNWLENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQyxxQ0FBcUMsRUFBRTtnQkFDeEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUN4QixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVoQix3QkFBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDckIsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDWixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNaLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ1osTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3BCLE9BQU8sQ0FBQyw4QkFBdUIsQ0FBQztvQkFDL0IsVUFBVSxFQUFFLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxHQUFHLENBQUM7b0JBQ3ZDLFFBQVEsRUFBRSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsR0FBRyxDQUFDO29CQUNyQyxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDO2lCQUM5QixDQUFDLENBQUMsQ0FBQztZQUNWLENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQyw0REFBNEQsRUFBRTtnQkFDL0QsZ0RBQWdEO2dCQUNoRCxJQUFJLFlBQVksR0FBRyxDQUFDLENBQUM7Z0JBQ3JCLElBQUksT0FBTyxHQUFHLFVBQUMsS0FBYSxFQUFFLElBQVM7b0JBQ3JDLFlBQVksRUFBRSxDQUFDO29CQUNmLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQ2QsQ0FBQyxDQUFDO2dCQUNGLElBQUksTUFBTSxHQUFHLElBQUksK0NBQXFCLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ2hELElBQUksRUFBRSxHQUFHLHdCQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFMUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDakIseUJBQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzdCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQ0osOEJBQXVCLENBQUMsRUFBQyxVQUFVLEVBQUUsQ0FBQyxZQUFZLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztnQkFHMUYsWUFBWSxHQUFHLENBQUMsQ0FBQztnQkFDakIsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDakIseUJBQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzdCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQUMsOEJBQXVCLENBQUMsRUFBQyxVQUFVLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztnQkFFNUUsWUFBWSxHQUFHLENBQUMsQ0FBQztnQkFDakIsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDakIseUJBQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzdCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQUMsOEJBQXVCLENBQUMsRUFBQyxVQUFVLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztZQUM5RSxDQUFDLENBQUMsQ0FBQztZQUVILDJCQUFRLENBQUMsTUFBTSxFQUFFO2dCQUNmLHFCQUFFLENBQUMsMkNBQTJDLEVBQzNDLGNBQVEseUJBQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFNUQscUJBQUUsQ0FBQyw0Q0FBNEMsRUFBRTtvQkFDL0MsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUN4Qix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDaEQsQ0FBQyxDQUFDLENBQUM7Z0JBRUgscUJBQUUsQ0FBQyxvQ0FBb0MsRUFBRTtvQkFDdkMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUN4Qix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7eUJBQy9CLE9BQU8sQ0FBQyw4QkFBdUIsQ0FBQzt3QkFDL0IsUUFBUSxFQUFFLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQzt3QkFDdEMsUUFBUSxFQUFFLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQztxQkFDdkMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1YsQ0FBQyxDQUFDLENBQUM7Z0JBRUgscUJBQUUsQ0FBQywrQ0FBK0MsRUFBRTtvQkFDbEQseUJBQU0sQ0FBQyxjQUFNLE9BQUEsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBdEIsQ0FBc0IsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLGdDQUFnQyxDQUFDLENBQUM7Z0JBQzFGLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILDJCQUFRLENBQUMsd0JBQXdCLEVBQUU7WUFDakMsSUFBSSxNQUFNLENBQUM7WUFFWCxJQUFJLGFBQWEsR0FBRyxVQUFDLEtBQWEsRUFBRSxJQUFTLElBQVUsT0FBQSxJQUFJLENBQUMsRUFBRSxFQUFQLENBQU8sQ0FBQztZQUUvRCxJQUFJLGFBQWEsR0FDYixVQUFDLElBQWMsSUFBTyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFDLEdBQUcsSUFBTSxNQUFNLENBQUMsSUFBSSxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUEsQ0FBQSxDQUFDLENBQUMsQ0FBQSxDQUFDLENBQUMsQ0FBQztZQUVuRiw2QkFBVSxDQUFDLGNBQVEsTUFBTSxHQUFHLElBQUksK0NBQXFCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUV6RSxxQkFBRSxDQUFDLDBEQUEwRCxFQUFFO2dCQUM3RCxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDbEMseUJBQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN6RCxDQUFDLENBQUMsQ0FBQztZQUVILHFCQUFFLENBQUMsOERBQThELEVBQUU7Z0JBQ2pFLElBQUksQ0FBQyxHQUFHLGFBQWEsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDdkMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3BCLE9BQU8sQ0FBQyw4QkFBdUIsQ0FBQztvQkFDL0IsVUFBVSxFQUFFLENBQUMsa0JBQWtCLEVBQUUsa0JBQWtCLEVBQUUsa0JBQWtCLENBQUM7b0JBQ3hFLFNBQVMsRUFBRSxDQUFDLGtCQUFrQixFQUFFLGtCQUFrQixFQUFFLGtCQUFrQixDQUFDO2lCQUN4RSxDQUFDLENBQUMsQ0FBQztnQkFFUixDQUFDLEdBQUcsYUFBYSxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNuQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDcEIsT0FBTyxDQUFDLDhCQUF1QixDQUFDO29CQUMvQixVQUFVLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQztvQkFDN0MsZUFBZSxFQUFFLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLENBQUM7b0JBQ2xELFFBQVEsRUFBRSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDO2lCQUM1QyxDQUFDLENBQUMsQ0FBQztZQUNWLENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQyw4REFBOEQsRUFBRTtnQkFDakUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLFdBQVcsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLEVBQUUsSUFBSSxXQUFXLENBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZFLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRWhCLENBQUMsR0FBRyxDQUFDLElBQUksV0FBVyxDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsRUFBRSxJQUFJLFdBQVcsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztnQkFDbEUsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3BCLE9BQU8sQ0FBQyw4QkFBdUIsQ0FBQztvQkFDL0IsVUFBVSxFQUFFLENBQUMsd0JBQXdCLEVBQUUscUJBQXFCLENBQUM7b0JBQzdELGVBQWUsRUFBRSxDQUFDLHdCQUF3QixFQUFFLHFCQUFxQixDQUFDO29CQUNsRSxRQUFRLEVBQUUsQ0FBQyx3QkFBd0IsRUFBRSxxQkFBcUIsQ0FBQztpQkFDNUQsQ0FBQyxDQUFDLENBQUM7WUFDVixDQUFDLENBQUMsQ0FBQztZQUVILHFCQUFFLENBQUMsNkJBQTZCLEVBQUU7Z0JBQ2hDLElBQUksQ0FBQyxHQUFHLGFBQWEsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDdkMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFaEIsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDbkMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3BCLE9BQU8sQ0FBQyw4QkFBdUIsQ0FBQztvQkFDL0IsVUFBVSxFQUFFLENBQUMsZUFBZSxFQUFFLGVBQWUsRUFBRSxTQUFTLENBQUM7b0JBQ3pELGVBQWUsRUFBRSxDQUFDLGVBQWUsRUFBRSxlQUFlLEVBQUUsU0FBUyxDQUFDO29CQUM5RCxRQUFRLEVBQUUsQ0FBQyxlQUFlLEVBQUUsZUFBZSxFQUFFLFNBQVMsQ0FBQztvQkFDdkQsS0FBSyxFQUFFLENBQUMsZUFBZSxFQUFFLGVBQWUsQ0FBQztpQkFDMUMsQ0FBQyxDQUFDLENBQUM7WUFFVixDQUFDLENBQUMsQ0FBQztZQUVILHFCQUFFLENBQUMsNkNBQTZDLEVBQUU7Z0JBQ2hELElBQUksQ0FBQyxHQUFHLGFBQWEsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNsQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVoQixDQUFDLEdBQUcsYUFBYSxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNuQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDcEIsT0FBTyxDQUFDLDhCQUF1QixDQUFDO29CQUMvQixVQUFVLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxlQUFlLEVBQUUsZUFBZSxDQUFDO29CQUNsRSxlQUFlLEVBQUUsQ0FBQyxlQUFlLEVBQUUsZUFBZSxDQUFDO29CQUNuRCxRQUFRLEVBQUUsQ0FBQyxlQUFlLEVBQUUsZUFBZSxDQUFDO29CQUM1QyxLQUFLLEVBQUUsQ0FBQyxlQUFlLEVBQUUsZUFBZSxDQUFDO29CQUN6QyxTQUFTLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztpQkFDaEMsQ0FBQyxDQUFDLENBQUM7WUFFVixDQUFDLENBQUMsQ0FBQztZQUVILHFCQUFFLENBQUMsZ0NBQWdDLEVBQUU7Z0JBQ25DLElBQUksQ0FBQyxHQUFHLGFBQWEsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDdkMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFaEIsd0JBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUMzQixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDcEIsT0FBTyxDQUFDLDhCQUF1QixDQUFDO29CQUMvQixVQUFVLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDO29CQUNsQyxRQUFRLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLGtCQUFrQixDQUFDO29CQUNwRCxRQUFRLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztpQkFDL0IsQ0FBQyxDQUFDLENBQUM7WUFDVixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0gsMkJBQVEsQ0FBQywyQkFBMkIsRUFBRTtZQUNwQyxJQUFJLE1BQU0sQ0FBQztZQUVYLElBQUksWUFBWSxHQUFHLFVBQUMsS0FBYSxFQUFFLElBQVMsSUFBYSxPQUFBLEtBQUssRUFBTCxDQUFLLENBQUM7WUFFL0QsNkJBQVUsQ0FBQyxjQUFRLE1BQU0sR0FBRyxJQUFJLCtDQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFeEUscUJBQUUsQ0FBQyxnQ0FBZ0MsRUFBRTtnQkFDbkMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ25DLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNuQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUU5Qix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDcEIsT0FBTyxDQUFDLDhCQUF1QixDQUFDO29CQUMvQixVQUFVLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQztvQkFDM0IsUUFBUSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsWUFBWSxDQUFDO29CQUN2QyxRQUFRLEVBQUUsQ0FBQyxZQUFZLENBQUM7b0JBQ3hCLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQztpQkFDdkIsQ0FBQyxDQUFDLENBQUM7WUFDVixDQUFDLENBQUMsQ0FBQztRQUVMLENBQUMsQ0FBQyxDQUFDO0lBR0wsQ0FBQyxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQXhjZSxZQUFJLE9Bd2NuQixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgZGRlc2NyaWJlLFxuICBkZXNjcmliZSxcbiAgaXQsXG4gIGlpdCxcbiAgeGl0LFxuICBleHBlY3QsXG4gIGJlZm9yZUVhY2gsXG4gIGFmdGVyRWFjaFxufSBmcm9tICdhbmd1bGFyMi90ZXN0aW5nX2ludGVybmFsJztcbmltcG9ydCB7XG4gIERlZmF1bHRJdGVyYWJsZURpZmZlcixcbiAgRGVmYXVsdEl0ZXJhYmxlRGlmZmVyRmFjdG9yeVxufSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9jaGFuZ2VfZGV0ZWN0aW9uL2RpZmZlcnMvZGVmYXVsdF9pdGVyYWJsZV9kaWZmZXInO1xuXG5pbXBvcnQge051bWJlcldyYXBwZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvbGFuZyc7XG5pbXBvcnQge0xpc3RXcmFwcGVyfSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2NvbGxlY3Rpb24nO1xuXG5pbXBvcnQge1Rlc3RJdGVyYWJsZX0gZnJvbSAnLi4vLi4vLi4vY29yZS9jaGFuZ2VfZGV0ZWN0aW9uL2l0ZXJhYmxlJztcbmltcG9ydCB7aXRlcmFibGVDaGFuZ2VzQXNTdHJpbmd9IGZyb20gJy4uLy4uLy4uL2NvcmUvY2hhbmdlX2RldGVjdGlvbi91dGlsJztcblxuY2xhc3MgSXRlbVdpdGhJZCB7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgaWQ6IHN0cmluZykge31cblxuICB0b1N0cmluZygpIHsgcmV0dXJuIGB7aWQ6ICR7dGhpcy5pZH19YCB9XG59XG5cbmNsYXNzIENvbXBsZXhJdGVtIHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBpZDogc3RyaW5nLCBwcml2YXRlIGNvbG9yOiBzdHJpbmcpIHt9XG5cbiAgdG9TdHJpbmcoKSB7IHJldHVybiBge2lkOiAke3RoaXMuaWR9LCBjb2xvcjogJHt0aGlzLmNvbG9yfX1gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGRlc2NyaWJlKCdpdGVyYWJsZSBkaWZmZXInLCBmdW5jdGlvbigpIHtcbiAgICBkZXNjcmliZSgnRGVmYXVsdEl0ZXJhYmxlRGlmZmVyJywgZnVuY3Rpb24oKSB7XG4gICAgICB2YXIgZGlmZmVyO1xuXG4gICAgICBiZWZvcmVFYWNoKCgpID0+IHsgZGlmZmVyID0gbmV3IERlZmF1bHRJdGVyYWJsZURpZmZlcigpOyB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IGxpc3QgYW5kIGl0ZXJhYmxlcycsICgpID0+IHtcbiAgICAgICAgdmFyIGYgPSBuZXcgRGVmYXVsdEl0ZXJhYmxlRGlmZmVyRmFjdG9yeSgpO1xuICAgICAgICBleHBlY3QoZi5zdXBwb3J0cyhbXSkpLnRvQmVUcnV0aHkoKTtcbiAgICAgICAgZXhwZWN0KGYuc3VwcG9ydHMobmV3IFRlc3RJdGVyYWJsZSgpKSkudG9CZVRydXRoeSgpO1xuICAgICAgICBleHBlY3QoZi5zdXBwb3J0cyhuZXcgTWFwKCkpKS50b0JlRmFsc3koKTtcbiAgICAgICAgZXhwZWN0KGYuc3VwcG9ydHMobnVsbCkpLnRvQmVGYWxzeSgpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCBpdGVyYWJsZXMnLCAoKSA9PiB7XG4gICAgICAgIGxldCBsID0gbmV3IFRlc3RJdGVyYWJsZSgpO1xuXG4gICAgICAgIGRpZmZlci5jaGVjayhsKTtcbiAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKS50b0VxdWFsKGl0ZXJhYmxlQ2hhbmdlc0FzU3RyaW5nKHtjb2xsZWN0aW9uOiBbXX0pKTtcblxuICAgICAgICBsLmxpc3QgPSBbMV07XG4gICAgICAgIGRpZmZlci5jaGVjayhsKTtcbiAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgLnRvRXF1YWwoXG4gICAgICAgICAgICAgICAgaXRlcmFibGVDaGFuZ2VzQXNTdHJpbmcoe2NvbGxlY3Rpb246IFsnMVtudWxsLT4wXSddLCBhZGRpdGlvbnM6IFsnMVtudWxsLT4wXSddfSkpO1xuXG4gICAgICAgIGwubGlzdCA9IFsyLCAxXTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuICAgICAgICBleHBlY3QoZGlmZmVyLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAudG9FcXVhbChpdGVyYWJsZUNoYW5nZXNBc1N0cmluZyh7XG4gICAgICAgICAgICAgIGNvbGxlY3Rpb246IFsnMltudWxsLT4wXScsICcxWzAtPjFdJ10sXG4gICAgICAgICAgICAgIHByZXZpb3VzOiBbJzFbMC0+MV0nXSxcbiAgICAgICAgICAgICAgYWRkaXRpb25zOiBbJzJbbnVsbC0+MF0nXSxcbiAgICAgICAgICAgICAgbW92ZXM6IFsnMVswLT4xXSddXG4gICAgICAgICAgICB9KSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBkZXRlY3QgYWRkaXRpb25zJywgKCkgPT4ge1xuICAgICAgICBsZXQgbCA9IFtdO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSkudG9FcXVhbChpdGVyYWJsZUNoYW5nZXNBc1N0cmluZyh7Y29sbGVjdGlvbjogW119KSk7XG5cbiAgICAgICAgbC5wdXNoKCdhJyk7XG4gICAgICAgIGRpZmZlci5jaGVjayhsKTtcbiAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgLnRvRXF1YWwoXG4gICAgICAgICAgICAgICAgaXRlcmFibGVDaGFuZ2VzQXNTdHJpbmcoe2NvbGxlY3Rpb246IFsnYVtudWxsLT4wXSddLCBhZGRpdGlvbnM6IFsnYVtudWxsLT4wXSddfSkpO1xuXG4gICAgICAgIGwucHVzaCgnYicpO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGl0ZXJhYmxlQ2hhbmdlc0FzU3RyaW5nKFxuICAgICAgICAgICAgICAgIHtjb2xsZWN0aW9uOiBbJ2EnLCAnYltudWxsLT4xXSddLCBwcmV2aW91czogWydhJ10sIGFkZGl0aW9uczogWydiW251bGwtPjFdJ119KSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IGNoYW5naW5nIHRoZSByZWZlcmVuY2UnLCAoKSA9PiB7XG4gICAgICAgIGxldCBsID0gWzBdO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG5cbiAgICAgICAgbCA9IFsxLCAwXTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuICAgICAgICBleHBlY3QoZGlmZmVyLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAudG9FcXVhbChpdGVyYWJsZUNoYW5nZXNBc1N0cmluZyh7XG4gICAgICAgICAgICAgIGNvbGxlY3Rpb246IFsnMVtudWxsLT4wXScsICcwWzAtPjFdJ10sXG4gICAgICAgICAgICAgIHByZXZpb3VzOiBbJzBbMC0+MV0nXSxcbiAgICAgICAgICAgICAgYWRkaXRpb25zOiBbJzFbbnVsbC0+MF0nXSxcbiAgICAgICAgICAgICAgbW92ZXM6IFsnMFswLT4xXSddXG4gICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgbCA9IFsyLCAxLCAwXTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuICAgICAgICBleHBlY3QoZGlmZmVyLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAudG9FcXVhbChpdGVyYWJsZUNoYW5nZXNBc1N0cmluZyh7XG4gICAgICAgICAgICAgIGNvbGxlY3Rpb246IFsnMltudWxsLT4wXScsICcxWzAtPjFdJywgJzBbMS0+Ml0nXSxcbiAgICAgICAgICAgICAgcHJldmlvdXM6IFsnMVswLT4xXScsICcwWzEtPjJdJ10sXG4gICAgICAgICAgICAgIGFkZGl0aW9uczogWycyW251bGwtPjBdJ10sXG4gICAgICAgICAgICAgIG1vdmVzOiBbJzFbMC0+MV0nLCAnMFsxLT4yXSddXG4gICAgICAgICAgICB9KSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBoYW5kbGUgc3dhcHBpbmcgZWxlbWVudCcsICgpID0+IHtcbiAgICAgICAgbGV0IGwgPSBbMSwgMl07XG4gICAgICAgIGRpZmZlci5jaGVjayhsKTtcblxuICAgICAgICBMaXN0V3JhcHBlci5jbGVhcihsKTtcbiAgICAgICAgbC5wdXNoKDIpO1xuICAgICAgICBsLnB1c2goMSk7XG4gICAgICAgIGRpZmZlci5jaGVjayhsKTtcbiAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgLnRvRXF1YWwoaXRlcmFibGVDaGFuZ2VzQXNTdHJpbmcoe1xuICAgICAgICAgICAgICBjb2xsZWN0aW9uOiBbJzJbMS0+MF0nLCAnMVswLT4xXSddLFxuICAgICAgICAgICAgICBwcmV2aW91czogWycxWzAtPjFdJywgJzJbMS0+MF0nXSxcbiAgICAgICAgICAgICAgbW92ZXM6IFsnMlsxLT4wXScsICcxWzAtPjFdJ11cbiAgICAgICAgICAgIH0pKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIGhhbmRsZSBpbmNyZW1lbnRhbCBzd2FwcGluZyBlbGVtZW50JywgKCkgPT4ge1xuICAgICAgICBsZXQgbCA9IFsnYScsICdiJywgJ2MnXTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuXG4gICAgICAgIExpc3RXcmFwcGVyLnJlbW92ZUF0KGwsIDEpO1xuICAgICAgICBMaXN0V3JhcHBlci5pbnNlcnQobCwgMCwgJ2InKTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuICAgICAgICBleHBlY3QoZGlmZmVyLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAudG9FcXVhbChpdGVyYWJsZUNoYW5nZXNBc1N0cmluZyh7XG4gICAgICAgICAgICAgIGNvbGxlY3Rpb246IFsnYlsxLT4wXScsICdhWzAtPjFdJywgJ2MnXSxcbiAgICAgICAgICAgICAgcHJldmlvdXM6IFsnYVswLT4xXScsICdiWzEtPjBdJywgJ2MnXSxcbiAgICAgICAgICAgICAgbW92ZXM6IFsnYlsxLT4wXScsICdhWzAtPjFdJ11cbiAgICAgICAgICAgIH0pKTtcblxuICAgICAgICBMaXN0V3JhcHBlci5yZW1vdmVBdChsLCAxKTtcbiAgICAgICAgbC5wdXNoKCdhJyk7XG4gICAgICAgIGRpZmZlci5jaGVjayhsKTtcbiAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgLnRvRXF1YWwoaXRlcmFibGVDaGFuZ2VzQXNTdHJpbmcoe1xuICAgICAgICAgICAgICBjb2xsZWN0aW9uOiBbJ2InLCAnY1syLT4xXScsICdhWzEtPjJdJ10sXG4gICAgICAgICAgICAgIHByZXZpb3VzOiBbJ2InLCAnYVsxLT4yXScsICdjWzItPjFdJ10sXG4gICAgICAgICAgICAgIG1vdmVzOiBbJ2NbMi0+MV0nLCAnYVsxLT4yXSddXG4gICAgICAgICAgICB9KSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBkZXRlY3QgY2hhbmdlcyBpbiBsaXN0JywgKCkgPT4ge1xuICAgICAgICBsZXQgbCA9IFtdO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG5cbiAgICAgICAgbC5wdXNoKCdhJyk7XG4gICAgICAgIGRpZmZlci5jaGVjayhsKTtcbiAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgLnRvRXF1YWwoXG4gICAgICAgICAgICAgICAgaXRlcmFibGVDaGFuZ2VzQXNTdHJpbmcoe2NvbGxlY3Rpb246IFsnYVtudWxsLT4wXSddLCBhZGRpdGlvbnM6IFsnYVtudWxsLT4wXSddfSkpO1xuXG4gICAgICAgIGwucHVzaCgnYicpO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGl0ZXJhYmxlQ2hhbmdlc0FzU3RyaW5nKFxuICAgICAgICAgICAgICAgIHtjb2xsZWN0aW9uOiBbJ2EnLCAnYltudWxsLT4xXSddLCBwcmV2aW91czogWydhJ10sIGFkZGl0aW9uczogWydiW251bGwtPjFdJ119KSk7XG5cbiAgICAgICAgbC5wdXNoKCdjJyk7XG4gICAgICAgIGwucHVzaCgnZCcpO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGl0ZXJhYmxlQ2hhbmdlc0FzU3RyaW5nKHtcbiAgICAgICAgICAgICAgY29sbGVjdGlvbjogWydhJywgJ2InLCAnY1tudWxsLT4yXScsICdkW251bGwtPjNdJ10sXG4gICAgICAgICAgICAgIHByZXZpb3VzOiBbJ2EnLCAnYiddLFxuICAgICAgICAgICAgICBhZGRpdGlvbnM6IFsnY1tudWxsLT4yXScsICdkW251bGwtPjNdJ11cbiAgICAgICAgICAgIH0pKTtcblxuICAgICAgICBMaXN0V3JhcHBlci5yZW1vdmVBdChsLCAyKTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuICAgICAgICBleHBlY3QoZGlmZmVyLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAudG9FcXVhbChpdGVyYWJsZUNoYW5nZXNBc1N0cmluZyh7XG4gICAgICAgICAgICAgIGNvbGxlY3Rpb246IFsnYScsICdiJywgJ2RbMy0+Ml0nXSxcbiAgICAgICAgICAgICAgcHJldmlvdXM6IFsnYScsICdiJywgJ2NbMi0+bnVsbF0nLCAnZFszLT4yXSddLFxuICAgICAgICAgICAgICBtb3ZlczogWydkWzMtPjJdJ10sXG4gICAgICAgICAgICAgIHJlbW92YWxzOiBbJ2NbMi0+bnVsbF0nXVxuICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIExpc3RXcmFwcGVyLmNsZWFyKGwpO1xuICAgICAgICBsLnB1c2goJ2QnKTtcbiAgICAgICAgbC5wdXNoKCdjJyk7XG4gICAgICAgIGwucHVzaCgnYicpO1xuICAgICAgICBsLnB1c2goJ2EnKTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuICAgICAgICBleHBlY3QoZGlmZmVyLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAudG9FcXVhbChpdGVyYWJsZUNoYW5nZXNBc1N0cmluZyh7XG4gICAgICAgICAgICAgIGNvbGxlY3Rpb246IFsnZFsyLT4wXScsICdjW251bGwtPjFdJywgJ2JbMS0+Ml0nLCAnYVswLT4zXSddLFxuICAgICAgICAgICAgICBwcmV2aW91czogWydhWzAtPjNdJywgJ2JbMS0+Ml0nLCAnZFsyLT4wXSddLFxuICAgICAgICAgICAgICBhZGRpdGlvbnM6IFsnY1tudWxsLT4xXSddLFxuICAgICAgICAgICAgICBtb3ZlczogWydkWzItPjBdJywgJ2JbMS0+Ml0nLCAnYVswLT4zXSddXG4gICAgICAgICAgICB9KSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCB0ZXN0IHN0cmluZyBieSB2YWx1ZSByYXRoZXIgdGhhbiBieSByZWZlcmVuY2UgKERhcnQpJywgKCkgPT4ge1xuICAgICAgICBsZXQgbCA9IFsnYScsICdib28nXTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuXG4gICAgICAgIHZhciBiID0gJ2InO1xuICAgICAgICB2YXIgb28gPSAnb28nO1xuICAgICAgICBsWzFdID0gYiArIG9vO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGl0ZXJhYmxlQ2hhbmdlc0FzU3RyaW5nKHtjb2xsZWN0aW9uOiBbJ2EnLCAnYm9vJ10sIHByZXZpb3VzOiBbJ2EnLCAnYm9vJ119KSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBpZ25vcmUgW05hTl0gIT0gW05hTl0gKEpTKScsICgpID0+IHtcbiAgICAgICAgbGV0IGwgPSBbTnVtYmVyV3JhcHBlci5OYU5dO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG4gICAgICAgIGRpZmZlci5jaGVjayhsKTtcbiAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgLnRvRXF1YWwoaXRlcmFibGVDaGFuZ2VzQXNTdHJpbmcoXG4gICAgICAgICAgICAgICAge2NvbGxlY3Rpb246IFtOdW1iZXJXcmFwcGVyLk5hTl0sIHByZXZpb3VzOiBbTnVtYmVyV3JhcHBlci5OYU5dfSkpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgZGV0ZWN0IFtOYU5dIG1vdmVzJywgKCkgPT4ge1xuICAgICAgICBsZXQgbCA9IFtOdW1iZXJXcmFwcGVyLk5hTiwgTnVtYmVyV3JhcHBlci5OYU5dO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG5cbiAgICAgICAgTGlzdFdyYXBwZXIuaW5zZXJ0PGFueT4obCwgMCwgJ2ZvbycpO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGl0ZXJhYmxlQ2hhbmdlc0FzU3RyaW5nKHtcbiAgICAgICAgICAgICAgY29sbGVjdGlvbjogWydmb29bbnVsbC0+MF0nLCAnTmFOWzAtPjFdJywgJ05hTlsxLT4yXSddLFxuICAgICAgICAgICAgICBwcmV2aW91czogWydOYU5bMC0+MV0nLCAnTmFOWzEtPjJdJ10sXG4gICAgICAgICAgICAgIGFkZGl0aW9uczogWydmb29bbnVsbC0+MF0nXSxcbiAgICAgICAgICAgICAgbW92ZXM6IFsnTmFOWzAtPjFdJywgJ05hTlsxLT4yXSddXG4gICAgICAgICAgICB9KSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCByZW1vdmUgYW5kIGFkZCBzYW1lIGl0ZW0nLCAoKSA9PiB7XG4gICAgICAgIGxldCBsID0gWydhJywgJ2InLCAnYyddO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG5cbiAgICAgICAgTGlzdFdyYXBwZXIucmVtb3ZlQXQobCwgMSk7XG4gICAgICAgIGRpZmZlci5jaGVjayhsKTtcbiAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgLnRvRXF1YWwoaXRlcmFibGVDaGFuZ2VzQXNTdHJpbmcoe1xuICAgICAgICAgICAgICBjb2xsZWN0aW9uOiBbJ2EnLCAnY1syLT4xXSddLFxuICAgICAgICAgICAgICBwcmV2aW91czogWydhJywgJ2JbMS0+bnVsbF0nLCAnY1syLT4xXSddLFxuICAgICAgICAgICAgICBtb3ZlczogWydjWzItPjFdJ10sXG4gICAgICAgICAgICAgIHJlbW92YWxzOiBbJ2JbMS0+bnVsbF0nXVxuICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIExpc3RXcmFwcGVyLmluc2VydChsLCAxLCAnYicpO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGl0ZXJhYmxlQ2hhbmdlc0FzU3RyaW5nKHtcbiAgICAgICAgICAgICAgY29sbGVjdGlvbjogWydhJywgJ2JbbnVsbC0+MV0nLCAnY1sxLT4yXSddLFxuICAgICAgICAgICAgICBwcmV2aW91czogWydhJywgJ2NbMS0+Ml0nXSxcbiAgICAgICAgICAgICAgYWRkaXRpb25zOiBbJ2JbbnVsbC0+MV0nXSxcbiAgICAgICAgICAgICAgbW92ZXM6IFsnY1sxLT4yXSddXG4gICAgICAgICAgICB9KSk7XG4gICAgICB9KTtcblxuXG4gICAgICBpdCgnc2hvdWxkIHN1cHBvcnQgZHVwbGljYXRlcycsICgpID0+IHtcbiAgICAgICAgbGV0IGwgPSBbJ2EnLCAnYScsICdhJywgJ2InLCAnYiddO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG5cbiAgICAgICAgTGlzdFdyYXBwZXIucmVtb3ZlQXQobCwgMCk7XG4gICAgICAgIGRpZmZlci5jaGVjayhsKTtcbiAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgLnRvRXF1YWwoaXRlcmFibGVDaGFuZ2VzQXNTdHJpbmcoe1xuICAgICAgICAgICAgICBjb2xsZWN0aW9uOiBbJ2EnLCAnYScsICdiWzMtPjJdJywgJ2JbNC0+M10nXSxcbiAgICAgICAgICAgICAgcHJldmlvdXM6IFsnYScsICdhJywgJ2FbMi0+bnVsbF0nLCAnYlszLT4yXScsICdiWzQtPjNdJ10sXG4gICAgICAgICAgICAgIG1vdmVzOiBbJ2JbMy0+Ml0nLCAnYls0LT4zXSddLFxuICAgICAgICAgICAgICByZW1vdmFsczogWydhWzItPm51bGxdJ11cbiAgICAgICAgICAgIH0pKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHN1cHBvcnQgaW5zZXJ0aW9ucy9tb3ZlcycsICgpID0+IHtcbiAgICAgICAgbGV0IGwgPSBbJ2EnLCAnYScsICdiJywgJ2InXTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuXG4gICAgICAgIExpc3RXcmFwcGVyLmluc2VydChsLCAwLCAnYicpO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGl0ZXJhYmxlQ2hhbmdlc0FzU3RyaW5nKHtcbiAgICAgICAgICAgICAgY29sbGVjdGlvbjogWydiWzItPjBdJywgJ2FbMC0+MV0nLCAnYVsxLT4yXScsICdiJywgJ2JbbnVsbC0+NF0nXSxcbiAgICAgICAgICAgICAgcHJldmlvdXM6IFsnYVswLT4xXScsICdhWzEtPjJdJywgJ2JbMi0+MF0nLCAnYiddLFxuICAgICAgICAgICAgICBhZGRpdGlvbnM6IFsnYltudWxsLT40XSddLFxuICAgICAgICAgICAgICBtb3ZlczogWydiWzItPjBdJywgJ2FbMC0+MV0nLCAnYVsxLT4yXSddXG4gICAgICAgICAgICB9KSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBub3QgcmVwb3J0IHVubmVjZXNzYXJ5IG1vdmVzJywgKCkgPT4ge1xuICAgICAgICBsZXQgbCA9IFsnYScsICdiJywgJ2MnXTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuXG4gICAgICAgIExpc3RXcmFwcGVyLmNsZWFyKGwpO1xuICAgICAgICBsLnB1c2goJ2InKTtcbiAgICAgICAgbC5wdXNoKCdhJyk7XG4gICAgICAgIGwucHVzaCgnYycpO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGl0ZXJhYmxlQ2hhbmdlc0FzU3RyaW5nKHtcbiAgICAgICAgICAgICAgY29sbGVjdGlvbjogWydiWzEtPjBdJywgJ2FbMC0+MV0nLCAnYyddLFxuICAgICAgICAgICAgICBwcmV2aW91czogWydhWzAtPjFdJywgJ2JbMS0+MF0nLCAnYyddLFxuICAgICAgICAgICAgICBtb3ZlczogWydiWzEtPjBdJywgJ2FbMC0+MV0nXVxuICAgICAgICAgICAgfSkpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgbm90IGRpZmYgaW1tdXRhYmxlIGNvbGxlY3Rpb25zIGlmIHRoZXkgYXJlIHRoZSBzYW1lJywgKCkgPT4ge1xuICAgICAgICAvLyBOb3RlOiBVc2UgdHJhY2tCeSB0byBrbm93IGlmIGRpZmZpbmcgaGFwcGVuZWRcbiAgICAgICAgdmFyIHRyYWNrQnlDb3VudCA9IDA7XG4gICAgICAgIHZhciB0cmFja0J5ID0gKGluZGV4OiBudW1iZXIsIGl0ZW06IGFueSk6IGFueSA9PiB7XG4gICAgICAgICAgdHJhY2tCeUNvdW50Kys7XG4gICAgICAgICAgcmV0dXJuIGl0ZW07XG4gICAgICAgIH07XG4gICAgICAgIHZhciBkaWZmZXIgPSBuZXcgRGVmYXVsdEl0ZXJhYmxlRGlmZmVyKHRyYWNrQnkpO1xuICAgICAgICB2YXIgbDEgPSBMaXN0V3JhcHBlci5jcmVhdGVJbW11dGFibGUoWzFdKTtcblxuICAgICAgICBkaWZmZXIuY2hlY2sobDEpO1xuICAgICAgICBleHBlY3QodHJhY2tCeUNvdW50KS50b0JlKDEpO1xuICAgICAgICBleHBlY3QoZGlmZmVyLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAudG9FcXVhbChcbiAgICAgICAgICAgICAgICBpdGVyYWJsZUNoYW5nZXNBc1N0cmluZyh7Y29sbGVjdGlvbjogWycxW251bGwtPjBdJ10sIGFkZGl0aW9uczogWycxW251bGwtPjBdJ119KSk7XG5cblxuICAgICAgICB0cmFja0J5Q291bnQgPSAwO1xuICAgICAgICBkaWZmZXIuY2hlY2sobDEpO1xuICAgICAgICBleHBlY3QodHJhY2tCeUNvdW50KS50b0JlKDApO1xuICAgICAgICBleHBlY3QoZGlmZmVyLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAudG9FcXVhbChpdGVyYWJsZUNoYW5nZXNBc1N0cmluZyh7Y29sbGVjdGlvbjogWycxJ10sIHByZXZpb3VzOiBbJzEnXX0pKTtcblxuICAgICAgICB0cmFja0J5Q291bnQgPSAwO1xuICAgICAgICBkaWZmZXIuY2hlY2sobDEpO1xuICAgICAgICBleHBlY3QodHJhY2tCeUNvdW50KS50b0JlKDApO1xuICAgICAgICBleHBlY3QoZGlmZmVyLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAudG9FcXVhbChpdGVyYWJsZUNoYW5nZXNBc1N0cmluZyh7Y29sbGVjdGlvbjogWycxJ10sIHByZXZpb3VzOiBbJzEnXX0pKTtcbiAgICAgIH0pO1xuXG4gICAgICBkZXNjcmliZSgnZGlmZicsICgpID0+IHtcbiAgICAgICAgaXQoJ3Nob3VsZCByZXR1cm4gc2VsZiB3aGVuIHRoZXJlIGlzIGEgY2hhbmdlJyxcbiAgICAgICAgICAgKCkgPT4geyBleHBlY3QoZGlmZmVyLmRpZmYoWydhJywgJ2InXSkpLnRvQmUoZGlmZmVyKTsgfSk7XG5cbiAgICAgICAgaXQoJ3Nob3VsZCByZXR1cm4gbnVsbCB3aGVuIHRoZXJlIGlzIG5vIGNoYW5nZScsICgpID0+IHtcbiAgICAgICAgICBkaWZmZXIuZGlmZihbJ2EnLCAnYiddKTtcbiAgICAgICAgICBleHBlY3QoZGlmZmVyLmRpZmYoWydhJywgJ2InXSkpLnRvRXF1YWwobnVsbCk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGl0KCdzaG91bGQgdHJlYXQgbnVsbCBhcyBhbiBlbXB0eSBsaXN0JywgKCkgPT4ge1xuICAgICAgICAgIGRpZmZlci5kaWZmKFsnYScsICdiJ10pO1xuICAgICAgICAgIGV4cGVjdChkaWZmZXIuZGlmZihudWxsKS50b1N0cmluZygpKVxuICAgICAgICAgICAgICAudG9FcXVhbChpdGVyYWJsZUNoYW5nZXNBc1N0cmluZyh7XG4gICAgICAgICAgICAgICAgcHJldmlvdXM6IFsnYVswLT5udWxsXScsICdiWzEtPm51bGxdJ10sXG4gICAgICAgICAgICAgICAgcmVtb3ZhbHM6IFsnYVswLT5udWxsXScsICdiWzEtPm51bGxdJ11cbiAgICAgICAgICAgICAgfSkpO1xuICAgICAgICB9KTtcblxuICAgICAgICBpdCgnc2hvdWxkIHRocm93IHdoZW4gZ2l2ZW4gYW4gaW52YWxpZCBjb2xsZWN0aW9uJywgKCkgPT4ge1xuICAgICAgICAgIGV4cGVjdCgoKSA9PiBkaWZmZXIuZGlmZihcImludmFsaWRcIikpLnRvVGhyb3dFcnJvcldpdGgoXCJFcnJvciB0cnlpbmcgdG8gZGlmZiAnaW52YWxpZCdcIik7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICBkZXNjcmliZSgndHJhY2tCeSBmdW5jdGlvbiBieSBpZCcsIGZ1bmN0aW9uKCkge1xuICAgICAgdmFyIGRpZmZlcjtcblxuICAgICAgdmFyIHRyYWNrQnlJdGVtSWQgPSAoaW5kZXg6IG51bWJlciwgaXRlbTogYW55KTogYW55ID0+IGl0ZW0uaWQ7XG5cbiAgICAgIHZhciBidWlsZEl0ZW1MaXN0ID1cbiAgICAgICAgICAobGlzdDogc3RyaW5nW10pID0+IHsgcmV0dXJuIGxpc3QubWFwKCh2YWwpID0+IHtyZXR1cm4gbmV3IEl0ZW1XaXRoSWQodmFsKX0pIH07XG5cbiAgICAgIGJlZm9yZUVhY2goKCkgPT4geyBkaWZmZXIgPSBuZXcgRGVmYXVsdEl0ZXJhYmxlRGlmZmVyKHRyYWNrQnlJdGVtSWQpOyB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCB0cmVhdCB0aGUgY29sbGVjdGlvbiBhcyBkaXJ0eSBpZiBpZGVudGl0eSBjaGFuZ2VzJywgKCkgPT4ge1xuICAgICAgICBkaWZmZXIuZGlmZihidWlsZEl0ZW1MaXN0KFsnYSddKSk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIuZGlmZihidWlsZEl0ZW1MaXN0KFsnYSddKSkpLnRvQmUoZGlmZmVyKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHRyZWF0IHNlZW4gcmVjb3JkcyBhcyBpZGVudGl0eSBjaGFuZ2VzLCBub3QgYWRkaXRpb25zJywgKCkgPT4ge1xuICAgICAgICBsZXQgbCA9IGJ1aWxkSXRlbUxpc3QoWydhJywgJ2InLCAnYyddKTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuICAgICAgICBleHBlY3QoZGlmZmVyLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAudG9FcXVhbChpdGVyYWJsZUNoYW5nZXNBc1N0cmluZyh7XG4gICAgICAgICAgICAgIGNvbGxlY3Rpb246IFtge2lkOiBhfVtudWxsLT4wXWAsIGB7aWQ6IGJ9W251bGwtPjFdYCwgYHtpZDogY31bbnVsbC0+Ml1gXSxcbiAgICAgICAgICAgICAgYWRkaXRpb25zOiBbYHtpZDogYX1bbnVsbC0+MF1gLCBge2lkOiBifVtudWxsLT4xXWAsIGB7aWQ6IGN9W251bGwtPjJdYF1cbiAgICAgICAgICAgIH0pKTtcblxuICAgICAgICBsID0gYnVpbGRJdGVtTGlzdChbJ2EnLCAnYicsICdjJ10pO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGl0ZXJhYmxlQ2hhbmdlc0FzU3RyaW5nKHtcbiAgICAgICAgICAgICAgY29sbGVjdGlvbjogW2B7aWQ6IGF9YCwgYHtpZDogYn1gLCBge2lkOiBjfWBdLFxuICAgICAgICAgICAgICBpZGVudGl0eUNoYW5nZXM6IFtge2lkOiBhfWAsIGB7aWQ6IGJ9YCwgYHtpZDogY31gXSxcbiAgICAgICAgICAgICAgcHJldmlvdXM6IFtge2lkOiBhfWAsIGB7aWQ6IGJ9YCwgYHtpZDogY31gXVxuICAgICAgICAgICAgfSkpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgaGF2ZSB1cGRhdGVkIHByb3BlcnRpZXMgaW4gaWRlbnRpdHkgY2hhbmdlIGNvbGxlY3Rpb24nLCAoKSA9PiB7XG4gICAgICAgIGxldCBsID0gW25ldyBDb21wbGV4SXRlbSgnYScsICdibHVlJyksIG5ldyBDb21wbGV4SXRlbSgnYicsICd5ZWxsb3cnKV07XG4gICAgICAgIGRpZmZlci5jaGVjayhsKTtcblxuICAgICAgICBsID0gW25ldyBDb21wbGV4SXRlbSgnYScsICdvcmFuZ2UnKSwgbmV3IENvbXBsZXhJdGVtKCdiJywgJ3JlZCcpXTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuICAgICAgICBleHBlY3QoZGlmZmVyLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAudG9FcXVhbChpdGVyYWJsZUNoYW5nZXNBc1N0cmluZyh7XG4gICAgICAgICAgICAgIGNvbGxlY3Rpb246IFtge2lkOiBhLCBjb2xvcjogb3JhbmdlfWAsIGB7aWQ6IGIsIGNvbG9yOiByZWR9YF0sXG4gICAgICAgICAgICAgIGlkZW50aXR5Q2hhbmdlczogW2B7aWQ6IGEsIGNvbG9yOiBvcmFuZ2V9YCwgYHtpZDogYiwgY29sb3I6IHJlZH1gXSxcbiAgICAgICAgICAgICAgcHJldmlvdXM6IFtge2lkOiBhLCBjb2xvcjogb3JhbmdlfWAsIGB7aWQ6IGIsIGNvbG9yOiByZWR9YF1cbiAgICAgICAgICAgIH0pKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHRyYWNrIG1vdmVzIG5vcm1hbGx5JywgKCkgPT4ge1xuICAgICAgICBsZXQgbCA9IGJ1aWxkSXRlbUxpc3QoWydhJywgJ2InLCAnYyddKTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuXG4gICAgICAgIGwgPSBidWlsZEl0ZW1MaXN0KFsnYicsICdhJywgJ2MnXSk7XG4gICAgICAgIGRpZmZlci5jaGVjayhsKTtcbiAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgLnRvRXF1YWwoaXRlcmFibGVDaGFuZ2VzQXNTdHJpbmcoe1xuICAgICAgICAgICAgICBjb2xsZWN0aW9uOiBbJ3tpZDogYn1bMS0+MF0nLCAne2lkOiBhfVswLT4xXScsICd7aWQ6IGN9J10sXG4gICAgICAgICAgICAgIGlkZW50aXR5Q2hhbmdlczogWyd7aWQ6IGJ9WzEtPjBdJywgJ3tpZDogYX1bMC0+MV0nLCAne2lkOiBjfSddLFxuICAgICAgICAgICAgICBwcmV2aW91czogWyd7aWQ6IGF9WzAtPjFdJywgJ3tpZDogYn1bMS0+MF0nLCAne2lkOiBjfSddLFxuICAgICAgICAgICAgICBtb3ZlczogWyd7aWQ6IGJ9WzEtPjBdJywgJ3tpZDogYX1bMC0+MV0nXVxuICAgICAgICAgICAgfSkpO1xuXG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCB0cmFjayBkdXBsaWNhdGUgcmVpbnNlcnRpb24gbm9ybWFsbHknLCAoKSA9PiB7XG4gICAgICAgIGxldCBsID0gYnVpbGRJdGVtTGlzdChbJ2EnLCAnYSddKTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuXG4gICAgICAgIGwgPSBidWlsZEl0ZW1MaXN0KFsnYicsICdhJywgJ2EnXSk7XG4gICAgICAgIGRpZmZlci5jaGVjayhsKTtcbiAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgLnRvRXF1YWwoaXRlcmFibGVDaGFuZ2VzQXNTdHJpbmcoe1xuICAgICAgICAgICAgICBjb2xsZWN0aW9uOiBbJ3tpZDogYn1bbnVsbC0+MF0nLCAne2lkOiBhfVswLT4xXScsICd7aWQ6IGF9WzEtPjJdJ10sXG4gICAgICAgICAgICAgIGlkZW50aXR5Q2hhbmdlczogWyd7aWQ6IGF9WzAtPjFdJywgJ3tpZDogYX1bMS0+Ml0nXSxcbiAgICAgICAgICAgICAgcHJldmlvdXM6IFsne2lkOiBhfVswLT4xXScsICd7aWQ6IGF9WzEtPjJdJ10sXG4gICAgICAgICAgICAgIG1vdmVzOiBbJ3tpZDogYX1bMC0+MV0nLCAne2lkOiBhfVsxLT4yXSddLFxuICAgICAgICAgICAgICBhZGRpdGlvbnM6IFsne2lkOiBifVtudWxsLT4wXSddXG4gICAgICAgICAgICB9KSk7XG5cbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHRyYWNrIHJlbW92YWxzIG5vcm1hbGx5JywgKCkgPT4ge1xuICAgICAgICBsZXQgbCA9IGJ1aWxkSXRlbUxpc3QoWydhJywgJ2InLCAnYyddKTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKGwpO1xuXG4gICAgICAgIExpc3RXcmFwcGVyLnJlbW92ZUF0KGwsIDIpO1xuICAgICAgICBkaWZmZXIuY2hlY2sobCk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGl0ZXJhYmxlQ2hhbmdlc0FzU3RyaW5nKHtcbiAgICAgICAgICAgICAgY29sbGVjdGlvbjogWyd7aWQ6IGF9JywgJ3tpZDogYn0nXSxcbiAgICAgICAgICAgICAgcHJldmlvdXM6IFsne2lkOiBhfScsICd7aWQ6IGJ9JywgJ3tpZDogY31bMi0+bnVsbF0nXSxcbiAgICAgICAgICAgICAgcmVtb3ZhbHM6IFsne2lkOiBjfVsyLT5udWxsXSddXG4gICAgICAgICAgICB9KSk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICBkZXNjcmliZSgndHJhY2tCeSBmdW5jdGlvbiBieSBpbmRleCcsIGZ1bmN0aW9uKCkge1xuICAgICAgdmFyIGRpZmZlcjtcblxuICAgICAgdmFyIHRyYWNrQnlJbmRleCA9IChpbmRleDogbnVtYmVyLCBpdGVtOiBhbnkpOiBudW1iZXIgPT4gaW5kZXg7XG5cbiAgICAgIGJlZm9yZUVhY2goKCkgPT4geyBkaWZmZXIgPSBuZXcgRGVmYXVsdEl0ZXJhYmxlRGlmZmVyKHRyYWNrQnlJbmRleCk7IH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHRyYWNrIHJlbW92YWxzIG5vcm1hbGx5JywgKCkgPT4ge1xuICAgICAgICBkaWZmZXIuY2hlY2soWydhJywgJ2InLCAnYycsICdkJ10pO1xuICAgICAgICBkaWZmZXIuY2hlY2soWydlJywgJ2YnLCAnZycsICdoJ10pO1xuICAgICAgICBkaWZmZXIuY2hlY2soWydlJywgJ2YnLCAnaCddKTtcblxuICAgICAgICBleHBlY3QoZGlmZmVyLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAudG9FcXVhbChpdGVyYWJsZUNoYW5nZXNBc1N0cmluZyh7XG4gICAgICAgICAgICAgIGNvbGxlY3Rpb246IFsnZScsICdmJywgJ2gnXSxcbiAgICAgICAgICAgICAgcHJldmlvdXM6IFsnZScsICdmJywgJ2gnLCAnaFszLT5udWxsXSddLFxuICAgICAgICAgICAgICByZW1vdmFsczogWydoWzMtPm51bGxdJ10sXG4gICAgICAgICAgICAgIGlkZW50aXR5Q2hhbmdlczogWydoJ11cbiAgICAgICAgICAgIH0pKTtcbiAgICAgIH0pO1xuXG4gICAgfSk7XG5cblxuICB9KTtcbn1cbiJdfQ==
 main(); 
