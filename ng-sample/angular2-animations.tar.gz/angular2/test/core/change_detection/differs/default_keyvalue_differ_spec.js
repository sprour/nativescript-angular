'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var default_keyvalue_differ_1 = require('angular2/src/core/change_detection/differs/default_keyvalue_differ');
var lang_1 = require('angular2/src/facade/lang');
var util_1 = require('../../../core/change_detection/util');
// todo(vicb): Update the code & tests for object equality
function main() {
    testing_internal_1.describe('keyvalue differ', function () {
        testing_internal_1.describe('DefaultKeyValueDiffer', function () {
            var differ;
            var m;
            testing_internal_1.beforeEach(function () {
                differ = new default_keyvalue_differ_1.DefaultKeyValueDiffer();
                m = new Map();
            });
            testing_internal_1.afterEach(function () { differ = null; });
            testing_internal_1.it('should detect additions', function () {
                differ.check(m);
                m.set('a', 1);
                differ.check(m);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.kvChangesAsString({ map: ['a[null->1]'], additions: ['a[null->1]'] }));
                m.set('b', 2);
                differ.check(m);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.kvChangesAsString({ map: ['a', 'b[null->2]'], previous: ['a'], additions: ['b[null->2]'] }));
            });
            testing_internal_1.it('should handle changing key/values correctly', function () {
                m.set(1, 10);
                m.set(2, 20);
                differ.check(m);
                m.set(2, 10);
                m.set(1, 20);
                differ.check(m);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.kvChangesAsString({
                    map: ['1[10->20]', '2[20->10]'],
                    previous: ['1[10->20]', '2[20->10]'],
                    changes: ['1[10->20]', '2[20->10]']
                }));
            });
            testing_internal_1.it('should expose previous and current value', function () {
                var previous, current;
                m.set(1, 10);
                differ.check(m);
                m.set(1, 20);
                differ.check(m);
                differ.forEachChangedItem(function (record) {
                    previous = record.previousValue;
                    current = record.currentValue;
                });
                testing_internal_1.expect(previous).toEqual(10);
                testing_internal_1.expect(current).toEqual(20);
            });
            testing_internal_1.it('should do basic map watching', function () {
                differ.check(m);
                m.set('a', 'A');
                differ.check(m);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.kvChangesAsString({ map: ['a[null->A]'], additions: ['a[null->A]'] }));
                m.set('b', 'B');
                differ.check(m);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.kvChangesAsString({ map: ['a', 'b[null->B]'], previous: ['a'], additions: ['b[null->B]'] }));
                m.set('b', 'BB');
                m.set('d', 'D');
                differ.check(m);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.kvChangesAsString({
                    map: ['a', 'b[B->BB]', 'd[null->D]'],
                    previous: ['a', 'b[B->BB]'],
                    additions: ['d[null->D]'],
                    changes: ['b[B->BB]']
                }));
                m.delete('b');
                differ.check(m);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.kvChangesAsString({ map: ['a', 'd'], previous: ['a', 'b[BB->null]', 'd'], removals: ['b[BB->null]'] }));
                m.clear();
                differ.check(m);
                testing_internal_1.expect(differ.toString())
                    .toEqual(util_1.kvChangesAsString({ previous: ['a[A->null]', 'd[D->null]'], removals: ['a[A->null]', 'd[D->null]'] }));
            });
            testing_internal_1.it('should test string by value rather than by reference (DART)', function () {
                m.set('foo', 'bar');
                differ.check(m);
                var f = 'f';
                var oo = 'oo';
                var b = 'b';
                var ar = 'ar';
                m.set(f + oo, b + ar);
                differ.check(m);
                testing_internal_1.expect(differ.toString()).toEqual(util_1.kvChangesAsString({ map: ['foo'], previous: ['foo'] }));
            });
            testing_internal_1.it('should not see a NaN value as a change (JS)', function () {
                m.set('foo', lang_1.NumberWrapper.NaN);
                differ.check(m);
                differ.check(m);
                testing_internal_1.expect(differ.toString()).toEqual(util_1.kvChangesAsString({ map: ['foo'], previous: ['foo'] }));
            });
            // JS specific tests (JS Objects)
            if (lang_1.isJsObject({})) {
                testing_internal_1.describe('JsObject changes', function () {
                    testing_internal_1.it('should support JS Object', function () {
                        var f = new default_keyvalue_differ_1.DefaultKeyValueDifferFactory();
                        testing_internal_1.expect(f.supports({})).toBeTruthy();
                        testing_internal_1.expect(f.supports("not supported")).toBeFalsy();
                        testing_internal_1.expect(f.supports(0)).toBeFalsy();
                        testing_internal_1.expect(f.supports(null)).toBeFalsy();
                    });
                    testing_internal_1.it('should do basic object watching', function () {
                        var m = {};
                        differ.check(m);
                        m['a'] = 'A';
                        differ.check(m);
                        testing_internal_1.expect(differ.toString())
                            .toEqual(util_1.kvChangesAsString({ map: ['a[null->A]'], additions: ['a[null->A]'] }));
                        m['b'] = 'B';
                        differ.check(m);
                        testing_internal_1.expect(differ.toString())
                            .toEqual(util_1.kvChangesAsString({ map: ['a', 'b[null->B]'], previous: ['a'], additions: ['b[null->B]'] }));
                        m['b'] = 'BB';
                        m['d'] = 'D';
                        differ.check(m);
                        testing_internal_1.expect(differ.toString())
                            .toEqual(util_1.kvChangesAsString({
                            map: ['a', 'b[B->BB]', 'd[null->D]'],
                            previous: ['a', 'b[B->BB]'],
                            additions: ['d[null->D]'],
                            changes: ['b[B->BB]']
                        }));
                        m = {};
                        m['a'] = 'A';
                        m['d'] = 'D';
                        differ.check(m);
                        testing_internal_1.expect(differ.toString())
                            .toEqual(util_1.kvChangesAsString({
                            map: ['a', 'd'],
                            previous: ['a', 'b[BB->null]', 'd'],
                            removals: ['b[BB->null]']
                        }));
                        m = {};
                        differ.check(m);
                        testing_internal_1.expect(differ.toString())
                            .toEqual(util_1.kvChangesAsString({
                            previous: ['a[A->null]', 'd[D->null]'],
                            removals: ['a[A->null]', 'd[D->null]']
                        }));
                    });
                });
                testing_internal_1.describe('diff', function () {
                    testing_internal_1.it('should return self when there is a change', function () {
                        m.set('a', 'A');
                        testing_internal_1.expect(differ.diff(m)).toBe(differ);
                    });
                    testing_internal_1.it('should return null when there is no change', function () {
                        m.set('a', 'A');
                        differ.diff(m);
                        testing_internal_1.expect(differ.diff(m)).toEqual(null);
                    });
                    testing_internal_1.it('should treat null as an empty list', function () {
                        m.set('a', 'A');
                        differ.diff(m);
                        testing_internal_1.expect(differ.diff(null).toString())
                            .toEqual(util_1.kvChangesAsString({ previous: ['a[A->null]'], removals: ['a[A->null]'] }));
                    });
                    testing_internal_1.it('should throw when given an invalid collection', function () {
                        testing_internal_1.expect(function () { return differ.diff("invalid"); }).toThrowErrorWith("Error trying to diff 'invalid'");
                    });
                });
            }
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVmYXVsdF9rZXl2YWx1ZV9kaWZmZXJfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29yZS9jaGFuZ2VfZGV0ZWN0aW9uL2RpZmZlcnMvZGVmYXVsdF9rZXl2YWx1ZV9kaWZmZXJfc3BlYy50cyJdLCJuYW1lcyI6WyJtYWluIl0sIm1hcHBpbmdzIjoiQUFBQSxpQ0FTTywyQkFBMkIsQ0FBQyxDQUFBO0FBQ25DLHdDQUdPLG9FQUFvRSxDQUFDLENBQUE7QUFDNUUscUJBQXdDLDBCQUEwQixDQUFDLENBQUE7QUFDbkUscUJBQWdDLHFDQUFxQyxDQUFDLENBQUE7QUFFdEUsMERBQTBEO0FBQzFEO0lBQ0VBLDJCQUFRQSxDQUFDQSxpQkFBaUJBLEVBQUVBO1FBQzFCLDJCQUFRLENBQUMsdUJBQXVCLEVBQUU7WUFDaEMsSUFBSSxNQUFNLENBQUM7WUFDWCxJQUFJLENBQWdCLENBQUM7WUFFckIsNkJBQVUsQ0FBQztnQkFDVCxNQUFNLEdBQUcsSUFBSSwrQ0FBcUIsRUFBRSxDQUFDO2dCQUNyQyxDQUFDLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztZQUNoQixDQUFDLENBQUMsQ0FBQztZQUVILDRCQUFTLENBQUMsY0FBUSxNQUFNLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFcEMscUJBQUUsQ0FBQyx5QkFBeUIsRUFBRTtnQkFDNUIsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFaEIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ2QsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3BCLE9BQU8sQ0FBQyx3QkFBaUIsQ0FBQyxFQUFDLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFFLFNBQVMsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVsRixDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDZCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDcEIsT0FBTyxDQUFDLHdCQUFpQixDQUN0QixFQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRSxZQUFZLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztZQUNuRixDQUFDLENBQUMsQ0FBQztZQUVILHFCQUFFLENBQUMsNkNBQTZDLEVBQUU7Z0JBQ2hELENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUNiLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUNiLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRWhCLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUNiLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUNiLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQUMsd0JBQWlCLENBQUM7b0JBQ3pCLEdBQUcsRUFBRSxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUM7b0JBQy9CLFFBQVEsRUFBRSxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUM7b0JBQ3BDLE9BQU8sRUFBRSxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUM7aUJBQ3BDLENBQUMsQ0FBQyxDQUFDO1lBQ1YsQ0FBQyxDQUFDLENBQUM7WUFFSCxxQkFBRSxDQUFDLDBDQUEwQyxFQUFFO2dCQUM3QyxJQUFJLFFBQVEsRUFBRSxPQUFPLENBQUM7Z0JBRXRCLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUNiLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRWhCLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUNiLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRWhCLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxVQUFDLE1BQU07b0JBQy9CLFFBQVEsR0FBRyxNQUFNLENBQUMsYUFBYSxDQUFDO29CQUNoQyxPQUFPLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQztnQkFDaEMsQ0FBQyxDQUFDLENBQUM7Z0JBRUgseUJBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQzdCLHlCQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQzlCLENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQyw4QkFBOEIsRUFBRTtnQkFDakMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFaEIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ2hCLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQUMsd0JBQWlCLENBQUMsRUFBQyxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztnQkFFbEYsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ2hCLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQUMsd0JBQWlCLENBQ3RCLEVBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLFlBQVksQ0FBQyxFQUFFLFFBQVEsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLFNBQVMsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVqRixDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDakIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ2hCLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQUMsd0JBQWlCLENBQUM7b0JBQ3pCLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRSxVQUFVLEVBQUUsWUFBWSxDQUFDO29CQUNwQyxRQUFRLEVBQUUsQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDO29CQUMzQixTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUM7b0JBQ3pCLE9BQU8sRUFBRSxDQUFDLFVBQVUsQ0FBQztpQkFDdEIsQ0FBQyxDQUFDLENBQUM7Z0JBRVIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDZCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDcEIsT0FBTyxDQUFDLHdCQUFpQixDQUN0QixFQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxHQUFHLEVBQUUsYUFBYSxFQUFFLEdBQUcsQ0FBQyxFQUFFLFFBQVEsRUFBRSxDQUFDLGFBQWEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUU1RixDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQ1YsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3BCLE9BQU8sQ0FBQyx3QkFBaUIsQ0FDdEIsRUFBQyxRQUFRLEVBQUUsQ0FBQyxZQUFZLEVBQUUsWUFBWSxDQUFDLEVBQUUsUUFBUSxFQUFFLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzdGLENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQyw2REFBNkQsRUFBRTtnQkFDaEUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQ3BCLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRWhCLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQztnQkFDWixJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUM7Z0JBQ2QsSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDO2dCQUNaLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQztnQkFFZCxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO2dCQUN0QixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVoQix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyx3QkFBaUIsQ0FBQyxFQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLFFBQVEsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFGLENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQyw2Q0FBNkMsRUFBRTtnQkFDaEQsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsb0JBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDaEMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFaEIsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsd0JBQWlCLENBQUMsRUFBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztZQUMxRixDQUFDLENBQUMsQ0FBQztZQUVILGlDQUFpQztZQUNqQyxFQUFFLENBQUMsQ0FBQyxpQkFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDbkIsMkJBQVEsQ0FBQyxrQkFBa0IsRUFBRTtvQkFDM0IscUJBQUUsQ0FBQywwQkFBMEIsRUFBRTt3QkFDN0IsSUFBSSxDQUFDLEdBQUcsSUFBSSxzREFBNEIsRUFBRSxDQUFDO3dCQUMzQyx5QkFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQzt3QkFDcEMseUJBQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7d0JBQ2hELHlCQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO3dCQUNsQyx5QkFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFDdkMsQ0FBQyxDQUFDLENBQUM7b0JBRUgscUJBQUUsQ0FBQyxpQ0FBaUMsRUFBRTt3QkFDcEMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO3dCQUNYLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRWhCLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUM7d0JBQ2IsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7NkJBQ3BCLE9BQU8sQ0FBQyx3QkFBaUIsQ0FBQyxFQUFDLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFFLFNBQVMsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUVsRixDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDO3dCQUNiLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDOzZCQUNwQixPQUFPLENBQUMsd0JBQWlCLENBQ3RCLEVBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLFlBQVksQ0FBQyxFQUFFLFFBQVEsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLFNBQVMsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUVqRixDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDO3dCQUNkLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUM7d0JBQ2IsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7NkJBQ3BCLE9BQU8sQ0FBQyx3QkFBaUIsQ0FBQzs0QkFDekIsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLFVBQVUsRUFBRSxZQUFZLENBQUM7NEJBQ3BDLFFBQVEsRUFBRSxDQUFDLEdBQUcsRUFBRSxVQUFVLENBQUM7NEJBQzNCLFNBQVMsRUFBRSxDQUFDLFlBQVksQ0FBQzs0QkFDekIsT0FBTyxFQUFFLENBQUMsVUFBVSxDQUFDO3lCQUN0QixDQUFDLENBQUMsQ0FBQzt3QkFFUixDQUFDLEdBQUcsRUFBRSxDQUFDO3dCQUNQLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUM7d0JBQ2IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQzt3QkFDYixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNoQix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQzs2QkFDcEIsT0FBTyxDQUFDLHdCQUFpQixDQUFDOzRCQUN6QixHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDOzRCQUNmLFFBQVEsRUFBRSxDQUFDLEdBQUcsRUFBRSxhQUFhLEVBQUUsR0FBRyxDQUFDOzRCQUNuQyxRQUFRLEVBQUUsQ0FBQyxhQUFhLENBQUM7eUJBQzFCLENBQUMsQ0FBQyxDQUFDO3dCQUVSLENBQUMsR0FBRyxFQUFFLENBQUM7d0JBQ1AsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDaEIseUJBQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7NkJBQ3BCLE9BQU8sQ0FBQyx3QkFBaUIsQ0FBQzs0QkFDekIsUUFBUSxFQUFFLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQzs0QkFDdEMsUUFBUSxFQUFFLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQzt5QkFDdkMsQ0FBQyxDQUFDLENBQUM7b0JBQ1YsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsMkJBQVEsQ0FBQyxNQUFNLEVBQUU7b0JBQ2YscUJBQUUsQ0FBQywyQ0FBMkMsRUFBRTt3QkFDOUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7d0JBQ2hCLHlCQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDdEMsQ0FBQyxDQUFDLENBQUM7b0JBRUgscUJBQUUsQ0FBQyw0Q0FBNEMsRUFBRTt3QkFDL0MsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7d0JBQ2hCLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ2YseUJBQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUN2QyxDQUFDLENBQUMsQ0FBQztvQkFFSCxxQkFBRSxDQUFDLG9DQUFvQyxFQUFFO3dCQUN2QyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQzt3QkFDaEIsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDZix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7NkJBQy9CLE9BQU8sQ0FBQyx3QkFBaUIsQ0FBQyxFQUFDLFFBQVEsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFFLFFBQVEsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO29CQUN4RixDQUFDLENBQUMsQ0FBQztvQkFFSCxxQkFBRSxDQUFDLCtDQUErQyxFQUFFO3dCQUNsRCx5QkFBTSxDQUFDLGNBQU0sT0FBQSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUF0QixDQUFzQixDQUFDLENBQUMsZ0JBQWdCLENBQUMsZ0NBQWdDLENBQUMsQ0FBQztvQkFDMUYsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBL01lLFlBQUksT0ErTW5CLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBkZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICBpdCxcbiAgaWl0LFxuICB4aXQsXG4gIGV4cGVjdCxcbiAgYmVmb3JlRWFjaCxcbiAgYWZ0ZXJFYWNoXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuaW1wb3J0IHtcbiAgRGVmYXVsdEtleVZhbHVlRGlmZmVyLFxuICBEZWZhdWx0S2V5VmFsdWVEaWZmZXJGYWN0b3J5XG59IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2NoYW5nZV9kZXRlY3Rpb24vZGlmZmVycy9kZWZhdWx0X2tleXZhbHVlX2RpZmZlcic7XG5pbXBvcnQge051bWJlcldyYXBwZXIsIGlzSnNPYmplY3R9IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvbGFuZyc7XG5pbXBvcnQge2t2Q2hhbmdlc0FzU3RyaW5nfSBmcm9tICcuLi8uLi8uLi9jb3JlL2NoYW5nZV9kZXRlY3Rpb24vdXRpbCc7XG5cbi8vIHRvZG8odmljYik6IFVwZGF0ZSB0aGUgY29kZSAmIHRlc3RzIGZvciBvYmplY3QgZXF1YWxpdHlcbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgna2V5dmFsdWUgZGlmZmVyJywgZnVuY3Rpb24oKSB7XG4gICAgZGVzY3JpYmUoJ0RlZmF1bHRLZXlWYWx1ZURpZmZlcicsIGZ1bmN0aW9uKCkge1xuICAgICAgdmFyIGRpZmZlcjtcbiAgICAgIHZhciBtOiBNYXA8YW55LCBhbnk+O1xuXG4gICAgICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICAgICAgZGlmZmVyID0gbmV3IERlZmF1bHRLZXlWYWx1ZURpZmZlcigpO1xuICAgICAgICBtID0gbmV3IE1hcCgpO1xuICAgICAgfSk7XG5cbiAgICAgIGFmdGVyRWFjaCgoKSA9PiB7IGRpZmZlciA9IG51bGw7IH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIGRldGVjdCBhZGRpdGlvbnMnLCAoKSA9PiB7XG4gICAgICAgIGRpZmZlci5jaGVjayhtKTtcblxuICAgICAgICBtLnNldCgnYScsIDEpO1xuICAgICAgICBkaWZmZXIuY2hlY2sobSk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGt2Q2hhbmdlc0FzU3RyaW5nKHttYXA6IFsnYVtudWxsLT4xXSddLCBhZGRpdGlvbnM6IFsnYVtudWxsLT4xXSddfSkpO1xuXG4gICAgICAgIG0uc2V0KCdiJywgMik7XG4gICAgICAgIGRpZmZlci5jaGVjayhtKTtcbiAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgLnRvRXF1YWwoa3ZDaGFuZ2VzQXNTdHJpbmcoXG4gICAgICAgICAgICAgICAge21hcDogWydhJywgJ2JbbnVsbC0+Ml0nXSwgcHJldmlvdXM6IFsnYSddLCBhZGRpdGlvbnM6IFsnYltudWxsLT4yXSddfSkpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgaGFuZGxlIGNoYW5naW5nIGtleS92YWx1ZXMgY29ycmVjdGx5JywgKCkgPT4ge1xuICAgICAgICBtLnNldCgxLCAxMCk7XG4gICAgICAgIG0uc2V0KDIsIDIwKTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKG0pO1xuXG4gICAgICAgIG0uc2V0KDIsIDEwKTtcbiAgICAgICAgbS5zZXQoMSwgMjApO1xuICAgICAgICBkaWZmZXIuY2hlY2sobSk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGt2Q2hhbmdlc0FzU3RyaW5nKHtcbiAgICAgICAgICAgICAgbWFwOiBbJzFbMTAtPjIwXScsICcyWzIwLT4xMF0nXSxcbiAgICAgICAgICAgICAgcHJldmlvdXM6IFsnMVsxMC0+MjBdJywgJzJbMjAtPjEwXSddLFxuICAgICAgICAgICAgICBjaGFuZ2VzOiBbJzFbMTAtPjIwXScsICcyWzIwLT4xMF0nXVxuICAgICAgICAgICAgfSkpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgZXhwb3NlIHByZXZpb3VzIGFuZCBjdXJyZW50IHZhbHVlJywgKCkgPT4ge1xuICAgICAgICB2YXIgcHJldmlvdXMsIGN1cnJlbnQ7XG5cbiAgICAgICAgbS5zZXQoMSwgMTApO1xuICAgICAgICBkaWZmZXIuY2hlY2sobSk7XG5cbiAgICAgICAgbS5zZXQoMSwgMjApO1xuICAgICAgICBkaWZmZXIuY2hlY2sobSk7XG5cbiAgICAgICAgZGlmZmVyLmZvckVhY2hDaGFuZ2VkSXRlbSgocmVjb3JkKSA9PiB7XG4gICAgICAgICAgcHJldmlvdXMgPSByZWNvcmQucHJldmlvdXNWYWx1ZTtcbiAgICAgICAgICBjdXJyZW50ID0gcmVjb3JkLmN1cnJlbnRWYWx1ZTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgZXhwZWN0KHByZXZpb3VzKS50b0VxdWFsKDEwKTtcbiAgICAgICAgZXhwZWN0KGN1cnJlbnQpLnRvRXF1YWwoMjApO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgZG8gYmFzaWMgbWFwIHdhdGNoaW5nJywgKCkgPT4ge1xuICAgICAgICBkaWZmZXIuY2hlY2sobSk7XG5cbiAgICAgICAgbS5zZXQoJ2EnLCAnQScpO1xuICAgICAgICBkaWZmZXIuY2hlY2sobSk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGt2Q2hhbmdlc0FzU3RyaW5nKHttYXA6IFsnYVtudWxsLT5BXSddLCBhZGRpdGlvbnM6IFsnYVtudWxsLT5BXSddfSkpO1xuXG4gICAgICAgIG0uc2V0KCdiJywgJ0InKTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKG0pO1xuICAgICAgICBleHBlY3QoZGlmZmVyLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAudG9FcXVhbChrdkNoYW5nZXNBc1N0cmluZyhcbiAgICAgICAgICAgICAgICB7bWFwOiBbJ2EnLCAnYltudWxsLT5CXSddLCBwcmV2aW91czogWydhJ10sIGFkZGl0aW9uczogWydiW251bGwtPkJdJ119KSk7XG5cbiAgICAgICAgbS5zZXQoJ2InLCAnQkInKTtcbiAgICAgICAgbS5zZXQoJ2QnLCAnRCcpO1xuICAgICAgICBkaWZmZXIuY2hlY2sobSk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGt2Q2hhbmdlc0FzU3RyaW5nKHtcbiAgICAgICAgICAgICAgbWFwOiBbJ2EnLCAnYltCLT5CQl0nLCAnZFtudWxsLT5EXSddLFxuICAgICAgICAgICAgICBwcmV2aW91czogWydhJywgJ2JbQi0+QkJdJ10sXG4gICAgICAgICAgICAgIGFkZGl0aW9uczogWydkW251bGwtPkRdJ10sXG4gICAgICAgICAgICAgIGNoYW5nZXM6IFsnYltCLT5CQl0nXVxuICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIG0uZGVsZXRlKCdiJyk7XG4gICAgICAgIGRpZmZlci5jaGVjayhtKTtcbiAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgLnRvRXF1YWwoa3ZDaGFuZ2VzQXNTdHJpbmcoXG4gICAgICAgICAgICAgICAge21hcDogWydhJywgJ2QnXSwgcHJldmlvdXM6IFsnYScsICdiW0JCLT5udWxsXScsICdkJ10sIHJlbW92YWxzOiBbJ2JbQkItPm51bGxdJ119KSk7XG5cbiAgICAgICAgbS5jbGVhcigpO1xuICAgICAgICBkaWZmZXIuY2hlY2sobSk7XG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgIC50b0VxdWFsKGt2Q2hhbmdlc0FzU3RyaW5nKFxuICAgICAgICAgICAgICAgIHtwcmV2aW91czogWydhW0EtPm51bGxdJywgJ2RbRC0+bnVsbF0nXSwgcmVtb3ZhbHM6IFsnYVtBLT5udWxsXScsICdkW0QtPm51bGxdJ119KSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCB0ZXN0IHN0cmluZyBieSB2YWx1ZSByYXRoZXIgdGhhbiBieSByZWZlcmVuY2UgKERBUlQpJywgKCkgPT4ge1xuICAgICAgICBtLnNldCgnZm9vJywgJ2JhcicpO1xuICAgICAgICBkaWZmZXIuY2hlY2sobSk7XG5cbiAgICAgICAgdmFyIGYgPSAnZic7XG4gICAgICAgIHZhciBvbyA9ICdvbyc7XG4gICAgICAgIHZhciBiID0gJ2InO1xuICAgICAgICB2YXIgYXIgPSAnYXInO1xuXG4gICAgICAgIG0uc2V0KGYgKyBvbywgYiArIGFyKTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKG0pO1xuXG4gICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSkudG9FcXVhbChrdkNoYW5nZXNBc1N0cmluZyh7bWFwOiBbJ2ZvbyddLCBwcmV2aW91czogWydmb28nXX0pKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIG5vdCBzZWUgYSBOYU4gdmFsdWUgYXMgYSBjaGFuZ2UgKEpTKScsICgpID0+IHtcbiAgICAgICAgbS5zZXQoJ2ZvbycsIE51bWJlcldyYXBwZXIuTmFOKTtcbiAgICAgICAgZGlmZmVyLmNoZWNrKG0pO1xuXG4gICAgICAgIGRpZmZlci5jaGVjayhtKTtcbiAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKS50b0VxdWFsKGt2Q2hhbmdlc0FzU3RyaW5nKHttYXA6IFsnZm9vJ10sIHByZXZpb3VzOiBbJ2ZvbyddfSkpO1xuICAgICAgfSk7XG5cbiAgICAgIC8vIEpTIHNwZWNpZmljIHRlc3RzIChKUyBPYmplY3RzKVxuICAgICAgaWYgKGlzSnNPYmplY3Qoe30pKSB7XG4gICAgICAgIGRlc2NyaWJlKCdKc09iamVjdCBjaGFuZ2VzJywgKCkgPT4ge1xuICAgICAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCBKUyBPYmplY3QnLCAoKSA9PiB7XG4gICAgICAgICAgICB2YXIgZiA9IG5ldyBEZWZhdWx0S2V5VmFsdWVEaWZmZXJGYWN0b3J5KCk7XG4gICAgICAgICAgICBleHBlY3QoZi5zdXBwb3J0cyh7fSkpLnRvQmVUcnV0aHkoKTtcbiAgICAgICAgICAgIGV4cGVjdChmLnN1cHBvcnRzKFwibm90IHN1cHBvcnRlZFwiKSkudG9CZUZhbHN5KCk7XG4gICAgICAgICAgICBleHBlY3QoZi5zdXBwb3J0cygwKSkudG9CZUZhbHN5KCk7XG4gICAgICAgICAgICBleHBlY3QoZi5zdXBwb3J0cyhudWxsKSkudG9CZUZhbHN5KCk7XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBpdCgnc2hvdWxkIGRvIGJhc2ljIG9iamVjdCB3YXRjaGluZycsICgpID0+IHtcbiAgICAgICAgICAgIGxldCBtID0ge307XG4gICAgICAgICAgICBkaWZmZXIuY2hlY2sobSk7XG5cbiAgICAgICAgICAgIG1bJ2EnXSA9ICdBJztcbiAgICAgICAgICAgIGRpZmZlci5jaGVjayhtKTtcbiAgICAgICAgICAgIGV4cGVjdChkaWZmZXIudG9TdHJpbmcoKSlcbiAgICAgICAgICAgICAgICAudG9FcXVhbChrdkNoYW5nZXNBc1N0cmluZyh7bWFwOiBbJ2FbbnVsbC0+QV0nXSwgYWRkaXRpb25zOiBbJ2FbbnVsbC0+QV0nXX0pKTtcblxuICAgICAgICAgICAgbVsnYiddID0gJ0InO1xuICAgICAgICAgICAgZGlmZmVyLmNoZWNrKG0pO1xuICAgICAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgICAgIC50b0VxdWFsKGt2Q2hhbmdlc0FzU3RyaW5nKFxuICAgICAgICAgICAgICAgICAgICB7bWFwOiBbJ2EnLCAnYltudWxsLT5CXSddLCBwcmV2aW91czogWydhJ10sIGFkZGl0aW9uczogWydiW251bGwtPkJdJ119KSk7XG5cbiAgICAgICAgICAgIG1bJ2InXSA9ICdCQic7XG4gICAgICAgICAgICBtWydkJ10gPSAnRCc7XG4gICAgICAgICAgICBkaWZmZXIuY2hlY2sobSk7XG4gICAgICAgICAgICBleHBlY3QoZGlmZmVyLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAgICAgLnRvRXF1YWwoa3ZDaGFuZ2VzQXNTdHJpbmcoe1xuICAgICAgICAgICAgICAgICAgbWFwOiBbJ2EnLCAnYltCLT5CQl0nLCAnZFtudWxsLT5EXSddLFxuICAgICAgICAgICAgICAgICAgcHJldmlvdXM6IFsnYScsICdiW0ItPkJCXSddLFxuICAgICAgICAgICAgICAgICAgYWRkaXRpb25zOiBbJ2RbbnVsbC0+RF0nXSxcbiAgICAgICAgICAgICAgICAgIGNoYW5nZXM6IFsnYltCLT5CQl0nXVxuICAgICAgICAgICAgICAgIH0pKTtcblxuICAgICAgICAgICAgbSA9IHt9O1xuICAgICAgICAgICAgbVsnYSddID0gJ0EnO1xuICAgICAgICAgICAgbVsnZCddID0gJ0QnO1xuICAgICAgICAgICAgZGlmZmVyLmNoZWNrKG0pO1xuICAgICAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgICAgIC50b0VxdWFsKGt2Q2hhbmdlc0FzU3RyaW5nKHtcbiAgICAgICAgICAgICAgICAgIG1hcDogWydhJywgJ2QnXSxcbiAgICAgICAgICAgICAgICAgIHByZXZpb3VzOiBbJ2EnLCAnYltCQi0+bnVsbF0nLCAnZCddLFxuICAgICAgICAgICAgICAgICAgcmVtb3ZhbHM6IFsnYltCQi0+bnVsbF0nXVxuICAgICAgICAgICAgICAgIH0pKTtcblxuICAgICAgICAgICAgbSA9IHt9O1xuICAgICAgICAgICAgZGlmZmVyLmNoZWNrKG0pO1xuICAgICAgICAgICAgZXhwZWN0KGRpZmZlci50b1N0cmluZygpKVxuICAgICAgICAgICAgICAgIC50b0VxdWFsKGt2Q2hhbmdlc0FzU3RyaW5nKHtcbiAgICAgICAgICAgICAgICAgIHByZXZpb3VzOiBbJ2FbQS0+bnVsbF0nLCAnZFtELT5udWxsXSddLFxuICAgICAgICAgICAgICAgICAgcmVtb3ZhbHM6IFsnYVtBLT5udWxsXScsICdkW0QtPm51bGxdJ11cbiAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGRlc2NyaWJlKCdkaWZmJywgKCkgPT4ge1xuICAgICAgICAgIGl0KCdzaG91bGQgcmV0dXJuIHNlbGYgd2hlbiB0aGVyZSBpcyBhIGNoYW5nZScsICgpID0+IHtcbiAgICAgICAgICAgIG0uc2V0KCdhJywgJ0EnKTtcbiAgICAgICAgICAgIGV4cGVjdChkaWZmZXIuZGlmZihtKSkudG9CZShkaWZmZXIpO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgaXQoJ3Nob3VsZCByZXR1cm4gbnVsbCB3aGVuIHRoZXJlIGlzIG5vIGNoYW5nZScsICgpID0+IHtcbiAgICAgICAgICAgIG0uc2V0KCdhJywgJ0EnKTtcbiAgICAgICAgICAgIGRpZmZlci5kaWZmKG0pO1xuICAgICAgICAgICAgZXhwZWN0KGRpZmZlci5kaWZmKG0pKS50b0VxdWFsKG51bGwpO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgaXQoJ3Nob3VsZCB0cmVhdCBudWxsIGFzIGFuIGVtcHR5IGxpc3QnLCAoKSA9PiB7XG4gICAgICAgICAgICBtLnNldCgnYScsICdBJyk7XG4gICAgICAgICAgICBkaWZmZXIuZGlmZihtKTtcbiAgICAgICAgICAgIGV4cGVjdChkaWZmZXIuZGlmZihudWxsKS50b1N0cmluZygpKVxuICAgICAgICAgICAgICAgIC50b0VxdWFsKGt2Q2hhbmdlc0FzU3RyaW5nKHtwcmV2aW91czogWydhW0EtPm51bGxdJ10sIHJlbW92YWxzOiBbJ2FbQS0+bnVsbF0nXX0pKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KCdzaG91bGQgdGhyb3cgd2hlbiBnaXZlbiBhbiBpbnZhbGlkIGNvbGxlY3Rpb24nLCAoKSA9PiB7XG4gICAgICAgICAgICBleHBlY3QoKCkgPT4gZGlmZmVyLmRpZmYoXCJpbnZhbGlkXCIpKS50b1Rocm93RXJyb3JXaXRoKFwiRXJyb3IgdHJ5aW5nIHRvIGRpZmYgJ2ludmFsaWQnXCIpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG59XG4iXX0=
 main(); 
