'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var spies_1 = require('../../spies');
var iterable_differs_1 = require('angular2/src/core/change_detection/differs/iterable_differs');
var core_1 = require('angular2/core');
function main() {
    testing_internal_1.describe('IterableDiffers', function () {
        var factory1;
        var factory2;
        var factory3;
        testing_internal_1.beforeEach(function () {
            factory1 = new spies_1.SpyIterableDifferFactory();
            factory2 = new spies_1.SpyIterableDifferFactory();
            factory3 = new spies_1.SpyIterableDifferFactory();
        });
        testing_internal_1.it('should throw when no suitable implementation found', function () {
            var differs = new iterable_differs_1.IterableDiffers([]);
            testing_internal_1.expect(function () { return differs.find("some object"); })
                .toThrowErrorWith("Cannot find a differ supporting object 'some object'");
        });
        testing_internal_1.it('should return the first suitable implementation', function () {
            factory1.spy("supports").andReturn(false);
            factory2.spy("supports").andReturn(true);
            factory3.spy("supports").andReturn(true);
            var differs = iterable_differs_1.IterableDiffers.create([factory1, factory2, factory3]);
            testing_internal_1.expect(differs.find("some object")).toBe(factory2);
        });
        testing_internal_1.it('should copy over differs from the parent repo', function () {
            factory1.spy("supports").andReturn(true);
            factory2.spy("supports").andReturn(false);
            var parent = iterable_differs_1.IterableDiffers.create([factory1]);
            var child = iterable_differs_1.IterableDiffers.create([factory2], parent);
            testing_internal_1.expect(child.factories).toEqual([factory2, factory1]);
        });
        testing_internal_1.describe(".extend()", function () {
            testing_internal_1.it('should throw if calling extend when creating root injector', function () {
                var injector = core_1.Injector.resolveAndCreate([iterable_differs_1.IterableDiffers.extend([])]);
                testing_internal_1.expect(function () { return injector.get(iterable_differs_1.IterableDiffers); })
                    .toThrowErrorWith("Cannot extend IterableDiffers without a parent injector");
            });
            testing_internal_1.it('should extend di-inherited diffesr', function () {
                var parent = new iterable_differs_1.IterableDiffers([factory1]);
                var injector = core_1.Injector.resolveAndCreate([core_1.provide(iterable_differs_1.IterableDiffers, { useValue: parent })]);
                var childInjector = injector.resolveAndCreateChild([iterable_differs_1.IterableDiffers.extend([factory2])]);
                testing_internal_1.expect(injector.get(iterable_differs_1.IterableDiffers).factories).toEqual([factory1]);
                testing_internal_1.expect(childInjector.get(iterable_differs_1.IterableDiffers).factories).toEqual([factory2, factory1]);
            });
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXRlcmFibGVfZGlmZmVyc19zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb3JlL2NoYW5nZV9kZXRlY3Rpb24vZGlmZmVycy9pdGVyYWJsZV9kaWZmZXJzX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiJdLCJtYXBwaW5ncyI6IkFBQUEsaUNBU08sMkJBQTJCLENBQUMsQ0FBQTtBQUNuQyxzQkFBdUMsYUFBYSxDQUFDLENBQUE7QUFDckQsaUNBQThCLDZEQUE2RCxDQUFDLENBQUE7QUFDNUYscUJBQWdDLGVBQWUsQ0FBQyxDQUFBO0FBRWhEO0lBQ0VBLDJCQUFRQSxDQUFDQSxpQkFBaUJBLEVBQUVBO1FBQzFCLElBQUksUUFBUSxDQUFDO1FBQ2IsSUFBSSxRQUFRLENBQUM7UUFDYixJQUFJLFFBQVEsQ0FBQztRQUViLDZCQUFVLENBQUM7WUFDVCxRQUFRLEdBQUcsSUFBSSxnQ0FBd0IsRUFBRSxDQUFDO1lBQzFDLFFBQVEsR0FBRyxJQUFJLGdDQUF3QixFQUFFLENBQUM7WUFDMUMsUUFBUSxHQUFHLElBQUksZ0NBQXdCLEVBQUUsQ0FBQztRQUM1QyxDQUFDLENBQUMsQ0FBQztRQUVILHFCQUFFLENBQUMsb0RBQW9ELEVBQUU7WUFDdkQsSUFBSSxPQUFPLEdBQUcsSUFBSSxrQ0FBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3RDLHlCQUFNLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQTNCLENBQTJCLENBQUM7aUJBQ3BDLGdCQUFnQixDQUFDLHNEQUFzRCxDQUFDLENBQUE7UUFDL0UsQ0FBQyxDQUFDLENBQUM7UUFFSCxxQkFBRSxDQUFDLGlEQUFpRCxFQUFFO1lBQ3BELFFBQVEsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3pDLFFBQVEsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRXpDLElBQUksT0FBTyxHQUFHLGtDQUFlLENBQUMsTUFBTSxDQUFNLENBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBQzFFLHlCQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNyRCxDQUFDLENBQUMsQ0FBQztRQUVILHFCQUFFLENBQUMsK0NBQStDLEVBQUU7WUFDbEQsUUFBUSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDekMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFMUMsSUFBSSxNQUFNLEdBQUcsa0NBQWUsQ0FBQyxNQUFNLENBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBQ3JELElBQUksS0FBSyxHQUFHLGtDQUFlLENBQUMsTUFBTSxDQUFNLENBQUMsUUFBUSxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFNUQseUJBQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDeEQsQ0FBQyxDQUFDLENBQUM7UUFFSCwyQkFBUSxDQUFDLFdBQVcsRUFBRTtZQUNwQixxQkFBRSxDQUFDLDREQUE0RCxFQUFFO2dCQUMvRCxJQUFJLFFBQVEsR0FBRyxlQUFRLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxrQ0FBZSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRXZFLHlCQUFNLENBQUMsY0FBTSxPQUFBLFFBQVEsQ0FBQyxHQUFHLENBQUMsa0NBQWUsQ0FBQyxFQUE3QixDQUE2QixDQUFDO3FCQUN0QyxnQkFBZ0IsQ0FBQyx5REFBeUQsQ0FBQyxDQUFDO1lBQ25GLENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQyxvQ0FBb0MsRUFBRTtnQkFDdkMsSUFBSSxNQUFNLEdBQUcsSUFBSSxrQ0FBZSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztnQkFDN0MsSUFBSSxRQUFRLEdBQUcsZUFBUSxDQUFDLGdCQUFnQixDQUFDLENBQUMsY0FBTyxDQUFDLGtDQUFlLEVBQUUsRUFBQyxRQUFRLEVBQUUsTUFBTSxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3pGLElBQUksYUFBYSxHQUFHLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLGtDQUFlLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRXpGLHlCQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxrQ0FBZSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztnQkFDcEUseUJBQU0sQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLGtDQUFlLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUNyRixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQXZEZSxZQUFJLE9BdURuQixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgZGRlc2NyaWJlLFxuICBkZXNjcmliZSxcbiAgaXQsXG4gIGlpdCxcbiAgeGl0LFxuICBleHBlY3QsXG4gIGJlZm9yZUVhY2gsXG4gIGFmdGVyRWFjaFxufSBmcm9tICdhbmd1bGFyMi90ZXN0aW5nX2ludGVybmFsJztcbmltcG9ydCB7U3B5SXRlcmFibGVEaWZmZXJGYWN0b3J5fSBmcm9tICcuLi8uLi9zcGllcyc7XG5pbXBvcnQge0l0ZXJhYmxlRGlmZmVyc30gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvY2hhbmdlX2RldGVjdGlvbi9kaWZmZXJzL2l0ZXJhYmxlX2RpZmZlcnMnO1xuaW1wb3J0IHtJbmplY3RvciwgcHJvdmlkZX0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgnSXRlcmFibGVEaWZmZXJzJywgZnVuY3Rpb24oKSB7XG4gICAgdmFyIGZhY3RvcnkxO1xuICAgIHZhciBmYWN0b3J5MjtcbiAgICB2YXIgZmFjdG9yeTM7XG5cbiAgICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICAgIGZhY3RvcnkxID0gbmV3IFNweUl0ZXJhYmxlRGlmZmVyRmFjdG9yeSgpO1xuICAgICAgZmFjdG9yeTIgPSBuZXcgU3B5SXRlcmFibGVEaWZmZXJGYWN0b3J5KCk7XG4gICAgICBmYWN0b3J5MyA9IG5ldyBTcHlJdGVyYWJsZURpZmZlckZhY3RvcnkoKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgdGhyb3cgd2hlbiBubyBzdWl0YWJsZSBpbXBsZW1lbnRhdGlvbiBmb3VuZCcsICgpID0+IHtcbiAgICAgIHZhciBkaWZmZXJzID0gbmV3IEl0ZXJhYmxlRGlmZmVycyhbXSk7XG4gICAgICBleHBlY3QoKCkgPT4gZGlmZmVycy5maW5kKFwic29tZSBvYmplY3RcIikpXG4gICAgICAgICAgLnRvVGhyb3dFcnJvcldpdGgoXCJDYW5ub3QgZmluZCBhIGRpZmZlciBzdXBwb3J0aW5nIG9iamVjdCAnc29tZSBvYmplY3QnXCIpXG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIHJldHVybiB0aGUgZmlyc3Qgc3VpdGFibGUgaW1wbGVtZW50YXRpb24nLCAoKSA9PiB7XG4gICAgICBmYWN0b3J5MS5zcHkoXCJzdXBwb3J0c1wiKS5hbmRSZXR1cm4oZmFsc2UpO1xuICAgICAgZmFjdG9yeTIuc3B5KFwic3VwcG9ydHNcIikuYW5kUmV0dXJuKHRydWUpO1xuICAgICAgZmFjdG9yeTMuc3B5KFwic3VwcG9ydHNcIikuYW5kUmV0dXJuKHRydWUpO1xuXG4gICAgICB2YXIgZGlmZmVycyA9IEl0ZXJhYmxlRGlmZmVycy5jcmVhdGUoPGFueT5bZmFjdG9yeTEsIGZhY3RvcnkyLCBmYWN0b3J5M10pO1xuICAgICAgZXhwZWN0KGRpZmZlcnMuZmluZChcInNvbWUgb2JqZWN0XCIpKS50b0JlKGZhY3RvcnkyKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgY29weSBvdmVyIGRpZmZlcnMgZnJvbSB0aGUgcGFyZW50IHJlcG8nLCAoKSA9PiB7XG4gICAgICBmYWN0b3J5MS5zcHkoXCJzdXBwb3J0c1wiKS5hbmRSZXR1cm4odHJ1ZSk7XG4gICAgICBmYWN0b3J5Mi5zcHkoXCJzdXBwb3J0c1wiKS5hbmRSZXR1cm4oZmFsc2UpO1xuXG4gICAgICB2YXIgcGFyZW50ID0gSXRlcmFibGVEaWZmZXJzLmNyZWF0ZSg8YW55PltmYWN0b3J5MV0pO1xuICAgICAgdmFyIGNoaWxkID0gSXRlcmFibGVEaWZmZXJzLmNyZWF0ZSg8YW55PltmYWN0b3J5Ml0sIHBhcmVudCk7XG5cbiAgICAgIGV4cGVjdChjaGlsZC5mYWN0b3JpZXMpLnRvRXF1YWwoW2ZhY3RvcnkyLCBmYWN0b3J5MV0pO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoXCIuZXh0ZW5kKClcIiwgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCB0aHJvdyBpZiBjYWxsaW5nIGV4dGVuZCB3aGVuIGNyZWF0aW5nIHJvb3QgaW5qZWN0b3InLCAoKSA9PiB7XG4gICAgICAgIHZhciBpbmplY3RvciA9IEluamVjdG9yLnJlc29sdmVBbmRDcmVhdGUoW0l0ZXJhYmxlRGlmZmVycy5leHRlbmQoW10pXSk7XG5cbiAgICAgICAgZXhwZWN0KCgpID0+IGluamVjdG9yLmdldChJdGVyYWJsZURpZmZlcnMpKVxuICAgICAgICAgICAgLnRvVGhyb3dFcnJvcldpdGgoXCJDYW5ub3QgZXh0ZW5kIEl0ZXJhYmxlRGlmZmVycyB3aXRob3V0IGEgcGFyZW50IGluamVjdG9yXCIpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgZXh0ZW5kIGRpLWluaGVyaXRlZCBkaWZmZXNyJywgKCkgPT4ge1xuICAgICAgICB2YXIgcGFyZW50ID0gbmV3IEl0ZXJhYmxlRGlmZmVycyhbZmFjdG9yeTFdKTtcbiAgICAgICAgdmFyIGluamVjdG9yID0gSW5qZWN0b3IucmVzb2x2ZUFuZENyZWF0ZShbcHJvdmlkZShJdGVyYWJsZURpZmZlcnMsIHt1c2VWYWx1ZTogcGFyZW50fSldKTtcbiAgICAgICAgdmFyIGNoaWxkSW5qZWN0b3IgPSBpbmplY3Rvci5yZXNvbHZlQW5kQ3JlYXRlQ2hpbGQoW0l0ZXJhYmxlRGlmZmVycy5leHRlbmQoW2ZhY3RvcnkyXSldKTtcblxuICAgICAgICBleHBlY3QoaW5qZWN0b3IuZ2V0KEl0ZXJhYmxlRGlmZmVycykuZmFjdG9yaWVzKS50b0VxdWFsKFtmYWN0b3J5MV0pO1xuICAgICAgICBleHBlY3QoY2hpbGRJbmplY3Rvci5nZXQoSXRlcmFibGVEaWZmZXJzKS5mYWN0b3JpZXMpLnRvRXF1YWwoW2ZhY3RvcnkyLCBmYWN0b3J5MV0pO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH0pO1xufVxuIl19
 main(); 
