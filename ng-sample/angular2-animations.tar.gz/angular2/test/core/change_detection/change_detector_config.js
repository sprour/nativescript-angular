'use strict';var collection_1 = require('angular2/src/facade/collection');
var lang_1 = require('angular2/src/facade/lang');
var change_detection_1 = require('angular2/src/core/change_detection/change_detection');
var reflection_1 = require('angular2/src/core/reflection/reflection');
var reflection_capabilities_1 = require('angular2/src/core/reflection/reflection_capabilities');
/*
 * This file defines `ChangeDetectorDefinition` objects which are used in the tests defined in
 * the change_detector_spec library. Please see that library for more information.
 */
var _parser = new change_detection_1.Parser(new change_detection_1.Lexer());
function _getParser() {
    reflection_1.reflector.reflectionCapabilities = new reflection_capabilities_1.ReflectionCapabilities();
    return _parser;
}
function _createBindingRecords(expression) {
    var ast = _getParser().parseBinding(expression, 'location');
    return [change_detection_1.BindingRecord.createForElementProperty(ast, 0, exports.PROP_NAME)];
}
function _createEventRecords(expression) {
    var eq = expression.indexOf("=");
    var eventName = expression.substring(1, eq - 1);
    var exp = expression.substring(eq + 2, expression.length - 1);
    var ast = _getParser().parseAction(exp, 'location');
    return [change_detection_1.BindingRecord.createForEvent(ast, eventName, 0)];
}
function _createHostEventRecords(expression, directiveRecord) {
    var parts = expression.split("=");
    var eventName = parts[0].substring(1, parts[0].length - 1);
    var exp = parts[1].substring(1, parts[1].length - 1);
    var ast = _getParser().parseAction(exp, 'location');
    return [change_detection_1.BindingRecord.createForHostEvent(ast, eventName, directiveRecord)];
}
function _convertLocalsToVariableBindings(locals) {
    var variableBindings = [];
    var loc = locals;
    while (lang_1.isPresent(loc) && lang_1.isPresent(loc.current)) {
        loc.current.forEach(function (v, k) { return variableBindings.push(k); });
        loc = loc.parent;
    }
    return variableBindings;
}
exports.PROP_NAME = 'propName';
/**
 * In this case, we expect `id` and `expression` to be the same string.
 */
function getDefinition(id) {
    var genConfig = new change_detection_1.ChangeDetectorGenConfig(true, true, true);
    var testDef = null;
    if (collection_1.StringMapWrapper.contains(_ExpressionWithLocals.availableDefinitions, id)) {
        var val = collection_1.StringMapWrapper.get(_ExpressionWithLocals.availableDefinitions, id);
        var cdDef = val.createChangeDetectorDefinition();
        cdDef.id = id;
        testDef = new TestDefinition(id, cdDef, val.locals);
    }
    else if (collection_1.StringMapWrapper.contains(_ExpressionWithMode.availableDefinitions, id)) {
        var val = collection_1.StringMapWrapper.get(_ExpressionWithMode.availableDefinitions, id);
        var cdDef = val.createChangeDetectorDefinition();
        cdDef.id = id;
        testDef = new TestDefinition(id, cdDef, null);
    }
    else if (collection_1.StringMapWrapper.contains(_DirectiveUpdating.availableDefinitions, id)) {
        var val = collection_1.StringMapWrapper.get(_DirectiveUpdating.availableDefinitions, id);
        var cdDef = val.createChangeDetectorDefinition();
        cdDef.id = id;
        testDef = new TestDefinition(id, cdDef, null);
    }
    else if (collection_1.ListWrapper.indexOf(_availableDefinitions, id) >= 0) {
        var strategy = null;
        var variableBindings = [];
        var eventRecords = _createBindingRecords(id);
        var directiveRecords = [];
        var cdDef = new change_detection_1.ChangeDetectorDefinition(id, strategy, variableBindings, eventRecords, [], directiveRecords, genConfig);
        testDef = new TestDefinition(id, cdDef, null);
    }
    else if (collection_1.ListWrapper.indexOf(_availableEventDefinitions, id) >= 0) {
        var eventRecords = _createEventRecords(id);
        var cdDef = new change_detection_1.ChangeDetectorDefinition(id, null, [], [], eventRecords, [], genConfig);
        testDef = new TestDefinition(id, cdDef, null);
    }
    else if (collection_1.ListWrapper.indexOf(_availableHostEventDefinitions, id) >= 0) {
        var eventRecords = _createHostEventRecords(id, _DirectiveUpdating.basicRecords[0]);
        var cdDef = new change_detection_1.ChangeDetectorDefinition(id, null, [], [], eventRecords, [_DirectiveUpdating.basicRecords[0], _DirectiveUpdating.basicRecords[1]], genConfig);
        testDef = new TestDefinition(id, cdDef, null);
    }
    else if (id == "updateElementProduction") {
        var genConfig = new change_detection_1.ChangeDetectorGenConfig(false, false, true);
        var records = _createBindingRecords("name");
        var cdDef = new change_detection_1.ChangeDetectorDefinition(id, null, [], records, [], [], genConfig);
        testDef = new TestDefinition(id, cdDef, null);
    }
    if (lang_1.isBlank(testDef)) {
        throw "No ChangeDetectorDefinition for " + id + " available. Please modify this file if necessary.";
    }
    return testDef;
}
exports.getDefinition = getDefinition;
var TestDefinition = (function () {
    function TestDefinition(id, cdDef, locals) {
        this.id = id;
        this.cdDef = cdDef;
        this.locals = locals;
    }
    return TestDefinition;
})();
exports.TestDefinition = TestDefinition;
/**
 * Get all available ChangeDetectorDefinition objects. Used to pre-generate Dart
 * `ChangeDetector` classes.
 */
function getAllDefinitions() {
    var allDefs = _availableDefinitions;
    allDefs = collection_1.ListWrapper.concat(allDefs, collection_1.StringMapWrapper.keys(_ExpressionWithLocals.availableDefinitions));
    allDefs = allDefs.concat(collection_1.StringMapWrapper.keys(_ExpressionWithMode.availableDefinitions));
    allDefs = allDefs.concat(collection_1.StringMapWrapper.keys(_DirectiveUpdating.availableDefinitions));
    allDefs = allDefs.concat(_availableEventDefinitions);
    allDefs = allDefs.concat(_availableHostEventDefinitions);
    allDefs = allDefs.concat(["updateElementProduction"]);
    return allDefs.map(getDefinition);
}
exports.getAllDefinitions = getAllDefinitions;
var _ExpressionWithLocals = (function () {
    function _ExpressionWithLocals(_expression, locals) {
        this._expression = _expression;
        this.locals = locals;
    }
    _ExpressionWithLocals.prototype.createChangeDetectorDefinition = function () {
        var strategy = null;
        var variableBindings = _convertLocalsToVariableBindings(this.locals);
        var bindingRecords = _createBindingRecords(this._expression);
        var directiveRecords = [];
        var genConfig = new change_detection_1.ChangeDetectorGenConfig(true, true, true);
        return new change_detection_1.ChangeDetectorDefinition('(empty id)', strategy, variableBindings, bindingRecords, [], directiveRecords, genConfig);
    };
    /**
     * Map from test id to _ExpressionWithLocals.
     * Tests in this map define an expression and local values which those expressions refer to.
     */
    _ExpressionWithLocals.availableDefinitions = {
        'valueFromLocals': new _ExpressionWithLocals('key', new change_detection_1.Locals(null, collection_1.MapWrapper.createFromPairs([['key', 'value']]))),
        'functionFromLocals': new _ExpressionWithLocals('key()', new change_detection_1.Locals(null, collection_1.MapWrapper.createFromPairs([['key', function () { return 'value'; }]]))),
        'nestedLocals': new _ExpressionWithLocals('key', new change_detection_1.Locals(new change_detection_1.Locals(null, collection_1.MapWrapper.createFromPairs([['key', 'value']])), new Map())),
        'fallbackLocals': new _ExpressionWithLocals('name', new change_detection_1.Locals(null, collection_1.MapWrapper.createFromPairs([['key', 'value']]))),
        'contextNestedPropertyWithLocals': new _ExpressionWithLocals('address.city', new change_detection_1.Locals(null, collection_1.MapWrapper.createFromPairs([['city', 'MTV']]))),
        'localPropertyWithSimilarContext': new _ExpressionWithLocals('city', new change_detection_1.Locals(null, collection_1.MapWrapper.createFromPairs([['city', 'MTV']])))
    };
    return _ExpressionWithLocals;
})();
var _ExpressionWithMode = (function () {
    function _ExpressionWithMode(_strategy, _withRecords, _withEvents) {
        this._strategy = _strategy;
        this._withRecords = _withRecords;
        this._withEvents = _withEvents;
    }
    _ExpressionWithMode.prototype.createChangeDetectorDefinition = function () {
        var variableBindings = [];
        var bindingRecords = [];
        var directiveRecords = [];
        var eventRecords = [];
        var dirRecordWithDefault = new change_detection_1.DirectiveRecord({
            directiveIndex: new change_detection_1.DirectiveIndex(0, 0),
            changeDetection: change_detection_1.ChangeDetectionStrategy.Default
        });
        var dirRecordWithOnPush = new change_detection_1.DirectiveRecord({
            directiveIndex: new change_detection_1.DirectiveIndex(0, 1),
            changeDetection: change_detection_1.ChangeDetectionStrategy.OnPush
        });
        if (this._withRecords) {
            var updateDirWithOnDefaultRecord = change_detection_1.BindingRecord.createForDirective(_getParser().parseBinding('42', 'location'), 'a', function (o, v) { return o.a = v; }, dirRecordWithDefault);
            var updateDirWithOnPushRecord = change_detection_1.BindingRecord.createForDirective(_getParser().parseBinding('42', 'location'), 'a', function (o, v) { return o.a = v; }, dirRecordWithOnPush);
            directiveRecords = [dirRecordWithDefault, dirRecordWithOnPush];
            bindingRecords = [updateDirWithOnDefaultRecord, updateDirWithOnPushRecord];
        }
        if (this._withEvents) {
            directiveRecords = [dirRecordWithDefault, dirRecordWithOnPush];
            eventRecords =
                collection_1.ListWrapper.concat(_createEventRecords("(event)='false'"), _createHostEventRecords("(host-event)='false'", dirRecordWithOnPush));
        }
        var genConfig = new change_detection_1.ChangeDetectorGenConfig(true, true, true);
        return new change_detection_1.ChangeDetectorDefinition('(empty id)', this._strategy, variableBindings, bindingRecords, eventRecords, directiveRecords, genConfig);
    };
    /**
     * Map from test id to _ExpressionWithMode.
     * Definitions in this map define conditions which allow testing various change detector modes.
     */
    _ExpressionWithMode.availableDefinitions = {
        'emptyUsingDefaultStrategy': new _ExpressionWithMode(change_detection_1.ChangeDetectionStrategy.Default, false, false),
        'emptyUsingOnPushStrategy': new _ExpressionWithMode(change_detection_1.ChangeDetectionStrategy.OnPush, false, false),
        'onPushRecordsUsingDefaultStrategy': new _ExpressionWithMode(change_detection_1.ChangeDetectionStrategy.Default, true, false),
        'onPushWithEvent': new _ExpressionWithMode(change_detection_1.ChangeDetectionStrategy.OnPush, false, true),
        'onPushWithHostEvent': new _ExpressionWithMode(change_detection_1.ChangeDetectionStrategy.OnPush, false, true)
    };
    return _ExpressionWithMode;
})();
var _DirectiveUpdating = (function () {
    function _DirectiveUpdating(_bindingRecords, _directiveRecords) {
        this._bindingRecords = _bindingRecords;
        this._directiveRecords = _directiveRecords;
    }
    _DirectiveUpdating.prototype.createChangeDetectorDefinition = function () {
        var strategy = null;
        var variableBindings = [];
        var genConfig = new change_detection_1.ChangeDetectorGenConfig(true, true, true);
        return new change_detection_1.ChangeDetectorDefinition('(empty id)', strategy, variableBindings, this._bindingRecords, [], this._directiveRecords, genConfig);
    };
    _DirectiveUpdating.updateA = function (expression, dirRecord) {
        return change_detection_1.BindingRecord.createForDirective(_getParser().parseBinding(expression, 'location'), 'a', function (o, v) { return o.a = v; }, dirRecord);
    };
    _DirectiveUpdating.updateB = function (expression, dirRecord) {
        return change_detection_1.BindingRecord.createForDirective(_getParser().parseBinding(expression, 'location'), 'b', function (o, v) { return o.b = v; }, dirRecord);
    };
    _DirectiveUpdating.basicRecords = [
        new change_detection_1.DirectiveRecord({
            directiveIndex: new change_detection_1.DirectiveIndex(0, 0),
            callOnChanges: true,
            callDoCheck: true,
            callOnInit: true,
            callAfterContentInit: true,
            callAfterContentChecked: true,
            callAfterViewInit: true,
            callAfterViewChecked: true,
            callOnDestroy: true,
            outputs: [['eventEmitter', 'host-event']]
        }),
        new change_detection_1.DirectiveRecord({
            directiveIndex: new change_detection_1.DirectiveIndex(0, 1),
            callOnChanges: true,
            callDoCheck: true,
            callOnInit: true,
            callAfterContentInit: true,
            callAfterContentChecked: true,
            callAfterViewInit: true,
            callAfterViewChecked: true,
            callOnDestroy: true,
            outputs: [['eventEmitter', 'host-event']]
        })
    ];
    _DirectiveUpdating.recordNoCallbacks = new change_detection_1.DirectiveRecord({
        directiveIndex: new change_detection_1.DirectiveIndex(0, 0),
        callOnChanges: false,
        callDoCheck: false,
        callOnInit: false,
        callAfterContentInit: false,
        callAfterContentChecked: false,
        callAfterViewInit: false,
        callAfterViewChecked: false
    });
    /**
     * Map from test id to _DirectiveUpdating.
     * Definitions in this map define definitions which allow testing directive updating.
     */
    _DirectiveUpdating.availableDefinitions = {
        'directNoDispatcher': new _DirectiveUpdating([_DirectiveUpdating.updateA('42', _DirectiveUpdating.basicRecords[0])], [_DirectiveUpdating.basicRecords[0]]),
        'groupChanges': new _DirectiveUpdating([
            _DirectiveUpdating.updateA('1', _DirectiveUpdating.basicRecords[0]),
            _DirectiveUpdating.updateB('2', _DirectiveUpdating.basicRecords[0]),
            change_detection_1.BindingRecord.createDirectiveOnChanges(_DirectiveUpdating.basicRecords[0]),
            _DirectiveUpdating.updateA('3', _DirectiveUpdating.basicRecords[1]),
            change_detection_1.BindingRecord.createDirectiveOnChanges(_DirectiveUpdating.basicRecords[1])
        ], [_DirectiveUpdating.basicRecords[0], _DirectiveUpdating.basicRecords[1]]),
        'directiveDoCheck': new _DirectiveUpdating([change_detection_1.BindingRecord.createDirectiveDoCheck(_DirectiveUpdating.basicRecords[0])], [_DirectiveUpdating.basicRecords[0]]),
        'directiveOnInit': new _DirectiveUpdating([change_detection_1.BindingRecord.createDirectiveOnInit(_DirectiveUpdating.basicRecords[0])], [_DirectiveUpdating.basicRecords[0]]),
        'emptyWithDirectiveRecords': new _DirectiveUpdating([], [_DirectiveUpdating.basicRecords[0], _DirectiveUpdating.basicRecords[1]]),
        'noCallbacks': new _DirectiveUpdating([_DirectiveUpdating.updateA('1', _DirectiveUpdating.recordNoCallbacks)], [_DirectiveUpdating.recordNoCallbacks]),
        'readingDirectives': new _DirectiveUpdating([
            change_detection_1.BindingRecord.createForHostProperty(new change_detection_1.DirectiveIndex(0, 0), _getParser().parseBinding('a', 'location'), exports.PROP_NAME)
        ], [_DirectiveUpdating.basicRecords[0]]),
        'interpolation': new _DirectiveUpdating([
            change_detection_1.BindingRecord.createForElementProperty(_getParser().parseInterpolation('B{{a}}A', 'location'), 0, exports.PROP_NAME)
        ], [])
    };
    return _DirectiveUpdating;
})();
/**
 * The list of all test definitions this config supplies.
 * Items in this list that do not appear in other structures define tests with expressions
 * equivalent to their ids.
 */
var _availableDefinitions = [
    '"$"',
    '10',
    '"str"',
    '"a\n\nb"',
    '10 + 2',
    '10 - 2',
    '10 * 2',
    '10 / 2',
    '11 % 2',
    '1 == 1',
    '1 != 1',
    '1 == true',
    '1 === 1',
    '1 !== 1',
    '1 === true',
    '1 < 2',
    '2 < 1',
    '1 > 2',
    '2 > 1',
    '1 <= 2',
    '2 <= 2',
    '2 <= 1',
    '2 >= 1',
    '2 >= 2',
    '1 >= 2',
    'true && true',
    'true && false',
    'true || false',
    'false || false',
    '!true',
    '!!true',
    '1 < 2 ? 1 : 2',
    '1 > 2 ? 1 : 2',
    '["foo", "bar"][0]',
    '{"foo": "bar"}["foo"]',
    'name',
    '[1, 2]',
    '[1, a]',
    '{z: 1}',
    '{z: a}',
    'name | pipe',
    '(name | pipe).length',
    "name | pipe:'one':address.city",
    "name | pipe:'a':'b' | pipe:0:1:2",
    'value',
    'a',
    'address.city',
    'address?.city',
    'address?.toString()',
    'sayHi("Jim")',
    'a()(99)',
    'a.sayHi("Jim")',
    'passThrough([12])',
    'invalidFn(1)',
    'age',
    'true ? city : zipcode',
    'false ? city : zipcode',
    'getTrue() && getTrue()',
    'getFalse() && getTrue()',
    'getFalse() || getFalse()',
    'getTrue() || getFalse()',
    'name == "Victor" ? (true ? address.city : address.zipcode) : address.zipcode'
];
var _availableEventDefinitions = [
    '(event)="onEvent(\$event)"',
    '(event)="b=a=\$event"',
    '(event)="a[0]=\$event"',
    // '(event)="\$event=1"',
    '(event)="a=a+1; a=a+1;"',
    '(event)="true; false"',
    '(event)="false"',
    '(event)="true"',
    '(event)="true ? a = a + 1 : a = a + 1"',
];
var _availableHostEventDefinitions = ['(host-event)="onEvent(\$event)"'];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hhbmdlX2RldGVjdG9yX2NvbmZpZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29yZS9jaGFuZ2VfZGV0ZWN0aW9uL2NoYW5nZV9kZXRlY3Rvcl9jb25maWcudHMiXSwibmFtZXMiOlsiX2dldFBhcnNlciIsIl9jcmVhdGVCaW5kaW5nUmVjb3JkcyIsIl9jcmVhdGVFdmVudFJlY29yZHMiLCJfY3JlYXRlSG9zdEV2ZW50UmVjb3JkcyIsIl9jb252ZXJ0TG9jYWxzVG9WYXJpYWJsZUJpbmRpbmdzIiwiZ2V0RGVmaW5pdGlvbiIsIlRlc3REZWZpbml0aW9uIiwiVGVzdERlZmluaXRpb24uY29uc3RydWN0b3IiLCJnZXRBbGxEZWZpbml0aW9ucyIsIl9FeHByZXNzaW9uV2l0aExvY2FscyIsIl9FeHByZXNzaW9uV2l0aExvY2Fscy5jb25zdHJ1Y3RvciIsIl9FeHByZXNzaW9uV2l0aExvY2Fscy5jcmVhdGVDaGFuZ2VEZXRlY3RvckRlZmluaXRpb24iLCJfRXhwcmVzc2lvbldpdGhNb2RlIiwiX0V4cHJlc3Npb25XaXRoTW9kZS5jb25zdHJ1Y3RvciIsIl9FeHByZXNzaW9uV2l0aE1vZGUuY3JlYXRlQ2hhbmdlRGV0ZWN0b3JEZWZpbml0aW9uIiwiX0RpcmVjdGl2ZVVwZGF0aW5nIiwiX0RpcmVjdGl2ZVVwZGF0aW5nLmNvbnN0cnVjdG9yIiwiX0RpcmVjdGl2ZVVwZGF0aW5nLmNyZWF0ZUNoYW5nZURldGVjdG9yRGVmaW5pdGlvbiIsIl9EaXJlY3RpdmVVcGRhdGluZy51cGRhdGVBIiwiX0RpcmVjdGl2ZVVwZGF0aW5nLnVwZGF0ZUIiXSwibWFwcGluZ3MiOiJBQUFBLDJCQUF3RCxnQ0FBZ0MsQ0FBQyxDQUFBO0FBQ3pGLHFCQUFpQywwQkFBMEIsQ0FBQyxDQUFBO0FBQzVELGlDQVVPLHFEQUFxRCxDQUFDLENBQUE7QUFDN0QsMkJBQXdCLHlDQUF5QyxDQUFDLENBQUE7QUFDbEUsd0NBQXFDLHNEQUFzRCxDQUFDLENBQUE7QUFFNUY7OztHQUdHO0FBRUgsSUFBSSxPQUFPLEdBQUcsSUFBSSx5QkFBTSxDQUFDLElBQUksd0JBQUssRUFBRSxDQUFDLENBQUM7QUFFdEM7SUFDRUEsc0JBQVNBLENBQUNBLHNCQUFzQkEsR0FBR0EsSUFBSUEsZ0RBQXNCQSxFQUFFQSxDQUFDQTtJQUNoRUEsTUFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0E7QUFDakJBLENBQUNBO0FBRUQsK0JBQStCLFVBQWtCO0lBQy9DQyxJQUFJQSxHQUFHQSxHQUFHQSxVQUFVQSxFQUFFQSxDQUFDQSxZQUFZQSxDQUFDQSxVQUFVQSxFQUFFQSxVQUFVQSxDQUFDQSxDQUFDQTtJQUM1REEsTUFBTUEsQ0FBQ0EsQ0FBQ0EsZ0NBQWFBLENBQUNBLHdCQUF3QkEsQ0FBQ0EsR0FBR0EsRUFBRUEsQ0FBQ0EsRUFBRUEsaUJBQVNBLENBQUNBLENBQUNBLENBQUNBO0FBQ3JFQSxDQUFDQTtBQUVELDZCQUE2QixVQUFrQjtJQUM3Q0MsSUFBSUEsRUFBRUEsR0FBR0EsVUFBVUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7SUFDakNBLElBQUlBLFNBQVNBLEdBQUdBLFVBQVVBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBLEVBQUVBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBO0lBQ2hEQSxJQUFJQSxHQUFHQSxHQUFHQSxVQUFVQSxDQUFDQSxTQUFTQSxDQUFDQSxFQUFFQSxHQUFHQSxDQUFDQSxFQUFFQSxVQUFVQSxDQUFDQSxNQUFNQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUM5REEsSUFBSUEsR0FBR0EsR0FBR0EsVUFBVUEsRUFBRUEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsR0FBR0EsRUFBRUEsVUFBVUEsQ0FBQ0EsQ0FBQ0E7SUFDcERBLE1BQU1BLENBQUNBLENBQUNBLGdDQUFhQSxDQUFDQSxjQUFjQSxDQUFDQSxHQUFHQSxFQUFFQSxTQUFTQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUMzREEsQ0FBQ0E7QUFFRCxpQ0FBaUMsVUFBa0IsRUFDbEIsZUFBZ0M7SUFDL0RDLElBQUlBLEtBQUtBLEdBQUdBLFVBQVVBLENBQUNBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO0lBQ2xDQSxJQUFJQSxTQUFTQSxHQUFHQSxLQUFLQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQSxFQUFFQSxLQUFLQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxNQUFNQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUMzREEsSUFBSUEsR0FBR0EsR0FBR0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFFckRBLElBQUlBLEdBQUdBLEdBQUdBLFVBQVVBLEVBQUVBLENBQUNBLFdBQVdBLENBQUNBLEdBQUdBLEVBQUVBLFVBQVVBLENBQUNBLENBQUNBO0lBQ3BEQSxNQUFNQSxDQUFDQSxDQUFDQSxnQ0FBYUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxHQUFHQSxFQUFFQSxTQUFTQSxFQUFFQSxlQUFlQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUM3RUEsQ0FBQ0E7QUFFRCwwQ0FBMEMsTUFBYztJQUN0REMsSUFBSUEsZ0JBQWdCQSxHQUFHQSxFQUFFQSxDQUFDQTtJQUMxQkEsSUFBSUEsR0FBR0EsR0FBR0EsTUFBTUEsQ0FBQ0E7SUFDakJBLE9BQU9BLGdCQUFTQSxDQUFDQSxHQUFHQSxDQUFDQSxJQUFJQSxnQkFBU0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsRUFBRUEsQ0FBQ0E7UUFDaERBLEdBQUdBLENBQUNBLE9BQU9BLENBQUNBLE9BQU9BLENBQUNBLFVBQUNBLENBQUNBLEVBQUVBLENBQUNBLElBQUtBLE9BQUFBLGdCQUFnQkEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBeEJBLENBQXdCQSxDQUFDQSxDQUFDQTtRQUN4REEsR0FBR0EsR0FBR0EsR0FBR0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7SUFDbkJBLENBQUNBO0lBQ0RBLE1BQU1BLENBQUNBLGdCQUFnQkEsQ0FBQ0E7QUFDMUJBLENBQUNBO0FBRVksaUJBQVMsR0FBRyxVQUFVLENBQUM7QUFFcEM7O0dBRUc7QUFDSCx1QkFBOEIsRUFBVTtJQUN0Q0MsSUFBSUEsU0FBU0EsR0FBR0EsSUFBSUEsMENBQXVCQSxDQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtJQUM5REEsSUFBSUEsT0FBT0EsR0FBR0EsSUFBSUEsQ0FBQ0E7SUFDbkJBLEVBQUVBLENBQUNBLENBQUNBLDZCQUFnQkEsQ0FBQ0EsUUFBUUEsQ0FBQ0EscUJBQXFCQSxDQUFDQSxvQkFBb0JBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQzlFQSxJQUFJQSxHQUFHQSxHQUFHQSw2QkFBZ0JBLENBQUNBLEdBQUdBLENBQUNBLHFCQUFxQkEsQ0FBQ0Esb0JBQW9CQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQTtRQUMvRUEsSUFBSUEsS0FBS0EsR0FBR0EsR0FBR0EsQ0FBQ0EsOEJBQThCQSxFQUFFQSxDQUFDQTtRQUNqREEsS0FBS0EsQ0FBQ0EsRUFBRUEsR0FBR0EsRUFBRUEsQ0FBQ0E7UUFDZEEsT0FBT0EsR0FBR0EsSUFBSUEsY0FBY0EsQ0FBQ0EsRUFBRUEsRUFBRUEsS0FBS0EsRUFBRUEsR0FBR0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7SUFFdERBLENBQUNBO0lBQUNBLElBQUlBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLDZCQUFnQkEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxvQkFBb0JBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ25GQSxJQUFJQSxHQUFHQSxHQUFHQSw2QkFBZ0JBLENBQUNBLEdBQUdBLENBQUNBLG1CQUFtQkEsQ0FBQ0Esb0JBQW9CQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQTtRQUM3RUEsSUFBSUEsS0FBS0EsR0FBR0EsR0FBR0EsQ0FBQ0EsOEJBQThCQSxFQUFFQSxDQUFDQTtRQUNqREEsS0FBS0EsQ0FBQ0EsRUFBRUEsR0FBR0EsRUFBRUEsQ0FBQ0E7UUFDZEEsT0FBT0EsR0FBR0EsSUFBSUEsY0FBY0EsQ0FBQ0EsRUFBRUEsRUFBRUEsS0FBS0EsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7SUFFaERBLENBQUNBO0lBQUNBLElBQUlBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLDZCQUFnQkEsQ0FBQ0EsUUFBUUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxvQkFBb0JBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ2xGQSxJQUFJQSxHQUFHQSxHQUFHQSw2QkFBZ0JBLENBQUNBLEdBQUdBLENBQUNBLGtCQUFrQkEsQ0FBQ0Esb0JBQW9CQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQTtRQUM1RUEsSUFBSUEsS0FBS0EsR0FBR0EsR0FBR0EsQ0FBQ0EsOEJBQThCQSxFQUFFQSxDQUFDQTtRQUNqREEsS0FBS0EsQ0FBQ0EsRUFBRUEsR0FBR0EsRUFBRUEsQ0FBQ0E7UUFDZEEsT0FBT0EsR0FBR0EsSUFBSUEsY0FBY0EsQ0FBQ0EsRUFBRUEsRUFBRUEsS0FBS0EsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7SUFFaERBLENBQUNBO0lBQUNBLElBQUlBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLHdCQUFXQSxDQUFDQSxPQUFPQSxDQUFDQSxxQkFBcUJBLEVBQUVBLEVBQUVBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQy9EQSxJQUFJQSxRQUFRQSxHQUFHQSxJQUFJQSxDQUFDQTtRQUNwQkEsSUFBSUEsZ0JBQWdCQSxHQUFHQSxFQUFFQSxDQUFDQTtRQUMxQkEsSUFBSUEsWUFBWUEsR0FBR0EscUJBQXFCQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtRQUM3Q0EsSUFBSUEsZ0JBQWdCQSxHQUFHQSxFQUFFQSxDQUFDQTtRQUMxQkEsSUFBSUEsS0FBS0EsR0FBR0EsSUFBSUEsMkNBQXdCQSxDQUFDQSxFQUFFQSxFQUFFQSxRQUFRQSxFQUFFQSxnQkFBZ0JBLEVBQUVBLFlBQVlBLEVBQUVBLEVBQUVBLEVBQ2hEQSxnQkFBZ0JBLEVBQUVBLFNBQVNBLENBQUNBLENBQUNBO1FBQ3RFQSxPQUFPQSxHQUFHQSxJQUFJQSxjQUFjQSxDQUFDQSxFQUFFQSxFQUFFQSxLQUFLQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtJQUVoREEsQ0FBQ0E7SUFBQ0EsSUFBSUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0Esd0JBQVdBLENBQUNBLE9BQU9BLENBQUNBLDBCQUEwQkEsRUFBRUEsRUFBRUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDcEVBLElBQUlBLFlBQVlBLEdBQUdBLG1CQUFtQkEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7UUFDM0NBLElBQUlBLEtBQUtBLEdBQUdBLElBQUlBLDJDQUF3QkEsQ0FBQ0EsRUFBRUEsRUFBRUEsSUFBSUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsWUFBWUEsRUFBRUEsRUFBRUEsRUFBRUEsU0FBU0EsQ0FBQ0EsQ0FBQ0E7UUFDeEZBLE9BQU9BLEdBQUdBLElBQUlBLGNBQWNBLENBQUNBLEVBQUVBLEVBQUVBLEtBQUtBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO0lBRWhEQSxDQUFDQTtJQUFDQSxJQUFJQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSx3QkFBV0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsOEJBQThCQSxFQUFFQSxFQUFFQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUN4RUEsSUFBSUEsWUFBWUEsR0FBR0EsdUJBQXVCQSxDQUFDQSxFQUFFQSxFQUFFQSxrQkFBa0JBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ25GQSxJQUFJQSxLQUFLQSxHQUFHQSxJQUFJQSwyQ0FBd0JBLENBQ3BDQSxFQUFFQSxFQUFFQSxJQUFJQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxZQUFZQSxFQUM5QkEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxrQkFBa0JBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLFNBQVNBLENBQUNBLENBQUNBO1FBQ3pGQSxPQUFPQSxHQUFHQSxJQUFJQSxjQUFjQSxDQUFDQSxFQUFFQSxFQUFFQSxLQUFLQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtJQUVoREEsQ0FBQ0E7SUFBQ0EsSUFBSUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsSUFBSUEseUJBQXlCQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUMzQ0EsSUFBSUEsU0FBU0EsR0FBR0EsSUFBSUEsMENBQXVCQSxDQUFDQSxLQUFLQSxFQUFFQSxLQUFLQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtRQUNoRUEsSUFBSUEsT0FBT0EsR0FBR0EscUJBQXFCQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTtRQUM1Q0EsSUFBSUEsS0FBS0EsR0FBR0EsSUFBSUEsMkNBQXdCQSxDQUFDQSxFQUFFQSxFQUFFQSxJQUFJQSxFQUFFQSxFQUFFQSxFQUFFQSxPQUFPQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxTQUFTQSxDQUFDQSxDQUFDQTtRQUNuRkEsT0FBT0EsR0FBR0EsSUFBSUEsY0FBY0EsQ0FBQ0EsRUFBRUEsRUFBRUEsS0FBS0EsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7SUFDaERBLENBQUNBO0lBRURBLEVBQUVBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ3JCQSxNQUFNQSxxQ0FBbUNBLEVBQUVBLHNEQUFtREEsQ0FBQ0E7SUFDakdBLENBQUNBO0lBRURBLE1BQU1BLENBQUNBLE9BQU9BLENBQUNBO0FBQ2pCQSxDQUFDQTtBQXREZSxxQkFBYSxnQkFzRDVCLENBQUE7QUFFRDtJQUNFQyx3QkFBbUJBLEVBQVVBLEVBQVNBLEtBQStCQSxFQUFTQSxNQUFjQTtRQUF6RUMsT0FBRUEsR0FBRkEsRUFBRUEsQ0FBUUE7UUFBU0EsVUFBS0EsR0FBTEEsS0FBS0EsQ0FBMEJBO1FBQVNBLFdBQU1BLEdBQU5BLE1BQU1BLENBQVFBO0lBQUdBLENBQUNBO0lBQ2xHRCxxQkFBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDO0FBRlksc0JBQWMsaUJBRTFCLENBQUE7QUFFRDs7O0dBR0c7QUFDSDtJQUNFRSxJQUFJQSxPQUFPQSxHQUFHQSxxQkFBcUJBLENBQUNBO0lBQ3BDQSxPQUFPQSxHQUFHQSx3QkFBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsT0FBT0EsRUFDUEEsNkJBQWdCQSxDQUFDQSxJQUFJQSxDQUFDQSxxQkFBcUJBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDaEdBLE9BQU9BLEdBQUdBLE9BQU9BLENBQUNBLE1BQU1BLENBQUNBLDZCQUFnQkEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxvQkFBb0JBLENBQUNBLENBQUNBLENBQUNBO0lBQzFGQSxPQUFPQSxHQUFHQSxPQUFPQSxDQUFDQSxNQUFNQSxDQUFDQSw2QkFBZ0JBLENBQUNBLElBQUlBLENBQUNBLGtCQUFrQkEsQ0FBQ0Esb0JBQW9CQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUN6RkEsT0FBT0EsR0FBR0EsT0FBT0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsMEJBQTBCQSxDQUFDQSxDQUFDQTtJQUNyREEsT0FBT0EsR0FBR0EsT0FBT0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsOEJBQThCQSxDQUFDQSxDQUFDQTtJQUN6REEsT0FBT0EsR0FBR0EsT0FBT0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EseUJBQXlCQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUN0REEsTUFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7QUFDcENBLENBQUNBO0FBVmUseUJBQWlCLG9CQVVoQyxDQUFBO0FBRUQ7SUFDRUMsK0JBQW9CQSxXQUFtQkEsRUFBU0EsTUFBY0E7UUFBMUNDLGdCQUFXQSxHQUFYQSxXQUFXQSxDQUFRQTtRQUFTQSxXQUFNQSxHQUFOQSxNQUFNQSxDQUFRQTtJQUFHQSxDQUFDQTtJQUVsRUQsOERBQThCQSxHQUE5QkE7UUFDRUUsSUFBSUEsUUFBUUEsR0FBR0EsSUFBSUEsQ0FBQ0E7UUFDcEJBLElBQUlBLGdCQUFnQkEsR0FBR0EsZ0NBQWdDQSxDQUFDQSxJQUFJQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTtRQUNyRUEsSUFBSUEsY0FBY0EsR0FBR0EscUJBQXFCQSxDQUFDQSxJQUFJQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQTtRQUM3REEsSUFBSUEsZ0JBQWdCQSxHQUFHQSxFQUFFQSxDQUFDQTtRQUMxQkEsSUFBSUEsU0FBU0EsR0FBR0EsSUFBSUEsMENBQXVCQSxDQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtRQUM5REEsTUFBTUEsQ0FBQ0EsSUFBSUEsMkNBQXdCQSxDQUFDQSxZQUFZQSxFQUFFQSxRQUFRQSxFQUFFQSxnQkFBZ0JBLEVBQUVBLGNBQWNBLEVBQ3hEQSxFQUFFQSxFQUFFQSxnQkFBZ0JBLEVBQUVBLFNBQVNBLENBQUNBLENBQUNBO0lBQ3ZFQSxDQUFDQTtJQUVERjs7O09BR0dBO0lBQ0lBLDBDQUFvQkEsR0FBMkNBO1FBQ3BFQSxpQkFBaUJBLEVBQUVBLElBQUlBLHFCQUFxQkEsQ0FDeENBLEtBQUtBLEVBQUVBLElBQUlBLHlCQUFNQSxDQUFDQSxJQUFJQSxFQUFFQSx1QkFBVUEsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsRUFBRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDNUVBLG9CQUFvQkEsRUFBRUEsSUFBSUEscUJBQXFCQSxDQUMzQ0EsT0FBT0EsRUFBRUEsSUFBSUEseUJBQU1BLENBQUNBLElBQUlBLEVBQUVBLHVCQUFVQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQSxDQUFDQSxLQUFLQSxFQUFFQSxjQUFNQSxPQUFBQSxPQUFPQSxFQUFQQSxDQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNwRkEsY0FBY0EsRUFBRUEsSUFBSUEscUJBQXFCQSxDQUNyQ0EsS0FBS0EsRUFDTEEsSUFBSUEseUJBQU1BLENBQUNBLElBQUlBLHlCQUFNQSxDQUFDQSxJQUFJQSxFQUFFQSx1QkFBVUEsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsRUFBRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsSUFBSUEsR0FBR0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7UUFDNUZBLGdCQUFnQkEsRUFBRUEsSUFBSUEscUJBQXFCQSxDQUN2Q0EsTUFBTUEsRUFBRUEsSUFBSUEseUJBQU1BLENBQUNBLElBQUlBLEVBQUVBLHVCQUFVQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQSxDQUFDQSxLQUFLQSxFQUFFQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUM3RUEsaUNBQWlDQSxFQUFFQSxJQUFJQSxxQkFBcUJBLENBQ3hEQSxjQUFjQSxFQUFFQSxJQUFJQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsRUFBRUEsdUJBQVVBLENBQUNBLGVBQWVBLENBQUNBLENBQUNBLENBQUNBLE1BQU1BLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ3BGQSxpQ0FBaUNBLEVBQUVBLElBQUlBLHFCQUFxQkEsQ0FDeERBLE1BQU1BLEVBQUVBLElBQUlBLHlCQUFNQSxDQUFDQSxJQUFJQSxFQUFFQSx1QkFBVUEsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsRUFBRUEsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7S0FDN0VBLENBQUNBO0lBQ0pBLDRCQUFDQTtBQUFEQSxDQUFDQSxBQWhDRCxJQWdDQztBQUVEO0lBQ0VHLDZCQUFvQkEsU0FBa0NBLEVBQVVBLFlBQXFCQSxFQUNqRUEsV0FBb0JBO1FBRHBCQyxjQUFTQSxHQUFUQSxTQUFTQSxDQUF5QkE7UUFBVUEsaUJBQVlBLEdBQVpBLFlBQVlBLENBQVNBO1FBQ2pFQSxnQkFBV0EsR0FBWEEsV0FBV0EsQ0FBU0E7SUFBR0EsQ0FBQ0E7SUFFNUNELDREQUE4QkEsR0FBOUJBO1FBQ0VFLElBQUlBLGdCQUFnQkEsR0FBR0EsRUFBRUEsQ0FBQ0E7UUFDMUJBLElBQUlBLGNBQWNBLEdBQUdBLEVBQUVBLENBQUNBO1FBQ3hCQSxJQUFJQSxnQkFBZ0JBLEdBQUdBLEVBQUVBLENBQUNBO1FBQzFCQSxJQUFJQSxZQUFZQSxHQUFHQSxFQUFFQSxDQUFDQTtRQUV0QkEsSUFBSUEsb0JBQW9CQSxHQUFHQSxJQUFJQSxrQ0FBZUEsQ0FBQ0E7WUFDN0NBLGNBQWNBLEVBQUVBLElBQUlBLGlDQUFjQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtZQUN4Q0EsZUFBZUEsRUFBRUEsMENBQXVCQSxDQUFDQSxPQUFPQTtTQUNqREEsQ0FBQ0EsQ0FBQ0E7UUFDSEEsSUFBSUEsbUJBQW1CQSxHQUFHQSxJQUFJQSxrQ0FBZUEsQ0FBQ0E7WUFDNUNBLGNBQWNBLEVBQUVBLElBQUlBLGlDQUFjQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtZQUN4Q0EsZUFBZUEsRUFBRUEsMENBQXVCQSxDQUFDQSxNQUFNQTtTQUNoREEsQ0FBQ0EsQ0FBQ0E7UUFFSEEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDdEJBLElBQUlBLDRCQUE0QkEsR0FDNUJBLGdDQUFhQSxDQUFDQSxrQkFBa0JBLENBQUNBLFVBQVVBLEVBQUVBLENBQUNBLFlBQVlBLENBQUNBLElBQUlBLEVBQUVBLFVBQVVBLENBQUNBLEVBQUVBLEdBQUdBLEVBQ2hEQSxVQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxJQUFLQSxPQUFNQSxDQUFFQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFkQSxDQUFjQSxFQUFFQSxvQkFBb0JBLENBQUNBLENBQUNBO1lBQ3JGQSxJQUFJQSx5QkFBeUJBLEdBQ3pCQSxnQ0FBYUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxVQUFVQSxFQUFFQSxDQUFDQSxZQUFZQSxDQUFDQSxJQUFJQSxFQUFFQSxVQUFVQSxDQUFDQSxFQUFFQSxHQUFHQSxFQUNoREEsVUFBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsSUFBS0EsT0FBTUEsQ0FBRUEsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBZEEsQ0FBY0EsRUFBRUEsbUJBQW1CQSxDQUFDQSxDQUFDQTtZQUVwRkEsZ0JBQWdCQSxHQUFHQSxDQUFDQSxvQkFBb0JBLEVBQUVBLG1CQUFtQkEsQ0FBQ0EsQ0FBQ0E7WUFDL0RBLGNBQWNBLEdBQUdBLENBQUNBLDRCQUE0QkEsRUFBRUEseUJBQXlCQSxDQUFDQSxDQUFDQTtRQUM3RUEsQ0FBQ0E7UUFFREEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDckJBLGdCQUFnQkEsR0FBR0EsQ0FBQ0Esb0JBQW9CQSxFQUFFQSxtQkFBbUJBLENBQUNBLENBQUNBO1lBQy9EQSxZQUFZQTtnQkFDUkEsd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBLG1CQUFtQkEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxFQUN0Q0EsdUJBQXVCQSxDQUFDQSxzQkFBc0JBLEVBQUVBLG1CQUFtQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQUE7UUFDOUZBLENBQUNBO1FBRURBLElBQUlBLFNBQVNBLEdBQUdBLElBQUlBLDBDQUF1QkEsQ0FBQ0EsSUFBSUEsRUFBRUEsSUFBSUEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7UUFFOURBLE1BQU1BLENBQUNBLElBQUlBLDJDQUF3QkEsQ0FBQ0EsWUFBWUEsRUFBRUEsSUFBSUEsQ0FBQ0EsU0FBU0EsRUFBRUEsZ0JBQWdCQSxFQUM5Q0EsY0FBY0EsRUFBRUEsWUFBWUEsRUFBRUEsZ0JBQWdCQSxFQUFFQSxTQUFTQSxDQUFDQSxDQUFDQTtJQUNqR0EsQ0FBQ0E7SUFFREY7OztPQUdHQTtJQUNJQSx3Q0FBb0JBLEdBQXlDQTtRQUNsRUEsMkJBQTJCQSxFQUN2QkEsSUFBSUEsbUJBQW1CQSxDQUFDQSwwQ0FBdUJBLENBQUNBLE9BQU9BLEVBQUVBLEtBQUtBLEVBQUVBLEtBQUtBLENBQUNBO1FBQzFFQSwwQkFBMEJBLEVBQ3RCQSxJQUFJQSxtQkFBbUJBLENBQUNBLDBDQUF1QkEsQ0FBQ0EsTUFBTUEsRUFBRUEsS0FBS0EsRUFBRUEsS0FBS0EsQ0FBQ0E7UUFDekVBLG1DQUFtQ0EsRUFDL0JBLElBQUlBLG1CQUFtQkEsQ0FBQ0EsMENBQXVCQSxDQUFDQSxPQUFPQSxFQUFFQSxJQUFJQSxFQUFFQSxLQUFLQSxDQUFDQTtRQUN6RUEsaUJBQWlCQSxFQUFFQSxJQUFJQSxtQkFBbUJBLENBQUNBLDBDQUF1QkEsQ0FBQ0EsTUFBTUEsRUFBRUEsS0FBS0EsRUFBRUEsSUFBSUEsQ0FBQ0E7UUFDdkZBLHFCQUFxQkEsRUFBRUEsSUFBSUEsbUJBQW1CQSxDQUFDQSwwQ0FBdUJBLENBQUNBLE1BQU1BLEVBQUVBLEtBQUtBLEVBQUVBLElBQUlBLENBQUNBO0tBQzVGQSxDQUFDQTtJQUNKQSwwQkFBQ0E7QUFBREEsQ0FBQ0EsQUExREQsSUEwREM7QUFFRDtJQUNFRyw0QkFBb0JBLGVBQWdDQSxFQUNoQ0EsaUJBQW9DQTtRQURwQ0Msb0JBQWVBLEdBQWZBLGVBQWVBLENBQWlCQTtRQUNoQ0Esc0JBQWlCQSxHQUFqQkEsaUJBQWlCQSxDQUFtQkE7SUFBR0EsQ0FBQ0E7SUFFNURELDJEQUE4QkEsR0FBOUJBO1FBQ0VFLElBQUlBLFFBQVFBLEdBQUdBLElBQUlBLENBQUNBO1FBQ3BCQSxJQUFJQSxnQkFBZ0JBLEdBQUdBLEVBQUVBLENBQUNBO1FBQzFCQSxJQUFJQSxTQUFTQSxHQUFHQSxJQUFJQSwwQ0FBdUJBLENBQUNBLElBQUlBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO1FBRTlEQSxNQUFNQSxDQUFDQSxJQUFJQSwyQ0FBd0JBLENBQUNBLFlBQVlBLEVBQUVBLFFBQVFBLEVBQUVBLGdCQUFnQkEsRUFDeENBLElBQUlBLENBQUNBLGVBQWVBLEVBQUVBLEVBQUVBLEVBQUVBLElBQUlBLENBQUNBLGlCQUFpQkEsRUFDaERBLFNBQVNBLENBQUNBLENBQUNBO0lBQ2pEQSxDQUFDQTtJQUVNRiwwQkFBT0EsR0FBZEEsVUFBZUEsVUFBa0JBLEVBQUVBLFNBQVNBO1FBQzFDRyxNQUFNQSxDQUFDQSxnQ0FBYUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxVQUFVQSxFQUFFQSxDQUFDQSxZQUFZQSxDQUFDQSxVQUFVQSxFQUFFQSxVQUFVQSxDQUFDQSxFQUFFQSxHQUFHQSxFQUN0REEsVUFBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsSUFBS0EsT0FBTUEsQ0FBRUEsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBZEEsQ0FBY0EsRUFBRUEsU0FBU0EsQ0FBQ0EsQ0FBQ0E7SUFDL0VBLENBQUNBO0lBRU1ILDBCQUFPQSxHQUFkQSxVQUFlQSxVQUFrQkEsRUFBRUEsU0FBU0E7UUFDMUNJLE1BQU1BLENBQUNBLGdDQUFhQSxDQUFDQSxrQkFBa0JBLENBQUNBLFVBQVVBLEVBQUVBLENBQUNBLFlBQVlBLENBQUNBLFVBQVVBLEVBQUVBLFVBQVVBLENBQUNBLEVBQUVBLEdBQUdBLEVBQ3REQSxVQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxJQUFLQSxPQUFNQSxDQUFFQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFkQSxDQUFjQSxFQUFFQSxTQUFTQSxDQUFDQSxDQUFDQTtJQUMvRUEsQ0FBQ0E7SUFFTUosK0JBQVlBLEdBQXNCQTtRQUN2Q0EsSUFBSUEsa0NBQWVBLENBQUNBO1lBQ2xCQSxjQUFjQSxFQUFFQSxJQUFJQSxpQ0FBY0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7WUFDeENBLGFBQWFBLEVBQUVBLElBQUlBO1lBQ25CQSxXQUFXQSxFQUFFQSxJQUFJQTtZQUNqQkEsVUFBVUEsRUFBRUEsSUFBSUE7WUFDaEJBLG9CQUFvQkEsRUFBRUEsSUFBSUE7WUFDMUJBLHVCQUF1QkEsRUFBRUEsSUFBSUE7WUFDN0JBLGlCQUFpQkEsRUFBRUEsSUFBSUE7WUFDdkJBLG9CQUFvQkEsRUFBRUEsSUFBSUE7WUFDMUJBLGFBQWFBLEVBQUVBLElBQUlBO1lBQ25CQSxPQUFPQSxFQUFFQSxDQUFDQSxDQUFDQSxjQUFjQSxFQUFFQSxZQUFZQSxDQUFDQSxDQUFDQTtTQUMxQ0EsQ0FBQ0E7UUFDRkEsSUFBSUEsa0NBQWVBLENBQUNBO1lBQ2xCQSxjQUFjQSxFQUFFQSxJQUFJQSxpQ0FBY0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7WUFDeENBLGFBQWFBLEVBQUVBLElBQUlBO1lBQ25CQSxXQUFXQSxFQUFFQSxJQUFJQTtZQUNqQkEsVUFBVUEsRUFBRUEsSUFBSUE7WUFDaEJBLG9CQUFvQkEsRUFBRUEsSUFBSUE7WUFDMUJBLHVCQUF1QkEsRUFBRUEsSUFBSUE7WUFDN0JBLGlCQUFpQkEsRUFBRUEsSUFBSUE7WUFDdkJBLG9CQUFvQkEsRUFBRUEsSUFBSUE7WUFDMUJBLGFBQWFBLEVBQUVBLElBQUlBO1lBQ25CQSxPQUFPQSxFQUFFQSxDQUFDQSxDQUFDQSxjQUFjQSxFQUFFQSxZQUFZQSxDQUFDQSxDQUFDQTtTQUMxQ0EsQ0FBQ0E7S0FDSEEsQ0FBQ0E7SUFFS0Esb0NBQWlCQSxHQUFHQSxJQUFJQSxrQ0FBZUEsQ0FBQ0E7UUFDN0NBLGNBQWNBLEVBQUVBLElBQUlBLGlDQUFjQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtRQUN4Q0EsYUFBYUEsRUFBRUEsS0FBS0E7UUFDcEJBLFdBQVdBLEVBQUVBLEtBQUtBO1FBQ2xCQSxVQUFVQSxFQUFFQSxLQUFLQTtRQUNqQkEsb0JBQW9CQSxFQUFFQSxLQUFLQTtRQUMzQkEsdUJBQXVCQSxFQUFFQSxLQUFLQTtRQUM5QkEsaUJBQWlCQSxFQUFFQSxLQUFLQTtRQUN4QkEsb0JBQW9CQSxFQUFFQSxLQUFLQTtLQUM1QkEsQ0FBQ0EsQ0FBQ0E7SUFFSEE7OztPQUdHQTtJQUNJQSx1Q0FBb0JBLEdBQXdDQTtRQUNqRUEsb0JBQW9CQSxFQUFFQSxJQUFJQSxrQkFBa0JBLENBQ3hDQSxDQUFDQSxrQkFBa0JBLENBQUNBLE9BQU9BLENBQUNBLElBQUlBLEVBQUVBLGtCQUFrQkEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFDdEVBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDekNBLGNBQWNBLEVBQ1ZBLElBQUlBLGtCQUFrQkEsQ0FDbEJBO1lBQ0VBLGtCQUFrQkEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsR0FBR0EsRUFBRUEsa0JBQWtCQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNuRUEsa0JBQWtCQSxDQUFDQSxPQUFPQSxDQUFDQSxHQUFHQSxFQUFFQSxrQkFBa0JBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ25FQSxnQ0FBYUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSxrQkFBa0JBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQzFFQSxrQkFBa0JBLENBQUNBLE9BQU9BLENBQUNBLEdBQUdBLEVBQUVBLGtCQUFrQkEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDbkVBLGdDQUFhQSxDQUFDQSx3QkFBd0JBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7U0FDM0VBLEVBQ0RBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsa0JBQWtCQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNqRkEsa0JBQWtCQSxFQUFFQSxJQUFJQSxrQkFBa0JBLENBQ3RDQSxDQUFDQSxnQ0FBYUEsQ0FBQ0Esc0JBQXNCQSxDQUFDQSxrQkFBa0JBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLEVBQzFFQSxDQUFDQSxrQkFBa0JBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ3pDQSxpQkFBaUJBLEVBQUVBLElBQUlBLGtCQUFrQkEsQ0FDckNBLENBQUNBLGdDQUFhQSxDQUFDQSxxQkFBcUJBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFDekVBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDekNBLDJCQUEyQkEsRUFBRUEsSUFBSUEsa0JBQWtCQSxDQUMvQ0EsRUFBRUEsRUFBRUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxrQkFBa0JBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ2pGQSxhQUFhQSxFQUFFQSxJQUFJQSxrQkFBa0JBLENBQ2pDQSxDQUFDQSxrQkFBa0JBLENBQUNBLE9BQU9BLENBQUNBLEdBQUdBLEVBQUVBLGtCQUFrQkEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQSxFQUN2RUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBO1FBQzNDQSxtQkFBbUJBLEVBQ2ZBLElBQUlBLGtCQUFrQkEsQ0FDbEJBO1lBQ0VBLGdDQUFhQSxDQUFDQSxxQkFBcUJBLENBQy9CQSxJQUFJQSxpQ0FBY0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsVUFBVUEsRUFBRUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsR0FBR0EsRUFBRUEsVUFBVUEsQ0FBQ0EsRUFBRUEsaUJBQVNBLENBQUNBO1NBQ3JGQSxFQUNEQSxDQUFDQSxrQkFBa0JBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQzdDQSxlQUFlQSxFQUNYQSxJQUFJQSxrQkFBa0JBLENBQ2xCQTtZQUNFQSxnQ0FBYUEsQ0FBQ0Esd0JBQXdCQSxDQUNsQ0EsVUFBVUEsRUFBRUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxTQUFTQSxFQUFFQSxVQUFVQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxpQkFBU0EsQ0FBQ0E7U0FDMUVBLEVBQ0RBLEVBQUVBLENBQUNBO0tBQ1pBLENBQUNBO0lBQ0pBLHlCQUFDQTtBQUFEQSxDQUFDQSxBQTFHRCxJQTBHQztBQUVEOzs7O0dBSUc7QUFDSCxJQUFJLHFCQUFxQixHQUFHO0lBQzFCLEtBQUs7SUFDTCxJQUFJO0lBQ0osT0FBTztJQUNQLFVBQVU7SUFDVixRQUFRO0lBQ1IsUUFBUTtJQUNSLFFBQVE7SUFDUixRQUFRO0lBQ1IsUUFBUTtJQUNSLFFBQVE7SUFDUixRQUFRO0lBQ1IsV0FBVztJQUNYLFNBQVM7SUFDVCxTQUFTO0lBQ1QsWUFBWTtJQUNaLE9BQU87SUFDUCxPQUFPO0lBQ1AsT0FBTztJQUNQLE9BQU87SUFDUCxRQUFRO0lBQ1IsUUFBUTtJQUNSLFFBQVE7SUFDUixRQUFRO0lBQ1IsUUFBUTtJQUNSLFFBQVE7SUFDUixjQUFjO0lBQ2QsZUFBZTtJQUNmLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsT0FBTztJQUNQLFFBQVE7SUFDUixlQUFlO0lBQ2YsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQix1QkFBdUI7SUFDdkIsTUFBTTtJQUNOLFFBQVE7SUFDUixRQUFRO0lBQ1IsUUFBUTtJQUNSLFFBQVE7SUFDUixhQUFhO0lBQ2Isc0JBQXNCO0lBQ3RCLGdDQUFnQztJQUNoQyxrQ0FBa0M7SUFDbEMsT0FBTztJQUNQLEdBQUc7SUFDSCxjQUFjO0lBQ2QsZUFBZTtJQUNmLHFCQUFxQjtJQUNyQixjQUFjO0lBQ2QsU0FBUztJQUNULGdCQUFnQjtJQUNoQixtQkFBbUI7SUFDbkIsY0FBYztJQUNkLEtBQUs7SUFDTCx1QkFBdUI7SUFDdkIsd0JBQXdCO0lBQ3hCLHdCQUF3QjtJQUN4Qix5QkFBeUI7SUFDekIsMEJBQTBCO0lBQzFCLHlCQUF5QjtJQUN6Qiw4RUFBOEU7Q0FDL0UsQ0FBQztBQUVGLElBQUksMEJBQTBCLEdBQUc7SUFDL0IsNEJBQTRCO0lBQzVCLHVCQUF1QjtJQUN2Qix3QkFBd0I7SUFDeEIseUJBQXlCO0lBQ3pCLHlCQUF5QjtJQUN6Qix1QkFBdUI7SUFDdkIsaUJBQWlCO0lBQ2pCLGdCQUFnQjtJQUNoQix3Q0FBd0M7Q0FDekMsQ0FBQztBQUVGLElBQUksOEJBQThCLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtMaXN0V3JhcHBlciwgTWFwV3JhcHBlciwgU3RyaW5nTWFwV3JhcHBlcn0gZnJvbSAnYW5ndWxhcjIvc3JjL2ZhY2FkZS9jb2xsZWN0aW9uJztcbmltcG9ydCB7aXNCbGFuaywgaXNQcmVzZW50fSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2xhbmcnO1xuaW1wb3J0IHtcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIEJpbmRpbmdSZWNvcmQsXG4gIENoYW5nZURldGVjdG9yRGVmaW5pdGlvbixcbiAgRGlyZWN0aXZlSW5kZXgsXG4gIERpcmVjdGl2ZVJlY29yZCxcbiAgTGV4ZXIsXG4gIExvY2FscyxcbiAgUGFyc2VyLFxuICBDaGFuZ2VEZXRlY3RvckdlbkNvbmZpZ1xufSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9jaGFuZ2VfZGV0ZWN0aW9uL2NoYW5nZV9kZXRlY3Rpb24nO1xuaW1wb3J0IHtyZWZsZWN0b3J9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL3JlZmxlY3Rpb24vcmVmbGVjdGlvbic7XG5pbXBvcnQge1JlZmxlY3Rpb25DYXBhYmlsaXRpZXN9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL3JlZmxlY3Rpb24vcmVmbGVjdGlvbl9jYXBhYmlsaXRpZXMnO1xuXG4vKlxuICogVGhpcyBmaWxlIGRlZmluZXMgYENoYW5nZURldGVjdG9yRGVmaW5pdGlvbmAgb2JqZWN0cyB3aGljaCBhcmUgdXNlZCBpbiB0aGUgdGVzdHMgZGVmaW5lZCBpblxuICogdGhlIGNoYW5nZV9kZXRlY3Rvcl9zcGVjIGxpYnJhcnkuIFBsZWFzZSBzZWUgdGhhdCBsaWJyYXJ5IGZvciBtb3JlIGluZm9ybWF0aW9uLlxuICovXG5cbnZhciBfcGFyc2VyID0gbmV3IFBhcnNlcihuZXcgTGV4ZXIoKSk7XG5cbmZ1bmN0aW9uIF9nZXRQYXJzZXIoKSB7XG4gIHJlZmxlY3Rvci5yZWZsZWN0aW9uQ2FwYWJpbGl0aWVzID0gbmV3IFJlZmxlY3Rpb25DYXBhYmlsaXRpZXMoKTtcbiAgcmV0dXJuIF9wYXJzZXI7XG59XG5cbmZ1bmN0aW9uIF9jcmVhdGVCaW5kaW5nUmVjb3JkcyhleHByZXNzaW9uOiBzdHJpbmcpOiBCaW5kaW5nUmVjb3JkW10ge1xuICB2YXIgYXN0ID0gX2dldFBhcnNlcigpLnBhcnNlQmluZGluZyhleHByZXNzaW9uLCAnbG9jYXRpb24nKTtcbiAgcmV0dXJuIFtCaW5kaW5nUmVjb3JkLmNyZWF0ZUZvckVsZW1lbnRQcm9wZXJ0eShhc3QsIDAsIFBST1BfTkFNRSldO1xufVxuXG5mdW5jdGlvbiBfY3JlYXRlRXZlbnRSZWNvcmRzKGV4cHJlc3Npb246IHN0cmluZyk6IEJpbmRpbmdSZWNvcmRbXSB7XG4gIHZhciBlcSA9IGV4cHJlc3Npb24uaW5kZXhPZihcIj1cIik7XG4gIHZhciBldmVudE5hbWUgPSBleHByZXNzaW9uLnN1YnN0cmluZygxLCBlcSAtIDEpO1xuICB2YXIgZXhwID0gZXhwcmVzc2lvbi5zdWJzdHJpbmcoZXEgKyAyLCBleHByZXNzaW9uLmxlbmd0aCAtIDEpO1xuICB2YXIgYXN0ID0gX2dldFBhcnNlcigpLnBhcnNlQWN0aW9uKGV4cCwgJ2xvY2F0aW9uJyk7XG4gIHJldHVybiBbQmluZGluZ1JlY29yZC5jcmVhdGVGb3JFdmVudChhc3QsIGV2ZW50TmFtZSwgMCldO1xufVxuXG5mdW5jdGlvbiBfY3JlYXRlSG9zdEV2ZW50UmVjb3JkcyhleHByZXNzaW9uOiBzdHJpbmcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVSZWNvcmQ6IERpcmVjdGl2ZVJlY29yZCk6IEJpbmRpbmdSZWNvcmRbXSB7XG4gIHZhciBwYXJ0cyA9IGV4cHJlc3Npb24uc3BsaXQoXCI9XCIpO1xuICB2YXIgZXZlbnROYW1lID0gcGFydHNbMF0uc3Vic3RyaW5nKDEsIHBhcnRzWzBdLmxlbmd0aCAtIDEpO1xuICB2YXIgZXhwID0gcGFydHNbMV0uc3Vic3RyaW5nKDEsIHBhcnRzWzFdLmxlbmd0aCAtIDEpO1xuXG4gIHZhciBhc3QgPSBfZ2V0UGFyc2VyKCkucGFyc2VBY3Rpb24oZXhwLCAnbG9jYXRpb24nKTtcbiAgcmV0dXJuIFtCaW5kaW5nUmVjb3JkLmNyZWF0ZUZvckhvc3RFdmVudChhc3QsIGV2ZW50TmFtZSwgZGlyZWN0aXZlUmVjb3JkKV07XG59XG5cbmZ1bmN0aW9uIF9jb252ZXJ0TG9jYWxzVG9WYXJpYWJsZUJpbmRpbmdzKGxvY2FsczogTG9jYWxzKTogYW55W10ge1xuICB2YXIgdmFyaWFibGVCaW5kaW5ncyA9IFtdO1xuICB2YXIgbG9jID0gbG9jYWxzO1xuICB3aGlsZSAoaXNQcmVzZW50KGxvYykgJiYgaXNQcmVzZW50KGxvYy5jdXJyZW50KSkge1xuICAgIGxvYy5jdXJyZW50LmZvckVhY2goKHYsIGspID0+IHZhcmlhYmxlQmluZGluZ3MucHVzaChrKSk7XG4gICAgbG9jID0gbG9jLnBhcmVudDtcbiAgfVxuICByZXR1cm4gdmFyaWFibGVCaW5kaW5ncztcbn1cblxuZXhwb3J0IGNvbnN0IFBST1BfTkFNRSA9ICdwcm9wTmFtZSc7XG5cbi8qKlxuICogSW4gdGhpcyBjYXNlLCB3ZSBleHBlY3QgYGlkYCBhbmQgYGV4cHJlc3Npb25gIHRvIGJlIHRoZSBzYW1lIHN0cmluZy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldERlZmluaXRpb24oaWQ6IHN0cmluZyk6IFRlc3REZWZpbml0aW9uIHtcbiAgdmFyIGdlbkNvbmZpZyA9IG5ldyBDaGFuZ2VEZXRlY3RvckdlbkNvbmZpZyh0cnVlLCB0cnVlLCB0cnVlKTtcbiAgdmFyIHRlc3REZWYgPSBudWxsO1xuICBpZiAoU3RyaW5nTWFwV3JhcHBlci5jb250YWlucyhfRXhwcmVzc2lvbldpdGhMb2NhbHMuYXZhaWxhYmxlRGVmaW5pdGlvbnMsIGlkKSkge1xuICAgIGxldCB2YWwgPSBTdHJpbmdNYXBXcmFwcGVyLmdldChfRXhwcmVzc2lvbldpdGhMb2NhbHMuYXZhaWxhYmxlRGVmaW5pdGlvbnMsIGlkKTtcbiAgICBsZXQgY2REZWYgPSB2YWwuY3JlYXRlQ2hhbmdlRGV0ZWN0b3JEZWZpbml0aW9uKCk7XG4gICAgY2REZWYuaWQgPSBpZDtcbiAgICB0ZXN0RGVmID0gbmV3IFRlc3REZWZpbml0aW9uKGlkLCBjZERlZiwgdmFsLmxvY2Fscyk7XG5cbiAgfSBlbHNlIGlmIChTdHJpbmdNYXBXcmFwcGVyLmNvbnRhaW5zKF9FeHByZXNzaW9uV2l0aE1vZGUuYXZhaWxhYmxlRGVmaW5pdGlvbnMsIGlkKSkge1xuICAgIGxldCB2YWwgPSBTdHJpbmdNYXBXcmFwcGVyLmdldChfRXhwcmVzc2lvbldpdGhNb2RlLmF2YWlsYWJsZURlZmluaXRpb25zLCBpZCk7XG4gICAgbGV0IGNkRGVmID0gdmFsLmNyZWF0ZUNoYW5nZURldGVjdG9yRGVmaW5pdGlvbigpO1xuICAgIGNkRGVmLmlkID0gaWQ7XG4gICAgdGVzdERlZiA9IG5ldyBUZXN0RGVmaW5pdGlvbihpZCwgY2REZWYsIG51bGwpO1xuXG4gIH0gZWxzZSBpZiAoU3RyaW5nTWFwV3JhcHBlci5jb250YWlucyhfRGlyZWN0aXZlVXBkYXRpbmcuYXZhaWxhYmxlRGVmaW5pdGlvbnMsIGlkKSkge1xuICAgIGxldCB2YWwgPSBTdHJpbmdNYXBXcmFwcGVyLmdldChfRGlyZWN0aXZlVXBkYXRpbmcuYXZhaWxhYmxlRGVmaW5pdGlvbnMsIGlkKTtcbiAgICBsZXQgY2REZWYgPSB2YWwuY3JlYXRlQ2hhbmdlRGV0ZWN0b3JEZWZpbml0aW9uKCk7XG4gICAgY2REZWYuaWQgPSBpZDtcbiAgICB0ZXN0RGVmID0gbmV3IFRlc3REZWZpbml0aW9uKGlkLCBjZERlZiwgbnVsbCk7XG5cbiAgfSBlbHNlIGlmIChMaXN0V3JhcHBlci5pbmRleE9mKF9hdmFpbGFibGVEZWZpbml0aW9ucywgaWQpID49IDApIHtcbiAgICB2YXIgc3RyYXRlZ3kgPSBudWxsO1xuICAgIHZhciB2YXJpYWJsZUJpbmRpbmdzID0gW107XG4gICAgdmFyIGV2ZW50UmVjb3JkcyA9IF9jcmVhdGVCaW5kaW5nUmVjb3JkcyhpZCk7XG4gICAgdmFyIGRpcmVjdGl2ZVJlY29yZHMgPSBbXTtcbiAgICBsZXQgY2REZWYgPSBuZXcgQ2hhbmdlRGV0ZWN0b3JEZWZpbml0aW9uKGlkLCBzdHJhdGVneSwgdmFyaWFibGVCaW5kaW5ncywgZXZlbnRSZWNvcmRzLCBbXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZVJlY29yZHMsIGdlbkNvbmZpZyk7XG4gICAgdGVzdERlZiA9IG5ldyBUZXN0RGVmaW5pdGlvbihpZCwgY2REZWYsIG51bGwpO1xuXG4gIH0gZWxzZSBpZiAoTGlzdFdyYXBwZXIuaW5kZXhPZihfYXZhaWxhYmxlRXZlbnREZWZpbml0aW9ucywgaWQpID49IDApIHtcbiAgICB2YXIgZXZlbnRSZWNvcmRzID0gX2NyZWF0ZUV2ZW50UmVjb3JkcyhpZCk7XG4gICAgbGV0IGNkRGVmID0gbmV3IENoYW5nZURldGVjdG9yRGVmaW5pdGlvbihpZCwgbnVsbCwgW10sIFtdLCBldmVudFJlY29yZHMsIFtdLCBnZW5Db25maWcpO1xuICAgIHRlc3REZWYgPSBuZXcgVGVzdERlZmluaXRpb24oaWQsIGNkRGVmLCBudWxsKTtcblxuICB9IGVsc2UgaWYgKExpc3RXcmFwcGVyLmluZGV4T2YoX2F2YWlsYWJsZUhvc3RFdmVudERlZmluaXRpb25zLCBpZCkgPj0gMCkge1xuICAgIHZhciBldmVudFJlY29yZHMgPSBfY3JlYXRlSG9zdEV2ZW50UmVjb3JkcyhpZCwgX0RpcmVjdGl2ZVVwZGF0aW5nLmJhc2ljUmVjb3Jkc1swXSk7XG4gICAgbGV0IGNkRGVmID0gbmV3IENoYW5nZURldGVjdG9yRGVmaW5pdGlvbihcbiAgICAgICAgaWQsIG51bGwsIFtdLCBbXSwgZXZlbnRSZWNvcmRzLFxuICAgICAgICBbX0RpcmVjdGl2ZVVwZGF0aW5nLmJhc2ljUmVjb3Jkc1swXSwgX0RpcmVjdGl2ZVVwZGF0aW5nLmJhc2ljUmVjb3Jkc1sxXV0sIGdlbkNvbmZpZyk7XG4gICAgdGVzdERlZiA9IG5ldyBUZXN0RGVmaW5pdGlvbihpZCwgY2REZWYsIG51bGwpO1xuXG4gIH0gZWxzZSBpZiAoaWQgPT0gXCJ1cGRhdGVFbGVtZW50UHJvZHVjdGlvblwiKSB7XG4gICAgdmFyIGdlbkNvbmZpZyA9IG5ldyBDaGFuZ2VEZXRlY3RvckdlbkNvbmZpZyhmYWxzZSwgZmFsc2UsIHRydWUpO1xuICAgIHZhciByZWNvcmRzID0gX2NyZWF0ZUJpbmRpbmdSZWNvcmRzKFwibmFtZVwiKTtcbiAgICBsZXQgY2REZWYgPSBuZXcgQ2hhbmdlRGV0ZWN0b3JEZWZpbml0aW9uKGlkLCBudWxsLCBbXSwgcmVjb3JkcywgW10sIFtdLCBnZW5Db25maWcpO1xuICAgIHRlc3REZWYgPSBuZXcgVGVzdERlZmluaXRpb24oaWQsIGNkRGVmLCBudWxsKTtcbiAgfVxuXG4gIGlmIChpc0JsYW5rKHRlc3REZWYpKSB7XG4gICAgdGhyb3cgYE5vIENoYW5nZURldGVjdG9yRGVmaW5pdGlvbiBmb3IgJHtpZH0gYXZhaWxhYmxlLiBQbGVhc2UgbW9kaWZ5IHRoaXMgZmlsZSBpZiBuZWNlc3NhcnkuYDtcbiAgfVxuXG4gIHJldHVybiB0ZXN0RGVmO1xufVxuXG5leHBvcnQgY2xhc3MgVGVzdERlZmluaXRpb24ge1xuICBjb25zdHJ1Y3RvcihwdWJsaWMgaWQ6IHN0cmluZywgcHVibGljIGNkRGVmOiBDaGFuZ2VEZXRlY3RvckRlZmluaXRpb24sIHB1YmxpYyBsb2NhbHM6IExvY2Fscykge31cbn1cblxuLyoqXG4gKiBHZXQgYWxsIGF2YWlsYWJsZSBDaGFuZ2VEZXRlY3RvckRlZmluaXRpb24gb2JqZWN0cy4gVXNlZCB0byBwcmUtZ2VuZXJhdGUgRGFydFxuICogYENoYW5nZURldGVjdG9yYCBjbGFzc2VzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0QWxsRGVmaW5pdGlvbnMoKTogVGVzdERlZmluaXRpb25bXSB7XG4gIHZhciBhbGxEZWZzID0gX2F2YWlsYWJsZURlZmluaXRpb25zO1xuICBhbGxEZWZzID0gTGlzdFdyYXBwZXIuY29uY2F0KGFsbERlZnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nTWFwV3JhcHBlci5rZXlzKF9FeHByZXNzaW9uV2l0aExvY2Fscy5hdmFpbGFibGVEZWZpbml0aW9ucykpO1xuICBhbGxEZWZzID0gYWxsRGVmcy5jb25jYXQoU3RyaW5nTWFwV3JhcHBlci5rZXlzKF9FeHByZXNzaW9uV2l0aE1vZGUuYXZhaWxhYmxlRGVmaW5pdGlvbnMpKTtcbiAgYWxsRGVmcyA9IGFsbERlZnMuY29uY2F0KFN0cmluZ01hcFdyYXBwZXIua2V5cyhfRGlyZWN0aXZlVXBkYXRpbmcuYXZhaWxhYmxlRGVmaW5pdGlvbnMpKTtcbiAgYWxsRGVmcyA9IGFsbERlZnMuY29uY2F0KF9hdmFpbGFibGVFdmVudERlZmluaXRpb25zKTtcbiAgYWxsRGVmcyA9IGFsbERlZnMuY29uY2F0KF9hdmFpbGFibGVIb3N0RXZlbnREZWZpbml0aW9ucyk7XG4gIGFsbERlZnMgPSBhbGxEZWZzLmNvbmNhdChbXCJ1cGRhdGVFbGVtZW50UHJvZHVjdGlvblwiXSk7XG4gIHJldHVybiBhbGxEZWZzLm1hcChnZXREZWZpbml0aW9uKTtcbn1cblxuY2xhc3MgX0V4cHJlc3Npb25XaXRoTG9jYWxzIHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBfZXhwcmVzc2lvbjogc3RyaW5nLCBwdWJsaWMgbG9jYWxzOiBMb2NhbHMpIHt9XG5cbiAgY3JlYXRlQ2hhbmdlRGV0ZWN0b3JEZWZpbml0aW9uKCk6IENoYW5nZURldGVjdG9yRGVmaW5pdGlvbiB7XG4gICAgdmFyIHN0cmF0ZWd5ID0gbnVsbDtcbiAgICB2YXIgdmFyaWFibGVCaW5kaW5ncyA9IF9jb252ZXJ0TG9jYWxzVG9WYXJpYWJsZUJpbmRpbmdzKHRoaXMubG9jYWxzKTtcbiAgICB2YXIgYmluZGluZ1JlY29yZHMgPSBfY3JlYXRlQmluZGluZ1JlY29yZHModGhpcy5fZXhwcmVzc2lvbik7XG4gICAgdmFyIGRpcmVjdGl2ZVJlY29yZHMgPSBbXTtcbiAgICB2YXIgZ2VuQ29uZmlnID0gbmV3IENoYW5nZURldGVjdG9yR2VuQ29uZmlnKHRydWUsIHRydWUsIHRydWUpO1xuICAgIHJldHVybiBuZXcgQ2hhbmdlRGV0ZWN0b3JEZWZpbml0aW9uKCcoZW1wdHkgaWQpJywgc3RyYXRlZ3ksIHZhcmlhYmxlQmluZGluZ3MsIGJpbmRpbmdSZWNvcmRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtdLCBkaXJlY3RpdmVSZWNvcmRzLCBnZW5Db25maWcpO1xuICB9XG5cbiAgLyoqXG4gICAqIE1hcCBmcm9tIHRlc3QgaWQgdG8gX0V4cHJlc3Npb25XaXRoTG9jYWxzLlxuICAgKiBUZXN0cyBpbiB0aGlzIG1hcCBkZWZpbmUgYW4gZXhwcmVzc2lvbiBhbmQgbG9jYWwgdmFsdWVzIHdoaWNoIHRob3NlIGV4cHJlc3Npb25zIHJlZmVyIHRvLlxuICAgKi9cbiAgc3RhdGljIGF2YWlsYWJsZURlZmluaXRpb25zOiB7W2tleTogc3RyaW5nXTogX0V4cHJlc3Npb25XaXRoTG9jYWxzfSA9IHtcbiAgICAndmFsdWVGcm9tTG9jYWxzJzogbmV3IF9FeHByZXNzaW9uV2l0aExvY2FscyhcbiAgICAgICAgJ2tleScsIG5ldyBMb2NhbHMobnVsbCwgTWFwV3JhcHBlci5jcmVhdGVGcm9tUGFpcnMoW1sna2V5JywgJ3ZhbHVlJ11dKSkpLFxuICAgICdmdW5jdGlvbkZyb21Mb2NhbHMnOiBuZXcgX0V4cHJlc3Npb25XaXRoTG9jYWxzKFxuICAgICAgICAna2V5KCknLCBuZXcgTG9jYWxzKG51bGwsIE1hcFdyYXBwZXIuY3JlYXRlRnJvbVBhaXJzKFtbJ2tleScsICgpID0+ICd2YWx1ZSddXSkpKSxcbiAgICAnbmVzdGVkTG9jYWxzJzogbmV3IF9FeHByZXNzaW9uV2l0aExvY2FscyhcbiAgICAgICAgJ2tleScsXG4gICAgICAgIG5ldyBMb2NhbHMobmV3IExvY2FscyhudWxsLCBNYXBXcmFwcGVyLmNyZWF0ZUZyb21QYWlycyhbWydrZXknLCAndmFsdWUnXV0pKSwgbmV3IE1hcCgpKSksXG4gICAgJ2ZhbGxiYWNrTG9jYWxzJzogbmV3IF9FeHByZXNzaW9uV2l0aExvY2FscyhcbiAgICAgICAgJ25hbWUnLCBuZXcgTG9jYWxzKG51bGwsIE1hcFdyYXBwZXIuY3JlYXRlRnJvbVBhaXJzKFtbJ2tleScsICd2YWx1ZSddXSkpKSxcbiAgICAnY29udGV4dE5lc3RlZFByb3BlcnR5V2l0aExvY2Fscyc6IG5ldyBfRXhwcmVzc2lvbldpdGhMb2NhbHMoXG4gICAgICAgICdhZGRyZXNzLmNpdHknLCBuZXcgTG9jYWxzKG51bGwsIE1hcFdyYXBwZXIuY3JlYXRlRnJvbVBhaXJzKFtbJ2NpdHknLCAnTVRWJ11dKSkpLFxuICAgICdsb2NhbFByb3BlcnR5V2l0aFNpbWlsYXJDb250ZXh0JzogbmV3IF9FeHByZXNzaW9uV2l0aExvY2FscyhcbiAgICAgICAgJ2NpdHknLCBuZXcgTG9jYWxzKG51bGwsIE1hcFdyYXBwZXIuY3JlYXRlRnJvbVBhaXJzKFtbJ2NpdHknLCAnTVRWJ11dKSkpXG4gIH07XG59XG5cbmNsYXNzIF9FeHByZXNzaW9uV2l0aE1vZGUge1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9zdHJhdGVneTogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksIHByaXZhdGUgX3dpdGhSZWNvcmRzOiBib29sZWFuLFxuICAgICAgICAgICAgICBwcml2YXRlIF93aXRoRXZlbnRzOiBib29sZWFuKSB7fVxuXG4gIGNyZWF0ZUNoYW5nZURldGVjdG9yRGVmaW5pdGlvbigpOiBDaGFuZ2VEZXRlY3RvckRlZmluaXRpb24ge1xuICAgIHZhciB2YXJpYWJsZUJpbmRpbmdzID0gW107XG4gICAgdmFyIGJpbmRpbmdSZWNvcmRzID0gW107XG4gICAgdmFyIGRpcmVjdGl2ZVJlY29yZHMgPSBbXTtcbiAgICB2YXIgZXZlbnRSZWNvcmRzID0gW107XG5cbiAgICB2YXIgZGlyUmVjb3JkV2l0aERlZmF1bHQgPSBuZXcgRGlyZWN0aXZlUmVjb3JkKHtcbiAgICAgIGRpcmVjdGl2ZUluZGV4OiBuZXcgRGlyZWN0aXZlSW5kZXgoMCwgMCksXG4gICAgICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5LkRlZmF1bHRcbiAgICB9KTtcbiAgICB2YXIgZGlyUmVjb3JkV2l0aE9uUHVzaCA9IG5ldyBEaXJlY3RpdmVSZWNvcmQoe1xuICAgICAgZGlyZWN0aXZlSW5kZXg6IG5ldyBEaXJlY3RpdmVJbmRleCgwLCAxKSxcbiAgICAgIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoXG4gICAgfSk7XG5cbiAgICBpZiAodGhpcy5fd2l0aFJlY29yZHMpIHtcbiAgICAgIHZhciB1cGRhdGVEaXJXaXRoT25EZWZhdWx0UmVjb3JkID1cbiAgICAgICAgICBCaW5kaW5nUmVjb3JkLmNyZWF0ZUZvckRpcmVjdGl2ZShfZ2V0UGFyc2VyKCkucGFyc2VCaW5kaW5nKCc0MicsICdsb2NhdGlvbicpLCAnYScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKG8sIHYpID0+ICg8YW55Pm8pLmEgPSB2LCBkaXJSZWNvcmRXaXRoRGVmYXVsdCk7XG4gICAgICB2YXIgdXBkYXRlRGlyV2l0aE9uUHVzaFJlY29yZCA9XG4gICAgICAgICAgQmluZGluZ1JlY29yZC5jcmVhdGVGb3JEaXJlY3RpdmUoX2dldFBhcnNlcigpLnBhcnNlQmluZGluZygnNDInLCAnbG9jYXRpb24nKSwgJ2EnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChvLCB2KSA9PiAoPGFueT5vKS5hID0gdiwgZGlyUmVjb3JkV2l0aE9uUHVzaCk7XG5cbiAgICAgIGRpcmVjdGl2ZVJlY29yZHMgPSBbZGlyUmVjb3JkV2l0aERlZmF1bHQsIGRpclJlY29yZFdpdGhPblB1c2hdO1xuICAgICAgYmluZGluZ1JlY29yZHMgPSBbdXBkYXRlRGlyV2l0aE9uRGVmYXVsdFJlY29yZCwgdXBkYXRlRGlyV2l0aE9uUHVzaFJlY29yZF07XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuX3dpdGhFdmVudHMpIHtcbiAgICAgIGRpcmVjdGl2ZVJlY29yZHMgPSBbZGlyUmVjb3JkV2l0aERlZmF1bHQsIGRpclJlY29yZFdpdGhPblB1c2hdO1xuICAgICAgZXZlbnRSZWNvcmRzID1cbiAgICAgICAgICBMaXN0V3JhcHBlci5jb25jYXQoX2NyZWF0ZUV2ZW50UmVjb3JkcyhcIihldmVudCk9J2ZhbHNlJ1wiKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2NyZWF0ZUhvc3RFdmVudFJlY29yZHMoXCIoaG9zdC1ldmVudCk9J2ZhbHNlJ1wiLCBkaXJSZWNvcmRXaXRoT25QdXNoKSlcbiAgICB9XG5cbiAgICB2YXIgZ2VuQ29uZmlnID0gbmV3IENoYW5nZURldGVjdG9yR2VuQ29uZmlnKHRydWUsIHRydWUsIHRydWUpO1xuXG4gICAgcmV0dXJuIG5ldyBDaGFuZ2VEZXRlY3RvckRlZmluaXRpb24oJyhlbXB0eSBpZCknLCB0aGlzLl9zdHJhdGVneSwgdmFyaWFibGVCaW5kaW5ncyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiaW5kaW5nUmVjb3JkcywgZXZlbnRSZWNvcmRzLCBkaXJlY3RpdmVSZWNvcmRzLCBnZW5Db25maWcpO1xuICB9XG5cbiAgLyoqXG4gICAqIE1hcCBmcm9tIHRlc3QgaWQgdG8gX0V4cHJlc3Npb25XaXRoTW9kZS5cbiAgICogRGVmaW5pdGlvbnMgaW4gdGhpcyBtYXAgZGVmaW5lIGNvbmRpdGlvbnMgd2hpY2ggYWxsb3cgdGVzdGluZyB2YXJpb3VzIGNoYW5nZSBkZXRlY3RvciBtb2Rlcy5cbiAgICovXG4gIHN0YXRpYyBhdmFpbGFibGVEZWZpbml0aW9uczoge1trZXk6IHN0cmluZ106IF9FeHByZXNzaW9uV2l0aE1vZGV9ID0ge1xuICAgICdlbXB0eVVzaW5nRGVmYXVsdFN0cmF0ZWd5JzpcbiAgICAgICAgbmV3IF9FeHByZXNzaW9uV2l0aE1vZGUoQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuRGVmYXVsdCwgZmFsc2UsIGZhbHNlKSxcbiAgICAnZW1wdHlVc2luZ09uUHVzaFN0cmF0ZWd5JzpcbiAgICAgICAgbmV3IF9FeHByZXNzaW9uV2l0aE1vZGUoQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLCBmYWxzZSwgZmFsc2UpLFxuICAgICdvblB1c2hSZWNvcmRzVXNpbmdEZWZhdWx0U3RyYXRlZ3knOlxuICAgICAgICBuZXcgX0V4cHJlc3Npb25XaXRoTW9kZShDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5EZWZhdWx0LCB0cnVlLCBmYWxzZSksXG4gICAgJ29uUHVzaFdpdGhFdmVudCc6IG5ldyBfRXhwcmVzc2lvbldpdGhNb2RlKENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCwgZmFsc2UsIHRydWUpLFxuICAgICdvblB1c2hXaXRoSG9zdEV2ZW50JzogbmV3IF9FeHByZXNzaW9uV2l0aE1vZGUoQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLCBmYWxzZSwgdHJ1ZSlcbiAgfTtcbn1cblxuY2xhc3MgX0RpcmVjdGl2ZVVwZGF0aW5nIHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBfYmluZGluZ1JlY29yZHM6IEJpbmRpbmdSZWNvcmRbXSxcbiAgICAgICAgICAgICAgcHJpdmF0ZSBfZGlyZWN0aXZlUmVjb3JkczogRGlyZWN0aXZlUmVjb3JkW10pIHt9XG5cbiAgY3JlYXRlQ2hhbmdlRGV0ZWN0b3JEZWZpbml0aW9uKCk6IENoYW5nZURldGVjdG9yRGVmaW5pdGlvbiB7XG4gICAgdmFyIHN0cmF0ZWd5ID0gbnVsbDtcbiAgICB2YXIgdmFyaWFibGVCaW5kaW5ncyA9IFtdO1xuICAgIHZhciBnZW5Db25maWcgPSBuZXcgQ2hhbmdlRGV0ZWN0b3JHZW5Db25maWcodHJ1ZSwgdHJ1ZSwgdHJ1ZSk7XG5cbiAgICByZXR1cm4gbmV3IENoYW5nZURldGVjdG9yRGVmaW5pdGlvbignKGVtcHR5IGlkKScsIHN0cmF0ZWd5LCB2YXJpYWJsZUJpbmRpbmdzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2JpbmRpbmdSZWNvcmRzLCBbXSwgdGhpcy5fZGlyZWN0aXZlUmVjb3JkcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnZW5Db25maWcpO1xuICB9XG5cbiAgc3RhdGljIHVwZGF0ZUEoZXhwcmVzc2lvbjogc3RyaW5nLCBkaXJSZWNvcmQpOiBCaW5kaW5nUmVjb3JkIHtcbiAgICByZXR1cm4gQmluZGluZ1JlY29yZC5jcmVhdGVGb3JEaXJlY3RpdmUoX2dldFBhcnNlcigpLnBhcnNlQmluZGluZyhleHByZXNzaW9uLCAnbG9jYXRpb24nKSwgJ2EnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAobywgdikgPT4gKDxhbnk+bykuYSA9IHYsIGRpclJlY29yZCk7XG4gIH1cblxuICBzdGF0aWMgdXBkYXRlQihleHByZXNzaW9uOiBzdHJpbmcsIGRpclJlY29yZCk6IEJpbmRpbmdSZWNvcmQge1xuICAgIHJldHVybiBCaW5kaW5nUmVjb3JkLmNyZWF0ZUZvckRpcmVjdGl2ZShfZ2V0UGFyc2VyKCkucGFyc2VCaW5kaW5nKGV4cHJlc3Npb24sICdsb2NhdGlvbicpLCAnYicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChvLCB2KSA9PiAoPGFueT5vKS5iID0gdiwgZGlyUmVjb3JkKTtcbiAgfVxuXG4gIHN0YXRpYyBiYXNpY1JlY29yZHM6IERpcmVjdGl2ZVJlY29yZFtdID0gW1xuICAgIG5ldyBEaXJlY3RpdmVSZWNvcmQoe1xuICAgICAgZGlyZWN0aXZlSW5kZXg6IG5ldyBEaXJlY3RpdmVJbmRleCgwLCAwKSxcbiAgICAgIGNhbGxPbkNoYW5nZXM6IHRydWUsXG4gICAgICBjYWxsRG9DaGVjazogdHJ1ZSxcbiAgICAgIGNhbGxPbkluaXQ6IHRydWUsXG4gICAgICBjYWxsQWZ0ZXJDb250ZW50SW5pdDogdHJ1ZSxcbiAgICAgIGNhbGxBZnRlckNvbnRlbnRDaGVja2VkOiB0cnVlLFxuICAgICAgY2FsbEFmdGVyVmlld0luaXQ6IHRydWUsXG4gICAgICBjYWxsQWZ0ZXJWaWV3Q2hlY2tlZDogdHJ1ZSxcbiAgICAgIGNhbGxPbkRlc3Ryb3k6IHRydWUsXG4gICAgICBvdXRwdXRzOiBbWydldmVudEVtaXR0ZXInLCAnaG9zdC1ldmVudCddXVxuICAgIH0pLFxuICAgIG5ldyBEaXJlY3RpdmVSZWNvcmQoe1xuICAgICAgZGlyZWN0aXZlSW5kZXg6IG5ldyBEaXJlY3RpdmVJbmRleCgwLCAxKSxcbiAgICAgIGNhbGxPbkNoYW5nZXM6IHRydWUsXG4gICAgICBjYWxsRG9DaGVjazogdHJ1ZSxcbiAgICAgIGNhbGxPbkluaXQ6IHRydWUsXG4gICAgICBjYWxsQWZ0ZXJDb250ZW50SW5pdDogdHJ1ZSxcbiAgICAgIGNhbGxBZnRlckNvbnRlbnRDaGVja2VkOiB0cnVlLFxuICAgICAgY2FsbEFmdGVyVmlld0luaXQ6IHRydWUsXG4gICAgICBjYWxsQWZ0ZXJWaWV3Q2hlY2tlZDogdHJ1ZSxcbiAgICAgIGNhbGxPbkRlc3Ryb3k6IHRydWUsXG4gICAgICBvdXRwdXRzOiBbWydldmVudEVtaXR0ZXInLCAnaG9zdC1ldmVudCddXVxuICAgIH0pXG4gIF07XG5cbiAgc3RhdGljIHJlY29yZE5vQ2FsbGJhY2tzID0gbmV3IERpcmVjdGl2ZVJlY29yZCh7XG4gICAgZGlyZWN0aXZlSW5kZXg6IG5ldyBEaXJlY3RpdmVJbmRleCgwLCAwKSxcbiAgICBjYWxsT25DaGFuZ2VzOiBmYWxzZSxcbiAgICBjYWxsRG9DaGVjazogZmFsc2UsXG4gICAgY2FsbE9uSW5pdDogZmFsc2UsXG4gICAgY2FsbEFmdGVyQ29udGVudEluaXQ6IGZhbHNlLFxuICAgIGNhbGxBZnRlckNvbnRlbnRDaGVja2VkOiBmYWxzZSxcbiAgICBjYWxsQWZ0ZXJWaWV3SW5pdDogZmFsc2UsXG4gICAgY2FsbEFmdGVyVmlld0NoZWNrZWQ6IGZhbHNlXG4gIH0pO1xuXG4gIC8qKlxuICAgKiBNYXAgZnJvbSB0ZXN0IGlkIHRvIF9EaXJlY3RpdmVVcGRhdGluZy5cbiAgICogRGVmaW5pdGlvbnMgaW4gdGhpcyBtYXAgZGVmaW5lIGRlZmluaXRpb25zIHdoaWNoIGFsbG93IHRlc3RpbmcgZGlyZWN0aXZlIHVwZGF0aW5nLlxuICAgKi9cbiAgc3RhdGljIGF2YWlsYWJsZURlZmluaXRpb25zOiB7W2tleTogc3RyaW5nXTogX0RpcmVjdGl2ZVVwZGF0aW5nfSA9IHtcbiAgICAnZGlyZWN0Tm9EaXNwYXRjaGVyJzogbmV3IF9EaXJlY3RpdmVVcGRhdGluZyhcbiAgICAgICAgW19EaXJlY3RpdmVVcGRhdGluZy51cGRhdGVBKCc0MicsIF9EaXJlY3RpdmVVcGRhdGluZy5iYXNpY1JlY29yZHNbMF0pXSxcbiAgICAgICAgW19EaXJlY3RpdmVVcGRhdGluZy5iYXNpY1JlY29yZHNbMF1dKSxcbiAgICAnZ3JvdXBDaGFuZ2VzJzpcbiAgICAgICAgbmV3IF9EaXJlY3RpdmVVcGRhdGluZyhcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgX0RpcmVjdGl2ZVVwZGF0aW5nLnVwZGF0ZUEoJzEnLCBfRGlyZWN0aXZlVXBkYXRpbmcuYmFzaWNSZWNvcmRzWzBdKSxcbiAgICAgICAgICAgICAgX0RpcmVjdGl2ZVVwZGF0aW5nLnVwZGF0ZUIoJzInLCBfRGlyZWN0aXZlVXBkYXRpbmcuYmFzaWNSZWNvcmRzWzBdKSxcbiAgICAgICAgICAgICAgQmluZGluZ1JlY29yZC5jcmVhdGVEaXJlY3RpdmVPbkNoYW5nZXMoX0RpcmVjdGl2ZVVwZGF0aW5nLmJhc2ljUmVjb3Jkc1swXSksXG4gICAgICAgICAgICAgIF9EaXJlY3RpdmVVcGRhdGluZy51cGRhdGVBKCczJywgX0RpcmVjdGl2ZVVwZGF0aW5nLmJhc2ljUmVjb3Jkc1sxXSksXG4gICAgICAgICAgICAgIEJpbmRpbmdSZWNvcmQuY3JlYXRlRGlyZWN0aXZlT25DaGFuZ2VzKF9EaXJlY3RpdmVVcGRhdGluZy5iYXNpY1JlY29yZHNbMV0pXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgW19EaXJlY3RpdmVVcGRhdGluZy5iYXNpY1JlY29yZHNbMF0sIF9EaXJlY3RpdmVVcGRhdGluZy5iYXNpY1JlY29yZHNbMV1dKSxcbiAgICAnZGlyZWN0aXZlRG9DaGVjayc6IG5ldyBfRGlyZWN0aXZlVXBkYXRpbmcoXG4gICAgICAgIFtCaW5kaW5nUmVjb3JkLmNyZWF0ZURpcmVjdGl2ZURvQ2hlY2soX0RpcmVjdGl2ZVVwZGF0aW5nLmJhc2ljUmVjb3Jkc1swXSldLFxuICAgICAgICBbX0RpcmVjdGl2ZVVwZGF0aW5nLmJhc2ljUmVjb3Jkc1swXV0pLFxuICAgICdkaXJlY3RpdmVPbkluaXQnOiBuZXcgX0RpcmVjdGl2ZVVwZGF0aW5nKFxuICAgICAgICBbQmluZGluZ1JlY29yZC5jcmVhdGVEaXJlY3RpdmVPbkluaXQoX0RpcmVjdGl2ZVVwZGF0aW5nLmJhc2ljUmVjb3Jkc1swXSldLFxuICAgICAgICBbX0RpcmVjdGl2ZVVwZGF0aW5nLmJhc2ljUmVjb3Jkc1swXV0pLFxuICAgICdlbXB0eVdpdGhEaXJlY3RpdmVSZWNvcmRzJzogbmV3IF9EaXJlY3RpdmVVcGRhdGluZyhcbiAgICAgICAgW10sIFtfRGlyZWN0aXZlVXBkYXRpbmcuYmFzaWNSZWNvcmRzWzBdLCBfRGlyZWN0aXZlVXBkYXRpbmcuYmFzaWNSZWNvcmRzWzFdXSksXG4gICAgJ25vQ2FsbGJhY2tzJzogbmV3IF9EaXJlY3RpdmVVcGRhdGluZyhcbiAgICAgICAgW19EaXJlY3RpdmVVcGRhdGluZy51cGRhdGVBKCcxJywgX0RpcmVjdGl2ZVVwZGF0aW5nLnJlY29yZE5vQ2FsbGJhY2tzKV0sXG4gICAgICAgIFtfRGlyZWN0aXZlVXBkYXRpbmcucmVjb3JkTm9DYWxsYmFja3NdKSxcbiAgICAncmVhZGluZ0RpcmVjdGl2ZXMnOlxuICAgICAgICBuZXcgX0RpcmVjdGl2ZVVwZGF0aW5nKFxuICAgICAgICAgICAgW1xuICAgICAgICAgICAgICBCaW5kaW5nUmVjb3JkLmNyZWF0ZUZvckhvc3RQcm9wZXJ0eShcbiAgICAgICAgICAgICAgICAgIG5ldyBEaXJlY3RpdmVJbmRleCgwLCAwKSwgX2dldFBhcnNlcigpLnBhcnNlQmluZGluZygnYScsICdsb2NhdGlvbicpLCBQUk9QX05BTUUpXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgW19EaXJlY3RpdmVVcGRhdGluZy5iYXNpY1JlY29yZHNbMF1dKSxcbiAgICAnaW50ZXJwb2xhdGlvbic6XG4gICAgICAgIG5ldyBfRGlyZWN0aXZlVXBkYXRpbmcoXG4gICAgICAgICAgICBbXG4gICAgICAgICAgICAgIEJpbmRpbmdSZWNvcmQuY3JlYXRlRm9yRWxlbWVudFByb3BlcnR5KFxuICAgICAgICAgICAgICAgICAgX2dldFBhcnNlcigpLnBhcnNlSW50ZXJwb2xhdGlvbignQnt7YX19QScsICdsb2NhdGlvbicpLCAwLCBQUk9QX05BTUUpXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgW10pXG4gIH07XG59XG5cbi8qKlxuICogVGhlIGxpc3Qgb2YgYWxsIHRlc3QgZGVmaW5pdGlvbnMgdGhpcyBjb25maWcgc3VwcGxpZXMuXG4gKiBJdGVtcyBpbiB0aGlzIGxpc3QgdGhhdCBkbyBub3QgYXBwZWFyIGluIG90aGVyIHN0cnVjdHVyZXMgZGVmaW5lIHRlc3RzIHdpdGggZXhwcmVzc2lvbnNcbiAqIGVxdWl2YWxlbnQgdG8gdGhlaXIgaWRzLlxuICovXG52YXIgX2F2YWlsYWJsZURlZmluaXRpb25zID0gW1xuICAnXCIkXCInLFxuICAnMTAnLFxuICAnXCJzdHJcIicsXG4gICdcImFcXG5cXG5iXCInLFxuICAnMTAgKyAyJyxcbiAgJzEwIC0gMicsXG4gICcxMCAqIDInLFxuICAnMTAgLyAyJyxcbiAgJzExICUgMicsXG4gICcxID09IDEnLFxuICAnMSAhPSAxJyxcbiAgJzEgPT0gdHJ1ZScsXG4gICcxID09PSAxJyxcbiAgJzEgIT09IDEnLFxuICAnMSA9PT0gdHJ1ZScsXG4gICcxIDwgMicsXG4gICcyIDwgMScsXG4gICcxID4gMicsXG4gICcyID4gMScsXG4gICcxIDw9IDInLFxuICAnMiA8PSAyJyxcbiAgJzIgPD0gMScsXG4gICcyID49IDEnLFxuICAnMiA+PSAyJyxcbiAgJzEgPj0gMicsXG4gICd0cnVlICYmIHRydWUnLFxuICAndHJ1ZSAmJiBmYWxzZScsXG4gICd0cnVlIHx8IGZhbHNlJyxcbiAgJ2ZhbHNlIHx8IGZhbHNlJyxcbiAgJyF0cnVlJyxcbiAgJyEhdHJ1ZScsXG4gICcxIDwgMiA/IDEgOiAyJyxcbiAgJzEgPiAyID8gMSA6IDInLFxuICAnW1wiZm9vXCIsIFwiYmFyXCJdWzBdJyxcbiAgJ3tcImZvb1wiOiBcImJhclwifVtcImZvb1wiXScsXG4gICduYW1lJyxcbiAgJ1sxLCAyXScsXG4gICdbMSwgYV0nLFxuICAne3o6IDF9JyxcbiAgJ3t6OiBhfScsXG4gICduYW1lIHwgcGlwZScsXG4gICcobmFtZSB8IHBpcGUpLmxlbmd0aCcsXG4gIFwibmFtZSB8IHBpcGU6J29uZSc6YWRkcmVzcy5jaXR5XCIsXG4gIFwibmFtZSB8IHBpcGU6J2EnOidiJyB8IHBpcGU6MDoxOjJcIixcbiAgJ3ZhbHVlJyxcbiAgJ2EnLFxuICAnYWRkcmVzcy5jaXR5JyxcbiAgJ2FkZHJlc3M/LmNpdHknLFxuICAnYWRkcmVzcz8udG9TdHJpbmcoKScsXG4gICdzYXlIaShcIkppbVwiKScsXG4gICdhKCkoOTkpJyxcbiAgJ2Euc2F5SGkoXCJKaW1cIiknLFxuICAncGFzc1Rocm91Z2goWzEyXSknLFxuICAnaW52YWxpZEZuKDEpJyxcbiAgJ2FnZScsXG4gICd0cnVlID8gY2l0eSA6IHppcGNvZGUnLFxuICAnZmFsc2UgPyBjaXR5IDogemlwY29kZScsXG4gICdnZXRUcnVlKCkgJiYgZ2V0VHJ1ZSgpJyxcbiAgJ2dldEZhbHNlKCkgJiYgZ2V0VHJ1ZSgpJyxcbiAgJ2dldEZhbHNlKCkgfHwgZ2V0RmFsc2UoKScsXG4gICdnZXRUcnVlKCkgfHwgZ2V0RmFsc2UoKScsXG4gICduYW1lID09IFwiVmljdG9yXCIgPyAodHJ1ZSA/IGFkZHJlc3MuY2l0eSA6IGFkZHJlc3MuemlwY29kZSkgOiBhZGRyZXNzLnppcGNvZGUnXG5dO1xuXG52YXIgX2F2YWlsYWJsZUV2ZW50RGVmaW5pdGlvbnMgPSBbXG4gICcoZXZlbnQpPVwib25FdmVudChcXCRldmVudClcIicsXG4gICcoZXZlbnQpPVwiYj1hPVxcJGV2ZW50XCInLFxuICAnKGV2ZW50KT1cImFbMF09XFwkZXZlbnRcIicsXG4gIC8vICcoZXZlbnQpPVwiXFwkZXZlbnQ9MVwiJyxcbiAgJyhldmVudCk9XCJhPWErMTsgYT1hKzE7XCInLFxuICAnKGV2ZW50KT1cInRydWU7IGZhbHNlXCInLFxuICAnKGV2ZW50KT1cImZhbHNlXCInLFxuICAnKGV2ZW50KT1cInRydWVcIicsXG4gICcoZXZlbnQpPVwidHJ1ZSA/IGEgPSBhICsgMSA6IGEgPSBhICsgMVwiJyxcbl07XG5cbnZhciBfYXZhaWxhYmxlSG9zdEV2ZW50RGVmaW5pdGlvbnMgPSBbJyhob3N0LWV2ZW50KT1cIm9uRXZlbnQoXFwkZXZlbnQpXCInXTtcbiJdfQ==