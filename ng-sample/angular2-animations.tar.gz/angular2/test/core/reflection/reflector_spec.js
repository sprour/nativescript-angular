'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var testing_internal_1 = require('angular2/testing_internal');
var reflection_1 = require('angular2/src/core/reflection/reflection');
var reflection_capabilities_1 = require('angular2/src/core/reflection/reflection_capabilities');
var reflector_common_1 = require('./reflector_common');
var lang_1 = require('angular2/src/facade/lang');
var AType = (function () {
    function AType(value) {
        this.value = value;
    }
    return AType;
})();
var ClassWithDecorators = (function () {
    function ClassWithDecorators(a, b) {
        this.a = a;
        this.b = b;
    }
    Object.defineProperty(ClassWithDecorators.prototype, "c", {
        set: function (value) {
        },
        enumerable: true,
        configurable: true
    });
    __decorate([
        reflector_common_1.PropDecorator("p1"),
        reflector_common_1.PropDecorator("p2"), 
        __metadata('design:type', Object)
    ], ClassWithDecorators.prototype, "a", void 0);
    __decorate([
        reflector_common_1.PropDecorator("p3"), 
        __metadata('design:type', Object), 
        __metadata('design:paramtypes', [Object])
    ], ClassWithDecorators.prototype, "c", null);
    ClassWithDecorators = __decorate([
        reflector_common_1.ClassDecorator('class'),
        __param(0, reflector_common_1.ParamDecorator("a")),
        __param(1, reflector_common_1.ParamDecorator("b")), 
        __metadata('design:paramtypes', [AType, AType])
    ], ClassWithDecorators);
    return ClassWithDecorators;
})();
var ClassWithoutDecorators = (function () {
    function ClassWithoutDecorators(a, b) {
    }
    return ClassWithoutDecorators;
})();
var TestObj = (function () {
    function TestObj(a, b) {
        this.a = a;
        this.b = b;
    }
    TestObj.prototype.identity = function (arg) { return arg; };
    return TestObj;
})();
var Interface = (function () {
    function Interface() {
    }
    return Interface;
})();
var Interface2 = (function () {
    function Interface2() {
    }
    return Interface2;
})();
var SuperClassImplementingInterface = (function () {
    function SuperClassImplementingInterface() {
    }
    return SuperClassImplementingInterface;
})();
var ClassImplementingInterface = (function (_super) {
    __extends(ClassImplementingInterface, _super);
    function ClassImplementingInterface() {
        _super.apply(this, arguments);
    }
    return ClassImplementingInterface;
})(SuperClassImplementingInterface);
// Classes used to test our runtime check for classes that implement lifecycle interfaces but do not
// declare them.
// See https://github.com/angular/angular/pull/6879 and https://goo.gl/b07Kii for details.
var ClassDoesNotDeclareOnInit = (function () {
    function ClassDoesNotDeclareOnInit() {
    }
    ClassDoesNotDeclareOnInit.prototype.ngOnInit = function () { };
    return ClassDoesNotDeclareOnInit;
})();
var SuperClassImplementingOnInit = (function () {
    function SuperClassImplementingOnInit() {
    }
    SuperClassImplementingOnInit.prototype.ngOnInit = function () { };
    return SuperClassImplementingOnInit;
})();
var SubClassDoesNotDeclareOnInit = (function (_super) {
    __extends(SubClassDoesNotDeclareOnInit, _super);
    function SubClassDoesNotDeclareOnInit() {
        _super.apply(this, arguments);
    }
    return SubClassDoesNotDeclareOnInit;
})(SuperClassImplementingOnInit);
function main() {
    testing_internal_1.describe('Reflector', function () {
        var reflector;
        testing_internal_1.beforeEach(function () { reflector = new reflection_1.Reflector(new reflection_capabilities_1.ReflectionCapabilities()); });
        testing_internal_1.describe("usage tracking", function () {
            testing_internal_1.beforeEach(function () { reflector = new reflection_1.Reflector(null); });
            testing_internal_1.it("should be disabled by default", function () {
                testing_internal_1.expect(function () { return reflector.listUnusedKeys(); }).toThrowError('Usage tracking is disabled');
            });
            testing_internal_1.it("should report unused keys", function () {
                reflector.trackUsage();
                testing_internal_1.expect(reflector.listUnusedKeys()).toEqual([]);
                reflector.registerType(AType, new reflection_1.ReflectionInfo(null, null, function () { return "AType"; }));
                reflector.registerType(TestObj, new reflection_1.ReflectionInfo(null, null, function () { return "TestObj"; }));
                testing_internal_1.expect(reflector.listUnusedKeys()).toEqual([AType, TestObj]);
                reflector.factory(AType);
                testing_internal_1.expect(reflector.listUnusedKeys()).toEqual([TestObj]);
                reflector.factory(TestObj);
                testing_internal_1.expect(reflector.listUnusedKeys()).toEqual([]);
            });
        });
        testing_internal_1.describe("factory", function () {
            testing_internal_1.it("should create a factory for the given type", function () {
                var obj = reflector.factory(TestObj)(1, 2);
                testing_internal_1.expect(obj.a).toEqual(1);
                testing_internal_1.expect(obj.b).toEqual(2);
            });
            // Makes Edge to disconnect when running the full unit test campaign
            // TODO: remove when issue is solved: https://github.com/angular/angular/issues/4756
            if (!testing_internal_1.browserDetection.isEdge) {
                testing_internal_1.it("should check args from no to max", function () {
                    var f = function (t) { return reflector.factory(t); };
                    var checkArgs = function (obj, args) { return testing_internal_1.expect(obj.args).toEqual(args); };
                    // clang-format off
                    checkArgs(f(TestObjWith00Args)(), []);
                    checkArgs(f(TestObjWith01Args)(1), [1]);
                    checkArgs(f(TestObjWith02Args)(1, 2), [1, 2]);
                    checkArgs(f(TestObjWith03Args)(1, 2, 3), [1, 2, 3]);
                    checkArgs(f(TestObjWith04Args)(1, 2, 3, 4), [1, 2, 3, 4]);
                    checkArgs(f(TestObjWith05Args)(1, 2, 3, 4, 5), [1, 2, 3, 4, 5]);
                    checkArgs(f(TestObjWith06Args)(1, 2, 3, 4, 5, 6), [1, 2, 3, 4, 5, 6]);
                    checkArgs(f(TestObjWith07Args)(1, 2, 3, 4, 5, 6, 7), [1, 2, 3, 4, 5, 6, 7]);
                    checkArgs(f(TestObjWith08Args)(1, 2, 3, 4, 5, 6, 7, 8), [1, 2, 3, 4, 5, 6, 7, 8]);
                    checkArgs(f(TestObjWith09Args)(1, 2, 3, 4, 5, 6, 7, 8, 9), [1, 2, 3, 4, 5, 6, 7, 8, 9]);
                    checkArgs(f(TestObjWith10Args)(1, 2, 3, 4, 5, 6, 7, 8, 9, 10), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
                    checkArgs(f(TestObjWith11Args)(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]);
                    checkArgs(f(TestObjWith12Args)(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]);
                    checkArgs(f(TestObjWith13Args)(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]);
                    checkArgs(f(TestObjWith14Args)(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]);
                    checkArgs(f(TestObjWith15Args)(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);
                    checkArgs(f(TestObjWith16Args)(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]);
                    checkArgs(f(TestObjWith17Args)(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17]);
                    checkArgs(f(TestObjWith18Args)(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18]);
                    checkArgs(f(TestObjWith19Args)(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]);
                    checkArgs(f(TestObjWith20Args)(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]);
                    // clang-format on
                });
            }
            testing_internal_1.it("should throw when more than 20 arguments", function () { testing_internal_1.expect(function () { return reflector.factory(TestObjWith21Args); }).toThrowError(); });
            testing_internal_1.it("should return a registered factory if available", function () {
                reflector.registerType(TestObj, new reflection_1.ReflectionInfo(null, null, function () { return "fake"; }));
                testing_internal_1.expect(reflector.factory(TestObj)()).toEqual("fake");
            });
        });
        testing_internal_1.describe("parameters", function () {
            testing_internal_1.it("should return an array of parameters for a type", function () {
                var p = reflector.parameters(ClassWithDecorators);
                testing_internal_1.expect(p).toEqual([[AType, reflector_common_1.paramDecorator('a')], [AType, reflector_common_1.paramDecorator('b')]]);
            });
            testing_internal_1.it("should work for a class without annotations", function () {
                var p = reflector.parameters(ClassWithoutDecorators);
                testing_internal_1.expect(p.length).toEqual(2);
            });
            testing_internal_1.it("should return registered parameters if available", function () {
                reflector.registerType(TestObj, new reflection_1.ReflectionInfo(null, [[1], [2]]));
                testing_internal_1.expect(reflector.parameters(TestObj)).toEqual([[1], [2]]);
            });
            testing_internal_1.it("should return an empty list when no parameters field in the stored type info", function () {
                reflector.registerType(TestObj, new reflection_1.ReflectionInfo());
                testing_internal_1.expect(reflector.parameters(TestObj)).toEqual([]);
            });
        });
        testing_internal_1.describe("propMetadata", function () {
            testing_internal_1.it("should return a string map of prop metadata for the given class", function () {
                var p = reflector.propMetadata(ClassWithDecorators);
                testing_internal_1.expect(p["a"]).toEqual([reflector_common_1.propDecorator("p1"), reflector_common_1.propDecorator("p2")]);
                testing_internal_1.expect(p["c"]).toEqual([reflector_common_1.propDecorator("p3")]);
            });
            testing_internal_1.it("should return registered meta if available", function () {
                reflector.registerType(TestObj, new reflection_1.ReflectionInfo(null, null, null, null, { "a": [1, 2] }));
                testing_internal_1.expect(reflector.propMetadata(TestObj)).toEqual({ "a": [1, 2] });
            });
            if (lang_1.IS_DART) {
                testing_internal_1.it("should merge metadata from getters and setters", function () {
                    var p = reflector.propMetadata(reflector_common_1.HasGetterAndSetterDecorators);
                    testing_internal_1.expect(p["a"]).toEqual([reflector_common_1.propDecorator("get"), reflector_common_1.propDecorator("set")]);
                });
            }
        });
        testing_internal_1.describe("annotations", function () {
            testing_internal_1.it("should return an array of annotations for a type", function () {
                var p = reflector.annotations(ClassWithDecorators);
                testing_internal_1.expect(p).toEqual([reflector_common_1.classDecorator('class')]);
            });
            testing_internal_1.it("should return registered annotations if available", function () {
                reflector.registerType(TestObj, new reflection_1.ReflectionInfo([1, 2]));
                testing_internal_1.expect(reflector.annotations(TestObj)).toEqual([1, 2]);
            });
            testing_internal_1.it("should work for a class without annotations", function () {
                var p = reflector.annotations(ClassWithoutDecorators);
                testing_internal_1.expect(p).toEqual([]);
            });
        });
        if (lang_1.IS_DART) {
            testing_internal_1.describe("interfaces", function () {
                testing_internal_1.it("should return an array of interfaces for a type", function () {
                    var p = reflector.interfaces(ClassImplementingInterface);
                    testing_internal_1.expect(p).toEqual([Interface, Interface2]);
                });
                testing_internal_1.it("should return an empty array otherwise", function () {
                    var p = reflector.interfaces(ClassWithDecorators);
                    testing_internal_1.expect(p).toEqual([]);
                });
                testing_internal_1.it("should throw for undeclared lifecycle interfaces", function () { testing_internal_1.expect(function () { return reflector.interfaces(ClassDoesNotDeclareOnInit); }).toThrowError(); });
                testing_internal_1.it("should throw for class inheriting a lifecycle impl and not declaring the interface", function () {
                    testing_internal_1.expect(function () { return reflector.interfaces(SubClassDoesNotDeclareOnInit); }).toThrowError();
                });
            });
        }
        testing_internal_1.describe("getter", function () {
            testing_internal_1.it("returns a function reading a property", function () {
                var getA = reflector.getter('a');
                testing_internal_1.expect(getA(new TestObj(1, 2))).toEqual(1);
            });
            testing_internal_1.it("should return a registered getter if available", function () {
                reflector.registerGetters({ "abc": function (obj) { return "fake"; } });
                testing_internal_1.expect(reflector.getter("abc")("anything")).toEqual("fake");
            });
        });
        testing_internal_1.describe("setter", function () {
            testing_internal_1.it("returns a function setting a property", function () {
                var setA = reflector.setter('a');
                var obj = new TestObj(1, 2);
                setA(obj, 100);
                testing_internal_1.expect(obj.a).toEqual(100);
            });
            testing_internal_1.it("should return a registered setter if available", function () {
                var updateMe;
                reflector.registerSetters({ "abc": function (obj, value) { updateMe = value; } });
                reflector.setter("abc")("anything", "fake");
                testing_internal_1.expect(updateMe).toEqual("fake");
            });
        });
        testing_internal_1.describe("method", function () {
            testing_internal_1.it("returns a function invoking a method", function () {
                var func = reflector.method('identity');
                var obj = new TestObj(1, 2);
                testing_internal_1.expect(func(obj, ['value'])).toEqual('value');
            });
            testing_internal_1.it("should return a registered method if available", function () {
                reflector.registerMethods({ "abc": function (obj, args) { return args; } });
                testing_internal_1.expect(reflector.method("abc")("anything", ["fake"])).toEqual(['fake']);
            });
        });
        if (lang_1.IS_DART) {
            testing_internal_1.describe("importUri", function () {
                testing_internal_1.it("should return the importUri for a type", function () {
                    testing_internal_1.expect(reflector.importUri(TestObjWith00Args)
                        .endsWith('test/core/reflection/reflector_spec.dart'))
                        .toBe(true);
                });
            });
        }
    });
}
exports.main = main;
var TestObjWith00Args = (function () {
    function TestObjWith00Args() {
        this.args = [];
    }
    return TestObjWith00Args;
})();
var TestObjWith01Args = (function () {
    function TestObjWith01Args(a1) {
        this.args = [a1];
    }
    return TestObjWith01Args;
})();
var TestObjWith02Args = (function () {
    function TestObjWith02Args(a1, a2) {
        this.args = [a1, a2];
    }
    return TestObjWith02Args;
})();
var TestObjWith03Args = (function () {
    function TestObjWith03Args(a1, a2, a3) {
        this.args = [a1, a2, a3];
    }
    return TestObjWith03Args;
})();
var TestObjWith04Args = (function () {
    function TestObjWith04Args(a1, a2, a3, a4) {
        this.args = [a1, a2, a3, a4];
    }
    return TestObjWith04Args;
})();
var TestObjWith05Args = (function () {
    function TestObjWith05Args(a1, a2, a3, a4, a5) {
        this.args = [a1, a2, a3, a4, a5];
    }
    return TestObjWith05Args;
})();
var TestObjWith06Args = (function () {
    function TestObjWith06Args(a1, a2, a3, a4, a5, a6) {
        this.args = [a1, a2, a3, a4, a5, a6];
    }
    return TestObjWith06Args;
})();
var TestObjWith07Args = (function () {
    function TestObjWith07Args(a1, a2, a3, a4, a5, a6, a7) {
        this.args = [a1, a2, a3, a4, a5, a6, a7];
    }
    return TestObjWith07Args;
})();
var TestObjWith08Args = (function () {
    function TestObjWith08Args(a1, a2, a3, a4, a5, a6, a7, a8) {
        this.args = [a1, a2, a3, a4, a5, a6, a7, a8];
    }
    return TestObjWith08Args;
})();
var TestObjWith09Args = (function () {
    function TestObjWith09Args(a1, a2, a3, a4, a5, a6, a7, a8, a9) {
        this.args = [a1, a2, a3, a4, a5, a6, a7, a8, a9];
    }
    return TestObjWith09Args;
})();
var TestObjWith10Args = (function () {
    function TestObjWith10Args(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10) {
        this.args = [a1, a2, a3, a4, a5, a6, a7, a8, a9, a10];
    }
    return TestObjWith10Args;
})();
var TestObjWith11Args = (function () {
    function TestObjWith11Args(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11) {
        this.args = [a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11];
    }
    return TestObjWith11Args;
})();
var TestObjWith12Args = (function () {
    function TestObjWith12Args(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12) {
        this.args = [a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12];
    }
    return TestObjWith12Args;
})();
var TestObjWith13Args = (function () {
    function TestObjWith13Args(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13) {
        this.args = [a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13];
    }
    return TestObjWith13Args;
})();
var TestObjWith14Args = (function () {
    function TestObjWith14Args(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14) {
        this.args = [a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14];
    }
    return TestObjWith14Args;
})();
var TestObjWith15Args = (function () {
    function TestObjWith15Args(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15) {
        this.args = [a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15];
    }
    return TestObjWith15Args;
})();
var TestObjWith16Args = (function () {
    function TestObjWith16Args(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16) {
        this.args = [a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16];
    }
    return TestObjWith16Args;
})();
var TestObjWith17Args = (function () {
    function TestObjWith17Args(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17) {
        this.args = [a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17];
    }
    return TestObjWith17Args;
})();
var TestObjWith18Args = (function () {
    function TestObjWith18Args(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18) {
        this.args = [a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18];
    }
    return TestObjWith18Args;
})();
var TestObjWith19Args = (function () {
    function TestObjWith19Args(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19) {
        this.args =
            [a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19];
    }
    return TestObjWith19Args;
})();
var TestObjWith20Args = (function () {
    function TestObjWith20Args(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20) {
        this.args =
            [a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20];
    }
    return TestObjWith20Args;
})();
var TestObjWith21Args = (function () {
    function TestObjWith21Args(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, a21) {
        this.args = [
            a1,
            a2,
            a3,
            a4,
            a5,
            a6,
            a7,
            a8,
            a9,
            a10,
            a11,
            a12,
            a13,
            a14,
            a15,
            a16,
            a17,
            a18,
            a19,
            a20,
            a21
        ];
    }
    return TestObjWith21Args;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVmbGVjdG9yX3NwZWMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L2NvcmUvcmVmbGVjdGlvbi9yZWZsZWN0b3Jfc3BlYy50cyJdLCJuYW1lcyI6WyJBVHlwZSIsIkFUeXBlLmNvbnN0cnVjdG9yIiwiQ2xhc3NXaXRoRGVjb3JhdG9ycyIsIkNsYXNzV2l0aERlY29yYXRvcnMuY29uc3RydWN0b3IiLCJDbGFzc1dpdGhEZWNvcmF0b3JzLmMiLCJDbGFzc1dpdGhvdXREZWNvcmF0b3JzIiwiQ2xhc3NXaXRob3V0RGVjb3JhdG9ycy5jb25zdHJ1Y3RvciIsIlRlc3RPYmoiLCJUZXN0T2JqLmNvbnN0cnVjdG9yIiwiVGVzdE9iai5pZGVudGl0eSIsIkludGVyZmFjZSIsIkludGVyZmFjZS5jb25zdHJ1Y3RvciIsIkludGVyZmFjZTIiLCJJbnRlcmZhY2UyLmNvbnN0cnVjdG9yIiwiU3VwZXJDbGFzc0ltcGxlbWVudGluZ0ludGVyZmFjZSIsIlN1cGVyQ2xhc3NJbXBsZW1lbnRpbmdJbnRlcmZhY2UuY29uc3RydWN0b3IiLCJDbGFzc0ltcGxlbWVudGluZ0ludGVyZmFjZSIsIkNsYXNzSW1wbGVtZW50aW5nSW50ZXJmYWNlLmNvbnN0cnVjdG9yIiwiQ2xhc3NEb2VzTm90RGVjbGFyZU9uSW5pdCIsIkNsYXNzRG9lc05vdERlY2xhcmVPbkluaXQuY29uc3RydWN0b3IiLCJDbGFzc0RvZXNOb3REZWNsYXJlT25Jbml0Lm5nT25Jbml0IiwiU3VwZXJDbGFzc0ltcGxlbWVudGluZ09uSW5pdCIsIlN1cGVyQ2xhc3NJbXBsZW1lbnRpbmdPbkluaXQuY29uc3RydWN0b3IiLCJTdXBlckNsYXNzSW1wbGVtZW50aW5nT25Jbml0Lm5nT25Jbml0IiwiU3ViQ2xhc3NEb2VzTm90RGVjbGFyZU9uSW5pdCIsIlN1YkNsYXNzRG9lc05vdERlY2xhcmVPbkluaXQuY29uc3RydWN0b3IiLCJtYWluIiwiVGVzdE9ialdpdGgwMEFyZ3MiLCJUZXN0T2JqV2l0aDAwQXJncy5jb25zdHJ1Y3RvciIsIlRlc3RPYmpXaXRoMDFBcmdzIiwiVGVzdE9ialdpdGgwMUFyZ3MuY29uc3RydWN0b3IiLCJUZXN0T2JqV2l0aDAyQXJncyIsIlRlc3RPYmpXaXRoMDJBcmdzLmNvbnN0cnVjdG9yIiwiVGVzdE9ialdpdGgwM0FyZ3MiLCJUZXN0T2JqV2l0aDAzQXJncy5jb25zdHJ1Y3RvciIsIlRlc3RPYmpXaXRoMDRBcmdzIiwiVGVzdE9ialdpdGgwNEFyZ3MuY29uc3RydWN0b3IiLCJUZXN0T2JqV2l0aDA1QXJncyIsIlRlc3RPYmpXaXRoMDVBcmdzLmNvbnN0cnVjdG9yIiwiVGVzdE9ialdpdGgwNkFyZ3MiLCJUZXN0T2JqV2l0aDA2QXJncy5jb25zdHJ1Y3RvciIsIlRlc3RPYmpXaXRoMDdBcmdzIiwiVGVzdE9ialdpdGgwN0FyZ3MuY29uc3RydWN0b3IiLCJUZXN0T2JqV2l0aDA4QXJncyIsIlRlc3RPYmpXaXRoMDhBcmdzLmNvbnN0cnVjdG9yIiwiVGVzdE9ialdpdGgwOUFyZ3MiLCJUZXN0T2JqV2l0aDA5QXJncy5jb25zdHJ1Y3RvciIsIlRlc3RPYmpXaXRoMTBBcmdzIiwiVGVzdE9ialdpdGgxMEFyZ3MuY29uc3RydWN0b3IiLCJUZXN0T2JqV2l0aDExQXJncyIsIlRlc3RPYmpXaXRoMTFBcmdzLmNvbnN0cnVjdG9yIiwiVGVzdE9ialdpdGgxMkFyZ3MiLCJUZXN0T2JqV2l0aDEyQXJncy5jb25zdHJ1Y3RvciIsIlRlc3RPYmpXaXRoMTNBcmdzIiwiVGVzdE9ialdpdGgxM0FyZ3MuY29uc3RydWN0b3IiLCJUZXN0T2JqV2l0aDE0QXJncyIsIlRlc3RPYmpXaXRoMTRBcmdzLmNvbnN0cnVjdG9yIiwiVGVzdE9ialdpdGgxNUFyZ3MiLCJUZXN0T2JqV2l0aDE1QXJncy5jb25zdHJ1Y3RvciIsIlRlc3RPYmpXaXRoMTZBcmdzIiwiVGVzdE9ialdpdGgxNkFyZ3MuY29uc3RydWN0b3IiLCJUZXN0T2JqV2l0aDE3QXJncyIsIlRlc3RPYmpXaXRoMTdBcmdzLmNvbnN0cnVjdG9yIiwiVGVzdE9ialdpdGgxOEFyZ3MiLCJUZXN0T2JqV2l0aDE4QXJncy5jb25zdHJ1Y3RvciIsIlRlc3RPYmpXaXRoMTlBcmdzIiwiVGVzdE9ialdpdGgxOUFyZ3MuY29uc3RydWN0b3IiLCJUZXN0T2JqV2l0aDIwQXJncyIsIlRlc3RPYmpXaXRoMjBBcmdzLmNvbnN0cnVjdG9yIiwiVGVzdE9ialdpdGgyMUFyZ3MiLCJUZXN0T2JqV2l0aDIxQXJncy5jb25zdHJ1Y3RvciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxpQ0FRTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLDJCQUF3Qyx5Q0FBeUMsQ0FBQyxDQUFBO0FBQ2xGLHdDQUFxQyxzREFBc0QsQ0FBQyxDQUFBO0FBQzVGLGlDQVFPLG9CQUFvQixDQUFDLENBQUE7QUFDNUIscUJBQXNCLDBCQUEwQixDQUFDLENBQUE7QUFFakQ7SUFHRUEsZUFBWUEsS0FBS0E7UUFBSUMsSUFBSUEsQ0FBQ0EsS0FBS0EsR0FBR0EsS0FBS0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFDNUNELFlBQUNBO0FBQURBLENBQUNBLEFBSkQsSUFJQztBQUVEO0lBU0VFLDZCQUFpQ0EsQ0FBUUEsRUFBdUJBLENBQVFBO1FBQ3RFQyxJQUFJQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtRQUNYQSxJQUFJQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtJQUNiQSxDQUFDQTtJQVBERCxzQkFDSUEsa0NBQUNBO2FBRExBLFVBQ01BLEtBQUtBO1FBQ1hFLENBQUNBOzs7T0FBQUY7SUFMREE7UUFBQ0EsZ0NBQWFBLENBQUNBLElBQUlBLENBQUNBO1FBQUVBLGdDQUFhQSxDQUFDQSxJQUFJQSxDQUFDQTs7T0FBQ0Esa0NBQUNBLFVBQUNBO0lBRzVDQTtRQUFDQSxnQ0FBYUEsQ0FBQ0EsSUFBSUEsQ0FBQ0E7OztPQUNoQkEsa0NBQUNBLFFBQ0pBO0lBUEhBO1FBQUNBLGlDQUFjQSxDQUFDQSxPQUFPQSxDQUFDQTtRQVNWQSxXQUFDQSxpQ0FBY0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQUE7UUFBV0EsV0FBQ0EsaUNBQWNBLENBQUNBLEdBQUdBLENBQUNBLENBQUFBOzs0QkFJaEVBO0lBQURBLDBCQUFDQTtBQUFEQSxDQUFDQSxBQWJELElBYUM7QUFFRDtJQUNFRyxnQ0FBWUEsQ0FBQ0EsRUFBRUEsQ0FBQ0E7SUFBR0MsQ0FBQ0E7SUFDdEJELDZCQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUM7QUFFRDtJQUlFRSxpQkFBWUEsQ0FBQ0EsRUFBRUEsQ0FBQ0E7UUFDZEMsSUFBSUEsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7UUFDWEEsSUFBSUEsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7SUFDYkEsQ0FBQ0E7SUFFREQsMEJBQVFBLEdBQVJBLFVBQVNBLEdBQUdBLElBQUlFLE1BQU1BLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBO0lBQy9CRixjQUFDQTtBQUFEQSxDQUFDQSxBQVZELElBVUM7QUFFRDtJQUFBRztJQUFpQkMsQ0FBQ0E7SUFBREQsZ0JBQUNBO0FBQURBLENBQUNBLEFBQWxCLElBQWtCO0FBRWxCO0lBQUFFO0lBQWtCQyxDQUFDQTtJQUFERCxpQkFBQ0E7QUFBREEsQ0FBQ0EsQUFBbkIsSUFBbUI7QUFFbkI7SUFBQUU7SUFBNkRDLENBQUNBO0lBQURELHNDQUFDQTtBQUFEQSxDQUFDQSxBQUE5RCxJQUE4RDtBQUU5RDtJQUF5Q0UsOENBQStCQTtJQUF4RUE7UUFBeUNDLDhCQUErQkE7SUFBdUJBLENBQUNBO0lBQURELGlDQUFDQTtBQUFEQSxDQUFDQSxBQUFoRyxFQUF5QywrQkFBK0IsRUFBd0I7QUFFaEcsb0dBQW9HO0FBQ3BHLGdCQUFnQjtBQUNoQiwwRkFBMEY7QUFDMUY7SUFBQUU7SUFFQUMsQ0FBQ0E7SUFEQ0QsNENBQVFBLEdBQVJBLGNBQVlFLENBQUNBO0lBQ2ZGLGdDQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUM7QUFFRDtJQUFBRztJQUVBQyxDQUFDQTtJQURDRCwrQ0FBUUEsR0FBUkEsY0FBWUUsQ0FBQ0E7SUFDZkYsbUNBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBQTJDRyxnREFBNEJBO0lBQXZFQTtRQUEyQ0MsOEJBQTRCQTtJQUFFQSxDQUFDQTtJQUFERCxtQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFBMUUsRUFBMkMsNEJBQTRCLEVBQUc7QUFFMUU7SUFDRUUsMkJBQVFBLENBQUNBLFdBQVdBLEVBQUVBO1FBQ3BCQSxJQUFJQSxTQUFTQSxDQUFDQTtRQUVkQSw2QkFBVUEsQ0FBQ0EsY0FBUUEsU0FBU0EsR0FBR0EsSUFBSUEsc0JBQVNBLENBQUNBLElBQUlBLGdEQUFzQkEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFL0VBLDJCQUFRQSxDQUFDQSxnQkFBZ0JBLEVBQUVBO1lBQ3pCQSw2QkFBVUEsQ0FBQ0EsY0FBUUEsU0FBU0EsR0FBR0EsSUFBSUEsc0JBQVNBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRXZEQSxxQkFBRUEsQ0FBQ0EsK0JBQStCQSxFQUFFQTtnQkFDbENBLHlCQUFNQSxDQUFDQSxjQUFNQSxPQUFBQSxTQUFTQSxDQUFDQSxjQUFjQSxFQUFFQSxFQUExQkEsQ0FBMEJBLENBQUNBLENBQUNBLFlBQVlBLENBQUNBLDRCQUE0QkEsQ0FBQ0EsQ0FBQ0E7WUFDdEZBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSwyQkFBMkJBLEVBQUVBO2dCQUM5QkEsU0FBU0EsQ0FBQ0EsVUFBVUEsRUFBRUEsQ0FBQ0E7Z0JBQ3ZCQSx5QkFBTUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsY0FBY0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7Z0JBRS9DQSxTQUFTQSxDQUFDQSxZQUFZQSxDQUFDQSxLQUFLQSxFQUFFQSxJQUFJQSwyQkFBY0EsQ0FBQ0EsSUFBSUEsRUFBRUEsSUFBSUEsRUFBRUEsY0FBTUEsT0FBQUEsT0FBT0EsRUFBUEEsQ0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzdFQSxTQUFTQSxDQUFDQSxZQUFZQSxDQUFDQSxPQUFPQSxFQUFFQSxJQUFJQSwyQkFBY0EsQ0FBQ0EsSUFBSUEsRUFBRUEsSUFBSUEsRUFBRUEsY0FBTUEsT0FBQUEsU0FBU0EsRUFBVEEsQ0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ2pGQSx5QkFBTUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsY0FBY0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsRUFBRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRTdEQSxTQUFTQSxDQUFDQSxPQUFPQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQTtnQkFDekJBLHlCQUFNQSxDQUFDQSxTQUFTQSxDQUFDQSxjQUFjQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFdERBLFNBQVNBLENBQUNBLE9BQU9BLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO2dCQUMzQkEseUJBQU1BLENBQUNBLFNBQVNBLENBQUNBLGNBQWNBLEVBQUVBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO1lBQ2pEQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsU0FBU0EsRUFBRUE7WUFDbEJBLHFCQUFFQSxDQUFDQSw0Q0FBNENBLEVBQUVBO2dCQUMvQ0EsSUFBSUEsR0FBR0EsR0FBR0EsU0FBU0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRTNDQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3pCQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDM0JBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLG9FQUFvRUE7WUFDcEVBLG9GQUFvRkE7WUFDcEZBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLG1DQUFnQkEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzdCQSxxQkFBRUEsQ0FBQ0Esa0NBQWtDQSxFQUFFQTtvQkFDckNBLElBQUlBLENBQUNBLEdBQUdBLFVBQUFBLENBQUNBLElBQUlBLE9BQUFBLFNBQVNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLEVBQXBCQSxDQUFvQkEsQ0FBQ0E7b0JBQ2xDQSxJQUFJQSxTQUFTQSxHQUFHQSxVQUFDQSxHQUFHQSxFQUFFQSxJQUFJQSxJQUFLQSxPQUFBQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsRUFBOUJBLENBQThCQSxDQUFDQTtvQkFFOURBLG1CQUFtQkE7b0JBQ25CQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxpQkFBaUJBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBO29CQUN0Q0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDeENBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQzlDQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUNwREEsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDMURBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ2hFQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUN0RUEsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDNUVBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ2xGQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUN4RkEsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDaEdBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ3hHQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO29CQUNoSEEsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDeEhBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ2hJQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO29CQUN4SUEsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDaEpBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ3hKQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO29CQUNoS0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDeEtBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ2hMQSxrQkFBa0JBO2dCQUNwQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDTEEsQ0FBQ0E7WUFFREEscUJBQUVBLENBQUNBLDBDQUEwQ0EsRUFDMUNBLGNBQVFBLHlCQUFNQSxDQUFDQSxjQUFNQSxPQUFBQSxTQUFTQSxDQUFDQSxPQUFPQSxDQUFDQSxpQkFBaUJBLENBQUNBLEVBQXBDQSxDQUFvQ0EsQ0FBQ0EsQ0FBQ0EsWUFBWUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFakZBLHFCQUFFQSxDQUFDQSxpREFBaURBLEVBQUVBO2dCQUNwREEsU0FBU0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsT0FBT0EsRUFBRUEsSUFBSUEsMkJBQWNBLENBQUNBLElBQUlBLEVBQUVBLElBQUlBLEVBQUVBLGNBQU1BLE9BQUFBLE1BQU1BLEVBQU5BLENBQU1BLENBQUNBLENBQUNBLENBQUNBO2dCQUM5RUEseUJBQU1BLENBQUNBLFNBQVNBLENBQUNBLE9BQU9BLENBQUNBLE9BQU9BLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO1lBQ3ZEQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsWUFBWUEsRUFBRUE7WUFDckJBLHFCQUFFQSxDQUFDQSxpREFBaURBLEVBQUVBO2dCQUNwREEsSUFBSUEsQ0FBQ0EsR0FBR0EsU0FBU0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxDQUFDQTtnQkFDbERBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxLQUFLQSxFQUFFQSxpQ0FBY0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsS0FBS0EsRUFBRUEsaUNBQWNBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ2xGQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsNkNBQTZDQSxFQUFFQTtnQkFDaERBLElBQUlBLENBQUNBLEdBQUdBLFNBQVNBLENBQUNBLFVBQVVBLENBQUNBLHNCQUFzQkEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3JEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDOUJBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxrREFBa0RBLEVBQUVBO2dCQUNyREEsU0FBU0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsT0FBT0EsRUFBRUEsSUFBSUEsMkJBQWNBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUN0RUEseUJBQU1BLENBQUNBLFNBQVNBLENBQUNBLFVBQVVBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQzVEQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsOEVBQThFQSxFQUFFQTtnQkFDakZBLFNBQVNBLENBQUNBLFlBQVlBLENBQUNBLE9BQU9BLEVBQUVBLElBQUlBLDJCQUFjQSxFQUFFQSxDQUFDQSxDQUFDQTtnQkFDdERBLHlCQUFNQSxDQUFDQSxTQUFTQSxDQUFDQSxVQUFVQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtZQUNwREEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEsMkJBQVFBLENBQUNBLGNBQWNBLEVBQUVBO1lBQ3ZCQSxxQkFBRUEsQ0FBQ0EsaUVBQWlFQSxFQUFFQTtnQkFDcEVBLElBQUlBLENBQUNBLEdBQUdBLFNBQVNBLENBQUNBLFlBQVlBLENBQUNBLG1CQUFtQkEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3BEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsZ0NBQWFBLENBQUNBLElBQUlBLENBQUNBLEVBQUVBLGdDQUFhQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDbkVBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxnQ0FBYUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDaERBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSw0Q0FBNENBLEVBQUVBO2dCQUMvQ0EsU0FBU0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsT0FBT0EsRUFBRUEsSUFBSUEsMkJBQWNBLENBQUNBLElBQUlBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLEVBQUVBLEVBQUNBLEdBQUdBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUMzRkEseUJBQU1BLENBQUNBLFNBQVNBLENBQUNBLFlBQVlBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEVBQUNBLEdBQUdBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUNBLENBQUNBLENBQUNBO1lBQ2pFQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxFQUFFQSxDQUFDQSxDQUFDQSxjQUFPQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDWkEscUJBQUVBLENBQUNBLGdEQUFnREEsRUFBRUE7b0JBQ25EQSxJQUFJQSxDQUFDQSxHQUFHQSxTQUFTQSxDQUFDQSxZQUFZQSxDQUFDQSwrQ0FBNEJBLENBQUNBLENBQUNBO29CQUM3REEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLGdDQUFhQSxDQUFDQSxLQUFLQSxDQUFDQSxFQUFFQSxnQ0FBYUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3ZFQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNMQSxDQUFDQTtRQUNIQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsYUFBYUEsRUFBRUE7WUFDdEJBLHFCQUFFQSxDQUFDQSxrREFBa0RBLEVBQUVBO2dCQUNyREEsSUFBSUEsQ0FBQ0EsR0FBR0EsU0FBU0EsQ0FBQ0EsV0FBV0EsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxDQUFDQTtnQkFDbkRBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxpQ0FBY0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDL0NBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxtREFBbURBLEVBQUVBO2dCQUN0REEsU0FBU0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsT0FBT0EsRUFBRUEsSUFBSUEsMkJBQWNBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUM1REEseUJBQU1BLENBQUNBLFNBQVNBLENBQUNBLFdBQVdBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ3pEQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsNkNBQTZDQSxFQUFFQTtnQkFDaERBLElBQUlBLENBQUNBLEdBQUdBLFNBQVNBLENBQUNBLFdBQVdBLENBQUNBLHNCQUFzQkEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3REQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7WUFDeEJBLENBQUNBLENBQUNBLENBQUNBO1FBQ0xBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLEVBQUVBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLENBQUNBLENBQUNBO1lBQ1pBLDJCQUFRQSxDQUFDQSxZQUFZQSxFQUFFQTtnQkFDckJBLHFCQUFFQSxDQUFDQSxpREFBaURBLEVBQUVBO29CQUNwREEsSUFBSUEsQ0FBQ0EsR0FBR0EsU0FBU0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsMEJBQTBCQSxDQUFDQSxDQUFDQTtvQkFDekRBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxTQUFTQSxFQUFFQSxVQUFVQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDN0NBLENBQUNBLENBQUNBLENBQUNBO2dCQUVIQSxxQkFBRUEsQ0FBQ0Esd0NBQXdDQSxFQUFFQTtvQkFDM0NBLElBQUlBLENBQUNBLEdBQUdBLFNBQVNBLENBQUNBLFVBQVVBLENBQUNBLG1CQUFtQkEsQ0FBQ0EsQ0FBQ0E7b0JBQ2xEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3hCQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFSEEscUJBQUVBLENBQUNBLGtEQUFrREEsRUFDbERBLGNBQVFBLHlCQUFNQSxDQUFDQSxjQUFNQSxPQUFBQSxTQUFTQSxDQUFDQSxVQUFVQSxDQUFDQSx5QkFBeUJBLENBQUNBLEVBQS9DQSxDQUErQ0EsQ0FBQ0EsQ0FBQ0EsWUFBWUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRTVGQSxxQkFBRUEsQ0FBQ0Esb0ZBQW9GQSxFQUNwRkE7b0JBQ0VBLHlCQUFNQSxDQUFDQSxjQUFNQSxPQUFBQSxTQUFTQSxDQUFDQSxVQUFVQSxDQUFDQSw0QkFBNEJBLENBQUNBLEVBQWxEQSxDQUFrREEsQ0FBQ0EsQ0FBQ0EsWUFBWUEsRUFBRUEsQ0FBQ0E7Z0JBQ2xGQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNSQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQTtRQUVEQSwyQkFBUUEsQ0FBQ0EsUUFBUUEsRUFBRUE7WUFDakJBLHFCQUFFQSxDQUFDQSx1Q0FBdUNBLEVBQUVBO2dCQUMxQ0EsSUFBSUEsSUFBSUEsR0FBR0EsU0FBU0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ2pDQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDN0NBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxnREFBZ0RBLEVBQUVBO2dCQUNuREEsU0FBU0EsQ0FBQ0EsZUFBZUEsQ0FBQ0EsRUFBQ0EsS0FBS0EsRUFBRUEsVUFBQ0EsR0FBR0EsSUFBS0EsT0FBQUEsTUFBTUEsRUFBTkEsQ0FBTUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3BEQSx5QkFBTUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7WUFDOURBLENBQUNBLENBQUNBLENBQUNBO1FBQ0xBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLDJCQUFRQSxDQUFDQSxRQUFRQSxFQUFFQTtZQUNqQkEscUJBQUVBLENBQUNBLHVDQUF1Q0EsRUFBRUE7Z0JBQzFDQSxJQUFJQSxJQUFJQSxHQUFHQSxTQUFTQSxDQUFDQSxNQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtnQkFDakNBLElBQUlBLEdBQUdBLEdBQUdBLElBQUlBLE9BQU9BLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO2dCQUM1QkEsSUFBSUEsQ0FBQ0EsR0FBR0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ2ZBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtZQUM3QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLGdEQUFnREEsRUFBRUE7Z0JBQ25EQSxJQUFJQSxRQUFRQSxDQUFDQTtnQkFDYkEsU0FBU0EsQ0FBQ0EsZUFBZUEsQ0FBQ0EsRUFBQ0EsS0FBS0EsRUFBRUEsVUFBQ0EsR0FBR0EsRUFBRUEsS0FBS0EsSUFBT0EsUUFBUUEsR0FBR0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzFFQSxTQUFTQSxDQUFDQSxNQUFNQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxVQUFVQSxFQUFFQSxNQUFNQSxDQUFDQSxDQUFDQTtnQkFFNUNBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTtZQUNuQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEsMkJBQVFBLENBQUNBLFFBQVFBLEVBQUVBO1lBQ2pCQSxxQkFBRUEsQ0FBQ0Esc0NBQXNDQSxFQUFFQTtnQkFDekNBLElBQUlBLElBQUlBLEdBQUdBLFNBQVNBLENBQUNBLE1BQU1BLENBQUNBLFVBQVVBLENBQUNBLENBQUNBO2dCQUN4Q0EsSUFBSUEsR0FBR0EsR0FBR0EsSUFBSUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzVCQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsR0FBR0EsRUFBRUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7WUFDaERBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxnREFBZ0RBLEVBQUVBO2dCQUNuREEsU0FBU0EsQ0FBQ0EsZUFBZUEsQ0FBQ0EsRUFBQ0EsS0FBS0EsRUFBRUEsVUFBQ0EsR0FBR0EsRUFBRUEsSUFBSUEsSUFBS0EsT0FBQUEsSUFBSUEsRUFBSkEsQ0FBSUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3hEQSx5QkFBTUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsVUFBVUEsRUFBRUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDMUVBLENBQUNBLENBQUNBLENBQUNBO1FBQ0xBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLEVBQUVBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLENBQUNBLENBQUNBO1lBQ1pBLDJCQUFRQSxDQUFDQSxXQUFXQSxFQUFFQTtnQkFDcEJBLHFCQUFFQSxDQUFDQSx3Q0FBd0NBLEVBQUVBO29CQUMzQ0EseUJBQU1BLENBQUNBLFNBQVNBLENBQUNBLFNBQVNBLENBQUNBLGlCQUFpQkEsQ0FBQ0E7eUJBQ2pDQSxRQUFRQSxDQUFDQSwwQ0FBMENBLENBQUNBLENBQUNBO3lCQUM1REEsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ2xCQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQTtJQUNIQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQXBOZSxZQUFJLE9Bb05uQixDQUFBO0FBR0Q7SUFFRUM7UUFBZ0JDLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLEVBQUVBLENBQUNBO0lBQUNBLENBQUNBO0lBQ25DRCx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFFRUUsMkJBQVlBLEVBQU9BO1FBQUlDLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBQzVDRCx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFFRUUsMkJBQVlBLEVBQU9BLEVBQUVBLEVBQU9BO1FBQUlDLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBQ3pERCx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFFRUUsMkJBQVlBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BO1FBQUlDLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBQ3RFRCx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFFRUUsMkJBQVlBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BO1FBQUlDLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBQ25GRCx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFFRUUsMkJBQVlBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BO1FBQUlDLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBQ2hHRCx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFFRUUsMkJBQVlBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BO1FBQzlEQyxJQUFJQSxDQUFDQSxJQUFJQSxHQUFHQSxDQUFDQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQTtJQUN2Q0EsQ0FBQ0E7SUFDSEQsd0JBQUNBO0FBQURBLENBQUNBLEFBTEQsSUFLQztBQUVEO0lBRUVFLDJCQUFZQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQTtRQUN2RUMsSUFBSUEsQ0FBQ0EsSUFBSUEsR0FBR0EsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsQ0FBQ0EsQ0FBQ0E7SUFDM0NBLENBQUNBO0lBQ0hELHdCQUFDQTtBQUFEQSxDQUFDQSxBQUxELElBS0M7QUFFRDtJQUVFRSwyQkFBWUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0E7UUFDaEZDLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBO0lBQy9DQSxDQUFDQTtJQUNIRCx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFMRCxJQUtDO0FBRUQ7SUFFRUUsMkJBQVlBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BO1FBQ3pGQyxJQUFJQSxDQUFDQSxJQUFJQSxHQUFHQSxDQUFDQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQTtJQUNuREEsQ0FBQ0E7SUFDSEQsd0JBQUNBO0FBQURBLENBQUNBLEFBTEQsSUFLQztBQUVEO0lBRUVFLDJCQUFZQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUMvRUEsR0FBUUE7UUFDbEJDLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBO0lBQ3hEQSxDQUFDQTtJQUNIRCx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFORCxJQU1DO0FBRUQ7SUFFRUUsMkJBQVlBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQy9FQSxHQUFRQSxFQUFFQSxHQUFRQTtRQUM1QkMsSUFBSUEsQ0FBQ0EsSUFBSUEsR0FBR0EsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0E7SUFDN0RBLENBQUNBO0lBQ0hELHdCQUFDQTtBQUFEQSxDQUFDQSxBQU5ELElBTUM7QUFFRDtJQUVFRSwyQkFBWUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFDL0VBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBO1FBQ3RDQyxJQUFJQSxDQUFDQSxJQUFJQSxHQUFHQSxDQUFDQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQTtJQUNsRUEsQ0FBQ0E7SUFDSEQsd0JBQUNBO0FBQURBLENBQUNBLEFBTkQsSUFNQztBQUVEO0lBRUVFLDJCQUFZQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUMvRUEsR0FBUUEsRUFBRUEsR0FBUUEsRUFBRUEsR0FBUUEsRUFBRUEsR0FBUUE7UUFDaERDLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBO0lBQ3ZFQSxDQUFDQTtJQUNIRCx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFORCxJQU1DO0FBRUQ7SUFFRUUsMkJBQVlBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQy9FQSxHQUFRQSxFQUFFQSxHQUFRQSxFQUFFQSxHQUFRQSxFQUFFQSxHQUFRQSxFQUFFQSxHQUFRQTtRQUMxREMsSUFBSUEsQ0FBQ0EsSUFBSUEsR0FBR0EsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0E7SUFDNUVBLENBQUNBO0lBQ0hELHdCQUFDQTtBQUFEQSxDQUFDQSxBQU5ELElBTUM7QUFFRDtJQUVFRSwyQkFBWUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFDL0VBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBO1FBQ3BFQyxJQUFJQSxDQUFDQSxJQUFJQSxHQUFHQSxDQUFDQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQTtJQUNqRkEsQ0FBQ0E7SUFDSEQsd0JBQUNBO0FBQURBLENBQUNBLEFBTkQsSUFNQztBQUVEO0lBRUVFLDJCQUFZQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUFFQSxFQUFPQSxFQUMvRUEsR0FBUUEsRUFBRUEsR0FBUUEsRUFBRUEsR0FBUUEsRUFBRUEsR0FBUUEsRUFBRUEsR0FBUUEsRUFBRUEsR0FBUUEsRUFBRUEsR0FBUUE7UUFDOUVDLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBO0lBQ3RGQSxDQUFDQTtJQUNIRCx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFORCxJQU1DO0FBRUQ7SUFFRUUsMkJBQVlBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQUVBLEVBQU9BLEVBQy9FQSxHQUFRQSxFQUFFQSxHQUFRQSxFQUFFQSxHQUFRQSxFQUFFQSxHQUFRQSxFQUFFQSxHQUFRQSxFQUFFQSxHQUFRQSxFQUFFQSxHQUFRQSxFQUFFQSxHQUFRQTtRQUN4RkMsSUFBSUEsQ0FBQ0EsSUFBSUEsR0FBR0EsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0E7SUFDM0ZBLENBQUNBO0lBQ0hELHdCQUFDQTtBQUFEQSxDQUFDQSxBQU5ELElBTUM7QUFFRDtJQUVFRSwyQkFBWUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFDL0VBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQzlFQSxHQUFRQTtRQUNsQkMsSUFBSUEsQ0FBQ0EsSUFBSUEsR0FBR0EsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0E7SUFDaEdBLENBQUNBO0lBQ0hELHdCQUFDQTtBQUFEQSxDQUFDQSxBQVBELElBT0M7QUFFRDtJQUVFRSwyQkFBWUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFDL0VBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQzlFQSxHQUFRQSxFQUFFQSxHQUFRQTtRQUM1QkMsSUFBSUEsQ0FBQ0EsSUFBSUE7WUFDTEEsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0E7SUFDN0ZBLENBQUNBO0lBQ0hELHdCQUFDQTtBQUFEQSxDQUFDQSxBQVJELElBUUM7QUFFRDtJQUVFRSwyQkFBWUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFDL0VBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQzlFQSxHQUFRQSxFQUFFQSxHQUFRQSxFQUFFQSxHQUFRQTtRQUN0Q0MsSUFBSUEsQ0FBQ0EsSUFBSUE7WUFDTEEsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0E7SUFDbEdBLENBQUNBO0lBQ0hELHdCQUFDQTtBQUFEQSxDQUFDQSxBQVJELElBUUM7QUFFRDtJQUVFRSwyQkFBWUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFBRUEsRUFBT0EsRUFDL0VBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQUVBLEdBQVFBLEVBQzlFQSxHQUFRQSxFQUFFQSxHQUFRQSxFQUFFQSxHQUFRQSxFQUFFQSxHQUFRQTtRQUNoREMsSUFBSUEsQ0FBQ0EsSUFBSUEsR0FBR0E7WUFDVkEsRUFBRUE7WUFDRkEsRUFBRUE7WUFDRkEsRUFBRUE7WUFDRkEsRUFBRUE7WUFDRkEsRUFBRUE7WUFDRkEsRUFBRUE7WUFDRkEsRUFBRUE7WUFDRkEsRUFBRUE7WUFDRkEsRUFBRUE7WUFDRkEsR0FBR0E7WUFDSEEsR0FBR0E7WUFDSEEsR0FBR0E7WUFDSEEsR0FBR0E7WUFDSEEsR0FBR0E7WUFDSEEsR0FBR0E7WUFDSEEsR0FBR0E7WUFDSEEsR0FBR0E7WUFDSEEsR0FBR0E7WUFDSEEsR0FBR0E7WUFDSEEsR0FBR0E7WUFDSEEsR0FBR0E7U0FDSkEsQ0FBQ0E7SUFDSkEsQ0FBQ0E7SUFDSEQsd0JBQUNBO0FBQURBLENBQUNBLEFBN0JELElBNkJDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgZGVzY3JpYmUsXG4gIGl0LFxuICBpaXQsXG4gIGRkZXNjcmliZSxcbiAgZXhwZWN0LFxuICBiZWZvcmVFYWNoLFxuICBicm93c2VyRGV0ZWN0aW9uXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuaW1wb3J0IHtPbkluaXR9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuaW1wb3J0IHtSZWZsZWN0b3IsIFJlZmxlY3Rpb25JbmZvfSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9yZWZsZWN0aW9uL3JlZmxlY3Rpb24nO1xuaW1wb3J0IHtSZWZsZWN0aW9uQ2FwYWJpbGl0aWVzfSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9yZWZsZWN0aW9uL3JlZmxlY3Rpb25fY2FwYWJpbGl0aWVzJztcbmltcG9ydCB7XG4gIENsYXNzRGVjb3JhdG9yLFxuICBQYXJhbURlY29yYXRvcixcbiAgUHJvcERlY29yYXRvcixcbiAgY2xhc3NEZWNvcmF0b3IsXG4gIHBhcmFtRGVjb3JhdG9yLFxuICBwcm9wRGVjb3JhdG9yLFxuICBIYXNHZXR0ZXJBbmRTZXR0ZXJEZWNvcmF0b3JzXG59IGZyb20gJy4vcmVmbGVjdG9yX2NvbW1vbic7XG5pbXBvcnQge0lTX0RBUlR9IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvbGFuZyc7XG5cbmNsYXNzIEFUeXBlIHtcbiAgdmFsdWU7XG5cbiAgY29uc3RydWN0b3IodmFsdWUpIHsgdGhpcy52YWx1ZSA9IHZhbHVlOyB9XG59XG5cbkBDbGFzc0RlY29yYXRvcignY2xhc3MnKVxuY2xhc3MgQ2xhc3NXaXRoRGVjb3JhdG9ycyB7XG4gIEBQcm9wRGVjb3JhdG9yKFwicDFcIikgQFByb3BEZWNvcmF0b3IoXCJwMlwiKSBhO1xuICBiO1xuXG4gIEBQcm9wRGVjb3JhdG9yKFwicDNcIilcbiAgc2V0IGModmFsdWUpIHtcbiAgfVxuXG4gIGNvbnN0cnVjdG9yKEBQYXJhbURlY29yYXRvcihcImFcIikgYTogQVR5cGUsIEBQYXJhbURlY29yYXRvcihcImJcIikgYjogQVR5cGUpIHtcbiAgICB0aGlzLmEgPSBhO1xuICAgIHRoaXMuYiA9IGI7XG4gIH1cbn1cblxuY2xhc3MgQ2xhc3NXaXRob3V0RGVjb3JhdG9ycyB7XG4gIGNvbnN0cnVjdG9yKGEsIGIpIHt9XG59XG5cbmNsYXNzIFRlc3RPYmoge1xuICBhO1xuICBiO1xuXG4gIGNvbnN0cnVjdG9yKGEsIGIpIHtcbiAgICB0aGlzLmEgPSBhO1xuICAgIHRoaXMuYiA9IGI7XG4gIH1cblxuICBpZGVudGl0eShhcmcpIHsgcmV0dXJuIGFyZzsgfVxufVxuXG5jbGFzcyBJbnRlcmZhY2Uge31cblxuY2xhc3MgSW50ZXJmYWNlMiB7fVxuXG5jbGFzcyBTdXBlckNsYXNzSW1wbGVtZW50aW5nSW50ZXJmYWNlIGltcGxlbWVudHMgSW50ZXJmYWNlMiB7fVxuXG5jbGFzcyBDbGFzc0ltcGxlbWVudGluZ0ludGVyZmFjZSBleHRlbmRzIFN1cGVyQ2xhc3NJbXBsZW1lbnRpbmdJbnRlcmZhY2UgaW1wbGVtZW50cyBJbnRlcmZhY2Uge31cblxuLy8gQ2xhc3NlcyB1c2VkIHRvIHRlc3Qgb3VyIHJ1bnRpbWUgY2hlY2sgZm9yIGNsYXNzZXMgdGhhdCBpbXBsZW1lbnQgbGlmZWN5Y2xlIGludGVyZmFjZXMgYnV0IGRvIG5vdFxuLy8gZGVjbGFyZSB0aGVtLlxuLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvcHVsbC82ODc5IGFuZCBodHRwczovL2dvby5nbC9iMDdLaWkgZm9yIGRldGFpbHMuXG5jbGFzcyBDbGFzc0RvZXNOb3REZWNsYXJlT25Jbml0IHtcbiAgbmdPbkluaXQoKSB7fVxufVxuXG5jbGFzcyBTdXBlckNsYXNzSW1wbGVtZW50aW5nT25Jbml0IGltcGxlbWVudHMgT25Jbml0IHtcbiAgbmdPbkluaXQoKSB7fVxufVxuXG5jbGFzcyBTdWJDbGFzc0RvZXNOb3REZWNsYXJlT25Jbml0IGV4dGVuZHMgU3VwZXJDbGFzc0ltcGxlbWVudGluZ09uSW5pdCB7fVxuXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpIHtcbiAgZGVzY3JpYmUoJ1JlZmxlY3RvcicsICgpID0+IHtcbiAgICB2YXIgcmVmbGVjdG9yO1xuXG4gICAgYmVmb3JlRWFjaCgoKSA9PiB7IHJlZmxlY3RvciA9IG5ldyBSZWZsZWN0b3IobmV3IFJlZmxlY3Rpb25DYXBhYmlsaXRpZXMoKSk7IH0pO1xuXG4gICAgZGVzY3JpYmUoXCJ1c2FnZSB0cmFja2luZ1wiLCAoKSA9PiB7XG4gICAgICBiZWZvcmVFYWNoKCgpID0+IHsgcmVmbGVjdG9yID0gbmV3IFJlZmxlY3RvcihudWxsKTsgfSk7XG5cbiAgICAgIGl0KFwic2hvdWxkIGJlIGRpc2FibGVkIGJ5IGRlZmF1bHRcIiwgKCkgPT4ge1xuICAgICAgICBleHBlY3QoKCkgPT4gcmVmbGVjdG9yLmxpc3RVbnVzZWRLZXlzKCkpLnRvVGhyb3dFcnJvcignVXNhZ2UgdHJhY2tpbmcgaXMgZGlzYWJsZWQnKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdChcInNob3VsZCByZXBvcnQgdW51c2VkIGtleXNcIiwgKCkgPT4ge1xuICAgICAgICByZWZsZWN0b3IudHJhY2tVc2FnZSgpO1xuICAgICAgICBleHBlY3QocmVmbGVjdG9yLmxpc3RVbnVzZWRLZXlzKCkpLnRvRXF1YWwoW10pO1xuXG4gICAgICAgIHJlZmxlY3Rvci5yZWdpc3RlclR5cGUoQVR5cGUsIG5ldyBSZWZsZWN0aW9uSW5mbyhudWxsLCBudWxsLCAoKSA9PiBcIkFUeXBlXCIpKTtcbiAgICAgICAgcmVmbGVjdG9yLnJlZ2lzdGVyVHlwZShUZXN0T2JqLCBuZXcgUmVmbGVjdGlvbkluZm8obnVsbCwgbnVsbCwgKCkgPT4gXCJUZXN0T2JqXCIpKTtcbiAgICAgICAgZXhwZWN0KHJlZmxlY3Rvci5saXN0VW51c2VkS2V5cygpKS50b0VxdWFsKFtBVHlwZSwgVGVzdE9ial0pO1xuXG4gICAgICAgIHJlZmxlY3Rvci5mYWN0b3J5KEFUeXBlKTtcbiAgICAgICAgZXhwZWN0KHJlZmxlY3Rvci5saXN0VW51c2VkS2V5cygpKS50b0VxdWFsKFtUZXN0T2JqXSk7XG5cbiAgICAgICAgcmVmbGVjdG9yLmZhY3RvcnkoVGVzdE9iaik7XG4gICAgICAgIGV4cGVjdChyZWZsZWN0b3IubGlzdFVudXNlZEtleXMoKSkudG9FcXVhbChbXSk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKFwiZmFjdG9yeVwiLCAoKSA9PiB7XG4gICAgICBpdChcInNob3VsZCBjcmVhdGUgYSBmYWN0b3J5IGZvciB0aGUgZ2l2ZW4gdHlwZVwiLCAoKSA9PiB7XG4gICAgICAgIHZhciBvYmogPSByZWZsZWN0b3IuZmFjdG9yeShUZXN0T2JqKSgxLCAyKTtcblxuICAgICAgICBleHBlY3Qob2JqLmEpLnRvRXF1YWwoMSk7XG4gICAgICAgIGV4cGVjdChvYmouYikudG9FcXVhbCgyKTtcbiAgICAgIH0pO1xuXG4gICAgICAvLyBNYWtlcyBFZGdlIHRvIGRpc2Nvbm5lY3Qgd2hlbiBydW5uaW5nIHRoZSBmdWxsIHVuaXQgdGVzdCBjYW1wYWlnblxuICAgICAgLy8gVE9ETzogcmVtb3ZlIHdoZW4gaXNzdWUgaXMgc29sdmVkOiBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2lzc3Vlcy80NzU2XG4gICAgICBpZiAoIWJyb3dzZXJEZXRlY3Rpb24uaXNFZGdlKSB7XG4gICAgICAgIGl0KFwic2hvdWxkIGNoZWNrIGFyZ3MgZnJvbSBubyB0byBtYXhcIiwgKCkgPT4ge1xuICAgICAgICAgIHZhciBmID0gdCA9PiByZWZsZWN0b3IuZmFjdG9yeSh0KTtcbiAgICAgICAgICB2YXIgY2hlY2tBcmdzID0gKG9iaiwgYXJncykgPT4gZXhwZWN0KG9iai5hcmdzKS50b0VxdWFsKGFyZ3MpO1xuXG4gICAgICAgICAgLy8gY2xhbmctZm9ybWF0IG9mZlxuICAgICAgICAgIGNoZWNrQXJncyhmKFRlc3RPYmpXaXRoMDBBcmdzKSgpLCBbXSk7XG4gICAgICAgICAgY2hlY2tBcmdzKGYoVGVzdE9ialdpdGgwMUFyZ3MpKDEpLCBbMV0pO1xuICAgICAgICAgIGNoZWNrQXJncyhmKFRlc3RPYmpXaXRoMDJBcmdzKSgxLCAyKSwgWzEsIDJdKTtcbiAgICAgICAgICBjaGVja0FyZ3MoZihUZXN0T2JqV2l0aDAzQXJncykoMSwgMiwgMyksIFsxLCAyLCAzXSk7XG4gICAgICAgICAgY2hlY2tBcmdzKGYoVGVzdE9ialdpdGgwNEFyZ3MpKDEsIDIsIDMsIDQpLCBbMSwgMiwgMywgNF0pO1xuICAgICAgICAgIGNoZWNrQXJncyhmKFRlc3RPYmpXaXRoMDVBcmdzKSgxLCAyLCAzLCA0LCA1KSwgWzEsIDIsIDMsIDQsIDVdKTtcbiAgICAgICAgICBjaGVja0FyZ3MoZihUZXN0T2JqV2l0aDA2QXJncykoMSwgMiwgMywgNCwgNSwgNiksIFsxLCAyLCAzLCA0LCA1LCA2XSk7XG4gICAgICAgICAgY2hlY2tBcmdzKGYoVGVzdE9ialdpdGgwN0FyZ3MpKDEsIDIsIDMsIDQsIDUsIDYsIDcpLCBbMSwgMiwgMywgNCwgNSwgNiwgN10pO1xuICAgICAgICAgIGNoZWNrQXJncyhmKFRlc3RPYmpXaXRoMDhBcmdzKSgxLCAyLCAzLCA0LCA1LCA2LCA3LCA4KSwgWzEsIDIsIDMsIDQsIDUsIDYsIDcsIDhdKTtcbiAgICAgICAgICBjaGVja0FyZ3MoZihUZXN0T2JqV2l0aDA5QXJncykoMSwgMiwgMywgNCwgNSwgNiwgNywgOCwgOSksIFsxLCAyLCAzLCA0LCA1LCA2LCA3LCA4LCA5XSk7XG4gICAgICAgICAgY2hlY2tBcmdzKGYoVGVzdE9ialdpdGgxMEFyZ3MpKDEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIDksIDEwKSwgWzEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIDksIDEwXSk7XG4gICAgICAgICAgY2hlY2tBcmdzKGYoVGVzdE9ialdpdGgxMUFyZ3MpKDEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIDksIDEwLCAxMSksIFsxLCAyLCAzLCA0LCA1LCA2LCA3LCA4LCA5LCAxMCwgMTFdKTtcbiAgICAgICAgICBjaGVja0FyZ3MoZihUZXN0T2JqV2l0aDEyQXJncykoMSwgMiwgMywgNCwgNSwgNiwgNywgOCwgOSwgMTAsIDExLCAxMiksIFsxLCAyLCAzLCA0LCA1LCA2LCA3LCA4LCA5LCAxMCwgMTEsIDEyXSk7XG4gICAgICAgICAgY2hlY2tBcmdzKGYoVGVzdE9ialdpdGgxM0FyZ3MpKDEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIDksIDEwLCAxMSwgMTIsIDEzKSwgWzEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIDksIDEwLCAxMSwgMTIsIDEzXSk7XG4gICAgICAgICAgY2hlY2tBcmdzKGYoVGVzdE9ialdpdGgxNEFyZ3MpKDEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIDksIDEwLCAxMSwgMTIsIDEzLCAxNCksIFsxLCAyLCAzLCA0LCA1LCA2LCA3LCA4LCA5LCAxMCwgMTEsIDEyLCAxMywgMTRdKTtcbiAgICAgICAgICBjaGVja0FyZ3MoZihUZXN0T2JqV2l0aDE1QXJncykoMSwgMiwgMywgNCwgNSwgNiwgNywgOCwgOSwgMTAsIDExLCAxMiwgMTMsIDE0LCAxNSksIFsxLCAyLCAzLCA0LCA1LCA2LCA3LCA4LCA5LCAxMCwgMTEsIDEyLCAxMywgMTQsIDE1XSk7XG4gICAgICAgICAgY2hlY2tBcmdzKGYoVGVzdE9ialdpdGgxNkFyZ3MpKDEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIDksIDEwLCAxMSwgMTIsIDEzLCAxNCwgMTUsIDE2KSwgWzEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIDksIDEwLCAxMSwgMTIsIDEzLCAxNCwgMTUsIDE2XSk7XG4gICAgICAgICAgY2hlY2tBcmdzKGYoVGVzdE9ialdpdGgxN0FyZ3MpKDEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIDksIDEwLCAxMSwgMTIsIDEzLCAxNCwgMTUsIDE2LCAxNyksIFsxLCAyLCAzLCA0LCA1LCA2LCA3LCA4LCA5LCAxMCwgMTEsIDEyLCAxMywgMTQsIDE1LCAxNiwgMTddKTtcbiAgICAgICAgICBjaGVja0FyZ3MoZihUZXN0T2JqV2l0aDE4QXJncykoMSwgMiwgMywgNCwgNSwgNiwgNywgOCwgOSwgMTAsIDExLCAxMiwgMTMsIDE0LCAxNSwgMTYsIDE3LCAxOCksIFsxLCAyLCAzLCA0LCA1LCA2LCA3LCA4LCA5LCAxMCwgMTEsIDEyLCAxMywgMTQsIDE1LCAxNiwgMTcsIDE4XSk7XG4gICAgICAgICAgY2hlY2tBcmdzKGYoVGVzdE9ialdpdGgxOUFyZ3MpKDEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIDksIDEwLCAxMSwgMTIsIDEzLCAxNCwgMTUsIDE2LCAxNywgMTgsIDE5KSwgWzEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIDksIDEwLCAxMSwgMTIsIDEzLCAxNCwgMTUsIDE2LCAxNywgMTgsIDE5XSk7XG4gICAgICAgICAgY2hlY2tBcmdzKGYoVGVzdE9ialdpdGgyMEFyZ3MpKDEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIDksIDEwLCAxMSwgMTIsIDEzLCAxNCwgMTUsIDE2LCAxNywgMTgsIDE5LCAyMCksIFsxLCAyLCAzLCA0LCA1LCA2LCA3LCA4LCA5LCAxMCwgMTEsIDEyLCAxMywgMTQsIDE1LCAxNiwgMTcsIDE4LCAxOSwgMjBdKTtcbiAgICAgICAgICAvLyBjbGFuZy1mb3JtYXQgb25cbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIGl0KFwic2hvdWxkIHRocm93IHdoZW4gbW9yZSB0aGFuIDIwIGFyZ3VtZW50c1wiLFxuICAgICAgICAgKCkgPT4geyBleHBlY3QoKCkgPT4gcmVmbGVjdG9yLmZhY3RvcnkoVGVzdE9ialdpdGgyMUFyZ3MpKS50b1Rocm93RXJyb3IoKTsgfSk7XG5cbiAgICAgIGl0KFwic2hvdWxkIHJldHVybiBhIHJlZ2lzdGVyZWQgZmFjdG9yeSBpZiBhdmFpbGFibGVcIiwgKCkgPT4ge1xuICAgICAgICByZWZsZWN0b3IucmVnaXN0ZXJUeXBlKFRlc3RPYmosIG5ldyBSZWZsZWN0aW9uSW5mbyhudWxsLCBudWxsLCAoKSA9PiBcImZha2VcIikpO1xuICAgICAgICBleHBlY3QocmVmbGVjdG9yLmZhY3RvcnkoVGVzdE9iaikoKSkudG9FcXVhbChcImZha2VcIik7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKFwicGFyYW1ldGVyc1wiLCAoKSA9PiB7XG4gICAgICBpdChcInNob3VsZCByZXR1cm4gYW4gYXJyYXkgb2YgcGFyYW1ldGVycyBmb3IgYSB0eXBlXCIsICgpID0+IHtcbiAgICAgICAgdmFyIHAgPSByZWZsZWN0b3IucGFyYW1ldGVycyhDbGFzc1dpdGhEZWNvcmF0b3JzKTtcbiAgICAgICAgZXhwZWN0KHApLnRvRXF1YWwoW1tBVHlwZSwgcGFyYW1EZWNvcmF0b3IoJ2EnKV0sIFtBVHlwZSwgcGFyYW1EZWNvcmF0b3IoJ2InKV1dKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdChcInNob3VsZCB3b3JrIGZvciBhIGNsYXNzIHdpdGhvdXQgYW5ub3RhdGlvbnNcIiwgKCkgPT4ge1xuICAgICAgICB2YXIgcCA9IHJlZmxlY3Rvci5wYXJhbWV0ZXJzKENsYXNzV2l0aG91dERlY29yYXRvcnMpO1xuICAgICAgICBleHBlY3QocC5sZW5ndGgpLnRvRXF1YWwoMik7XG4gICAgICB9KTtcblxuICAgICAgaXQoXCJzaG91bGQgcmV0dXJuIHJlZ2lzdGVyZWQgcGFyYW1ldGVycyBpZiBhdmFpbGFibGVcIiwgKCkgPT4ge1xuICAgICAgICByZWZsZWN0b3IucmVnaXN0ZXJUeXBlKFRlc3RPYmosIG5ldyBSZWZsZWN0aW9uSW5mbyhudWxsLCBbWzFdLCBbMl1dKSk7XG4gICAgICAgIGV4cGVjdChyZWZsZWN0b3IucGFyYW1ldGVycyhUZXN0T2JqKSkudG9FcXVhbChbWzFdLCBbMl1dKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdChcInNob3VsZCByZXR1cm4gYW4gZW1wdHkgbGlzdCB3aGVuIG5vIHBhcmFtZXRlcnMgZmllbGQgaW4gdGhlIHN0b3JlZCB0eXBlIGluZm9cIiwgKCkgPT4ge1xuICAgICAgICByZWZsZWN0b3IucmVnaXN0ZXJUeXBlKFRlc3RPYmosIG5ldyBSZWZsZWN0aW9uSW5mbygpKTtcbiAgICAgICAgZXhwZWN0KHJlZmxlY3Rvci5wYXJhbWV0ZXJzKFRlc3RPYmopKS50b0VxdWFsKFtdKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoXCJwcm9wTWV0YWRhdGFcIiwgKCkgPT4ge1xuICAgICAgaXQoXCJzaG91bGQgcmV0dXJuIGEgc3RyaW5nIG1hcCBvZiBwcm9wIG1ldGFkYXRhIGZvciB0aGUgZ2l2ZW4gY2xhc3NcIiwgKCkgPT4ge1xuICAgICAgICB2YXIgcCA9IHJlZmxlY3Rvci5wcm9wTWV0YWRhdGEoQ2xhc3NXaXRoRGVjb3JhdG9ycyk7XG4gICAgICAgIGV4cGVjdChwW1wiYVwiXSkudG9FcXVhbChbcHJvcERlY29yYXRvcihcInAxXCIpLCBwcm9wRGVjb3JhdG9yKFwicDJcIildKTtcbiAgICAgICAgZXhwZWN0KHBbXCJjXCJdKS50b0VxdWFsKFtwcm9wRGVjb3JhdG9yKFwicDNcIildKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdChcInNob3VsZCByZXR1cm4gcmVnaXN0ZXJlZCBtZXRhIGlmIGF2YWlsYWJsZVwiLCAoKSA9PiB7XG4gICAgICAgIHJlZmxlY3Rvci5yZWdpc3RlclR5cGUoVGVzdE9iaiwgbmV3IFJlZmxlY3Rpb25JbmZvKG51bGwsIG51bGwsIG51bGwsIG51bGwsIHtcImFcIjogWzEsIDJdfSkpO1xuICAgICAgICBleHBlY3QocmVmbGVjdG9yLnByb3BNZXRhZGF0YShUZXN0T2JqKSkudG9FcXVhbCh7XCJhXCI6IFsxLCAyXX0pO1xuICAgICAgfSk7XG5cbiAgICAgIGlmIChJU19EQVJUKSB7XG4gICAgICAgIGl0KFwic2hvdWxkIG1lcmdlIG1ldGFkYXRhIGZyb20gZ2V0dGVycyBhbmQgc2V0dGVyc1wiLCAoKSA9PiB7XG4gICAgICAgICAgdmFyIHAgPSByZWZsZWN0b3IucHJvcE1ldGFkYXRhKEhhc0dldHRlckFuZFNldHRlckRlY29yYXRvcnMpO1xuICAgICAgICAgIGV4cGVjdChwW1wiYVwiXSkudG9FcXVhbChbcHJvcERlY29yYXRvcihcImdldFwiKSwgcHJvcERlY29yYXRvcihcInNldFwiKV0pO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKFwiYW5ub3RhdGlvbnNcIiwgKCkgPT4ge1xuICAgICAgaXQoXCJzaG91bGQgcmV0dXJuIGFuIGFycmF5IG9mIGFubm90YXRpb25zIGZvciBhIHR5cGVcIiwgKCkgPT4ge1xuICAgICAgICB2YXIgcCA9IHJlZmxlY3Rvci5hbm5vdGF0aW9ucyhDbGFzc1dpdGhEZWNvcmF0b3JzKTtcbiAgICAgICAgZXhwZWN0KHApLnRvRXF1YWwoW2NsYXNzRGVjb3JhdG9yKCdjbGFzcycpXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoXCJzaG91bGQgcmV0dXJuIHJlZ2lzdGVyZWQgYW5ub3RhdGlvbnMgaWYgYXZhaWxhYmxlXCIsICgpID0+IHtcbiAgICAgICAgcmVmbGVjdG9yLnJlZ2lzdGVyVHlwZShUZXN0T2JqLCBuZXcgUmVmbGVjdGlvbkluZm8oWzEsIDJdKSk7XG4gICAgICAgIGV4cGVjdChyZWZsZWN0b3IuYW5ub3RhdGlvbnMoVGVzdE9iaikpLnRvRXF1YWwoWzEsIDJdKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdChcInNob3VsZCB3b3JrIGZvciBhIGNsYXNzIHdpdGhvdXQgYW5ub3RhdGlvbnNcIiwgKCkgPT4ge1xuICAgICAgICB2YXIgcCA9IHJlZmxlY3Rvci5hbm5vdGF0aW9ucyhDbGFzc1dpdGhvdXREZWNvcmF0b3JzKTtcbiAgICAgICAgZXhwZWN0KHApLnRvRXF1YWwoW10pO1xuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICBpZiAoSVNfREFSVCkge1xuICAgICAgZGVzY3JpYmUoXCJpbnRlcmZhY2VzXCIsICgpID0+IHtcbiAgICAgICAgaXQoXCJzaG91bGQgcmV0dXJuIGFuIGFycmF5IG9mIGludGVyZmFjZXMgZm9yIGEgdHlwZVwiLCAoKSA9PiB7XG4gICAgICAgICAgdmFyIHAgPSByZWZsZWN0b3IuaW50ZXJmYWNlcyhDbGFzc0ltcGxlbWVudGluZ0ludGVyZmFjZSk7XG4gICAgICAgICAgZXhwZWN0KHApLnRvRXF1YWwoW0ludGVyZmFjZSwgSW50ZXJmYWNlMl0pO1xuICAgICAgICB9KTtcblxuICAgICAgICBpdChcInNob3VsZCByZXR1cm4gYW4gZW1wdHkgYXJyYXkgb3RoZXJ3aXNlXCIsICgpID0+IHtcbiAgICAgICAgICB2YXIgcCA9IHJlZmxlY3Rvci5pbnRlcmZhY2VzKENsYXNzV2l0aERlY29yYXRvcnMpO1xuICAgICAgICAgIGV4cGVjdChwKS50b0VxdWFsKFtdKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaXQoXCJzaG91bGQgdGhyb3cgZm9yIHVuZGVjbGFyZWQgbGlmZWN5Y2xlIGludGVyZmFjZXNcIixcbiAgICAgICAgICAgKCkgPT4geyBleHBlY3QoKCkgPT4gcmVmbGVjdG9yLmludGVyZmFjZXMoQ2xhc3NEb2VzTm90RGVjbGFyZU9uSW5pdCkpLnRvVGhyb3dFcnJvcigpOyB9KTtcblxuICAgICAgICBpdChcInNob3VsZCB0aHJvdyBmb3IgY2xhc3MgaW5oZXJpdGluZyBhIGxpZmVjeWNsZSBpbXBsIGFuZCBub3QgZGVjbGFyaW5nIHRoZSBpbnRlcmZhY2VcIixcbiAgICAgICAgICAgKCkgPT4ge1xuICAgICAgICAgICAgIGV4cGVjdCgoKSA9PiByZWZsZWN0b3IuaW50ZXJmYWNlcyhTdWJDbGFzc0RvZXNOb3REZWNsYXJlT25Jbml0KSkudG9UaHJvd0Vycm9yKCk7XG4gICAgICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgZGVzY3JpYmUoXCJnZXR0ZXJcIiwgKCkgPT4ge1xuICAgICAgaXQoXCJyZXR1cm5zIGEgZnVuY3Rpb24gcmVhZGluZyBhIHByb3BlcnR5XCIsICgpID0+IHtcbiAgICAgICAgdmFyIGdldEEgPSByZWZsZWN0b3IuZ2V0dGVyKCdhJyk7XG4gICAgICAgIGV4cGVjdChnZXRBKG5ldyBUZXN0T2JqKDEsIDIpKSkudG9FcXVhbCgxKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdChcInNob3VsZCByZXR1cm4gYSByZWdpc3RlcmVkIGdldHRlciBpZiBhdmFpbGFibGVcIiwgKCkgPT4ge1xuICAgICAgICByZWZsZWN0b3IucmVnaXN0ZXJHZXR0ZXJzKHtcImFiY1wiOiAob2JqKSA9PiBcImZha2VcIn0pO1xuICAgICAgICBleHBlY3QocmVmbGVjdG9yLmdldHRlcihcImFiY1wiKShcImFueXRoaW5nXCIpKS50b0VxdWFsKFwiZmFrZVwiKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoXCJzZXR0ZXJcIiwgKCkgPT4ge1xuICAgICAgaXQoXCJyZXR1cm5zIGEgZnVuY3Rpb24gc2V0dGluZyBhIHByb3BlcnR5XCIsICgpID0+IHtcbiAgICAgICAgdmFyIHNldEEgPSByZWZsZWN0b3Iuc2V0dGVyKCdhJyk7XG4gICAgICAgIHZhciBvYmogPSBuZXcgVGVzdE9iaigxLCAyKTtcbiAgICAgICAgc2V0QShvYmosIDEwMCk7XG4gICAgICAgIGV4cGVjdChvYmouYSkudG9FcXVhbCgxMDApO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KFwic2hvdWxkIHJldHVybiBhIHJlZ2lzdGVyZWQgc2V0dGVyIGlmIGF2YWlsYWJsZVwiLCAoKSA9PiB7XG4gICAgICAgIHZhciB1cGRhdGVNZTtcbiAgICAgICAgcmVmbGVjdG9yLnJlZ2lzdGVyU2V0dGVycyh7XCJhYmNcIjogKG9iaiwgdmFsdWUpID0+IHsgdXBkYXRlTWUgPSB2YWx1ZTsgfX0pO1xuICAgICAgICByZWZsZWN0b3Iuc2V0dGVyKFwiYWJjXCIpKFwiYW55dGhpbmdcIiwgXCJmYWtlXCIpO1xuXG4gICAgICAgIGV4cGVjdCh1cGRhdGVNZSkudG9FcXVhbChcImZha2VcIik7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKFwibWV0aG9kXCIsICgpID0+IHtcbiAgICAgIGl0KFwicmV0dXJucyBhIGZ1bmN0aW9uIGludm9raW5nIGEgbWV0aG9kXCIsICgpID0+IHtcbiAgICAgICAgdmFyIGZ1bmMgPSByZWZsZWN0b3IubWV0aG9kKCdpZGVudGl0eScpO1xuICAgICAgICB2YXIgb2JqID0gbmV3IFRlc3RPYmooMSwgMik7XG4gICAgICAgIGV4cGVjdChmdW5jKG9iaiwgWyd2YWx1ZSddKSkudG9FcXVhbCgndmFsdWUnKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdChcInNob3VsZCByZXR1cm4gYSByZWdpc3RlcmVkIG1ldGhvZCBpZiBhdmFpbGFibGVcIiwgKCkgPT4ge1xuICAgICAgICByZWZsZWN0b3IucmVnaXN0ZXJNZXRob2RzKHtcImFiY1wiOiAob2JqLCBhcmdzKSA9PiBhcmdzfSk7XG4gICAgICAgIGV4cGVjdChyZWZsZWN0b3IubWV0aG9kKFwiYWJjXCIpKFwiYW55dGhpbmdcIiwgW1wiZmFrZVwiXSkpLnRvRXF1YWwoWydmYWtlJ10pO1xuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICBpZiAoSVNfREFSVCkge1xuICAgICAgZGVzY3JpYmUoXCJpbXBvcnRVcmlcIiwgKCkgPT4ge1xuICAgICAgICBpdChcInNob3VsZCByZXR1cm4gdGhlIGltcG9ydFVyaSBmb3IgYSB0eXBlXCIsICgpID0+IHtcbiAgICAgICAgICBleHBlY3QocmVmbGVjdG9yLmltcG9ydFVyaShUZXN0T2JqV2l0aDAwQXJncylcbiAgICAgICAgICAgICAgICAgICAgIC5lbmRzV2l0aCgndGVzdC9jb3JlL3JlZmxlY3Rpb24vcmVmbGVjdG9yX3NwZWMuZGFydCcpKVxuICAgICAgICAgICAgICAudG9CZSh0cnVlKTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0pO1xufVxuXG5cbmNsYXNzIFRlc3RPYmpXaXRoMDBBcmdzIHtcbiAgYXJnczogYW55W107XG4gIGNvbnN0cnVjdG9yKCkgeyB0aGlzLmFyZ3MgPSBbXTsgfVxufVxuXG5jbGFzcyBUZXN0T2JqV2l0aDAxQXJncyB7XG4gIGFyZ3M6IGFueVtdO1xuICBjb25zdHJ1Y3RvcihhMTogYW55KSB7IHRoaXMuYXJncyA9IFthMV07IH1cbn1cblxuY2xhc3MgVGVzdE9ialdpdGgwMkFyZ3Mge1xuICBhcmdzOiBhbnlbXTtcbiAgY29uc3RydWN0b3IoYTE6IGFueSwgYTI6IGFueSkgeyB0aGlzLmFyZ3MgPSBbYTEsIGEyXTsgfVxufVxuXG5jbGFzcyBUZXN0T2JqV2l0aDAzQXJncyB7XG4gIGFyZ3M6IGFueVtdO1xuICBjb25zdHJ1Y3RvcihhMTogYW55LCBhMjogYW55LCBhMzogYW55KSB7IHRoaXMuYXJncyA9IFthMSwgYTIsIGEzXTsgfVxufVxuXG5jbGFzcyBUZXN0T2JqV2l0aDA0QXJncyB7XG4gIGFyZ3M6IGFueVtdO1xuICBjb25zdHJ1Y3RvcihhMTogYW55LCBhMjogYW55LCBhMzogYW55LCBhNDogYW55KSB7IHRoaXMuYXJncyA9IFthMSwgYTIsIGEzLCBhNF07IH1cbn1cblxuY2xhc3MgVGVzdE9ialdpdGgwNUFyZ3Mge1xuICBhcmdzOiBhbnlbXTtcbiAgY29uc3RydWN0b3IoYTE6IGFueSwgYTI6IGFueSwgYTM6IGFueSwgYTQ6IGFueSwgYTU6IGFueSkgeyB0aGlzLmFyZ3MgPSBbYTEsIGEyLCBhMywgYTQsIGE1XTsgfVxufVxuXG5jbGFzcyBUZXN0T2JqV2l0aDA2QXJncyB7XG4gIGFyZ3M6IGFueVtdO1xuICBjb25zdHJ1Y3RvcihhMTogYW55LCBhMjogYW55LCBhMzogYW55LCBhNDogYW55LCBhNTogYW55LCBhNjogYW55KSB7XG4gICAgdGhpcy5hcmdzID0gW2ExLCBhMiwgYTMsIGE0LCBhNSwgYTZdO1xuICB9XG59XG5cbmNsYXNzIFRlc3RPYmpXaXRoMDdBcmdzIHtcbiAgYXJnczogYW55W107XG4gIGNvbnN0cnVjdG9yKGExOiBhbnksIGEyOiBhbnksIGEzOiBhbnksIGE0OiBhbnksIGE1OiBhbnksIGE2OiBhbnksIGE3OiBhbnkpIHtcbiAgICB0aGlzLmFyZ3MgPSBbYTEsIGEyLCBhMywgYTQsIGE1LCBhNiwgYTddO1xuICB9XG59XG5cbmNsYXNzIFRlc3RPYmpXaXRoMDhBcmdzIHtcbiAgYXJnczogYW55W107XG4gIGNvbnN0cnVjdG9yKGExOiBhbnksIGEyOiBhbnksIGEzOiBhbnksIGE0OiBhbnksIGE1OiBhbnksIGE2OiBhbnksIGE3OiBhbnksIGE4OiBhbnkpIHtcbiAgICB0aGlzLmFyZ3MgPSBbYTEsIGEyLCBhMywgYTQsIGE1LCBhNiwgYTcsIGE4XTtcbiAgfVxufVxuXG5jbGFzcyBUZXN0T2JqV2l0aDA5QXJncyB7XG4gIGFyZ3M6IGFueVtdO1xuICBjb25zdHJ1Y3RvcihhMTogYW55LCBhMjogYW55LCBhMzogYW55LCBhNDogYW55LCBhNTogYW55LCBhNjogYW55LCBhNzogYW55LCBhODogYW55LCBhOTogYW55KSB7XG4gICAgdGhpcy5hcmdzID0gW2ExLCBhMiwgYTMsIGE0LCBhNSwgYTYsIGE3LCBhOCwgYTldO1xuICB9XG59XG5cbmNsYXNzIFRlc3RPYmpXaXRoMTBBcmdzIHtcbiAgYXJnczogYW55W107XG4gIGNvbnN0cnVjdG9yKGExOiBhbnksIGEyOiBhbnksIGEzOiBhbnksIGE0OiBhbnksIGE1OiBhbnksIGE2OiBhbnksIGE3OiBhbnksIGE4OiBhbnksIGE5OiBhbnksXG4gICAgICAgICAgICAgIGExMDogYW55KSB7XG4gICAgdGhpcy5hcmdzID0gW2ExLCBhMiwgYTMsIGE0LCBhNSwgYTYsIGE3LCBhOCwgYTksIGExMF07XG4gIH1cbn1cblxuY2xhc3MgVGVzdE9ialdpdGgxMUFyZ3Mge1xuICBhcmdzOiBhbnlbXTtcbiAgY29uc3RydWN0b3IoYTE6IGFueSwgYTI6IGFueSwgYTM6IGFueSwgYTQ6IGFueSwgYTU6IGFueSwgYTY6IGFueSwgYTc6IGFueSwgYTg6IGFueSwgYTk6IGFueSxcbiAgICAgICAgICAgICAgYTEwOiBhbnksIGExMTogYW55KSB7XG4gICAgdGhpcy5hcmdzID0gW2ExLCBhMiwgYTMsIGE0LCBhNSwgYTYsIGE3LCBhOCwgYTksIGExMCwgYTExXTtcbiAgfVxufVxuXG5jbGFzcyBUZXN0T2JqV2l0aDEyQXJncyB7XG4gIGFyZ3M6IGFueVtdO1xuICBjb25zdHJ1Y3RvcihhMTogYW55LCBhMjogYW55LCBhMzogYW55LCBhNDogYW55LCBhNTogYW55LCBhNjogYW55LCBhNzogYW55LCBhODogYW55LCBhOTogYW55LFxuICAgICAgICAgICAgICBhMTA6IGFueSwgYTExOiBhbnksIGExMjogYW55KSB7XG4gICAgdGhpcy5hcmdzID0gW2ExLCBhMiwgYTMsIGE0LCBhNSwgYTYsIGE3LCBhOCwgYTksIGExMCwgYTExLCBhMTJdO1xuICB9XG59XG5cbmNsYXNzIFRlc3RPYmpXaXRoMTNBcmdzIHtcbiAgYXJnczogYW55W107XG4gIGNvbnN0cnVjdG9yKGExOiBhbnksIGEyOiBhbnksIGEzOiBhbnksIGE0OiBhbnksIGE1OiBhbnksIGE2OiBhbnksIGE3OiBhbnksIGE4OiBhbnksIGE5OiBhbnksXG4gICAgICAgICAgICAgIGExMDogYW55LCBhMTE6IGFueSwgYTEyOiBhbnksIGExMzogYW55KSB7XG4gICAgdGhpcy5hcmdzID0gW2ExLCBhMiwgYTMsIGE0LCBhNSwgYTYsIGE3LCBhOCwgYTksIGExMCwgYTExLCBhMTIsIGExM107XG4gIH1cbn1cblxuY2xhc3MgVGVzdE9ialdpdGgxNEFyZ3Mge1xuICBhcmdzOiBhbnlbXTtcbiAgY29uc3RydWN0b3IoYTE6IGFueSwgYTI6IGFueSwgYTM6IGFueSwgYTQ6IGFueSwgYTU6IGFueSwgYTY6IGFueSwgYTc6IGFueSwgYTg6IGFueSwgYTk6IGFueSxcbiAgICAgICAgICAgICAgYTEwOiBhbnksIGExMTogYW55LCBhMTI6IGFueSwgYTEzOiBhbnksIGExNDogYW55KSB7XG4gICAgdGhpcy5hcmdzID0gW2ExLCBhMiwgYTMsIGE0LCBhNSwgYTYsIGE3LCBhOCwgYTksIGExMCwgYTExLCBhMTIsIGExMywgYTE0XTtcbiAgfVxufVxuXG5jbGFzcyBUZXN0T2JqV2l0aDE1QXJncyB7XG4gIGFyZ3M6IGFueVtdO1xuICBjb25zdHJ1Y3RvcihhMTogYW55LCBhMjogYW55LCBhMzogYW55LCBhNDogYW55LCBhNTogYW55LCBhNjogYW55LCBhNzogYW55LCBhODogYW55LCBhOTogYW55LFxuICAgICAgICAgICAgICBhMTA6IGFueSwgYTExOiBhbnksIGExMjogYW55LCBhMTM6IGFueSwgYTE0OiBhbnksIGExNTogYW55KSB7XG4gICAgdGhpcy5hcmdzID0gW2ExLCBhMiwgYTMsIGE0LCBhNSwgYTYsIGE3LCBhOCwgYTksIGExMCwgYTExLCBhMTIsIGExMywgYTE0LCBhMTVdO1xuICB9XG59XG5cbmNsYXNzIFRlc3RPYmpXaXRoMTZBcmdzIHtcbiAgYXJnczogYW55W107XG4gIGNvbnN0cnVjdG9yKGExOiBhbnksIGEyOiBhbnksIGEzOiBhbnksIGE0OiBhbnksIGE1OiBhbnksIGE2OiBhbnksIGE3OiBhbnksIGE4OiBhbnksIGE5OiBhbnksXG4gICAgICAgICAgICAgIGExMDogYW55LCBhMTE6IGFueSwgYTEyOiBhbnksIGExMzogYW55LCBhMTQ6IGFueSwgYTE1OiBhbnksIGExNjogYW55KSB7XG4gICAgdGhpcy5hcmdzID0gW2ExLCBhMiwgYTMsIGE0LCBhNSwgYTYsIGE3LCBhOCwgYTksIGExMCwgYTExLCBhMTIsIGExMywgYTE0LCBhMTUsIGExNl07XG4gIH1cbn1cblxuY2xhc3MgVGVzdE9ialdpdGgxN0FyZ3Mge1xuICBhcmdzOiBhbnlbXTtcbiAgY29uc3RydWN0b3IoYTE6IGFueSwgYTI6IGFueSwgYTM6IGFueSwgYTQ6IGFueSwgYTU6IGFueSwgYTY6IGFueSwgYTc6IGFueSwgYTg6IGFueSwgYTk6IGFueSxcbiAgICAgICAgICAgICAgYTEwOiBhbnksIGExMTogYW55LCBhMTI6IGFueSwgYTEzOiBhbnksIGExNDogYW55LCBhMTU6IGFueSwgYTE2OiBhbnksIGExNzogYW55KSB7XG4gICAgdGhpcy5hcmdzID0gW2ExLCBhMiwgYTMsIGE0LCBhNSwgYTYsIGE3LCBhOCwgYTksIGExMCwgYTExLCBhMTIsIGExMywgYTE0LCBhMTUsIGExNiwgYTE3XTtcbiAgfVxufVxuXG5jbGFzcyBUZXN0T2JqV2l0aDE4QXJncyB7XG4gIGFyZ3M6IGFueVtdO1xuICBjb25zdHJ1Y3RvcihhMTogYW55LCBhMjogYW55LCBhMzogYW55LCBhNDogYW55LCBhNTogYW55LCBhNjogYW55LCBhNzogYW55LCBhODogYW55LCBhOTogYW55LFxuICAgICAgICAgICAgICBhMTA6IGFueSwgYTExOiBhbnksIGExMjogYW55LCBhMTM6IGFueSwgYTE0OiBhbnksIGExNTogYW55LCBhMTY6IGFueSwgYTE3OiBhbnksXG4gICAgICAgICAgICAgIGExODogYW55KSB7XG4gICAgdGhpcy5hcmdzID0gW2ExLCBhMiwgYTMsIGE0LCBhNSwgYTYsIGE3LCBhOCwgYTksIGExMCwgYTExLCBhMTIsIGExMywgYTE0LCBhMTUsIGExNiwgYTE3LCBhMThdO1xuICB9XG59XG5cbmNsYXNzIFRlc3RPYmpXaXRoMTlBcmdzIHtcbiAgYXJnczogYW55W107XG4gIGNvbnN0cnVjdG9yKGExOiBhbnksIGEyOiBhbnksIGEzOiBhbnksIGE0OiBhbnksIGE1OiBhbnksIGE2OiBhbnksIGE3OiBhbnksIGE4OiBhbnksIGE5OiBhbnksXG4gICAgICAgICAgICAgIGExMDogYW55LCBhMTE6IGFueSwgYTEyOiBhbnksIGExMzogYW55LCBhMTQ6IGFueSwgYTE1OiBhbnksIGExNjogYW55LCBhMTc6IGFueSxcbiAgICAgICAgICAgICAgYTE4OiBhbnksIGExOTogYW55KSB7XG4gICAgdGhpcy5hcmdzID1cbiAgICAgICAgW2ExLCBhMiwgYTMsIGE0LCBhNSwgYTYsIGE3LCBhOCwgYTksIGExMCwgYTExLCBhMTIsIGExMywgYTE0LCBhMTUsIGExNiwgYTE3LCBhMTgsIGExOV07XG4gIH1cbn1cblxuY2xhc3MgVGVzdE9ialdpdGgyMEFyZ3Mge1xuICBhcmdzOiBhbnlbXTtcbiAgY29uc3RydWN0b3IoYTE6IGFueSwgYTI6IGFueSwgYTM6IGFueSwgYTQ6IGFueSwgYTU6IGFueSwgYTY6IGFueSwgYTc6IGFueSwgYTg6IGFueSwgYTk6IGFueSxcbiAgICAgICAgICAgICAgYTEwOiBhbnksIGExMTogYW55LCBhMTI6IGFueSwgYTEzOiBhbnksIGExNDogYW55LCBhMTU6IGFueSwgYTE2OiBhbnksIGExNzogYW55LFxuICAgICAgICAgICAgICBhMTg6IGFueSwgYTE5OiBhbnksIGEyMDogYW55KSB7XG4gICAgdGhpcy5hcmdzID1cbiAgICAgICAgW2ExLCBhMiwgYTMsIGE0LCBhNSwgYTYsIGE3LCBhOCwgYTksIGExMCwgYTExLCBhMTIsIGExMywgYTE0LCBhMTUsIGExNiwgYTE3LCBhMTgsIGExOSwgYTIwXTtcbiAgfVxufVxuXG5jbGFzcyBUZXN0T2JqV2l0aDIxQXJncyB7XG4gIGFyZ3M6IGFueVtdO1xuICBjb25zdHJ1Y3RvcihhMTogYW55LCBhMjogYW55LCBhMzogYW55LCBhNDogYW55LCBhNTogYW55LCBhNjogYW55LCBhNzogYW55LCBhODogYW55LCBhOTogYW55LFxuICAgICAgICAgICAgICBhMTA6IGFueSwgYTExOiBhbnksIGExMjogYW55LCBhMTM6IGFueSwgYTE0OiBhbnksIGExNTogYW55LCBhMTY6IGFueSwgYTE3OiBhbnksXG4gICAgICAgICAgICAgIGExODogYW55LCBhMTk6IGFueSwgYTIwOiBhbnksIGEyMTogYW55KSB7XG4gICAgdGhpcy5hcmdzID0gW1xuICAgICAgYTEsXG4gICAgICBhMixcbiAgICAgIGEzLFxuICAgICAgYTQsXG4gICAgICBhNSxcbiAgICAgIGE2LFxuICAgICAgYTcsXG4gICAgICBhOCxcbiAgICAgIGE5LFxuICAgICAgYTEwLFxuICAgICAgYTExLFxuICAgICAgYTEyLFxuICAgICAgYTEzLFxuICAgICAgYTE0LFxuICAgICAgYTE1LFxuICAgICAgYTE2LFxuICAgICAgYTE3LFxuICAgICAgYTE4LFxuICAgICAgYTE5LFxuICAgICAgYTIwLFxuICAgICAgYTIxXG4gICAgXTtcbiAgfVxufVxuIl19
 main(); 
