'use strict';var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var change_detection_1 = require('angular2/src/core/change_detection/change_detection');
var api_1 = require('angular2/src/core/render/api');
var directive_resolver_1 = require('angular2/src/core/linker/directive_resolver');
var view_1 = require('angular2/src/core/linker/view');
var element_ref_1 = require('angular2/src/core/linker/element_ref');
var view_manager_1 = require('angular2/src/core/linker/view_manager');
var dom_adapter_1 = require('angular2/src/platform/dom/dom_adapter');
var testing_internal_1 = require('angular2/testing_internal');
var SpyDependencyProvider = (function (_super) {
    __extends(SpyDependencyProvider, _super);
    function SpyDependencyProvider() {
        _super.apply(this, arguments);
    }
    return SpyDependencyProvider;
})(testing_internal_1.SpyObject);
exports.SpyDependencyProvider = SpyDependencyProvider;
var SpyChangeDetector = (function (_super) {
    __extends(SpyChangeDetector, _super);
    function SpyChangeDetector() {
        _super.call(this, change_detection_1.DynamicChangeDetector);
    }
    return SpyChangeDetector;
})(testing_internal_1.SpyObject);
exports.SpyChangeDetector = SpyChangeDetector;
var SpyChangeDispatcher = (function (_super) {
    __extends(SpyChangeDispatcher, _super);
    function SpyChangeDispatcher() {
        _super.apply(this, arguments);
    }
    return SpyChangeDispatcher;
})(testing_internal_1.SpyObject);
exports.SpyChangeDispatcher = SpyChangeDispatcher;
var SpyIterableDifferFactory = (function (_super) {
    __extends(SpyIterableDifferFactory, _super);
    function SpyIterableDifferFactory() {
        _super.apply(this, arguments);
    }
    return SpyIterableDifferFactory;
})(testing_internal_1.SpyObject);
exports.SpyIterableDifferFactory = SpyIterableDifferFactory;
var SpyDirectiveResolver = (function (_super) {
    __extends(SpyDirectiveResolver, _super);
    function SpyDirectiveResolver() {
        _super.call(this, directive_resolver_1.DirectiveResolver);
    }
    return SpyDirectiveResolver;
})(testing_internal_1.SpyObject);
exports.SpyDirectiveResolver = SpyDirectiveResolver;
var SpyView = (function (_super) {
    __extends(SpyView, _super);
    function SpyView() {
        _super.call(this, view_1.AppView);
    }
    return SpyView;
})(testing_internal_1.SpyObject);
exports.SpyView = SpyView;
var SpyProtoView = (function (_super) {
    __extends(SpyProtoView, _super);
    function SpyProtoView() {
        _super.call(this, view_1.AppProtoView);
    }
    return SpyProtoView;
})(testing_internal_1.SpyObject);
exports.SpyProtoView = SpyProtoView;
var SpyHostViewFactory = (function (_super) {
    __extends(SpyHostViewFactory, _super);
    function SpyHostViewFactory() {
        _super.call(this, view_1.HostViewFactory);
    }
    return SpyHostViewFactory;
})(testing_internal_1.SpyObject);
exports.SpyHostViewFactory = SpyHostViewFactory;
var SpyElementRef = (function (_super) {
    __extends(SpyElementRef, _super);
    function SpyElementRef() {
        _super.call(this, element_ref_1.ElementRef);
    }
    return SpyElementRef;
})(testing_internal_1.SpyObject);
exports.SpyElementRef = SpyElementRef;
var SpyAppViewManager = (function (_super) {
    __extends(SpyAppViewManager, _super);
    function SpyAppViewManager() {
        _super.call(this, view_manager_1.AppViewManager_);
    }
    return SpyAppViewManager;
})(testing_internal_1.SpyObject);
exports.SpyAppViewManager = SpyAppViewManager;
var SpyRenderer = (function (_super) {
    __extends(SpyRenderer, _super);
    function SpyRenderer() {
        // Note: Renderer is an abstract class,
        // so we can't generates spy functions automatically
        // by inspecting the prototype...
        _super.call(this, api_1.Renderer);
        this.spy('renderComponent');
        this.spy('selectRootElement');
        this.spy('createElement');
        this.spy('createViewRoot');
        this.spy('createTemplateAnchor');
        this.spy('createText');
        this.spy('projectNodes');
        this.spy('attachViewAfter');
        this.spy('detachView');
        this.spy('destroyView');
        this.spy('listen');
        this.spy('listenGlobal');
        this.spy('setElementProperty');
        this.spy('setElementAttribute');
        this.spy('setBindingDebugInfo');
        this.spy('setElementDebugInfo');
        this.spy('setElementClass');
        this.spy('setElementStyle');
        this.spy('invokeElementMethod');
        this.spy('setText');
    }
    return SpyRenderer;
})(testing_internal_1.SpyObject);
exports.SpyRenderer = SpyRenderer;
var SpyRootRenderer = (function (_super) {
    __extends(SpyRootRenderer, _super);
    function SpyRootRenderer() {
        // Note: RootRenderer is an abstract class,
        // so we can't generates spy functions automatically
        // by inspecting the prototype...
        _super.call(this, SpyRootRenderer);
        this.spy('renderComponent');
    }
    return SpyRootRenderer;
})(testing_internal_1.SpyObject);
exports.SpyRootRenderer = SpyRootRenderer;
var SpyDomAdapter = (function (_super) {
    __extends(SpyDomAdapter, _super);
    function SpyDomAdapter() {
        _super.call(this, dom_adapter_1.DomAdapter);
    }
    return SpyDomAdapter;
})(testing_internal_1.SpyObject);
exports.SpyDomAdapter = SpyDomAdapter;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3BpZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L2NvcmUvc3BpZXMudHMiXSwibmFtZXMiOlsiU3B5RGVwZW5kZW5jeVByb3ZpZGVyIiwiU3B5RGVwZW5kZW5jeVByb3ZpZGVyLmNvbnN0cnVjdG9yIiwiU3B5Q2hhbmdlRGV0ZWN0b3IiLCJTcHlDaGFuZ2VEZXRlY3Rvci5jb25zdHJ1Y3RvciIsIlNweUNoYW5nZURpc3BhdGNoZXIiLCJTcHlDaGFuZ2VEaXNwYXRjaGVyLmNvbnN0cnVjdG9yIiwiU3B5SXRlcmFibGVEaWZmZXJGYWN0b3J5IiwiU3B5SXRlcmFibGVEaWZmZXJGYWN0b3J5LmNvbnN0cnVjdG9yIiwiU3B5RGlyZWN0aXZlUmVzb2x2ZXIiLCJTcHlEaXJlY3RpdmVSZXNvbHZlci5jb25zdHJ1Y3RvciIsIlNweVZpZXciLCJTcHlWaWV3LmNvbnN0cnVjdG9yIiwiU3B5UHJvdG9WaWV3IiwiU3B5UHJvdG9WaWV3LmNvbnN0cnVjdG9yIiwiU3B5SG9zdFZpZXdGYWN0b3J5IiwiU3B5SG9zdFZpZXdGYWN0b3J5LmNvbnN0cnVjdG9yIiwiU3B5RWxlbWVudFJlZiIsIlNweUVsZW1lbnRSZWYuY29uc3RydWN0b3IiLCJTcHlBcHBWaWV3TWFuYWdlciIsIlNweUFwcFZpZXdNYW5hZ2VyLmNvbnN0cnVjdG9yIiwiU3B5UmVuZGVyZXIiLCJTcHlSZW5kZXJlci5jb25zdHJ1Y3RvciIsIlNweVJvb3RSZW5kZXJlciIsIlNweVJvb3RSZW5kZXJlci5jb25zdHJ1Y3RvciIsIlNweURvbUFkYXB0ZXIiLCJTcHlEb21BZGFwdGVyLmNvbnN0cnVjdG9yIl0sIm1hcHBpbmdzIjoiOzs7OztBQUFBLGlDQUtPLHFEQUFxRCxDQUFDLENBQUE7QUFFN0Qsb0JBQXVCLDhCQUE4QixDQUFDLENBQUE7QUFDdEQsbUNBQWdDLDZDQUE2QyxDQUFDLENBQUE7QUFFOUUscUJBQXFELCtCQUErQixDQUFDLENBQUE7QUFDckYsNEJBQXlCLHNDQUFzQyxDQUFDLENBQUE7QUFDaEUsNkJBQThCLHVDQUF1QyxDQUFDLENBQUE7QUFDdEUsNEJBQXlCLHVDQUF1QyxDQUFDLENBQUE7QUFFakUsaUNBQStCLDJCQUEyQixDQUFDLENBQUE7QUFFM0Q7SUFBMkNBLHlDQUFTQTtJQUFwREE7UUFBMkNDLDhCQUFTQTtJQUFFQSxDQUFDQTtJQUFERCw0QkFBQ0E7QUFBREEsQ0FBQ0EsQUFBdkQsRUFBMkMsNEJBQVMsRUFBRztBQUExQyw2QkFBcUIsd0JBQXFCLENBQUE7QUFFdkQ7SUFBdUNFLHFDQUFTQTtJQUM5Q0E7UUFBZ0JDLGtCQUFNQSx3Q0FBcUJBLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBQ2pERCx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxFQUF1Qyw0QkFBUyxFQUUvQztBQUZZLHlCQUFpQixvQkFFN0IsQ0FBQTtBQUVEO0lBQXlDRSx1Q0FBU0E7SUFBbERBO1FBQXlDQyw4QkFBU0E7SUFBRUEsQ0FBQ0E7SUFBREQsMEJBQUNBO0FBQURBLENBQUNBLEFBQXJELEVBQXlDLDRCQUFTLEVBQUc7QUFBeEMsMkJBQW1CLHNCQUFxQixDQUFBO0FBRXJEO0lBQThDRSw0Q0FBU0E7SUFBdkRBO1FBQThDQyw4QkFBU0E7SUFBRUEsQ0FBQ0E7SUFBREQsK0JBQUNBO0FBQURBLENBQUNBLEFBQTFELEVBQThDLDRCQUFTLEVBQUc7QUFBN0MsZ0NBQXdCLDJCQUFxQixDQUFBO0FBRTFEO0lBQTBDRSx3Q0FBU0E7SUFDakRBO1FBQWdCQyxrQkFBTUEsc0NBQWlCQSxDQUFDQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUM3Q0QsMkJBQUNBO0FBQURBLENBQUNBLEFBRkQsRUFBMEMsNEJBQVMsRUFFbEQ7QUFGWSw0QkFBb0IsdUJBRWhDLENBQUE7QUFFRDtJQUE2QkUsMkJBQVNBO0lBQ3BDQTtRQUFnQkMsa0JBQU1BLGNBQU9BLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBQ25DRCxjQUFDQTtBQUFEQSxDQUFDQSxBQUZELEVBQTZCLDRCQUFTLEVBRXJDO0FBRlksZUFBTyxVQUVuQixDQUFBO0FBRUQ7SUFBa0NFLGdDQUFTQTtJQUN6Q0E7UUFBZ0JDLGtCQUFNQSxtQkFBWUEsQ0FBQ0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFDeENELG1CQUFDQTtBQUFEQSxDQUFDQSxBQUZELEVBQWtDLDRCQUFTLEVBRTFDO0FBRlksb0JBQVksZUFFeEIsQ0FBQTtBQUVEO0lBQXdDRSxzQ0FBU0E7SUFDL0NBO1FBQWdCQyxrQkFBTUEsc0JBQWVBLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBQzNDRCx5QkFBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxFQUF3Qyw0QkFBUyxFQUVoRDtBQUZZLDBCQUFrQixxQkFFOUIsQ0FBQTtBQUVEO0lBQW1DRSxpQ0FBU0E7SUFDMUNBO1FBQWdCQyxrQkFBTUEsd0JBQVVBLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBQ3RDRCxvQkFBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxFQUFtQyw0QkFBUyxFQUUzQztBQUZZLHFCQUFhLGdCQUV6QixDQUFBO0FBRUQ7SUFBdUNFLHFDQUFTQTtJQUM5Q0E7UUFBZ0JDLGtCQUFNQSw4QkFBZUEsQ0FBQ0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFDM0NELHdCQUFDQTtBQUFEQSxDQUFDQSxBQUZELEVBQXVDLDRCQUFTLEVBRS9DO0FBRlkseUJBQWlCLG9CQUU3QixDQUFBO0FBRUQ7SUFBaUNFLCtCQUFTQTtJQUN4Q0E7UUFDRUMsdUNBQXVDQTtRQUN2Q0Esb0RBQW9EQTtRQUNwREEsaUNBQWlDQTtRQUNqQ0Esa0JBQU1BLGNBQVFBLENBQUNBLENBQUNBO1FBQ2hCQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBO1FBQzVCQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxtQkFBbUJBLENBQUNBLENBQUNBO1FBQzlCQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQTtRQUMxQkEsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQTtRQUMzQkEsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0Esc0JBQXNCQSxDQUFDQSxDQUFDQTtRQUNqQ0EsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0E7UUFDdkJBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLGNBQWNBLENBQUNBLENBQUNBO1FBQ3pCQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBO1FBQzVCQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQTtRQUN2QkEsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7UUFDeEJBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBO1FBQ25CQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQTtRQUN6QkEsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0Esb0JBQW9CQSxDQUFDQSxDQUFDQTtRQUMvQkEsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQTtRQUNoQ0EsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQTtRQUNoQ0EsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQTtRQUNoQ0EsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQTtRQUM1QkEsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQTtRQUM1QkEsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQTtRQUNoQ0EsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7SUFDdEJBLENBQUNBO0lBQ0hELGtCQUFDQTtBQUFEQSxDQUFDQSxBQTNCRCxFQUFpQyw0QkFBUyxFQTJCekM7QUEzQlksbUJBQVcsY0EyQnZCLENBQUE7QUFFRDtJQUFxQ0UsbUNBQVNBO0lBQzVDQTtRQUNFQywyQ0FBMkNBO1FBQzNDQSxvREFBb0RBO1FBQ3BEQSxpQ0FBaUNBO1FBQ2pDQSxrQkFBTUEsZUFBZUEsQ0FBQ0EsQ0FBQ0E7UUFDdkJBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0E7SUFDOUJBLENBQUNBO0lBQ0hELHNCQUFDQTtBQUFEQSxDQUFDQSxBQVJELEVBQXFDLDRCQUFTLEVBUTdDO0FBUlksdUJBQWUsa0JBUTNCLENBQUE7QUFFRDtJQUFtQ0UsaUNBQVNBO0lBQzFDQTtRQUFnQkMsa0JBQU1BLHdCQUFVQSxDQUFDQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUN0Q0Qsb0JBQUNBO0FBQURBLENBQUNBLEFBRkQsRUFBbUMsNEJBQVMsRUFFM0M7QUFGWSxxQkFBYSxnQkFFekIsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIENoYW5nZURldGVjdG9yLFxuICBDaGFuZ2VEZXRlY3RvclJlZixcbiAgUHJvdG9DaGFuZ2VEZXRlY3RvcixcbiAgRHluYW1pY0NoYW5nZURldGVjdG9yXG59IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2NoYW5nZV9kZXRlY3Rpb24vY2hhbmdlX2RldGVjdGlvbic7XG5cbmltcG9ydCB7UmVuZGVyZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL3JlbmRlci9hcGknO1xuaW1wb3J0IHtEaXJlY3RpdmVSZXNvbHZlcn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvbGlua2VyL2RpcmVjdGl2ZV9yZXNvbHZlcic7XG5cbmltcG9ydCB7QXBwVmlldywgQXBwUHJvdG9WaWV3LCBIb3N0Vmlld0ZhY3Rvcnl9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci92aWV3JztcbmltcG9ydCB7RWxlbWVudFJlZn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvbGlua2VyL2VsZW1lbnRfcmVmJztcbmltcG9ydCB7QXBwVmlld01hbmFnZXJffSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9saW5rZXIvdmlld19tYW5hZ2VyJztcbmltcG9ydCB7RG9tQWRhcHRlcn0gZnJvbSAnYW5ndWxhcjIvc3JjL3BsYXRmb3JtL2RvbS9kb21fYWRhcHRlcic7XG5cbmltcG9ydCB7U3B5T2JqZWN0LCBwcm94eX0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmV4cG9ydCBjbGFzcyBTcHlEZXBlbmRlbmN5UHJvdmlkZXIgZXh0ZW5kcyBTcHlPYmplY3Qge31cblxuZXhwb3J0IGNsYXNzIFNweUNoYW5nZURldGVjdG9yIGV4dGVuZHMgU3B5T2JqZWN0IHtcbiAgY29uc3RydWN0b3IoKSB7IHN1cGVyKER5bmFtaWNDaGFuZ2VEZXRlY3Rvcik7IH1cbn1cblxuZXhwb3J0IGNsYXNzIFNweUNoYW5nZURpc3BhdGNoZXIgZXh0ZW5kcyBTcHlPYmplY3Qge31cblxuZXhwb3J0IGNsYXNzIFNweUl0ZXJhYmxlRGlmZmVyRmFjdG9yeSBleHRlbmRzIFNweU9iamVjdCB7fVxuXG5leHBvcnQgY2xhc3MgU3B5RGlyZWN0aXZlUmVzb2x2ZXIgZXh0ZW5kcyBTcHlPYmplY3Qge1xuICBjb25zdHJ1Y3RvcigpIHsgc3VwZXIoRGlyZWN0aXZlUmVzb2x2ZXIpOyB9XG59XG5cbmV4cG9ydCBjbGFzcyBTcHlWaWV3IGV4dGVuZHMgU3B5T2JqZWN0IHtcbiAgY29uc3RydWN0b3IoKSB7IHN1cGVyKEFwcFZpZXcpOyB9XG59XG5cbmV4cG9ydCBjbGFzcyBTcHlQcm90b1ZpZXcgZXh0ZW5kcyBTcHlPYmplY3Qge1xuICBjb25zdHJ1Y3RvcigpIHsgc3VwZXIoQXBwUHJvdG9WaWV3KTsgfVxufVxuXG5leHBvcnQgY2xhc3MgU3B5SG9zdFZpZXdGYWN0b3J5IGV4dGVuZHMgU3B5T2JqZWN0IHtcbiAgY29uc3RydWN0b3IoKSB7IHN1cGVyKEhvc3RWaWV3RmFjdG9yeSk7IH1cbn1cblxuZXhwb3J0IGNsYXNzIFNweUVsZW1lbnRSZWYgZXh0ZW5kcyBTcHlPYmplY3Qge1xuICBjb25zdHJ1Y3RvcigpIHsgc3VwZXIoRWxlbWVudFJlZik7IH1cbn1cblxuZXhwb3J0IGNsYXNzIFNweUFwcFZpZXdNYW5hZ2VyIGV4dGVuZHMgU3B5T2JqZWN0IHtcbiAgY29uc3RydWN0b3IoKSB7IHN1cGVyKEFwcFZpZXdNYW5hZ2VyXyk7IH1cbn1cblxuZXhwb3J0IGNsYXNzIFNweVJlbmRlcmVyIGV4dGVuZHMgU3B5T2JqZWN0IHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgLy8gTm90ZTogUmVuZGVyZXIgaXMgYW4gYWJzdHJhY3QgY2xhc3MsXG4gICAgLy8gc28gd2UgY2FuJ3QgZ2VuZXJhdGVzIHNweSBmdW5jdGlvbnMgYXV0b21hdGljYWxseVxuICAgIC8vIGJ5IGluc3BlY3RpbmcgdGhlIHByb3RvdHlwZS4uLlxuICAgIHN1cGVyKFJlbmRlcmVyKTtcbiAgICB0aGlzLnNweSgncmVuZGVyQ29tcG9uZW50Jyk7XG4gICAgdGhpcy5zcHkoJ3NlbGVjdFJvb3RFbGVtZW50Jyk7XG4gICAgdGhpcy5zcHkoJ2NyZWF0ZUVsZW1lbnQnKTtcbiAgICB0aGlzLnNweSgnY3JlYXRlVmlld1Jvb3QnKTtcbiAgICB0aGlzLnNweSgnY3JlYXRlVGVtcGxhdGVBbmNob3InKTtcbiAgICB0aGlzLnNweSgnY3JlYXRlVGV4dCcpO1xuICAgIHRoaXMuc3B5KCdwcm9qZWN0Tm9kZXMnKTtcbiAgICB0aGlzLnNweSgnYXR0YWNoVmlld0FmdGVyJyk7XG4gICAgdGhpcy5zcHkoJ2RldGFjaFZpZXcnKTtcbiAgICB0aGlzLnNweSgnZGVzdHJveVZpZXcnKTtcbiAgICB0aGlzLnNweSgnbGlzdGVuJyk7XG4gICAgdGhpcy5zcHkoJ2xpc3Rlbkdsb2JhbCcpO1xuICAgIHRoaXMuc3B5KCdzZXRFbGVtZW50UHJvcGVydHknKTtcbiAgICB0aGlzLnNweSgnc2V0RWxlbWVudEF0dHJpYnV0ZScpO1xuICAgIHRoaXMuc3B5KCdzZXRCaW5kaW5nRGVidWdJbmZvJyk7XG4gICAgdGhpcy5zcHkoJ3NldEVsZW1lbnREZWJ1Z0luZm8nKTtcbiAgICB0aGlzLnNweSgnc2V0RWxlbWVudENsYXNzJyk7XG4gICAgdGhpcy5zcHkoJ3NldEVsZW1lbnRTdHlsZScpO1xuICAgIHRoaXMuc3B5KCdpbnZva2VFbGVtZW50TWV0aG9kJyk7XG4gICAgdGhpcy5zcHkoJ3NldFRleHQnKTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgU3B5Um9vdFJlbmRlcmVyIGV4dGVuZHMgU3B5T2JqZWN0IHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgLy8gTm90ZTogUm9vdFJlbmRlcmVyIGlzIGFuIGFic3RyYWN0IGNsYXNzLFxuICAgIC8vIHNvIHdlIGNhbid0IGdlbmVyYXRlcyBzcHkgZnVuY3Rpb25zIGF1dG9tYXRpY2FsbHlcbiAgICAvLyBieSBpbnNwZWN0aW5nIHRoZSBwcm90b3R5cGUuLi5cbiAgICBzdXBlcihTcHlSb290UmVuZGVyZXIpO1xuICAgIHRoaXMuc3B5KCdyZW5kZXJDb21wb25lbnQnKTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgU3B5RG9tQWRhcHRlciBleHRlbmRzIFNweU9iamVjdCB7XG4gIGNvbnN0cnVjdG9yKCkgeyBzdXBlcihEb21BZGFwdGVyKTsgfVxufVxuIl19