'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var di_1 = require('angular2/src/core/di');
var testing_internal_1 = require('angular2/testing_internal');
var testability_1 = require('angular2/src/core/testability/testability');
var ng_zone_1 = require('angular2/src/core/zone/ng_zone');
var lang_1 = require('angular2/src/facade/lang');
var async_1 = require('angular2/src/facade/async');
// Schedules a microtasks (using a resolved promise .then())
function microTask(fn) {
    lang_1.scheduleMicroTask(function () {
        // We do double dispatch so that we  can wait for scheduleMicrotas in the Testability when
        // NgZone becomes stable.
        lang_1.scheduleMicroTask(fn);
    });
}
var MockNgZone = (function (_super) {
    __extends(MockNgZone, _super);
    function MockNgZone() {
        _super.call(this, { enableLongStackTrace: false });
        this._onUnstableStream = new async_1.EventEmitter(false);
        this._onStableStream = new async_1.EventEmitter(false);
    }
    Object.defineProperty(MockNgZone.prototype, "onUnstable", {
        get: function () { return this._onUnstableStream; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MockNgZone.prototype, "onStable", {
        get: function () { return this._onStableStream; },
        enumerable: true,
        configurable: true
    });
    MockNgZone.prototype.unstable = function () { async_1.ObservableWrapper.callEmit(this._onUnstableStream, null); };
    MockNgZone.prototype.stable = function () { async_1.ObservableWrapper.callEmit(this._onStableStream, null); };
    MockNgZone = __decorate([
        di_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], MockNgZone);
    return MockNgZone;
})(ng_zone_1.NgZone);
function main() {
    testing_internal_1.describe('Testability', function () {
        var testability;
        var execute;
        var execute2;
        var ngZone;
        testing_internal_1.beforeEach(function () {
            ngZone = new MockNgZone();
            testability = new testability_1.Testability(ngZone);
            execute = new testing_internal_1.SpyObject().spy('execute');
            execute2 = new testing_internal_1.SpyObject().spy('execute');
        });
        testing_internal_1.describe('Pending count logic', function () {
            testing_internal_1.it('should start with a pending count of 0', function () { testing_internal_1.expect(testability.getPendingRequestCount()).toEqual(0); });
            testing_internal_1.it('should fire whenstable callbacks if pending count is 0', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                testability.whenStable(execute);
                microTask(function () {
                    testing_internal_1.expect(execute).toHaveBeenCalled();
                    async.done();
                });
            }));
            testing_internal_1.it('should not fire whenstable callbacks synchronously if pending count is 0', function () {
                testability.whenStable(execute);
                testing_internal_1.expect(execute).not.toHaveBeenCalled();
            });
            testing_internal_1.it('should not call whenstable callbacks when there are pending counts', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                testability.increasePendingRequestCount();
                testability.increasePendingRequestCount();
                testability.whenStable(execute);
                microTask(function () {
                    testing_internal_1.expect(execute).not.toHaveBeenCalled();
                    testability.decreasePendingRequestCount();
                    microTask(function () {
                        testing_internal_1.expect(execute).not.toHaveBeenCalled();
                        async.done();
                    });
                });
            }));
            testing_internal_1.it('should fire whenstable callbacks when pending drops to 0', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                testability.increasePendingRequestCount();
                testability.whenStable(execute);
                microTask(function () {
                    testing_internal_1.expect(execute).not.toHaveBeenCalled();
                    testability.decreasePendingRequestCount();
                    microTask(function () {
                        testing_internal_1.expect(execute).toHaveBeenCalled();
                        async.done();
                    });
                });
            }));
            testing_internal_1.it('should not fire whenstable callbacks synchronously when pending drops to 0', function () {
                testability.increasePendingRequestCount();
                testability.whenStable(execute);
                testability.decreasePendingRequestCount();
                testing_internal_1.expect(execute).not.toHaveBeenCalled();
            });
            testing_internal_1.it('should fire whenstable callbacks with didWork if pending count is 0', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                testability.whenStable(execute);
                microTask(function () {
                    testing_internal_1.expect(execute).toHaveBeenCalledWith(false);
                    async.done();
                });
            }));
            testing_internal_1.it('should fire whenstable callbacks with didWork when pending drops to 0', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                testability.increasePendingRequestCount();
                testability.whenStable(execute);
                microTask(function () {
                    testability.decreasePendingRequestCount();
                    microTask(function () {
                        testing_internal_1.expect(execute).toHaveBeenCalledWith(true);
                        testability.whenStable(execute2);
                        microTask(function () {
                            testing_internal_1.expect(execute2).toHaveBeenCalledWith(false);
                            async.done();
                        });
                    });
                });
            }));
        });
        testing_internal_1.describe('NgZone callback logic', function () {
            testing_internal_1.it('should fire whenstable callback if event is already finished', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                ngZone.unstable();
                ngZone.stable();
                testability.whenStable(execute);
                microTask(function () {
                    testing_internal_1.expect(execute).toHaveBeenCalled();
                    async.done();
                });
            }));
            testing_internal_1.it('should not fire whenstable callbacks synchronously if event is already finished', function () {
                ngZone.unstable();
                ngZone.stable();
                testability.whenStable(execute);
                testing_internal_1.expect(execute).not.toHaveBeenCalled();
            });
            testing_internal_1.it('should fire whenstable callback when event finishes', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                ngZone.unstable();
                testability.whenStable(execute);
                microTask(function () {
                    testing_internal_1.expect(execute).not.toHaveBeenCalled();
                    ngZone.stable();
                    microTask(function () {
                        testing_internal_1.expect(execute).toHaveBeenCalled();
                        async.done();
                    });
                });
            }));
            testing_internal_1.it('should not fire whenstable callbacks synchronously when event finishes', function () {
                ngZone.unstable();
                testability.whenStable(execute);
                ngZone.stable();
                testing_internal_1.expect(execute).not.toHaveBeenCalled();
            });
            testing_internal_1.it('should not fire whenstable callback when event did not finish', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                ngZone.unstable();
                testability.increasePendingRequestCount();
                testability.whenStable(execute);
                microTask(function () {
                    testing_internal_1.expect(execute).not.toHaveBeenCalled();
                    testability.decreasePendingRequestCount();
                    microTask(function () {
                        testing_internal_1.expect(execute).not.toHaveBeenCalled();
                        ngZone.stable();
                        microTask(function () {
                            testing_internal_1.expect(execute).toHaveBeenCalled();
                            async.done();
                        });
                    });
                });
            }));
            testing_internal_1.it('should not fire whenstable callback when there are pending counts', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                ngZone.unstable();
                testability.increasePendingRequestCount();
                testability.increasePendingRequestCount();
                testability.whenStable(execute);
                microTask(function () {
                    testing_internal_1.expect(execute).not.toHaveBeenCalled();
                    ngZone.stable();
                    microTask(function () {
                        testing_internal_1.expect(execute).not.toHaveBeenCalled();
                        testability.decreasePendingRequestCount();
                        microTask(function () {
                            testing_internal_1.expect(execute).not.toHaveBeenCalled();
                            testability.decreasePendingRequestCount();
                            microTask(function () {
                                testing_internal_1.expect(execute).toHaveBeenCalled();
                                async.done();
                            });
                        });
                    });
                });
            }));
            testing_internal_1.it('should fire whenstable callback with didWork if event is already finished', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                ngZone.unstable();
                ngZone.stable();
                testability.whenStable(execute);
                microTask(function () {
                    testing_internal_1.expect(execute).toHaveBeenCalledWith(true);
                    testability.whenStable(execute2);
                    microTask(function () {
                        testing_internal_1.expect(execute2).toHaveBeenCalledWith(false);
                        async.done();
                    });
                });
            }));
            testing_internal_1.it('should fire whenstable callback with didwork when event finishes', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                ngZone.unstable();
                testability.whenStable(execute);
                microTask(function () {
                    ngZone.stable();
                    microTask(function () {
                        testing_internal_1.expect(execute).toHaveBeenCalledWith(true);
                        testability.whenStable(execute2);
                        microTask(function () {
                            testing_internal_1.expect(execute2).toHaveBeenCalledWith(false);
                            async.done();
                        });
                    });
                });
            }));
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVzdGFiaWxpdHlfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29yZS90ZXN0YWJpbGl0eS90ZXN0YWJpbGl0eV9zcGVjLnRzIl0sIm5hbWVzIjpbIm1pY3JvVGFzayIsIk1vY2tOZ1pvbmUiLCJNb2NrTmdab25lLmNvbnN0cnVjdG9yIiwiTW9ja05nWm9uZS5vblVuc3RhYmxlIiwiTW9ja05nWm9uZS5vblN0YWJsZSIsIk1vY2tOZ1pvbmUudW5zdGFibGUiLCJNb2NrTmdab25lLnN0YWJsZSIsIm1haW4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQUEsbUJBQXlCLHNCQUFzQixDQUFDLENBQUE7QUFDaEQsaUNBWU8sMkJBQTJCLENBQUMsQ0FBQTtBQUNuQyw0QkFBMEIsMkNBQTJDLENBQUMsQ0FBQTtBQUN0RSx3QkFBcUIsZ0NBQWdDLENBQUMsQ0FBQTtBQUN0RCxxQkFBZ0QsMEJBQTBCLENBQUMsQ0FBQTtBQUMzRSxzQkFBOEQsMkJBQTJCLENBQUMsQ0FBQTtBQUUxRiw0REFBNEQ7QUFDNUQsbUJBQW1CLEVBQVk7SUFDN0JBLHdCQUFpQkEsQ0FBQ0E7UUFDaEJBLDBGQUEwRkE7UUFDMUZBLHlCQUF5QkE7UUFDekJBLHdCQUFpQkEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7SUFDeEJBLENBQUNBLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBRUQ7SUFDeUJDLDhCQUFNQTtJQU83QkE7UUFDRUMsa0JBQU1BLEVBQUNBLG9CQUFvQkEsRUFBRUEsS0FBS0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDckNBLElBQUlBLENBQUNBLGlCQUFpQkEsR0FBR0EsSUFBSUEsb0JBQVlBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO1FBQ2pEQSxJQUFJQSxDQUFDQSxlQUFlQSxHQUFHQSxJQUFJQSxvQkFBWUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0E7SUFDakRBLENBQUNBO0lBVERELHNCQUFJQSxrQ0FBVUE7YUFBZEEsY0FBbUJFLE1BQU1BLENBQUNBLElBQUlBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7OztPQUFBRjtJQUduREEsc0JBQUlBLGdDQUFRQTthQUFaQSxjQUFpQkcsTUFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7OztPQUFBSDtJQVEvQ0EsNkJBQVFBLEdBQVJBLGNBQW1CSSx5QkFBaUJBLENBQUNBLFFBQVFBLENBQUNBLElBQUlBLENBQUNBLGlCQUFpQkEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFFOUVKLDJCQUFNQSxHQUFOQSxjQUFpQksseUJBQWlCQSxDQUFDQSxRQUFRQSxDQUFDQSxJQUFJQSxDQUFDQSxlQUFlQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQWhCNUVMO1FBQUNBLGVBQVVBLEVBQUVBOzttQkFpQlpBO0lBQURBLGlCQUFDQTtBQUFEQSxDQUFDQSxBQWpCRCxFQUN5QixnQkFBTSxFQWdCOUI7QUFFRDtJQUNFTSwyQkFBUUEsQ0FBQ0EsYUFBYUEsRUFBRUE7UUFDdEJBLElBQUlBLFdBQXdCQSxDQUFDQTtRQUM3QkEsSUFBSUEsT0FBWUEsQ0FBQ0E7UUFDakJBLElBQUlBLFFBQWFBLENBQUNBO1FBQ2xCQSxJQUFJQSxNQUFrQkEsQ0FBQ0E7UUFFdkJBLDZCQUFVQSxDQUFDQTtZQUNUQSxNQUFNQSxHQUFHQSxJQUFJQSxVQUFVQSxFQUFFQSxDQUFDQTtZQUMxQkEsV0FBV0EsR0FBR0EsSUFBSUEseUJBQVdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO1lBQ3RDQSxPQUFPQSxHQUFHQSxJQUFJQSw0QkFBU0EsRUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7WUFDekNBLFFBQVFBLEdBQUdBLElBQUlBLDRCQUFTQSxFQUFFQSxDQUFDQSxHQUFHQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQTtRQUM1Q0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEsMkJBQVFBLENBQUNBLHFCQUFxQkEsRUFBRUE7WUFDOUJBLHFCQUFFQSxDQUFDQSx3Q0FBd0NBLEVBQ3hDQSxjQUFRQSx5QkFBTUEsQ0FBQ0EsV0FBV0EsQ0FBQ0Esc0JBQXNCQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUV2RUEscUJBQUVBLENBQUNBLHdEQUF3REEsRUFDeERBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO2dCQUNqQ0EsV0FBV0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ2hDQSxTQUFTQSxDQUFDQTtvQkFDUkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLGdCQUFnQkEsRUFBRUEsQ0FBQ0E7b0JBQ25DQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFUEEscUJBQUVBLENBQUNBLDBFQUEwRUEsRUFBRUE7Z0JBQzdFQSxXQUFXQSxDQUFDQSxVQUFVQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtnQkFDaENBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLEVBQUVBLENBQUNBO1lBQ3pDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0Esb0VBQW9FQSxFQUNwRUEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7Z0JBQ2pDQSxXQUFXQSxDQUFDQSwyQkFBMkJBLEVBQUVBLENBQUNBO2dCQUMxQ0EsV0FBV0EsQ0FBQ0EsMkJBQTJCQSxFQUFFQSxDQUFDQTtnQkFDMUNBLFdBQVdBLENBQUNBLFVBQVVBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO2dCQUVoQ0EsU0FBU0EsQ0FBQ0E7b0JBQ1JBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLEVBQUVBLENBQUNBO29CQUN2Q0EsV0FBV0EsQ0FBQ0EsMkJBQTJCQSxFQUFFQSxDQUFDQTtvQkFFMUNBLFNBQVNBLENBQUNBO3dCQUNSQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxFQUFFQSxDQUFDQTt3QkFDdkNBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO29CQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFUEEscUJBQUVBLENBQUNBLDBEQUEwREEsRUFDMURBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO2dCQUNqQ0EsV0FBV0EsQ0FBQ0EsMkJBQTJCQSxFQUFFQSxDQUFDQTtnQkFDMUNBLFdBQVdBLENBQUNBLFVBQVVBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO2dCQUVoQ0EsU0FBU0EsQ0FBQ0E7b0JBQ1JBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLEVBQUVBLENBQUNBO29CQUN2Q0EsV0FBV0EsQ0FBQ0EsMkJBQTJCQSxFQUFFQSxDQUFDQTtvQkFFMUNBLFNBQVNBLENBQUNBO3dCQUNSQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxFQUFFQSxDQUFDQTt3QkFDbkNBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO29CQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFUEEscUJBQUVBLENBQUNBLDRFQUE0RUEsRUFBRUE7Z0JBQy9FQSxXQUFXQSxDQUFDQSwyQkFBMkJBLEVBQUVBLENBQUNBO2dCQUMxQ0EsV0FBV0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ2hDQSxXQUFXQSxDQUFDQSwyQkFBMkJBLEVBQUVBLENBQUNBO2dCQUUxQ0EseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLGdCQUFnQkEsRUFBRUEsQ0FBQ0E7WUFDekNBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxxRUFBcUVBLEVBQ3JFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtnQkFDakNBLFdBQVdBLENBQUNBLFVBQVVBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO2dCQUNoQ0EsU0FBU0EsQ0FBQ0E7b0JBQ1JBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxvQkFBb0JBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO29CQUM1Q0EsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ0xBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSx1RUFBdUVBLEVBQ3ZFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtnQkFDakNBLFdBQVdBLENBQUNBLDJCQUEyQkEsRUFBRUEsQ0FBQ0E7Z0JBQzFDQSxXQUFXQSxDQUFDQSxVQUFVQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtnQkFFaENBLFNBQVNBLENBQUNBO29CQUNSQSxXQUFXQSxDQUFDQSwyQkFBMkJBLEVBQUVBLENBQUNBO29CQUUxQ0EsU0FBU0EsQ0FBQ0E7d0JBQ1JBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxvQkFBb0JBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO3dCQUMzQ0EsV0FBV0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0E7d0JBRWpDQSxTQUFTQSxDQUFDQTs0QkFDUkEseUJBQU1BLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0E7NEJBQzdDQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTt3QkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ0xBLENBQUNBLENBQUNBLENBQUNBO2dCQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNMQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsdUJBQXVCQSxFQUFFQTtZQUNoQ0EscUJBQUVBLENBQUNBLDhEQUE4REEsRUFDOURBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO2dCQUNqQ0EsTUFBTUEsQ0FBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0E7Z0JBQ2xCQSxNQUFNQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQTtnQkFDaEJBLFdBQVdBLENBQUNBLFVBQVVBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO2dCQUVoQ0EsU0FBU0EsQ0FBQ0E7b0JBQ1JBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLEVBQUVBLENBQUNBO29CQUNuQ0EsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ0xBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSxpRkFBaUZBLEVBQUVBO2dCQUNwRkEsTUFBTUEsQ0FBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0E7Z0JBQ2xCQSxNQUFNQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQTtnQkFDaEJBLFdBQVdBLENBQUNBLFVBQVVBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO2dCQUVoQ0EseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLGdCQUFnQkEsRUFBRUEsQ0FBQ0E7WUFDekNBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxxREFBcURBLEVBQ3JEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtnQkFDakNBLE1BQU1BLENBQUNBLFFBQVFBLEVBQUVBLENBQUNBO2dCQUNsQkEsV0FBV0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7Z0JBRWhDQSxTQUFTQSxDQUFDQTtvQkFDUkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLGdCQUFnQkEsRUFBRUEsQ0FBQ0E7b0JBQ3ZDQSxNQUFNQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQTtvQkFFaEJBLFNBQVNBLENBQUNBO3dCQUNSQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxFQUFFQSxDQUFDQTt3QkFDbkNBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO29CQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFUEEscUJBQUVBLENBQUNBLHdFQUF3RUEsRUFBRUE7Z0JBQzNFQSxNQUFNQSxDQUFDQSxRQUFRQSxFQUFFQSxDQUFDQTtnQkFDbEJBLFdBQVdBLENBQUNBLFVBQVVBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO2dCQUNoQ0EsTUFBTUEsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0E7Z0JBRWhCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxFQUFFQSxDQUFDQTtZQUN6Q0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLCtEQUErREEsRUFDL0RBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO2dCQUNqQ0EsTUFBTUEsQ0FBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0E7Z0JBQ2xCQSxXQUFXQSxDQUFDQSwyQkFBMkJBLEVBQUVBLENBQUNBO2dCQUMxQ0EsV0FBV0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7Z0JBRWhDQSxTQUFTQSxDQUFDQTtvQkFDUkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLGdCQUFnQkEsRUFBRUEsQ0FBQ0E7b0JBQ3ZDQSxXQUFXQSxDQUFDQSwyQkFBMkJBLEVBQUVBLENBQUNBO29CQUUxQ0EsU0FBU0EsQ0FBQ0E7d0JBQ1JBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLEVBQUVBLENBQUNBO3dCQUN2Q0EsTUFBTUEsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0E7d0JBRWhCQSxTQUFTQSxDQUFDQTs0QkFDUkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLGdCQUFnQkEsRUFBRUEsQ0FBQ0E7NEJBQ25DQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTt3QkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ0xBLENBQUNBLENBQUNBLENBQUNBO2dCQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNMQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVQQSxxQkFBRUEsQ0FBQ0EsbUVBQW1FQSxFQUNuRUEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7Z0JBQ2pDQSxNQUFNQSxDQUFDQSxRQUFRQSxFQUFFQSxDQUFDQTtnQkFDbEJBLFdBQVdBLENBQUNBLDJCQUEyQkEsRUFBRUEsQ0FBQ0E7Z0JBQzFDQSxXQUFXQSxDQUFDQSwyQkFBMkJBLEVBQUVBLENBQUNBO2dCQUMxQ0EsV0FBV0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7Z0JBRWhDQSxTQUFTQSxDQUFDQTtvQkFDUkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLGdCQUFnQkEsRUFBRUEsQ0FBQ0E7b0JBQ3ZDQSxNQUFNQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQTtvQkFFaEJBLFNBQVNBLENBQUNBO3dCQUNSQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxFQUFFQSxDQUFDQTt3QkFDdkNBLFdBQVdBLENBQUNBLDJCQUEyQkEsRUFBRUEsQ0FBQ0E7d0JBRTFDQSxTQUFTQSxDQUFDQTs0QkFDUkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLGdCQUFnQkEsRUFBRUEsQ0FBQ0E7NEJBQ3ZDQSxXQUFXQSxDQUFDQSwyQkFBMkJBLEVBQUVBLENBQUNBOzRCQUUxQ0EsU0FBU0EsQ0FBQ0E7Z0NBQ1JBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLEVBQUVBLENBQUNBO2dDQUNuQ0EsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7NEJBQ2ZBLENBQUNBLENBQUNBLENBQUNBO3dCQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ0xBLENBQUNBLENBQUNBLENBQUNBO1lBQ0xBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSwyRUFBMkVBLEVBQzNFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtnQkFDakNBLE1BQU1BLENBQUNBLFFBQVFBLEVBQUVBLENBQUNBO2dCQUNsQkEsTUFBTUEsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0E7Z0JBQ2hCQSxXQUFXQSxDQUFDQSxVQUFVQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtnQkFFaENBLFNBQVNBLENBQUNBO29CQUNSQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0Esb0JBQW9CQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtvQkFDM0NBLFdBQVdBLENBQUNBLFVBQVVBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBO29CQUVqQ0EsU0FBU0EsQ0FBQ0E7d0JBQ1JBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxvQkFBb0JBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO3dCQUM3Q0EsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7b0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO2dCQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNMQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVQQSxxQkFBRUEsQ0FBQ0Esa0VBQWtFQSxFQUNsRUEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7Z0JBQ2pDQSxNQUFNQSxDQUFDQSxRQUFRQSxFQUFFQSxDQUFDQTtnQkFDbEJBLFdBQVdBLENBQUNBLFVBQVVBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO2dCQUVoQ0EsU0FBU0EsQ0FBQ0E7b0JBQ1JBLE1BQU1BLENBQUNBLE1BQU1BLEVBQUVBLENBQUNBO29CQUVoQkEsU0FBU0EsQ0FBQ0E7d0JBQ1JBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxvQkFBb0JBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO3dCQUMzQ0EsV0FBV0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0E7d0JBRWpDQSxTQUFTQSxDQUFDQTs0QkFDUkEseUJBQU1BLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0E7NEJBQzdDQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTt3QkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ0xBLENBQUNBLENBQUNBLENBQUNBO2dCQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNMQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQTVPZSxZQUFJLE9BNE9uQixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtJbmplY3RhYmxlfSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9kaSc7XG5pbXBvcnQge1xuICBBc3luY1Rlc3RDb21wbGV0ZXIsXG4gIGluamVjdCxcbiAgZGVzY3JpYmUsXG4gIGRkZXNjcmliZSxcbiAgaXQsXG4gIGlpdCxcbiAgeGl0LFxuICB4ZGVzY3JpYmUsXG4gIGV4cGVjdCxcbiAgYmVmb3JlRWFjaCxcbiAgU3B5T2JqZWN0XG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuaW1wb3J0IHtUZXN0YWJpbGl0eX0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvdGVzdGFiaWxpdHkvdGVzdGFiaWxpdHknO1xuaW1wb3J0IHtOZ1pvbmV9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL3pvbmUvbmdfem9uZSc7XG5pbXBvcnQge25vcm1hbGl6ZUJsYW5rLCBzY2hlZHVsZU1pY3JvVGFza30gZnJvbSAnYW5ndWxhcjIvc3JjL2ZhY2FkZS9sYW5nJztcbmltcG9ydCB7UHJvbWlzZVdyYXBwZXIsIEV2ZW50RW1pdHRlciwgT2JzZXJ2YWJsZVdyYXBwZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvYXN5bmMnO1xuXG4vLyBTY2hlZHVsZXMgYSBtaWNyb3Rhc2tzICh1c2luZyBhIHJlc29sdmVkIHByb21pc2UgLnRoZW4oKSlcbmZ1bmN0aW9uIG1pY3JvVGFzayhmbjogRnVuY3Rpb24pOiB2b2lkIHtcbiAgc2NoZWR1bGVNaWNyb1Rhc2soKCkgPT4ge1xuICAgIC8vIFdlIGRvIGRvdWJsZSBkaXNwYXRjaCBzbyB0aGF0IHdlICBjYW4gd2FpdCBmb3Igc2NoZWR1bGVNaWNyb3RhcyBpbiB0aGUgVGVzdGFiaWxpdHkgd2hlblxuICAgIC8vIE5nWm9uZSBiZWNvbWVzIHN0YWJsZS5cbiAgICBzY2hlZHVsZU1pY3JvVGFzayhmbik7XG4gIH0pO1xufVxuXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBNb2NrTmdab25lIGV4dGVuZHMgTmdab25lIHtcbiAgX29uVW5zdGFibGVTdHJlYW06IEV2ZW50RW1pdHRlcjxhbnk+O1xuICBnZXQgb25VbnN0YWJsZSgpIHsgcmV0dXJuIHRoaXMuX29uVW5zdGFibGVTdHJlYW07IH1cblxuICBfb25TdGFibGVTdHJlYW06IEV2ZW50RW1pdHRlcjxhbnk+O1xuICBnZXQgb25TdGFibGUoKSB7IHJldHVybiB0aGlzLl9vblN0YWJsZVN0cmVhbTsgfVxuXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKHtlbmFibGVMb25nU3RhY2tUcmFjZTogZmFsc2V9KTtcbiAgICB0aGlzLl9vblVuc3RhYmxlU3RyZWFtID0gbmV3IEV2ZW50RW1pdHRlcihmYWxzZSk7XG4gICAgdGhpcy5fb25TdGFibGVTdHJlYW0gPSBuZXcgRXZlbnRFbWl0dGVyKGZhbHNlKTtcbiAgfVxuXG4gIHVuc3RhYmxlKCk6IHZvaWQgeyBPYnNlcnZhYmxlV3JhcHBlci5jYWxsRW1pdCh0aGlzLl9vblVuc3RhYmxlU3RyZWFtLCBudWxsKTsgfVxuXG4gIHN0YWJsZSgpOiB2b2lkIHsgT2JzZXJ2YWJsZVdyYXBwZXIuY2FsbEVtaXQodGhpcy5fb25TdGFibGVTdHJlYW0sIG51bGwpOyB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgnVGVzdGFiaWxpdHknLCAoKSA9PiB7XG4gICAgdmFyIHRlc3RhYmlsaXR5OiBUZXN0YWJpbGl0eTtcbiAgICB2YXIgZXhlY3V0ZTogYW55O1xuICAgIHZhciBleGVjdXRlMjogYW55O1xuICAgIHZhciBuZ1pvbmU6IE1vY2tOZ1pvbmU7XG5cbiAgICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICAgIG5nWm9uZSA9IG5ldyBNb2NrTmdab25lKCk7XG4gICAgICB0ZXN0YWJpbGl0eSA9IG5ldyBUZXN0YWJpbGl0eShuZ1pvbmUpO1xuICAgICAgZXhlY3V0ZSA9IG5ldyBTcHlPYmplY3QoKS5zcHkoJ2V4ZWN1dGUnKTtcbiAgICAgIGV4ZWN1dGUyID0gbmV3IFNweU9iamVjdCgpLnNweSgnZXhlY3V0ZScpO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ1BlbmRpbmcgY291bnQgbG9naWMnLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIHN0YXJ0IHdpdGggYSBwZW5kaW5nIGNvdW50IG9mIDAnLFxuICAgICAgICAgKCkgPT4geyBleHBlY3QodGVzdGFiaWxpdHkuZ2V0UGVuZGluZ1JlcXVlc3RDb3VudCgpKS50b0VxdWFsKDApOyB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBmaXJlIHdoZW5zdGFibGUgY2FsbGJhY2tzIGlmIHBlbmRpbmcgY291bnQgaXMgMCcsXG4gICAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICB0ZXN0YWJpbGl0eS53aGVuU3RhYmxlKGV4ZWN1dGUpO1xuICAgICAgICAgICBtaWNyb1Rhc2soKCkgPT4ge1xuICAgICAgICAgICAgIGV4cGVjdChleGVjdXRlKS50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBub3QgZmlyZSB3aGVuc3RhYmxlIGNhbGxiYWNrcyBzeW5jaHJvbm91c2x5IGlmIHBlbmRpbmcgY291bnQgaXMgMCcsICgpID0+IHtcbiAgICAgICAgdGVzdGFiaWxpdHkud2hlblN0YWJsZShleGVjdXRlKTtcbiAgICAgICAgZXhwZWN0KGV4ZWN1dGUpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBub3QgY2FsbCB3aGVuc3RhYmxlIGNhbGxiYWNrcyB3aGVuIHRoZXJlIGFyZSBwZW5kaW5nIGNvdW50cycsXG4gICAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICB0ZXN0YWJpbGl0eS5pbmNyZWFzZVBlbmRpbmdSZXF1ZXN0Q291bnQoKTtcbiAgICAgICAgICAgdGVzdGFiaWxpdHkuaW5jcmVhc2VQZW5kaW5nUmVxdWVzdENvdW50KCk7XG4gICAgICAgICAgIHRlc3RhYmlsaXR5LndoZW5TdGFibGUoZXhlY3V0ZSk7XG5cbiAgICAgICAgICAgbWljcm9UYXNrKCgpID0+IHtcbiAgICAgICAgICAgICBleHBlY3QoZXhlY3V0ZSkubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgICAgICAgICAgICB0ZXN0YWJpbGl0eS5kZWNyZWFzZVBlbmRpbmdSZXF1ZXN0Q291bnQoKTtcblxuICAgICAgICAgICAgIG1pY3JvVGFzaygoKSA9PiB7XG4gICAgICAgICAgICAgICBleHBlY3QoZXhlY3V0ZSkubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgZmlyZSB3aGVuc3RhYmxlIGNhbGxiYWNrcyB3aGVuIHBlbmRpbmcgZHJvcHMgdG8gMCcsXG4gICAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICB0ZXN0YWJpbGl0eS5pbmNyZWFzZVBlbmRpbmdSZXF1ZXN0Q291bnQoKTtcbiAgICAgICAgICAgdGVzdGFiaWxpdHkud2hlblN0YWJsZShleGVjdXRlKTtcblxuICAgICAgICAgICBtaWNyb1Rhc2soKCkgPT4ge1xuICAgICAgICAgICAgIGV4cGVjdChleGVjdXRlKS5ub3QudG9IYXZlQmVlbkNhbGxlZCgpO1xuICAgICAgICAgICAgIHRlc3RhYmlsaXR5LmRlY3JlYXNlUGVuZGluZ1JlcXVlc3RDb3VudCgpO1xuXG4gICAgICAgICAgICAgbWljcm9UYXNrKCgpID0+IHtcbiAgICAgICAgICAgICAgIGV4cGVjdChleGVjdXRlKS50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIG5vdCBmaXJlIHdoZW5zdGFibGUgY2FsbGJhY2tzIHN5bmNocm9ub3VzbHkgd2hlbiBwZW5kaW5nIGRyb3BzIHRvIDAnLCAoKSA9PiB7XG4gICAgICAgIHRlc3RhYmlsaXR5LmluY3JlYXNlUGVuZGluZ1JlcXVlc3RDb3VudCgpO1xuICAgICAgICB0ZXN0YWJpbGl0eS53aGVuU3RhYmxlKGV4ZWN1dGUpO1xuICAgICAgICB0ZXN0YWJpbGl0eS5kZWNyZWFzZVBlbmRpbmdSZXF1ZXN0Q291bnQoKTtcblxuICAgICAgICBleHBlY3QoZXhlY3V0ZSkubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIGZpcmUgd2hlbnN0YWJsZSBjYWxsYmFja3Mgd2l0aCBkaWRXb3JrIGlmIHBlbmRpbmcgY291bnQgaXMgMCcsXG4gICAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICB0ZXN0YWJpbGl0eS53aGVuU3RhYmxlKGV4ZWN1dGUpO1xuICAgICAgICAgICBtaWNyb1Rhc2soKCkgPT4ge1xuICAgICAgICAgICAgIGV4cGVjdChleGVjdXRlKS50b0hhdmVCZWVuQ2FsbGVkV2l0aChmYWxzZSk7XG4gICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBmaXJlIHdoZW5zdGFibGUgY2FsbGJhY2tzIHdpdGggZGlkV29yayB3aGVuIHBlbmRpbmcgZHJvcHMgdG8gMCcsXG4gICAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICB0ZXN0YWJpbGl0eS5pbmNyZWFzZVBlbmRpbmdSZXF1ZXN0Q291bnQoKTtcbiAgICAgICAgICAgdGVzdGFiaWxpdHkud2hlblN0YWJsZShleGVjdXRlKTtcblxuICAgICAgICAgICBtaWNyb1Rhc2soKCkgPT4ge1xuICAgICAgICAgICAgIHRlc3RhYmlsaXR5LmRlY3JlYXNlUGVuZGluZ1JlcXVlc3RDb3VudCgpO1xuXG4gICAgICAgICAgICAgbWljcm9UYXNrKCgpID0+IHtcbiAgICAgICAgICAgICAgIGV4cGVjdChleGVjdXRlKS50b0hhdmVCZWVuQ2FsbGVkV2l0aCh0cnVlKTtcbiAgICAgICAgICAgICAgIHRlc3RhYmlsaXR5LndoZW5TdGFibGUoZXhlY3V0ZTIpO1xuXG4gICAgICAgICAgICAgICBtaWNyb1Rhc2soKCkgPT4ge1xuICAgICAgICAgICAgICAgICBleHBlY3QoZXhlY3V0ZTIpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ05nWm9uZSBjYWxsYmFjayBsb2dpYycsICgpID0+IHtcbiAgICAgIGl0KCdzaG91bGQgZmlyZSB3aGVuc3RhYmxlIGNhbGxiYWNrIGlmIGV2ZW50IGlzIGFscmVhZHkgZmluaXNoZWQnLFxuICAgICAgICAgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgICAgbmdab25lLnVuc3RhYmxlKCk7XG4gICAgICAgICAgIG5nWm9uZS5zdGFibGUoKTtcbiAgICAgICAgICAgdGVzdGFiaWxpdHkud2hlblN0YWJsZShleGVjdXRlKTtcblxuICAgICAgICAgICBtaWNyb1Rhc2soKCkgPT4ge1xuICAgICAgICAgICAgIGV4cGVjdChleGVjdXRlKS50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBub3QgZmlyZSB3aGVuc3RhYmxlIGNhbGxiYWNrcyBzeW5jaHJvbm91c2x5IGlmIGV2ZW50IGlzIGFscmVhZHkgZmluaXNoZWQnLCAoKSA9PiB7XG4gICAgICAgIG5nWm9uZS51bnN0YWJsZSgpO1xuICAgICAgICBuZ1pvbmUuc3RhYmxlKCk7XG4gICAgICAgIHRlc3RhYmlsaXR5LndoZW5TdGFibGUoZXhlY3V0ZSk7XG5cbiAgICAgICAgZXhwZWN0KGV4ZWN1dGUpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBmaXJlIHdoZW5zdGFibGUgY2FsbGJhY2sgd2hlbiBldmVudCBmaW5pc2hlcycsXG4gICAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICBuZ1pvbmUudW5zdGFibGUoKTtcbiAgICAgICAgICAgdGVzdGFiaWxpdHkud2hlblN0YWJsZShleGVjdXRlKTtcblxuICAgICAgICAgICBtaWNyb1Rhc2soKCkgPT4ge1xuICAgICAgICAgICAgIGV4cGVjdChleGVjdXRlKS5ub3QudG9IYXZlQmVlbkNhbGxlZCgpO1xuICAgICAgICAgICAgIG5nWm9uZS5zdGFibGUoKTtcblxuICAgICAgICAgICAgIG1pY3JvVGFzaygoKSA9PiB7XG4gICAgICAgICAgICAgICBleHBlY3QoZXhlY3V0ZSkudG9IYXZlQmVlbkNhbGxlZCgpO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBub3QgZmlyZSB3aGVuc3RhYmxlIGNhbGxiYWNrcyBzeW5jaHJvbm91c2x5IHdoZW4gZXZlbnQgZmluaXNoZXMnLCAoKSA9PiB7XG4gICAgICAgIG5nWm9uZS51bnN0YWJsZSgpO1xuICAgICAgICB0ZXN0YWJpbGl0eS53aGVuU3RhYmxlKGV4ZWN1dGUpO1xuICAgICAgICBuZ1pvbmUuc3RhYmxlKCk7XG5cbiAgICAgICAgZXhwZWN0KGV4ZWN1dGUpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBub3QgZmlyZSB3aGVuc3RhYmxlIGNhbGxiYWNrIHdoZW4gZXZlbnQgZGlkIG5vdCBmaW5pc2gnLFxuICAgICAgICAgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgICAgbmdab25lLnVuc3RhYmxlKCk7XG4gICAgICAgICAgIHRlc3RhYmlsaXR5LmluY3JlYXNlUGVuZGluZ1JlcXVlc3RDb3VudCgpO1xuICAgICAgICAgICB0ZXN0YWJpbGl0eS53aGVuU3RhYmxlKGV4ZWN1dGUpO1xuXG4gICAgICAgICAgIG1pY3JvVGFzaygoKSA9PiB7XG4gICAgICAgICAgICAgZXhwZWN0KGV4ZWN1dGUpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgICAgICAgICAgdGVzdGFiaWxpdHkuZGVjcmVhc2VQZW5kaW5nUmVxdWVzdENvdW50KCk7XG5cbiAgICAgICAgICAgICBtaWNyb1Rhc2soKCkgPT4ge1xuICAgICAgICAgICAgICAgZXhwZWN0KGV4ZWN1dGUpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgICAgICAgICAgICBuZ1pvbmUuc3RhYmxlKCk7XG5cbiAgICAgICAgICAgICAgIG1pY3JvVGFzaygoKSA9PiB7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChleGVjdXRlKS50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBub3QgZmlyZSB3aGVuc3RhYmxlIGNhbGxiYWNrIHdoZW4gdGhlcmUgYXJlIHBlbmRpbmcgY291bnRzJyxcbiAgICAgICAgIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICAgIG5nWm9uZS51bnN0YWJsZSgpO1xuICAgICAgICAgICB0ZXN0YWJpbGl0eS5pbmNyZWFzZVBlbmRpbmdSZXF1ZXN0Q291bnQoKTtcbiAgICAgICAgICAgdGVzdGFiaWxpdHkuaW5jcmVhc2VQZW5kaW5nUmVxdWVzdENvdW50KCk7XG4gICAgICAgICAgIHRlc3RhYmlsaXR5LndoZW5TdGFibGUoZXhlY3V0ZSk7XG5cbiAgICAgICAgICAgbWljcm9UYXNrKCgpID0+IHtcbiAgICAgICAgICAgICBleHBlY3QoZXhlY3V0ZSkubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgICAgICAgICAgICBuZ1pvbmUuc3RhYmxlKCk7XG5cbiAgICAgICAgICAgICBtaWNyb1Rhc2soKCkgPT4ge1xuICAgICAgICAgICAgICAgZXhwZWN0KGV4ZWN1dGUpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgICAgICAgICAgICB0ZXN0YWJpbGl0eS5kZWNyZWFzZVBlbmRpbmdSZXF1ZXN0Q291bnQoKTtcblxuICAgICAgICAgICAgICAgbWljcm9UYXNrKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGV4ZWN1dGUpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgICAgICAgICAgICAgIHRlc3RhYmlsaXR5LmRlY3JlYXNlUGVuZGluZ1JlcXVlc3RDb3VudCgpO1xuXG4gICAgICAgICAgICAgICAgIG1pY3JvVGFzaygoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGV4ZWN1dGUpLnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIGZpcmUgd2hlbnN0YWJsZSBjYWxsYmFjayB3aXRoIGRpZFdvcmsgaWYgZXZlbnQgaXMgYWxyZWFkeSBmaW5pc2hlZCcsXG4gICAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICBuZ1pvbmUudW5zdGFibGUoKTtcbiAgICAgICAgICAgbmdab25lLnN0YWJsZSgpO1xuICAgICAgICAgICB0ZXN0YWJpbGl0eS53aGVuU3RhYmxlKGV4ZWN1dGUpO1xuXG4gICAgICAgICAgIG1pY3JvVGFzaygoKSA9PiB7XG4gICAgICAgICAgICAgZXhwZWN0KGV4ZWN1dGUpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKHRydWUpO1xuICAgICAgICAgICAgIHRlc3RhYmlsaXR5LndoZW5TdGFibGUoZXhlY3V0ZTIpO1xuXG4gICAgICAgICAgICAgbWljcm9UYXNrKCgpID0+IHtcbiAgICAgICAgICAgICAgIGV4cGVjdChleGVjdXRlMikudG9IYXZlQmVlbkNhbGxlZFdpdGgoZmFsc2UpO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBmaXJlIHdoZW5zdGFibGUgY2FsbGJhY2sgd2l0aCBkaWR3b3JrIHdoZW4gZXZlbnQgZmluaXNoZXMnLFxuICAgICAgICAgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgICAgbmdab25lLnVuc3RhYmxlKCk7XG4gICAgICAgICAgIHRlc3RhYmlsaXR5LndoZW5TdGFibGUoZXhlY3V0ZSk7XG5cbiAgICAgICAgICAgbWljcm9UYXNrKCgpID0+IHtcbiAgICAgICAgICAgICBuZ1pvbmUuc3RhYmxlKCk7XG5cbiAgICAgICAgICAgICBtaWNyb1Rhc2soKCkgPT4ge1xuICAgICAgICAgICAgICAgZXhwZWN0KGV4ZWN1dGUpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKHRydWUpO1xuICAgICAgICAgICAgICAgdGVzdGFiaWxpdHkud2hlblN0YWJsZShleGVjdXRlMik7XG5cbiAgICAgICAgICAgICAgIG1pY3JvVGFzaygoKSA9PiB7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChleGVjdXRlMikudG9IYXZlQmVlbkNhbGxlZFdpdGgoZmFsc2UpO1xuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG4gICAgfSk7XG4gIH0pO1xufVxuIl19
 main(); 
