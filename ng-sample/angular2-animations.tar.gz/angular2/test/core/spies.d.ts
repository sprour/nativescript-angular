import { SpyObject } from 'angular2/testing_internal';
export declare class SpyDependencyProvider extends SpyObject {
}
export declare class SpyChangeDetector extends SpyObject {
    constructor();
}
export declare class SpyChangeDispatcher extends SpyObject {
}
export declare class SpyIterableDifferFactory extends SpyObject {
}
export declare class SpyDirectiveResolver extends SpyObject {
    constructor();
}
export declare class SpyView extends SpyObject {
    constructor();
}
export declare class SpyProtoView extends SpyObject {
    constructor();
}
export declare class SpyHostViewFactory extends SpyObject {
    constructor();
}
export declare class SpyElementRef extends SpyObject {
    constructor();
}
export declare class SpyAppViewManager extends SpyObject {
    constructor();
}
export declare class SpyRenderer extends SpyObject {
    constructor();
}
export declare class SpyRootRenderer extends SpyObject {
    constructor();
}
export declare class SpyDomAdapter extends SpyObject {
    constructor();
}
