'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var core_1 = require('angular2/core');
function main() {
    testing_internal_1.describe('provider', function () {
        testing_internal_1.describe('type errors', function () {
            testing_internal_1.it('should throw when trying to create a class provider and not passing a class', function () {
                testing_internal_1.expect(function () { core_1.bind('foo').toClass(0); })
                    .toThrowError('Trying to create a class provider but "0" is not a class!');
            });
            testing_internal_1.it('should throw when trying to create a factory provider and not passing a function', function () {
                testing_internal_1.expect(function () { core_1.bind('foo').toFactory(0); })
                    .toThrowError('Trying to create a factory provider but "0" is not a function!');
            });
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmluZGluZ19zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb3JlL2RpL2JpbmRpbmdfc3BlYy50cyJdLCJuYW1lcyI6WyJtYWluIl0sIm1hcHBpbmdzIjoiQUFBQSxpQ0FVTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLHFCQUE0QixlQUFlLENBQUMsQ0FBQTtBQUU1QztJQUNFQSwyQkFBUUEsQ0FBQ0EsVUFBVUEsRUFBRUE7UUFFbkJBLDJCQUFRQSxDQUFDQSxhQUFhQSxFQUFFQTtZQUV0QkEscUJBQUVBLENBQUNBLDZFQUE2RUEsRUFBRUE7Z0JBQ2hGQSx5QkFBTUEsQ0FBQ0EsY0FBUUEsV0FBSUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7cUJBQ3pDQSxZQUFZQSxDQUFDQSwyREFBMkRBLENBQUNBLENBQUNBO1lBQ2pGQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0Esa0ZBQWtGQSxFQUFFQTtnQkFDckZBLHlCQUFNQSxDQUFDQSxjQUFRQSxXQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxTQUFTQSxDQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtxQkFDM0NBLFlBQVlBLENBQUNBLGdFQUFnRUEsQ0FBQ0EsQ0FBQ0E7WUFDdEZBLENBQUNBLENBQUNBLENBQUNBO1FBQ0xBLENBQUNBLENBQUNBLENBQUNBO0lBQ0xBLENBQUNBLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBaEJlLFlBQUksT0FnQm5CLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBc3luY1Rlc3RDb21wbGV0ZXIsXG4gIGJlZm9yZUVhY2gsXG4gIGRkZXNjcmliZSxcbiAgZGVzY3JpYmUsXG4gIGV4cGVjdCxcbiAgaWl0LFxuICBpbmplY3QsXG4gIGl0LFxuICB4aXQsXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5pbXBvcnQge2JpbmQsIHByb3ZpZGV9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpIHtcbiAgZGVzY3JpYmUoJ3Byb3ZpZGVyJywgKCkgPT4ge1xuXG4gICAgZGVzY3JpYmUoJ3R5cGUgZXJyb3JzJywgKCkgPT4ge1xuXG4gICAgICBpdCgnc2hvdWxkIHRocm93IHdoZW4gdHJ5aW5nIHRvIGNyZWF0ZSBhIGNsYXNzIHByb3ZpZGVyIGFuZCBub3QgcGFzc2luZyBhIGNsYXNzJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QoKCkgPT4geyBiaW5kKCdmb28nKS50b0NsYXNzKDxhbnk+MCk7IH0pXG4gICAgICAgICAgICAudG9UaHJvd0Vycm9yKCdUcnlpbmcgdG8gY3JlYXRlIGEgY2xhc3MgcHJvdmlkZXIgYnV0IFwiMFwiIGlzIG5vdCBhIGNsYXNzIScpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgdGhyb3cgd2hlbiB0cnlpbmcgdG8gY3JlYXRlIGEgZmFjdG9yeSBwcm92aWRlciBhbmQgbm90IHBhc3NpbmcgYSBmdW5jdGlvbicsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KCgpID0+IHsgYmluZCgnZm9vJykudG9GYWN0b3J5KDxhbnk+MCk7IH0pXG4gICAgICAgICAgICAudG9UaHJvd0Vycm9yKCdUcnlpbmcgdG8gY3JlYXRlIGEgZmFjdG9yeSBwcm92aWRlciBidXQgXCIwXCIgaXMgbm90IGEgZnVuY3Rpb24hJyk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfSk7XG59XG4iXX0=
 main(); 
