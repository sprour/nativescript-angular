'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var di_1 = require('angular2/src/core/di');
var lang_1 = require('angular2/src/facade/lang');
function main() {
    testing_internal_1.describe("forwardRef", function () {
        testing_internal_1.it('should wrap and unwrap the reference', function () {
            var ref = di_1.forwardRef(function () { return String; });
            testing_internal_1.expect(ref instanceof lang_1.Type).toBe(true);
            testing_internal_1.expect(di_1.resolveForwardRef(ref)).toBe(String);
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9yd2FyZF9yZWZfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29yZS9kaS9mb3J3YXJkX3JlZl9zcGVjLnRzIl0sIm5hbWVzIjpbIm1haW4iXSwibWFwcGluZ3MiOiJBQUFBLGlDQVVPLDJCQUEyQixDQUFDLENBQUE7QUFDbkMsbUJBQTRDLHNCQUFzQixDQUFDLENBQUE7QUFDbkUscUJBQW1CLDBCQUEwQixDQUFDLENBQUE7QUFFOUM7SUFDRUEsMkJBQVFBLENBQUNBLFlBQVlBLEVBQUVBO1FBQ3JCLHFCQUFFLENBQUMsc0NBQXNDLEVBQUU7WUFDekMsSUFBSSxHQUFHLEdBQUcsZUFBVSxDQUFDLGNBQU0sT0FBQSxNQUFNLEVBQU4sQ0FBTSxDQUFDLENBQUM7WUFDbkMseUJBQU0sQ0FBQyxHQUFHLFlBQVksV0FBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3ZDLHlCQUFNLENBQUMsc0JBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDOUMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBUmUsWUFBSSxPQVFuQixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXN5bmNUZXN0Q29tcGxldGVyLFxuICBiZWZvcmVFYWNoLFxuICBkZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICBleHBlY3QsXG4gIGlpdCxcbiAgaW5qZWN0LFxuICBpdCxcbiAgeGl0LFxufSBmcm9tICdhbmd1bGFyMi90ZXN0aW5nX2ludGVybmFsJztcbmltcG9ydCB7Zm9yd2FyZFJlZiwgcmVzb2x2ZUZvcndhcmRSZWZ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2RpJztcbmltcG9ydCB7VHlwZX0gZnJvbSAnYW5ndWxhcjIvc3JjL2ZhY2FkZS9sYW5nJztcblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGRlc2NyaWJlKFwiZm9yd2FyZFJlZlwiLCBmdW5jdGlvbigpIHtcbiAgICBpdCgnc2hvdWxkIHdyYXAgYW5kIHVud3JhcCB0aGUgcmVmZXJlbmNlJywgKCkgPT4ge1xuICAgICAgdmFyIHJlZiA9IGZvcndhcmRSZWYoKCkgPT4gU3RyaW5nKTtcbiAgICAgIGV4cGVjdChyZWYgaW5zdGFuY2VvZiBUeXBlKS50b0JlKHRydWUpO1xuICAgICAgZXhwZWN0KHJlc29sdmVGb3J3YXJkUmVmKHJlZikpLnRvQmUoU3RyaW5nKTtcbiAgICB9KTtcbiAgfSk7XG59XG4iXX0=
 main(); 
