'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var lang_1 = require('angular2/src/facade/lang');
var exceptions_1 = require('angular2/src/facade/exceptions');
var testing_internal_1 = require('angular2/testing_internal');
var spies_1 = require('../spies');
var core_1 = require('angular2/core');
var metadata_1 = require('angular2/src/core/di/metadata');
var provider_1 = require('angular2/src/core/di/provider');
var injector_1 = require('angular2/src/core/di/injector');
var CustomDependencyMetadata = (function (_super) {
    __extends(CustomDependencyMetadata, _super);
    function CustomDependencyMetadata() {
        _super.apply(this, arguments);
    }
    return CustomDependencyMetadata;
})(metadata_1.DependencyMetadata);
var Engine = (function () {
    function Engine() {
    }
    return Engine;
})();
var BrokenEngine = (function () {
    function BrokenEngine() {
        throw new exceptions_1.BaseException("Broken Engine");
    }
    return BrokenEngine;
})();
var DashboardSoftware = (function () {
    function DashboardSoftware() {
    }
    return DashboardSoftware;
})();
var Dashboard = (function () {
    function Dashboard(software) {
    }
    Dashboard = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [DashboardSoftware])
    ], Dashboard);
    return Dashboard;
})();
var TurboEngine = (function (_super) {
    __extends(TurboEngine, _super);
    function TurboEngine() {
        _super.apply(this, arguments);
    }
    return TurboEngine;
})(Engine);
var Car = (function () {
    function Car(engine) {
        this.engine = engine;
    }
    Car = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [Engine])
    ], Car);
    return Car;
})();
var CarWithOptionalEngine = (function () {
    function CarWithOptionalEngine(engine) {
        this.engine = engine;
    }
    CarWithOptionalEngine = __decorate([
        core_1.Injectable(),
        __param(0, core_1.Optional()), 
        __metadata('design:paramtypes', [Engine])
    ], CarWithOptionalEngine);
    return CarWithOptionalEngine;
})();
var CarWithDashboard = (function () {
    function CarWithDashboard(engine, dashboard) {
        this.engine = engine;
        this.dashboard = dashboard;
    }
    CarWithDashboard = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [Engine, Dashboard])
    ], CarWithDashboard);
    return CarWithDashboard;
})();
var SportsCar = (function (_super) {
    __extends(SportsCar, _super);
    function SportsCar(engine) {
        _super.call(this, engine);
    }
    SportsCar = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [Engine])
    ], SportsCar);
    return SportsCar;
})(Car);
var CarWithInject = (function () {
    function CarWithInject(engine) {
        this.engine = engine;
    }
    CarWithInject = __decorate([
        core_1.Injectable(),
        __param(0, core_1.Inject(TurboEngine)), 
        __metadata('design:paramtypes', [Engine])
    ], CarWithInject);
    return CarWithInject;
})();
var CyclicEngine = (function () {
    function CyclicEngine(car) {
    }
    CyclicEngine = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [Car])
    ], CyclicEngine);
    return CyclicEngine;
})();
var NoAnnotations = (function () {
    function NoAnnotations(secretDependency) {
    }
    return NoAnnotations;
})();
function factoryFn(a) { }
function main() {
    var dynamicProviders = [
        core_1.provide('provider0', { useValue: 1 }),
        core_1.provide('provider1', { useValue: 1 }),
        core_1.provide('provider2', { useValue: 1 }),
        core_1.provide('provider3', { useValue: 1 }),
        core_1.provide('provider4', { useValue: 1 }),
        core_1.provide('provider5', { useValue: 1 }),
        core_1.provide('provider6', { useValue: 1 }),
        core_1.provide('provider7', { useValue: 1 }),
        core_1.provide('provider8', { useValue: 1 }),
        core_1.provide('provider9', { useValue: 1 }),
        core_1.provide('provider10', { useValue: 1 })
    ];
    [{ strategy: 'inline', providers: [], strategyClass: injector_1.InjectorInlineStrategy },
        {
            strategy: 'dynamic',
            providers: dynamicProviders,
            strategyClass: injector_1.InjectorDynamicStrategy
        }].forEach(function (context) {
        function createInjector(providers, parent, isHost) {
            if (parent === void 0) { parent = null; }
            if (isHost === void 0) { isHost = false; }
            return new core_1.Injector(injector_1.ProtoInjector.fromResolvedProviders(core_1.Injector.resolve(providers.concat(context['providers']))), parent, isHost);
        }
        testing_internal_1.describe("injector " + context['strategy'], function () {
            testing_internal_1.it("should use the right strategy", function () {
                var injector = createInjector([]);
                testing_internal_1.expect(injector.internalStrategy).toBeAnInstanceOf(context['strategyClass']);
            });
            testing_internal_1.it('should instantiate a class without dependencies', function () {
                var injector = createInjector([Engine]);
                var engine = injector.get(Engine);
                testing_internal_1.expect(engine).toBeAnInstanceOf(Engine);
            });
            testing_internal_1.it('should resolve dependencies based on type information', function () {
                var injector = createInjector([Engine, Car]);
                var car = injector.get(Car);
                testing_internal_1.expect(car).toBeAnInstanceOf(Car);
                testing_internal_1.expect(car.engine).toBeAnInstanceOf(Engine);
            });
            testing_internal_1.it('should resolve dependencies based on @Inject annotation', function () {
                var injector = createInjector([TurboEngine, Engine, CarWithInject]);
                var car = injector.get(CarWithInject);
                testing_internal_1.expect(car).toBeAnInstanceOf(CarWithInject);
                testing_internal_1.expect(car.engine).toBeAnInstanceOf(TurboEngine);
            });
            testing_internal_1.it('should throw when no type and not @Inject (class case)', function () {
                testing_internal_1.expect(function () { return createInjector([NoAnnotations]); })
                    .toThrowError("Cannot resolve all parameters for 'NoAnnotations'(?). " +
                    'Make sure that all the parameters are decorated with Inject or have valid type annotations ' +
                    "and that 'NoAnnotations' is decorated with Injectable.");
            });
            testing_internal_1.it('should throw when no type and not @Inject (factory case)', function () {
                testing_internal_1.expect(function () { return createInjector([core_1.provide("someToken", { useFactory: factoryFn })]); })
                    .toThrowError("Cannot resolve all parameters for 'factoryFn'(?). " +
                    'Make sure that all the parameters are decorated with Inject or have valid type annotations ' +
                    "and that 'factoryFn' is decorated with Injectable.");
            });
            testing_internal_1.it('should cache instances', function () {
                var injector = createInjector([Engine]);
                var e1 = injector.get(Engine);
                var e2 = injector.get(Engine);
                testing_internal_1.expect(e1).toBe(e2);
            });
            testing_internal_1.it('should provide to a value', function () {
                var injector = createInjector([core_1.provide(Engine, { useValue: "fake engine" })]);
                var engine = injector.get(Engine);
                testing_internal_1.expect(engine).toEqual("fake engine");
            });
            testing_internal_1.it('should provide to a factory', function () {
                function sportsCarFactory(e) { return new SportsCar(e); }
                var injector = createInjector([Engine, core_1.provide(Car, { useFactory: sportsCarFactory, deps: [Engine] })]);
                var car = injector.get(Car);
                testing_internal_1.expect(car).toBeAnInstanceOf(SportsCar);
                testing_internal_1.expect(car.engine).toBeAnInstanceOf(Engine);
            });
            testing_internal_1.it('should throw when using a factory with more than 20 dependencies', function () {
                function factoryWithTooManyArgs() { return new Car(null); }
                var injector = createInjector([
                    Engine,
                    core_1.provide(Car, {
                        useFactory: factoryWithTooManyArgs,
                        deps: [
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine,
                            Engine
                        ]
                    })
                ]);
                try {
                    injector.get(Car);
                    throw "Must throw";
                }
                catch (e) {
                    testing_internal_1.expect(e.message)
                        .toContain("Cannot instantiate 'Car' because it has more than 20 dependencies");
                }
            });
            testing_internal_1.it('should supporting provider to null', function () {
                var injector = createInjector([core_1.provide(Engine, { useValue: null })]);
                var engine = injector.get(Engine);
                testing_internal_1.expect(engine).toBeNull();
            });
            testing_internal_1.it('should provide to an alias', function () {
                var injector = createInjector([
                    Engine,
                    core_1.provide(SportsCar, { useClass: SportsCar }),
                    core_1.provide(Car, { useExisting: SportsCar })
                ]);
                var car = injector.get(Car);
                var sportsCar = injector.get(SportsCar);
                testing_internal_1.expect(car).toBeAnInstanceOf(SportsCar);
                testing_internal_1.expect(car).toBe(sportsCar);
            });
            testing_internal_1.it('should support multiProviders', function () {
                var injector = createInjector([
                    Engine,
                    new core_1.Provider(Car, { useClass: SportsCar, multi: true }),
                    new core_1.Provider(Car, { useClass: CarWithOptionalEngine, multi: true })
                ]);
                var cars = injector.get(Car);
                testing_internal_1.expect(cars.length).toEqual(2);
                testing_internal_1.expect(cars[0]).toBeAnInstanceOf(SportsCar);
                testing_internal_1.expect(cars[1]).toBeAnInstanceOf(CarWithOptionalEngine);
            });
            testing_internal_1.it('should support multiProviders that are created using useExisting', function () {
                var injector = createInjector([Engine, SportsCar, new core_1.Provider(Car, { useExisting: SportsCar, multi: true })]);
                var cars = injector.get(Car);
                testing_internal_1.expect(cars.length).toEqual(1);
                testing_internal_1.expect(cars[0]).toBe(injector.get(SportsCar));
            });
            testing_internal_1.it('should throw when the aliased provider does not exist', function () {
                var injector = createInjector([core_1.provide('car', { useExisting: SportsCar })]);
                var e = "No provider for " + lang_1.stringify(SportsCar) + "! (car -> " + lang_1.stringify(SportsCar) + ")";
                testing_internal_1.expect(function () { return injector.get('car'); }).toThrowError(e);
            });
            testing_internal_1.it('should handle forwardRef in useExisting', function () {
                var injector = createInjector([
                    core_1.provide('originalEngine', { useClass: core_1.forwardRef(function () { return Engine; }) }),
                    core_1.provide('aliasedEngine', { useExisting: core_1.forwardRef(function () { return 'originalEngine'; }) })
                ]);
                testing_internal_1.expect(injector.get('aliasedEngine')).toBeAnInstanceOf(Engine);
            });
            testing_internal_1.it('should support overriding factory dependencies', function () {
                var injector = createInjector([Engine, core_1.provide(Car, { useFactory: function (e) { return new SportsCar(e); }, deps: [Engine] })]);
                var car = injector.get(Car);
                testing_internal_1.expect(car).toBeAnInstanceOf(SportsCar);
                testing_internal_1.expect(car.engine).toBeAnInstanceOf(Engine);
            });
            testing_internal_1.it('should support optional dependencies', function () {
                var injector = createInjector([CarWithOptionalEngine]);
                var car = injector.get(CarWithOptionalEngine);
                testing_internal_1.expect(car.engine).toEqual(null);
            });
            testing_internal_1.it("should flatten passed-in providers", function () {
                var injector = createInjector([[[Engine, Car]]]);
                var car = injector.get(Car);
                testing_internal_1.expect(car).toBeAnInstanceOf(Car);
            });
            testing_internal_1.it("should use the last provider when there are multiple providers for same token", function () {
                var injector = createInjector([core_1.provide(Engine, { useClass: Engine }), core_1.provide(Engine, { useClass: TurboEngine })]);
                testing_internal_1.expect(injector.get(Engine)).toBeAnInstanceOf(TurboEngine);
            });
            testing_internal_1.it('should use non-type tokens', function () {
                var injector = createInjector([core_1.provide('token', { useValue: 'value' })]);
                testing_internal_1.expect(injector.get('token')).toEqual('value');
            });
            testing_internal_1.it('should throw when given invalid providers', function () {
                testing_internal_1.expect(function () { return createInjector(["blah"]); })
                    .toThrowError('Invalid provider - only instances of Provider and Type are allowed, got: blah');
            });
            testing_internal_1.it('should provide itself', function () {
                var parent = createInjector([]);
                var child = parent.resolveAndCreateChild([]);
                testing_internal_1.expect(child.get(core_1.Injector)).toBe(child);
            });
            testing_internal_1.it('should throw when no provider defined', function () {
                var injector = createInjector([]);
                testing_internal_1.expect(function () { return injector.get('NonExisting'); }).toThrowError('No provider for NonExisting!');
            });
            testing_internal_1.it('should show the full path when no provider', function () {
                var injector = createInjector([CarWithDashboard, Engine, Dashboard]);
                testing_internal_1.expect(function () { return injector.get(CarWithDashboard); })
                    .toThrowError("No provider for DashboardSoftware! (" + lang_1.stringify(CarWithDashboard) + " -> " + lang_1.stringify(Dashboard) + " -> DashboardSoftware)");
            });
            testing_internal_1.it('should throw when trying to instantiate a cyclic dependency', function () {
                var injector = createInjector([Car, core_1.provide(Engine, { useClass: CyclicEngine })]);
                testing_internal_1.expect(function () { return injector.get(Car); })
                    .toThrowError("Cannot instantiate cyclic dependency! (" + lang_1.stringify(Car) + " -> " + lang_1.stringify(Engine) + " -> " + lang_1.stringify(Car) + ")");
            });
            testing_internal_1.it('should show the full path when error happens in a constructor', function () {
                var providers = core_1.Injector.resolve([Car, core_1.provide(Engine, { useClass: BrokenEngine })]);
                var proto = new injector_1.ProtoInjector([
                    new injector_1.ProviderWithVisibility(providers[0], injector_1.Visibility.Public),
                    new injector_1.ProviderWithVisibility(providers[1], injector_1.Visibility.Public)
                ]);
                var injector = new core_1.Injector(proto);
                try {
                    injector.get(Car);
                    throw "Must throw";
                }
                catch (e) {
                    testing_internal_1.expect(e.message)
                        .toContain("Error during instantiation of Engine! (" + lang_1.stringify(Car) + " -> Engine)");
                    testing_internal_1.expect(e.originalException instanceof exceptions_1.BaseException).toBeTruthy();
                    testing_internal_1.expect(e.causeKey.token).toEqual(Engine);
                }
            });
            testing_internal_1.it('should provide context when throwing an exception ', function () {
                var engineProvider = core_1.Injector.resolve([core_1.provide(Engine, { useClass: BrokenEngine })])[0];
                var protoParent = new injector_1.ProtoInjector([new injector_1.ProviderWithVisibility(engineProvider, injector_1.Visibility.Public)]);
                var carProvider = core_1.Injector.resolve([Car])[0];
                var protoChild = new injector_1.ProtoInjector([new injector_1.ProviderWithVisibility(carProvider, injector_1.Visibility.Public)]);
                var parent = new core_1.Injector(protoParent, null, false, null, function () { return "parentContext"; });
                var child = new core_1.Injector(protoChild, parent, false, null, function () { return "childContext"; });
                try {
                    child.get(Car);
                    throw "Must throw";
                }
                catch (e) {
                    testing_internal_1.expect(e.context).toEqual("childContext");
                }
            });
            testing_internal_1.it('should instantiate an object after a failed attempt', function () {
                var isBroken = true;
                var injector = createInjector([
                    Car,
                    core_1.provide(Engine, { useFactory: (function () { return isBroken ? new BrokenEngine() : new Engine(); }) })
                ]);
                testing_internal_1.expect(function () { return injector.get(Car); }).toThrowError(new RegExp("Error"));
                isBroken = false;
                testing_internal_1.expect(injector.get(Car)).toBeAnInstanceOf(Car);
            });
            testing_internal_1.it('should support null values', function () {
                var injector = createInjector([core_1.provide('null', { useValue: null })]);
                testing_internal_1.expect(injector.get('null')).toBe(null);
            });
            testing_internal_1.it('should use custom dependency provider', function () {
                var e = new Engine();
                var depProvider = new spies_1.SpyDependencyProvider();
                depProvider.spy("getDependency").andReturn(e);
                var providers = core_1.Injector.resolve([Car]);
                var proto = new injector_1.ProtoInjector([new injector_1.ProviderWithVisibility(providers[0], injector_1.Visibility.Public)]);
                var injector = new core_1.Injector(proto, null, false, depProvider);
                testing_internal_1.expect(injector.get(Car).engine).toEqual(e);
                testing_internal_1.expect(depProvider.spy("getDependency"))
                    .toHaveBeenCalledWith(injector, providers[0], providers[0].resolvedFactories[0].dependencies[0]);
            });
        });
        testing_internal_1.describe("child", function () {
            testing_internal_1.it('should load instances from parent injector', function () {
                var parent = core_1.Injector.resolveAndCreate([Engine]);
                var child = parent.resolveAndCreateChild([]);
                var engineFromParent = parent.get(Engine);
                var engineFromChild = child.get(Engine);
                testing_internal_1.expect(engineFromChild).toBe(engineFromParent);
            });
            testing_internal_1.it("should not use the child providers when resolving the dependencies of a parent provider", function () {
                var parent = core_1.Injector.resolveAndCreate([Car, Engine]);
                var child = parent.resolveAndCreateChild([core_1.provide(Engine, { useClass: TurboEngine })]);
                var carFromChild = child.get(Car);
                testing_internal_1.expect(carFromChild.engine).toBeAnInstanceOf(Engine);
            });
            testing_internal_1.it('should create new instance in a child injector', function () {
                var parent = core_1.Injector.resolveAndCreate([Engine]);
                var child = parent.resolveAndCreateChild([core_1.provide(Engine, { useClass: TurboEngine })]);
                var engineFromParent = parent.get(Engine);
                var engineFromChild = child.get(Engine);
                testing_internal_1.expect(engineFromParent).not.toBe(engineFromChild);
                testing_internal_1.expect(engineFromChild).toBeAnInstanceOf(TurboEngine);
            });
            testing_internal_1.it("should give access to parent", function () {
                var parent = core_1.Injector.resolveAndCreate([]);
                var child = parent.resolveAndCreateChild([]);
                testing_internal_1.expect(child.parent).toBe(parent);
            });
        });
        testing_internal_1.describe('resolveAndInstantiate', function () {
            testing_internal_1.it('should instantiate an object in the context of the injector', function () {
                var inj = core_1.Injector.resolveAndCreate([Engine]);
                var car = inj.resolveAndInstantiate(Car);
                testing_internal_1.expect(car).toBeAnInstanceOf(Car);
                testing_internal_1.expect(car.engine).toBe(inj.get(Engine));
            });
            testing_internal_1.it('should not store the instantiated object in the injector', function () {
                var inj = core_1.Injector.resolveAndCreate([Engine]);
                inj.resolveAndInstantiate(Car);
                testing_internal_1.expect(function () { return inj.get(Car); }).toThrowError();
            });
        });
        testing_internal_1.describe('instantiate', function () {
            testing_internal_1.it('should instantiate an object in the context of the injector', function () {
                var inj = core_1.Injector.resolveAndCreate([Engine]);
                var car = inj.instantiateResolved(core_1.Injector.resolve([Car])[0]);
                testing_internal_1.expect(car).toBeAnInstanceOf(Car);
                testing_internal_1.expect(car.engine).toBe(inj.get(Engine));
            });
        });
        testing_internal_1.describe("depedency resolution", function () {
            testing_internal_1.describe("@Self()", function () {
                testing_internal_1.it("should return a dependency from self", function () {
                    var inj = core_1.Injector.resolveAndCreate([
                        Engine,
                        core_1.provide(Car, { useFactory: function (e) { return new Car(e); }, deps: [[Engine, new core_1.SelfMetadata()]] })
                    ]);
                    testing_internal_1.expect(inj.get(Car)).toBeAnInstanceOf(Car);
                });
                testing_internal_1.it("should throw when not requested provider on self", function () {
                    var parent = core_1.Injector.resolveAndCreate([Engine]);
                    var child = parent.resolveAndCreateChild([
                        core_1.provide(Car, { useFactory: function (e) { return new Car(e); }, deps: [[Engine, new core_1.SelfMetadata()]] })
                    ]);
                    testing_internal_1.expect(function () { return child.get(Car); })
                        .toThrowError("No provider for Engine! (" + lang_1.stringify(Car) + " -> " + lang_1.stringify(Engine) + ")");
                });
            });
            testing_internal_1.describe("@Host()", function () {
                testing_internal_1.it("should return a dependency from same host", function () {
                    var parent = core_1.Injector.resolveAndCreate([Engine]);
                    var child = parent.resolveAndCreateChild([
                        core_1.provide(Car, { useFactory: function (e) { return new Car(e); }, deps: [[Engine, new core_1.HostMetadata()]] })
                    ]);
                    testing_internal_1.expect(child.get(Car)).toBeAnInstanceOf(Car);
                });
                testing_internal_1.it("should return a private dependency declared at the host", function () {
                    var engine = core_1.Injector.resolve([Engine])[0];
                    var protoParent = new injector_1.ProtoInjector([new injector_1.ProviderWithVisibility(engine, injector_1.Visibility.Private)]);
                    var parent = new core_1.Injector(protoParent);
                    var child = createInjector([core_1.provide(Car, { useFactory: function (e) { return new Car(e); }, deps: [[Engine, new core_1.HostMetadata()]] })], parent, true); // host
                    testing_internal_1.expect(child.get(Car)).toBeAnInstanceOf(Car);
                });
                testing_internal_1.it("should not return a public dependency declared at the host", function () {
                    var engine = core_1.Injector.resolve([Engine])[0];
                    var protoParent = new injector_1.ProtoInjector([new injector_1.ProviderWithVisibility(engine, injector_1.Visibility.Public)]);
                    var parent = new core_1.Injector(protoParent);
                    var child = createInjector([core_1.provide(Car, { useFactory: function (e) { return new Car(e); }, deps: [[Engine, new core_1.HostMetadata()]] })], parent, true); // host
                    testing_internal_1.expect(function () { return child.get(Car); })
                        .toThrowError("No provider for Engine! (" + lang_1.stringify(Car) + " -> " + lang_1.stringify(Engine) + ")");
                });
                testing_internal_1.it("should not skip self", function () {
                    var parent = core_1.Injector.resolveAndCreate([Engine]);
                    var child = parent.resolveAndCreateChild([
                        core_1.provide(Engine, { useClass: TurboEngine }),
                        core_1.provide(Car, { useFactory: function (e) { return new Car(e); }, deps: [[Engine, new core_1.HostMetadata()]] })
                    ]);
                    testing_internal_1.expect(child.get(Car).engine).toBeAnInstanceOf(TurboEngine);
                });
            });
            testing_internal_1.describe("default", function () {
                testing_internal_1.it("should return a private dependency declared at the host", function () {
                    var engine = core_1.Injector.resolve([Engine])[0];
                    var protoParent = new injector_1.ProtoInjector([new injector_1.ProviderWithVisibility(engine, injector_1.Visibility.Private)]);
                    var parent = new core_1.Injector(protoParent);
                    var child = createInjector([
                        core_1.provide(Engine, { useClass: BrokenEngine }),
                        core_1.provide(Car, { useFactory: function (e) { return new Car(e); }, deps: [[Engine, new core_1.SkipSelfMetadata()]] })
                    ], parent, true); // boundary
                    testing_internal_1.expect(child.get(Car)).toBeAnInstanceOf(Car);
                });
                testing_internal_1.it("should return a public dependency declared at the host", function () {
                    var engine = core_1.Injector.resolve([Engine])[0];
                    var protoParent = new injector_1.ProtoInjector([new injector_1.ProviderWithVisibility(engine, injector_1.Visibility.Public)]);
                    var parent = new core_1.Injector(protoParent);
                    var child = createInjector([
                        core_1.provide(Engine, { useClass: BrokenEngine }),
                        core_1.provide(Car, { useFactory: function (e) { return new Car(e); }, deps: [[Engine, new core_1.SkipSelfMetadata()]] })
                    ], parent, true); // boundary
                    testing_internal_1.expect(child.get(Car)).toBeAnInstanceOf(Car);
                });
                testing_internal_1.it("should not return a private dependency declared NOT at the host", function () {
                    var engine = core_1.Injector.resolve([Engine])[0];
                    var protoParent = new injector_1.ProtoInjector([new injector_1.ProviderWithVisibility(engine, injector_1.Visibility.Private)]);
                    var parent = new core_1.Injector(protoParent);
                    var child = createInjector([
                        core_1.provide(Engine, { useClass: BrokenEngine }),
                        core_1.provide(Car, { useFactory: function (e) { return new Car(e); }, deps: [[Engine, new core_1.SkipSelfMetadata()]] })
                    ], parent, false);
                    testing_internal_1.expect(function () { return child.get(Car); })
                        .toThrowError("No provider for Engine! (" + lang_1.stringify(Car) + " -> " + lang_1.stringify(Engine) + ")");
                });
                testing_internal_1.it("should not skip self", function () {
                    var parent = core_1.Injector.resolveAndCreate([Engine]);
                    var child = parent.resolveAndCreateChild([
                        core_1.provide(Engine, { useClass: TurboEngine }),
                        core_1.provide(Car, { useFactory: function (e) { return new Car(e); }, deps: [Engine] })
                    ]);
                    testing_internal_1.expect(child.get(Car).engine).toBeAnInstanceOf(TurboEngine);
                });
            });
        });
        testing_internal_1.describe('resolve', function () {
            testing_internal_1.it('should resolve and flatten', function () {
                var providers = core_1.Injector.resolve([Engine, [BrokenEngine]]);
                providers.forEach(function (b) {
                    if (lang_1.isBlank(b))
                        return; // the result is a sparse array
                    testing_internal_1.expect(b instanceof provider_1.ResolvedProvider_).toBe(true);
                });
            });
            testing_internal_1.it("should support multi providers", function () {
                var provider = core_1.Injector.resolve([
                    new core_1.Provider(Engine, { useClass: BrokenEngine, multi: true }),
                    new core_1.Provider(Engine, { useClass: TurboEngine, multi: true })
                ])[0];
                testing_internal_1.expect(provider.key.token).toBe(Engine);
                testing_internal_1.expect(provider.multiProvider).toEqual(true);
                testing_internal_1.expect(provider.resolvedFactories.length).toEqual(2);
            });
            testing_internal_1.it("should support multi providers with only one provider", function () {
                var provider = core_1.Injector.resolve([new core_1.Provider(Engine, { useClass: BrokenEngine, multi: true })])[0];
                testing_internal_1.expect(provider.key.token).toBe(Engine);
                testing_internal_1.expect(provider.multiProvider).toEqual(true);
                testing_internal_1.expect(provider.resolvedFactories.length).toEqual(1);
            });
            testing_internal_1.it("should throw when mixing multi providers with regular providers", function () {
                testing_internal_1.expect(function () {
                    core_1.Injector.resolve([new core_1.Provider(Engine, { useClass: BrokenEngine, multi: true }), Engine]);
                }).toThrowErrorWith("Cannot mix multi providers and regular providers");
                testing_internal_1.expect(function () {
                    core_1.Injector.resolve([Engine, new core_1.Provider(Engine, { useClass: BrokenEngine, multi: true })]);
                }).toThrowErrorWith("Cannot mix multi providers and regular providers");
            });
            testing_internal_1.it('should resolve forward references', function () {
                var providers = core_1.Injector.resolve([
                    core_1.forwardRef(function () { return Engine; }),
                    [core_1.provide(core_1.forwardRef(function () { return BrokenEngine; }), { useClass: core_1.forwardRef(function () { return Engine; }) })],
                    core_1.provide(core_1.forwardRef(function () { return String; }), { useFactory: function () { return 'OK'; }, deps: [core_1.forwardRef(function () { return Engine; })] })
                ]);
                var engineProvider = providers[0];
                var brokenEngineProvider = providers[1];
                var stringProvider = providers[2];
                testing_internal_1.expect(engineProvider.resolvedFactories[0].factory() instanceof Engine).toBe(true);
                testing_internal_1.expect(brokenEngineProvider.resolvedFactories[0].factory() instanceof Engine).toBe(true);
                testing_internal_1.expect(stringProvider.resolvedFactories[0].dependencies[0].key).toEqual(core_1.Key.get(Engine));
            });
            testing_internal_1.it('should support overriding factory dependencies with dependency annotations', function () {
                var providers = core_1.Injector.resolve([
                    core_1.provide("token", {
                        useFactory: function (e) { return "result"; },
                        deps: [[new core_1.InjectMetadata("dep"), new CustomDependencyMetadata()]]
                    })
                ]);
                var provider = providers[0];
                testing_internal_1.expect(provider.resolvedFactories[0].dependencies[0].key.token).toEqual("dep");
                testing_internal_1.expect(provider.resolvedFactories[0].dependencies[0].properties)
                    .toEqual([new CustomDependencyMetadata()]);
            });
            testing_internal_1.it('should allow declaring dependencies with flat arrays', function () {
                var resolved = core_1.Injector.resolve([core_1.provide('token', { useFactory: function (e) { return e; }, deps: [new core_1.InjectMetadata("dep")] })]);
                var nestedResolved = core_1.Injector.resolve([core_1.provide('token', { useFactory: function (e) { return e; }, deps: [[new core_1.InjectMetadata("dep")]] })]);
                testing_internal_1.expect(resolved[0].resolvedFactories[0].dependencies[0].key.token)
                    .toEqual(nestedResolved[0].resolvedFactories[0].dependencies[0].key.token);
            });
        });
        testing_internal_1.describe("displayName", function () {
            testing_internal_1.it("should work", function () {
                testing_internal_1.expect(core_1.Injector.resolveAndCreate([Engine, BrokenEngine]).displayName)
                    .toEqual('Injector(providers: [ "Engine" ,  "BrokenEngine" ])');
            });
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5qZWN0b3Jfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29yZS9kaS9pbmplY3Rvcl9zcGVjLnRzIl0sIm5hbWVzIjpbIkN1c3RvbURlcGVuZGVuY3lNZXRhZGF0YSIsIkN1c3RvbURlcGVuZGVuY3lNZXRhZGF0YS5jb25zdHJ1Y3RvciIsIkVuZ2luZSIsIkVuZ2luZS5jb25zdHJ1Y3RvciIsIkJyb2tlbkVuZ2luZSIsIkJyb2tlbkVuZ2luZS5jb25zdHJ1Y3RvciIsIkRhc2hib2FyZFNvZnR3YXJlIiwiRGFzaGJvYXJkU29mdHdhcmUuY29uc3RydWN0b3IiLCJEYXNoYm9hcmQiLCJEYXNoYm9hcmQuY29uc3RydWN0b3IiLCJUdXJib0VuZ2luZSIsIlR1cmJvRW5naW5lLmNvbnN0cnVjdG9yIiwiQ2FyIiwiQ2FyLmNvbnN0cnVjdG9yIiwiQ2FyV2l0aE9wdGlvbmFsRW5naW5lIiwiQ2FyV2l0aE9wdGlvbmFsRW5naW5lLmNvbnN0cnVjdG9yIiwiQ2FyV2l0aERhc2hib2FyZCIsIkNhcldpdGhEYXNoYm9hcmQuY29uc3RydWN0b3IiLCJTcG9ydHNDYXIiLCJTcG9ydHNDYXIuY29uc3RydWN0b3IiLCJDYXJXaXRoSW5qZWN0IiwiQ2FyV2l0aEluamVjdC5jb25zdHJ1Y3RvciIsIkN5Y2xpY0VuZ2luZSIsIkN5Y2xpY0VuZ2luZS5jb25zdHJ1Y3RvciIsIk5vQW5ub3RhdGlvbnMiLCJOb0Fubm90YXRpb25zLmNvbnN0cnVjdG9yIiwiZmFjdG9yeUZuIiwibWFpbiIsIm1haW4uY3JlYXRlSW5qZWN0b3IiLCJtYWluLnNwb3J0c0NhckZhY3RvcnkiLCJtYWluLmZhY3RvcnlXaXRoVG9vTWFueUFyZ3MiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEscUJBQWlDLDBCQUEwQixDQUFDLENBQUE7QUFDNUQsMkJBQThDLGdDQUFnQyxDQUFDLENBQUE7QUFDL0UsaUNBQStELDJCQUEyQixDQUFDLENBQUE7QUFDM0Ysc0JBQW9DLFVBQVUsQ0FBQyxDQUFBO0FBQy9DLHFCQWNPLGVBQWUsQ0FBQyxDQUFBO0FBQ3ZCLHlCQUFpQywrQkFBK0IsQ0FBQyxDQUFBO0FBQ2pFLHlCQUFnQywrQkFBK0IsQ0FBQyxDQUFBO0FBRWhFLHlCQU1PLCtCQUErQixDQUFDLENBQUE7QUFFdkM7SUFBdUNBLDRDQUFrQkE7SUFBekRBO1FBQXVDQyw4QkFBa0JBO0lBQUVBLENBQUNBO0lBQURELCtCQUFDQTtBQUFEQSxDQUFDQSxBQUE1RCxFQUF1Qyw2QkFBa0IsRUFBRztBQUU1RDtJQUFBRTtJQUFjQyxDQUFDQTtJQUFERCxhQUFDQTtBQUFEQSxDQUFDQSxBQUFmLElBQWU7QUFFZjtJQUNFRTtRQUFnQkMsTUFBTUEsSUFBSUEsMEJBQWFBLENBQUNBLGVBQWVBLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBQzdERCxtQkFBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDO0FBRUQ7SUFBQUU7SUFBeUJDLENBQUNBO0lBQURELHdCQUFDQTtBQUFEQSxDQUFDQSxBQUExQixJQUEwQjtBQUUxQjtJQUVFRSxtQkFBWUEsUUFBMkJBO0lBQUdDLENBQUNBO0lBRjdDRDtRQUFDQSxpQkFBVUEsRUFBRUE7O2tCQUdaQTtJQUFEQSxnQkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFBMEJFLCtCQUFNQTtJQUFoQ0E7UUFBMEJDLDhCQUFNQTtJQUFFQSxDQUFDQTtJQUFERCxrQkFBQ0E7QUFBREEsQ0FBQ0EsQUFBbkMsRUFBMEIsTUFBTSxFQUFHO0FBRW5DO0lBR0VFLGFBQVlBLE1BQWNBO1FBQUlDLElBQUlBLENBQUNBLE1BQU1BLEdBQUdBLE1BQU1BLENBQUNBO0lBQUNBLENBQUNBO0lBSHZERDtRQUFDQSxpQkFBVUEsRUFBRUE7O1lBSVpBO0lBQURBLFVBQUNBO0FBQURBLENBQUNBLEFBSkQsSUFJQztBQUVEO0lBR0VFLCtCQUF3QkEsTUFBY0E7UUFBSUMsSUFBSUEsQ0FBQ0EsTUFBTUEsR0FBR0EsTUFBTUEsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFIbkVEO1FBQUNBLGlCQUFVQSxFQUFFQTtRQUdDQSxXQUFDQSxlQUFRQSxFQUFFQSxDQUFBQTs7OEJBQ3hCQTtJQUFEQSw0QkFBQ0E7QUFBREEsQ0FBQ0EsQUFKRCxJQUlDO0FBRUQ7SUFJRUUsMEJBQVlBLE1BQWNBLEVBQUVBLFNBQW9CQTtRQUM5Q0MsSUFBSUEsQ0FBQ0EsTUFBTUEsR0FBR0EsTUFBTUEsQ0FBQ0E7UUFDckJBLElBQUlBLENBQUNBLFNBQVNBLEdBQUdBLFNBQVNBLENBQUNBO0lBQzdCQSxDQUFDQTtJQVBIRDtRQUFDQSxpQkFBVUEsRUFBRUE7O3lCQVFaQTtJQUFEQSx1QkFBQ0E7QUFBREEsQ0FBQ0EsQUFSRCxJQVFDO0FBRUQ7SUFDd0JFLDZCQUFHQTtJQUV6QkEsbUJBQVlBLE1BQWNBO1FBQUlDLGtCQUFNQSxNQUFNQSxDQUFDQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUhoREQ7UUFBQ0EsaUJBQVVBLEVBQUVBOztrQkFJWkE7SUFBREEsZ0JBQUNBO0FBQURBLENBQUNBLEFBSkQsRUFDd0IsR0FBRyxFQUcxQjtBQUVEO0lBR0VFLHVCQUFpQ0EsTUFBY0E7UUFBSUMsSUFBSUEsQ0FBQ0EsTUFBTUEsR0FBR0EsTUFBTUEsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFINUVEO1FBQUNBLGlCQUFVQSxFQUFFQTtRQUdDQSxXQUFDQSxhQUFNQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFBQTs7c0JBQ2pDQTtJQUFEQSxvQkFBQ0E7QUFBREEsQ0FBQ0EsQUFKRCxJQUlDO0FBRUQ7SUFFRUUsc0JBQVlBLEdBQVFBO0lBQUdDLENBQUNBO0lBRjFCRDtRQUFDQSxpQkFBVUEsRUFBRUE7O3FCQUdaQTtJQUFEQSxtQkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFDRUUsdUJBQVlBLGdCQUFnQkE7SUFBR0MsQ0FBQ0E7SUFDbENELG9CQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUM7QUFFRCxtQkFBbUIsQ0FBQyxJQUFHRSxDQUFDQTtBQUV4QjtJQUNFQyxJQUFJQSxnQkFBZ0JBLEdBQUdBO1FBQ3JCQSxjQUFPQSxDQUFDQSxXQUFXQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxDQUFDQSxFQUFDQSxDQUFDQTtRQUNuQ0EsY0FBT0EsQ0FBQ0EsV0FBV0EsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7UUFDbkNBLGNBQU9BLENBQUNBLFdBQVdBLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLENBQUNBLEVBQUNBLENBQUNBO1FBQ25DQSxjQUFPQSxDQUFDQSxXQUFXQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxDQUFDQSxFQUFDQSxDQUFDQTtRQUNuQ0EsY0FBT0EsQ0FBQ0EsV0FBV0EsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7UUFDbkNBLGNBQU9BLENBQUNBLFdBQVdBLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLENBQUNBLEVBQUNBLENBQUNBO1FBQ25DQSxjQUFPQSxDQUFDQSxXQUFXQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxDQUFDQSxFQUFDQSxDQUFDQTtRQUNuQ0EsY0FBT0EsQ0FBQ0EsV0FBV0EsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7UUFDbkNBLGNBQU9BLENBQUNBLFdBQVdBLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLENBQUNBLEVBQUNBLENBQUNBO1FBQ25DQSxjQUFPQSxDQUFDQSxXQUFXQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxDQUFDQSxFQUFDQSxDQUFDQTtRQUNuQ0EsY0FBT0EsQ0FBQ0EsWUFBWUEsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7S0FDckNBLENBQUNBO0lBRUZBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLFFBQVFBLEVBQUVBLFNBQVNBLEVBQUVBLEVBQUVBLEVBQUVBLGFBQWFBLEVBQUVBLGlDQUFzQkEsRUFBQ0E7UUFDMUVBO1lBQ0VBLFFBQVFBLEVBQUVBLFNBQVNBO1lBQ25CQSxTQUFTQSxFQUFFQSxnQkFBZ0JBO1lBQzNCQSxhQUFhQSxFQUFFQSxrQ0FBdUJBO1NBQ3ZDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxVQUFDQSxPQUFPQTtRQUNsQkEsd0JBQXdCQSxTQUFnQkEsRUFBRUEsTUFBdUJBLEVBQUVBLE1BQXVCQTtZQUFoREMsc0JBQXVCQSxHQUF2QkEsYUFBdUJBO1lBQUVBLHNCQUF1QkEsR0FBdkJBLGNBQXVCQTtZQUN4RkEsTUFBTUEsQ0FBQ0EsSUFBSUEsZUFBUUEsQ0FBQ0Esd0JBQWFBLENBQUNBLHFCQUFxQkEsQ0FDL0JBLGVBQVFBLENBQUNBLE9BQU9BLENBQUNBLFNBQVNBLENBQUNBLE1BQU1BLENBQUNBLE9BQU9BLENBQUNBLFdBQVdBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLEVBQzdEQSxNQUFNQSxFQUFFQSxNQUFNQSxDQUFDQSxDQUFDQTtRQUN0Q0EsQ0FBQ0E7UUFFREQsMkJBQVFBLENBQUNBLGNBQVlBLE9BQU9BLENBQUNBLFVBQVVBLENBQUdBLEVBQUVBO1lBQzFDQSxxQkFBRUEsQ0FBQ0EsK0JBQStCQSxFQUFFQTtnQkFDbENBLElBQUlBLFFBQVFBLEdBQUdBLGNBQWNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO2dCQUNsQ0EseUJBQU1BLENBQUNBLFFBQVFBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxPQUFPQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUMvRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLGlEQUFpREEsRUFBRUE7Z0JBQ3BEQSxJQUFJQSxRQUFRQSxHQUFHQSxjQUFjQSxDQUFDQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDeENBLElBQUlBLE1BQU1BLEdBQUdBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO2dCQUVsQ0EseUJBQU1BLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7WUFDMUNBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSx1REFBdURBLEVBQUVBO2dCQUMxREEsSUFBSUEsUUFBUUEsR0FBR0EsY0FBY0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzdDQSxJQUFJQSxHQUFHQSxHQUFHQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtnQkFFNUJBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO2dCQUNsQ0EseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7WUFDOUNBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSx5REFBeURBLEVBQUVBO2dCQUM1REEsSUFBSUEsUUFBUUEsR0FBR0EsY0FBY0EsQ0FBQ0EsQ0FBQ0EsV0FBV0EsRUFBRUEsTUFBTUEsRUFBRUEsYUFBYUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3BFQSxJQUFJQSxHQUFHQSxHQUFHQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtnQkFFdENBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBO2dCQUM1Q0EseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsQ0FBQ0E7WUFDbkRBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSx3REFBd0RBLEVBQUVBO2dCQUMzREEseUJBQU1BLENBQUNBLGNBQU1BLE9BQUFBLGNBQWNBLENBQUNBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLEVBQS9CQSxDQUErQkEsQ0FBQ0E7cUJBQ3hDQSxZQUFZQSxDQUNUQSx3REFBd0RBO29CQUN4REEsNkZBQTZGQTtvQkFDN0ZBLHdEQUF3REEsQ0FBQ0EsQ0FBQ0E7WUFDcEVBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSwwREFBMERBLEVBQUVBO2dCQUM3REEseUJBQU1BLENBQUNBLGNBQU1BLE9BQUFBLGNBQWNBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLFdBQVdBLEVBQUVBLEVBQUNBLFVBQVVBLEVBQUVBLFNBQVNBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBLEVBQS9EQSxDQUErREEsQ0FBQ0E7cUJBQ3hFQSxZQUFZQSxDQUNUQSxvREFBb0RBO29CQUNwREEsNkZBQTZGQTtvQkFDN0ZBLG9EQUFvREEsQ0FBQ0EsQ0FBQ0E7WUFDaEVBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSx3QkFBd0JBLEVBQUVBO2dCQUMzQkEsSUFBSUEsUUFBUUEsR0FBR0EsY0FBY0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRXhDQSxJQUFJQSxFQUFFQSxHQUFHQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTtnQkFDOUJBLElBQUlBLEVBQUVBLEdBQUdBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO2dCQUU5QkEseUJBQU1BLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO1lBQ3RCQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsMkJBQTJCQSxFQUFFQTtnQkFDOUJBLElBQUlBLFFBQVFBLEdBQUdBLGNBQWNBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLE1BQU1BLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLGFBQWFBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUU1RUEsSUFBSUEsTUFBTUEsR0FBR0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ2xDQSx5QkFBTUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7WUFDeENBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSw2QkFBNkJBLEVBQUVBO2dCQUNoQ0EsMEJBQTBCQSxDQUFDQSxJQUFJRSxNQUFNQSxDQUFDQSxJQUFJQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFekRGLElBQUlBLFFBQVFBLEdBQ1JBLGNBQWNBLENBQUNBLENBQUNBLE1BQU1BLEVBQUVBLGNBQU9BLENBQUNBLEdBQUdBLEVBQUVBLEVBQUNBLFVBQVVBLEVBQUVBLGdCQUFnQkEsRUFBRUEsSUFBSUEsRUFBRUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRTNGQSxJQUFJQSxHQUFHQSxHQUFHQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtnQkFDNUJBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBO2dCQUN4Q0EseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7WUFDOUNBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxrRUFBa0VBLEVBQUVBO2dCQUNyRUEsb0NBQW9DRyxNQUFNQSxDQUFDQSxJQUFJQSxHQUFHQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFM0RILElBQUlBLFFBQVFBLEdBQUdBLGNBQWNBLENBQUNBO29CQUM1QkEsTUFBTUE7b0JBQ05BLGNBQU9BLENBQUNBLEdBQUdBLEVBQ0hBO3dCQUNFQSxVQUFVQSxFQUFFQSxzQkFBc0JBO3dCQUNsQ0EsSUFBSUEsRUFBRUE7NEJBQ0pBLE1BQU1BOzRCQUNOQSxNQUFNQTs0QkFDTkEsTUFBTUE7NEJBQ05BLE1BQU1BOzRCQUNOQSxNQUFNQTs0QkFDTkEsTUFBTUE7NEJBQ05BLE1BQU1BOzRCQUNOQSxNQUFNQTs0QkFDTkEsTUFBTUE7NEJBQ05BLE1BQU1BOzRCQUNOQSxNQUFNQTs0QkFDTkEsTUFBTUE7NEJBQ05BLE1BQU1BOzRCQUNOQSxNQUFNQTs0QkFDTkEsTUFBTUE7NEJBQ05BLE1BQU1BOzRCQUNOQSxNQUFNQTs0QkFDTkEsTUFBTUE7NEJBQ05BLE1BQU1BOzRCQUNOQSxNQUFNQTs0QkFDTkEsTUFBTUE7eUJBQ1BBO3FCQUNGQSxDQUFDQTtpQkFDWEEsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLElBQUlBLENBQUNBO29CQUNIQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtvQkFDbEJBLE1BQU1BLFlBQVlBLENBQUNBO2dCQUNyQkEsQ0FBRUE7Z0JBQUFBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUNYQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0E7eUJBQ1pBLFNBQVNBLENBQUNBLG1FQUFtRUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3RGQSxDQUFDQTtZQUNIQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0Esb0NBQW9DQSxFQUFFQTtnQkFDdkNBLElBQUlBLFFBQVFBLEdBQUdBLGNBQWNBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLE1BQU1BLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLElBQUlBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUNuRUEsSUFBSUEsTUFBTUEsR0FBR0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ2xDQSx5QkFBTUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0E7WUFDNUJBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSw0QkFBNEJBLEVBQUVBO2dCQUMvQkEsSUFBSUEsUUFBUUEsR0FBR0EsY0FBY0EsQ0FBQ0E7b0JBQzVCQSxNQUFNQTtvQkFDTkEsY0FBT0EsQ0FBQ0EsU0FBU0EsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsU0FBU0EsRUFBQ0EsQ0FBQ0E7b0JBQ3pDQSxjQUFPQSxDQUFDQSxHQUFHQSxFQUFFQSxFQUFDQSxXQUFXQSxFQUFFQSxTQUFTQSxFQUFDQSxDQUFDQTtpQkFDdkNBLENBQUNBLENBQUNBO2dCQUVIQSxJQUFJQSxHQUFHQSxHQUFHQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtnQkFDNUJBLElBQUlBLFNBQVNBLEdBQUdBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBO2dCQUN4Q0EseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3hDQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7WUFDOUJBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSwrQkFBK0JBLEVBQUVBO2dCQUNsQ0EsSUFBSUEsUUFBUUEsR0FBR0EsY0FBY0EsQ0FBQ0E7b0JBQzVCQSxNQUFNQTtvQkFDTkEsSUFBSUEsZUFBUUEsQ0FBQ0EsR0FBR0EsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsU0FBU0EsRUFBRUEsS0FBS0EsRUFBRUEsSUFBSUEsRUFBQ0EsQ0FBQ0E7b0JBQ3JEQSxJQUFJQSxlQUFRQSxDQUFDQSxHQUFHQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxxQkFBcUJBLEVBQUVBLEtBQUtBLEVBQUVBLElBQUlBLEVBQUNBLENBQUNBO2lCQUNsRUEsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLElBQUlBLElBQUlBLEdBQUdBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO2dCQUM3QkEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUMvQkEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzVDQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxxQkFBcUJBLENBQUNBLENBQUNBO1lBQzFEQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0Esa0VBQWtFQSxFQUFFQTtnQkFDckVBLElBQUlBLFFBQVFBLEdBQUdBLGNBQWNBLENBQ3pCQSxDQUFDQSxNQUFNQSxFQUFFQSxTQUFTQSxFQUFFQSxJQUFJQSxlQUFRQSxDQUFDQSxHQUFHQSxFQUFFQSxFQUFDQSxXQUFXQSxFQUFFQSxTQUFTQSxFQUFFQSxLQUFLQSxFQUFFQSxJQUFJQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFbkZBLElBQUlBLElBQUlBLEdBQUdBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO2dCQUM3QkEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUMvQkEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBO1lBQ2hEQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsdURBQXVEQSxFQUFFQTtnQkFDMURBLElBQUlBLFFBQVFBLEdBQUdBLGNBQWNBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLEtBQUtBLEVBQUVBLEVBQUNBLFdBQVdBLEVBQUVBLFNBQVNBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUMxRUEsSUFBSUEsQ0FBQ0EsR0FBR0EscUJBQW1CQSxnQkFBU0EsQ0FBQ0EsU0FBU0EsQ0FBQ0Esa0JBQWFBLGdCQUFTQSxDQUFDQSxTQUFTQSxDQUFDQSxNQUFHQSxDQUFDQTtnQkFDcEZBLHlCQUFNQSxDQUFDQSxjQUFNQSxPQUFBQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxLQUFLQSxDQUFDQSxFQUFuQkEsQ0FBbUJBLENBQUNBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ3BEQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EseUNBQXlDQSxFQUFFQTtnQkFDNUNBLElBQUlBLFFBQVFBLEdBQUdBLGNBQWNBLENBQUNBO29CQUM1QkEsY0FBT0EsQ0FBQ0EsZ0JBQWdCQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxpQkFBVUEsQ0FBQ0EsY0FBTUEsT0FBQUEsTUFBTUEsRUFBTkEsQ0FBTUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7b0JBQy9EQSxjQUFPQSxDQUFDQSxlQUFlQSxFQUFFQSxFQUFDQSxXQUFXQSxFQUFNQSxpQkFBVUEsQ0FBQ0EsY0FBTUEsT0FBQUEsZ0JBQWdCQSxFQUFoQkEsQ0FBZ0JBLENBQUNBLEVBQUNBLENBQUNBO2lCQUNoRkEsQ0FBQ0EsQ0FBQ0E7Z0JBQ0hBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO1lBQ2pFQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsZ0RBQWdEQSxFQUFFQTtnQkFDbkRBLElBQUlBLFFBQVFBLEdBQUdBLGNBQWNBLENBQ3pCQSxDQUFDQSxNQUFNQSxFQUFFQSxjQUFPQSxDQUFDQSxHQUFHQSxFQUFFQSxFQUFDQSxVQUFVQSxFQUFFQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxJQUFJQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFoQkEsQ0FBZ0JBLEVBQUVBLElBQUlBLEVBQUVBLENBQUNBLE1BQU1BLENBQUNBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUVuRkEsSUFBSUEsR0FBR0EsR0FBR0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzVCQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQTtnQkFDeENBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO1lBQzlDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0Esc0NBQXNDQSxFQUFFQTtnQkFDekNBLElBQUlBLFFBQVFBLEdBQUdBLGNBQWNBLENBQUNBLENBQUNBLHFCQUFxQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRXZEQSxJQUFJQSxHQUFHQSxHQUFHQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxxQkFBcUJBLENBQUNBLENBQUNBO2dCQUM5Q0EseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLElBQUlBLENBQUNBLENBQUNBO1lBQ25DQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0Esb0NBQW9DQSxFQUFFQTtnQkFDdkNBLElBQUlBLFFBQVFBLEdBQUdBLGNBQWNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLE1BQU1BLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUVqREEsSUFBSUEsR0FBR0EsR0FBR0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzVCQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtZQUNwQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLCtFQUErRUEsRUFBRUE7Z0JBQ2xGQSxJQUFJQSxRQUFRQSxHQUFHQSxjQUFjQSxDQUN6QkEsQ0FBQ0EsY0FBT0EsQ0FBQ0EsTUFBTUEsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsTUFBTUEsRUFBQ0EsQ0FBQ0EsRUFBRUEsY0FBT0EsQ0FBQ0EsTUFBTUEsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsV0FBV0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRXJGQSx5QkFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQTtZQUM3REEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDRCQUE0QkEsRUFBRUE7Z0JBQy9CQSxJQUFJQSxRQUFRQSxHQUFHQSxjQUFjQSxDQUFDQSxDQUFDQSxjQUFPQSxDQUFDQSxPQUFPQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxPQUFPQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFdkVBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtZQUNqREEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDJDQUEyQ0EsRUFBRUE7Z0JBQzlDQSx5QkFBTUEsQ0FBQ0EsY0FBTUEsT0FBQUEsY0FBY0EsQ0FBTUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsRUFBN0JBLENBQTZCQSxDQUFDQTtxQkFDdENBLFlBQVlBLENBQ1RBLCtFQUErRUEsQ0FBQ0EsQ0FBQ0E7WUFDM0ZBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSx1QkFBdUJBLEVBQUVBO2dCQUMxQkEsSUFBSUEsTUFBTUEsR0FBR0EsY0FBY0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ2hDQSxJQUFJQSxLQUFLQSxHQUFHQSxNQUFNQSxDQUFDQSxxQkFBcUJBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO2dCQUU3Q0EseUJBQU1BLENBQUNBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLGVBQVFBLENBQUNBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO1lBQzFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsdUNBQXVDQSxFQUFFQTtnQkFDMUNBLElBQUlBLFFBQVFBLEdBQUdBLGNBQWNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO2dCQUNsQ0EseUJBQU1BLENBQUNBLGNBQU1BLE9BQUFBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLGFBQWFBLENBQUNBLEVBQTNCQSxDQUEyQkEsQ0FBQ0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsOEJBQThCQSxDQUFDQSxDQUFDQTtZQUN6RkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDRDQUE0Q0EsRUFBRUE7Z0JBQy9DQSxJQUFJQSxRQUFRQSxHQUFHQSxjQUFjQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLEVBQUVBLE1BQU1BLEVBQUVBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBO2dCQUNyRUEseUJBQU1BLENBQUNBLGNBQU1BLE9BQUFBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsRUFBOUJBLENBQThCQSxDQUFDQTtxQkFDdkNBLFlBQVlBLENBQ1RBLHlDQUF1Q0EsZ0JBQVNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsWUFBT0EsZ0JBQVNBLENBQUNBLFNBQVNBLENBQUNBLDJCQUF3QkEsQ0FBQ0EsQ0FBQ0E7WUFDaklBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSw2REFBNkRBLEVBQUVBO2dCQUNoRUEsSUFBSUEsUUFBUUEsR0FBR0EsY0FBY0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsRUFBRUEsY0FBT0EsQ0FBQ0EsTUFBTUEsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsWUFBWUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRWhGQSx5QkFBTUEsQ0FBQ0EsY0FBTUEsT0FBQUEsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBakJBLENBQWlCQSxDQUFDQTtxQkFDMUJBLFlBQVlBLENBQ1RBLDRDQUEwQ0EsZ0JBQVNBLENBQUNBLEdBQUdBLENBQUNBLFlBQU9BLGdCQUFTQSxDQUFDQSxNQUFNQSxDQUFDQSxZQUFPQSxnQkFBU0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsTUFBR0EsQ0FBQ0EsQ0FBQ0E7WUFDcEhBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSwrREFBK0RBLEVBQUVBO2dCQUNsRUEsSUFBSUEsU0FBU0EsR0FBR0EsZUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsRUFBRUEsY0FBT0EsQ0FBQ0EsTUFBTUEsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsWUFBWUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ25GQSxJQUFJQSxLQUFLQSxHQUFHQSxJQUFJQSx3QkFBYUEsQ0FBQ0E7b0JBQzVCQSxJQUFJQSxpQ0FBc0JBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLHFCQUFVQSxDQUFDQSxNQUFNQSxDQUFDQTtvQkFDM0RBLElBQUlBLGlDQUFzQkEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEscUJBQVVBLENBQUNBLE1BQU1BLENBQUNBO2lCQUM1REEsQ0FBQ0EsQ0FBQ0E7Z0JBQ0hBLElBQUlBLFFBQVFBLEdBQUdBLElBQUlBLGVBQVFBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO2dCQUVuQ0EsSUFBSUEsQ0FBQ0E7b0JBQ0hBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO29CQUNsQkEsTUFBTUEsWUFBWUEsQ0FBQ0E7Z0JBQ3JCQSxDQUFFQTtnQkFBQUEsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ1hBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQTt5QkFDWkEsU0FBU0EsQ0FBQ0EsNENBQTBDQSxnQkFBU0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsZ0JBQWFBLENBQUNBLENBQUNBO29CQUN0RkEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLGlCQUFpQkEsWUFBWUEsMEJBQWFBLENBQUNBLENBQUNBLFVBQVVBLEVBQUVBLENBQUNBO29CQUNsRUEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLFFBQVFBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO2dCQUMzQ0EsQ0FBQ0E7WUFDSEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLG9EQUFvREEsRUFBRUE7Z0JBQ3ZEQSxJQUFJQSxjQUFjQSxHQUFHQSxlQUFRQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxjQUFPQSxDQUFDQSxNQUFNQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxZQUFZQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDdEZBLElBQUlBLFdBQVdBLEdBQ1hBLElBQUlBLHdCQUFhQSxDQUFDQSxDQUFDQSxJQUFJQSxpQ0FBc0JBLENBQUNBLGNBQWNBLEVBQUVBLHFCQUFVQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFdkZBLElBQUlBLFdBQVdBLEdBQUdBLGVBQVFBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUM3Q0EsSUFBSUEsVUFBVUEsR0FDVkEsSUFBSUEsd0JBQWFBLENBQUNBLENBQUNBLElBQUlBLGlDQUFzQkEsQ0FBQ0EsV0FBV0EsRUFBRUEscUJBQVVBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUVwRkEsSUFBSUEsTUFBTUEsR0FBR0EsSUFBSUEsZUFBUUEsQ0FBQ0EsV0FBV0EsRUFBRUEsSUFBSUEsRUFBRUEsS0FBS0EsRUFBRUEsSUFBSUEsRUFBRUEsY0FBTUEsT0FBQUEsZUFBZUEsRUFBZkEsQ0FBZUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ2pGQSxJQUFJQSxLQUFLQSxHQUFHQSxJQUFJQSxlQUFRQSxDQUFDQSxVQUFVQSxFQUFFQSxNQUFNQSxFQUFFQSxLQUFLQSxFQUFFQSxJQUFJQSxFQUFFQSxjQUFNQSxPQUFBQSxjQUFjQSxFQUFkQSxDQUFjQSxDQUFDQSxDQUFDQTtnQkFFaEZBLElBQUlBLENBQUNBO29CQUNIQSxLQUFLQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtvQkFDZkEsTUFBTUEsWUFBWUEsQ0FBQ0E7Z0JBQ3JCQSxDQUFFQTtnQkFBQUEsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ1hBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQTtnQkFDNUNBLENBQUNBO1lBQ0hBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxxREFBcURBLEVBQUVBO2dCQUN4REEsSUFBSUEsUUFBUUEsR0FBR0EsSUFBSUEsQ0FBQ0E7Z0JBRXBCQSxJQUFJQSxRQUFRQSxHQUFHQSxjQUFjQSxDQUFDQTtvQkFDNUJBLEdBQUdBO29CQUNIQSxjQUFPQSxDQUFDQSxNQUFNQSxFQUFFQSxFQUFDQSxVQUFVQSxFQUFFQSxDQUFDQSxjQUFNQSxPQUFBQSxRQUFRQSxHQUFHQSxJQUFJQSxZQUFZQSxFQUFFQSxHQUFHQSxJQUFJQSxNQUFNQSxFQUFFQSxFQUE1Q0EsQ0FBNENBLENBQUNBLEVBQUNBLENBQUNBO2lCQUNwRkEsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLHlCQUFNQSxDQUFDQSxjQUFNQSxPQUFBQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFqQkEsQ0FBaUJBLENBQUNBLENBQUNBLFlBQVlBLENBQUNBLElBQUlBLE1BQU1BLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBO2dCQUVsRUEsUUFBUUEsR0FBR0EsS0FBS0EsQ0FBQ0E7Z0JBRWpCQSx5QkFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtZQUNsREEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDRCQUE0QkEsRUFBRUE7Z0JBQy9CQSxJQUFJQSxRQUFRQSxHQUFHQSxjQUFjQSxDQUFDQSxDQUFDQSxjQUFPQSxDQUFDQSxNQUFNQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxJQUFJQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDbkVBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtZQUMxQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLHVDQUF1Q0EsRUFBRUE7Z0JBQzFDQSxJQUFJQSxDQUFDQSxHQUFHQSxJQUFJQSxNQUFNQSxFQUFFQSxDQUFDQTtnQkFFckJBLElBQUlBLFdBQVdBLEdBQVFBLElBQUlBLDZCQUFxQkEsRUFBRUEsQ0FBQ0E7Z0JBQ25EQSxXQUFXQSxDQUFDQSxHQUFHQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFOUNBLElBQUlBLFNBQVNBLEdBQUdBLGVBQVFBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBO2dCQUN4Q0EsSUFBSUEsS0FBS0EsR0FDTEEsSUFBSUEsd0JBQWFBLENBQUNBLENBQUNBLElBQUlBLGlDQUFzQkEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEscUJBQVVBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUNyRkEsSUFBSUEsUUFBUUEsR0FBR0EsSUFBSUEsZUFBUUEsQ0FBQ0EsS0FBS0EsRUFBRUEsSUFBSUEsRUFBRUEsS0FBS0EsRUFBRUEsV0FBV0EsQ0FBQ0EsQ0FBQ0E7Z0JBRTdEQSx5QkFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzVDQSx5QkFBTUEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0E7cUJBQ25DQSxvQkFBb0JBLENBQUNBLFFBQVFBLEVBQUVBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBLEVBQ3RCQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQy9FQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUdIQSwyQkFBUUEsQ0FBQ0EsT0FBT0EsRUFBRUE7WUFDaEJBLHFCQUFFQSxDQUFDQSw0Q0FBNENBLEVBQUVBO2dCQUMvQ0EsSUFBSUEsTUFBTUEsR0FBR0EsZUFBUUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDakRBLElBQUlBLEtBQUtBLEdBQUdBLE1BQU1BLENBQUNBLHFCQUFxQkEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7Z0JBRTdDQSxJQUFJQSxnQkFBZ0JBLEdBQUdBLE1BQU1BLENBQUNBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO2dCQUMxQ0EsSUFBSUEsZUFBZUEsR0FBR0EsS0FBS0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7Z0JBRXhDQSx5QkFBTUEsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQTtZQUNqREEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLHlGQUF5RkEsRUFDekZBO2dCQUNFQSxJQUFJQSxNQUFNQSxHQUFHQSxlQUFRQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLEdBQUdBLEVBQUVBLE1BQU1BLENBQUNBLENBQUNBLENBQUNBO2dCQUN0REEsSUFBSUEsS0FBS0EsR0FBR0EsTUFBTUEsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQSxjQUFPQSxDQUFDQSxNQUFNQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxXQUFXQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFckZBLElBQUlBLFlBQVlBLEdBQUdBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO2dCQUNsQ0EseUJBQU1BLENBQUNBLFlBQVlBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7WUFDdkRBLENBQUNBLENBQUNBLENBQUNBO1lBRU5BLHFCQUFFQSxDQUFDQSxnREFBZ0RBLEVBQUVBO2dCQUNuREEsSUFBSUEsTUFBTUEsR0FBR0EsZUFBUUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDakRBLElBQUlBLEtBQUtBLEdBQUdBLE1BQU1BLENBQUNBLHFCQUFxQkEsQ0FBQ0EsQ0FBQ0EsY0FBT0EsQ0FBQ0EsTUFBTUEsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsV0FBV0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRXJGQSxJQUFJQSxnQkFBZ0JBLEdBQUdBLE1BQU1BLENBQUNBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO2dCQUMxQ0EsSUFBSUEsZUFBZUEsR0FBR0EsS0FBS0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7Z0JBRXhDQSx5QkFBTUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxJQUFJQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQTtnQkFDbkRBLHlCQUFNQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO1lBQ3hEQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsOEJBQThCQSxFQUFFQTtnQkFDakNBLElBQUlBLE1BQU1BLEdBQUdBLGVBQVFBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7Z0JBQzNDQSxJQUFJQSxLQUFLQSxHQUFHQSxNQUFNQSxDQUFDQSxxQkFBcUJBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO2dCQUM3Q0EseUJBQU1BLENBQUNBLEtBQUtBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLElBQUlBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO1lBQ3BDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsdUJBQXVCQSxFQUFFQTtZQUNoQ0EscUJBQUVBLENBQUNBLDZEQUE2REEsRUFBRUE7Z0JBQ2hFQSxJQUFJQSxHQUFHQSxHQUFHQSxlQUFRQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLENBQUNBO2dCQUM5Q0EsSUFBSUEsR0FBR0EsR0FBR0EsR0FBR0EsQ0FBQ0EscUJBQXFCQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtnQkFDekNBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO2dCQUNsQ0EseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLENBQUNBO1lBQzNDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsMERBQTBEQSxFQUFFQTtnQkFDN0RBLElBQUlBLEdBQUdBLEdBQUdBLGVBQVFBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzlDQSxHQUFHQSxDQUFDQSxxQkFBcUJBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO2dCQUMvQkEseUJBQU1BLENBQUNBLGNBQU1BLE9BQUFBLEdBQUdBLENBQUNBLEdBQUdBLENBQUNBLEdBQUdBLENBQUNBLEVBQVpBLENBQVlBLENBQUNBLENBQUNBLFlBQVlBLEVBQUVBLENBQUNBO1lBQzVDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsYUFBYUEsRUFBRUE7WUFDdEJBLHFCQUFFQSxDQUFDQSw2REFBNkRBLEVBQUVBO2dCQUNoRUEsSUFBSUEsR0FBR0EsR0FBR0EsZUFBUUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDOUNBLElBQUlBLEdBQUdBLEdBQUdBLEdBQUdBLENBQUNBLG1CQUFtQkEsQ0FBQ0EsZUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzlEQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtnQkFDbENBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUMzQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEsMkJBQVFBLENBQUNBLHNCQUFzQkEsRUFBRUE7WUFDL0JBLDJCQUFRQSxDQUFDQSxTQUFTQSxFQUFFQTtnQkFDbEJBLHFCQUFFQSxDQUFDQSxzQ0FBc0NBLEVBQUVBO29CQUN6Q0EsSUFBSUEsR0FBR0EsR0FBR0EsZUFBUUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQTt3QkFDbENBLE1BQU1BO3dCQUNOQSxjQUFPQSxDQUFDQSxHQUFHQSxFQUFFQSxFQUFDQSxVQUFVQSxFQUFFQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxJQUFJQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFWQSxDQUFVQSxFQUFFQSxJQUFJQSxFQUFFQSxDQUFDQSxDQUFDQSxNQUFNQSxFQUFFQSxJQUFJQSxtQkFBWUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7cUJBQ3BGQSxDQUFDQSxDQUFDQTtvQkFFSEEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLEdBQUdBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzdDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFSEEscUJBQUVBLENBQUNBLGtEQUFrREEsRUFBRUE7b0JBQ3JEQSxJQUFJQSxNQUFNQSxHQUFHQSxlQUFRQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLENBQUNBO29CQUNqREEsSUFBSUEsS0FBS0EsR0FBR0EsTUFBTUEsQ0FBQ0EscUJBQXFCQSxDQUFDQTt3QkFDdkNBLGNBQU9BLENBQUNBLEdBQUdBLEVBQUVBLEVBQUNBLFVBQVVBLEVBQUVBLFVBQUNBLENBQUNBLElBQUtBLE9BQUFBLElBQUlBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLEVBQVZBLENBQVVBLEVBQUVBLElBQUlBLEVBQUVBLENBQUNBLENBQUNBLE1BQU1BLEVBQUVBLElBQUlBLG1CQUFZQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFDQSxDQUFDQTtxQkFDcEZBLENBQUNBLENBQUNBO29CQUVIQSx5QkFBTUEsQ0FBQ0EsY0FBTUEsT0FBQUEsS0FBS0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBZEEsQ0FBY0EsQ0FBQ0E7eUJBQ3ZCQSxZQUFZQSxDQUFDQSw4QkFBNEJBLGdCQUFTQSxDQUFDQSxHQUFHQSxDQUFDQSxZQUFPQSxnQkFBU0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsTUFBR0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzNGQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSwyQkFBUUEsQ0FBQ0EsU0FBU0EsRUFBRUE7Z0JBQ2xCQSxxQkFBRUEsQ0FBQ0EsMkNBQTJDQSxFQUFFQTtvQkFDOUNBLElBQUlBLE1BQU1BLEdBQUdBLGVBQVFBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ2pEQSxJQUFJQSxLQUFLQSxHQUFHQSxNQUFNQSxDQUFDQSxxQkFBcUJBLENBQUNBO3dCQUN2Q0EsY0FBT0EsQ0FBQ0EsR0FBR0EsRUFBRUEsRUFBQ0EsVUFBVUEsRUFBRUEsVUFBQ0EsQ0FBQ0EsSUFBS0EsT0FBQUEsSUFBSUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBVkEsQ0FBVUEsRUFBRUEsSUFBSUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsTUFBTUEsRUFBRUEsSUFBSUEsbUJBQVlBLEVBQUVBLENBQUNBLENBQUNBLEVBQUNBLENBQUNBO3FCQUNwRkEsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHlCQUFNQSxDQUFDQSxLQUFLQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO2dCQUMvQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLHFCQUFFQSxDQUFDQSx5REFBeURBLEVBQUVBO29CQUM1REEsSUFBSUEsTUFBTUEsR0FBR0EsZUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQzNDQSxJQUFJQSxXQUFXQSxHQUNYQSxJQUFJQSx3QkFBYUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsaUNBQXNCQSxDQUFDQSxNQUFNQSxFQUFFQSxxQkFBVUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ2hGQSxJQUFJQSxNQUFNQSxHQUFHQSxJQUFJQSxlQUFRQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQTtvQkFFdkNBLElBQUlBLEtBQUtBLEdBQUdBLGNBQWNBLENBQ3RCQSxDQUFDQSxjQUFPQSxDQUFDQSxHQUFHQSxFQUFFQSxFQUFDQSxVQUFVQSxFQUFFQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxJQUFJQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFWQSxDQUFVQSxFQUFFQSxJQUFJQSxFQUFFQSxDQUFDQSxDQUFDQSxNQUFNQSxFQUFFQSxJQUFJQSxtQkFBWUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsRUFDckZBLE1BQU1BLEVBQUVBLElBQUlBLENBQUNBLENBQUNBLENBQUVBLE9BQU9BO29CQUUzQkEseUJBQU1BLENBQUNBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7Z0JBQy9DQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFSEEscUJBQUVBLENBQUNBLDREQUE0REEsRUFBRUE7b0JBQy9EQSxJQUFJQSxNQUFNQSxHQUFHQSxlQUFRQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDM0NBLElBQUlBLFdBQVdBLEdBQ1hBLElBQUlBLHdCQUFhQSxDQUFDQSxDQUFDQSxJQUFJQSxpQ0FBc0JBLENBQUNBLE1BQU1BLEVBQUVBLHFCQUFVQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDL0VBLElBQUlBLE1BQU1BLEdBQUdBLElBQUlBLGVBQVFBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO29CQUV2Q0EsSUFBSUEsS0FBS0EsR0FBR0EsY0FBY0EsQ0FDdEJBLENBQUNBLGNBQU9BLENBQUNBLEdBQUdBLEVBQUVBLEVBQUNBLFVBQVVBLEVBQUVBLFVBQUNBLENBQUNBLElBQUtBLE9BQUFBLElBQUlBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLEVBQVZBLENBQVVBLEVBQUVBLElBQUlBLEVBQUVBLENBQUNBLENBQUNBLE1BQU1BLEVBQUVBLElBQUlBLG1CQUFZQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFDQSxDQUFDQSxDQUFDQSxFQUNyRkEsTUFBTUEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBRUEsT0FBT0E7b0JBRTNCQSx5QkFBTUEsQ0FBQ0EsY0FBTUEsT0FBQUEsS0FBS0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBZEEsQ0FBY0EsQ0FBQ0E7eUJBQ3ZCQSxZQUFZQSxDQUFDQSw4QkFBNEJBLGdCQUFTQSxDQUFDQSxHQUFHQSxDQUFDQSxZQUFPQSxnQkFBU0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsTUFBR0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzNGQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFSEEscUJBQUVBLENBQUNBLHNCQUFzQkEsRUFBRUE7b0JBQ3pCQSxJQUFJQSxNQUFNQSxHQUFHQSxlQUFRQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLENBQUNBO29CQUNqREEsSUFBSUEsS0FBS0EsR0FBR0EsTUFBTUEsQ0FBQ0EscUJBQXFCQSxDQUFDQTt3QkFDdkNBLGNBQU9BLENBQUNBLE1BQU1BLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLFdBQVdBLEVBQUNBLENBQUNBO3dCQUN4Q0EsY0FBT0EsQ0FBQ0EsR0FBR0EsRUFBRUEsRUFBQ0EsVUFBVUEsRUFBRUEsVUFBQ0EsQ0FBQ0EsSUFBS0EsT0FBQUEsSUFBSUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBVkEsQ0FBVUEsRUFBRUEsSUFBSUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsTUFBTUEsRUFBRUEsSUFBSUEsbUJBQVlBLEVBQUVBLENBQUNBLENBQUNBLEVBQUNBLENBQUNBO3FCQUNwRkEsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHlCQUFNQSxDQUFDQSxLQUFLQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO2dCQUM5REEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEsMkJBQVFBLENBQUNBLFNBQVNBLEVBQUVBO2dCQUNsQkEscUJBQUVBLENBQUNBLHlEQUF5REEsRUFBRUE7b0JBQzVEQSxJQUFJQSxNQUFNQSxHQUFHQSxlQUFRQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDM0NBLElBQUlBLFdBQVdBLEdBQ1hBLElBQUlBLHdCQUFhQSxDQUFDQSxDQUFDQSxJQUFJQSxpQ0FBc0JBLENBQUNBLE1BQU1BLEVBQUVBLHFCQUFVQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDaEZBLElBQUlBLE1BQU1BLEdBQUdBLElBQUlBLGVBQVFBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO29CQUV2Q0EsSUFBSUEsS0FBS0EsR0FBR0EsY0FBY0EsQ0FDdEJBO3dCQUNFQSxjQUFPQSxDQUFDQSxNQUFNQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxZQUFZQSxFQUFDQSxDQUFDQTt3QkFDekNBLGNBQU9BLENBQUNBLEdBQUdBLEVBQ0hBLEVBQUNBLFVBQVVBLEVBQUVBLFVBQUNBLENBQUNBLElBQUtBLE9BQUFBLElBQUlBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLEVBQVZBLENBQVVBLEVBQUVBLElBQUlBLEVBQUVBLENBQUNBLENBQUNBLE1BQU1BLEVBQUVBLElBQUlBLHVCQUFnQkEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7cUJBQ25GQSxFQUNEQSxNQUFNQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFFQSxXQUFXQTtvQkFFL0JBLHlCQUFNQSxDQUFDQSxLQUFLQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO2dCQUMvQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLHFCQUFFQSxDQUFDQSx3REFBd0RBLEVBQUVBO29CQUMzREEsSUFBSUEsTUFBTUEsR0FBR0EsZUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQzNDQSxJQUFJQSxXQUFXQSxHQUNYQSxJQUFJQSx3QkFBYUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsaUNBQXNCQSxDQUFDQSxNQUFNQSxFQUFFQSxxQkFBVUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQy9FQSxJQUFJQSxNQUFNQSxHQUFHQSxJQUFJQSxlQUFRQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQTtvQkFFdkNBLElBQUlBLEtBQUtBLEdBQUdBLGNBQWNBLENBQ3RCQTt3QkFDRUEsY0FBT0EsQ0FBQ0EsTUFBTUEsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsWUFBWUEsRUFBQ0EsQ0FBQ0E7d0JBQ3pDQSxjQUFPQSxDQUFDQSxHQUFHQSxFQUNIQSxFQUFDQSxVQUFVQSxFQUFFQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxJQUFJQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFWQSxDQUFVQSxFQUFFQSxJQUFJQSxFQUFFQSxDQUFDQSxDQUFDQSxNQUFNQSxFQUFFQSxJQUFJQSx1QkFBZ0JBLEVBQUVBLENBQUNBLENBQUNBLEVBQUNBLENBQUNBO3FCQUNuRkEsRUFDREEsTUFBTUEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBRUEsV0FBV0E7b0JBRS9CQSx5QkFBTUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtnQkFDL0NBLENBQUNBLENBQUNBLENBQUNBO2dCQUVIQSxxQkFBRUEsQ0FBQ0EsaUVBQWlFQSxFQUFFQTtvQkFDcEVBLElBQUlBLE1BQU1BLEdBQUdBLGVBQVFBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUMzQ0EsSUFBSUEsV0FBV0EsR0FDWEEsSUFBSUEsd0JBQWFBLENBQUNBLENBQUNBLElBQUlBLGlDQUFzQkEsQ0FBQ0EsTUFBTUEsRUFBRUEscUJBQVVBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUNoRkEsSUFBSUEsTUFBTUEsR0FBR0EsSUFBSUEsZUFBUUEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsQ0FBQ0E7b0JBRXZDQSxJQUFJQSxLQUFLQSxHQUFHQSxjQUFjQSxDQUN0QkE7d0JBQ0VBLGNBQU9BLENBQUNBLE1BQU1BLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLFlBQVlBLEVBQUNBLENBQUNBO3dCQUN6Q0EsY0FBT0EsQ0FBQ0EsR0FBR0EsRUFDSEEsRUFBQ0EsVUFBVUEsRUFBRUEsVUFBQ0EsQ0FBQ0EsSUFBS0EsT0FBQUEsSUFBSUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBVkEsQ0FBVUEsRUFBRUEsSUFBSUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsTUFBTUEsRUFBRUEsSUFBSUEsdUJBQWdCQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFDQSxDQUFDQTtxQkFDbkZBLEVBQ0RBLE1BQU1BLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBO29CQUVuQkEseUJBQU1BLENBQUNBLGNBQU1BLE9BQUFBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLEdBQUdBLENBQUNBLEVBQWRBLENBQWNBLENBQUNBO3lCQUN2QkEsWUFBWUEsQ0FBQ0EsOEJBQTRCQSxnQkFBU0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsWUFBT0EsZ0JBQVNBLENBQUNBLE1BQU1BLENBQUNBLE1BQUdBLENBQUNBLENBQUNBO2dCQUMzRkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLHFCQUFFQSxDQUFDQSxzQkFBc0JBLEVBQUVBO29CQUN6QkEsSUFBSUEsTUFBTUEsR0FBR0EsZUFBUUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDakRBLElBQUlBLEtBQUtBLEdBQUdBLE1BQU1BLENBQUNBLHFCQUFxQkEsQ0FBQ0E7d0JBQ3ZDQSxjQUFPQSxDQUFDQSxNQUFNQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxXQUFXQSxFQUFDQSxDQUFDQTt3QkFDeENBLGNBQU9BLENBQUNBLEdBQUdBLEVBQUVBLEVBQUNBLFVBQVVBLEVBQUVBLFVBQUNBLENBQUNBLElBQUtBLE9BQUFBLElBQUlBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLEVBQVZBLENBQVVBLEVBQUVBLElBQUlBLEVBQUVBLENBQUNBLE1BQU1BLENBQUNBLEVBQUNBLENBQUNBO3FCQUM5REEsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHlCQUFNQSxDQUFDQSxLQUFLQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO2dCQUM5REEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEsMkJBQVFBLENBQUNBLFNBQVNBLEVBQUVBO1lBQ2xCQSxxQkFBRUEsQ0FBQ0EsNEJBQTRCQSxFQUFFQTtnQkFDL0JBLElBQUlBLFNBQVNBLEdBQUdBLGVBQVFBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLE1BQU1BLEVBQUVBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUMzREEsU0FBU0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsVUFBU0EsQ0FBQ0E7b0JBQzFCLEVBQUUsQ0FBQyxDQUFDLGNBQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFBQyxNQUFNLENBQUMsQ0FBRSwrQkFBK0I7b0JBQ3hELHlCQUFNLENBQUMsQ0FBQyxZQUFZLDRCQUFpQixDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNwRCxDQUFDLENBQUNBLENBQUNBO1lBQ0xBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxnQ0FBZ0NBLEVBQUVBO2dCQUNuQ0EsSUFBSUEsUUFBUUEsR0FBR0EsZUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0E7b0JBQzlCQSxJQUFJQSxlQUFRQSxDQUFDQSxNQUFNQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxZQUFZQSxFQUFFQSxLQUFLQSxFQUFFQSxJQUFJQSxFQUFDQSxDQUFDQTtvQkFDM0RBLElBQUlBLGVBQVFBLENBQUNBLE1BQU1BLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLFdBQVdBLEVBQUVBLEtBQUtBLEVBQUVBLElBQUlBLEVBQUNBLENBQUNBO2lCQUMzREEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRU5BLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTtnQkFDeENBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtnQkFDN0NBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxpQkFBaUJBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ3ZEQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsdURBQXVEQSxFQUFFQTtnQkFDMURBLElBQUlBLFFBQVFBLEdBQ1JBLGVBQVFBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLElBQUlBLGVBQVFBLENBQUNBLE1BQU1BLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLFlBQVlBLEVBQUVBLEtBQUtBLEVBQUVBLElBQUlBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUV2RkEseUJBQU1BLENBQUNBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO2dCQUN4Q0EseUJBQU1BLENBQUNBLFFBQVFBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLElBQUlBLENBQUNBLENBQUNBO2dCQUM3Q0EseUJBQU1BLENBQUNBLFFBQVFBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDdkRBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxpRUFBaUVBLEVBQUVBO2dCQUNwRUEseUJBQU1BLENBQUNBO29CQUNMQSxlQUFRQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxJQUFJQSxlQUFRQSxDQUFDQSxNQUFNQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxZQUFZQSxFQUFFQSxLQUFLQSxFQUFFQSxJQUFJQSxFQUFDQSxDQUFDQSxFQUFFQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDMUZBLENBQUNBLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0Esa0RBQWtEQSxDQUFDQSxDQUFDQTtnQkFFeEVBLHlCQUFNQSxDQUFDQTtvQkFDTEEsZUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsRUFBRUEsSUFBSUEsZUFBUUEsQ0FBQ0EsTUFBTUEsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsWUFBWUEsRUFBRUEsS0FBS0EsRUFBRUEsSUFBSUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzFGQSxDQUFDQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLGtEQUFrREEsQ0FBQ0EsQ0FBQ0E7WUFDMUVBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxtQ0FBbUNBLEVBQUVBO2dCQUN0Q0EsSUFBSUEsU0FBU0EsR0FBR0EsZUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0E7b0JBQy9CQSxpQkFBVUEsQ0FBQ0EsY0FBTUEsT0FBQUEsTUFBTUEsRUFBTkEsQ0FBTUEsQ0FBQ0E7b0JBQ3hCQSxDQUFDQSxjQUFPQSxDQUFDQSxpQkFBVUEsQ0FBQ0EsY0FBTUEsT0FBQUEsWUFBWUEsRUFBWkEsQ0FBWUEsQ0FBQ0EsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsaUJBQVVBLENBQUNBLGNBQU1BLE9BQUFBLE1BQU1BLEVBQU5BLENBQU1BLENBQUNBLEVBQUNBLENBQUNBLENBQUNBO29CQUMvRUEsY0FBT0EsQ0FBQ0EsaUJBQVVBLENBQUNBLGNBQU1BLE9BQUFBLE1BQU1BLEVBQU5BLENBQU1BLENBQUNBLEVBQ3hCQSxFQUFDQSxVQUFVQSxFQUFFQSxjQUFNQSxPQUFBQSxJQUFJQSxFQUFKQSxDQUFJQSxFQUFFQSxJQUFJQSxFQUFFQSxDQUFDQSxpQkFBVUEsQ0FBQ0EsY0FBTUEsT0FBQUEsTUFBTUEsRUFBTkEsQ0FBTUEsQ0FBQ0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7aUJBQ3BFQSxDQUFDQSxDQUFDQTtnQkFFSEEsSUFBSUEsY0FBY0EsR0FBR0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ2xDQSxJQUFJQSxvQkFBb0JBLEdBQUdBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUN4Q0EsSUFBSUEsY0FBY0EsR0FBR0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRWxDQSx5QkFBTUEsQ0FBQ0EsY0FBY0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxFQUFFQSxZQUFZQSxNQUFNQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtnQkFDbkZBLHlCQUFNQSxDQUFDQSxvQkFBb0JBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsRUFBRUEsWUFBWUEsTUFBTUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3pGQSx5QkFBTUEsQ0FBQ0EsY0FBY0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxVQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUMzRkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDRFQUE0RUEsRUFBRUE7Z0JBQy9FQSxJQUFJQSxTQUFTQSxHQUFHQSxlQUFRQSxDQUFDQSxPQUFPQSxDQUFDQTtvQkFDL0JBLGNBQU9BLENBQUNBLE9BQU9BLEVBQ1BBO3dCQUNFQSxVQUFVQSxFQUFFQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxRQUFRQSxFQUFSQSxDQUFRQTt3QkFDM0JBLElBQUlBLEVBQUVBLENBQUNBLENBQUNBLElBQUlBLHFCQUFjQSxDQUFDQSxLQUFLQSxDQUFDQSxFQUFFQSxJQUFJQSx3QkFBd0JBLEVBQUVBLENBQUNBLENBQUNBO3FCQUNwRUEsQ0FBQ0E7aUJBQ1hBLENBQUNBLENBQUNBO2dCQUVIQSxJQUFJQSxRQUFRQSxHQUFHQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFNUJBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO2dCQUMvRUEseUJBQU1BLENBQUNBLFFBQVFBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0E7cUJBQzNEQSxPQUFPQSxDQUFDQSxDQUFDQSxJQUFJQSx3QkFBd0JBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO1lBQ2pEQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0Esc0RBQXNEQSxFQUFFQTtnQkFDekRBLElBQUlBLFFBQVFBLEdBQUdBLGVBQVFBLENBQUNBLE9BQU9BLENBQzNCQSxDQUFDQSxjQUFPQSxDQUFDQSxPQUFPQSxFQUFFQSxFQUFDQSxVQUFVQSxFQUFFQSxVQUFBQSxDQUFDQSxJQUFJQSxPQUFBQSxDQUFDQSxFQUFEQSxDQUFDQSxFQUFFQSxJQUFJQSxFQUFFQSxDQUFDQSxJQUFJQSxxQkFBY0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ2pGQSxJQUFJQSxjQUFjQSxHQUFHQSxlQUFRQSxDQUFDQSxPQUFPQSxDQUNqQ0EsQ0FBQ0EsY0FBT0EsQ0FBQ0EsT0FBT0EsRUFBRUEsRUFBQ0EsVUFBVUEsRUFBRUEsVUFBQUEsQ0FBQ0EsSUFBSUEsT0FBQUEsQ0FBQ0EsRUFBREEsQ0FBQ0EsRUFBRUEsSUFBSUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEscUJBQWNBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUNuRkEseUJBQU1BLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsS0FBS0EsQ0FBQ0E7cUJBQzdEQSxPQUFPQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO1lBQ2pGQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsYUFBYUEsRUFBRUE7WUFDdEJBLHFCQUFFQSxDQUFDQSxhQUFhQSxFQUFFQTtnQkFDaEJBLHlCQUFNQSxDQUFDQSxlQUFRQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLE1BQU1BLEVBQUVBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLFdBQVdBLENBQUNBO3FCQUNoRUEsT0FBT0EsQ0FBQ0EscURBQXFEQSxDQUFDQSxDQUFDQTtZQUN0RUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7QUFDTEEsQ0FBQ0E7QUF0bkJlLFlBQUksT0FzbkJuQixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtpc0JsYW5rLCBzdHJpbmdpZnl9IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvbGFuZyc7XG5pbXBvcnQge0Jhc2VFeGNlcHRpb24sIFdyYXBwZWRFeGNlcHRpb259IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvZXhjZXB0aW9ucyc7XG5pbXBvcnQge2Rlc2NyaWJlLCBkZGVzY3JpYmUsIGl0LCBpaXQsIGV4cGVjdCwgYmVmb3JlRWFjaH0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5pbXBvcnQge1NweURlcGVuZGVuY3lQcm92aWRlcn0gZnJvbSAnLi4vc3BpZXMnO1xuaW1wb3J0IHtcbiAgSW5qZWN0b3IsXG4gIHByb3ZpZGUsXG4gIFJlc29sdmVkUHJvdmlkZXIsXG4gIEtleSxcbiAgZm9yd2FyZFJlZixcbiAgSW5qZWN0YWJsZSxcbiAgSW5qZWN0TWV0YWRhdGEsXG4gIFNlbGZNZXRhZGF0YSxcbiAgSG9zdE1ldGFkYXRhLFxuICBTa2lwU2VsZk1ldGFkYXRhLFxuICBPcHRpb25hbCxcbiAgSW5qZWN0LFxuICBQcm92aWRlclxufSBmcm9tICdhbmd1bGFyMi9jb3JlJztcbmltcG9ydCB7RGVwZW5kZW5jeU1ldGFkYXRhfSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9kaS9tZXRhZGF0YSc7XG5pbXBvcnQge1Jlc29sdmVkUHJvdmlkZXJffSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9kaS9wcm92aWRlcic7XG5cbmltcG9ydCB7XG4gIEluamVjdG9ySW5saW5lU3RyYXRlZ3ksXG4gIEluamVjdG9yRHluYW1pY1N0cmF0ZWd5LFxuICBQcm90b0luamVjdG9yLFxuICBQcm92aWRlcldpdGhWaXNpYmlsaXR5LFxuICBWaXNpYmlsaXR5XG59IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2RpL2luamVjdG9yJztcblxuY2xhc3MgQ3VzdG9tRGVwZW5kZW5jeU1ldGFkYXRhIGV4dGVuZHMgRGVwZW5kZW5jeU1ldGFkYXRhIHt9XG5cbmNsYXNzIEVuZ2luZSB7fVxuXG5jbGFzcyBCcm9rZW5FbmdpbmUge1xuICBjb25zdHJ1Y3RvcigpIHsgdGhyb3cgbmV3IEJhc2VFeGNlcHRpb24oXCJCcm9rZW4gRW5naW5lXCIpOyB9XG59XG5cbmNsYXNzIERhc2hib2FyZFNvZnR3YXJlIHt9XG5cbkBJbmplY3RhYmxlKClcbmNsYXNzIERhc2hib2FyZCB7XG4gIGNvbnN0cnVjdG9yKHNvZnR3YXJlOiBEYXNoYm9hcmRTb2Z0d2FyZSkge31cbn1cblxuY2xhc3MgVHVyYm9FbmdpbmUgZXh0ZW5kcyBFbmdpbmUge31cblxuQEluamVjdGFibGUoKVxuY2xhc3MgQ2FyIHtcbiAgZW5naW5lOiBFbmdpbmU7XG4gIGNvbnN0cnVjdG9yKGVuZ2luZTogRW5naW5lKSB7IHRoaXMuZW5naW5lID0gZW5naW5lOyB9XG59XG5cbkBJbmplY3RhYmxlKClcbmNsYXNzIENhcldpdGhPcHRpb25hbEVuZ2luZSB7XG4gIGVuZ2luZTtcbiAgY29uc3RydWN0b3IoQE9wdGlvbmFsKCkgZW5naW5lOiBFbmdpbmUpIHsgdGhpcy5lbmdpbmUgPSBlbmdpbmU7IH1cbn1cblxuQEluamVjdGFibGUoKVxuY2xhc3MgQ2FyV2l0aERhc2hib2FyZCB7XG4gIGVuZ2luZTogRW5naW5lO1xuICBkYXNoYm9hcmQ6IERhc2hib2FyZDtcbiAgY29uc3RydWN0b3IoZW5naW5lOiBFbmdpbmUsIGRhc2hib2FyZDogRGFzaGJvYXJkKSB7XG4gICAgdGhpcy5lbmdpbmUgPSBlbmdpbmU7XG4gICAgdGhpcy5kYXNoYm9hcmQgPSBkYXNoYm9hcmQ7XG4gIH1cbn1cblxuQEluamVjdGFibGUoKVxuY2xhc3MgU3BvcnRzQ2FyIGV4dGVuZHMgQ2FyIHtcbiAgZW5naW5lOiBFbmdpbmU7XG4gIGNvbnN0cnVjdG9yKGVuZ2luZTogRW5naW5lKSB7IHN1cGVyKGVuZ2luZSk7IH1cbn1cblxuQEluamVjdGFibGUoKVxuY2xhc3MgQ2FyV2l0aEluamVjdCB7XG4gIGVuZ2luZTogRW5naW5lO1xuICBjb25zdHJ1Y3RvcihASW5qZWN0KFR1cmJvRW5naW5lKSBlbmdpbmU6IEVuZ2luZSkgeyB0aGlzLmVuZ2luZSA9IGVuZ2luZTsgfVxufVxuXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBDeWNsaWNFbmdpbmUge1xuICBjb25zdHJ1Y3RvcihjYXI6IENhcikge31cbn1cblxuY2xhc3MgTm9Bbm5vdGF0aW9ucyB7XG4gIGNvbnN0cnVjdG9yKHNlY3JldERlcGVuZGVuY3kpIHt9XG59XG5cbmZ1bmN0aW9uIGZhY3RvcnlGbihhKSB7fVxuXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpIHtcbiAgdmFyIGR5bmFtaWNQcm92aWRlcnMgPSBbXG4gICAgcHJvdmlkZSgncHJvdmlkZXIwJywge3VzZVZhbHVlOiAxfSksXG4gICAgcHJvdmlkZSgncHJvdmlkZXIxJywge3VzZVZhbHVlOiAxfSksXG4gICAgcHJvdmlkZSgncHJvdmlkZXIyJywge3VzZVZhbHVlOiAxfSksXG4gICAgcHJvdmlkZSgncHJvdmlkZXIzJywge3VzZVZhbHVlOiAxfSksXG4gICAgcHJvdmlkZSgncHJvdmlkZXI0Jywge3VzZVZhbHVlOiAxfSksXG4gICAgcHJvdmlkZSgncHJvdmlkZXI1Jywge3VzZVZhbHVlOiAxfSksXG4gICAgcHJvdmlkZSgncHJvdmlkZXI2Jywge3VzZVZhbHVlOiAxfSksXG4gICAgcHJvdmlkZSgncHJvdmlkZXI3Jywge3VzZVZhbHVlOiAxfSksXG4gICAgcHJvdmlkZSgncHJvdmlkZXI4Jywge3VzZVZhbHVlOiAxfSksXG4gICAgcHJvdmlkZSgncHJvdmlkZXI5Jywge3VzZVZhbHVlOiAxfSksXG4gICAgcHJvdmlkZSgncHJvdmlkZXIxMCcsIHt1c2VWYWx1ZTogMX0pXG4gIF07XG5cbiAgW3tzdHJhdGVneTogJ2lubGluZScsIHByb3ZpZGVyczogW10sIHN0cmF0ZWd5Q2xhc3M6IEluamVjdG9ySW5saW5lU3RyYXRlZ3l9LFxuICAge1xuICAgICBzdHJhdGVneTogJ2R5bmFtaWMnLFxuICAgICBwcm92aWRlcnM6IGR5bmFtaWNQcm92aWRlcnMsXG4gICAgIHN0cmF0ZWd5Q2xhc3M6IEluamVjdG9yRHluYW1pY1N0cmF0ZWd5XG4gICB9XS5mb3JFYWNoKChjb250ZXh0KSA9PiB7XG4gICAgZnVuY3Rpb24gY3JlYXRlSW5qZWN0b3IocHJvdmlkZXJzOiBhbnlbXSwgcGFyZW50OiBJbmplY3RvciA9IG51bGwsIGlzSG9zdDogYm9vbGVhbiA9IGZhbHNlKSB7XG4gICAgICByZXR1cm4gbmV3IEluamVjdG9yKFByb3RvSW5qZWN0b3IuZnJvbVJlc29sdmVkUHJvdmlkZXJzKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSW5qZWN0b3IucmVzb2x2ZShwcm92aWRlcnMuY29uY2F0KGNvbnRleHRbJ3Byb3ZpZGVycyddKSkpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJlbnQsIGlzSG9zdCk7XG4gICAgfVxuXG4gICAgZGVzY3JpYmUoYGluamVjdG9yICR7Y29udGV4dFsnc3RyYXRlZ3knXX1gLCAoKSA9PiB7XG4gICAgICBpdChcInNob3VsZCB1c2UgdGhlIHJpZ2h0IHN0cmF0ZWd5XCIsICgpID0+IHtcbiAgICAgICAgdmFyIGluamVjdG9yID0gY3JlYXRlSW5qZWN0b3IoW10pO1xuICAgICAgICBleHBlY3QoaW5qZWN0b3IuaW50ZXJuYWxTdHJhdGVneSkudG9CZUFuSW5zdGFuY2VPZihjb250ZXh0WydzdHJhdGVneUNsYXNzJ10pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgaW5zdGFudGlhdGUgYSBjbGFzcyB3aXRob3V0IGRlcGVuZGVuY2llcycsICgpID0+IHtcbiAgICAgICAgdmFyIGluamVjdG9yID0gY3JlYXRlSW5qZWN0b3IoW0VuZ2luZV0pO1xuICAgICAgICB2YXIgZW5naW5lID0gaW5qZWN0b3IuZ2V0KEVuZ2luZSk7XG5cbiAgICAgICAgZXhwZWN0KGVuZ2luZSkudG9CZUFuSW5zdGFuY2VPZihFbmdpbmUpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcmVzb2x2ZSBkZXBlbmRlbmNpZXMgYmFzZWQgb24gdHlwZSBpbmZvcm1hdGlvbicsICgpID0+IHtcbiAgICAgICAgdmFyIGluamVjdG9yID0gY3JlYXRlSW5qZWN0b3IoW0VuZ2luZSwgQ2FyXSk7XG4gICAgICAgIHZhciBjYXIgPSBpbmplY3Rvci5nZXQoQ2FyKTtcblxuICAgICAgICBleHBlY3QoY2FyKS50b0JlQW5JbnN0YW5jZU9mKENhcik7XG4gICAgICAgIGV4cGVjdChjYXIuZW5naW5lKS50b0JlQW5JbnN0YW5jZU9mKEVuZ2luZSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCByZXNvbHZlIGRlcGVuZGVuY2llcyBiYXNlZCBvbiBASW5qZWN0IGFubm90YXRpb24nLCAoKSA9PiB7XG4gICAgICAgIHZhciBpbmplY3RvciA9IGNyZWF0ZUluamVjdG9yKFtUdXJib0VuZ2luZSwgRW5naW5lLCBDYXJXaXRoSW5qZWN0XSk7XG4gICAgICAgIHZhciBjYXIgPSBpbmplY3Rvci5nZXQoQ2FyV2l0aEluamVjdCk7XG5cbiAgICAgICAgZXhwZWN0KGNhcikudG9CZUFuSW5zdGFuY2VPZihDYXJXaXRoSW5qZWN0KTtcbiAgICAgICAgZXhwZWN0KGNhci5lbmdpbmUpLnRvQmVBbkluc3RhbmNlT2YoVHVyYm9FbmdpbmUpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgdGhyb3cgd2hlbiBubyB0eXBlIGFuZCBub3QgQEluamVjdCAoY2xhc3MgY2FzZSknLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCgoKSA9PiBjcmVhdGVJbmplY3RvcihbTm9Bbm5vdGF0aW9uc10pKVxuICAgICAgICAgICAgLnRvVGhyb3dFcnJvcihcbiAgICAgICAgICAgICAgICBcIkNhbm5vdCByZXNvbHZlIGFsbCBwYXJhbWV0ZXJzIGZvciAnTm9Bbm5vdGF0aW9ucycoPykuIFwiICtcbiAgICAgICAgICAgICAgICAnTWFrZSBzdXJlIHRoYXQgYWxsIHRoZSBwYXJhbWV0ZXJzIGFyZSBkZWNvcmF0ZWQgd2l0aCBJbmplY3Qgb3IgaGF2ZSB2YWxpZCB0eXBlIGFubm90YXRpb25zICcgK1xuICAgICAgICAgICAgICAgIFwiYW5kIHRoYXQgJ05vQW5ub3RhdGlvbnMnIGlzIGRlY29yYXRlZCB3aXRoIEluamVjdGFibGUuXCIpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgdGhyb3cgd2hlbiBubyB0eXBlIGFuZCBub3QgQEluamVjdCAoZmFjdG9yeSBjYXNlKScsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KCgpID0+IGNyZWF0ZUluamVjdG9yKFtwcm92aWRlKFwic29tZVRva2VuXCIsIHt1c2VGYWN0b3J5OiBmYWN0b3J5Rm59KV0pKVxuICAgICAgICAgICAgLnRvVGhyb3dFcnJvcihcbiAgICAgICAgICAgICAgICBcIkNhbm5vdCByZXNvbHZlIGFsbCBwYXJhbWV0ZXJzIGZvciAnZmFjdG9yeUZuJyg/KS4gXCIgK1xuICAgICAgICAgICAgICAgICdNYWtlIHN1cmUgdGhhdCBhbGwgdGhlIHBhcmFtZXRlcnMgYXJlIGRlY29yYXRlZCB3aXRoIEluamVjdCBvciBoYXZlIHZhbGlkIHR5cGUgYW5ub3RhdGlvbnMgJyArXG4gICAgICAgICAgICAgICAgXCJhbmQgdGhhdCAnZmFjdG9yeUZuJyBpcyBkZWNvcmF0ZWQgd2l0aCBJbmplY3RhYmxlLlwiKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIGNhY2hlIGluc3RhbmNlcycsICgpID0+IHtcbiAgICAgICAgdmFyIGluamVjdG9yID0gY3JlYXRlSW5qZWN0b3IoW0VuZ2luZV0pO1xuXG4gICAgICAgIHZhciBlMSA9IGluamVjdG9yLmdldChFbmdpbmUpO1xuICAgICAgICB2YXIgZTIgPSBpbmplY3Rvci5nZXQoRW5naW5lKTtcblxuICAgICAgICBleHBlY3QoZTEpLnRvQmUoZTIpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcHJvdmlkZSB0byBhIHZhbHVlJywgKCkgPT4ge1xuICAgICAgICB2YXIgaW5qZWN0b3IgPSBjcmVhdGVJbmplY3RvcihbcHJvdmlkZShFbmdpbmUsIHt1c2VWYWx1ZTogXCJmYWtlIGVuZ2luZVwifSldKTtcblxuICAgICAgICB2YXIgZW5naW5lID0gaW5qZWN0b3IuZ2V0KEVuZ2luZSk7XG4gICAgICAgIGV4cGVjdChlbmdpbmUpLnRvRXF1YWwoXCJmYWtlIGVuZ2luZVwiKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHByb3ZpZGUgdG8gYSBmYWN0b3J5JywgKCkgPT4ge1xuICAgICAgICBmdW5jdGlvbiBzcG9ydHNDYXJGYWN0b3J5KGUpIHsgcmV0dXJuIG5ldyBTcG9ydHNDYXIoZSk7IH1cblxuICAgICAgICB2YXIgaW5qZWN0b3IgPVxuICAgICAgICAgICAgY3JlYXRlSW5qZWN0b3IoW0VuZ2luZSwgcHJvdmlkZShDYXIsIHt1c2VGYWN0b3J5OiBzcG9ydHNDYXJGYWN0b3J5LCBkZXBzOiBbRW5naW5lXX0pXSk7XG5cbiAgICAgICAgdmFyIGNhciA9IGluamVjdG9yLmdldChDYXIpO1xuICAgICAgICBleHBlY3QoY2FyKS50b0JlQW5JbnN0YW5jZU9mKFNwb3J0c0Nhcik7XG4gICAgICAgIGV4cGVjdChjYXIuZW5naW5lKS50b0JlQW5JbnN0YW5jZU9mKEVuZ2luZSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCB0aHJvdyB3aGVuIHVzaW5nIGEgZmFjdG9yeSB3aXRoIG1vcmUgdGhhbiAyMCBkZXBlbmRlbmNpZXMnLCAoKSA9PiB7XG4gICAgICAgIGZ1bmN0aW9uIGZhY3RvcnlXaXRoVG9vTWFueUFyZ3MoKSB7IHJldHVybiBuZXcgQ2FyKG51bGwpOyB9XG5cbiAgICAgICAgdmFyIGluamVjdG9yID0gY3JlYXRlSW5qZWN0b3IoW1xuICAgICAgICAgIEVuZ2luZSxcbiAgICAgICAgICBwcm92aWRlKENhcixcbiAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgdXNlRmFjdG9yeTogZmFjdG9yeVdpdGhUb29NYW55QXJncyxcbiAgICAgICAgICAgICAgICAgICAgZGVwczogW1xuICAgICAgICAgICAgICAgICAgICAgIEVuZ2luZSxcbiAgICAgICAgICAgICAgICAgICAgICBFbmdpbmUsXG4gICAgICAgICAgICAgICAgICAgICAgRW5naW5lLFxuICAgICAgICAgICAgICAgICAgICAgIEVuZ2luZSxcbiAgICAgICAgICAgICAgICAgICAgICBFbmdpbmUsXG4gICAgICAgICAgICAgICAgICAgICAgRW5naW5lLFxuICAgICAgICAgICAgICAgICAgICAgIEVuZ2luZSxcbiAgICAgICAgICAgICAgICAgICAgICBFbmdpbmUsXG4gICAgICAgICAgICAgICAgICAgICAgRW5naW5lLFxuICAgICAgICAgICAgICAgICAgICAgIEVuZ2luZSxcbiAgICAgICAgICAgICAgICAgICAgICBFbmdpbmUsXG4gICAgICAgICAgICAgICAgICAgICAgRW5naW5lLFxuICAgICAgICAgICAgICAgICAgICAgIEVuZ2luZSxcbiAgICAgICAgICAgICAgICAgICAgICBFbmdpbmUsXG4gICAgICAgICAgICAgICAgICAgICAgRW5naW5lLFxuICAgICAgICAgICAgICAgICAgICAgIEVuZ2luZSxcbiAgICAgICAgICAgICAgICAgICAgICBFbmdpbmUsXG4gICAgICAgICAgICAgICAgICAgICAgRW5naW5lLFxuICAgICAgICAgICAgICAgICAgICAgIEVuZ2luZSxcbiAgICAgICAgICAgICAgICAgICAgICBFbmdpbmUsXG4gICAgICAgICAgICAgICAgICAgICAgRW5naW5lXG4gICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgIF0pO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgaW5qZWN0b3IuZ2V0KENhcik7XG4gICAgICAgICAgdGhyb3cgXCJNdXN0IHRocm93XCI7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBleHBlY3QoZS5tZXNzYWdlKVxuICAgICAgICAgICAgICAudG9Db250YWluKGBDYW5ub3QgaW5zdGFudGlhdGUgJ0NhcicgYmVjYXVzZSBpdCBoYXMgbW9yZSB0aGFuIDIwIGRlcGVuZGVuY2llc2ApO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0aW5nIHByb3ZpZGVyIHRvIG51bGwnLCAoKSA9PiB7XG4gICAgICAgIHZhciBpbmplY3RvciA9IGNyZWF0ZUluamVjdG9yKFtwcm92aWRlKEVuZ2luZSwge3VzZVZhbHVlOiBudWxsfSldKTtcbiAgICAgICAgdmFyIGVuZ2luZSA9IGluamVjdG9yLmdldChFbmdpbmUpO1xuICAgICAgICBleHBlY3QoZW5naW5lKS50b0JlTnVsbCgpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcHJvdmlkZSB0byBhbiBhbGlhcycsICgpID0+IHtcbiAgICAgICAgdmFyIGluamVjdG9yID0gY3JlYXRlSW5qZWN0b3IoW1xuICAgICAgICAgIEVuZ2luZSxcbiAgICAgICAgICBwcm92aWRlKFNwb3J0c0Nhciwge3VzZUNsYXNzOiBTcG9ydHNDYXJ9KSxcbiAgICAgICAgICBwcm92aWRlKENhciwge3VzZUV4aXN0aW5nOiBTcG9ydHNDYXJ9KVxuICAgICAgICBdKTtcblxuICAgICAgICB2YXIgY2FyID0gaW5qZWN0b3IuZ2V0KENhcik7XG4gICAgICAgIHZhciBzcG9ydHNDYXIgPSBpbmplY3Rvci5nZXQoU3BvcnRzQ2FyKTtcbiAgICAgICAgZXhwZWN0KGNhcikudG9CZUFuSW5zdGFuY2VPZihTcG9ydHNDYXIpO1xuICAgICAgICBleHBlY3QoY2FyKS50b0JlKHNwb3J0c0Nhcik7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IG11bHRpUHJvdmlkZXJzJywgKCkgPT4ge1xuICAgICAgICB2YXIgaW5qZWN0b3IgPSBjcmVhdGVJbmplY3RvcihbXG4gICAgICAgICAgRW5naW5lLFxuICAgICAgICAgIG5ldyBQcm92aWRlcihDYXIsIHt1c2VDbGFzczogU3BvcnRzQ2FyLCBtdWx0aTogdHJ1ZX0pLFxuICAgICAgICAgIG5ldyBQcm92aWRlcihDYXIsIHt1c2VDbGFzczogQ2FyV2l0aE9wdGlvbmFsRW5naW5lLCBtdWx0aTogdHJ1ZX0pXG4gICAgICAgIF0pO1xuXG4gICAgICAgIHZhciBjYXJzID0gaW5qZWN0b3IuZ2V0KENhcik7XG4gICAgICAgIGV4cGVjdChjYXJzLmxlbmd0aCkudG9FcXVhbCgyKTtcbiAgICAgICAgZXhwZWN0KGNhcnNbMF0pLnRvQmVBbkluc3RhbmNlT2YoU3BvcnRzQ2FyKTtcbiAgICAgICAgZXhwZWN0KGNhcnNbMV0pLnRvQmVBbkluc3RhbmNlT2YoQ2FyV2l0aE9wdGlvbmFsRW5naW5lKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHN1cHBvcnQgbXVsdGlQcm92aWRlcnMgdGhhdCBhcmUgY3JlYXRlZCB1c2luZyB1c2VFeGlzdGluZycsICgpID0+IHtcbiAgICAgICAgdmFyIGluamVjdG9yID0gY3JlYXRlSW5qZWN0b3IoXG4gICAgICAgICAgICBbRW5naW5lLCBTcG9ydHNDYXIsIG5ldyBQcm92aWRlcihDYXIsIHt1c2VFeGlzdGluZzogU3BvcnRzQ2FyLCBtdWx0aTogdHJ1ZX0pXSk7XG5cbiAgICAgICAgdmFyIGNhcnMgPSBpbmplY3Rvci5nZXQoQ2FyKTtcbiAgICAgICAgZXhwZWN0KGNhcnMubGVuZ3RoKS50b0VxdWFsKDEpO1xuICAgICAgICBleHBlY3QoY2Fyc1swXSkudG9CZShpbmplY3Rvci5nZXQoU3BvcnRzQ2FyKSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCB0aHJvdyB3aGVuIHRoZSBhbGlhc2VkIHByb3ZpZGVyIGRvZXMgbm90IGV4aXN0JywgKCkgPT4ge1xuICAgICAgICB2YXIgaW5qZWN0b3IgPSBjcmVhdGVJbmplY3RvcihbcHJvdmlkZSgnY2FyJywge3VzZUV4aXN0aW5nOiBTcG9ydHNDYXJ9KV0pO1xuICAgICAgICB2YXIgZSA9IGBObyBwcm92aWRlciBmb3IgJHtzdHJpbmdpZnkoU3BvcnRzQ2FyKX0hIChjYXIgLT4gJHtzdHJpbmdpZnkoU3BvcnRzQ2FyKX0pYDtcbiAgICAgICAgZXhwZWN0KCgpID0+IGluamVjdG9yLmdldCgnY2FyJykpLnRvVGhyb3dFcnJvcihlKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIGhhbmRsZSBmb3J3YXJkUmVmIGluIHVzZUV4aXN0aW5nJywgKCkgPT4ge1xuICAgICAgICB2YXIgaW5qZWN0b3IgPSBjcmVhdGVJbmplY3RvcihbXG4gICAgICAgICAgcHJvdmlkZSgnb3JpZ2luYWxFbmdpbmUnLCB7dXNlQ2xhc3M6IGZvcndhcmRSZWYoKCkgPT4gRW5naW5lKX0pLFxuICAgICAgICAgIHByb3ZpZGUoJ2FsaWFzZWRFbmdpbmUnLCB7dXNlRXhpc3Rpbmc6PGFueT5mb3J3YXJkUmVmKCgpID0+ICdvcmlnaW5hbEVuZ2luZScpfSlcbiAgICAgICAgXSk7XG4gICAgICAgIGV4cGVjdChpbmplY3Rvci5nZXQoJ2FsaWFzZWRFbmdpbmUnKSkudG9CZUFuSW5zdGFuY2VPZihFbmdpbmUpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCBvdmVycmlkaW5nIGZhY3RvcnkgZGVwZW5kZW5jaWVzJywgKCkgPT4ge1xuICAgICAgICB2YXIgaW5qZWN0b3IgPSBjcmVhdGVJbmplY3RvcihcbiAgICAgICAgICAgIFtFbmdpbmUsIHByb3ZpZGUoQ2FyLCB7dXNlRmFjdG9yeTogKGUpID0+IG5ldyBTcG9ydHNDYXIoZSksIGRlcHM6IFtFbmdpbmVdfSldKTtcblxuICAgICAgICB2YXIgY2FyID0gaW5qZWN0b3IuZ2V0KENhcik7XG4gICAgICAgIGV4cGVjdChjYXIpLnRvQmVBbkluc3RhbmNlT2YoU3BvcnRzQ2FyKTtcbiAgICAgICAgZXhwZWN0KGNhci5lbmdpbmUpLnRvQmVBbkluc3RhbmNlT2YoRW5naW5lKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHN1cHBvcnQgb3B0aW9uYWwgZGVwZW5kZW5jaWVzJywgKCkgPT4ge1xuICAgICAgICB2YXIgaW5qZWN0b3IgPSBjcmVhdGVJbmplY3RvcihbQ2FyV2l0aE9wdGlvbmFsRW5naW5lXSk7XG5cbiAgICAgICAgdmFyIGNhciA9IGluamVjdG9yLmdldChDYXJXaXRoT3B0aW9uYWxFbmdpbmUpO1xuICAgICAgICBleHBlY3QoY2FyLmVuZ2luZSkudG9FcXVhbChudWxsKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdChcInNob3VsZCBmbGF0dGVuIHBhc3NlZC1pbiBwcm92aWRlcnNcIiwgKCkgPT4ge1xuICAgICAgICB2YXIgaW5qZWN0b3IgPSBjcmVhdGVJbmplY3RvcihbW1tFbmdpbmUsIENhcl1dXSk7XG5cbiAgICAgICAgdmFyIGNhciA9IGluamVjdG9yLmdldChDYXIpO1xuICAgICAgICBleHBlY3QoY2FyKS50b0JlQW5JbnN0YW5jZU9mKENhcik7XG4gICAgICB9KTtcblxuICAgICAgaXQoXCJzaG91bGQgdXNlIHRoZSBsYXN0IHByb3ZpZGVyIHdoZW4gdGhlcmUgYXJlIG11bHRpcGxlIHByb3ZpZGVycyBmb3Igc2FtZSB0b2tlblwiLCAoKSA9PiB7XG4gICAgICAgIHZhciBpbmplY3RvciA9IGNyZWF0ZUluamVjdG9yKFxuICAgICAgICAgICAgW3Byb3ZpZGUoRW5naW5lLCB7dXNlQ2xhc3M6IEVuZ2luZX0pLCBwcm92aWRlKEVuZ2luZSwge3VzZUNsYXNzOiBUdXJib0VuZ2luZX0pXSk7XG5cbiAgICAgICAgZXhwZWN0KGluamVjdG9yLmdldChFbmdpbmUpKS50b0JlQW5JbnN0YW5jZU9mKFR1cmJvRW5naW5lKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHVzZSBub24tdHlwZSB0b2tlbnMnLCAoKSA9PiB7XG4gICAgICAgIHZhciBpbmplY3RvciA9IGNyZWF0ZUluamVjdG9yKFtwcm92aWRlKCd0b2tlbicsIHt1c2VWYWx1ZTogJ3ZhbHVlJ30pXSk7XG5cbiAgICAgICAgZXhwZWN0KGluamVjdG9yLmdldCgndG9rZW4nKSkudG9FcXVhbCgndmFsdWUnKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHRocm93IHdoZW4gZ2l2ZW4gaW52YWxpZCBwcm92aWRlcnMnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCgoKSA9PiBjcmVhdGVJbmplY3Rvcig8YW55PltcImJsYWhcIl0pKVxuICAgICAgICAgICAgLnRvVGhyb3dFcnJvcihcbiAgICAgICAgICAgICAgICAnSW52YWxpZCBwcm92aWRlciAtIG9ubHkgaW5zdGFuY2VzIG9mIFByb3ZpZGVyIGFuZCBUeXBlIGFyZSBhbGxvd2VkLCBnb3Q6IGJsYWgnKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHByb3ZpZGUgaXRzZWxmJywgKCkgPT4ge1xuICAgICAgICB2YXIgcGFyZW50ID0gY3JlYXRlSW5qZWN0b3IoW10pO1xuICAgICAgICB2YXIgY2hpbGQgPSBwYXJlbnQucmVzb2x2ZUFuZENyZWF0ZUNoaWxkKFtdKTtcblxuICAgICAgICBleHBlY3QoY2hpbGQuZ2V0KEluamVjdG9yKSkudG9CZShjaGlsZCk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCB0aHJvdyB3aGVuIG5vIHByb3ZpZGVyIGRlZmluZWQnLCAoKSA9PiB7XG4gICAgICAgIHZhciBpbmplY3RvciA9IGNyZWF0ZUluamVjdG9yKFtdKTtcbiAgICAgICAgZXhwZWN0KCgpID0+IGluamVjdG9yLmdldCgnTm9uRXhpc3RpbmcnKSkudG9UaHJvd0Vycm9yKCdObyBwcm92aWRlciBmb3IgTm9uRXhpc3RpbmchJyk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBzaG93IHRoZSBmdWxsIHBhdGggd2hlbiBubyBwcm92aWRlcicsICgpID0+IHtcbiAgICAgICAgdmFyIGluamVjdG9yID0gY3JlYXRlSW5qZWN0b3IoW0NhcldpdGhEYXNoYm9hcmQsIEVuZ2luZSwgRGFzaGJvYXJkXSk7XG4gICAgICAgIGV4cGVjdCgoKSA9PiBpbmplY3Rvci5nZXQoQ2FyV2l0aERhc2hib2FyZCkpXG4gICAgICAgICAgICAudG9UaHJvd0Vycm9yKFxuICAgICAgICAgICAgICAgIGBObyBwcm92aWRlciBmb3IgRGFzaGJvYXJkU29mdHdhcmUhICgke3N0cmluZ2lmeShDYXJXaXRoRGFzaGJvYXJkKX0gLT4gJHtzdHJpbmdpZnkoRGFzaGJvYXJkKX0gLT4gRGFzaGJvYXJkU29mdHdhcmUpYCk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCB0aHJvdyB3aGVuIHRyeWluZyB0byBpbnN0YW50aWF0ZSBhIGN5Y2xpYyBkZXBlbmRlbmN5JywgKCkgPT4ge1xuICAgICAgICB2YXIgaW5qZWN0b3IgPSBjcmVhdGVJbmplY3RvcihbQ2FyLCBwcm92aWRlKEVuZ2luZSwge3VzZUNsYXNzOiBDeWNsaWNFbmdpbmV9KV0pO1xuXG4gICAgICAgIGV4cGVjdCgoKSA9PiBpbmplY3Rvci5nZXQoQ2FyKSlcbiAgICAgICAgICAgIC50b1Rocm93RXJyb3IoXG4gICAgICAgICAgICAgICAgYENhbm5vdCBpbnN0YW50aWF0ZSBjeWNsaWMgZGVwZW5kZW5jeSEgKCR7c3RyaW5naWZ5KENhcil9IC0+ICR7c3RyaW5naWZ5KEVuZ2luZSl9IC0+ICR7c3RyaW5naWZ5KENhcil9KWApO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc2hvdyB0aGUgZnVsbCBwYXRoIHdoZW4gZXJyb3IgaGFwcGVucyBpbiBhIGNvbnN0cnVjdG9yJywgKCkgPT4ge1xuICAgICAgICB2YXIgcHJvdmlkZXJzID0gSW5qZWN0b3IucmVzb2x2ZShbQ2FyLCBwcm92aWRlKEVuZ2luZSwge3VzZUNsYXNzOiBCcm9rZW5FbmdpbmV9KV0pO1xuICAgICAgICB2YXIgcHJvdG8gPSBuZXcgUHJvdG9JbmplY3RvcihbXG4gICAgICAgICAgbmV3IFByb3ZpZGVyV2l0aFZpc2liaWxpdHkocHJvdmlkZXJzWzBdLCBWaXNpYmlsaXR5LlB1YmxpYyksXG4gICAgICAgICAgbmV3IFByb3ZpZGVyV2l0aFZpc2liaWxpdHkocHJvdmlkZXJzWzFdLCBWaXNpYmlsaXR5LlB1YmxpYylcbiAgICAgICAgXSk7XG4gICAgICAgIHZhciBpbmplY3RvciA9IG5ldyBJbmplY3Rvcihwcm90byk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBpbmplY3Rvci5nZXQoQ2FyKTtcbiAgICAgICAgICB0aHJvdyBcIk11c3QgdGhyb3dcIjtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIGV4cGVjdChlLm1lc3NhZ2UpXG4gICAgICAgICAgICAgIC50b0NvbnRhaW4oYEVycm9yIGR1cmluZyBpbnN0YW50aWF0aW9uIG9mIEVuZ2luZSEgKCR7c3RyaW5naWZ5KENhcil9IC0+IEVuZ2luZSlgKTtcbiAgICAgICAgICBleHBlY3QoZS5vcmlnaW5hbEV4Y2VwdGlvbiBpbnN0YW5jZW9mIEJhc2VFeGNlcHRpb24pLnRvQmVUcnV0aHkoKTtcbiAgICAgICAgICBleHBlY3QoZS5jYXVzZUtleS50b2tlbikudG9FcXVhbChFbmdpbmUpO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBwcm92aWRlIGNvbnRleHQgd2hlbiB0aHJvd2luZyBhbiBleGNlcHRpb24gJywgKCkgPT4ge1xuICAgICAgICB2YXIgZW5naW5lUHJvdmlkZXIgPSBJbmplY3Rvci5yZXNvbHZlKFtwcm92aWRlKEVuZ2luZSwge3VzZUNsYXNzOiBCcm9rZW5FbmdpbmV9KV0pWzBdO1xuICAgICAgICB2YXIgcHJvdG9QYXJlbnQgPVxuICAgICAgICAgICAgbmV3IFByb3RvSW5qZWN0b3IoW25ldyBQcm92aWRlcldpdGhWaXNpYmlsaXR5KGVuZ2luZVByb3ZpZGVyLCBWaXNpYmlsaXR5LlB1YmxpYyldKTtcblxuICAgICAgICB2YXIgY2FyUHJvdmlkZXIgPSBJbmplY3Rvci5yZXNvbHZlKFtDYXJdKVswXTtcbiAgICAgICAgdmFyIHByb3RvQ2hpbGQgPVxuICAgICAgICAgICAgbmV3IFByb3RvSW5qZWN0b3IoW25ldyBQcm92aWRlcldpdGhWaXNpYmlsaXR5KGNhclByb3ZpZGVyLCBWaXNpYmlsaXR5LlB1YmxpYyldKTtcblxuICAgICAgICB2YXIgcGFyZW50ID0gbmV3IEluamVjdG9yKHByb3RvUGFyZW50LCBudWxsLCBmYWxzZSwgbnVsbCwgKCkgPT4gXCJwYXJlbnRDb250ZXh0XCIpO1xuICAgICAgICB2YXIgY2hpbGQgPSBuZXcgSW5qZWN0b3IocHJvdG9DaGlsZCwgcGFyZW50LCBmYWxzZSwgbnVsbCwgKCkgPT4gXCJjaGlsZENvbnRleHRcIik7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjaGlsZC5nZXQoQ2FyKTtcbiAgICAgICAgICB0aHJvdyBcIk11c3QgdGhyb3dcIjtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIGV4cGVjdChlLmNvbnRleHQpLnRvRXF1YWwoXCJjaGlsZENvbnRleHRcIik7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIGluc3RhbnRpYXRlIGFuIG9iamVjdCBhZnRlciBhIGZhaWxlZCBhdHRlbXB0JywgKCkgPT4ge1xuICAgICAgICB2YXIgaXNCcm9rZW4gPSB0cnVlO1xuXG4gICAgICAgIHZhciBpbmplY3RvciA9IGNyZWF0ZUluamVjdG9yKFtcbiAgICAgICAgICBDYXIsXG4gICAgICAgICAgcHJvdmlkZShFbmdpbmUsIHt1c2VGYWN0b3J5OiAoKCkgPT4gaXNCcm9rZW4gPyBuZXcgQnJva2VuRW5naW5lKCkgOiBuZXcgRW5naW5lKCkpfSlcbiAgICAgICAgXSk7XG5cbiAgICAgICAgZXhwZWN0KCgpID0+IGluamVjdG9yLmdldChDYXIpKS50b1Rocm93RXJyb3IobmV3IFJlZ0V4cChcIkVycm9yXCIpKTtcblxuICAgICAgICBpc0Jyb2tlbiA9IGZhbHNlO1xuXG4gICAgICAgIGV4cGVjdChpbmplY3Rvci5nZXQoQ2FyKSkudG9CZUFuSW5zdGFuY2VPZihDYXIpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCBudWxsIHZhbHVlcycsICgpID0+IHtcbiAgICAgICAgdmFyIGluamVjdG9yID0gY3JlYXRlSW5qZWN0b3IoW3Byb3ZpZGUoJ251bGwnLCB7dXNlVmFsdWU6IG51bGx9KV0pO1xuICAgICAgICBleHBlY3QoaW5qZWN0b3IuZ2V0KCdudWxsJykpLnRvQmUobnVsbCk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCB1c2UgY3VzdG9tIGRlcGVuZGVuY3kgcHJvdmlkZXInLCAoKSA9PiB7XG4gICAgICAgIHZhciBlID0gbmV3IEVuZ2luZSgpO1xuXG4gICAgICAgIHZhciBkZXBQcm92aWRlciA9IDxhbnk+bmV3IFNweURlcGVuZGVuY3lQcm92aWRlcigpO1xuICAgICAgICBkZXBQcm92aWRlci5zcHkoXCJnZXREZXBlbmRlbmN5XCIpLmFuZFJldHVybihlKTtcblxuICAgICAgICB2YXIgcHJvdmlkZXJzID0gSW5qZWN0b3IucmVzb2x2ZShbQ2FyXSk7XG4gICAgICAgIHZhciBwcm90byA9XG4gICAgICAgICAgICBuZXcgUHJvdG9JbmplY3RvcihbbmV3IFByb3ZpZGVyV2l0aFZpc2liaWxpdHkocHJvdmlkZXJzWzBdLCBWaXNpYmlsaXR5LlB1YmxpYyldKTtcbiAgICAgICAgdmFyIGluamVjdG9yID0gbmV3IEluamVjdG9yKHByb3RvLCBudWxsLCBmYWxzZSwgZGVwUHJvdmlkZXIpO1xuXG4gICAgICAgIGV4cGVjdChpbmplY3Rvci5nZXQoQ2FyKS5lbmdpbmUpLnRvRXF1YWwoZSk7XG4gICAgICAgIGV4cGVjdChkZXBQcm92aWRlci5zcHkoXCJnZXREZXBlbmRlbmN5XCIpKVxuICAgICAgICAgICAgLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKGluamVjdG9yLCBwcm92aWRlcnNbMF0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvdmlkZXJzWzBdLnJlc29sdmVkRmFjdG9yaWVzWzBdLmRlcGVuZGVuY2llc1swXSk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuXG4gICAgZGVzY3JpYmUoXCJjaGlsZFwiLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIGxvYWQgaW5zdGFuY2VzIGZyb20gcGFyZW50IGluamVjdG9yJywgKCkgPT4ge1xuICAgICAgICB2YXIgcGFyZW50ID0gSW5qZWN0b3IucmVzb2x2ZUFuZENyZWF0ZShbRW5naW5lXSk7XG4gICAgICAgIHZhciBjaGlsZCA9IHBhcmVudC5yZXNvbHZlQW5kQ3JlYXRlQ2hpbGQoW10pO1xuXG4gICAgICAgIHZhciBlbmdpbmVGcm9tUGFyZW50ID0gcGFyZW50LmdldChFbmdpbmUpO1xuICAgICAgICB2YXIgZW5naW5lRnJvbUNoaWxkID0gY2hpbGQuZ2V0KEVuZ2luZSk7XG5cbiAgICAgICAgZXhwZWN0KGVuZ2luZUZyb21DaGlsZCkudG9CZShlbmdpbmVGcm9tUGFyZW50KTtcbiAgICAgIH0pO1xuXG4gICAgICBpdChcInNob3VsZCBub3QgdXNlIHRoZSBjaGlsZCBwcm92aWRlcnMgd2hlbiByZXNvbHZpbmcgdGhlIGRlcGVuZGVuY2llcyBvZiBhIHBhcmVudCBwcm92aWRlclwiLFxuICAgICAgICAgKCkgPT4ge1xuICAgICAgICAgICB2YXIgcGFyZW50ID0gSW5qZWN0b3IucmVzb2x2ZUFuZENyZWF0ZShbQ2FyLCBFbmdpbmVdKTtcbiAgICAgICAgICAgdmFyIGNoaWxkID0gcGFyZW50LnJlc29sdmVBbmRDcmVhdGVDaGlsZChbcHJvdmlkZShFbmdpbmUsIHt1c2VDbGFzczogVHVyYm9FbmdpbmV9KV0pO1xuXG4gICAgICAgICAgIHZhciBjYXJGcm9tQ2hpbGQgPSBjaGlsZC5nZXQoQ2FyKTtcbiAgICAgICAgICAgZXhwZWN0KGNhckZyb21DaGlsZC5lbmdpbmUpLnRvQmVBbkluc3RhbmNlT2YoRW5naW5lKTtcbiAgICAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIGNyZWF0ZSBuZXcgaW5zdGFuY2UgaW4gYSBjaGlsZCBpbmplY3RvcicsICgpID0+IHtcbiAgICAgICAgdmFyIHBhcmVudCA9IEluamVjdG9yLnJlc29sdmVBbmRDcmVhdGUoW0VuZ2luZV0pO1xuICAgICAgICB2YXIgY2hpbGQgPSBwYXJlbnQucmVzb2x2ZUFuZENyZWF0ZUNoaWxkKFtwcm92aWRlKEVuZ2luZSwge3VzZUNsYXNzOiBUdXJib0VuZ2luZX0pXSk7XG5cbiAgICAgICAgdmFyIGVuZ2luZUZyb21QYXJlbnQgPSBwYXJlbnQuZ2V0KEVuZ2luZSk7XG4gICAgICAgIHZhciBlbmdpbmVGcm9tQ2hpbGQgPSBjaGlsZC5nZXQoRW5naW5lKTtcblxuICAgICAgICBleHBlY3QoZW5naW5lRnJvbVBhcmVudCkubm90LnRvQmUoZW5naW5lRnJvbUNoaWxkKTtcbiAgICAgICAgZXhwZWN0KGVuZ2luZUZyb21DaGlsZCkudG9CZUFuSW5zdGFuY2VPZihUdXJib0VuZ2luZSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoXCJzaG91bGQgZ2l2ZSBhY2Nlc3MgdG8gcGFyZW50XCIsICgpID0+IHtcbiAgICAgICAgdmFyIHBhcmVudCA9IEluamVjdG9yLnJlc29sdmVBbmRDcmVhdGUoW10pO1xuICAgICAgICB2YXIgY2hpbGQgPSBwYXJlbnQucmVzb2x2ZUFuZENyZWF0ZUNoaWxkKFtdKTtcbiAgICAgICAgZXhwZWN0KGNoaWxkLnBhcmVudCkudG9CZShwYXJlbnQpO1xuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICBkZXNjcmliZSgncmVzb2x2ZUFuZEluc3RhbnRpYXRlJywgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCBpbnN0YW50aWF0ZSBhbiBvYmplY3QgaW4gdGhlIGNvbnRleHQgb2YgdGhlIGluamVjdG9yJywgKCkgPT4ge1xuICAgICAgICB2YXIgaW5qID0gSW5qZWN0b3IucmVzb2x2ZUFuZENyZWF0ZShbRW5naW5lXSk7XG4gICAgICAgIHZhciBjYXIgPSBpbmoucmVzb2x2ZUFuZEluc3RhbnRpYXRlKENhcik7XG4gICAgICAgIGV4cGVjdChjYXIpLnRvQmVBbkluc3RhbmNlT2YoQ2FyKTtcbiAgICAgICAgZXhwZWN0KGNhci5lbmdpbmUpLnRvQmUoaW5qLmdldChFbmdpbmUpKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIG5vdCBzdG9yZSB0aGUgaW5zdGFudGlhdGVkIG9iamVjdCBpbiB0aGUgaW5qZWN0b3InLCAoKSA9PiB7XG4gICAgICAgIHZhciBpbmogPSBJbmplY3Rvci5yZXNvbHZlQW5kQ3JlYXRlKFtFbmdpbmVdKTtcbiAgICAgICAgaW5qLnJlc29sdmVBbmRJbnN0YW50aWF0ZShDYXIpO1xuICAgICAgICBleHBlY3QoKCkgPT4gaW5qLmdldChDYXIpKS50b1Rocm93RXJyb3IoKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ2luc3RhbnRpYXRlJywgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCBpbnN0YW50aWF0ZSBhbiBvYmplY3QgaW4gdGhlIGNvbnRleHQgb2YgdGhlIGluamVjdG9yJywgKCkgPT4ge1xuICAgICAgICB2YXIgaW5qID0gSW5qZWN0b3IucmVzb2x2ZUFuZENyZWF0ZShbRW5naW5lXSk7XG4gICAgICAgIHZhciBjYXIgPSBpbmouaW5zdGFudGlhdGVSZXNvbHZlZChJbmplY3Rvci5yZXNvbHZlKFtDYXJdKVswXSk7XG4gICAgICAgIGV4cGVjdChjYXIpLnRvQmVBbkluc3RhbmNlT2YoQ2FyKTtcbiAgICAgICAgZXhwZWN0KGNhci5lbmdpbmUpLnRvQmUoaW5qLmdldChFbmdpbmUpKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoXCJkZXBlZGVuY3kgcmVzb2x1dGlvblwiLCAoKSA9PiB7XG4gICAgICBkZXNjcmliZShcIkBTZWxmKClcIiwgKCkgPT4ge1xuICAgICAgICBpdChcInNob3VsZCByZXR1cm4gYSBkZXBlbmRlbmN5IGZyb20gc2VsZlwiLCAoKSA9PiB7XG4gICAgICAgICAgdmFyIGluaiA9IEluamVjdG9yLnJlc29sdmVBbmRDcmVhdGUoW1xuICAgICAgICAgICAgRW5naW5lLFxuICAgICAgICAgICAgcHJvdmlkZShDYXIsIHt1c2VGYWN0b3J5OiAoZSkgPT4gbmV3IENhcihlKSwgZGVwczogW1tFbmdpbmUsIG5ldyBTZWxmTWV0YWRhdGEoKV1dfSlcbiAgICAgICAgICBdKTtcblxuICAgICAgICAgIGV4cGVjdChpbmouZ2V0KENhcikpLnRvQmVBbkluc3RhbmNlT2YoQ2FyKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaXQoXCJzaG91bGQgdGhyb3cgd2hlbiBub3QgcmVxdWVzdGVkIHByb3ZpZGVyIG9uIHNlbGZcIiwgKCkgPT4ge1xuICAgICAgICAgIHZhciBwYXJlbnQgPSBJbmplY3Rvci5yZXNvbHZlQW5kQ3JlYXRlKFtFbmdpbmVdKTtcbiAgICAgICAgICB2YXIgY2hpbGQgPSBwYXJlbnQucmVzb2x2ZUFuZENyZWF0ZUNoaWxkKFtcbiAgICAgICAgICAgIHByb3ZpZGUoQ2FyLCB7dXNlRmFjdG9yeTogKGUpID0+IG5ldyBDYXIoZSksIGRlcHM6IFtbRW5naW5lLCBuZXcgU2VsZk1ldGFkYXRhKCldXX0pXG4gICAgICAgICAgXSk7XG5cbiAgICAgICAgICBleHBlY3QoKCkgPT4gY2hpbGQuZ2V0KENhcikpXG4gICAgICAgICAgICAgIC50b1Rocm93RXJyb3IoYE5vIHByb3ZpZGVyIGZvciBFbmdpbmUhICgke3N0cmluZ2lmeShDYXIpfSAtPiAke3N0cmluZ2lmeShFbmdpbmUpfSlgKTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcblxuICAgICAgZGVzY3JpYmUoXCJASG9zdCgpXCIsICgpID0+IHtcbiAgICAgICAgaXQoXCJzaG91bGQgcmV0dXJuIGEgZGVwZW5kZW5jeSBmcm9tIHNhbWUgaG9zdFwiLCAoKSA9PiB7XG4gICAgICAgICAgdmFyIHBhcmVudCA9IEluamVjdG9yLnJlc29sdmVBbmRDcmVhdGUoW0VuZ2luZV0pO1xuICAgICAgICAgIHZhciBjaGlsZCA9IHBhcmVudC5yZXNvbHZlQW5kQ3JlYXRlQ2hpbGQoW1xuICAgICAgICAgICAgcHJvdmlkZShDYXIsIHt1c2VGYWN0b3J5OiAoZSkgPT4gbmV3IENhcihlKSwgZGVwczogW1tFbmdpbmUsIG5ldyBIb3N0TWV0YWRhdGEoKV1dfSlcbiAgICAgICAgICBdKTtcblxuICAgICAgICAgIGV4cGVjdChjaGlsZC5nZXQoQ2FyKSkudG9CZUFuSW5zdGFuY2VPZihDYXIpO1xuICAgICAgICB9KTtcblxuICAgICAgICBpdChcInNob3VsZCByZXR1cm4gYSBwcml2YXRlIGRlcGVuZGVuY3kgZGVjbGFyZWQgYXQgdGhlIGhvc3RcIiwgKCkgPT4ge1xuICAgICAgICAgIHZhciBlbmdpbmUgPSBJbmplY3Rvci5yZXNvbHZlKFtFbmdpbmVdKVswXTtcbiAgICAgICAgICB2YXIgcHJvdG9QYXJlbnQgPVxuICAgICAgICAgICAgICBuZXcgUHJvdG9JbmplY3RvcihbbmV3IFByb3ZpZGVyV2l0aFZpc2liaWxpdHkoZW5naW5lLCBWaXNpYmlsaXR5LlByaXZhdGUpXSk7XG4gICAgICAgICAgdmFyIHBhcmVudCA9IG5ldyBJbmplY3Rvcihwcm90b1BhcmVudCk7XG5cbiAgICAgICAgICB2YXIgY2hpbGQgPSBjcmVhdGVJbmplY3RvcihcbiAgICAgICAgICAgICAgW3Byb3ZpZGUoQ2FyLCB7dXNlRmFjdG9yeTogKGUpID0+IG5ldyBDYXIoZSksIGRlcHM6IFtbRW5naW5lLCBuZXcgSG9zdE1ldGFkYXRhKCldXX0pXSxcbiAgICAgICAgICAgICAgcGFyZW50LCB0cnVlKTsgIC8vIGhvc3RcblxuICAgICAgICAgIGV4cGVjdChjaGlsZC5nZXQoQ2FyKSkudG9CZUFuSW5zdGFuY2VPZihDYXIpO1xuICAgICAgICB9KTtcblxuICAgICAgICBpdChcInNob3VsZCBub3QgcmV0dXJuIGEgcHVibGljIGRlcGVuZGVuY3kgZGVjbGFyZWQgYXQgdGhlIGhvc3RcIiwgKCkgPT4ge1xuICAgICAgICAgIHZhciBlbmdpbmUgPSBJbmplY3Rvci5yZXNvbHZlKFtFbmdpbmVdKVswXTtcbiAgICAgICAgICB2YXIgcHJvdG9QYXJlbnQgPVxuICAgICAgICAgICAgICBuZXcgUHJvdG9JbmplY3RvcihbbmV3IFByb3ZpZGVyV2l0aFZpc2liaWxpdHkoZW5naW5lLCBWaXNpYmlsaXR5LlB1YmxpYyldKTtcbiAgICAgICAgICB2YXIgcGFyZW50ID0gbmV3IEluamVjdG9yKHByb3RvUGFyZW50KTtcblxuICAgICAgICAgIHZhciBjaGlsZCA9IGNyZWF0ZUluamVjdG9yKFxuICAgICAgICAgICAgICBbcHJvdmlkZShDYXIsIHt1c2VGYWN0b3J5OiAoZSkgPT4gbmV3IENhcihlKSwgZGVwczogW1tFbmdpbmUsIG5ldyBIb3N0TWV0YWRhdGEoKV1dfSldLFxuICAgICAgICAgICAgICBwYXJlbnQsIHRydWUpOyAgLy8gaG9zdFxuXG4gICAgICAgICAgZXhwZWN0KCgpID0+IGNoaWxkLmdldChDYXIpKVxuICAgICAgICAgICAgICAudG9UaHJvd0Vycm9yKGBObyBwcm92aWRlciBmb3IgRW5naW5lISAoJHtzdHJpbmdpZnkoQ2FyKX0gLT4gJHtzdHJpbmdpZnkoRW5naW5lKX0pYCk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGl0KFwic2hvdWxkIG5vdCBza2lwIHNlbGZcIiwgKCkgPT4ge1xuICAgICAgICAgIHZhciBwYXJlbnQgPSBJbmplY3Rvci5yZXNvbHZlQW5kQ3JlYXRlKFtFbmdpbmVdKTtcbiAgICAgICAgICB2YXIgY2hpbGQgPSBwYXJlbnQucmVzb2x2ZUFuZENyZWF0ZUNoaWxkKFtcbiAgICAgICAgICAgIHByb3ZpZGUoRW5naW5lLCB7dXNlQ2xhc3M6IFR1cmJvRW5naW5lfSksXG4gICAgICAgICAgICBwcm92aWRlKENhciwge3VzZUZhY3Rvcnk6IChlKSA9PiBuZXcgQ2FyKGUpLCBkZXBzOiBbW0VuZ2luZSwgbmV3IEhvc3RNZXRhZGF0YSgpXV19KVxuICAgICAgICAgIF0pO1xuXG4gICAgICAgICAgZXhwZWN0KGNoaWxkLmdldChDYXIpLmVuZ2luZSkudG9CZUFuSW5zdGFuY2VPZihUdXJib0VuZ2luZSk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG5cbiAgICAgIGRlc2NyaWJlKFwiZGVmYXVsdFwiLCAoKSA9PiB7XG4gICAgICAgIGl0KFwic2hvdWxkIHJldHVybiBhIHByaXZhdGUgZGVwZW5kZW5jeSBkZWNsYXJlZCBhdCB0aGUgaG9zdFwiLCAoKSA9PiB7XG4gICAgICAgICAgdmFyIGVuZ2luZSA9IEluamVjdG9yLnJlc29sdmUoW0VuZ2luZV0pWzBdO1xuICAgICAgICAgIHZhciBwcm90b1BhcmVudCA9XG4gICAgICAgICAgICAgIG5ldyBQcm90b0luamVjdG9yKFtuZXcgUHJvdmlkZXJXaXRoVmlzaWJpbGl0eShlbmdpbmUsIFZpc2liaWxpdHkuUHJpdmF0ZSldKTtcbiAgICAgICAgICB2YXIgcGFyZW50ID0gbmV3IEluamVjdG9yKHByb3RvUGFyZW50KTtcblxuICAgICAgICAgIHZhciBjaGlsZCA9IGNyZWF0ZUluamVjdG9yKFxuICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgcHJvdmlkZShFbmdpbmUsIHt1c2VDbGFzczogQnJva2VuRW5naW5lfSksXG4gICAgICAgICAgICAgICAgcHJvdmlkZShDYXIsXG4gICAgICAgICAgICAgICAgICAgICAgICB7dXNlRmFjdG9yeTogKGUpID0+IG5ldyBDYXIoZSksIGRlcHM6IFtbRW5naW5lLCBuZXcgU2tpcFNlbGZNZXRhZGF0YSgpXV19KVxuICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICBwYXJlbnQsIHRydWUpOyAgLy8gYm91bmRhcnlcblxuICAgICAgICAgIGV4cGVjdChjaGlsZC5nZXQoQ2FyKSkudG9CZUFuSW5zdGFuY2VPZihDYXIpO1xuICAgICAgICB9KTtcblxuICAgICAgICBpdChcInNob3VsZCByZXR1cm4gYSBwdWJsaWMgZGVwZW5kZW5jeSBkZWNsYXJlZCBhdCB0aGUgaG9zdFwiLCAoKSA9PiB7XG4gICAgICAgICAgdmFyIGVuZ2luZSA9IEluamVjdG9yLnJlc29sdmUoW0VuZ2luZV0pWzBdO1xuICAgICAgICAgIHZhciBwcm90b1BhcmVudCA9XG4gICAgICAgICAgICAgIG5ldyBQcm90b0luamVjdG9yKFtuZXcgUHJvdmlkZXJXaXRoVmlzaWJpbGl0eShlbmdpbmUsIFZpc2liaWxpdHkuUHVibGljKV0pO1xuICAgICAgICAgIHZhciBwYXJlbnQgPSBuZXcgSW5qZWN0b3IocHJvdG9QYXJlbnQpO1xuXG4gICAgICAgICAgdmFyIGNoaWxkID0gY3JlYXRlSW5qZWN0b3IoXG4gICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICBwcm92aWRlKEVuZ2luZSwge3VzZUNsYXNzOiBCcm9rZW5FbmdpbmV9KSxcbiAgICAgICAgICAgICAgICBwcm92aWRlKENhcixcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VGYWN0b3J5OiAoZSkgPT4gbmV3IENhcihlKSwgZGVwczogW1tFbmdpbmUsIG5ldyBTa2lwU2VsZk1ldGFkYXRhKCldXX0pXG4gICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgIHBhcmVudCwgdHJ1ZSk7ICAvLyBib3VuZGFyeVxuXG4gICAgICAgICAgZXhwZWN0KGNoaWxkLmdldChDYXIpKS50b0JlQW5JbnN0YW5jZU9mKENhcik7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGl0KFwic2hvdWxkIG5vdCByZXR1cm4gYSBwcml2YXRlIGRlcGVuZGVuY3kgZGVjbGFyZWQgTk9UIGF0IHRoZSBob3N0XCIsICgpID0+IHtcbiAgICAgICAgICB2YXIgZW5naW5lID0gSW5qZWN0b3IucmVzb2x2ZShbRW5naW5lXSlbMF07XG4gICAgICAgICAgdmFyIHByb3RvUGFyZW50ID1cbiAgICAgICAgICAgICAgbmV3IFByb3RvSW5qZWN0b3IoW25ldyBQcm92aWRlcldpdGhWaXNpYmlsaXR5KGVuZ2luZSwgVmlzaWJpbGl0eS5Qcml2YXRlKV0pO1xuICAgICAgICAgIHZhciBwYXJlbnQgPSBuZXcgSW5qZWN0b3IocHJvdG9QYXJlbnQpO1xuXG4gICAgICAgICAgdmFyIGNoaWxkID0gY3JlYXRlSW5qZWN0b3IoXG4gICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICBwcm92aWRlKEVuZ2luZSwge3VzZUNsYXNzOiBCcm9rZW5FbmdpbmV9KSxcbiAgICAgICAgICAgICAgICBwcm92aWRlKENhcixcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VGYWN0b3J5OiAoZSkgPT4gbmV3IENhcihlKSwgZGVwczogW1tFbmdpbmUsIG5ldyBTa2lwU2VsZk1ldGFkYXRhKCldXX0pXG4gICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgIHBhcmVudCwgZmFsc2UpO1xuXG4gICAgICAgICAgZXhwZWN0KCgpID0+IGNoaWxkLmdldChDYXIpKVxuICAgICAgICAgICAgICAudG9UaHJvd0Vycm9yKGBObyBwcm92aWRlciBmb3IgRW5naW5lISAoJHtzdHJpbmdpZnkoQ2FyKX0gLT4gJHtzdHJpbmdpZnkoRW5naW5lKX0pYCk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGl0KFwic2hvdWxkIG5vdCBza2lwIHNlbGZcIiwgKCkgPT4ge1xuICAgICAgICAgIHZhciBwYXJlbnQgPSBJbmplY3Rvci5yZXNvbHZlQW5kQ3JlYXRlKFtFbmdpbmVdKTtcbiAgICAgICAgICB2YXIgY2hpbGQgPSBwYXJlbnQucmVzb2x2ZUFuZENyZWF0ZUNoaWxkKFtcbiAgICAgICAgICAgIHByb3ZpZGUoRW5naW5lLCB7dXNlQ2xhc3M6IFR1cmJvRW5naW5lfSksXG4gICAgICAgICAgICBwcm92aWRlKENhciwge3VzZUZhY3Rvcnk6IChlKSA9PiBuZXcgQ2FyKGUpLCBkZXBzOiBbRW5naW5lXX0pXG4gICAgICAgICAgXSk7XG5cbiAgICAgICAgICBleHBlY3QoY2hpbGQuZ2V0KENhcikuZW5naW5lKS50b0JlQW5JbnN0YW5jZU9mKFR1cmJvRW5naW5lKTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKCdyZXNvbHZlJywgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCByZXNvbHZlIGFuZCBmbGF0dGVuJywgKCkgPT4ge1xuICAgICAgICB2YXIgcHJvdmlkZXJzID0gSW5qZWN0b3IucmVzb2x2ZShbRW5naW5lLCBbQnJva2VuRW5naW5lXV0pO1xuICAgICAgICBwcm92aWRlcnMuZm9yRWFjaChmdW5jdGlvbihiKSB7XG4gICAgICAgICAgaWYgKGlzQmxhbmsoYikpIHJldHVybjsgIC8vIHRoZSByZXN1bHQgaXMgYSBzcGFyc2UgYXJyYXlcbiAgICAgICAgICBleHBlY3QoYiBpbnN0YW5jZW9mIFJlc29sdmVkUHJvdmlkZXJfKS50b0JlKHRydWUpO1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuXG4gICAgICBpdChcInNob3VsZCBzdXBwb3J0IG11bHRpIHByb3ZpZGVyc1wiLCAoKSA9PiB7XG4gICAgICAgIHZhciBwcm92aWRlciA9IEluamVjdG9yLnJlc29sdmUoW1xuICAgICAgICAgIG5ldyBQcm92aWRlcihFbmdpbmUsIHt1c2VDbGFzczogQnJva2VuRW5naW5lLCBtdWx0aTogdHJ1ZX0pLFxuICAgICAgICAgIG5ldyBQcm92aWRlcihFbmdpbmUsIHt1c2VDbGFzczogVHVyYm9FbmdpbmUsIG11bHRpOiB0cnVlfSlcbiAgICAgICAgXSlbMF07XG5cbiAgICAgICAgZXhwZWN0KHByb3ZpZGVyLmtleS50b2tlbikudG9CZShFbmdpbmUpO1xuICAgICAgICBleHBlY3QocHJvdmlkZXIubXVsdGlQcm92aWRlcikudG9FcXVhbCh0cnVlKTtcbiAgICAgICAgZXhwZWN0KHByb3ZpZGVyLnJlc29sdmVkRmFjdG9yaWVzLmxlbmd0aCkudG9FcXVhbCgyKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdChcInNob3VsZCBzdXBwb3J0IG11bHRpIHByb3ZpZGVycyB3aXRoIG9ubHkgb25lIHByb3ZpZGVyXCIsICgpID0+IHtcbiAgICAgICAgdmFyIHByb3ZpZGVyID1cbiAgICAgICAgICAgIEluamVjdG9yLnJlc29sdmUoW25ldyBQcm92aWRlcihFbmdpbmUsIHt1c2VDbGFzczogQnJva2VuRW5naW5lLCBtdWx0aTogdHJ1ZX0pXSlbMF07XG5cbiAgICAgICAgZXhwZWN0KHByb3ZpZGVyLmtleS50b2tlbikudG9CZShFbmdpbmUpO1xuICAgICAgICBleHBlY3QocHJvdmlkZXIubXVsdGlQcm92aWRlcikudG9FcXVhbCh0cnVlKTtcbiAgICAgICAgZXhwZWN0KHByb3ZpZGVyLnJlc29sdmVkRmFjdG9yaWVzLmxlbmd0aCkudG9FcXVhbCgxKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdChcInNob3VsZCB0aHJvdyB3aGVuIG1peGluZyBtdWx0aSBwcm92aWRlcnMgd2l0aCByZWd1bGFyIHByb3ZpZGVyc1wiLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCgoKSA9PiB7XG4gICAgICAgICAgSW5qZWN0b3IucmVzb2x2ZShbbmV3IFByb3ZpZGVyKEVuZ2luZSwge3VzZUNsYXNzOiBCcm9rZW5FbmdpbmUsIG11bHRpOiB0cnVlfSksIEVuZ2luZV0pO1xuICAgICAgICB9KS50b1Rocm93RXJyb3JXaXRoKFwiQ2Fubm90IG1peCBtdWx0aSBwcm92aWRlcnMgYW5kIHJlZ3VsYXIgcHJvdmlkZXJzXCIpO1xuXG4gICAgICAgIGV4cGVjdCgoKSA9PiB7XG4gICAgICAgICAgSW5qZWN0b3IucmVzb2x2ZShbRW5naW5lLCBuZXcgUHJvdmlkZXIoRW5naW5lLCB7dXNlQ2xhc3M6IEJyb2tlbkVuZ2luZSwgbXVsdGk6IHRydWV9KV0pO1xuICAgICAgICB9KS50b1Rocm93RXJyb3JXaXRoKFwiQ2Fubm90IG1peCBtdWx0aSBwcm92aWRlcnMgYW5kIHJlZ3VsYXIgcHJvdmlkZXJzXCIpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcmVzb2x2ZSBmb3J3YXJkIHJlZmVyZW5jZXMnLCAoKSA9PiB7XG4gICAgICAgIHZhciBwcm92aWRlcnMgPSBJbmplY3Rvci5yZXNvbHZlKFtcbiAgICAgICAgICBmb3J3YXJkUmVmKCgpID0+IEVuZ2luZSksXG4gICAgICAgICAgW3Byb3ZpZGUoZm9yd2FyZFJlZigoKSA9PiBCcm9rZW5FbmdpbmUpLCB7dXNlQ2xhc3M6IGZvcndhcmRSZWYoKCkgPT4gRW5naW5lKX0pXSxcbiAgICAgICAgICBwcm92aWRlKGZvcndhcmRSZWYoKCkgPT4gU3RyaW5nKSxcbiAgICAgICAgICAgICAgICAgIHt1c2VGYWN0b3J5OiAoKSA9PiAnT0snLCBkZXBzOiBbZm9yd2FyZFJlZigoKSA9PiBFbmdpbmUpXX0pXG4gICAgICAgIF0pO1xuXG4gICAgICAgIHZhciBlbmdpbmVQcm92aWRlciA9IHByb3ZpZGVyc1swXTtcbiAgICAgICAgdmFyIGJyb2tlbkVuZ2luZVByb3ZpZGVyID0gcHJvdmlkZXJzWzFdO1xuICAgICAgICB2YXIgc3RyaW5nUHJvdmlkZXIgPSBwcm92aWRlcnNbMl07XG5cbiAgICAgICAgZXhwZWN0KGVuZ2luZVByb3ZpZGVyLnJlc29sdmVkRmFjdG9yaWVzWzBdLmZhY3RvcnkoKSBpbnN0YW5jZW9mIEVuZ2luZSkudG9CZSh0cnVlKTtcbiAgICAgICAgZXhwZWN0KGJyb2tlbkVuZ2luZVByb3ZpZGVyLnJlc29sdmVkRmFjdG9yaWVzWzBdLmZhY3RvcnkoKSBpbnN0YW5jZW9mIEVuZ2luZSkudG9CZSh0cnVlKTtcbiAgICAgICAgZXhwZWN0KHN0cmluZ1Byb3ZpZGVyLnJlc29sdmVkRmFjdG9yaWVzWzBdLmRlcGVuZGVuY2llc1swXS5rZXkpLnRvRXF1YWwoS2V5LmdldChFbmdpbmUpKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHN1cHBvcnQgb3ZlcnJpZGluZyBmYWN0b3J5IGRlcGVuZGVuY2llcyB3aXRoIGRlcGVuZGVuY3kgYW5ub3RhdGlvbnMnLCAoKSA9PiB7XG4gICAgICAgIHZhciBwcm92aWRlcnMgPSBJbmplY3Rvci5yZXNvbHZlKFtcbiAgICAgICAgICBwcm92aWRlKFwidG9rZW5cIixcbiAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgdXNlRmFjdG9yeTogKGUpID0+IFwicmVzdWx0XCIsXG4gICAgICAgICAgICAgICAgICAgIGRlcHM6IFtbbmV3IEluamVjdE1ldGFkYXRhKFwiZGVwXCIpLCBuZXcgQ3VzdG9tRGVwZW5kZW5jeU1ldGFkYXRhKCldXVxuICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgXSk7XG5cbiAgICAgICAgdmFyIHByb3ZpZGVyID0gcHJvdmlkZXJzWzBdO1xuXG4gICAgICAgIGV4cGVjdChwcm92aWRlci5yZXNvbHZlZEZhY3Rvcmllc1swXS5kZXBlbmRlbmNpZXNbMF0ua2V5LnRva2VuKS50b0VxdWFsKFwiZGVwXCIpO1xuICAgICAgICBleHBlY3QocHJvdmlkZXIucmVzb2x2ZWRGYWN0b3JpZXNbMF0uZGVwZW5kZW5jaWVzWzBdLnByb3BlcnRpZXMpXG4gICAgICAgICAgICAudG9FcXVhbChbbmV3IEN1c3RvbURlcGVuZGVuY3lNZXRhZGF0YSgpXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBhbGxvdyBkZWNsYXJpbmcgZGVwZW5kZW5jaWVzIHdpdGggZmxhdCBhcnJheXMnLCAoKSA9PiB7XG4gICAgICAgIHZhciByZXNvbHZlZCA9IEluamVjdG9yLnJlc29sdmUoXG4gICAgICAgICAgICBbcHJvdmlkZSgndG9rZW4nLCB7dXNlRmFjdG9yeTogZSA9PiBlLCBkZXBzOiBbbmV3IEluamVjdE1ldGFkYXRhKFwiZGVwXCIpXX0pXSk7XG4gICAgICAgIHZhciBuZXN0ZWRSZXNvbHZlZCA9IEluamVjdG9yLnJlc29sdmUoXG4gICAgICAgICAgICBbcHJvdmlkZSgndG9rZW4nLCB7dXNlRmFjdG9yeTogZSA9PiBlLCBkZXBzOiBbW25ldyBJbmplY3RNZXRhZGF0YShcImRlcFwiKV1dfSldKTtcbiAgICAgICAgZXhwZWN0KHJlc29sdmVkWzBdLnJlc29sdmVkRmFjdG9yaWVzWzBdLmRlcGVuZGVuY2llc1swXS5rZXkudG9rZW4pXG4gICAgICAgICAgICAudG9FcXVhbChuZXN0ZWRSZXNvbHZlZFswXS5yZXNvbHZlZEZhY3Rvcmllc1swXS5kZXBlbmRlbmNpZXNbMF0ua2V5LnRva2VuKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoXCJkaXNwbGF5TmFtZVwiLCAoKSA9PiB7XG4gICAgICBpdChcInNob3VsZCB3b3JrXCIsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KEluamVjdG9yLnJlc29sdmVBbmRDcmVhdGUoW0VuZ2luZSwgQnJva2VuRW5naW5lXSkuZGlzcGxheU5hbWUpXG4gICAgICAgICAgICAudG9FcXVhbCgnSW5qZWN0b3IocHJvdmlkZXJzOiBbIFwiRW5naW5lXCIgLCAgXCJCcm9rZW5FbmdpbmVcIiBdKScpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH0pO1xufVxuIl19
 main(); 
