'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var animation_player_1 = require('angular2/src/core/animation/animation_player');
function main() {
    testing_internal_1.describe('NoOpAnimationPlayer', function () {
        testing_internal_1.it('should call onDone after the next microtask when constructed', testing_internal_1.fakeAsync(function () {
            var player = new animation_player_1.NoOpAnimationPlayer();
            var completed = false;
            player.onDone(function () { return completed = true; });
            testing_internal_1.expect(completed).toEqual(false);
            testing_internal_1.flushMicrotasks();
            testing_internal_1.expect(completed).toEqual(true);
        }));
        testing_internal_1.it('should be able to run each of the player methods', testing_internal_1.fakeAsync(function () {
            var player = new animation_player_1.NoOpAnimationPlayer();
            player.pause();
            player.play();
            player.finish();
            player.restart();
            player.destroy();
        }));
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYW5pbWF0aW9uX3BsYXllcl9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb3JlL2FuaW1hdGlvbi9hbmltYXRpb25fcGxheWVyX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiJdLCJtYXBwaW5ncyI6IkFBQUEsaUNBc0JPLDJCQUEyQixDQUFDLENBQUE7QUFFbkMsaUNBQW1ELDhDQUE4QyxDQUFDLENBQUE7QUFFbEc7SUFDRUEsMkJBQVFBLENBQUNBLHFCQUFxQkEsRUFBRUE7UUFDOUIscUJBQUUsQ0FBQyw4REFBOEQsRUFBRSw0QkFBUyxDQUFDO1lBQ3hFLElBQUksTUFBTSxHQUFHLElBQUksc0NBQW1CLEVBQUUsQ0FBQztZQUN2QyxJQUFJLFNBQVMsR0FBRyxLQUFLLENBQUM7WUFDdEIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFNLE9BQUEsU0FBUyxHQUFHLElBQUksRUFBaEIsQ0FBZ0IsQ0FBQyxDQUFDO1lBQ3RDLHlCQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ2pDLGtDQUFlLEVBQUUsQ0FBQztZQUNsQix5QkFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRVAscUJBQUUsQ0FBQyxrREFBa0QsRUFBRSw0QkFBUyxDQUFDO1lBQzVELElBQUksTUFBTSxHQUFHLElBQUksc0NBQW1CLEVBQUUsQ0FBQztZQUN2QyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDZixNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDZCxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDaEIsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2pCLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ1QsQ0FBQyxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQXBCZSxZQUFJLE9Bb0JuQixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXN5bmNUZXN0Q29tcGxldGVyLFxuICBiZWZvcmVFYWNoLFxuICBkZGVzY3JpYmUsXG4gIHhkZXNjcmliZSxcbiAgZGVzY3JpYmUsXG4gIGVsLFxuICBkaXNwYXRjaEV2ZW50LFxuICBleHBlY3QsXG4gIGlpdCxcbiAgaW5qZWN0LFxuICBiZWZvcmVFYWNoUHJvdmlkZXJzLFxuICBpdCxcbiAgeGl0LFxuICBjb250YWluc1JlZ2V4cCxcbiAgc3RyaW5naWZ5RWxlbWVudCxcbiAgVGVzdENvbXBvbmVudEJ1aWxkZXIsXG4gIGZha2VBc3luYyxcbiAgY2xlYXJQZW5kaW5nVGltZXJzLFxuICBDb21wb25lbnRGaXh0dXJlLFxuICB0aWNrLFxuICBmbHVzaE1pY3JvdGFza3MsXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5pbXBvcnQge05vT3BBbmltYXRpb25QbGF5ZXIsIEFuaW1hdGlvblBsYXllcn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvYW5pbWF0aW9uL2FuaW1hdGlvbl9wbGF5ZXInO1xuXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpIHtcbiAgZGVzY3JpYmUoJ05vT3BBbmltYXRpb25QbGF5ZXInLCBmdW5jdGlvbigpIHtcbiAgICBpdCgnc2hvdWxkIGNhbGwgb25Eb25lIGFmdGVyIHRoZSBuZXh0IG1pY3JvdGFzayB3aGVuIGNvbnN0cnVjdGVkJywgZmFrZUFzeW5jKCgpID0+IHtcbiAgICAgICAgIHZhciBwbGF5ZXIgPSBuZXcgTm9PcEFuaW1hdGlvblBsYXllcigpO1xuICAgICAgICAgdmFyIGNvbXBsZXRlZCA9IGZhbHNlO1xuICAgICAgICAgcGxheWVyLm9uRG9uZSgoKSA9PiBjb21wbGV0ZWQgPSB0cnVlKTtcbiAgICAgICAgIGV4cGVjdChjb21wbGV0ZWQpLnRvRXF1YWwoZmFsc2UpO1xuICAgICAgICAgZmx1c2hNaWNyb3Rhc2tzKCk7XG4gICAgICAgICBleHBlY3QoY29tcGxldGVkKS50b0VxdWFsKHRydWUpO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgYmUgYWJsZSB0byBydW4gZWFjaCBvZiB0aGUgcGxheWVyIG1ldGhvZHMnLCBmYWtlQXN5bmMoKCkgPT4ge1xuICAgICAgICAgdmFyIHBsYXllciA9IG5ldyBOb09wQW5pbWF0aW9uUGxheWVyKCk7XG4gICAgICAgICBwbGF5ZXIucGF1c2UoKTtcbiAgICAgICAgIHBsYXllci5wbGF5KCk7XG4gICAgICAgICBwbGF5ZXIuZmluaXNoKCk7XG4gICAgICAgICBwbGF5ZXIucmVzdGFydCgpO1xuICAgICAgICAgcGxheWVyLmRlc3Ryb3koKTtcbiAgICAgICB9KSk7XG4gIH0pO1xufVxuIl19
 main(); 
