'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var animation_queue_1 = require('angular2/src/core/animation/animation_queue');
var mock_animation_player_1 = require('angular2/src/mock/mock_animation_player');
var ng_zone_mock_1 = require('angular2/src/mock/ng_zone_mock');
function main() {
    testing_internal_1.describe('AnimationGroupPlayer', function () {
        var queue;
        testing_internal_1.beforeEach(function () {
            var mockZone = new ng_zone_mock_1.MockNgZone();
            queue = new animation_queue_1.AnimationQueue(mockZone);
        });
        testing_internal_1.it('should queue up a series of players and run play when flushed', function () {
            var e1 = testing_internal_1.el('<div></div>');
            var e2 = testing_internal_1.el('<div></div>');
            var e3 = testing_internal_1.el('<div></div>');
            var players = [
                new mock_animation_player_1.MockAnimationPlayer(),
                new mock_animation_player_1.MockAnimationPlayer(),
                new mock_animation_player_1.MockAnimationPlayer(),
            ];
            var count = 0;
            var countFn = function () { return count++; };
            queue.schedule(e1, 1, players[0], countFn);
            queue.schedule(e2, 1, players[1], countFn);
            queue.schedule(e3, 1, players[2], countFn);
            testing_internal_1.expect(count).toEqual(0);
            queue.flush();
            players[0].finish();
            players[1].finish();
            players[2].finish();
            testing_internal_1.expect(count).toEqual(3);
        });
        testing_internal_1.it('should finish up a previously scheduled player if the new priority is higher on the same element', function () {
            var players = [
                new mock_animation_player_1.MockAnimationPlayer(),
                new mock_animation_player_1.MockAnimationPlayer(),
                new mock_animation_player_1.MockAnimationPlayer(),
            ];
            var lookup = {};
            var trackFn = function (letter) { return function () { lookup[letter] = true; }; };
            var element = testing_internal_1.el('<div></div>');
            queue.schedule(element, 100, players[0], trackFn('1'));
            testing_internal_1.expect(lookup['1']).toBeFalsy();
            queue.schedule(element, 200, players[1], trackFn('2'));
            testing_internal_1.expect(lookup['1']).toBeTruthy();
            testing_internal_1.expect(lookup['2']).toBeFalsy();
            queue.schedule(element, 150, players[2], trackFn('3'));
            testing_internal_1.expect(lookup['1']).toBeTruthy();
            testing_internal_1.expect(lookup['2']).toBeFalsy();
            testing_internal_1.expect(lookup['3']).toBeTruthy();
        });
        testing_internal_1.it('should cancel an already running animation which is on the same element only if the follow-up priority is higher', function () {
            var player1 = new mock_animation_player_1.MockAnimationPlayer();
            var player2 = new mock_animation_player_1.MockAnimationPlayer();
            var player3 = new mock_animation_player_1.MockAnimationPlayer();
            var element = testing_internal_1.el('<div></div>');
            var lookup = {};
            var trackFn = function (letter) { return function () { lookup[letter] = true; }; };
            queue.schedule(element, 100, player1, trackFn('A'));
            queue.flush();
            testing_internal_1.expect(lookup['A']).toBeFalsy();
            testing_internal_1.expect(lookup['B']).toBeFalsy();
            queue.schedule(element, 200, player2, trackFn('B'));
            testing_internal_1.expect(lookup['A']).toBeTruthy();
            testing_internal_1.expect(lookup['B']).toBeFalsy();
            queue.schedule(element, 150, player3, trackFn('C'));
            testing_internal_1.expect(lookup['A']).toBeTruthy();
            testing_internal_1.expect(lookup['B']).toBeFalsy();
            testing_internal_1.expect(lookup['C']).toBeTruthy();
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYW5pbWF0aW9uX3F1ZXVlX3NwZWMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L2NvcmUvYW5pbWF0aW9uL2FuaW1hdGlvbl9xdWV1ZV9zcGVjLnRzIl0sIm5hbWVzIjpbIm1haW4iXSwibWFwcGluZ3MiOiJBQUFBLGlDQXNCTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLGdDQUE2Qiw2Q0FBNkMsQ0FBQyxDQUFBO0FBQzNFLHNDQUFrQyx5Q0FBeUMsQ0FBQyxDQUFBO0FBQzVFLDZCQUF5QixnQ0FBZ0MsQ0FBQyxDQUFBO0FBRTFEO0lBQ0VBLDJCQUFRQSxDQUFDQSxzQkFBc0JBLEVBQUVBO1FBQy9CLElBQUksS0FBSyxDQUFDO1FBQ1YsNkJBQVUsQ0FBQztZQUNULElBQUksUUFBUSxHQUFHLElBQUkseUJBQVUsRUFBRSxDQUFDO1lBQ2hDLEtBQUssR0FBRyxJQUFJLGdDQUFjLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDdkMsQ0FBQyxDQUFDLENBQUM7UUFFSCxxQkFBRSxDQUFDLCtEQUErRCxFQUFFO1lBQ2xFLElBQUksRUFBRSxHQUFHLHFCQUFFLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDM0IsSUFBSSxFQUFFLEdBQUcscUJBQUUsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUMzQixJQUFJLEVBQUUsR0FBRyxxQkFBRSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBRTNCLElBQUksT0FBTyxHQUFHO2dCQUNaLElBQUksMkNBQW1CLEVBQUU7Z0JBQ3pCLElBQUksMkNBQW1CLEVBQUU7Z0JBQ3pCLElBQUksMkNBQW1CLEVBQUU7YUFDMUIsQ0FBQztZQUVGLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztZQUNkLElBQUksT0FBTyxHQUFHLGNBQU0sT0FBQSxLQUFLLEVBQUUsRUFBUCxDQUFPLENBQUM7WUFFNUIsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUMzQyxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQzNDLEtBQUssQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFFM0MseUJBQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFekIsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBRWQsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3BCLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNwQixPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7WUFFcEIseUJBQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0IsQ0FBQyxDQUFDLENBQUM7UUFFSCxxQkFBRSxDQUFDLGtHQUFrRyxFQUNsRztZQUNFLElBQUksT0FBTyxHQUFHO2dCQUNaLElBQUksMkNBQW1CLEVBQUU7Z0JBQ3pCLElBQUksMkNBQW1CLEVBQUU7Z0JBQ3pCLElBQUksMkNBQW1CLEVBQUU7YUFDMUIsQ0FBQztZQUVGLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQztZQUNoQixJQUFJLE9BQU8sR0FBRyxVQUFDLE1BQU0sSUFBTyxNQUFNLENBQUMsY0FBUSxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO1lBRXRFLElBQUksT0FBTyxHQUFHLHFCQUFFLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFaEMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUN2RCx5QkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBRWhDLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDdkQseUJBQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNqQyx5QkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBRWhDLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDdkQseUJBQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNqQyx5QkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ2hDLHlCQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbkMsQ0FBQyxDQUFDLENBQUM7UUFFTixxQkFBRSxDQUFDLGtIQUFrSCxFQUNsSDtZQUNFLElBQUksT0FBTyxHQUFHLElBQUksMkNBQW1CLEVBQUUsQ0FBQztZQUN4QyxJQUFJLE9BQU8sR0FBRyxJQUFJLDJDQUFtQixFQUFFLENBQUM7WUFDeEMsSUFBSSxPQUFPLEdBQUcsSUFBSSwyQ0FBbUIsRUFBRSxDQUFDO1lBQ3hDLElBQUksT0FBTyxHQUFHLHFCQUFFLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFaEMsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO1lBQ2hCLElBQUksT0FBTyxHQUFHLFVBQUMsTUFBTSxJQUFPLE1BQU0sQ0FBQyxjQUFRLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7WUFFNUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUU5RSxLQUFLLENBQUMsS0FBSyxFQUFFLENBQUM7WUFFZCx5QkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ2hDLHlCQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7WUFFaEMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUVwRCx5QkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2pDLHlCQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7WUFFaEMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUVwRCx5QkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2pDLHlCQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDaEMseUJBQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FBQztJQUNSLENBQUMsQ0FBQ0EsQ0FBQ0E7QUFDTEEsQ0FBQ0E7QUE1RmUsWUFBSSxPQTRGbkIsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFzeW5jVGVzdENvbXBsZXRlcixcbiAgYmVmb3JlRWFjaCxcbiAgZGRlc2NyaWJlLFxuICB4ZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICBlbCxcbiAgZGlzcGF0Y2hFdmVudCxcbiAgZXhwZWN0LFxuICBpaXQsXG4gIGluamVjdCxcbiAgYmVmb3JlRWFjaFByb3ZpZGVycyxcbiAgaXQsXG4gIHhpdCxcbiAgY29udGFpbnNSZWdleHAsXG4gIHN0cmluZ2lmeUVsZW1lbnQsXG4gIFRlc3RDb21wb25lbnRCdWlsZGVyLFxuICBmYWtlQXN5bmMsXG4gIGNsZWFyUGVuZGluZ1RpbWVycyxcbiAgQ29tcG9uZW50Rml4dHVyZSxcbiAgdGljayxcbiAgZmx1c2hNaWNyb3Rhc2tzLFxufSBmcm9tICdhbmd1bGFyMi90ZXN0aW5nX2ludGVybmFsJztcblxuaW1wb3J0IHtBbmltYXRpb25RdWV1ZX0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvYW5pbWF0aW9uL2FuaW1hdGlvbl9xdWV1ZSc7XG5pbXBvcnQge01vY2tBbmltYXRpb25QbGF5ZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9tb2NrL21vY2tfYW5pbWF0aW9uX3BsYXllcic7XG5pbXBvcnQge01vY2tOZ1pvbmV9IGZyb20gJ2FuZ3VsYXIyL3NyYy9tb2NrL25nX3pvbmVfbW9jayc7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgnQW5pbWF0aW9uR3JvdXBQbGF5ZXInLCBmdW5jdGlvbigpIHtcbiAgICB2YXIgcXVldWU7XG4gICAgYmVmb3JlRWFjaCgoKSA9PiB7XG4gICAgICB2YXIgbW9ja1pvbmUgPSBuZXcgTW9ja05nWm9uZSgpO1xuICAgICAgcXVldWUgPSBuZXcgQW5pbWF0aW9uUXVldWUobW9ja1pvbmUpO1xuICAgIH0pO1xuXG4gICAgaXQoJ3Nob3VsZCBxdWV1ZSB1cCBhIHNlcmllcyBvZiBwbGF5ZXJzIGFuZCBydW4gcGxheSB3aGVuIGZsdXNoZWQnLCAoKSA9PiB7XG4gICAgICB2YXIgZTEgPSBlbCgnPGRpdj48L2Rpdj4nKTtcbiAgICAgIHZhciBlMiA9IGVsKCc8ZGl2PjwvZGl2PicpO1xuICAgICAgdmFyIGUzID0gZWwoJzxkaXY+PC9kaXY+Jyk7XG5cbiAgICAgIHZhciBwbGF5ZXJzID0gW1xuICAgICAgICBuZXcgTW9ja0FuaW1hdGlvblBsYXllcigpLFxuICAgICAgICBuZXcgTW9ja0FuaW1hdGlvblBsYXllcigpLFxuICAgICAgICBuZXcgTW9ja0FuaW1hdGlvblBsYXllcigpLFxuICAgICAgXTtcblxuICAgICAgdmFyIGNvdW50ID0gMDtcbiAgICAgIHZhciBjb3VudEZuID0gKCkgPT4gY291bnQrKztcblxuICAgICAgcXVldWUuc2NoZWR1bGUoZTEsIDEsIHBsYXllcnNbMF0sIGNvdW50Rm4pO1xuICAgICAgcXVldWUuc2NoZWR1bGUoZTIsIDEsIHBsYXllcnNbMV0sIGNvdW50Rm4pO1xuICAgICAgcXVldWUuc2NoZWR1bGUoZTMsIDEsIHBsYXllcnNbMl0sIGNvdW50Rm4pO1xuXG4gICAgICBleHBlY3QoY291bnQpLnRvRXF1YWwoMCk7XG5cbiAgICAgIHF1ZXVlLmZsdXNoKCk7XG5cbiAgICAgIHBsYXllcnNbMF0uZmluaXNoKCk7XG4gICAgICBwbGF5ZXJzWzFdLmZpbmlzaCgpO1xuICAgICAgcGxheWVyc1syXS5maW5pc2goKTtcblxuICAgICAgZXhwZWN0KGNvdW50KS50b0VxdWFsKDMpO1xuICAgIH0pO1xuXG4gICAgaXQoJ3Nob3VsZCBmaW5pc2ggdXAgYSBwcmV2aW91c2x5IHNjaGVkdWxlZCBwbGF5ZXIgaWYgdGhlIG5ldyBwcmlvcml0eSBpcyBoaWdoZXIgb24gdGhlIHNhbWUgZWxlbWVudCcsXG4gICAgICAgKCkgPT4ge1xuICAgICAgICAgdmFyIHBsYXllcnMgPSBbXG4gICAgICAgICAgIG5ldyBNb2NrQW5pbWF0aW9uUGxheWVyKCksXG4gICAgICAgICAgIG5ldyBNb2NrQW5pbWF0aW9uUGxheWVyKCksXG4gICAgICAgICAgIG5ldyBNb2NrQW5pbWF0aW9uUGxheWVyKCksXG4gICAgICAgICBdO1xuXG4gICAgICAgICB2YXIgbG9va3VwID0ge307XG4gICAgICAgICB2YXIgdHJhY2tGbiA9IChsZXR0ZXIpID0+IHsgcmV0dXJuICgpID0+IHsgbG9va3VwW2xldHRlcl0gPSB0cnVlOyB9OyB9XG5cbiAgICAgICAgIHZhciBlbGVtZW50ID0gZWwoJzxkaXY+PC9kaXY+Jyk7XG5cbiAgICAgICAgIHF1ZXVlLnNjaGVkdWxlKGVsZW1lbnQsIDEwMCwgcGxheWVyc1swXSwgdHJhY2tGbignMScpKTtcbiAgICAgICAgIGV4cGVjdChsb29rdXBbJzEnXSkudG9CZUZhbHN5KCk7XG5cbiAgICAgICAgIHF1ZXVlLnNjaGVkdWxlKGVsZW1lbnQsIDIwMCwgcGxheWVyc1sxXSwgdHJhY2tGbignMicpKTtcbiAgICAgICAgIGV4cGVjdChsb29rdXBbJzEnXSkudG9CZVRydXRoeSgpO1xuICAgICAgICAgZXhwZWN0KGxvb2t1cFsnMiddKS50b0JlRmFsc3koKTtcblxuICAgICAgICAgcXVldWUuc2NoZWR1bGUoZWxlbWVudCwgMTUwLCBwbGF5ZXJzWzJdLCB0cmFja0ZuKCczJykpO1xuICAgICAgICAgZXhwZWN0KGxvb2t1cFsnMSddKS50b0JlVHJ1dGh5KCk7XG4gICAgICAgICBleHBlY3QobG9va3VwWycyJ10pLnRvQmVGYWxzeSgpO1xuICAgICAgICAgZXhwZWN0KGxvb2t1cFsnMyddKS50b0JlVHJ1dGh5KCk7XG4gICAgICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIGNhbmNlbCBhbiBhbHJlYWR5IHJ1bm5pbmcgYW5pbWF0aW9uIHdoaWNoIGlzIG9uIHRoZSBzYW1lIGVsZW1lbnQgb25seSBpZiB0aGUgZm9sbG93LXVwIHByaW9yaXR5IGlzIGhpZ2hlcicsXG4gICAgICAgKCkgPT4ge1xuICAgICAgICAgdmFyIHBsYXllcjEgPSBuZXcgTW9ja0FuaW1hdGlvblBsYXllcigpO1xuICAgICAgICAgdmFyIHBsYXllcjIgPSBuZXcgTW9ja0FuaW1hdGlvblBsYXllcigpO1xuICAgICAgICAgdmFyIHBsYXllcjMgPSBuZXcgTW9ja0FuaW1hdGlvblBsYXllcigpO1xuICAgICAgICAgdmFyIGVsZW1lbnQgPSBlbCgnPGRpdj48L2Rpdj4nKTtcblxuICAgICAgICAgdmFyIGxvb2t1cCA9IHt9O1xuICAgICAgICAgdmFyIHRyYWNrRm4gPSAobGV0dGVyKSA9PiB7IHJldHVybiAoKSA9PiB7IGxvb2t1cFtsZXR0ZXJdID0gdHJ1ZTsgfTsgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXVlLnNjaGVkdWxlKGVsZW1lbnQsIDEwMCwgcGxheWVyMSwgdHJhY2tGbignQScpKTtcblxuICAgICAgICAgcXVldWUuZmx1c2goKTtcblxuICAgICAgICAgZXhwZWN0KGxvb2t1cFsnQSddKS50b0JlRmFsc3koKTtcbiAgICAgICAgIGV4cGVjdChsb29rdXBbJ0InXSkudG9CZUZhbHN5KCk7XG5cbiAgICAgICAgIHF1ZXVlLnNjaGVkdWxlKGVsZW1lbnQsIDIwMCwgcGxheWVyMiwgdHJhY2tGbignQicpKTtcblxuICAgICAgICAgZXhwZWN0KGxvb2t1cFsnQSddKS50b0JlVHJ1dGh5KCk7XG4gICAgICAgICBleHBlY3QobG9va3VwWydCJ10pLnRvQmVGYWxzeSgpO1xuXG4gICAgICAgICBxdWV1ZS5zY2hlZHVsZShlbGVtZW50LCAxNTAsIHBsYXllcjMsIHRyYWNrRm4oJ0MnKSk7XG5cbiAgICAgICAgIGV4cGVjdChsb29rdXBbJ0EnXSkudG9CZVRydXRoeSgpO1xuICAgICAgICAgZXhwZWN0KGxvb2t1cFsnQiddKS50b0JlRmFsc3koKTtcbiAgICAgICAgIGV4cGVjdChsb29rdXBbJ0MnXSkudG9CZVRydXRoeSgpO1xuICAgICAgIH0pO1xuICB9KTtcbn1cbiJdfQ==
 main(); 
