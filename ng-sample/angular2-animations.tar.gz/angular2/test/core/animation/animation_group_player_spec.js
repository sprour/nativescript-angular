'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var animation_group_player_1 = require('angular2/src/core/animation/animation_group_player');
var mock_animation_player_1 = require('angular2/src/mock/mock_animation_player');
function main() {
    testing_internal_1.describe('AnimationGroupPlayer', function () {
        var players;
        testing_internal_1.beforeEach(function () {
            players = [
                new mock_animation_player_1.MockAnimationPlayer(),
                new mock_animation_player_1.MockAnimationPlayer(),
                new mock_animation_player_1.MockAnimationPlayer(),
            ];
        });
        var assertLastStatus = function (player, status, match) {
            var index = player.log.length - 1;
            var actual = player.log.length > 0 ? player.log[index] : null;
            if (match) {
                testing_internal_1.expect(actual).toEqual(status);
            }
            else {
                testing_internal_1.expect(actual).not.toEqual(status);
            }
        };
        var assertPlaying = function (player, isPlaying) {
            assertLastStatus(player, 'play', isPlaying);
        };
        testing_internal_1.it('should play and pause all players in parallel', function () {
            var group = new animation_group_player_1.AnimationGroupPlayer(players);
            assertPlaying(players[0], false);
            assertPlaying(players[1], false);
            assertPlaying(players[2], false);
            group.play();
            assertPlaying(players[0], true);
            assertPlaying(players[1], true);
            assertPlaying(players[2], true);
            group.pause();
            assertPlaying(players[0], false);
            assertPlaying(players[1], false);
            assertPlaying(players[2], false);
        });
        testing_internal_1.it('should finish when all players have finished', function () {
            var group = new animation_group_player_1.AnimationGroupPlayer(players);
            var completed = false;
            group.onDone(function () { return completed = true; });
            group.play();
            testing_internal_1.expect(completed).toBeFalsy();
            players[0].finish();
            testing_internal_1.expect(completed).toBeFalsy();
            players[1].finish();
            testing_internal_1.expect(completed).toBeFalsy();
            players[2].finish();
            testing_internal_1.expect(completed).toBeTruthy();
        });
        testing_internal_1.it('should restart all the players', function () {
            var group = new animation_group_player_1.AnimationGroupPlayer(players);
            group.play();
            assertLastStatus(players[0], 'restart', false);
            assertLastStatus(players[1], 'restart', false);
            assertLastStatus(players[2], 'restart', false);
            group.restart();
            assertLastStatus(players[0], 'restart', true);
            assertLastStatus(players[1], 'restart', true);
            assertLastStatus(players[2], 'restart', true);
        });
        testing_internal_1.it('should finish all the players', function () {
            var group = new animation_group_player_1.AnimationGroupPlayer(players);
            var completed = false;
            group.onDone(function () { return completed = true; });
            testing_internal_1.expect(completed).toBeFalsy();
            group.play();
            assertLastStatus(players[0], 'finish', false);
            assertLastStatus(players[1], 'finish', false);
            assertLastStatus(players[2], 'finish', false);
            testing_internal_1.expect(completed).toBeFalsy();
            group.finish();
            assertLastStatus(players[0], 'finish', true);
            assertLastStatus(players[1], 'finish', true);
            assertLastStatus(players[2], 'finish', true);
            testing_internal_1.expect(completed).toBeTruthy();
        });
        testing_internal_1.it('should destroy all the players', function () {
            var group = new animation_group_player_1.AnimationGroupPlayer(players);
            group.play();
            assertLastStatus(players[0], 'destroy', false);
            assertLastStatus(players[1], 'destroy', false);
            assertLastStatus(players[2], 'destroy', false);
            group.finish();
            assertLastStatus(players[0], 'destroy', false);
            assertLastStatus(players[1], 'destroy', false);
            assertLastStatus(players[2], 'destroy', false);
            group.destroy();
            assertLastStatus(players[0], 'destroy', true);
            assertLastStatus(players[1], 'destroy', true);
            assertLastStatus(players[2], 'destroy', true);
        });
        testing_internal_1.it('should function without any players', function () {
            var group = new animation_group_player_1.AnimationGroupPlayer([]);
            group.onDone(function () { });
            group.pause();
            group.play();
            group.finish();
            group.restart();
            group.destroy();
        });
        testing_internal_1.it('should call onDone after the next microtask if no players are provided', testing_internal_1.fakeAsync(function () {
            var group = new animation_group_player_1.AnimationGroupPlayer([]);
            var completed = false;
            group.onDone(function () { return completed = true; });
            testing_internal_1.expect(completed).toEqual(false);
            testing_internal_1.flushMicrotasks();
            testing_internal_1.expect(completed).toEqual(true);
        }));
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYW5pbWF0aW9uX2dyb3VwX3BsYXllcl9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb3JlL2FuaW1hdGlvbi9hbmltYXRpb25fZ3JvdXBfcGxheWVyX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiJdLCJtYXBwaW5ncyI6IkFBQUEsaUNBc0JPLDJCQUEyQixDQUFDLENBQUE7QUFHbkMsdUNBQW1DLG9EQUFvRCxDQUFDLENBQUE7QUFDeEYsc0NBQWtDLHlDQUF5QyxDQUFDLENBQUE7QUFFNUU7SUFDRUEsMkJBQVFBLENBQUNBLHNCQUFzQkEsRUFBRUE7UUFDL0IsSUFBSSxPQUFPLENBQUM7UUFDWiw2QkFBVSxDQUFDO1lBQ1QsT0FBTyxHQUFHO2dCQUNSLElBQUksMkNBQW1CLEVBQUU7Z0JBQ3pCLElBQUksMkNBQW1CLEVBQUU7Z0JBQ3pCLElBQUksMkNBQW1CLEVBQUU7YUFDMUIsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxnQkFBZ0IsR0FDaEIsVUFBQyxNQUEyQixFQUFFLE1BQWMsRUFBRSxLQUFjO1lBQzFELElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUNsQyxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUM7WUFDOUQsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztnQkFDVix5QkFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNqQyxDQUFDO1lBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ04seUJBQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3JDLENBQUM7UUFDSCxDQUFDLENBQUE7UUFFTCxJQUFJLGFBQWEsR0FBRyxVQUFDLE1BQTJCLEVBQUUsU0FBa0I7WUFDbEUsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQztRQUM5QyxDQUFDLENBQUM7UUFFRixxQkFBRSxDQUFDLCtDQUErQyxFQUFFO1lBQ2xELElBQUksS0FBSyxHQUFHLElBQUksNkNBQW9CLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFOUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNqQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ2pDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFakMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBRWIsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNoQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ2hDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFFaEMsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBRWQsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNqQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ2pDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDbkMsQ0FBQyxDQUFDLENBQUM7UUFFSCxxQkFBRSxDQUFDLDhDQUE4QyxFQUFFO1lBQ2pELElBQUksS0FBSyxHQUFHLElBQUksNkNBQW9CLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDOUMsSUFBSSxTQUFTLEdBQUcsS0FBSyxDQUFDO1lBQ3RCLEtBQUssQ0FBQyxNQUFNLENBQUMsY0FBTSxPQUFBLFNBQVMsR0FBRyxJQUFJLEVBQWhCLENBQWdCLENBQUMsQ0FBQztZQUVyQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7WUFFYix5QkFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBRTlCLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUVwQix5QkFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBRTlCLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUVwQix5QkFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBRTlCLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUVwQix5QkFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2pDLENBQUMsQ0FBQyxDQUFDO1FBRUgscUJBQUUsQ0FBQyxnQ0FBZ0MsRUFBRTtZQUNuQyxJQUFJLEtBQUssR0FBRyxJQUFJLDZDQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRTlDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUViLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDL0MsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUMvQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRS9DLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUVoQixnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzlDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDOUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNoRCxDQUFDLENBQUMsQ0FBQztRQUVILHFCQUFFLENBQUMsK0JBQStCLEVBQUU7WUFDbEMsSUFBSSxLQUFLLEdBQUcsSUFBSSw2Q0FBb0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUU5QyxJQUFJLFNBQVMsR0FBRyxLQUFLLENBQUM7WUFDdEIsS0FBSyxDQUFDLE1BQU0sQ0FBQyxjQUFNLE9BQUEsU0FBUyxHQUFHLElBQUksRUFBaEIsQ0FBZ0IsQ0FBQyxDQUFDO1lBRXJDLHlCQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7WUFFOUIsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBRWIsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUM5QyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzlDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFOUMseUJBQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUU5QixLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7WUFFZixnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzdDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDN0MsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUU3Qyx5QkFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2pDLENBQUMsQ0FBQyxDQUFDO1FBRUgscUJBQUUsQ0FBQyxnQ0FBZ0MsRUFBRTtZQUNuQyxJQUFJLEtBQUssR0FBRyxJQUFJLDZDQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRTlDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUViLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDL0MsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUMvQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRS9DLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUVmLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDL0MsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUMvQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRS9DLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUVoQixnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzlDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDOUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNoRCxDQUFDLENBQUMsQ0FBQztRQUVILHFCQUFFLENBQUMscUNBQXFDLEVBQUU7WUFDeEMsSUFBSSxLQUFLLEdBQUcsSUFBSSw2Q0FBb0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUN6QyxLQUFLLENBQUMsTUFBTSxDQUFDLGNBQU8sQ0FBQyxDQUFDLENBQUM7WUFDdkIsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ2QsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2IsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2YsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2hCLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNsQixDQUFDLENBQUMsQ0FBQztRQUVILHFCQUFFLENBQUMsd0VBQXdFLEVBQUUsNEJBQVMsQ0FBQztZQUNsRixJQUFJLEtBQUssR0FBRyxJQUFJLDZDQUFvQixDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3pDLElBQUksU0FBUyxHQUFHLEtBQUssQ0FBQztZQUN0QixLQUFLLENBQUMsTUFBTSxDQUFDLGNBQU0sT0FBQSxTQUFTLEdBQUcsSUFBSSxFQUFoQixDQUFnQixDQUFDLENBQUM7WUFDckMseUJBQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDakMsa0NBQWUsRUFBRSxDQUFDO1lBQ2xCLHlCQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDVCxDQUFDLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBdEplLFlBQUksT0FzSm5CLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBc3luY1Rlc3RDb21wbGV0ZXIsXG4gIGJlZm9yZUVhY2gsXG4gIGRkZXNjcmliZSxcbiAgeGRlc2NyaWJlLFxuICBkZXNjcmliZSxcbiAgZWwsXG4gIGRpc3BhdGNoRXZlbnQsXG4gIGV4cGVjdCxcbiAgaWl0LFxuICBpbmplY3QsXG4gIGJlZm9yZUVhY2hQcm92aWRlcnMsXG4gIGl0LFxuICB4aXQsXG4gIGNvbnRhaW5zUmVnZXhwLFxuICBzdHJpbmdpZnlFbGVtZW50LFxuICBUZXN0Q29tcG9uZW50QnVpbGRlcixcbiAgZmFrZUFzeW5jLFxuICBjbGVhclBlbmRpbmdUaW1lcnMsXG4gIENvbXBvbmVudEZpeHR1cmUsXG4gIHRpY2ssXG4gIGZsdXNoTWljcm90YXNrcyxcbn0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmltcG9ydCB7aXNQcmVzZW50fSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2xhbmcnO1xuaW1wb3J0IHtBbmltYXRpb25Hcm91cFBsYXllcn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvYW5pbWF0aW9uL2FuaW1hdGlvbl9ncm91cF9wbGF5ZXInO1xuaW1wb3J0IHtNb2NrQW5pbWF0aW9uUGxheWVyfSBmcm9tICdhbmd1bGFyMi9zcmMvbW9jay9tb2NrX2FuaW1hdGlvbl9wbGF5ZXInO1xuXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpIHtcbiAgZGVzY3JpYmUoJ0FuaW1hdGlvbkdyb3VwUGxheWVyJywgZnVuY3Rpb24oKSB7XG4gICAgdmFyIHBsYXllcnM7XG4gICAgYmVmb3JlRWFjaCgoKSA9PiB7XG4gICAgICBwbGF5ZXJzID0gW1xuICAgICAgICBuZXcgTW9ja0FuaW1hdGlvblBsYXllcigpLFxuICAgICAgICBuZXcgTW9ja0FuaW1hdGlvblBsYXllcigpLFxuICAgICAgICBuZXcgTW9ja0FuaW1hdGlvblBsYXllcigpLFxuICAgICAgXTtcbiAgICB9KTtcblxuICAgIHZhciBhc3NlcnRMYXN0U3RhdHVzID1cbiAgICAgICAgKHBsYXllcjogTW9ja0FuaW1hdGlvblBsYXllciwgc3RhdHVzOiBzdHJpbmcsIG1hdGNoOiBib29sZWFuKSA9PiB7XG4gICAgICAgICAgdmFyIGluZGV4ID0gcGxheWVyLmxvZy5sZW5ndGggLSAxO1xuICAgICAgICAgIHZhciBhY3R1YWwgPSBwbGF5ZXIubG9nLmxlbmd0aCA+IDAgPyBwbGF5ZXIubG9nW2luZGV4XSA6IG51bGw7XG4gICAgICAgICAgaWYgKG1hdGNoKSB7XG4gICAgICAgICAgICBleHBlY3QoYWN0dWFsKS50b0VxdWFsKHN0YXR1cyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGV4cGVjdChhY3R1YWwpLm5vdC50b0VxdWFsKHN0YXR1cyk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICB2YXIgYXNzZXJ0UGxheWluZyA9IChwbGF5ZXI6IE1vY2tBbmltYXRpb25QbGF5ZXIsIGlzUGxheWluZzogYm9vbGVhbikgPT4ge1xuICAgICAgYXNzZXJ0TGFzdFN0YXR1cyhwbGF5ZXIsICdwbGF5JywgaXNQbGF5aW5nKTtcbiAgICB9O1xuXG4gICAgaXQoJ3Nob3VsZCBwbGF5IGFuZCBwYXVzZSBhbGwgcGxheWVycyBpbiBwYXJhbGxlbCcsICgpID0+IHtcbiAgICAgIHZhciBncm91cCA9IG5ldyBBbmltYXRpb25Hcm91cFBsYXllcihwbGF5ZXJzKTtcblxuICAgICAgYXNzZXJ0UGxheWluZyhwbGF5ZXJzWzBdLCBmYWxzZSk7XG4gICAgICBhc3NlcnRQbGF5aW5nKHBsYXllcnNbMV0sIGZhbHNlKTtcbiAgICAgIGFzc2VydFBsYXlpbmcocGxheWVyc1syXSwgZmFsc2UpO1xuXG4gICAgICBncm91cC5wbGF5KCk7XG5cbiAgICAgIGFzc2VydFBsYXlpbmcocGxheWVyc1swXSwgdHJ1ZSk7XG4gICAgICBhc3NlcnRQbGF5aW5nKHBsYXllcnNbMV0sIHRydWUpO1xuICAgICAgYXNzZXJ0UGxheWluZyhwbGF5ZXJzWzJdLCB0cnVlKTtcblxuICAgICAgZ3JvdXAucGF1c2UoKTtcblxuICAgICAgYXNzZXJ0UGxheWluZyhwbGF5ZXJzWzBdLCBmYWxzZSk7XG4gICAgICBhc3NlcnRQbGF5aW5nKHBsYXllcnNbMV0sIGZhbHNlKTtcbiAgICAgIGFzc2VydFBsYXlpbmcocGxheWVyc1syXSwgZmFsc2UpO1xuICAgIH0pO1xuXG4gICAgaXQoJ3Nob3VsZCBmaW5pc2ggd2hlbiBhbGwgcGxheWVycyBoYXZlIGZpbmlzaGVkJywgKCkgPT4ge1xuICAgICAgdmFyIGdyb3VwID0gbmV3IEFuaW1hdGlvbkdyb3VwUGxheWVyKHBsYXllcnMpO1xuICAgICAgdmFyIGNvbXBsZXRlZCA9IGZhbHNlO1xuICAgICAgZ3JvdXAub25Eb25lKCgpID0+IGNvbXBsZXRlZCA9IHRydWUpO1xuXG4gICAgICBncm91cC5wbGF5KCk7XG5cbiAgICAgIGV4cGVjdChjb21wbGV0ZWQpLnRvQmVGYWxzeSgpO1xuXG4gICAgICBwbGF5ZXJzWzBdLmZpbmlzaCgpO1xuXG4gICAgICBleHBlY3QoY29tcGxldGVkKS50b0JlRmFsc3koKTtcblxuICAgICAgcGxheWVyc1sxXS5maW5pc2goKTtcblxuICAgICAgZXhwZWN0KGNvbXBsZXRlZCkudG9CZUZhbHN5KCk7XG5cbiAgICAgIHBsYXllcnNbMl0uZmluaXNoKCk7XG5cbiAgICAgIGV4cGVjdChjb21wbGV0ZWQpLnRvQmVUcnV0aHkoKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgcmVzdGFydCBhbGwgdGhlIHBsYXllcnMnLCAoKSA9PiB7XG4gICAgICB2YXIgZ3JvdXAgPSBuZXcgQW5pbWF0aW9uR3JvdXBQbGF5ZXIocGxheWVycyk7XG5cbiAgICAgIGdyb3VwLnBsYXkoKTtcblxuICAgICAgYXNzZXJ0TGFzdFN0YXR1cyhwbGF5ZXJzWzBdLCAncmVzdGFydCcsIGZhbHNlKTtcbiAgICAgIGFzc2VydExhc3RTdGF0dXMocGxheWVyc1sxXSwgJ3Jlc3RhcnQnLCBmYWxzZSk7XG4gICAgICBhc3NlcnRMYXN0U3RhdHVzKHBsYXllcnNbMl0sICdyZXN0YXJ0JywgZmFsc2UpO1xuXG4gICAgICBncm91cC5yZXN0YXJ0KCk7XG5cbiAgICAgIGFzc2VydExhc3RTdGF0dXMocGxheWVyc1swXSwgJ3Jlc3RhcnQnLCB0cnVlKTtcbiAgICAgIGFzc2VydExhc3RTdGF0dXMocGxheWVyc1sxXSwgJ3Jlc3RhcnQnLCB0cnVlKTtcbiAgICAgIGFzc2VydExhc3RTdGF0dXMocGxheWVyc1syXSwgJ3Jlc3RhcnQnLCB0cnVlKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgZmluaXNoIGFsbCB0aGUgcGxheWVycycsICgpID0+IHtcbiAgICAgIHZhciBncm91cCA9IG5ldyBBbmltYXRpb25Hcm91cFBsYXllcihwbGF5ZXJzKTtcblxuICAgICAgdmFyIGNvbXBsZXRlZCA9IGZhbHNlO1xuICAgICAgZ3JvdXAub25Eb25lKCgpID0+IGNvbXBsZXRlZCA9IHRydWUpO1xuXG4gICAgICBleHBlY3QoY29tcGxldGVkKS50b0JlRmFsc3koKTtcblxuICAgICAgZ3JvdXAucGxheSgpO1xuXG4gICAgICBhc3NlcnRMYXN0U3RhdHVzKHBsYXllcnNbMF0sICdmaW5pc2gnLCBmYWxzZSk7XG4gICAgICBhc3NlcnRMYXN0U3RhdHVzKHBsYXllcnNbMV0sICdmaW5pc2gnLCBmYWxzZSk7XG4gICAgICBhc3NlcnRMYXN0U3RhdHVzKHBsYXllcnNbMl0sICdmaW5pc2gnLCBmYWxzZSk7XG5cbiAgICAgIGV4cGVjdChjb21wbGV0ZWQpLnRvQmVGYWxzeSgpO1xuXG4gICAgICBncm91cC5maW5pc2goKTtcblxuICAgICAgYXNzZXJ0TGFzdFN0YXR1cyhwbGF5ZXJzWzBdLCAnZmluaXNoJywgdHJ1ZSk7XG4gICAgICBhc3NlcnRMYXN0U3RhdHVzKHBsYXllcnNbMV0sICdmaW5pc2gnLCB0cnVlKTtcbiAgICAgIGFzc2VydExhc3RTdGF0dXMocGxheWVyc1syXSwgJ2ZpbmlzaCcsIHRydWUpO1xuXG4gICAgICBleHBlY3QoY29tcGxldGVkKS50b0JlVHJ1dGh5KCk7XG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIGRlc3Ryb3kgYWxsIHRoZSBwbGF5ZXJzJywgKCkgPT4ge1xuICAgICAgdmFyIGdyb3VwID0gbmV3IEFuaW1hdGlvbkdyb3VwUGxheWVyKHBsYXllcnMpO1xuXG4gICAgICBncm91cC5wbGF5KCk7XG5cbiAgICAgIGFzc2VydExhc3RTdGF0dXMocGxheWVyc1swXSwgJ2Rlc3Ryb3knLCBmYWxzZSk7XG4gICAgICBhc3NlcnRMYXN0U3RhdHVzKHBsYXllcnNbMV0sICdkZXN0cm95JywgZmFsc2UpO1xuICAgICAgYXNzZXJ0TGFzdFN0YXR1cyhwbGF5ZXJzWzJdLCAnZGVzdHJveScsIGZhbHNlKTtcblxuICAgICAgZ3JvdXAuZmluaXNoKCk7XG5cbiAgICAgIGFzc2VydExhc3RTdGF0dXMocGxheWVyc1swXSwgJ2Rlc3Ryb3knLCBmYWxzZSk7XG4gICAgICBhc3NlcnRMYXN0U3RhdHVzKHBsYXllcnNbMV0sICdkZXN0cm95JywgZmFsc2UpO1xuICAgICAgYXNzZXJ0TGFzdFN0YXR1cyhwbGF5ZXJzWzJdLCAnZGVzdHJveScsIGZhbHNlKTtcblxuICAgICAgZ3JvdXAuZGVzdHJveSgpO1xuXG4gICAgICBhc3NlcnRMYXN0U3RhdHVzKHBsYXllcnNbMF0sICdkZXN0cm95JywgdHJ1ZSk7XG4gICAgICBhc3NlcnRMYXN0U3RhdHVzKHBsYXllcnNbMV0sICdkZXN0cm95JywgdHJ1ZSk7XG4gICAgICBhc3NlcnRMYXN0U3RhdHVzKHBsYXllcnNbMl0sICdkZXN0cm95JywgdHJ1ZSk7XG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIGZ1bmN0aW9uIHdpdGhvdXQgYW55IHBsYXllcnMnLCAoKSA9PiB7XG4gICAgICB2YXIgZ3JvdXAgPSBuZXcgQW5pbWF0aW9uR3JvdXBQbGF5ZXIoW10pO1xuICAgICAgZ3JvdXAub25Eb25lKCgpID0+IHt9KTtcbiAgICAgIGdyb3VwLnBhdXNlKCk7XG4gICAgICBncm91cC5wbGF5KCk7XG4gICAgICBncm91cC5maW5pc2goKTtcbiAgICAgIGdyb3VwLnJlc3RhcnQoKTtcbiAgICAgIGdyb3VwLmRlc3Ryb3koKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgY2FsbCBvbkRvbmUgYWZ0ZXIgdGhlIG5leHQgbWljcm90YXNrIGlmIG5vIHBsYXllcnMgYXJlIHByb3ZpZGVkJywgZmFrZUFzeW5jKCgpID0+IHtcbiAgICAgICAgIHZhciBncm91cCA9IG5ldyBBbmltYXRpb25Hcm91cFBsYXllcihbXSk7XG4gICAgICAgICB2YXIgY29tcGxldGVkID0gZmFsc2U7XG4gICAgICAgICBncm91cC5vbkRvbmUoKCkgPT4gY29tcGxldGVkID0gdHJ1ZSk7XG4gICAgICAgICBleHBlY3QoY29tcGxldGVkKS50b0VxdWFsKGZhbHNlKTtcbiAgICAgICAgIGZsdXNoTWljcm90YXNrcygpO1xuICAgICAgICAgZXhwZWN0KGNvbXBsZXRlZCkudG9FcXVhbCh0cnVlKTtcbiAgICAgICB9KSk7XG4gIH0pO1xufVxuIl19
 main(); 
