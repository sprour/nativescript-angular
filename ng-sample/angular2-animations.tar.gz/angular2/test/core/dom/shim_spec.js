'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
function main() {
    testing_internal_1.describe('Shim', function () {
        testing_internal_1.it('should provide correct function.name ', function () {
            var functionWithoutName = function (_) { };
            function foo(_) { }
            ;
            testing_internal_1.expect(functionWithoutName.name).toEqual('');
            testing_internal_1.expect(foo.name).toEqual('foo');
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2hpbV9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb3JlL2RvbS9zaGltX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiIsIm1haW4uZm9vIl0sIm1hcHBpbmdzIjoiQUFBQSxpQ0FXTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DO0lBQ0VBLDJCQUFRQSxDQUFDQSxNQUFNQSxFQUFFQTtRQUVmQSxxQkFBRUEsQ0FBQ0EsdUNBQXVDQSxFQUFFQTtZQUMxQ0EsSUFBSUEsbUJBQW1CQSxHQUFHQSxVQUFTQSxDQUFDQSxJQUFHLENBQUMsQ0FBQ0E7WUFDekNBLGFBQWFBLENBQUNBLElBQUVDLENBQUNBO1lBQUFELENBQUNBO1lBRWxCQSx5QkFBTUEsQ0FBT0EsbUJBQW9CQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtZQUNwREEseUJBQU1BLENBQU9BLEdBQUlBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO1FBQ3pDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUVMQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQVplLFlBQUksT0FZbkIsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFzeW5jVGVzdENvbXBsZXRlcixcbiAgYmVmb3JlRWFjaCxcbiAgZGRlc2NyaWJlLFxuICBkZXNjcmliZSxcbiAgZWwsXG4gIGV4cGVjdCxcbiAgaWl0LFxuICBpbmplY3QsXG4gIGl0LFxuICB4aXRcbn0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgnU2hpbScsICgpID0+IHtcblxuICAgIGl0KCdzaG91bGQgcHJvdmlkZSBjb3JyZWN0IGZ1bmN0aW9uLm5hbWUgJywgKCkgPT4ge1xuICAgICAgdmFyIGZ1bmN0aW9uV2l0aG91dE5hbWUgPSBmdW5jdGlvbihfKSB7fTtcbiAgICAgIGZ1bmN0aW9uIGZvbyhfKXt9O1xuXG4gICAgICBleHBlY3QoKDxhbnk+ZnVuY3Rpb25XaXRob3V0TmFtZSkubmFtZSkudG9FcXVhbCgnJyk7XG4gICAgICBleHBlY3QoKDxhbnk+Zm9vKS5uYW1lKS50b0VxdWFsKCdmb28nKTtcbiAgICB9KTtcblxuICB9KTtcbn1cbiJdfQ==
 main(); 
