'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var directive_resolver_1 = require('angular2/src/core/linker/directive_resolver');
var metadata_1 = require('angular2/src/core/metadata');
var SomeDirective = (function () {
    function SomeDirective() {
    }
    SomeDirective = __decorate([
        metadata_1.Directive({ selector: 'someDirective' }), 
        __metadata('design:paramtypes', [])
    ], SomeDirective);
    return SomeDirective;
})();
var SomeChildDirective = (function (_super) {
    __extends(SomeChildDirective, _super);
    function SomeChildDirective() {
        _super.apply(this, arguments);
    }
    SomeChildDirective = __decorate([
        metadata_1.Directive({ selector: 'someChildDirective' }), 
        __metadata('design:paramtypes', [])
    ], SomeChildDirective);
    return SomeChildDirective;
})(SomeDirective);
var SomeDirectiveWithInputs = (function () {
    function SomeDirectiveWithInputs() {
    }
    __decorate([
        metadata_1.Input(), 
        __metadata('design:type', Object)
    ], SomeDirectiveWithInputs.prototype, "a", void 0);
    __decorate([
        metadata_1.Input("renamed"), 
        __metadata('design:type', Object)
    ], SomeDirectiveWithInputs.prototype, "b", void 0);
    SomeDirectiveWithInputs = __decorate([
        metadata_1.Directive({ selector: 'someDirective', inputs: ['c'] }), 
        __metadata('design:paramtypes', [])
    ], SomeDirectiveWithInputs);
    return SomeDirectiveWithInputs;
})();
var SomeDirectiveWithOutputs = (function () {
    function SomeDirectiveWithOutputs() {
    }
    __decorate([
        metadata_1.Output(), 
        __metadata('design:type', Object)
    ], SomeDirectiveWithOutputs.prototype, "a", void 0);
    __decorate([
        metadata_1.Output("renamed"), 
        __metadata('design:type', Object)
    ], SomeDirectiveWithOutputs.prototype, "b", void 0);
    SomeDirectiveWithOutputs = __decorate([
        metadata_1.Directive({ selector: 'someDirective', outputs: ['c'] }), 
        __metadata('design:paramtypes', [])
    ], SomeDirectiveWithOutputs);
    return SomeDirectiveWithOutputs;
})();
var SomeDirectiveWithDuplicateOutputs = (function () {
    function SomeDirectiveWithDuplicateOutputs() {
    }
    __decorate([
        metadata_1.Output(), 
        __metadata('design:type', Object)
    ], SomeDirectiveWithDuplicateOutputs.prototype, "a", void 0);
    SomeDirectiveWithDuplicateOutputs = __decorate([
        metadata_1.Directive({ selector: 'someDirective', outputs: ['a'] }), 
        __metadata('design:paramtypes', [])
    ], SomeDirectiveWithDuplicateOutputs);
    return SomeDirectiveWithDuplicateOutputs;
})();
var SomeDirectiveWithProperties = (function () {
    function SomeDirectiveWithProperties() {
    }
    SomeDirectiveWithProperties = __decorate([
        metadata_1.Directive({ selector: 'someDirective', properties: ['a'] }), 
        __metadata('design:paramtypes', [])
    ], SomeDirectiveWithProperties);
    return SomeDirectiveWithProperties;
})();
var SomeDirectiveWithEvents = (function () {
    function SomeDirectiveWithEvents() {
    }
    SomeDirectiveWithEvents = __decorate([
        metadata_1.Directive({ selector: 'someDirective', events: ['a'] }), 
        __metadata('design:paramtypes', [])
    ], SomeDirectiveWithEvents);
    return SomeDirectiveWithEvents;
})();
var SomeDirectiveWithSetterProps = (function () {
    function SomeDirectiveWithSetterProps() {
    }
    Object.defineProperty(SomeDirectiveWithSetterProps.prototype, "a", {
        set: function (value) {
        },
        enumerable: true,
        configurable: true
    });
    __decorate([
        metadata_1.Input("renamed"), 
        __metadata('design:type', Object), 
        __metadata('design:paramtypes', [Object])
    ], SomeDirectiveWithSetterProps.prototype, "a", null);
    SomeDirectiveWithSetterProps = __decorate([
        metadata_1.Directive({ selector: 'someDirective' }), 
        __metadata('design:paramtypes', [])
    ], SomeDirectiveWithSetterProps);
    return SomeDirectiveWithSetterProps;
})();
var SomeDirectiveWithGetterOutputs = (function () {
    function SomeDirectiveWithGetterOutputs() {
    }
    Object.defineProperty(SomeDirectiveWithGetterOutputs.prototype, "a", {
        get: function () {
            return null;
        },
        enumerable: true,
        configurable: true
    });
    __decorate([
        metadata_1.Output("renamed"), 
        __metadata('design:type', Object)
    ], SomeDirectiveWithGetterOutputs.prototype, "a", null);
    SomeDirectiveWithGetterOutputs = __decorate([
        metadata_1.Directive({ selector: 'someDirective' }), 
        __metadata('design:paramtypes', [])
    ], SomeDirectiveWithGetterOutputs);
    return SomeDirectiveWithGetterOutputs;
})();
var SomeDirectiveWithHostBindings = (function () {
    function SomeDirectiveWithHostBindings() {
    }
    __decorate([
        metadata_1.HostBinding(), 
        __metadata('design:type', Object)
    ], SomeDirectiveWithHostBindings.prototype, "a", void 0);
    __decorate([
        metadata_1.HostBinding("renamed"), 
        __metadata('design:type', Object)
    ], SomeDirectiveWithHostBindings.prototype, "b", void 0);
    SomeDirectiveWithHostBindings = __decorate([
        metadata_1.Directive({ selector: 'someDirective', host: { '[c]': 'c' } }), 
        __metadata('design:paramtypes', [])
    ], SomeDirectiveWithHostBindings);
    return SomeDirectiveWithHostBindings;
})();
var SomeDirectiveWithHostListeners = (function () {
    function SomeDirectiveWithHostListeners() {
    }
    SomeDirectiveWithHostListeners.prototype.onA = function () {
    };
    SomeDirectiveWithHostListeners.prototype.onB = function (value) {
    };
    __decorate([
        metadata_1.HostListener('a'), 
        __metadata('design:type', Function), 
        __metadata('design:paramtypes', []), 
        __metadata('design:returntype', void 0)
    ], SomeDirectiveWithHostListeners.prototype, "onA", null);
    __decorate([
        metadata_1.HostListener('b', ['$event.value']), 
        __metadata('design:type', Function), 
        __metadata('design:paramtypes', [Object]), 
        __metadata('design:returntype', void 0)
    ], SomeDirectiveWithHostListeners.prototype, "onB", null);
    SomeDirectiveWithHostListeners = __decorate([
        metadata_1.Directive({ selector: 'someDirective', host: { '(c)': 'onC()' } }), 
        __metadata('design:paramtypes', [])
    ], SomeDirectiveWithHostListeners);
    return SomeDirectiveWithHostListeners;
})();
var SomeDirectiveWithContentChildren = (function () {
    function SomeDirectiveWithContentChildren() {
    }
    __decorate([
        metadata_1.ContentChildren("a"), 
        __metadata('design:type', Object)
    ], SomeDirectiveWithContentChildren.prototype, "as", void 0);
    SomeDirectiveWithContentChildren = __decorate([
        metadata_1.Directive({ selector: 'someDirective', queries: { "cs": new metadata_1.ContentChildren("c") } }), 
        __metadata('design:paramtypes', [])
    ], SomeDirectiveWithContentChildren);
    return SomeDirectiveWithContentChildren;
})();
var SomeDirectiveWithViewChildren = (function () {
    function SomeDirectiveWithViewChildren() {
    }
    __decorate([
        metadata_1.ViewChildren("a"), 
        __metadata('design:type', Object)
    ], SomeDirectiveWithViewChildren.prototype, "as", void 0);
    SomeDirectiveWithViewChildren = __decorate([
        metadata_1.Directive({ selector: 'someDirective', queries: { "cs": new metadata_1.ViewChildren("c") } }), 
        __metadata('design:paramtypes', [])
    ], SomeDirectiveWithViewChildren);
    return SomeDirectiveWithViewChildren;
})();
var SomeDirectiveWithContentChild = (function () {
    function SomeDirectiveWithContentChild() {
    }
    __decorate([
        metadata_1.ContentChild("a"), 
        __metadata('design:type', Object)
    ], SomeDirectiveWithContentChild.prototype, "a", void 0);
    SomeDirectiveWithContentChild = __decorate([
        metadata_1.Directive({ selector: 'someDirective', queries: { "c": new metadata_1.ContentChild("c") } }), 
        __metadata('design:paramtypes', [])
    ], SomeDirectiveWithContentChild);
    return SomeDirectiveWithContentChild;
})();
var SomeDirectiveWithViewChild = (function () {
    function SomeDirectiveWithViewChild() {
    }
    __decorate([
        metadata_1.ViewChild("a"), 
        __metadata('design:type', Object)
    ], SomeDirectiveWithViewChild.prototype, "a", void 0);
    SomeDirectiveWithViewChild = __decorate([
        metadata_1.Directive({ selector: 'someDirective', queries: { "c": new metadata_1.ViewChild("c") } }), 
        __metadata('design:paramtypes', [])
    ], SomeDirectiveWithViewChild);
    return SomeDirectiveWithViewChild;
})();
var SomeDirectiveWithoutMetadata = (function () {
    function SomeDirectiveWithoutMetadata() {
    }
    return SomeDirectiveWithoutMetadata;
})();
function main() {
    testing_internal_1.describe("DirectiveResolver", function () {
        var resolver;
        testing_internal_1.beforeEach(function () { resolver = new directive_resolver_1.DirectiveResolver(); });
        testing_internal_1.it('should read out the Directive metadata', function () {
            var directiveMetadata = resolver.resolve(SomeDirective);
            testing_internal_1.expect(directiveMetadata)
                .toEqual(new metadata_1.DirectiveMetadata({ selector: 'someDirective', inputs: [], outputs: [], host: {}, queries: {} }));
        });
        testing_internal_1.it('should throw if not matching metadata is found', function () {
            testing_internal_1.expect(function () { resolver.resolve(SomeDirectiveWithoutMetadata); })
                .toThrowError('No Directive annotation found on SomeDirectiveWithoutMetadata');
        });
        testing_internal_1.it('should not read parent class Directive metadata', function () {
            var directiveMetadata = resolver.resolve(SomeChildDirective);
            testing_internal_1.expect(directiveMetadata)
                .toEqual(new metadata_1.DirectiveMetadata({ selector: 'someChildDirective', inputs: [], outputs: [], host: {}, queries: {} }));
        });
        testing_internal_1.describe('inputs', function () {
            testing_internal_1.it('should append directive inputs', function () {
                var directiveMetadata = resolver.resolve(SomeDirectiveWithInputs);
                testing_internal_1.expect(directiveMetadata.inputs).toEqual(['c', 'a', 'b: renamed']);
            });
            testing_internal_1.it('should work with getters and setters', function () {
                var directiveMetadata = resolver.resolve(SomeDirectiveWithSetterProps);
                testing_internal_1.expect(directiveMetadata.inputs).toEqual(['a: renamed']);
            });
        });
        testing_internal_1.describe('outputs', function () {
            testing_internal_1.it('should append directive outputs', function () {
                var directiveMetadata = resolver.resolve(SomeDirectiveWithOutputs);
                testing_internal_1.expect(directiveMetadata.outputs).toEqual(['c', 'a', 'b: renamed']);
            });
            testing_internal_1.it('should work with getters and setters', function () {
                var directiveMetadata = resolver.resolve(SomeDirectiveWithGetterOutputs);
                testing_internal_1.expect(directiveMetadata.outputs).toEqual(['a: renamed']);
            });
            testing_internal_1.it('should throw if duplicate outputs', function () {
                testing_internal_1.expect(function () { resolver.resolve(SomeDirectiveWithDuplicateOutputs); })
                    .toThrowError("Output event 'a' defined multiple times in 'SomeDirectiveWithDuplicateOutputs'");
            });
        });
        testing_internal_1.describe('host', function () {
            testing_internal_1.it('should append host bindings', function () {
                var directiveMetadata = resolver.resolve(SomeDirectiveWithHostBindings);
                testing_internal_1.expect(directiveMetadata.host).toEqual({ '[c]': 'c', '[a]': 'a', '[renamed]': 'b' });
            });
            testing_internal_1.it('should append host listeners', function () {
                var directiveMetadata = resolver.resolve(SomeDirectiveWithHostListeners);
                testing_internal_1.expect(directiveMetadata.host)
                    .toEqual({ '(c)': 'onC()', '(a)': 'onA()', '(b)': 'onB($event.value)' });
            });
        });
        testing_internal_1.describe('queries', function () {
            testing_internal_1.it('should append ContentChildren', function () {
                var directiveMetadata = resolver.resolve(SomeDirectiveWithContentChildren);
                testing_internal_1.expect(directiveMetadata.queries)
                    .toEqual({ "cs": new metadata_1.ContentChildren("c"), "as": new metadata_1.ContentChildren("a") });
            });
            testing_internal_1.it('should append ViewChildren', function () {
                var directiveMetadata = resolver.resolve(SomeDirectiveWithViewChildren);
                testing_internal_1.expect(directiveMetadata.queries)
                    .toEqual({ "cs": new metadata_1.ViewChildren("c"), "as": new metadata_1.ViewChildren("a") });
            });
            testing_internal_1.it('should append ContentChild', function () {
                var directiveMetadata = resolver.resolve(SomeDirectiveWithContentChild);
                testing_internal_1.expect(directiveMetadata.queries)
                    .toEqual({ "c": new metadata_1.ContentChild("c"), "a": new metadata_1.ContentChild("a") });
            });
            testing_internal_1.it('should append ViewChild', function () {
                var directiveMetadata = resolver.resolve(SomeDirectiveWithViewChild);
                testing_internal_1.expect(directiveMetadata.queries)
                    .toEqual({ "c": new metadata_1.ViewChild("c"), "a": new metadata_1.ViewChild("a") });
            });
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlyZWN0aXZlX3Jlc29sdmVyX3NwZWMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L2NvcmUvbGlua2VyL2RpcmVjdGl2ZV9yZXNvbHZlcl9zcGVjLnRzIl0sIm5hbWVzIjpbIlNvbWVEaXJlY3RpdmUiLCJTb21lRGlyZWN0aXZlLmNvbnN0cnVjdG9yIiwiU29tZUNoaWxkRGlyZWN0aXZlIiwiU29tZUNoaWxkRGlyZWN0aXZlLmNvbnN0cnVjdG9yIiwiU29tZURpcmVjdGl2ZVdpdGhJbnB1dHMiLCJTb21lRGlyZWN0aXZlV2l0aElucHV0cy5jb25zdHJ1Y3RvciIsIlNvbWVEaXJlY3RpdmVXaXRoT3V0cHV0cyIsIlNvbWVEaXJlY3RpdmVXaXRoT3V0cHV0cy5jb25zdHJ1Y3RvciIsIlNvbWVEaXJlY3RpdmVXaXRoRHVwbGljYXRlT3V0cHV0cyIsIlNvbWVEaXJlY3RpdmVXaXRoRHVwbGljYXRlT3V0cHV0cy5jb25zdHJ1Y3RvciIsIlNvbWVEaXJlY3RpdmVXaXRoUHJvcGVydGllcyIsIlNvbWVEaXJlY3RpdmVXaXRoUHJvcGVydGllcy5jb25zdHJ1Y3RvciIsIlNvbWVEaXJlY3RpdmVXaXRoRXZlbnRzIiwiU29tZURpcmVjdGl2ZVdpdGhFdmVudHMuY29uc3RydWN0b3IiLCJTb21lRGlyZWN0aXZlV2l0aFNldHRlclByb3BzIiwiU29tZURpcmVjdGl2ZVdpdGhTZXR0ZXJQcm9wcy5jb25zdHJ1Y3RvciIsIlNvbWVEaXJlY3RpdmVXaXRoU2V0dGVyUHJvcHMuYSIsIlNvbWVEaXJlY3RpdmVXaXRoR2V0dGVyT3V0cHV0cyIsIlNvbWVEaXJlY3RpdmVXaXRoR2V0dGVyT3V0cHV0cy5jb25zdHJ1Y3RvciIsIlNvbWVEaXJlY3RpdmVXaXRoR2V0dGVyT3V0cHV0cy5hIiwiU29tZURpcmVjdGl2ZVdpdGhIb3N0QmluZGluZ3MiLCJTb21lRGlyZWN0aXZlV2l0aEhvc3RCaW5kaW5ncy5jb25zdHJ1Y3RvciIsIlNvbWVEaXJlY3RpdmVXaXRoSG9zdExpc3RlbmVycyIsIlNvbWVEaXJlY3RpdmVXaXRoSG9zdExpc3RlbmVycy5jb25zdHJ1Y3RvciIsIlNvbWVEaXJlY3RpdmVXaXRoSG9zdExpc3RlbmVycy5vbkEiLCJTb21lRGlyZWN0aXZlV2l0aEhvc3RMaXN0ZW5lcnMub25CIiwiU29tZURpcmVjdGl2ZVdpdGhDb250ZW50Q2hpbGRyZW4iLCJTb21lRGlyZWN0aXZlV2l0aENvbnRlbnRDaGlsZHJlbi5jb25zdHJ1Y3RvciIsIlNvbWVEaXJlY3RpdmVXaXRoVmlld0NoaWxkcmVuIiwiU29tZURpcmVjdGl2ZVdpdGhWaWV3Q2hpbGRyZW4uY29uc3RydWN0b3IiLCJTb21lRGlyZWN0aXZlV2l0aENvbnRlbnRDaGlsZCIsIlNvbWVEaXJlY3RpdmVXaXRoQ29udGVudENoaWxkLmNvbnN0cnVjdG9yIiwiU29tZURpcmVjdGl2ZVdpdGhWaWV3Q2hpbGQiLCJTb21lRGlyZWN0aXZlV2l0aFZpZXdDaGlsZC5jb25zdHJ1Y3RvciIsIlNvbWVEaXJlY3RpdmVXaXRob3V0TWV0YWRhdGEiLCJTb21lRGlyZWN0aXZlV2l0aG91dE1ldGFkYXRhLmNvbnN0cnVjdG9yIiwibWFpbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBQSxpQ0FBK0QsMkJBQTJCLENBQUMsQ0FBQTtBQUMzRixtQ0FBZ0MsNkNBQTZDLENBQUMsQ0FBQTtBQUM5RSx5QkFlTyw0QkFBNEIsQ0FBQyxDQUFBO0FBRXBDO0lBQUFBO0lBRUFDLENBQUNBO0lBRkREO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxlQUFlQSxFQUFDQSxDQUFDQTs7c0JBRXRDQTtJQUFEQSxvQkFBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDO0FBRUQ7SUFDaUNFLHNDQUFhQTtJQUQ5Q0E7UUFDaUNDLDhCQUFhQTtJQUM5Q0EsQ0FBQ0E7SUFGREQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLG9CQUFvQkEsRUFBQ0EsQ0FBQ0E7OzJCQUUzQ0E7SUFBREEseUJBQUNBO0FBQURBLENBQUNBLEFBRkQsRUFDaUMsYUFBYSxFQUM3QztBQUVEO0lBQUFFO0lBS0FDLENBQUNBO0lBSENEO1FBQUNBLGdCQUFLQSxFQUFFQTs7T0FBQ0Esc0NBQUNBLFVBQUNBO0lBQ1hBO1FBQUNBLGdCQUFLQSxDQUFDQSxTQUFTQSxDQUFDQTs7T0FBQ0Esc0NBQUNBLFVBQUNBO0lBSHRCQTtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsZUFBZUEsRUFBRUEsTUFBTUEsRUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7O2dDQUtyREE7SUFBREEsOEJBQUNBO0FBQURBLENBQUNBLEFBTEQsSUFLQztBQUVEO0lBQUFFO0lBS0FDLENBQUNBO0lBSENEO1FBQUNBLGlCQUFNQSxFQUFFQTs7T0FBQ0EsdUNBQUNBLFVBQUNBO0lBQ1pBO1FBQUNBLGlCQUFNQSxDQUFDQSxTQUFTQSxDQUFDQTs7T0FBQ0EsdUNBQUNBLFVBQUNBO0lBSHZCQTtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsZUFBZUEsRUFBRUEsT0FBT0EsRUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7O2lDQUt0REE7SUFBREEsK0JBQUNBO0FBQURBLENBQUNBLEFBTEQsSUFLQztBQUdEO0lBQUFFO0lBR0FDLENBQUNBO0lBRENEO1FBQUNBLGlCQUFNQSxFQUFFQTs7T0FBQ0EsZ0RBQUNBLFVBQUNBO0lBRmRBO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxlQUFlQSxFQUFFQSxPQUFPQSxFQUFFQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFDQSxDQUFDQTs7MENBR3REQTtJQUFEQSx3Q0FBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFBQUU7SUFFQUMsQ0FBQ0E7SUFGREQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLGVBQWVBLEVBQUVBLFVBQVVBLEVBQUVBLENBQUNBLEdBQUdBLENBQUNBLEVBQUNBLENBQUNBOztvQ0FFekRBO0lBQURBLGtDQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUM7QUFFRDtJQUFBRTtJQUVBQyxDQUFDQTtJQUZERDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsZUFBZUEsRUFBRUEsTUFBTUEsRUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7O2dDQUVyREE7SUFBREEsOEJBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBQUFFO0lBS0FDLENBQUNBO0lBSENELHNCQUNJQSwyQ0FBQ0E7YUFETEEsVUFDTUEsS0FBS0E7UUFDWEUsQ0FBQ0E7OztPQUFBRjtJQUZEQTtRQUFDQSxnQkFBS0EsQ0FBQ0EsU0FBU0EsQ0FBQ0E7OztPQUNiQSwyQ0FBQ0EsUUFDSkE7SUFKSEE7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLGVBQWVBLEVBQUNBLENBQUNBOztxQ0FLdENBO0lBQURBLG1DQUFDQTtBQUFEQSxDQUFDQSxBQUxELElBS0M7QUFFRDtJQUFBRztJQU1BQyxDQUFDQTtJQUpDRCxzQkFDSUEsNkNBQUNBO2FBRExBO1lBRUVFLE1BQU1BLENBQUNBLElBQUlBLENBQUNBO1FBQ2RBLENBQUNBOzs7T0FBQUY7SUFIREE7UUFBQ0EsaUJBQU1BLENBQUNBLFNBQVNBLENBQUNBOztPQUNkQSw2Q0FBQ0EsUUFFSkE7SUFMSEE7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLGVBQWVBLEVBQUNBLENBQUNBOzt1Q0FNdENBO0lBQURBLHFDQUFDQTtBQUFEQSxDQUFDQSxBQU5ELElBTUM7QUFFRDtJQUFBRztJQUtBQyxDQUFDQTtJQUhDRDtRQUFDQSxzQkFBV0EsRUFBRUE7O09BQUNBLDRDQUFDQSxVQUFDQTtJQUNqQkE7UUFBQ0Esc0JBQVdBLENBQUNBLFNBQVNBLENBQUNBOztPQUFDQSw0Q0FBQ0EsVUFBQ0E7SUFINUJBO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxlQUFlQSxFQUFFQSxJQUFJQSxFQUFFQSxFQUFDQSxLQUFLQSxFQUFFQSxHQUFHQSxFQUFDQSxFQUFDQSxDQUFDQTs7c0NBSzFEQTtJQUFEQSxvQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFMRCxJQUtDO0FBRUQ7SUFBQUU7SUFRQUMsQ0FBQ0E7SUFMQ0QsNENBQUdBLEdBREhBO0lBRUFFLENBQUNBO0lBRURGLDRDQUFHQSxHQURIQSxVQUNJQSxLQUFLQTtJQUNURyxDQUFDQTtJQUxESDtRQUFDQSx1QkFBWUEsQ0FBQ0EsR0FBR0EsQ0FBQ0E7Ozs7T0FDbEJBLCtDQUFHQSxRQUNGQTtJQUNEQTtRQUFDQSx1QkFBWUEsQ0FBQ0EsR0FBR0EsRUFBRUEsQ0FBQ0EsY0FBY0EsQ0FBQ0EsQ0FBQ0E7Ozs7T0FDcENBLCtDQUFHQSxRQUNGQTtJQVBIQTtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsZUFBZUEsRUFBRUEsSUFBSUEsRUFBRUEsRUFBQ0EsS0FBS0EsRUFBRUEsT0FBT0EsRUFBQ0EsRUFBQ0EsQ0FBQ0E7O3VDQVE5REE7SUFBREEscUNBQUNBO0FBQURBLENBQUNBLEFBUkQsSUFRQztBQUVEO0lBQUFJO0lBSUFDLENBQUNBO0lBRkNEO1FBQUNBLDBCQUFlQSxDQUFDQSxHQUFHQSxDQUFDQTs7T0FBQ0EsZ0RBQUVBLFVBQU1BO0lBRmhDQTtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsZUFBZUEsRUFBRUEsT0FBT0EsRUFBRUEsRUFBQ0EsSUFBSUEsRUFBRUEsSUFBSUEsMEJBQWVBLENBQUNBLEdBQUdBLENBQUNBLEVBQUNBLEVBQUNBLENBQUNBOzt5Q0FJakZBO0lBQURBLHVDQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQUFBRTtJQUlBQyxDQUFDQTtJQUZDRDtRQUFDQSx1QkFBWUEsQ0FBQ0EsR0FBR0EsQ0FBQ0E7O09BQUNBLDZDQUFFQSxVQUFNQTtJQUY3QkE7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLGVBQWVBLEVBQUVBLE9BQU9BLEVBQUVBLEVBQUNBLElBQUlBLEVBQUVBLElBQUlBLHVCQUFZQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFDQSxFQUFDQSxDQUFDQTs7c0NBSTlFQTtJQUFEQSxvQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFKRCxJQUlDO0FBRUQ7SUFBQUU7SUFJQUMsQ0FBQ0E7SUFGQ0Q7UUFBQ0EsdUJBQVlBLENBQUNBLEdBQUdBLENBQUNBOztPQUFDQSw0Q0FBQ0EsVUFBTUE7SUFGNUJBO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxlQUFlQSxFQUFFQSxPQUFPQSxFQUFFQSxFQUFDQSxHQUFHQSxFQUFFQSxJQUFJQSx1QkFBWUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBQ0EsRUFBQ0EsQ0FBQ0E7O3NDQUk3RUE7SUFBREEsb0NBQUNBO0FBQURBLENBQUNBLEFBSkQsSUFJQztBQUVEO0lBQUFFO0lBSUFDLENBQUNBO0lBRkNEO1FBQUNBLG9CQUFTQSxDQUFDQSxHQUFHQSxDQUFDQTs7T0FBQ0EseUNBQUNBLFVBQU1BO0lBRnpCQTtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsZUFBZUEsRUFBRUEsT0FBT0EsRUFBRUEsRUFBQ0EsR0FBR0EsRUFBRUEsSUFBSUEsb0JBQVNBLENBQUNBLEdBQUdBLENBQUNBLEVBQUNBLEVBQUNBLENBQUNBOzttQ0FJMUVBO0lBQURBLGlDQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQUFBRTtJQUFvQ0MsQ0FBQ0E7SUFBREQsbUNBQUNBO0FBQURBLENBQUNBLEFBQXJDLElBQXFDO0FBRXJDO0lBQ0VFLDJCQUFRQSxDQUFDQSxtQkFBbUJBLEVBQUVBO1FBQzVCQSxJQUFJQSxRQUEyQkEsQ0FBQ0E7UUFFaENBLDZCQUFVQSxDQUFDQSxjQUFRQSxRQUFRQSxHQUFHQSxJQUFJQSxzQ0FBaUJBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRTFEQSxxQkFBRUEsQ0FBQ0Esd0NBQXdDQSxFQUFFQTtZQUMzQ0EsSUFBSUEsaUJBQWlCQSxHQUFHQSxRQUFRQSxDQUFDQSxPQUFPQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtZQUN4REEseUJBQU1BLENBQUNBLGlCQUFpQkEsQ0FBQ0E7aUJBQ3BCQSxPQUFPQSxDQUFDQSxJQUFJQSw0QkFBaUJBLENBQzFCQSxFQUFDQSxRQUFRQSxFQUFFQSxlQUFlQSxFQUFFQSxNQUFNQSxFQUFFQSxFQUFFQSxFQUFFQSxPQUFPQSxFQUFFQSxFQUFFQSxFQUFFQSxJQUFJQSxFQUFFQSxFQUFFQSxFQUFFQSxPQUFPQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUN4RkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLGdEQUFnREEsRUFBRUE7WUFDbkRBLHlCQUFNQSxDQUFDQSxjQUFRQSxRQUFRQSxDQUFDQSxPQUFPQSxDQUFDQSw0QkFBNEJBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2lCQUM1REEsWUFBWUEsQ0FBQ0EsK0RBQStEQSxDQUFDQSxDQUFDQTtRQUNyRkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLGlEQUFpREEsRUFBRUE7WUFDcEQsSUFBSSxpQkFBaUIsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDN0QseUJBQU0sQ0FBQyxpQkFBaUIsQ0FBQztpQkFDcEIsT0FBTyxDQUFDLElBQUksNEJBQWlCLENBQzFCLEVBQUMsUUFBUSxFQUFFLG9CQUFvQixFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0YsQ0FBQyxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsUUFBUUEsRUFBRUE7WUFDakJBLHFCQUFFQSxDQUFDQSxnQ0FBZ0NBLEVBQUVBO2dCQUNuQ0EsSUFBSUEsaUJBQWlCQSxHQUFHQSxRQUFRQSxDQUFDQSxPQUFPQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBO2dCQUNsRUEseUJBQU1BLENBQUNBLGlCQUFpQkEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsWUFBWUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDckVBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxzQ0FBc0NBLEVBQUVBO2dCQUN6Q0EsSUFBSUEsaUJBQWlCQSxHQUFHQSxRQUFRQSxDQUFDQSxPQUFPQSxDQUFDQSw0QkFBNEJBLENBQUNBLENBQUNBO2dCQUN2RUEseUJBQU1BLENBQUNBLGlCQUFpQkEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDM0RBLENBQUNBLENBQUNBLENBQUNBO1FBRUxBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLDJCQUFRQSxDQUFDQSxTQUFTQSxFQUFFQTtZQUNsQkEscUJBQUVBLENBQUNBLGlDQUFpQ0EsRUFBRUE7Z0JBQ3BDQSxJQUFJQSxpQkFBaUJBLEdBQUdBLFFBQVFBLENBQUNBLE9BQU9BLENBQUNBLHdCQUF3QkEsQ0FBQ0EsQ0FBQ0E7Z0JBQ25FQSx5QkFBTUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxHQUFHQSxFQUFFQSxHQUFHQSxFQUFFQSxZQUFZQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUN0RUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLHNDQUFzQ0EsRUFBRUE7Z0JBQ3pDQSxJQUFJQSxpQkFBaUJBLEdBQUdBLFFBQVFBLENBQUNBLE9BQU9BLENBQUNBLDhCQUE4QkEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3pFQSx5QkFBTUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUM1REEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLG1DQUFtQ0EsRUFBRUE7Z0JBQ3RDQSx5QkFBTUEsQ0FBQ0EsY0FBUUEsUUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsaUNBQWlDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtxQkFDakVBLFlBQVlBLENBQ1RBLGdGQUFnRkEsQ0FBQ0EsQ0FBQ0E7WUFDNUZBLENBQUNBLENBQUNBLENBQUNBO1FBQ0xBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLDJCQUFRQSxDQUFDQSxNQUFNQSxFQUFFQTtZQUNmQSxxQkFBRUEsQ0FBQ0EsNkJBQTZCQSxFQUFFQTtnQkFDaENBLElBQUlBLGlCQUFpQkEsR0FBR0EsUUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsNkJBQTZCQSxDQUFDQSxDQUFDQTtnQkFDeEVBLHlCQUFNQSxDQUFDQSxpQkFBaUJBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEVBQUNBLEtBQUtBLEVBQUVBLEdBQUdBLEVBQUVBLEtBQUtBLEVBQUVBLEdBQUdBLEVBQUVBLFdBQVdBLEVBQUVBLEdBQUdBLEVBQUNBLENBQUNBLENBQUNBO1lBQ3JGQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsOEJBQThCQSxFQUFFQTtnQkFDakNBLElBQUlBLGlCQUFpQkEsR0FBR0EsUUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsOEJBQThCQSxDQUFDQSxDQUFDQTtnQkFDekVBLHlCQUFNQSxDQUFDQSxpQkFBaUJBLENBQUNBLElBQUlBLENBQUNBO3FCQUN6QkEsT0FBT0EsQ0FBQ0EsRUFBQ0EsS0FBS0EsRUFBRUEsT0FBT0EsRUFBRUEsS0FBS0EsRUFBRUEsT0FBT0EsRUFBRUEsS0FBS0EsRUFBRUEsbUJBQW1CQSxFQUFDQSxDQUFDQSxDQUFDQTtZQUM3RUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEsMkJBQVFBLENBQUNBLFNBQVNBLEVBQUVBO1lBQ2xCQSxxQkFBRUEsQ0FBQ0EsK0JBQStCQSxFQUFFQTtnQkFDbENBLElBQUlBLGlCQUFpQkEsR0FBR0EsUUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsZ0NBQWdDQSxDQUFDQSxDQUFDQTtnQkFDM0VBLHlCQUFNQSxDQUFDQSxpQkFBaUJBLENBQUNBLE9BQU9BLENBQUNBO3FCQUM1QkEsT0FBT0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsSUFBSUEsMEJBQWVBLENBQUNBLEdBQUdBLENBQUNBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLDBCQUFlQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFDQSxDQUFDQSxDQUFDQTtZQUNqRkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDRCQUE0QkEsRUFBRUE7Z0JBQy9CQSxJQUFJQSxpQkFBaUJBLEdBQUdBLFFBQVFBLENBQUNBLE9BQU9BLENBQUNBLDZCQUE2QkEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3hFQSx5QkFBTUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxPQUFPQSxDQUFDQTtxQkFDNUJBLE9BQU9BLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLElBQUlBLHVCQUFZQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSx1QkFBWUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDM0VBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSw0QkFBNEJBLEVBQUVBO2dCQUMvQkEsSUFBSUEsaUJBQWlCQSxHQUFHQSxRQUFRQSxDQUFDQSxPQUFPQSxDQUFDQSw2QkFBNkJBLENBQUNBLENBQUNBO2dCQUN4RUEseUJBQU1BLENBQUNBLGlCQUFpQkEsQ0FBQ0EsT0FBT0EsQ0FBQ0E7cUJBQzVCQSxPQUFPQSxDQUFDQSxFQUFDQSxHQUFHQSxFQUFFQSxJQUFJQSx1QkFBWUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBRUEsR0FBR0EsRUFBRUEsSUFBSUEsdUJBQVlBLENBQUNBLEdBQUdBLENBQUNBLEVBQUNBLENBQUNBLENBQUNBO1lBQ3pFQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EseUJBQXlCQSxFQUFFQTtnQkFDNUJBLElBQUlBLGlCQUFpQkEsR0FBR0EsUUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsMEJBQTBCQSxDQUFDQSxDQUFDQTtnQkFDckVBLHlCQUFNQSxDQUFDQSxpQkFBaUJBLENBQUNBLE9BQU9BLENBQUNBO3FCQUM1QkEsT0FBT0EsQ0FBQ0EsRUFBQ0EsR0FBR0EsRUFBRUEsSUFBSUEsb0JBQVNBLENBQUNBLEdBQUdBLENBQUNBLEVBQUVBLEdBQUdBLEVBQUVBLElBQUlBLG9CQUFTQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFDQSxDQUFDQSxDQUFDQTtZQUNuRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7QUFDTEEsQ0FBQ0E7QUEvRmUsWUFBSSxPQStGbkIsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7ZGRlc2NyaWJlLCBkZXNjcmliZSwgaXQsIGlpdCwgZXhwZWN0LCBiZWZvcmVFYWNofSBmcm9tICdhbmd1bGFyMi90ZXN0aW5nX2ludGVybmFsJztcbmltcG9ydCB7RGlyZWN0aXZlUmVzb2x2ZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci9kaXJlY3RpdmVfcmVzb2x2ZXInO1xuaW1wb3J0IHtcbiAgRGlyZWN0aXZlTWV0YWRhdGEsXG4gIERpcmVjdGl2ZSxcbiAgSW5wdXQsXG4gIE91dHB1dCxcbiAgSG9zdEJpbmRpbmcsXG4gIEhvc3RMaXN0ZW5lcixcbiAgQ29udGVudENoaWxkcmVuLFxuICBDb250ZW50Q2hpbGRyZW5NZXRhZGF0YSxcbiAgVmlld0NoaWxkcmVuLFxuICBWaWV3Q2hpbGRyZW5NZXRhZGF0YSxcbiAgQ29udGVudENoaWxkLFxuICBDb250ZW50Q2hpbGRNZXRhZGF0YSxcbiAgVmlld0NoaWxkLFxuICBWaWV3Q2hpbGRNZXRhZGF0YVxufSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9tZXRhZGF0YSc7XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnc29tZURpcmVjdGl2ZSd9KVxuY2xhc3MgU29tZURpcmVjdGl2ZSB7XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnc29tZUNoaWxkRGlyZWN0aXZlJ30pXG5jbGFzcyBTb21lQ2hpbGREaXJlY3RpdmUgZXh0ZW5kcyBTb21lRGlyZWN0aXZlIHtcbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdzb21lRGlyZWN0aXZlJywgaW5wdXRzOiBbJ2MnXX0pXG5jbGFzcyBTb21lRGlyZWN0aXZlV2l0aElucHV0cyB7XG4gIEBJbnB1dCgpIGE7XG4gIEBJbnB1dChcInJlbmFtZWRcIikgYjtcbiAgYztcbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdzb21lRGlyZWN0aXZlJywgb3V0cHV0czogWydjJ119KVxuY2xhc3MgU29tZURpcmVjdGl2ZVdpdGhPdXRwdXRzIHtcbiAgQE91dHB1dCgpIGE7XG4gIEBPdXRwdXQoXCJyZW5hbWVkXCIpIGI7XG4gIGM7XG59XG5cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdzb21lRGlyZWN0aXZlJywgb3V0cHV0czogWydhJ119KVxuY2xhc3MgU29tZURpcmVjdGl2ZVdpdGhEdXBsaWNhdGVPdXRwdXRzIHtcbiAgQE91dHB1dCgpIGE7XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnc29tZURpcmVjdGl2ZScsIHByb3BlcnRpZXM6IFsnYSddfSlcbmNsYXNzIFNvbWVEaXJlY3RpdmVXaXRoUHJvcGVydGllcyB7XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnc29tZURpcmVjdGl2ZScsIGV2ZW50czogWydhJ119KVxuY2xhc3MgU29tZURpcmVjdGl2ZVdpdGhFdmVudHMge1xufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJ3NvbWVEaXJlY3RpdmUnfSlcbmNsYXNzIFNvbWVEaXJlY3RpdmVXaXRoU2V0dGVyUHJvcHMge1xuICBASW5wdXQoXCJyZW5hbWVkXCIpXG4gIHNldCBhKHZhbHVlKSB7XG4gIH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdzb21lRGlyZWN0aXZlJ30pXG5jbGFzcyBTb21lRGlyZWN0aXZlV2l0aEdldHRlck91dHB1dHMge1xuICBAT3V0cHV0KFwicmVuYW1lZFwiKVxuICBnZXQgYSgpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJ3NvbWVEaXJlY3RpdmUnLCBob3N0OiB7J1tjXSc6ICdjJ319KVxuY2xhc3MgU29tZURpcmVjdGl2ZVdpdGhIb3N0QmluZGluZ3Mge1xuICBASG9zdEJpbmRpbmcoKSBhO1xuICBASG9zdEJpbmRpbmcoXCJyZW5hbWVkXCIpIGI7XG4gIGM7XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnc29tZURpcmVjdGl2ZScsIGhvc3Q6IHsnKGMpJzogJ29uQygpJ319KVxuY2xhc3MgU29tZURpcmVjdGl2ZVdpdGhIb3N0TGlzdGVuZXJzIHtcbiAgQEhvc3RMaXN0ZW5lcignYScpXG4gIG9uQSgpIHtcbiAgfVxuICBASG9zdExpc3RlbmVyKCdiJywgWyckZXZlbnQudmFsdWUnXSlcbiAgb25CKHZhbHVlKSB7XG4gIH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdzb21lRGlyZWN0aXZlJywgcXVlcmllczoge1wiY3NcIjogbmV3IENvbnRlbnRDaGlsZHJlbihcImNcIil9fSlcbmNsYXNzIFNvbWVEaXJlY3RpdmVXaXRoQ29udGVudENoaWxkcmVuIHtcbiAgQENvbnRlbnRDaGlsZHJlbihcImFcIikgYXM6IGFueTtcbiAgYztcbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdzb21lRGlyZWN0aXZlJywgcXVlcmllczoge1wiY3NcIjogbmV3IFZpZXdDaGlsZHJlbihcImNcIil9fSlcbmNsYXNzIFNvbWVEaXJlY3RpdmVXaXRoVmlld0NoaWxkcmVuIHtcbiAgQFZpZXdDaGlsZHJlbihcImFcIikgYXM6IGFueTtcbiAgYztcbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdzb21lRGlyZWN0aXZlJywgcXVlcmllczoge1wiY1wiOiBuZXcgQ29udGVudENoaWxkKFwiY1wiKX19KVxuY2xhc3MgU29tZURpcmVjdGl2ZVdpdGhDb250ZW50Q2hpbGQge1xuICBAQ29udGVudENoaWxkKFwiYVwiKSBhOiBhbnk7XG4gIGM7XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnc29tZURpcmVjdGl2ZScsIHF1ZXJpZXM6IHtcImNcIjogbmV3IFZpZXdDaGlsZChcImNcIil9fSlcbmNsYXNzIFNvbWVEaXJlY3RpdmVXaXRoVmlld0NoaWxkIHtcbiAgQFZpZXdDaGlsZChcImFcIikgYTogYW55O1xuICBjO1xufVxuXG5jbGFzcyBTb21lRGlyZWN0aXZlV2l0aG91dE1ldGFkYXRhIHt9XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZShcIkRpcmVjdGl2ZVJlc29sdmVyXCIsICgpID0+IHtcbiAgICB2YXIgcmVzb2x2ZXI6IERpcmVjdGl2ZVJlc29sdmVyO1xuXG4gICAgYmVmb3JlRWFjaCgoKSA9PiB7IHJlc29sdmVyID0gbmV3IERpcmVjdGl2ZVJlc29sdmVyKCk7IH0pO1xuXG4gICAgaXQoJ3Nob3VsZCByZWFkIG91dCB0aGUgRGlyZWN0aXZlIG1ldGFkYXRhJywgKCkgPT4ge1xuICAgICAgdmFyIGRpcmVjdGl2ZU1ldGFkYXRhID0gcmVzb2x2ZXIucmVzb2x2ZShTb21lRGlyZWN0aXZlKTtcbiAgICAgIGV4cGVjdChkaXJlY3RpdmVNZXRhZGF0YSlcbiAgICAgICAgICAudG9FcXVhbChuZXcgRGlyZWN0aXZlTWV0YWRhdGEoXG4gICAgICAgICAgICAgIHtzZWxlY3RvcjogJ3NvbWVEaXJlY3RpdmUnLCBpbnB1dHM6IFtdLCBvdXRwdXRzOiBbXSwgaG9zdDoge30sIHF1ZXJpZXM6IHt9fSkpO1xuICAgIH0pO1xuXG4gICAgaXQoJ3Nob3VsZCB0aHJvdyBpZiBub3QgbWF0Y2hpbmcgbWV0YWRhdGEgaXMgZm91bmQnLCAoKSA9PiB7XG4gICAgICBleHBlY3QoKCkgPT4geyByZXNvbHZlci5yZXNvbHZlKFNvbWVEaXJlY3RpdmVXaXRob3V0TWV0YWRhdGEpOyB9KVxuICAgICAgICAgIC50b1Rocm93RXJyb3IoJ05vIERpcmVjdGl2ZSBhbm5vdGF0aW9uIGZvdW5kIG9uIFNvbWVEaXJlY3RpdmVXaXRob3V0TWV0YWRhdGEnKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgbm90IHJlYWQgcGFyZW50IGNsYXNzIERpcmVjdGl2ZSBtZXRhZGF0YScsIGZ1bmN0aW9uKCkge1xuICAgICAgdmFyIGRpcmVjdGl2ZU1ldGFkYXRhID0gcmVzb2x2ZXIucmVzb2x2ZShTb21lQ2hpbGREaXJlY3RpdmUpO1xuICAgICAgZXhwZWN0KGRpcmVjdGl2ZU1ldGFkYXRhKVxuICAgICAgICAgIC50b0VxdWFsKG5ldyBEaXJlY3RpdmVNZXRhZGF0YShcbiAgICAgICAgICAgICAge3NlbGVjdG9yOiAnc29tZUNoaWxkRGlyZWN0aXZlJywgaW5wdXRzOiBbXSwgb3V0cHV0czogW10sIGhvc3Q6IHt9LCBxdWVyaWVzOiB7fX0pKTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKCdpbnB1dHMnLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIGFwcGVuZCBkaXJlY3RpdmUgaW5wdXRzJywgKCkgPT4ge1xuICAgICAgICB2YXIgZGlyZWN0aXZlTWV0YWRhdGEgPSByZXNvbHZlci5yZXNvbHZlKFNvbWVEaXJlY3RpdmVXaXRoSW5wdXRzKTtcbiAgICAgICAgZXhwZWN0KGRpcmVjdGl2ZU1ldGFkYXRhLmlucHV0cykudG9FcXVhbChbJ2MnLCAnYScsICdiOiByZW5hbWVkJ10pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgd29yayB3aXRoIGdldHRlcnMgYW5kIHNldHRlcnMnLCAoKSA9PiB7XG4gICAgICAgIHZhciBkaXJlY3RpdmVNZXRhZGF0YSA9IHJlc29sdmVyLnJlc29sdmUoU29tZURpcmVjdGl2ZVdpdGhTZXR0ZXJQcm9wcyk7XG4gICAgICAgIGV4cGVjdChkaXJlY3RpdmVNZXRhZGF0YS5pbnB1dHMpLnRvRXF1YWwoWydhOiByZW5hbWVkJ10pO1xuICAgICAgfSk7XG5cbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKCdvdXRwdXRzJywgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCBhcHBlbmQgZGlyZWN0aXZlIG91dHB1dHMnLCAoKSA9PiB7XG4gICAgICAgIHZhciBkaXJlY3RpdmVNZXRhZGF0YSA9IHJlc29sdmVyLnJlc29sdmUoU29tZURpcmVjdGl2ZVdpdGhPdXRwdXRzKTtcbiAgICAgICAgZXhwZWN0KGRpcmVjdGl2ZU1ldGFkYXRhLm91dHB1dHMpLnRvRXF1YWwoWydjJywgJ2EnLCAnYjogcmVuYW1lZCddKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHdvcmsgd2l0aCBnZXR0ZXJzIGFuZCBzZXR0ZXJzJywgKCkgPT4ge1xuICAgICAgICB2YXIgZGlyZWN0aXZlTWV0YWRhdGEgPSByZXNvbHZlci5yZXNvbHZlKFNvbWVEaXJlY3RpdmVXaXRoR2V0dGVyT3V0cHV0cyk7XG4gICAgICAgIGV4cGVjdChkaXJlY3RpdmVNZXRhZGF0YS5vdXRwdXRzKS50b0VxdWFsKFsnYTogcmVuYW1lZCddKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHRocm93IGlmIGR1cGxpY2F0ZSBvdXRwdXRzJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QoKCkgPT4geyByZXNvbHZlci5yZXNvbHZlKFNvbWVEaXJlY3RpdmVXaXRoRHVwbGljYXRlT3V0cHV0cyk7IH0pXG4gICAgICAgICAgICAudG9UaHJvd0Vycm9yKFxuICAgICAgICAgICAgICAgIGBPdXRwdXQgZXZlbnQgJ2EnIGRlZmluZWQgbXVsdGlwbGUgdGltZXMgaW4gJ1NvbWVEaXJlY3RpdmVXaXRoRHVwbGljYXRlT3V0cHV0cydgKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ2hvc3QnLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIGFwcGVuZCBob3N0IGJpbmRpbmdzJywgKCkgPT4ge1xuICAgICAgICB2YXIgZGlyZWN0aXZlTWV0YWRhdGEgPSByZXNvbHZlci5yZXNvbHZlKFNvbWVEaXJlY3RpdmVXaXRoSG9zdEJpbmRpbmdzKTtcbiAgICAgICAgZXhwZWN0KGRpcmVjdGl2ZU1ldGFkYXRhLmhvc3QpLnRvRXF1YWwoeydbY10nOiAnYycsICdbYV0nOiAnYScsICdbcmVuYW1lZF0nOiAnYid9KTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIGFwcGVuZCBob3N0IGxpc3RlbmVycycsICgpID0+IHtcbiAgICAgICAgdmFyIGRpcmVjdGl2ZU1ldGFkYXRhID0gcmVzb2x2ZXIucmVzb2x2ZShTb21lRGlyZWN0aXZlV2l0aEhvc3RMaXN0ZW5lcnMpO1xuICAgICAgICBleHBlY3QoZGlyZWN0aXZlTWV0YWRhdGEuaG9zdClcbiAgICAgICAgICAgIC50b0VxdWFsKHsnKGMpJzogJ29uQygpJywgJyhhKSc6ICdvbkEoKScsICcoYiknOiAnb25CKCRldmVudC52YWx1ZSknfSk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKCdxdWVyaWVzJywgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCBhcHBlbmQgQ29udGVudENoaWxkcmVuJywgKCkgPT4ge1xuICAgICAgICB2YXIgZGlyZWN0aXZlTWV0YWRhdGEgPSByZXNvbHZlci5yZXNvbHZlKFNvbWVEaXJlY3RpdmVXaXRoQ29udGVudENoaWxkcmVuKTtcbiAgICAgICAgZXhwZWN0KGRpcmVjdGl2ZU1ldGFkYXRhLnF1ZXJpZXMpXG4gICAgICAgICAgICAudG9FcXVhbCh7XCJjc1wiOiBuZXcgQ29udGVudENoaWxkcmVuKFwiY1wiKSwgXCJhc1wiOiBuZXcgQ29udGVudENoaWxkcmVuKFwiYVwiKX0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgYXBwZW5kIFZpZXdDaGlsZHJlbicsICgpID0+IHtcbiAgICAgICAgdmFyIGRpcmVjdGl2ZU1ldGFkYXRhID0gcmVzb2x2ZXIucmVzb2x2ZShTb21lRGlyZWN0aXZlV2l0aFZpZXdDaGlsZHJlbik7XG4gICAgICAgIGV4cGVjdChkaXJlY3RpdmVNZXRhZGF0YS5xdWVyaWVzKVxuICAgICAgICAgICAgLnRvRXF1YWwoe1wiY3NcIjogbmV3IFZpZXdDaGlsZHJlbihcImNcIiksIFwiYXNcIjogbmV3IFZpZXdDaGlsZHJlbihcImFcIil9KTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIGFwcGVuZCBDb250ZW50Q2hpbGQnLCAoKSA9PiB7XG4gICAgICAgIHZhciBkaXJlY3RpdmVNZXRhZGF0YSA9IHJlc29sdmVyLnJlc29sdmUoU29tZURpcmVjdGl2ZVdpdGhDb250ZW50Q2hpbGQpO1xuICAgICAgICBleHBlY3QoZGlyZWN0aXZlTWV0YWRhdGEucXVlcmllcylcbiAgICAgICAgICAgIC50b0VxdWFsKHtcImNcIjogbmV3IENvbnRlbnRDaGlsZChcImNcIiksIFwiYVwiOiBuZXcgQ29udGVudENoaWxkKFwiYVwiKX0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgYXBwZW5kIFZpZXdDaGlsZCcsICgpID0+IHtcbiAgICAgICAgdmFyIGRpcmVjdGl2ZU1ldGFkYXRhID0gcmVzb2x2ZXIucmVzb2x2ZShTb21lRGlyZWN0aXZlV2l0aFZpZXdDaGlsZCk7XG4gICAgICAgIGV4cGVjdChkaXJlY3RpdmVNZXRhZGF0YS5xdWVyaWVzKVxuICAgICAgICAgICAgLnRvRXF1YWwoe1wiY1wiOiBuZXcgVmlld0NoaWxkKFwiY1wiKSwgXCJhXCI6IG5ldyBWaWV3Q2hpbGQoXCJhXCIpfSk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfSk7XG59XG4iXX0=
 main(); 
