'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var dom_adapter_1 = require('angular2/src/platform/dom/dom_adapter');
var core_1 = require('angular2/core');
var common_dom_1 = require('angular2/platform/common_dom');
var debug_node_1 = require('angular2/src/core/debug/debug_node');
function main() {
    testing_internal_1.describe('projection', function () {
        testing_internal_1.it('should support simple components', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: '<simple>' +
                    '<div>A</div>' +
                    '</simple>',
                directives: [Simple]
            }))
                .createAsync(MainComp)
                .then(function (main) {
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('SIMPLE(A)');
                async.done();
            });
        }));
        testing_internal_1.it('should support simple components with text interpolation as direct children', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: '{{\'START(\'}}<simple>' +
                    '{{text}}' +
                    '</simple>{{\')END\'}}',
                directives: [Simple]
            }))
                .createAsync(MainComp)
                .then(function (main) {
                main.debugElement.componentInstance.text = 'A';
                main.detectChanges();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('START(SIMPLE(A))END');
                async.done();
            });
        }));
        testing_internal_1.it('should support projecting text interpolation to a non bound element', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(Simple, new core_1.ViewMetadata({ template: 'SIMPLE(<div><ng-content></ng-content></div>)', directives: [] }))
                .overrideView(MainComp, new core_1.ViewMetadata({ template: '<simple>{{text}}</simple>', directives: [Simple] }))
                .createAsync(MainComp)
                .then(function (main) {
                main.debugElement.componentInstance.text = 'A';
                main.detectChanges();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('SIMPLE(A)');
                async.done();
            });
        }));
        testing_internal_1.it('should support projecting text interpolation to a non bound element with other bound elements after it', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(Simple, new core_1.ViewMetadata({
                template: 'SIMPLE(<div><ng-content></ng-content></div><div [tabIndex]="0">EL</div>)',
                directives: []
            }))
                .overrideView(MainComp, new core_1.ViewMetadata({ template: '<simple>{{text}}</simple>', directives: [Simple] }))
                .createAsync(MainComp)
                .then(function (main) {
                main.debugElement.componentInstance.text = 'A';
                main.detectChanges();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('SIMPLE(AEL)');
                async.done();
            });
        }));
        testing_internal_1.it('should project content components', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(Simple, new core_1.ViewMetadata({ template: 'SIMPLE({{0}}|<ng-content></ng-content>|{{2}})', directives: [] }))
                .overrideView(OtherComp, new core_1.ViewMetadata({ template: '{{1}}', directives: [] }))
                .overrideView(MainComp, new core_1.ViewMetadata({
                template: '<simple><other></other></simple>',
                directives: [Simple, OtherComp]
            }))
                .createAsync(MainComp)
                .then(function (main) {
                main.detectChanges();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('SIMPLE(0|1|2)');
                async.done();
            });
        }));
        testing_internal_1.it('should not show the light dom even if there is no content tag', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({ template: '<empty>A</empty>', directives: [Empty] }))
                .createAsync(MainComp)
                .then(function (main) {
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('');
                async.done();
            });
        }));
        testing_internal_1.it('should support multiple content tags', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: '<multiple-content-tags>' +
                    '<div>B</div>' +
                    '<div>C</div>' +
                    '<div class="left">A</div>' +
                    '</multiple-content-tags>',
                directives: [MultipleContentTagsComponent]
            }))
                .createAsync(MainComp)
                .then(function (main) {
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(A, BC)');
                async.done();
            });
        }));
        testing_internal_1.it('should redistribute only direct children', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: '<multiple-content-tags>' +
                    '<div>B<div class="left">A</div></div>' +
                    '<div>C</div>' +
                    '</multiple-content-tags>',
                directives: [MultipleContentTagsComponent]
            }))
                .createAsync(MainComp)
                .then(function (main) {
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(, BAC)');
                async.done();
            });
        }));
        testing_internal_1.it("should redistribute direct child viewcontainers when the light dom changes", testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: '<multiple-content-tags>' +
                    '<template manual class="left"><div>A1</div></template>' +
                    '<div>B</div>' +
                    '</multiple-content-tags>',
                directives: [MultipleContentTagsComponent, ManualViewportDirective]
            }))
                .createAsync(MainComp)
                .then(function (main) {
                var viewportDirectives = main.debugElement.children[0]
                    .childNodes.filter(common_dom_1.By.directive(ManualViewportDirective))
                    .map(function (de) { return de.inject(ManualViewportDirective); });
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(, B)');
                viewportDirectives.forEach(function (d) { return d.show(); });
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(A1, B)');
                viewportDirectives.forEach(function (d) { return d.hide(); });
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(, B)');
                async.done();
            });
        }));
        testing_internal_1.it("should support nested components", testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: '<outer-with-indirect-nested>' +
                    '<div>A</div>' +
                    '<div>B</div>' +
                    '</outer-with-indirect-nested>',
                directives: [OuterWithIndirectNestedComponent]
            }))
                .createAsync(MainComp)
                .then(function (main) {
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('OUTER(SIMPLE(AB))');
                async.done();
            });
        }));
        testing_internal_1.it("should support nesting with content being direct child of a nested component", testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: '<outer>' +
                    '<template manual class="left"><div>A</div></template>' +
                    '<div>B</div>' +
                    '<div>C</div>' +
                    '</outer>',
                directives: [OuterComponent, ManualViewportDirective],
            }))
                .createAsync(MainComp)
                .then(function (main) {
                var viewportDirective = main.debugElement.queryAllNodes(common_dom_1.By.directive(ManualViewportDirective))[0].inject(ManualViewportDirective);
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('OUTER(INNER(INNERINNER(,BC)))');
                viewportDirective.show();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('OUTER(INNER(INNERINNER(A,BC)))');
                async.done();
            });
        }));
        testing_internal_1.it('should redistribute when the shadow dom changes', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: '<conditional-content>' +
                    '<div class="left">A</div>' +
                    '<div>B</div>' +
                    '<div>C</div>' +
                    '</conditional-content>',
                directives: [ConditionalContentComponent]
            }))
                .createAsync(MainComp)
                .then(function (main) {
                var viewportDirective = main.debugElement.queryAllNodes(common_dom_1.By.directive(ManualViewportDirective))[0].inject(ManualViewportDirective);
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(, BC)');
                viewportDirective.show();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(A, BC)');
                viewportDirective.hide();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(, BC)');
                async.done();
            });
        }));
        // GH-2095 - https://github.com/angular/angular/issues/2095
        // important as we are removing the ng-content element during compilation,
        // which could skrew up text node indices.
        testing_internal_1.it('should support text nodes after content tags', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({ template: '<simple stringProp="text"></simple>', directives: [Simple] }))
                .overrideTemplate(Simple, '<ng-content></ng-content><p>P,</p>{{stringProp}}')
                .createAsync(MainComp)
                .then(function (main) {
                main.detectChanges();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('P,text');
                async.done();
            });
        }));
        // important as we are moving style tags around during compilation,
        // which could skrew up text node indices.
        testing_internal_1.it('should support text nodes after style tags', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({ template: '<simple stringProp="text"></simple>', directives: [Simple] }))
                .overrideTemplate(Simple, '<style></style><p>P,</p>{{stringProp}}')
                .createAsync(MainComp)
                .then(function (main) {
                main.detectChanges();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('P,text');
                async.done();
            });
        }));
        testing_internal_1.it('should support moving non projected light dom around', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: '<empty>' +
                    '  <template manual><div>A</div></template>' +
                    '</empty>' +
                    'START(<div project></div>)END',
                directives: [Empty, ProjectDirective, ManualViewportDirective],
            }))
                .createAsync(MainComp)
                .then(function (main) {
                var sourceDirective;
                // We can't use the child nodes to get a hold of this because it's not in the dom at
                // all.
                debug_node_1.getAllDebugNodes().forEach(function (debug) {
                    if (debug.providerTokens.indexOf(ManualViewportDirective) !== -1) {
                        sourceDirective = debug.inject(ManualViewportDirective);
                    }
                });
                var projectDirective = main.debugElement.queryAllNodes(common_dom_1.By.directive(ProjectDirective))[0].inject(ProjectDirective);
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('START()END');
                projectDirective.show(sourceDirective.templateRef);
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('START(A)END');
                async.done();
            });
        }));
        testing_internal_1.it('should support moving projected light dom around', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: '<simple><template manual><div>A</div></template></simple>' +
                    'START(<div project></div>)END',
                directives: [Simple, ProjectDirective, ManualViewportDirective],
            }))
                .createAsync(MainComp)
                .then(function (main) {
                var sourceDirective = main.debugElement.queryAllNodes(common_dom_1.By.directive(ManualViewportDirective))[0].inject(ManualViewportDirective);
                var projectDirective = main.debugElement.queryAllNodes(common_dom_1.By.directive(ProjectDirective))[0].inject(ProjectDirective);
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('SIMPLE()START()END');
                projectDirective.show(sourceDirective.templateRef);
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('SIMPLE()START(A)END');
                async.done();
            });
        }));
        testing_internal_1.it('should support moving ng-content around', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: '<conditional-content>' +
                    '<div class="left">A</div>' +
                    '<div>B</div>' +
                    '</conditional-content>' +
                    'START(<div project></div>)END',
                directives: [ConditionalContentComponent, ProjectDirective, ManualViewportDirective]
            }))
                .createAsync(MainComp)
                .then(function (main) {
                var sourceDirective = main.debugElement.queryAllNodes(common_dom_1.By.directive(ManualViewportDirective))[0].inject(ManualViewportDirective);
                var projectDirective = main.debugElement.queryAllNodes(common_dom_1.By.directive(ProjectDirective))[0].inject(ProjectDirective);
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(, B)START()END');
                projectDirective.show(sourceDirective.templateRef);
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(, B)START(A)END');
                // Stamping ng-content multiple times should not produce the content multiple
                // times...
                projectDirective.show(sourceDirective.templateRef);
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(, B)START(A)END');
                async.done();
            });
        }));
        // Note: This does not use a ng-content element, but
        // is still important as we are merging proto views independent of
        // the presence of ng-content elements!
        testing_internal_1.it('should still allow to implement a recursive trees', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({ template: '<tree></tree>', directives: [Tree] }))
                .createAsync(MainComp)
                .then(function (main) {
                main.detectChanges();
                var manualDirective = main.debugElement.queryAllNodes(common_dom_1.By.directive(ManualViewportDirective))[0].inject(ManualViewportDirective);
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('TREE(0:)');
                manualDirective.show();
                main.detectChanges();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('TREE(0:TREE(1:))');
                async.done();
            });
        }));
        if (dom_adapter_1.DOM.supportsNativeShadowDOM()) {
            testing_internal_1.it('should support native content projection and isolate styles per component', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MainComp, new core_1.ViewMetadata({
                    template: '<simple-native1><div>A</div></simple-native1>' +
                        '<simple-native2><div>B</div></simple-native2>',
                    directives: [SimpleNative1, SimpleNative2]
                }))
                    .createAsync(MainComp)
                    .then(function (main) {
                    var childNodes = dom_adapter_1.DOM.childNodes(main.debugElement.nativeElement);
                    testing_internal_1.expect(childNodes[0]).toHaveText('div {color: red}SIMPLE1(A)');
                    testing_internal_1.expect(childNodes[1]).toHaveText('div {color: blue}SIMPLE2(B)');
                    main.destroy();
                    async.done();
                });
            }));
        }
        if (dom_adapter_1.DOM.supportsDOMEvents()) {
            testing_internal_1.it('should support emulated style encapsulation', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MainComp, new core_1.ViewMetadata({
                    template: '<div></div>',
                    styles: ['div { color: red}'],
                    encapsulation: core_1.ViewEncapsulation.Emulated
                }))
                    .createAsync(MainComp)
                    .then(function (main) {
                    var mainEl = main.debugElement.nativeElement;
                    var div1 = dom_adapter_1.DOM.firstChild(mainEl);
                    var div2 = dom_adapter_1.DOM.createElement('div');
                    dom_adapter_1.DOM.appendChild(mainEl, div2);
                    testing_internal_1.expect(dom_adapter_1.DOM.getComputedStyle(div1).color).toEqual('rgb(255, 0, 0)');
                    testing_internal_1.expect(dom_adapter_1.DOM.getComputedStyle(div2).color).toEqual('rgb(0, 0, 0)');
                    async.done();
                });
            }));
        }
        testing_internal_1.it('should support nested conditionals that contain ng-contents', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: "<conditional-text>a</conditional-text>",
                directives: [ConditionalTextComponent]
            }))
                .createAsync(MainComp)
                .then(function (main) {
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('MAIN()');
                var viewportElement = main.debugElement.queryAllNodes(common_dom_1.By.directive(ManualViewportDirective))[0];
                viewportElement.inject(ManualViewportDirective).show();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('MAIN(FIRST())');
                viewportElement =
                    main.debugElement.queryAllNodes(common_dom_1.By.directive(ManualViewportDirective))[1];
                viewportElement.inject(ManualViewportDirective).show();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('MAIN(FIRST(SECOND(a)))');
                async.done();
            });
        }));
        testing_internal_1.it('should allow to switch the order of nested components via ng-content', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: "<cmp-a><cmp-b></cmp-b></cmp-a>",
                directives: [CmpA, CmpB],
            }))
                .createAsync(MainComp)
                .then(function (main) {
                main.detectChanges();
                testing_internal_1.expect(dom_adapter_1.DOM.getInnerHTML(main.debugElement.nativeElement))
                    .toEqual('<cmp-a><cmp-b><cmp-d><d>cmp-d</d></cmp-d></cmp-b>' +
                    '<cmp-c><c>cmp-c</c></cmp-c></cmp-a>');
                async.done();
            });
        }));
        testing_internal_1.it('should create nested components in the right order', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: "<cmp-a1></cmp-a1><cmp-a2></cmp-a2>",
                directives: [CmpA1, CmpA2],
            }))
                .createAsync(MainComp)
                .then(function (main) {
                main.detectChanges();
                testing_internal_1.expect(dom_adapter_1.DOM.getInnerHTML(main.debugElement.nativeElement))
                    .toEqual('<cmp-a1>a1<cmp-b11>b11</cmp-b11><cmp-b12>b12</cmp-b12></cmp-a1>' +
                    '<cmp-a2>a2<cmp-b21>b21</cmp-b21><cmp-b22>b22</cmp-b22></cmp-a2>');
                async.done();
            });
        }));
        testing_internal_1.it('should project filled view containers into a view container', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MainComp, new core_1.ViewMetadata({
                template: '<conditional-content>' +
                    '<div class="left">A</div>' +
                    '<template manual class="left">B</template>' +
                    '<div class="left">C</div>' +
                    '<div>D</div>' +
                    '</conditional-content>',
                directives: [ConditionalContentComponent, ManualViewportDirective]
            }))
                .createAsync(MainComp)
                .then(function (main) {
                var conditionalComp = main.debugElement.query(common_dom_1.By.directive(ConditionalContentComponent));
                var viewViewportDir = conditionalComp.queryAllNodes(common_dom_1.By.directive(ManualViewportDirective))[0].inject(ManualViewportDirective);
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(, D)');
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(, D)');
                viewViewportDir.show();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(AC, D)');
                var contentViewportDir = conditionalComp.queryAllNodes(common_dom_1.By.directive(ManualViewportDirective))[1].inject(ManualViewportDirective);
                contentViewportDir.show();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(ABC, D)');
                // hide view viewport, and test that it also hides
                // the content viewport's views
                viewViewportDir.hide();
                testing_internal_1.expect(main.debugElement.nativeElement).toHaveText('(, D)');
                async.done();
            });
        }));
    });
}
exports.main = main;
var MainComp = (function () {
    function MainComp() {
        this.text = '';
    }
    MainComp = __decorate([
        core_1.Component({ selector: 'main', template: '', directives: [] }), 
        __metadata('design:paramtypes', [])
    ], MainComp);
    return MainComp;
})();
var OtherComp = (function () {
    function OtherComp() {
        this.text = '';
    }
    OtherComp = __decorate([
        core_1.Component({ selector: 'other', template: '', directives: [] }), 
        __metadata('design:paramtypes', [])
    ], OtherComp);
    return OtherComp;
})();
var Simple = (function () {
    function Simple() {
        this.stringProp = '';
    }
    Simple = __decorate([
        core_1.Component({
            selector: 'simple',
            inputs: ['stringProp'],
            template: 'SIMPLE(<ng-content></ng-content>)',
            directives: []
        }), 
        __metadata('design:paramtypes', [])
    ], Simple);
    return Simple;
})();
var SimpleNative1 = (function () {
    function SimpleNative1() {
    }
    SimpleNative1 = __decorate([
        core_1.Component({
            selector: 'simple-native1',
            template: 'SIMPLE1(<content></content>)',
            directives: [],
            encapsulation: core_1.ViewEncapsulation.Native,
            styles: ['div {color: red}']
        }), 
        __metadata('design:paramtypes', [])
    ], SimpleNative1);
    return SimpleNative1;
})();
var SimpleNative2 = (function () {
    function SimpleNative2() {
    }
    SimpleNative2 = __decorate([
        core_1.Component({
            selector: 'simple-native2',
            template: 'SIMPLE2(<content></content>)',
            directives: [],
            encapsulation: core_1.ViewEncapsulation.Native,
            styles: ['div {color: blue}']
        }), 
        __metadata('design:paramtypes', [])
    ], SimpleNative2);
    return SimpleNative2;
})();
var Empty = (function () {
    function Empty() {
    }
    Empty = __decorate([
        core_1.Component({ selector: 'empty', template: '', directives: [] }), 
        __metadata('design:paramtypes', [])
    ], Empty);
    return Empty;
})();
var MultipleContentTagsComponent = (function () {
    function MultipleContentTagsComponent() {
    }
    MultipleContentTagsComponent = __decorate([
        core_1.Component({
            selector: 'multiple-content-tags',
            template: '(<ng-content SELECT=".left"></ng-content>, <ng-content></ng-content>)',
            directives: []
        }), 
        __metadata('design:paramtypes', [])
    ], MultipleContentTagsComponent);
    return MultipleContentTagsComponent;
})();
var ManualViewportDirective = (function () {
    function ManualViewportDirective(vc, templateRef) {
        this.vc = vc;
        this.templateRef = templateRef;
    }
    ManualViewportDirective.prototype.show = function () { this.vc.createEmbeddedView(this.templateRef, 0); };
    ManualViewportDirective.prototype.hide = function () { this.vc.clear(); };
    ManualViewportDirective = __decorate([
        core_1.Directive({ selector: '[manual]' }), 
        __metadata('design:paramtypes', [core_1.ViewContainerRef, core_1.TemplateRef])
    ], ManualViewportDirective);
    return ManualViewportDirective;
})();
var ProjectDirective = (function () {
    function ProjectDirective(vc) {
        this.vc = vc;
    }
    ProjectDirective.prototype.show = function (templateRef) { this.vc.createEmbeddedView(templateRef, 0); };
    ProjectDirective.prototype.hide = function () { this.vc.clear(); };
    ProjectDirective = __decorate([
        core_1.Directive({ selector: '[project]' }), 
        __metadata('design:paramtypes', [core_1.ViewContainerRef])
    ], ProjectDirective);
    return ProjectDirective;
})();
var OuterWithIndirectNestedComponent = (function () {
    function OuterWithIndirectNestedComponent() {
    }
    OuterWithIndirectNestedComponent = __decorate([
        core_1.Component({
            selector: 'outer-with-indirect-nested',
            template: 'OUTER(<simple><div><ng-content></ng-content></div></simple>)',
            directives: [Simple]
        }), 
        __metadata('design:paramtypes', [])
    ], OuterWithIndirectNestedComponent);
    return OuterWithIndirectNestedComponent;
})();
var OuterComponent = (function () {
    function OuterComponent() {
    }
    OuterComponent = __decorate([
        core_1.Component({
            selector: 'outer',
            template: 'OUTER(<inner><ng-content select=".left" class="left"></ng-content><ng-content></ng-content></inner>)',
            directives: [core_1.forwardRef(function () { return InnerComponent; })]
        }), 
        __metadata('design:paramtypes', [])
    ], OuterComponent);
    return OuterComponent;
})();
var InnerComponent = (function () {
    function InnerComponent() {
    }
    InnerComponent = __decorate([
        core_1.Component({
            selector: 'inner',
            template: 'INNER(<innerinner><ng-content select=".left" class="left"></ng-content><ng-content></ng-content></innerinner>)',
            directives: [core_1.forwardRef(function () { return InnerInnerComponent; })]
        }), 
        __metadata('design:paramtypes', [])
    ], InnerComponent);
    return InnerComponent;
})();
var InnerInnerComponent = (function () {
    function InnerInnerComponent() {
    }
    InnerInnerComponent = __decorate([
        core_1.Component({
            selector: 'innerinner',
            template: 'INNERINNER(<ng-content select=".left"></ng-content>,<ng-content></ng-content>)',
            directives: []
        }), 
        __metadata('design:paramtypes', [])
    ], InnerInnerComponent);
    return InnerInnerComponent;
})();
var ConditionalContentComponent = (function () {
    function ConditionalContentComponent() {
    }
    ConditionalContentComponent = __decorate([
        core_1.Component({
            selector: 'conditional-content',
            template: '<div>(<div *manual><ng-content select=".left"></ng-content></div>, <ng-content></ng-content>)</div>',
            directives: [ManualViewportDirective]
        }), 
        __metadata('design:paramtypes', [])
    ], ConditionalContentComponent);
    return ConditionalContentComponent;
})();
var ConditionalTextComponent = (function () {
    function ConditionalTextComponent() {
    }
    ConditionalTextComponent = __decorate([
        core_1.Component({
            selector: 'conditional-text',
            template: 'MAIN(<template manual>FIRST(<template manual>SECOND(<ng-content></ng-content>)</template>)</template>)',
            directives: [ManualViewportDirective]
        }), 
        __metadata('design:paramtypes', [])
    ], ConditionalTextComponent);
    return ConditionalTextComponent;
})();
var Tab = (function () {
    function Tab() {
    }
    Tab = __decorate([
        core_1.Component({
            selector: 'tab',
            template: '<div><div *manual>TAB(<ng-content></ng-content>)</div></div>',
            directives: [ManualViewportDirective]
        }), 
        __metadata('design:paramtypes', [])
    ], Tab);
    return Tab;
})();
var Tree = (function () {
    function Tree() {
        this.depth = 0;
    }
    Tree = __decorate([
        core_1.Component({
            selector: 'tree',
            inputs: ['depth'],
            template: 'TREE({{depth}}:<tree *manual [depth]="depth+1"></tree>)',
            directives: [ManualViewportDirective, Tree]
        }), 
        __metadata('design:paramtypes', [])
    ], Tree);
    return Tree;
})();
var CmpD = (function () {
    function CmpD(elementRef) {
        this.tagName = dom_adapter_1.DOM.tagName(elementRef.nativeElement).toLowerCase();
    }
    CmpD = __decorate([
        core_1.Component({ selector: 'cmp-d', template: "<d>{{tagName}}</d>" }), 
        __metadata('design:paramtypes', [core_1.ElementRef])
    ], CmpD);
    return CmpD;
})();
var CmpC = (function () {
    function CmpC(elementRef) {
        this.tagName = dom_adapter_1.DOM.tagName(elementRef.nativeElement).toLowerCase();
    }
    CmpC = __decorate([
        core_1.Component({ selector: 'cmp-c', template: "<c>{{tagName}}</c>" }), 
        __metadata('design:paramtypes', [core_1.ElementRef])
    ], CmpC);
    return CmpC;
})();
var CmpB = (function () {
    function CmpB() {
    }
    CmpB = __decorate([
        core_1.Component({ selector: 'cmp-b', template: "<ng-content></ng-content><cmp-d></cmp-d>", directives: [CmpD] }), 
        __metadata('design:paramtypes', [])
    ], CmpB);
    return CmpB;
})();
var CmpA = (function () {
    function CmpA() {
    }
    CmpA = __decorate([
        core_1.Component({ selector: 'cmp-a', template: "<ng-content></ng-content><cmp-c></cmp-c>", directives: [CmpC] }), 
        __metadata('design:paramtypes', [])
    ], CmpA);
    return CmpA;
})();
var CmpB11 = (function () {
    function CmpB11() {
    }
    CmpB11 = __decorate([
        core_1.Component({ selector: 'cmp-b11', template: "{{'b11'}}", directives: [] }), 
        __metadata('design:paramtypes', [])
    ], CmpB11);
    return CmpB11;
})();
var CmpB12 = (function () {
    function CmpB12() {
    }
    CmpB12 = __decorate([
        core_1.Component({ selector: 'cmp-b12', template: "{{'b12'}}", directives: [] }), 
        __metadata('design:paramtypes', [])
    ], CmpB12);
    return CmpB12;
})();
var CmpB21 = (function () {
    function CmpB21() {
    }
    CmpB21 = __decorate([
        core_1.Component({ selector: 'cmp-b21', template: "{{'b21'}}", directives: [] }), 
        __metadata('design:paramtypes', [])
    ], CmpB21);
    return CmpB21;
})();
var CmpB22 = (function () {
    function CmpB22() {
    }
    CmpB22 = __decorate([
        core_1.Component({ selector: 'cmp-b22', template: "{{'b22'}}", directives: [] }), 
        __metadata('design:paramtypes', [])
    ], CmpB22);
    return CmpB22;
})();
var CmpA1 = (function () {
    function CmpA1() {
    }
    CmpA1 = __decorate([
        core_1.Component({ selector: 'cmp-a1', template: "{{'a1'}}<cmp-b11></cmp-b11><cmp-b12></cmp-b12>", directives: [CmpB11, CmpB12] }), 
        __metadata('design:paramtypes', [])
    ], CmpA1);
    return CmpA1;
})();
var CmpA2 = (function () {
    function CmpA2() {
    }
    CmpA2 = __decorate([
        core_1.Component({ selector: 'cmp-a2', template: "{{'a2'}}<cmp-b21></cmp-b21><cmp-b22></cmp-b22>", directives: [CmpB21, CmpB22] }), 
        __metadata('design:paramtypes', [])
    ], CmpA2);
    return CmpA2;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvamVjdGlvbl9pbnRlZ3JhdGlvbl9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb3JlL2xpbmtlci9wcm9qZWN0aW9uX2ludGVncmF0aW9uX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiIsIk1haW5Db21wIiwiTWFpbkNvbXAuY29uc3RydWN0b3IiLCJPdGhlckNvbXAiLCJPdGhlckNvbXAuY29uc3RydWN0b3IiLCJTaW1wbGUiLCJTaW1wbGUuY29uc3RydWN0b3IiLCJTaW1wbGVOYXRpdmUxIiwiU2ltcGxlTmF0aXZlMS5jb25zdHJ1Y3RvciIsIlNpbXBsZU5hdGl2ZTIiLCJTaW1wbGVOYXRpdmUyLmNvbnN0cnVjdG9yIiwiRW1wdHkiLCJFbXB0eS5jb25zdHJ1Y3RvciIsIk11bHRpcGxlQ29udGVudFRhZ3NDb21wb25lbnQiLCJNdWx0aXBsZUNvbnRlbnRUYWdzQ29tcG9uZW50LmNvbnN0cnVjdG9yIiwiTWFudWFsVmlld3BvcnREaXJlY3RpdmUiLCJNYW51YWxWaWV3cG9ydERpcmVjdGl2ZS5jb25zdHJ1Y3RvciIsIk1hbnVhbFZpZXdwb3J0RGlyZWN0aXZlLnNob3ciLCJNYW51YWxWaWV3cG9ydERpcmVjdGl2ZS5oaWRlIiwiUHJvamVjdERpcmVjdGl2ZSIsIlByb2plY3REaXJlY3RpdmUuY29uc3RydWN0b3IiLCJQcm9qZWN0RGlyZWN0aXZlLnNob3ciLCJQcm9qZWN0RGlyZWN0aXZlLmhpZGUiLCJPdXRlcldpdGhJbmRpcmVjdE5lc3RlZENvbXBvbmVudCIsIk91dGVyV2l0aEluZGlyZWN0TmVzdGVkQ29tcG9uZW50LmNvbnN0cnVjdG9yIiwiT3V0ZXJDb21wb25lbnQiLCJPdXRlckNvbXBvbmVudC5jb25zdHJ1Y3RvciIsIklubmVyQ29tcG9uZW50IiwiSW5uZXJDb21wb25lbnQuY29uc3RydWN0b3IiLCJJbm5lcklubmVyQ29tcG9uZW50IiwiSW5uZXJJbm5lckNvbXBvbmVudC5jb25zdHJ1Y3RvciIsIkNvbmRpdGlvbmFsQ29udGVudENvbXBvbmVudCIsIkNvbmRpdGlvbmFsQ29udGVudENvbXBvbmVudC5jb25zdHJ1Y3RvciIsIkNvbmRpdGlvbmFsVGV4dENvbXBvbmVudCIsIkNvbmRpdGlvbmFsVGV4dENvbXBvbmVudC5jb25zdHJ1Y3RvciIsIlRhYiIsIlRhYi5jb25zdHJ1Y3RvciIsIlRyZWUiLCJUcmVlLmNvbnN0cnVjdG9yIiwiQ21wRCIsIkNtcEQuY29uc3RydWN0b3IiLCJDbXBDIiwiQ21wQy5jb25zdHJ1Y3RvciIsIkNtcEIiLCJDbXBCLmNvbnN0cnVjdG9yIiwiQ21wQSIsIkNtcEEuY29uc3RydWN0b3IiLCJDbXBCMTEiLCJDbXBCMTEuY29uc3RydWN0b3IiLCJDbXBCMTIiLCJDbXBCMTIuY29uc3RydWN0b3IiLCJDbXBCMjEiLCJDbXBCMjEuY29uc3RydWN0b3IiLCJDbXBCMjIiLCJDbXBCMjIuY29uc3RydWN0b3IiLCJDbXBBMSIsIkNtcEExLmNvbnN0cnVjdG9yIiwiQ21wQTIiLCJDbXBBMi5jb25zdHJ1Y3RvciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEsaUNBb0JPLDJCQUEyQixDQUFDLENBQUE7QUFFbkMsNEJBQWtCLHVDQUF1QyxDQUFDLENBQUE7QUFFMUQscUJBV08sZUFBZSxDQUFDLENBQUE7QUFDdkIsMkJBRU8sOEJBQThCLENBQUMsQ0FBQTtBQUN0QywyQkFBK0Isb0NBQW9DLENBQUMsQ0FBQTtBQUVwRTtJQUNFQSwyQkFBUUEsQ0FBQ0EsWUFBWUEsRUFBRUE7UUFDckJBLHFCQUFFQSxDQUFDQSxrQ0FBa0NBLEVBQ2xDQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtZQUNsRkEsR0FBR0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsRUFBRUEsSUFBSUEsbUJBQVlBLENBQUNBO2dCQUN6QkEsUUFBUUEsRUFBRUEsVUFBVUE7b0JBQ05BLGNBQWNBO29CQUNkQSxXQUFXQTtnQkFDekJBLFVBQVVBLEVBQUVBLENBQUNBLE1BQU1BLENBQUNBO2FBQ3JCQSxDQUFDQSxDQUFDQTtpQkFDZkEsV0FBV0EsQ0FBQ0EsUUFBUUEsQ0FBQ0E7aUJBQ3JCQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtnQkFDVEEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO2dCQUNoRUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7WUFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFUEEscUJBQUVBLENBQUNBLDZFQUE2RUEsRUFDN0VBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO1lBQ2xGQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxFQUFFQSxJQUFJQSxtQkFBWUEsQ0FBQ0E7Z0JBQ3pCQSxRQUFRQSxFQUFFQSx3QkFBd0JBO29CQUNwQkEsVUFBVUE7b0JBQ1ZBLHVCQUF1QkE7Z0JBQ3JDQSxVQUFVQSxFQUFFQSxDQUFDQSxNQUFNQSxDQUFDQTthQUNyQkEsQ0FBQ0EsQ0FBQ0E7aUJBQ2ZBLFdBQVdBLENBQUNBLFFBQVFBLENBQUNBO2lCQUNyQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7Z0JBRVRBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsSUFBSUEsR0FBR0EsR0FBR0EsQ0FBQ0E7Z0JBQy9DQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtnQkFDckJBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxxQkFBcUJBLENBQUNBLENBQUNBO2dCQUMxRUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7WUFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFUEEscUJBQUVBLENBQUNBLHFFQUFxRUEsRUFDckVBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO1lBQ2xGQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUNUQSxNQUFNQSxFQUNOQSxJQUFJQSxtQkFBWUEsQ0FDWkEsRUFBQ0EsUUFBUUEsRUFBRUEsOENBQThDQSxFQUFFQSxVQUFVQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQSxDQUFDQTtpQkFDbEZBLFlBQVlBLENBQ1RBLFFBQVFBLEVBQ1JBLElBQUlBLG1CQUFZQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSwyQkFBMkJBLEVBQUVBLFVBQVVBLEVBQUVBLENBQUNBLE1BQU1BLENBQUNBLEVBQUNBLENBQUNBLENBQUNBO2lCQUNuRkEsV0FBV0EsQ0FBQ0EsUUFBUUEsQ0FBQ0E7aUJBQ3JCQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtnQkFFVEEsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxJQUFJQSxHQUFHQSxHQUFHQSxDQUFDQTtnQkFDL0NBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO2dCQUNyQkEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO2dCQUNoRUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7WUFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFHUEEscUJBQUVBLENBQUNBLHdHQUF3R0EsRUFDeEdBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO1lBQ2xGQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUNUQSxNQUFNQSxFQUFFQSxJQUFJQSxtQkFBWUEsQ0FBQ0E7Z0JBQ3ZCQSxRQUFRQSxFQUNKQSwwRUFBMEVBO2dCQUM5RUEsVUFBVUEsRUFBRUEsRUFBRUE7YUFDZkEsQ0FBQ0EsQ0FBQ0E7aUJBQ0xBLFlBQVlBLENBQ1RBLFFBQVFBLEVBQ1JBLElBQUlBLG1CQUFZQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSwyQkFBMkJBLEVBQUVBLFVBQVVBLEVBQUVBLENBQUNBLE1BQU1BLENBQUNBLEVBQUNBLENBQUNBLENBQUNBO2lCQUNuRkEsV0FBV0EsQ0FBQ0EsUUFBUUEsQ0FBQ0E7aUJBQ3JCQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtnQkFFVEEsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxJQUFJQSxHQUFHQSxHQUFHQSxDQUFDQTtnQkFDL0NBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO2dCQUNyQkEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBO2dCQUNsRUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7WUFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFUEEscUJBQUVBLENBQUNBLG1DQUFtQ0EsRUFDbkNBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO1lBQ2xGQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUNUQSxNQUFNQSxFQUNOQSxJQUFJQSxtQkFBWUEsQ0FDWkEsRUFBQ0EsUUFBUUEsRUFBRUEsK0NBQStDQSxFQUFFQSxVQUFVQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQSxDQUFDQTtpQkFDbkZBLFlBQVlBLENBQUNBLFNBQVNBLEVBQUVBLElBQUlBLG1CQUFZQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxPQUFPQSxFQUFFQSxVQUFVQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQSxDQUFDQTtpQkFDOUVBLFlBQVlBLENBQUNBLFFBQVFBLEVBQUVBLElBQUlBLG1CQUFZQSxDQUFDQTtnQkFDekJBLFFBQVFBLEVBQUVBLGtDQUFrQ0E7Z0JBQzVDQSxVQUFVQSxFQUFFQSxDQUFDQSxNQUFNQSxFQUFFQSxTQUFTQSxDQUFDQTthQUNoQ0EsQ0FBQ0EsQ0FBQ0E7aUJBQ2hCQSxXQUFXQSxDQUFDQSxRQUFRQSxDQUFDQTtpQkFDckJBLElBQUlBLENBQUNBLFVBQUNBLElBQUlBO2dCQUVUQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtnQkFDckJBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQTtnQkFDcEVBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLHFCQUFFQSxDQUFDQSwrREFBK0RBLEVBQy9EQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtZQUNsRkEsR0FBR0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsRUFDUkEsSUFBSUEsbUJBQVlBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLGtCQUFrQkEsRUFBRUEsVUFBVUEsRUFBRUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0E7aUJBQ2xGQSxXQUFXQSxDQUFDQSxRQUFRQSxDQUFDQTtpQkFDckJBLElBQUlBLENBQUNBLFVBQUNBLElBQUlBO2dCQUVUQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3ZEQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtZQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVQQSxxQkFBRUEsQ0FBQ0Esc0NBQXNDQSxFQUN0Q0EseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7WUFDbEZBLEdBQUdBLENBQUNBLFlBQVlBLENBQUNBLFFBQVFBLEVBQUVBLElBQUlBLG1CQUFZQSxDQUFDQTtnQkFDekJBLFFBQVFBLEVBQUVBLHlCQUF5QkE7b0JBQ3JCQSxjQUFjQTtvQkFDZEEsY0FBY0E7b0JBQ2RBLDJCQUEyQkE7b0JBQzNCQSwwQkFBMEJBO2dCQUN4Q0EsVUFBVUEsRUFBRUEsQ0FBQ0EsNEJBQTRCQSxDQUFDQTthQUMzQ0EsQ0FBQ0EsQ0FBQ0E7aUJBQ2ZBLFdBQVdBLENBQUNBLFFBQVFBLENBQUNBO2lCQUNyQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7Z0JBRVRBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQTtnQkFDOURBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLHFCQUFFQSxDQUFDQSwwQ0FBMENBLEVBQzFDQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtZQUNsRkEsR0FBR0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsRUFBRUEsSUFBSUEsbUJBQVlBLENBQUNBO2dCQUN6QkEsUUFBUUEsRUFBRUEseUJBQXlCQTtvQkFDckJBLHVDQUF1Q0E7b0JBQ3ZDQSxjQUFjQTtvQkFDZEEsMEJBQTBCQTtnQkFDeENBLFVBQVVBLEVBQUVBLENBQUNBLDRCQUE0QkEsQ0FBQ0E7YUFDM0NBLENBQUNBLENBQUNBO2lCQUNmQSxXQUFXQSxDQUFDQSxRQUFRQSxDQUFDQTtpQkFDckJBLElBQUlBLENBQUNBLFVBQUNBLElBQUlBO2dCQUVUQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzlEQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtZQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVQQSxxQkFBRUEsQ0FBQ0EsNEVBQTRFQSxFQUM1RUEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7WUFDbEZBLEdBQUdBLENBQUNBLFlBQVlBLENBQUNBLFFBQVFBLEVBQUVBLElBQUlBLG1CQUFZQSxDQUFDQTtnQkFDekJBLFFBQVFBLEVBQUVBLHlCQUF5QkE7b0JBQ3JCQSx3REFBd0RBO29CQUN4REEsY0FBY0E7b0JBQ2RBLDBCQUEwQkE7Z0JBQ3hDQSxVQUFVQSxFQUFFQSxDQUFDQSw0QkFBNEJBLEVBQUVBLHVCQUF1QkEsQ0FBQ0E7YUFDcEVBLENBQUNBLENBQUNBO2lCQUNmQSxXQUFXQSxDQUFDQSxRQUFRQSxDQUFDQTtpQkFDckJBLElBQUlBLENBQUNBLFVBQUNBLElBQUlBO2dCQUVUQSxJQUFJQSxrQkFBa0JBLEdBQ2xCQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQTtxQkFDeEJBLFVBQVVBLENBQUNBLE1BQU1BLENBQUNBLGVBQUVBLENBQUNBLFNBQVNBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0E7cUJBQ3hEQSxHQUFHQSxDQUFDQSxVQUFBQSxFQUFFQSxJQUFJQSxPQUFBQSxFQUFFQSxDQUFDQSxNQUFNQSxDQUFDQSx1QkFBdUJBLENBQUNBLEVBQWxDQSxDQUFrQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRXZEQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzVEQSxrQkFBa0JBLENBQUNBLE9BQU9BLENBQUNBLFVBQUFBLENBQUNBLElBQUlBLE9BQUFBLENBQUNBLENBQUNBLElBQUlBLEVBQUVBLEVBQVJBLENBQVFBLENBQUNBLENBQUNBO2dCQUMxQ0EseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBO2dCQUU5REEsa0JBQWtCQSxDQUFDQSxPQUFPQSxDQUFDQSxVQUFBQSxDQUFDQSxJQUFJQSxPQUFBQSxDQUFDQSxDQUFDQSxJQUFJQSxFQUFFQSxFQUFSQSxDQUFRQSxDQUFDQSxDQUFDQTtnQkFFMUNBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtnQkFDNURBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLHFCQUFFQSxDQUFDQSxrQ0FBa0NBLEVBQ2xDQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtZQUNsRkEsR0FBR0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsRUFBRUEsSUFBSUEsbUJBQVlBLENBQUNBO2dCQUN6QkEsUUFBUUEsRUFBRUEsOEJBQThCQTtvQkFDMUJBLGNBQWNBO29CQUNkQSxjQUFjQTtvQkFDZEEsK0JBQStCQTtnQkFDN0NBLFVBQVVBLEVBQUVBLENBQUNBLGdDQUFnQ0EsQ0FBQ0E7YUFDL0NBLENBQUNBLENBQUNBO2lCQUNmQSxXQUFXQSxDQUFDQSxRQUFRQSxDQUFDQTtpQkFDckJBLElBQUlBLENBQUNBLFVBQUNBLElBQUlBO2dCQUVUQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxDQUFDQTtnQkFDeEVBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLHFCQUFFQSxDQUFDQSw4RUFBOEVBLEVBQzlFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtZQUNsRkEsR0FBR0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsRUFBRUEsSUFBSUEsbUJBQVlBLENBQUNBO2dCQUN6QkEsUUFBUUEsRUFBRUEsU0FBU0E7b0JBQ0xBLHVEQUF1REE7b0JBQ3ZEQSxjQUFjQTtvQkFDZEEsY0FBY0E7b0JBQ2RBLFVBQVVBO2dCQUN4QkEsVUFBVUEsRUFBRUEsQ0FBQ0EsY0FBY0EsRUFBRUEsdUJBQXVCQSxDQUFDQTthQUN0REEsQ0FBQ0EsQ0FBQ0E7aUJBQ2ZBLFdBQVdBLENBQUNBLFFBQVFBLENBQUNBO2lCQUNyQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7Z0JBRVRBLElBQUlBLGlCQUFpQkEsR0FDakJBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLGVBQUVBLENBQUNBLFNBQVNBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FDNUVBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0E7Z0JBRWpDQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsK0JBQStCQSxDQUFDQSxDQUFDQTtnQkFDcEZBLGlCQUFpQkEsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBRXpCQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsZ0NBQWdDQSxDQUFDQSxDQUFDQTtnQkFDckZBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLHFCQUFFQSxDQUFDQSxpREFBaURBLEVBQ2pEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtZQUNsRkEsR0FBR0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsRUFBRUEsSUFBSUEsbUJBQVlBLENBQUNBO2dCQUN6QkEsUUFBUUEsRUFBRUEsdUJBQXVCQTtvQkFDbkJBLDJCQUEyQkE7b0JBQzNCQSxjQUFjQTtvQkFDZEEsY0FBY0E7b0JBQ2RBLHdCQUF3QkE7Z0JBQ3RDQSxVQUFVQSxFQUFFQSxDQUFDQSwyQkFBMkJBLENBQUNBO2FBQzFDQSxDQUFDQSxDQUFDQTtpQkFDZkEsV0FBV0EsQ0FBQ0EsUUFBUUEsQ0FBQ0E7aUJBQ3JCQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtnQkFFVEEsSUFBSUEsaUJBQWlCQSxHQUNqQkEsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsZUFBRUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsdUJBQXVCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxNQUFNQSxDQUM1RUEsdUJBQXVCQSxDQUFDQSxDQUFDQTtnQkFFakNBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtnQkFFN0RBLGlCQUFpQkEsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ3pCQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7Z0JBRTlEQSxpQkFBaUJBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUV6QkEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBO2dCQUM3REEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7WUFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFUEEsMkRBQTJEQTtRQUMzREEsMEVBQTBFQTtRQUMxRUEsMENBQTBDQTtRQUMxQ0EscUJBQUVBLENBQUNBLDhDQUE4Q0EsRUFDOUNBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO1lBRWxGQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUNUQSxRQUFRQSxFQUNSQSxJQUFJQSxtQkFBWUEsQ0FDWkEsRUFBQ0EsUUFBUUEsRUFBRUEscUNBQXFDQSxFQUFFQSxVQUFVQSxFQUFFQSxDQUFDQSxNQUFNQSxDQUFDQSxFQUFDQSxDQUFDQSxDQUFDQTtpQkFDL0VBLGdCQUFnQkEsQ0FBQ0EsTUFBTUEsRUFBRUEsa0RBQWtEQSxDQUFDQTtpQkFDNUVBLFdBQVdBLENBQUNBLFFBQVFBLENBQUNBO2lCQUNyQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBc0JBO2dCQUUzQkEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7Z0JBRXJCQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0E7Z0JBQzdEQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtZQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVQQSxtRUFBbUVBO1FBQ25FQSwwQ0FBMENBO1FBQzFDQSxxQkFBRUEsQ0FBQ0EsNENBQTRDQSxFQUM1Q0EseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7WUFFbEZBLEdBQUdBLENBQUNBLFlBQVlBLENBQ1RBLFFBQVFBLEVBQ1JBLElBQUlBLG1CQUFZQSxDQUNaQSxFQUFDQSxRQUFRQSxFQUFFQSxxQ0FBcUNBLEVBQUVBLFVBQVVBLEVBQUVBLENBQUNBLE1BQU1BLENBQUNBLEVBQUNBLENBQUNBLENBQUNBO2lCQUMvRUEsZ0JBQWdCQSxDQUFDQSxNQUFNQSxFQUFFQSx3Q0FBd0NBLENBQUNBO2lCQUNsRUEsV0FBV0EsQ0FBQ0EsUUFBUUEsQ0FBQ0E7aUJBQ3JCQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFzQkE7Z0JBRTNCQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtnQkFDckJBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtnQkFDN0RBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLHFCQUFFQSxDQUFDQSxzREFBc0RBLEVBQ3REQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtZQUNsRkEsR0FBR0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsRUFBRUEsSUFBSUEsbUJBQVlBLENBQUNBO2dCQUN6QkEsUUFBUUEsRUFBRUEsU0FBU0E7b0JBQ0xBLDRDQUE0Q0E7b0JBQzVDQSxVQUFVQTtvQkFDVkEsK0JBQStCQTtnQkFDN0NBLFVBQVVBLEVBQUVBLENBQUNBLEtBQUtBLEVBQUVBLGdCQUFnQkEsRUFBRUEsdUJBQXVCQSxDQUFDQTthQUMvREEsQ0FBQ0EsQ0FBQ0E7aUJBQ2ZBLFdBQVdBLENBQUNBLFFBQVFBLENBQUNBO2lCQUNyQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7Z0JBQ1RBLElBQUlBLGVBQWVBLENBQUNBO2dCQUVwQkEsb0ZBQW9GQTtnQkFDcEZBLE9BQU9BO2dCQUNQQSw2QkFBZ0JBLEVBQUVBLENBQUNBLE9BQU9BLENBQUNBLFVBQUNBLEtBQUtBO29CQUMvQkEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsY0FBY0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsdUJBQXVCQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDakVBLGVBQWVBLEdBQUdBLEtBQUtBLENBQUNBLE1BQU1BLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0E7b0JBQzFEQSxDQUFDQTtnQkFDSEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLElBQUlBLGdCQUFnQkEsR0FDaEJBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLGVBQUVBLENBQUNBLFNBQVNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FDckVBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0E7Z0JBRTFCQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0E7Z0JBRWpFQSxnQkFBZ0JBLENBQUNBLElBQUlBLENBQUNBLGVBQWVBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO2dCQUNuREEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBO2dCQUNsRUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7WUFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFUEEscUJBQUVBLENBQUNBLGtEQUFrREEsRUFDbERBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO1lBQ2xGQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxFQUFFQSxJQUFJQSxtQkFBWUEsQ0FBQ0E7Z0JBQ3pCQSxRQUFRQSxFQUFFQSwyREFBMkRBO29CQUN2REEsK0JBQStCQTtnQkFDN0NBLFVBQVVBLEVBQUVBLENBQUNBLE1BQU1BLEVBQUVBLGdCQUFnQkEsRUFBRUEsdUJBQXVCQSxDQUFDQTthQUNoRUEsQ0FBQ0EsQ0FBQ0E7aUJBQ2ZBLFdBQVdBLENBQUNBLFFBQVFBLENBQUNBO2lCQUNyQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7Z0JBRVRBLElBQUlBLGVBQWVBLEdBQ2ZBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLGVBQUVBLENBQUNBLFNBQVNBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FDNUVBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0E7Z0JBQ2pDQSxJQUFJQSxnQkFBZ0JBLEdBQ2hCQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxlQUFFQSxDQUFDQSxTQUFTQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLE1BQU1BLENBQ3JFQSxnQkFBZ0JBLENBQUNBLENBQUNBO2dCQUMxQkEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsQ0FBQ0E7Z0JBRXpFQSxnQkFBZ0JBLENBQUNBLElBQUlBLENBQUNBLGVBQWVBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO2dCQUNuREEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLHFCQUFxQkEsQ0FBQ0EsQ0FBQ0E7Z0JBQzFFQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtZQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVQQSxxQkFBRUEsQ0FBQ0EseUNBQXlDQSxFQUN6Q0EseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7WUFDbEZBLEdBQUdBLENBQUNBLFlBQVlBLENBQ1RBLFFBQVFBLEVBQUVBLElBQUlBLG1CQUFZQSxDQUFDQTtnQkFDekJBLFFBQVFBLEVBQUVBLHVCQUF1QkE7b0JBQ25CQSwyQkFBMkJBO29CQUMzQkEsY0FBY0E7b0JBQ2RBLHdCQUF3QkE7b0JBQ3hCQSwrQkFBK0JBO2dCQUM3Q0EsVUFBVUEsRUFDTkEsQ0FBQ0EsMkJBQTJCQSxFQUFFQSxnQkFBZ0JBLEVBQUVBLHVCQUF1QkEsQ0FBQ0E7YUFDN0VBLENBQUNBLENBQUNBO2lCQUNMQSxXQUFXQSxDQUFDQSxRQUFRQSxDQUFDQTtpQkFDckJBLElBQUlBLENBQUNBLFVBQUNBLElBQUlBO2dCQUVUQSxJQUFJQSxlQUFlQSxHQUNmQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxlQUFFQSxDQUFDQSxTQUFTQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLE1BQU1BLENBQzVFQSx1QkFBdUJBLENBQUNBLENBQUNBO2dCQUNqQ0EsSUFBSUEsZ0JBQWdCQSxHQUNoQkEsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsZUFBRUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxNQUFNQSxDQUNyRUEsZ0JBQWdCQSxDQUFDQSxDQUFDQTtnQkFDMUJBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBO2dCQUV0RUEsZ0JBQWdCQSxDQUFDQSxJQUFJQSxDQUFDQSxlQUFlQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQTtnQkFDbkRBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxrQkFBa0JBLENBQUNBLENBQUNBO2dCQUV2RUEsNkVBQTZFQTtnQkFDN0VBLFdBQVdBO2dCQUNYQSxnQkFBZ0JBLENBQUNBLElBQUlBLENBQUNBLGVBQWVBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO2dCQUNuREEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3ZFQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtZQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUdQQSxvREFBb0RBO1FBQ3BEQSxrRUFBa0VBO1FBQ2xFQSx1Q0FBdUNBO1FBQ3ZDQSxxQkFBRUEsQ0FBQ0EsbURBQW1EQSxFQUNuREEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7WUFDbEZBLEdBQUdBLENBQUNBLFlBQVlBLENBQUNBLFFBQVFBLEVBQ1JBLElBQUlBLG1CQUFZQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxlQUFlQSxFQUFFQSxVQUFVQSxFQUFFQSxDQUFDQSxJQUFJQSxDQUFDQSxFQUFDQSxDQUFDQSxDQUFDQTtpQkFDOUVBLFdBQVdBLENBQUNBLFFBQVFBLENBQUNBO2lCQUNyQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7Z0JBRVRBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO2dCQUNyQkEsSUFBSUEsZUFBZUEsR0FDZkEsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsZUFBRUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsdUJBQXVCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxNQUFNQSxDQUM1RUEsdUJBQXVCQSxDQUFDQSxDQUFDQTtnQkFDakNBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQTtnQkFDL0RBLGVBQWVBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUN2QkEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7Z0JBQ3JCQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxDQUFDQTtnQkFDdkVBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLEVBQUVBLENBQUNBLENBQUNBLGlCQUFHQSxDQUFDQSx1QkFBdUJBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO1lBQ2xDQSxxQkFBRUEsQ0FBQ0EsMkVBQTJFQSxFQUMzRUEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7Z0JBQ2xGQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxFQUFFQSxJQUFJQSxtQkFBWUEsQ0FBQ0E7b0JBQ3pCQSxRQUFRQSxFQUFFQSwrQ0FBK0NBO3dCQUMzQ0EsK0NBQStDQTtvQkFDN0RBLFVBQVVBLEVBQUVBLENBQUNBLGFBQWFBLEVBQUVBLGFBQWFBLENBQUNBO2lCQUMzQ0EsQ0FBQ0EsQ0FBQ0E7cUJBQ2ZBLFdBQVdBLENBQUNBLFFBQVFBLENBQUNBO3FCQUNyQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7b0JBQ1RBLElBQUlBLFVBQVVBLEdBQUdBLGlCQUFHQSxDQUFDQSxVQUFVQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtvQkFDakVBLHlCQUFNQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSw0QkFBNEJBLENBQUNBLENBQUNBO29CQUMvREEseUJBQU1BLENBQUNBLFVBQVVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLDZCQUE2QkEsQ0FBQ0EsQ0FBQ0E7b0JBQ2hFQSxJQUFJQSxDQUFDQSxPQUFPQSxFQUFFQSxDQUFDQTtvQkFDZkEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBO1FBRURBLEVBQUVBLENBQUNBLENBQUNBLGlCQUFHQSxDQUFDQSxpQkFBaUJBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO1lBQzVCQSxxQkFBRUEsQ0FBQ0EsNkNBQTZDQSxFQUM3Q0EseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7Z0JBQ2xGQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxFQUFFQSxJQUFJQSxtQkFBWUEsQ0FBQ0E7b0JBQ3pCQSxRQUFRQSxFQUFFQSxhQUFhQTtvQkFDdkJBLE1BQU1BLEVBQUVBLENBQUNBLG1CQUFtQkEsQ0FBQ0E7b0JBQzdCQSxhQUFhQSxFQUFFQSx3QkFBaUJBLENBQUNBLFFBQVFBO2lCQUMxQ0EsQ0FBQ0EsQ0FBQ0E7cUJBQ2ZBLFdBQVdBLENBQUNBLFFBQVFBLENBQUNBO3FCQUNyQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7b0JBQ1RBLElBQUlBLE1BQU1BLEdBQUdBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBO29CQUM3Q0EsSUFBSUEsSUFBSUEsR0FBR0EsaUJBQUdBLENBQUNBLFVBQVVBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO29CQUNsQ0EsSUFBSUEsSUFBSUEsR0FBR0EsaUJBQUdBLENBQUNBLGFBQWFBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO29CQUNwQ0EsaUJBQUdBLENBQUNBLFdBQVdBLENBQUNBLE1BQU1BLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO29CQUM5QkEseUJBQU1BLENBQUNBLGlCQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0E7b0JBQ25FQSx5QkFBTUEsQ0FBQ0EsaUJBQUdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsY0FBY0EsQ0FBQ0EsQ0FBQ0E7b0JBQ2pFQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0E7UUFFREEscUJBQUVBLENBQUNBLDZEQUE2REEsRUFDN0RBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO1lBQ2xGQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxFQUFFQSxJQUFJQSxtQkFBWUEsQ0FBQ0E7Z0JBQ3pCQSxRQUFRQSxFQUFFQSx3Q0FBd0NBO2dCQUNsREEsVUFBVUEsRUFBRUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQTthQUN2Q0EsQ0FBQ0EsQ0FBQ0E7aUJBQ2ZBLFdBQVdBLENBQUNBLFFBQVFBLENBQUNBO2lCQUNyQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7Z0JBQ1RBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtnQkFFN0RBLElBQUlBLGVBQWVBLEdBQ2ZBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLGVBQUVBLENBQUNBLFNBQVNBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzlFQSxlQUFlQSxDQUFDQSxNQUFNQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUN2REEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLGVBQWVBLENBQUNBLENBQUNBO2dCQUVwRUEsZUFBZUE7b0JBQ1hBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLGVBQUVBLENBQUNBLFNBQVNBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzlFQSxlQUFlQSxDQUFDQSxNQUFNQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUN2REEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLHdCQUF3QkEsQ0FBQ0EsQ0FBQ0E7Z0JBRTdFQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtZQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVQQSxxQkFBRUEsQ0FBQ0Esc0VBQXNFQSxFQUN0RUEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7WUFDbEZBLEdBQUdBLENBQUNBLFlBQVlBLENBQUNBLFFBQVFBLEVBQUVBLElBQUlBLG1CQUFZQSxDQUFDQTtnQkFDekJBLFFBQVFBLEVBQUVBLGdDQUFnQ0E7Z0JBQzFDQSxVQUFVQSxFQUFFQSxDQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQTthQUN6QkEsQ0FBQ0EsQ0FBQ0E7aUJBQ2ZBLFdBQVdBLENBQUNBLFFBQVFBLENBQUNBO2lCQUNyQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7Z0JBQ1RBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO2dCQUNyQkEseUJBQU1BLENBQUNBLGlCQUFHQSxDQUFDQSxZQUFZQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtxQkFDcERBLE9BQU9BLENBQUNBLG1EQUFtREE7b0JBQ25EQSxxQ0FBcUNBLENBQUNBLENBQUNBO2dCQUNwREEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7WUFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFUEEscUJBQUVBLENBQUNBLG9EQUFvREEsRUFDcERBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO1lBQ2xGQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxFQUFFQSxJQUFJQSxtQkFBWUEsQ0FBQ0E7Z0JBQ3pCQSxRQUFRQSxFQUFFQSxvQ0FBb0NBO2dCQUM5Q0EsVUFBVUEsRUFBRUEsQ0FBQ0EsS0FBS0EsRUFBRUEsS0FBS0EsQ0FBQ0E7YUFDM0JBLENBQUNBLENBQUNBO2lCQUNmQSxXQUFXQSxDQUFDQSxRQUFRQSxDQUFDQTtpQkFDckJBLElBQUlBLENBQUNBLFVBQUNBLElBQUlBO2dCQUNUQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtnQkFDckJBLHlCQUFNQSxDQUFDQSxpQkFBR0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7cUJBQ3BEQSxPQUFPQSxDQUFDQSxpRUFBaUVBO29CQUNqRUEsaUVBQWlFQSxDQUFDQSxDQUFDQTtnQkFDaEZBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLHFCQUFFQSxDQUFDQSw2REFBNkRBLEVBQzdEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtZQUNsRkEsR0FBR0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsRUFBRUEsSUFBSUEsbUJBQVlBLENBQUNBO2dCQUN6QkEsUUFBUUEsRUFBRUEsdUJBQXVCQTtvQkFDbkJBLDJCQUEyQkE7b0JBQzNCQSw0Q0FBNENBO29CQUM1Q0EsMkJBQTJCQTtvQkFDM0JBLGNBQWNBO29CQUNkQSx3QkFBd0JBO2dCQUN0Q0EsVUFBVUEsRUFBRUEsQ0FBQ0EsMkJBQTJCQSxFQUFFQSx1QkFBdUJBLENBQUNBO2FBQ25FQSxDQUFDQSxDQUFDQTtpQkFDZkEsV0FBV0EsQ0FBQ0EsUUFBUUEsQ0FBQ0E7aUJBQ3JCQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtnQkFDVEEsSUFBSUEsZUFBZUEsR0FDZkEsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsZUFBRUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsMkJBQTJCQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFdkVBLElBQUlBLGVBQWVBLEdBQ2ZBLGVBQWVBLENBQUNBLGFBQWFBLENBQUNBLGVBQUVBLENBQUNBLFNBQVNBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FDMUVBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0E7Z0JBRWpDQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzVEQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7Z0JBRTVEQSxlQUFlQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFFdkJBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQTtnQkFFOURBLElBQUlBLGtCQUFrQkEsR0FDbEJBLGVBQWVBLENBQUNBLGFBQWFBLENBQUNBLGVBQUVBLENBQUNBLFNBQVNBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FDMUVBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0E7Z0JBRWpDQSxrQkFBa0JBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUUxQkEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBO2dCQUUvREEsa0RBQWtEQTtnQkFDbERBLCtCQUErQkE7Z0JBQy9CQSxlQUFlQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDdkJBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtnQkFFNURBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO0lBRVRBLENBQUNBLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBMWhCZSxZQUFJLE9BMGhCbkIsQ0FBQTtBQUVEO0lBQUFDO1FBRUVDLFNBQUlBLEdBQVdBLEVBQUVBLENBQUNBO0lBQ3BCQSxDQUFDQTtJQUhERDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsTUFBTUEsRUFBRUEsUUFBUUEsRUFBRUEsRUFBRUEsRUFBRUEsVUFBVUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7O2lCQUczREE7SUFBREEsZUFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFBQUU7UUFFRUMsU0FBSUEsR0FBV0EsRUFBRUEsQ0FBQ0E7SUFDcEJBLENBQUNBO0lBSEREO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxPQUFPQSxFQUFFQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFFQSxVQUFVQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7a0JBRzVEQTtJQUFEQSxnQkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFBQUU7UUFPRUMsZUFBVUEsR0FBV0EsRUFBRUEsQ0FBQ0E7SUFDMUJBLENBQUNBO0lBUkREO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxRQUFRQTtZQUNsQkEsTUFBTUEsRUFBRUEsQ0FBQ0EsWUFBWUEsQ0FBQ0E7WUFDdEJBLFFBQVFBLEVBQUVBLG1DQUFtQ0E7WUFDN0NBLFVBQVVBLEVBQUVBLEVBQUVBO1NBQ2ZBLENBQUNBOztlQUdEQTtJQUFEQSxhQUFDQTtBQUFEQSxDQUFDQSxBQVJELElBUUM7QUFFRDtJQUFBRTtJQVFBQyxDQUFDQTtJQVJERDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsZ0JBQWdCQTtZQUMxQkEsUUFBUUEsRUFBRUEsOEJBQThCQTtZQUN4Q0EsVUFBVUEsRUFBRUEsRUFBRUE7WUFDZEEsYUFBYUEsRUFBRUEsd0JBQWlCQSxDQUFDQSxNQUFNQTtZQUN2Q0EsTUFBTUEsRUFBRUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQTtTQUM3QkEsQ0FBQ0E7O3NCQUVEQTtJQUFEQSxvQkFBQ0E7QUFBREEsQ0FBQ0EsQUFSRCxJQVFDO0FBRUQ7SUFBQUU7SUFRQUMsQ0FBQ0E7SUFSREQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLGdCQUFnQkE7WUFDMUJBLFFBQVFBLEVBQUVBLDhCQUE4QkE7WUFDeENBLFVBQVVBLEVBQUVBLEVBQUVBO1lBQ2RBLGFBQWFBLEVBQUVBLHdCQUFpQkEsQ0FBQ0EsTUFBTUE7WUFDdkNBLE1BQU1BLEVBQUVBLENBQUNBLG1CQUFtQkEsQ0FBQ0E7U0FDOUJBLENBQUNBOztzQkFFREE7SUFBREEsb0JBQUNBO0FBQURBLENBQUNBLEFBUkQsSUFRQztBQUVEO0lBQUFFO0lBRUFDLENBQUNBO0lBRkREO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxPQUFPQSxFQUFFQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFFQSxVQUFVQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7Y0FFNURBO0lBQURBLFlBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBQUFFO0lBTUFDLENBQUNBO0lBTkREO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSx1QkFBdUJBO1lBQ2pDQSxRQUFRQSxFQUFFQSx1RUFBdUVBO1lBQ2pGQSxVQUFVQSxFQUFFQSxFQUFFQTtTQUNmQSxDQUFDQTs7cUNBRURBO0lBQURBLG1DQUFDQTtBQUFEQSxDQUFDQSxBQU5ELElBTUM7QUFFRDtJQUVFRSxpQ0FBbUJBLEVBQW9CQSxFQUFTQSxXQUF3QkE7UUFBckRDLE9BQUVBLEdBQUZBLEVBQUVBLENBQWtCQTtRQUFTQSxnQkFBV0EsR0FBWEEsV0FBV0EsQ0FBYUE7SUFBR0EsQ0FBQ0E7SUFDNUVELHNDQUFJQSxHQUFKQSxjQUFTRSxJQUFJQSxDQUFDQSxFQUFFQSxDQUFDQSxrQkFBa0JBLENBQUNBLElBQUlBLENBQUNBLFdBQVdBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO0lBQzNERixzQ0FBSUEsR0FBSkEsY0FBU0csSUFBSUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsS0FBS0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFKN0JIO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxVQUFVQSxFQUFDQSxDQUFDQTs7Z0NBS2pDQTtJQUFEQSw4QkFBQ0E7QUFBREEsQ0FBQ0EsQUFMRCxJQUtDO0FBRUQ7SUFFRUksMEJBQW1CQSxFQUFvQkE7UUFBcEJDLE9BQUVBLEdBQUZBLEVBQUVBLENBQWtCQTtJQUFHQSxDQUFDQTtJQUMzQ0QsK0JBQUlBLEdBQUpBLFVBQUtBLFdBQXdCQSxJQUFJRSxJQUFJQSxDQUFDQSxFQUFFQSxDQUFDQSxrQkFBa0JBLENBQUNBLFdBQVdBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO0lBQzlFRiwrQkFBSUEsR0FBSkEsY0FBU0csSUFBSUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsS0FBS0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFKN0JIO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxXQUFXQSxFQUFDQSxDQUFDQTs7eUJBS2xDQTtJQUFEQSx1QkFBQ0E7QUFBREEsQ0FBQ0EsQUFMRCxJQUtDO0FBRUQ7SUFBQUk7SUFNQUMsQ0FBQ0E7SUFOREQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLDRCQUE0QkE7WUFDdENBLFFBQVFBLEVBQUVBLDhEQUE4REE7WUFDeEVBLFVBQVVBLEVBQUVBLENBQUNBLE1BQU1BLENBQUNBO1NBQ3JCQSxDQUFDQTs7eUNBRURBO0lBQURBLHVDQUFDQTtBQUFEQSxDQUFDQSxBQU5ELElBTUM7QUFFRDtJQUFBRTtJQU9BQyxDQUFDQTtJQVBERDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsT0FBT0E7WUFDakJBLFFBQVFBLEVBQ0pBLHNHQUFzR0E7WUFDMUdBLFVBQVVBLEVBQUVBLENBQUNBLGlCQUFVQSxDQUFDQSxjQUFNQSxPQUFBQSxjQUFjQSxFQUFkQSxDQUFjQSxDQUFDQSxDQUFDQTtTQUMvQ0EsQ0FBQ0E7O3VCQUVEQTtJQUFEQSxxQkFBQ0E7QUFBREEsQ0FBQ0EsQUFQRCxJQU9DO0FBRUQ7SUFBQUU7SUFPQUMsQ0FBQ0E7SUFQREQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLE9BQU9BO1lBQ2pCQSxRQUFRQSxFQUNKQSxnSEFBZ0hBO1lBQ3BIQSxVQUFVQSxFQUFFQSxDQUFDQSxpQkFBVUEsQ0FBQ0EsY0FBTUEsT0FBQUEsbUJBQW1CQSxFQUFuQkEsQ0FBbUJBLENBQUNBLENBQUNBO1NBQ3BEQSxDQUFDQTs7dUJBRURBO0lBQURBLHFCQUFDQTtBQUFEQSxDQUFDQSxBQVBELElBT0M7QUFFRDtJQUFBRTtJQU1BQyxDQUFDQTtJQU5ERDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsWUFBWUE7WUFDdEJBLFFBQVFBLEVBQUVBLGdGQUFnRkE7WUFDMUZBLFVBQVVBLEVBQUVBLEVBQUVBO1NBQ2ZBLENBQUNBOzs0QkFFREE7SUFBREEsMEJBQUNBO0FBQURBLENBQUNBLEFBTkQsSUFNQztBQUVEO0lBQUFFO0lBT0FDLENBQUNBO0lBUEREO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxxQkFBcUJBO1lBQy9CQSxRQUFRQSxFQUNKQSxxR0FBcUdBO1lBQ3pHQSxVQUFVQSxFQUFFQSxDQUFDQSx1QkFBdUJBLENBQUNBO1NBQ3RDQSxDQUFDQTs7b0NBRURBO0lBQURBLGtDQUFDQTtBQUFEQSxDQUFDQSxBQVBELElBT0M7QUFFRDtJQUFBRTtJQU9BQyxDQUFDQTtJQVBERDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsa0JBQWtCQTtZQUM1QkEsUUFBUUEsRUFDSkEsd0dBQXdHQTtZQUM1R0EsVUFBVUEsRUFBRUEsQ0FBQ0EsdUJBQXVCQSxDQUFDQTtTQUN0Q0EsQ0FBQ0E7O2lDQUVEQTtJQUFEQSwrQkFBQ0E7QUFBREEsQ0FBQ0EsQUFQRCxJQU9DO0FBRUQ7SUFBQUU7SUFNQUMsQ0FBQ0E7SUFOREQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLEtBQUtBO1lBQ2ZBLFFBQVFBLEVBQUVBLDhEQUE4REE7WUFDeEVBLFVBQVVBLEVBQUVBLENBQUNBLHVCQUF1QkEsQ0FBQ0E7U0FDdENBLENBQUNBOztZQUVEQTtJQUFEQSxVQUFDQTtBQUFEQSxDQUFDQSxBQU5ELElBTUM7QUFFRDtJQUFBRTtRQU9FQyxVQUFLQSxHQUFHQSxDQUFDQSxDQUFDQTtJQUNaQSxDQUFDQTtJQVJERDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsTUFBTUE7WUFDaEJBLE1BQU1BLEVBQUVBLENBQUNBLE9BQU9BLENBQUNBO1lBQ2pCQSxRQUFRQSxFQUFFQSx5REFBeURBO1lBQ25FQSxVQUFVQSxFQUFFQSxDQUFDQSx1QkFBdUJBLEVBQUVBLElBQUlBLENBQUNBO1NBQzVDQSxDQUFDQTs7YUFHREE7SUFBREEsV0FBQ0E7QUFBREEsQ0FBQ0EsQUFSRCxJQVFDO0FBR0Q7SUFHRUUsY0FBWUEsVUFBc0JBO1FBQ2hDQyxJQUFJQSxDQUFDQSxPQUFPQSxHQUFHQSxpQkFBR0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsV0FBV0EsRUFBRUEsQ0FBQ0E7SUFDckVBLENBQUNBO0lBTEhEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxPQUFPQSxFQUFFQSxRQUFRQSxFQUFFQSxvQkFBb0JBLEVBQUNBLENBQUNBOzthQU05REE7SUFBREEsV0FBQ0E7QUFBREEsQ0FBQ0EsQUFORCxJQU1DO0FBR0Q7SUFHRUUsY0FBWUEsVUFBc0JBO1FBQ2hDQyxJQUFJQSxDQUFDQSxPQUFPQSxHQUFHQSxpQkFBR0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsV0FBV0EsRUFBRUEsQ0FBQ0E7SUFDckVBLENBQUNBO0lBTEhEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxPQUFPQSxFQUFFQSxRQUFRQSxFQUFFQSxvQkFBb0JBLEVBQUNBLENBQUNBOzthQU05REE7SUFBREEsV0FBQ0E7QUFBREEsQ0FBQ0EsQUFORCxJQU1DO0FBR0Q7SUFBQUU7SUFFQUMsQ0FBQ0E7SUFGREQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLE9BQU9BLEVBQUVBLFFBQVFBLEVBQUVBLDBDQUEwQ0EsRUFBRUEsVUFBVUEsRUFBRUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7O2FBRXhHQTtJQUFEQSxXQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUM7QUFHRDtJQUFBRTtJQUVBQyxDQUFDQTtJQUZERDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsT0FBT0EsRUFBRUEsUUFBUUEsRUFBRUEsMENBQTBDQSxFQUFFQSxVQUFVQSxFQUFFQSxDQUFDQSxJQUFJQSxDQUFDQSxFQUFDQSxDQUFDQTs7YUFFeEdBO0lBQURBLFdBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBQUFFO0lBRUFDLENBQUNBO0lBRkREO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxTQUFTQSxFQUFFQSxRQUFRQSxFQUFFQSxXQUFXQSxFQUFFQSxVQUFVQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7ZUFFdkVBO0lBQURBLGFBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBQUFFO0lBRUFDLENBQUNBO0lBRkREO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxTQUFTQSxFQUFFQSxRQUFRQSxFQUFFQSxXQUFXQSxFQUFFQSxVQUFVQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7ZUFFdkVBO0lBQURBLGFBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBQUFFO0lBRUFDLENBQUNBO0lBRkREO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxTQUFTQSxFQUFFQSxRQUFRQSxFQUFFQSxXQUFXQSxFQUFFQSxVQUFVQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7ZUFFdkVBO0lBQURBLGFBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBQUFFO0lBRUFDLENBQUNBO0lBRkREO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxTQUFTQSxFQUFFQSxRQUFRQSxFQUFFQSxXQUFXQSxFQUFFQSxVQUFVQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7ZUFFdkVBO0lBQURBLGFBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBQUFFO0lBR0FDLENBQUNBO0lBSEREO1FBQUNBLGdCQUFTQSxDQUNOQSxFQUFDQSxRQUFRQSxFQUFFQSxRQUFRQSxFQUFFQSxRQUFRQSxFQUFFQSxnREFBZ0RBLEVBQUVBLFVBQVVBLEVBQUVBLENBQUNBLE1BQU1BLEVBQUVBLE1BQU1BLENBQUNBLEVBQUNBLENBQUNBOztjQUVsSEE7SUFBREEsWUFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFBQUU7SUFHQUMsQ0FBQ0E7SUFIREQ7UUFBQ0EsZ0JBQVNBLENBQ05BLEVBQUNBLFFBQVFBLEVBQUVBLFFBQVFBLEVBQUVBLFFBQVFBLEVBQUVBLGdEQUFnREEsRUFBRUEsVUFBVUEsRUFBRUEsQ0FBQ0EsTUFBTUEsRUFBRUEsTUFBTUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7O2NBRWxIQTtJQUFEQSxZQUFDQTtBQUFEQSxDQUFDQSxBQUhELElBR0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBc3luY1Rlc3RDb21wbGV0ZXIsXG4gIGJlZm9yZUVhY2gsXG4gIGRkZXNjcmliZSxcbiAgeGRlc2NyaWJlLFxuICBkZXNjcmliZSxcbiAgZWwsXG4gIGRpc3BhdGNoRXZlbnQsXG4gIGV4cGVjdCxcbiAgaWl0LFxuICBpbmplY3QsXG4gIGJlZm9yZUVhY2hQcm92aWRlcnMsXG4gIGl0LFxuICB4aXQsXG4gIGNvbnRhaW5zUmVnZXhwLFxuICBzdHJpbmdpZnlFbGVtZW50LFxuICBUZXN0Q29tcG9uZW50QnVpbGRlcixcbiAgQ29tcG9uZW50Rml4dHVyZSxcbiAgZmFrZUFzeW5jLFxuICB0aWNrXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5pbXBvcnQge0RPTX0gZnJvbSAnYW5ndWxhcjIvc3JjL3BsYXRmb3JtL2RvbS9kb21fYWRhcHRlcic7XG5cbmltcG9ydCB7XG4gIGJpbmQsXG4gIHByb3ZpZGUsXG4gIGZvcndhcmRSZWYsXG4gIENvbXBvbmVudCxcbiAgRGlyZWN0aXZlLFxuICBFbGVtZW50UmVmLFxuICBUZW1wbGF0ZVJlZixcbiAgVmlld0NvbnRhaW5lclJlZixcbiAgVmlld0VuY2Fwc3VsYXRpb24sXG4gIFZpZXdNZXRhZGF0YVxufSBmcm9tICdhbmd1bGFyMi9jb3JlJztcbmltcG9ydCB7XG4gIEJ5LFxufSBmcm9tICdhbmd1bGFyMi9wbGF0Zm9ybS9jb21tb25fZG9tJztcbmltcG9ydCB7Z2V0QWxsRGVidWdOb2Rlc30gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvZGVidWcvZGVidWdfbm9kZSc7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgncHJvamVjdGlvbicsICgpID0+IHtcbiAgICBpdCgnc2hvdWxkIHN1cHBvcnQgc2ltcGxlIGNvbXBvbmVudHMnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNYWluQ29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8c2ltcGxlPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJzxkaXY+QTwvZGl2PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJzwvc2ltcGxlPicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW1NpbXBsZV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE1haW5Db21wKVxuICAgICAgICAgICAgIC50aGVuKChtYWluKSA9PiB7XG4gICAgICAgICAgICAgICBleHBlY3QobWFpbi5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnU0lNUExFKEEpJyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBzdXBwb3J0IHNpbXBsZSBjb21wb25lbnRzIHdpdGggdGV4dCBpbnRlcnBvbGF0aW9uIGFzIGRpcmVjdCBjaGlsZHJlbicsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE1haW5Db21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJ3t7XFwnU1RBUlQoXFwnfX08c2ltcGxlPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3t7dGV4dH19JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPC9zaW1wbGU+e3tcXCcpRU5EXFwnfX0nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtTaW1wbGVdXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNYWluQ29tcClcbiAgICAgICAgICAgICAudGhlbigobWFpbikgPT4ge1xuXG4gICAgICAgICAgICAgICBtYWluLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS50ZXh0ID0gJ0EnO1xuICAgICAgICAgICAgICAgbWFpbi5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICBleHBlY3QobWFpbi5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnU1RBUlQoU0lNUExFKEEpKUVORCcpO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgc3VwcG9ydCBwcm9qZWN0aW5nIHRleHQgaW50ZXJwb2xhdGlvbiB0byBhIG5vbiBib3VuZCBlbGVtZW50JyxcbiAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoXG4gICAgICAgICAgICAgICAgU2ltcGxlLFxuICAgICAgICAgICAgICAgIG5ldyBWaWV3TWV0YWRhdGEoXG4gICAgICAgICAgICAgICAgICAgIHt0ZW1wbGF0ZTogJ1NJTVBMRSg8ZGl2PjxuZy1jb250ZW50PjwvbmctY29udGVudD48L2Rpdj4pJywgZGlyZWN0aXZlczogW119KSlcbiAgICAgICAgICAgICAub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgICBNYWluQ29tcCxcbiAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6ICc8c2ltcGxlPnt7dGV4dH19PC9zaW1wbGU+JywgZGlyZWN0aXZlczogW1NpbXBsZV19KSlcbiAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTWFpbkNvbXApXG4gICAgICAgICAgICAgLnRoZW4oKG1haW4pID0+IHtcblxuICAgICAgICAgICAgICAgbWFpbi5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UudGV4dCA9ICdBJztcbiAgICAgICAgICAgICAgIG1haW4uZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KG1haW4uZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ1NJTVBMRShBKScpO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuXG4gICAgaXQoJ3Nob3VsZCBzdXBwb3J0IHByb2plY3RpbmcgdGV4dCBpbnRlcnBvbGF0aW9uIHRvIGEgbm9uIGJvdW5kIGVsZW1lbnQgd2l0aCBvdGhlciBib3VuZCBlbGVtZW50cyBhZnRlciBpdCcsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgIFNpbXBsZSwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTpcbiAgICAgICAgICAgICAgICAgICAgICAnU0lNUExFKDxkaXY+PG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50PjwvZGl2PjxkaXYgW3RhYkluZGV4XT1cIjBcIj5FTDwvZGl2PiknLFxuICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW11cbiAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgICBNYWluQ29tcCxcbiAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6ICc8c2ltcGxlPnt7dGV4dH19PC9zaW1wbGU+JywgZGlyZWN0aXZlczogW1NpbXBsZV19KSlcbiAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTWFpbkNvbXApXG4gICAgICAgICAgICAgLnRoZW4oKG1haW4pID0+IHtcblxuICAgICAgICAgICAgICAgbWFpbi5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UudGV4dCA9ICdBJztcbiAgICAgICAgICAgICAgIG1haW4uZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KG1haW4uZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ1NJTVBMRShBRUwpJyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBwcm9qZWN0IGNvbnRlbnQgY29tcG9uZW50cycsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgIFNpbXBsZSxcbiAgICAgICAgICAgICAgICBuZXcgVmlld01ldGFkYXRhKFxuICAgICAgICAgICAgICAgICAgICB7dGVtcGxhdGU6ICdTSU1QTEUoe3swfX18PG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50Pnx7ezJ9fSknLCBkaXJlY3RpdmVzOiBbXX0pKVxuICAgICAgICAgICAgIC5vdmVycmlkZVZpZXcoT3RoZXJDb21wLCBuZXcgVmlld01ldGFkYXRhKHt0ZW1wbGF0ZTogJ3t7MX19JywgZGlyZWN0aXZlczogW119KSlcbiAgICAgICAgICAgICAub3ZlcnJpZGVWaWV3KE1haW5Db21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8c2ltcGxlPjxvdGhlcj48L290aGVyPjwvc2ltcGxlPicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtTaW1wbGUsIE90aGVyQ29tcF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNYWluQ29tcClcbiAgICAgICAgICAgICAudGhlbigobWFpbikgPT4ge1xuXG4gICAgICAgICAgICAgICBtYWluLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChtYWluLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdTSU1QTEUoMHwxfDIpJyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBub3Qgc2hvdyB0aGUgbGlnaHQgZG9tIGV2ZW4gaWYgdGhlcmUgaXMgbm8gY29udGVudCB0YWcnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNYWluQ29tcCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6ICc8ZW1wdHk+QTwvZW1wdHk+JywgZGlyZWN0aXZlczogW0VtcHR5XX0pKVxuICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNYWluQ29tcClcbiAgICAgICAgICAgICAudGhlbigobWFpbikgPT4ge1xuXG4gICAgICAgICAgICAgICBleHBlY3QobWFpbi5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnJyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBzdXBwb3J0IG11bHRpcGxlIGNvbnRlbnQgdGFncycsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE1haW5Db21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJzxtdWx0aXBsZS1jb250ZW50LXRhZ3M+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPGRpdj5CPC9kaXY+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPGRpdj5DPC9kaXY+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPGRpdiBjbGFzcz1cImxlZnRcIj5BPC9kaXY+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPC9tdWx0aXBsZS1jb250ZW50LXRhZ3M+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbTXVsdGlwbGVDb250ZW50VGFnc0NvbXBvbmVudF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE1haW5Db21wKVxuICAgICAgICAgICAgIC50aGVuKChtYWluKSA9PiB7XG5cbiAgICAgICAgICAgICAgIGV4cGVjdChtYWluLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCcoQSwgQkMpJyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCByZWRpc3RyaWJ1dGUgb25seSBkaXJlY3QgY2hpbGRyZW4nLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNYWluQ29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8bXVsdGlwbGUtY29udGVudC10YWdzPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJzxkaXY+QjxkaXYgY2xhc3M9XCJsZWZ0XCI+QTwvZGl2PjwvZGl2PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJzxkaXY+QzwvZGl2PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJzwvbXVsdGlwbGUtY29udGVudC10YWdzPicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW011bHRpcGxlQ29udGVudFRhZ3NDb21wb25lbnRdXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNYWluQ29tcClcbiAgICAgICAgICAgICAudGhlbigobWFpbikgPT4ge1xuXG4gICAgICAgICAgICAgICBleHBlY3QobWFpbi5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnKCwgQkFDKScpO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KFwic2hvdWxkIHJlZGlzdHJpYnV0ZSBkaXJlY3QgY2hpbGQgdmlld2NvbnRhaW5lcnMgd2hlbiB0aGUgbGlnaHQgZG9tIGNoYW5nZXNcIixcbiAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTWFpbkNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPG11bHRpcGxlLWNvbnRlbnQtdGFncz4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICc8dGVtcGxhdGUgbWFudWFsIGNsYXNzPVwibGVmdFwiPjxkaXY+QTE8L2Rpdj48L3RlbXBsYXRlPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJzxkaXY+QjwvZGl2PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJzwvbXVsdGlwbGUtY29udGVudC10YWdzPicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW011bHRpcGxlQ29udGVudFRhZ3NDb21wb25lbnQsIE1hbnVhbFZpZXdwb3J0RGlyZWN0aXZlXVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTWFpbkNvbXApXG4gICAgICAgICAgICAgLnRoZW4oKG1haW4pID0+IHtcblxuICAgICAgICAgICAgICAgdmFyIHZpZXdwb3J0RGlyZWN0aXZlcyA9XG4gICAgICAgICAgICAgICAgICAgbWFpbi5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF1cbiAgICAgICAgICAgICAgICAgICAgICAgLmNoaWxkTm9kZXMuZmlsdGVyKEJ5LmRpcmVjdGl2ZShNYW51YWxWaWV3cG9ydERpcmVjdGl2ZSkpXG4gICAgICAgICAgICAgICAgICAgICAgIC5tYXAoZGUgPT4gZGUuaW5qZWN0KE1hbnVhbFZpZXdwb3J0RGlyZWN0aXZlKSk7XG5cbiAgICAgICAgICAgICAgIGV4cGVjdChtYWluLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCcoLCBCKScpO1xuICAgICAgICAgICAgICAgdmlld3BvcnREaXJlY3RpdmVzLmZvckVhY2goZCA9PiBkLnNob3coKSk7XG4gICAgICAgICAgICAgICBleHBlY3QobWFpbi5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnKEExLCBCKScpO1xuXG4gICAgICAgICAgICAgICB2aWV3cG9ydERpcmVjdGl2ZXMuZm9yRWFjaChkID0+IGQuaGlkZSgpKTtcblxuICAgICAgICAgICAgICAgZXhwZWN0KG1haW4uZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJygsIEIpJyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoXCJzaG91bGQgc3VwcG9ydCBuZXN0ZWQgY29tcG9uZW50c1wiLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNYWluQ29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8b3V0ZXItd2l0aC1pbmRpcmVjdC1uZXN0ZWQ+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPGRpdj5BPC9kaXY+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPGRpdj5CPC9kaXY+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPC9vdXRlci13aXRoLWluZGlyZWN0LW5lc3RlZD4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtPdXRlcldpdGhJbmRpcmVjdE5lc3RlZENvbXBvbmVudF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE1haW5Db21wKVxuICAgICAgICAgICAgIC50aGVuKChtYWluKSA9PiB7XG5cbiAgICAgICAgICAgICAgIGV4cGVjdChtYWluLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdPVVRFUihTSU1QTEUoQUIpKScpO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KFwic2hvdWxkIHN1cHBvcnQgbmVzdGluZyB3aXRoIGNvbnRlbnQgYmVpbmcgZGlyZWN0IGNoaWxkIG9mIGEgbmVzdGVkIGNvbXBvbmVudFwiLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNYWluQ29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8b3V0ZXI+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPHRlbXBsYXRlIG1hbnVhbCBjbGFzcz1cImxlZnRcIj48ZGl2PkE8L2Rpdj48L3RlbXBsYXRlPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJzxkaXY+QjwvZGl2PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJzxkaXY+QzwvZGl2PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJzwvb3V0ZXI+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbT3V0ZXJDb21wb25lbnQsIE1hbnVhbFZpZXdwb3J0RGlyZWN0aXZlXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE1haW5Db21wKVxuICAgICAgICAgICAgIC50aGVuKChtYWluKSA9PiB7XG5cbiAgICAgICAgICAgICAgIHZhciB2aWV3cG9ydERpcmVjdGl2ZSA9XG4gICAgICAgICAgICAgICAgICAgbWFpbi5kZWJ1Z0VsZW1lbnQucXVlcnlBbGxOb2RlcyhCeS5kaXJlY3RpdmUoTWFudWFsVmlld3BvcnREaXJlY3RpdmUpKVswXS5pbmplY3QoXG4gICAgICAgICAgICAgICAgICAgICAgIE1hbnVhbFZpZXdwb3J0RGlyZWN0aXZlKTtcblxuICAgICAgICAgICAgICAgZXhwZWN0KG1haW4uZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ09VVEVSKElOTkVSKElOTkVSSU5ORVIoLEJDKSkpJyk7XG4gICAgICAgICAgICAgICB2aWV3cG9ydERpcmVjdGl2ZS5zaG93KCk7XG5cbiAgICAgICAgICAgICAgIGV4cGVjdChtYWluLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdPVVRFUihJTk5FUihJTk5FUklOTkVSKEEsQkMpKSknKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIHJlZGlzdHJpYnV0ZSB3aGVuIHRoZSBzaGFkb3cgZG9tIGNoYW5nZXMnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNYWluQ29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8Y29uZGl0aW9uYWwtY29udGVudD4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICc8ZGl2IGNsYXNzPVwibGVmdFwiPkE8L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICc8ZGl2PkI8L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICc8ZGl2PkM8L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICc8L2NvbmRpdGlvbmFsLWNvbnRlbnQ+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbQ29uZGl0aW9uYWxDb250ZW50Q29tcG9uZW50XVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTWFpbkNvbXApXG4gICAgICAgICAgICAgLnRoZW4oKG1haW4pID0+IHtcblxuICAgICAgICAgICAgICAgdmFyIHZpZXdwb3J0RGlyZWN0aXZlID1cbiAgICAgICAgICAgICAgICAgICBtYWluLmRlYnVnRWxlbWVudC5xdWVyeUFsbE5vZGVzKEJ5LmRpcmVjdGl2ZShNYW51YWxWaWV3cG9ydERpcmVjdGl2ZSkpWzBdLmluamVjdChcbiAgICAgICAgICAgICAgICAgICAgICAgTWFudWFsVmlld3BvcnREaXJlY3RpdmUpO1xuXG4gICAgICAgICAgICAgICBleHBlY3QobWFpbi5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnKCwgQkMpJyk7XG5cbiAgICAgICAgICAgICAgIHZpZXdwb3J0RGlyZWN0aXZlLnNob3coKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChtYWluLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCcoQSwgQkMpJyk7XG5cbiAgICAgICAgICAgICAgIHZpZXdwb3J0RGlyZWN0aXZlLmhpZGUoKTtcblxuICAgICAgICAgICAgICAgZXhwZWN0KG1haW4uZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJygsIEJDKScpO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIC8vIEdILTIwOTUgLSBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2lzc3Vlcy8yMDk1XG4gICAgLy8gaW1wb3J0YW50IGFzIHdlIGFyZSByZW1vdmluZyB0aGUgbmctY29udGVudCBlbGVtZW50IGR1cmluZyBjb21waWxhdGlvbixcbiAgICAvLyB3aGljaCBjb3VsZCBza3JldyB1cCB0ZXh0IG5vZGUgaW5kaWNlcy5cbiAgICBpdCgnc2hvdWxkIHN1cHBvcnQgdGV4dCBub2RlcyBhZnRlciBjb250ZW50IHRhZ3MnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuXG4gICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgIE1haW5Db21wLFxuICAgICAgICAgICAgICAgIG5ldyBWaWV3TWV0YWRhdGEoXG4gICAgICAgICAgICAgICAgICAgIHt0ZW1wbGF0ZTogJzxzaW1wbGUgc3RyaW5nUHJvcD1cInRleHRcIj48L3NpbXBsZT4nLCBkaXJlY3RpdmVzOiBbU2ltcGxlXX0pKVxuICAgICAgICAgICAgIC5vdmVycmlkZVRlbXBsYXRlKFNpbXBsZSwgJzxuZy1jb250ZW50PjwvbmctY29udGVudD48cD5QLDwvcD57e3N0cmluZ1Byb3B9fScpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE1haW5Db21wKVxuICAgICAgICAgICAgIC50aGVuKChtYWluOiBDb21wb25lbnRGaXh0dXJlKSA9PiB7XG5cbiAgICAgICAgICAgICAgIG1haW4uZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICBleHBlY3QobWFpbi5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnUCx0ZXh0Jyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG5cbiAgICAgICB9KSk7XG5cbiAgICAvLyBpbXBvcnRhbnQgYXMgd2UgYXJlIG1vdmluZyBzdHlsZSB0YWdzIGFyb3VuZCBkdXJpbmcgY29tcGlsYXRpb24sXG4gICAgLy8gd2hpY2ggY291bGQgc2tyZXcgdXAgdGV4dCBub2RlIGluZGljZXMuXG4gICAgaXQoJ3Nob3VsZCBzdXBwb3J0IHRleHQgbm9kZXMgYWZ0ZXIgc3R5bGUgdGFncycsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG5cbiAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoXG4gICAgICAgICAgICAgICAgTWFpbkNvbXAsXG4gICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YShcbiAgICAgICAgICAgICAgICAgICAge3RlbXBsYXRlOiAnPHNpbXBsZSBzdHJpbmdQcm9wPVwidGV4dFwiPjwvc2ltcGxlPicsIGRpcmVjdGl2ZXM6IFtTaW1wbGVdfSkpXG4gICAgICAgICAgICAgLm92ZXJyaWRlVGVtcGxhdGUoU2ltcGxlLCAnPHN0eWxlPjwvc3R5bGU+PHA+UCw8L3A+e3tzdHJpbmdQcm9wfX0nKVxuICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNYWluQ29tcClcbiAgICAgICAgICAgICAudGhlbigobWFpbjogQ29tcG9uZW50Rml4dHVyZSkgPT4ge1xuXG4gICAgICAgICAgICAgICBtYWluLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChtYWluLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdQLHRleHQnKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIHN1cHBvcnQgbW92aW5nIG5vbiBwcm9qZWN0ZWQgbGlnaHQgZG9tIGFyb3VuZCcsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE1haW5Db21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJzxlbXB0eT4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICcgIDx0ZW1wbGF0ZSBtYW51YWw+PGRpdj5BPC9kaXY+PC90ZW1wbGF0ZT4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICc8L2VtcHR5PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ1NUQVJUKDxkaXYgcHJvamVjdD48L2Rpdj4pRU5EJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbRW1wdHksIFByb2plY3REaXJlY3RpdmUsIE1hbnVhbFZpZXdwb3J0RGlyZWN0aXZlXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE1haW5Db21wKVxuICAgICAgICAgICAgIC50aGVuKChtYWluKSA9PiB7XG4gICAgICAgICAgICAgICB2YXIgc291cmNlRGlyZWN0aXZlO1xuXG4gICAgICAgICAgICAgICAvLyBXZSBjYW4ndCB1c2UgdGhlIGNoaWxkIG5vZGVzIHRvIGdldCBhIGhvbGQgb2YgdGhpcyBiZWNhdXNlIGl0J3Mgbm90IGluIHRoZSBkb20gYXRcbiAgICAgICAgICAgICAgIC8vIGFsbC5cbiAgICAgICAgICAgICAgIGdldEFsbERlYnVnTm9kZXMoKS5mb3JFYWNoKChkZWJ1ZykgPT4ge1xuICAgICAgICAgICAgICAgICBpZiAoZGVidWcucHJvdmlkZXJUb2tlbnMuaW5kZXhPZihNYW51YWxWaWV3cG9ydERpcmVjdGl2ZSkgIT09IC0xKSB7XG4gICAgICAgICAgICAgICAgICAgc291cmNlRGlyZWN0aXZlID0gZGVidWcuaW5qZWN0KE1hbnVhbFZpZXdwb3J0RGlyZWN0aXZlKTtcbiAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgIHZhciBwcm9qZWN0RGlyZWN0aXZlOiBQcm9qZWN0RGlyZWN0aXZlID1cbiAgICAgICAgICAgICAgICAgICBtYWluLmRlYnVnRWxlbWVudC5xdWVyeUFsbE5vZGVzKEJ5LmRpcmVjdGl2ZShQcm9qZWN0RGlyZWN0aXZlKSlbMF0uaW5qZWN0KFxuICAgICAgICAgICAgICAgICAgICAgICBQcm9qZWN0RGlyZWN0aXZlKTtcblxuICAgICAgICAgICAgICAgZXhwZWN0KG1haW4uZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ1NUQVJUKClFTkQnKTtcblxuICAgICAgICAgICAgICAgcHJvamVjdERpcmVjdGl2ZS5zaG93KHNvdXJjZURpcmVjdGl2ZS50ZW1wbGF0ZVJlZik7XG4gICAgICAgICAgICAgICBleHBlY3QobWFpbi5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnU1RBUlQoQSlFTkQnKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIHN1cHBvcnQgbW92aW5nIHByb2plY3RlZCBsaWdodCBkb20gYXJvdW5kJyxcbiAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTWFpbkNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPHNpbXBsZT48dGVtcGxhdGUgbWFudWFsPjxkaXY+QTwvZGl2PjwvdGVtcGxhdGU+PC9zaW1wbGU+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnU1RBUlQoPGRpdiBwcm9qZWN0PjwvZGl2PilFTkQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtTaW1wbGUsIFByb2plY3REaXJlY3RpdmUsIE1hbnVhbFZpZXdwb3J0RGlyZWN0aXZlXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE1haW5Db21wKVxuICAgICAgICAgICAgIC50aGVuKChtYWluKSA9PiB7XG5cbiAgICAgICAgICAgICAgIHZhciBzb3VyY2VEaXJlY3RpdmU6IE1hbnVhbFZpZXdwb3J0RGlyZWN0aXZlID1cbiAgICAgICAgICAgICAgICAgICBtYWluLmRlYnVnRWxlbWVudC5xdWVyeUFsbE5vZGVzKEJ5LmRpcmVjdGl2ZShNYW51YWxWaWV3cG9ydERpcmVjdGl2ZSkpWzBdLmluamVjdChcbiAgICAgICAgICAgICAgICAgICAgICAgTWFudWFsVmlld3BvcnREaXJlY3RpdmUpO1xuICAgICAgICAgICAgICAgdmFyIHByb2plY3REaXJlY3RpdmU6IFByb2plY3REaXJlY3RpdmUgPVxuICAgICAgICAgICAgICAgICAgIG1haW4uZGVidWdFbGVtZW50LnF1ZXJ5QWxsTm9kZXMoQnkuZGlyZWN0aXZlKFByb2plY3REaXJlY3RpdmUpKVswXS5pbmplY3QoXG4gICAgICAgICAgICAgICAgICAgICAgIFByb2plY3REaXJlY3RpdmUpO1xuICAgICAgICAgICAgICAgZXhwZWN0KG1haW4uZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ1NJTVBMRSgpU1RBUlQoKUVORCcpO1xuXG4gICAgICAgICAgICAgICBwcm9qZWN0RGlyZWN0aXZlLnNob3coc291cmNlRGlyZWN0aXZlLnRlbXBsYXRlUmVmKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChtYWluLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdTSU1QTEUoKVNUQVJUKEEpRU5EJyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBzdXBwb3J0IG1vdmluZyBuZy1jb250ZW50IGFyb3VuZCcsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgIE1haW5Db21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPGNvbmRpdGlvbmFsLWNvbnRlbnQ+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICc8ZGl2IGNsYXNzPVwibGVmdFwiPkE8L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJzxkaXY+QjwvZGl2PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPC9jb25kaXRpb25hbC1jb250ZW50PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnU1RBUlQoPGRpdiBwcm9qZWN0PjwvZGl2PilFTkQnLFxuICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczpcbiAgICAgICAgICAgICAgICAgICAgICBbQ29uZGl0aW9uYWxDb250ZW50Q29tcG9uZW50LCBQcm9qZWN0RGlyZWN0aXZlLCBNYW51YWxWaWV3cG9ydERpcmVjdGl2ZV1cbiAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTWFpbkNvbXApXG4gICAgICAgICAgICAgLnRoZW4oKG1haW4pID0+IHtcblxuICAgICAgICAgICAgICAgdmFyIHNvdXJjZURpcmVjdGl2ZTogTWFudWFsVmlld3BvcnREaXJlY3RpdmUgPVxuICAgICAgICAgICAgICAgICAgIG1haW4uZGVidWdFbGVtZW50LnF1ZXJ5QWxsTm9kZXMoQnkuZGlyZWN0aXZlKE1hbnVhbFZpZXdwb3J0RGlyZWN0aXZlKSlbMF0uaW5qZWN0KFxuICAgICAgICAgICAgICAgICAgICAgICBNYW51YWxWaWV3cG9ydERpcmVjdGl2ZSk7XG4gICAgICAgICAgICAgICB2YXIgcHJvamVjdERpcmVjdGl2ZTogUHJvamVjdERpcmVjdGl2ZSA9XG4gICAgICAgICAgICAgICAgICAgbWFpbi5kZWJ1Z0VsZW1lbnQucXVlcnlBbGxOb2RlcyhCeS5kaXJlY3RpdmUoUHJvamVjdERpcmVjdGl2ZSkpWzBdLmluamVjdChcbiAgICAgICAgICAgICAgICAgICAgICAgUHJvamVjdERpcmVjdGl2ZSk7XG4gICAgICAgICAgICAgICBleHBlY3QobWFpbi5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnKCwgQilTVEFSVCgpRU5EJyk7XG5cbiAgICAgICAgICAgICAgIHByb2plY3REaXJlY3RpdmUuc2hvdyhzb3VyY2VEaXJlY3RpdmUudGVtcGxhdGVSZWYpO1xuICAgICAgICAgICAgICAgZXhwZWN0KG1haW4uZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJygsIEIpU1RBUlQoQSlFTkQnKTtcblxuICAgICAgICAgICAgICAgLy8gU3RhbXBpbmcgbmctY29udGVudCBtdWx0aXBsZSB0aW1lcyBzaG91bGQgbm90IHByb2R1Y2UgdGhlIGNvbnRlbnQgbXVsdGlwbGVcbiAgICAgICAgICAgICAgIC8vIHRpbWVzLi4uXG4gICAgICAgICAgICAgICBwcm9qZWN0RGlyZWN0aXZlLnNob3coc291cmNlRGlyZWN0aXZlLnRlbXBsYXRlUmVmKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChtYWluLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCcoLCBCKVNUQVJUKEEpRU5EJyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG5cbiAgICAvLyBOb3RlOiBUaGlzIGRvZXMgbm90IHVzZSBhIG5nLWNvbnRlbnQgZWxlbWVudCwgYnV0XG4gICAgLy8gaXMgc3RpbGwgaW1wb3J0YW50IGFzIHdlIGFyZSBtZXJnaW5nIHByb3RvIHZpZXdzIGluZGVwZW5kZW50IG9mXG4gICAgLy8gdGhlIHByZXNlbmNlIG9mIG5nLWNvbnRlbnQgZWxlbWVudHMhXG4gICAgaXQoJ3Nob3VsZCBzdGlsbCBhbGxvdyB0byBpbXBsZW1lbnQgYSByZWN1cnNpdmUgdHJlZXMnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNYWluQ29tcCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6ICc8dHJlZT48L3RyZWU+JywgZGlyZWN0aXZlczogW1RyZWVdfSkpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE1haW5Db21wKVxuICAgICAgICAgICAgIC50aGVuKChtYWluKSA9PiB7XG5cbiAgICAgICAgICAgICAgIG1haW4uZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgdmFyIG1hbnVhbERpcmVjdGl2ZTogTWFudWFsVmlld3BvcnREaXJlY3RpdmUgPVxuICAgICAgICAgICAgICAgICAgIG1haW4uZGVidWdFbGVtZW50LnF1ZXJ5QWxsTm9kZXMoQnkuZGlyZWN0aXZlKE1hbnVhbFZpZXdwb3J0RGlyZWN0aXZlKSlbMF0uaW5qZWN0KFxuICAgICAgICAgICAgICAgICAgICAgICBNYW51YWxWaWV3cG9ydERpcmVjdGl2ZSk7XG4gICAgICAgICAgICAgICBleHBlY3QobWFpbi5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnVFJFRSgwOiknKTtcbiAgICAgICAgICAgICAgIG1hbnVhbERpcmVjdGl2ZS5zaG93KCk7XG4gICAgICAgICAgICAgICBtYWluLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChtYWluLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdUUkVFKDA6VFJFRSgxOikpJyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaWYgKERPTS5zdXBwb3J0c05hdGl2ZVNoYWRvd0RPTSgpKSB7XG4gICAgICBpdCgnc2hvdWxkIHN1cHBvcnQgbmF0aXZlIGNvbnRlbnQgcHJvamVjdGlvbiBhbmQgaXNvbGF0ZSBzdHlsZXMgcGVyIGNvbXBvbmVudCcsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNYWluQ29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJzxzaW1wbGUtbmF0aXZlMT48ZGl2PkE8L2Rpdj48L3NpbXBsZS1uYXRpdmUxPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPHNpbXBsZS1uYXRpdmUyPjxkaXY+QjwvZGl2Pjwvc2ltcGxlLW5hdGl2ZTI+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtTaW1wbGVOYXRpdmUxLCBTaW1wbGVOYXRpdmUyXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE1haW5Db21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKG1haW4pID0+IHtcbiAgICAgICAgICAgICAgICAgdmFyIGNoaWxkTm9kZXMgPSBET00uY2hpbGROb2RlcyhtYWluLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGNoaWxkTm9kZXNbMF0pLnRvSGF2ZVRleHQoJ2RpdiB7Y29sb3I6IHJlZH1TSU1QTEUxKEEpJyk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChjaGlsZE5vZGVzWzFdKS50b0hhdmVUZXh0KCdkaXYge2NvbG9yOiBibHVlfVNJTVBMRTIoQiknKTtcbiAgICAgICAgICAgICAgICAgbWFpbi5kZXN0cm95KCk7XG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuICAgIH1cblxuICAgIGlmIChET00uc3VwcG9ydHNET01FdmVudHMoKSkge1xuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IGVtdWxhdGVkIHN0eWxlIGVuY2Fwc3VsYXRpb24nLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTWFpbkNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8ZGl2PjwvZGl2PicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZXM6IFsnZGl2IHsgY29sb3I6IHJlZH0nXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLkVtdWxhdGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTWFpbkNvbXApXG4gICAgICAgICAgICAgICAudGhlbigobWFpbikgPT4ge1xuICAgICAgICAgICAgICAgICB2YXIgbWFpbkVsID0gbWFpbi5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudDtcbiAgICAgICAgICAgICAgICAgdmFyIGRpdjEgPSBET00uZmlyc3RDaGlsZChtYWluRWwpO1xuICAgICAgICAgICAgICAgICB2YXIgZGl2MiA9IERPTS5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgICAgICAgICAgICAgRE9NLmFwcGVuZENoaWxkKG1haW5FbCwgZGl2Mik7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChET00uZ2V0Q29tcHV0ZWRTdHlsZShkaXYxKS5jb2xvcikudG9FcXVhbCgncmdiKDI1NSwgMCwgMCknKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5nZXRDb21wdXRlZFN0eWxlKGRpdjIpLmNvbG9yKS50b0VxdWFsKCdyZ2IoMCwgMCwgMCknKTtcbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG4gICAgfVxuXG4gICAgaXQoJ3Nob3VsZCBzdXBwb3J0IG5lc3RlZCBjb25kaXRpb25hbHMgdGhhdCBjb250YWluIG5nLWNvbnRlbnRzJyxcbiAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTWFpbkNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiBgPGNvbmRpdGlvbmFsLXRleHQ+YTwvY29uZGl0aW9uYWwtdGV4dD5gLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtDb25kaXRpb25hbFRleHRDb21wb25lbnRdXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNYWluQ29tcClcbiAgICAgICAgICAgICAudGhlbigobWFpbikgPT4ge1xuICAgICAgICAgICAgICAgZXhwZWN0KG1haW4uZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ01BSU4oKScpO1xuXG4gICAgICAgICAgICAgICB2YXIgdmlld3BvcnRFbGVtZW50ID1cbiAgICAgICAgICAgICAgICAgICBtYWluLmRlYnVnRWxlbWVudC5xdWVyeUFsbE5vZGVzKEJ5LmRpcmVjdGl2ZShNYW51YWxWaWV3cG9ydERpcmVjdGl2ZSkpWzBdO1xuICAgICAgICAgICAgICAgdmlld3BvcnRFbGVtZW50LmluamVjdChNYW51YWxWaWV3cG9ydERpcmVjdGl2ZSkuc2hvdygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KG1haW4uZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ01BSU4oRklSU1QoKSknKTtcblxuICAgICAgICAgICAgICAgdmlld3BvcnRFbGVtZW50ID1cbiAgICAgICAgICAgICAgICAgICBtYWluLmRlYnVnRWxlbWVudC5xdWVyeUFsbE5vZGVzKEJ5LmRpcmVjdGl2ZShNYW51YWxWaWV3cG9ydERpcmVjdGl2ZSkpWzFdO1xuICAgICAgICAgICAgICAgdmlld3BvcnRFbGVtZW50LmluamVjdChNYW51YWxWaWV3cG9ydERpcmVjdGl2ZSkuc2hvdygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KG1haW4uZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ01BSU4oRklSU1QoU0VDT05EKGEpKSknKTtcblxuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgYWxsb3cgdG8gc3dpdGNoIHRoZSBvcmRlciBvZiBuZXN0ZWQgY29tcG9uZW50cyB2aWEgbmctY29udGVudCcsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE1haW5Db21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogYDxjbXAtYT48Y21wLWI+PC9jbXAtYj48L2NtcC1hPmAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW0NtcEEsIENtcEJdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTWFpbkNvbXApXG4gICAgICAgICAgICAgLnRoZW4oKG1haW4pID0+IHtcbiAgICAgICAgICAgICAgIG1haW4uZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KERPTS5nZXRJbm5lckhUTUwobWFpbi5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkpXG4gICAgICAgICAgICAgICAgICAgLnRvRXF1YWwoJzxjbXAtYT48Y21wLWI+PGNtcC1kPjxkPmNtcC1kPC9kPjwvY21wLWQ+PC9jbXAtYj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPGNtcC1jPjxjPmNtcC1jPC9jPjwvY21wLWM+PC9jbXAtYT4nKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIGNyZWF0ZSBuZXN0ZWQgY29tcG9uZW50cyBpbiB0aGUgcmlnaHQgb3JkZXInLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNYWluQ29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6IGA8Y21wLWExPjwvY21wLWExPjxjbXAtYTI+PC9jbXAtYTI+YCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbQ21wQTEsIENtcEEyXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE1haW5Db21wKVxuICAgICAgICAgICAgIC50aGVuKChtYWluKSA9PiB7XG4gICAgICAgICAgICAgICBtYWluLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChET00uZ2V0SW5uZXJIVE1MKG1haW4uZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpKVxuICAgICAgICAgICAgICAgICAgIC50b0VxdWFsKCc8Y21wLWExPmExPGNtcC1iMTE+YjExPC9jbXAtYjExPjxjbXAtYjEyPmIxMjwvY21wLWIxMj48L2NtcC1hMT4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPGNtcC1hMj5hMjxjbXAtYjIxPmIyMTwvY21wLWIyMT48Y21wLWIyMj5iMjI8L2NtcC1iMjI+PC9jbXAtYTI+Jyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBwcm9qZWN0IGZpbGxlZCB2aWV3IGNvbnRhaW5lcnMgaW50byBhIHZpZXcgY29udGFpbmVyJyxcbiAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTWFpbkNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPGNvbmRpdGlvbmFsLWNvbnRlbnQ+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPGRpdiBjbGFzcz1cImxlZnRcIj5BPC9kaXY+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPHRlbXBsYXRlIG1hbnVhbCBjbGFzcz1cImxlZnRcIj5CPC90ZW1wbGF0ZT4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICc8ZGl2IGNsYXNzPVwibGVmdFwiPkM8L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICc8ZGl2PkQ8L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICc8L2NvbmRpdGlvbmFsLWNvbnRlbnQ+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbQ29uZGl0aW9uYWxDb250ZW50Q29tcG9uZW50LCBNYW51YWxWaWV3cG9ydERpcmVjdGl2ZV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE1haW5Db21wKVxuICAgICAgICAgICAgIC50aGVuKChtYWluKSA9PiB7XG4gICAgICAgICAgICAgICB2YXIgY29uZGl0aW9uYWxDb21wID1cbiAgICAgICAgICAgICAgICAgICBtYWluLmRlYnVnRWxlbWVudC5xdWVyeShCeS5kaXJlY3RpdmUoQ29uZGl0aW9uYWxDb250ZW50Q29tcG9uZW50KSk7XG5cbiAgICAgICAgICAgICAgIHZhciB2aWV3Vmlld3BvcnREaXIgPVxuICAgICAgICAgICAgICAgICAgIGNvbmRpdGlvbmFsQ29tcC5xdWVyeUFsbE5vZGVzKEJ5LmRpcmVjdGl2ZShNYW51YWxWaWV3cG9ydERpcmVjdGl2ZSkpWzBdLmluamVjdChcbiAgICAgICAgICAgICAgICAgICAgICAgTWFudWFsVmlld3BvcnREaXJlY3RpdmUpO1xuXG4gICAgICAgICAgICAgICBleHBlY3QobWFpbi5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnKCwgRCknKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChtYWluLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCcoLCBEKScpO1xuXG4gICAgICAgICAgICAgICB2aWV3Vmlld3BvcnREaXIuc2hvdygpO1xuXG4gICAgICAgICAgICAgICBleHBlY3QobWFpbi5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnKEFDLCBEKScpO1xuXG4gICAgICAgICAgICAgICB2YXIgY29udGVudFZpZXdwb3J0RGlyID1cbiAgICAgICAgICAgICAgICAgICBjb25kaXRpb25hbENvbXAucXVlcnlBbGxOb2RlcyhCeS5kaXJlY3RpdmUoTWFudWFsVmlld3BvcnREaXJlY3RpdmUpKVsxXS5pbmplY3QoXG4gICAgICAgICAgICAgICAgICAgICAgIE1hbnVhbFZpZXdwb3J0RGlyZWN0aXZlKTtcblxuICAgICAgICAgICAgICAgY29udGVudFZpZXdwb3J0RGlyLnNob3coKTtcblxuICAgICAgICAgICAgICAgZXhwZWN0KG1haW4uZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJyhBQkMsIEQpJyk7XG5cbiAgICAgICAgICAgICAgIC8vIGhpZGUgdmlldyB2aWV3cG9ydCwgYW5kIHRlc3QgdGhhdCBpdCBhbHNvIGhpZGVzXG4gICAgICAgICAgICAgICAvLyB0aGUgY29udGVudCB2aWV3cG9ydCdzIHZpZXdzXG4gICAgICAgICAgICAgICB2aWV3Vmlld3BvcnREaXIuaGlkZSgpO1xuICAgICAgICAgICAgICAgZXhwZWN0KG1haW4uZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJygsIEQpJyk7XG5cbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgfSk7XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnbWFpbicsIHRlbXBsYXRlOiAnJywgZGlyZWN0aXZlczogW119KVxuY2xhc3MgTWFpbkNvbXAge1xuICB0ZXh0OiBzdHJpbmcgPSAnJztcbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdvdGhlcicsIHRlbXBsYXRlOiAnJywgZGlyZWN0aXZlczogW119KVxuY2xhc3MgT3RoZXJDb21wIHtcbiAgdGV4dDogc3RyaW5nID0gJyc7XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ3NpbXBsZScsXG4gIGlucHV0czogWydzdHJpbmdQcm9wJ10sXG4gIHRlbXBsYXRlOiAnU0lNUExFKDxuZy1jb250ZW50PjwvbmctY29udGVudD4pJyxcbiAgZGlyZWN0aXZlczogW11cbn0pXG5jbGFzcyBTaW1wbGUge1xuICBzdHJpbmdQcm9wOiBzdHJpbmcgPSAnJztcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnc2ltcGxlLW5hdGl2ZTEnLFxuICB0ZW1wbGF0ZTogJ1NJTVBMRTEoPGNvbnRlbnQ+PC9jb250ZW50PiknLFxuICBkaXJlY3RpdmVzOiBbXSxcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTmF0aXZlLFxuICBzdHlsZXM6IFsnZGl2IHtjb2xvcjogcmVkfSddXG59KVxuY2xhc3MgU2ltcGxlTmF0aXZlMSB7XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ3NpbXBsZS1uYXRpdmUyJyxcbiAgdGVtcGxhdGU6ICdTSU1QTEUyKDxjb250ZW50PjwvY29udGVudD4pJyxcbiAgZGlyZWN0aXZlczogW10sXG4gIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5hdGl2ZSxcbiAgc3R5bGVzOiBbJ2RpdiB7Y29sb3I6IGJsdWV9J11cbn0pXG5jbGFzcyBTaW1wbGVOYXRpdmUyIHtcbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdlbXB0eScsIHRlbXBsYXRlOiAnJywgZGlyZWN0aXZlczogW119KVxuY2xhc3MgRW1wdHkge1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdtdWx0aXBsZS1jb250ZW50LXRhZ3MnLFxuICB0ZW1wbGF0ZTogJyg8bmctY29udGVudCBTRUxFQ1Q9XCIubGVmdFwiPjwvbmctY29udGVudD4sIDxuZy1jb250ZW50PjwvbmctY29udGVudD4pJyxcbiAgZGlyZWN0aXZlczogW11cbn0pXG5jbGFzcyBNdWx0aXBsZUNvbnRlbnRUYWdzQ29tcG9uZW50IHtcbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdbbWFudWFsXSd9KVxuY2xhc3MgTWFudWFsVmlld3BvcnREaXJlY3RpdmUge1xuICBjb25zdHJ1Y3RvcihwdWJsaWMgdmM6IFZpZXdDb250YWluZXJSZWYsIHB1YmxpYyB0ZW1wbGF0ZVJlZjogVGVtcGxhdGVSZWYpIHt9XG4gIHNob3coKSB7IHRoaXMudmMuY3JlYXRlRW1iZWRkZWRWaWV3KHRoaXMudGVtcGxhdGVSZWYsIDApOyB9XG4gIGhpZGUoKSB7IHRoaXMudmMuY2xlYXIoKTsgfVxufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJ1twcm9qZWN0XSd9KVxuY2xhc3MgUHJvamVjdERpcmVjdGl2ZSB7XG4gIGNvbnN0cnVjdG9yKHB1YmxpYyB2YzogVmlld0NvbnRhaW5lclJlZikge31cbiAgc2hvdyh0ZW1wbGF0ZVJlZjogVGVtcGxhdGVSZWYpIHsgdGhpcy52Yy5jcmVhdGVFbWJlZGRlZFZpZXcodGVtcGxhdGVSZWYsIDApOyB9XG4gIGhpZGUoKSB7IHRoaXMudmMuY2xlYXIoKTsgfVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdvdXRlci13aXRoLWluZGlyZWN0LW5lc3RlZCcsXG4gIHRlbXBsYXRlOiAnT1VURVIoPHNpbXBsZT48ZGl2PjxuZy1jb250ZW50PjwvbmctY29udGVudD48L2Rpdj48L3NpbXBsZT4pJyxcbiAgZGlyZWN0aXZlczogW1NpbXBsZV1cbn0pXG5jbGFzcyBPdXRlcldpdGhJbmRpcmVjdE5lc3RlZENvbXBvbmVudCB7XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291dGVyJyxcbiAgdGVtcGxhdGU6XG4gICAgICAnT1VURVIoPGlubmVyPjxuZy1jb250ZW50IHNlbGVjdD1cIi5sZWZ0XCIgY2xhc3M9XCJsZWZ0XCI+PC9uZy1jb250ZW50PjxuZy1jb250ZW50PjwvbmctY29udGVudD48L2lubmVyPiknLFxuICBkaXJlY3RpdmVzOiBbZm9yd2FyZFJlZigoKSA9PiBJbm5lckNvbXBvbmVudCldXG59KVxuY2xhc3MgT3V0ZXJDb21wb25lbnQge1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdpbm5lcicsXG4gIHRlbXBsYXRlOlxuICAgICAgJ0lOTkVSKDxpbm5lcmlubmVyPjxuZy1jb250ZW50IHNlbGVjdD1cIi5sZWZ0XCIgY2xhc3M9XCJsZWZ0XCI+PC9uZy1jb250ZW50PjxuZy1jb250ZW50PjwvbmctY29udGVudD48L2lubmVyaW5uZXI+KScsXG4gIGRpcmVjdGl2ZXM6IFtmb3J3YXJkUmVmKCgpID0+IElubmVySW5uZXJDb21wb25lbnQpXVxufSlcbmNsYXNzIElubmVyQ29tcG9uZW50IHtcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnaW5uZXJpbm5lcicsXG4gIHRlbXBsYXRlOiAnSU5ORVJJTk5FUig8bmctY29udGVudCBzZWxlY3Q9XCIubGVmdFwiPjwvbmctY29udGVudD4sPG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50PiknLFxuICBkaXJlY3RpdmVzOiBbXVxufSlcbmNsYXNzIElubmVySW5uZXJDb21wb25lbnQge1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdjb25kaXRpb25hbC1jb250ZW50JyxcbiAgdGVtcGxhdGU6XG4gICAgICAnPGRpdj4oPGRpdiAqbWFudWFsPjxuZy1jb250ZW50IHNlbGVjdD1cIi5sZWZ0XCI+PC9uZy1jb250ZW50PjwvZGl2PiwgPG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50Pik8L2Rpdj4nLFxuICBkaXJlY3RpdmVzOiBbTWFudWFsVmlld3BvcnREaXJlY3RpdmVdXG59KVxuY2xhc3MgQ29uZGl0aW9uYWxDb250ZW50Q29tcG9uZW50IHtcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY29uZGl0aW9uYWwtdGV4dCcsXG4gIHRlbXBsYXRlOlxuICAgICAgJ01BSU4oPHRlbXBsYXRlIG1hbnVhbD5GSVJTVCg8dGVtcGxhdGUgbWFudWFsPlNFQ09ORCg8bmctY29udGVudD48L25nLWNvbnRlbnQ+KTwvdGVtcGxhdGU+KTwvdGVtcGxhdGU+KScsXG4gIGRpcmVjdGl2ZXM6IFtNYW51YWxWaWV3cG9ydERpcmVjdGl2ZV1cbn0pXG5jbGFzcyBDb25kaXRpb25hbFRleHRDb21wb25lbnQge1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICd0YWInLFxuICB0ZW1wbGF0ZTogJzxkaXY+PGRpdiAqbWFudWFsPlRBQig8bmctY29udGVudD48L25nLWNvbnRlbnQ+KTwvZGl2PjwvZGl2PicsXG4gIGRpcmVjdGl2ZXM6IFtNYW51YWxWaWV3cG9ydERpcmVjdGl2ZV1cbn0pXG5jbGFzcyBUYWIge1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICd0cmVlJyxcbiAgaW5wdXRzOiBbJ2RlcHRoJ10sXG4gIHRlbXBsYXRlOiAnVFJFRSh7e2RlcHRofX06PHRyZWUgKm1hbnVhbCBbZGVwdGhdPVwiZGVwdGgrMVwiPjwvdHJlZT4pJyxcbiAgZGlyZWN0aXZlczogW01hbnVhbFZpZXdwb3J0RGlyZWN0aXZlLCBUcmVlXVxufSlcbmNsYXNzIFRyZWUge1xuICBkZXB0aCA9IDA7XG59XG5cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdjbXAtZCcsIHRlbXBsYXRlOiBgPGQ+e3t0YWdOYW1lfX08L2Q+YH0pXG5jbGFzcyBDbXBEIHtcbiAgdGFnTmFtZTogc3RyaW5nO1xuICBjb25zdHJ1Y3RvcihlbGVtZW50UmVmOiBFbGVtZW50UmVmKSB7XG4gICAgdGhpcy50YWdOYW1lID0gRE9NLnRhZ05hbWUoZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50KS50b0xvd2VyQ2FzZSgpO1xuICB9XG59XG5cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdjbXAtYycsIHRlbXBsYXRlOiBgPGM+e3t0YWdOYW1lfX08L2M+YH0pXG5jbGFzcyBDbXBDIHtcbiAgdGFnTmFtZTogc3RyaW5nO1xuICBjb25zdHJ1Y3RvcihlbGVtZW50UmVmOiBFbGVtZW50UmVmKSB7XG4gICAgdGhpcy50YWdOYW1lID0gRE9NLnRhZ05hbWUoZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50KS50b0xvd2VyQ2FzZSgpO1xuICB9XG59XG5cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdjbXAtYicsIHRlbXBsYXRlOiBgPG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50PjxjbXAtZD48L2NtcC1kPmAsIGRpcmVjdGl2ZXM6IFtDbXBEXX0pXG5jbGFzcyBDbXBCIHtcbn1cblxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ2NtcC1hJywgdGVtcGxhdGU6IGA8bmctY29udGVudD48L25nLWNvbnRlbnQ+PGNtcC1jPjwvY21wLWM+YCwgZGlyZWN0aXZlczogW0NtcENdfSlcbmNsYXNzIENtcEEge1xufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ2NtcC1iMTEnLCB0ZW1wbGF0ZTogYHt7J2IxMSd9fWAsIGRpcmVjdGl2ZXM6IFtdfSlcbmNsYXNzIENtcEIxMSB7XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnY21wLWIxMicsIHRlbXBsYXRlOiBge3snYjEyJ319YCwgZGlyZWN0aXZlczogW119KVxuY2xhc3MgQ21wQjEyIHtcbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdjbXAtYjIxJywgdGVtcGxhdGU6IGB7eydiMjEnfX1gLCBkaXJlY3RpdmVzOiBbXX0pXG5jbGFzcyBDbXBCMjEge1xufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ2NtcC1iMjInLCB0ZW1wbGF0ZTogYHt7J2IyMid9fWAsIGRpcmVjdGl2ZXM6IFtdfSlcbmNsYXNzIENtcEIyMiB7XG59XG5cbkBDb21wb25lbnQoXG4gICAge3NlbGVjdG9yOiAnY21wLWExJywgdGVtcGxhdGU6IGB7eydhMSd9fTxjbXAtYjExPjwvY21wLWIxMT48Y21wLWIxMj48L2NtcC1iMTI+YCwgZGlyZWN0aXZlczogW0NtcEIxMSwgQ21wQjEyXX0pXG5jbGFzcyBDbXBBMSB7XG59XG5cbkBDb21wb25lbnQoXG4gICAge3NlbGVjdG9yOiAnY21wLWEyJywgdGVtcGxhdGU6IGB7eydhMid9fTxjbXAtYjIxPjwvY21wLWIyMT48Y21wLWIyMj48L2NtcC1iMjI+YCwgZGlyZWN0aXZlczogW0NtcEIyMSwgQ21wQjIyXX0pXG5jbGFzcyBDbXBBMiB7XG59XG4iXX0=
 main(); 
