'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var directive_lifecycle_reflector_1 = require('angular2/src/core/linker/directive_lifecycle_reflector');
var interfaces_1 = require('angular2/src/core/linker/interfaces');
function main() {
    testing_internal_1.describe('Create DirectiveMetadata', function () {
        testing_internal_1.describe('lifecycle', function () {
            testing_internal_1.describe("ngOnChanges", function () {
                testing_internal_1.it("should be true when the directive has the ngOnChanges method", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.OnChanges, DirectiveWithOnChangesMethod))
                        .toBe(true);
                });
                testing_internal_1.it("should be false otherwise", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.OnChanges, DirectiveNoHooks)).toBe(false);
                });
            });
            testing_internal_1.describe("ngOnDestroy", function () {
                testing_internal_1.it("should be true when the directive has the ngOnDestroy method", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.OnDestroy, DirectiveWithOnDestroyMethod))
                        .toBe(true);
                });
                testing_internal_1.it("should be false otherwise", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.OnDestroy, DirectiveNoHooks)).toBe(false);
                });
            });
            testing_internal_1.describe("ngOnInit", function () {
                testing_internal_1.it("should be true when the directive has the ngOnInit method", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.OnInit, DirectiveWithOnInitMethod)).toBe(true);
                });
                testing_internal_1.it("should be false otherwise", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.OnInit, DirectiveNoHooks)).toBe(false);
                });
            });
            testing_internal_1.describe("ngDoCheck", function () {
                testing_internal_1.it("should be true when the directive has the ngDoCheck method", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.DoCheck, DirectiveWithOnCheckMethod)).toBe(true);
                });
                testing_internal_1.it("should be false otherwise", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.DoCheck, DirectiveNoHooks)).toBe(false);
                });
            });
            testing_internal_1.describe("ngAfterContentInit", function () {
                testing_internal_1.it("should be true when the directive has the ngAfterContentInit method", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.AfterContentInit, DirectiveWithAfterContentInitMethod))
                        .toBe(true);
                });
                testing_internal_1.it("should be false otherwise", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.AfterContentInit, DirectiveNoHooks)).toBe(false);
                });
            });
            testing_internal_1.describe("ngAfterContentChecked", function () {
                testing_internal_1.it("should be true when the directive has the ngAfterContentChecked method", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.AfterContentChecked, DirectiveWithAfterContentCheckedMethod))
                        .toBe(true);
                });
                testing_internal_1.it("should be false otherwise", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.AfterContentChecked, DirectiveNoHooks))
                        .toBe(false);
                });
            });
            testing_internal_1.describe("ngAfterViewInit", function () {
                testing_internal_1.it("should be true when the directive has the ngAfterViewInit method", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.AfterViewInit, DirectiveWithAfterViewInitMethod))
                        .toBe(true);
                });
                testing_internal_1.it("should be false otherwise", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.AfterViewInit, DirectiveNoHooks)).toBe(false);
                });
            });
            testing_internal_1.describe("ngAfterViewChecked", function () {
                testing_internal_1.it("should be true when the directive has the ngAfterViewChecked method", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.AfterViewChecked, DirectiveWithAfterViewCheckedMethod))
                        .toBe(true);
                });
                testing_internal_1.it("should be false otherwise", function () {
                    testing_internal_1.expect(directive_lifecycle_reflector_1.hasLifecycleHook(interfaces_1.LifecycleHooks.AfterViewChecked, DirectiveNoHooks)).toBe(false);
                });
            });
        });
    });
}
exports.main = main;
var DirectiveNoHooks = (function () {
    function DirectiveNoHooks() {
    }
    return DirectiveNoHooks;
})();
var DirectiveWithOnChangesMethod = (function () {
    function DirectiveWithOnChangesMethod() {
    }
    DirectiveWithOnChangesMethod.prototype.ngOnChanges = function (_) { };
    return DirectiveWithOnChangesMethod;
})();
var DirectiveWithOnInitMethod = (function () {
    function DirectiveWithOnInitMethod() {
    }
    DirectiveWithOnInitMethod.prototype.ngOnInit = function () { };
    return DirectiveWithOnInitMethod;
})();
var DirectiveWithOnCheckMethod = (function () {
    function DirectiveWithOnCheckMethod() {
    }
    DirectiveWithOnCheckMethod.prototype.ngDoCheck = function () { };
    return DirectiveWithOnCheckMethod;
})();
var DirectiveWithOnDestroyMethod = (function () {
    function DirectiveWithOnDestroyMethod() {
    }
    DirectiveWithOnDestroyMethod.prototype.ngOnDestroy = function () { };
    return DirectiveWithOnDestroyMethod;
})();
var DirectiveWithAfterContentInitMethod = (function () {
    function DirectiveWithAfterContentInitMethod() {
    }
    DirectiveWithAfterContentInitMethod.prototype.ngAfterContentInit = function () { };
    return DirectiveWithAfterContentInitMethod;
})();
var DirectiveWithAfterContentCheckedMethod = (function () {
    function DirectiveWithAfterContentCheckedMethod() {
    }
    DirectiveWithAfterContentCheckedMethod.prototype.ngAfterContentChecked = function () { };
    return DirectiveWithAfterContentCheckedMethod;
})();
var DirectiveWithAfterViewInitMethod = (function () {
    function DirectiveWithAfterViewInitMethod() {
    }
    DirectiveWithAfterViewInitMethod.prototype.ngAfterViewInit = function () { };
    return DirectiveWithAfterViewInitMethod;
})();
var DirectiveWithAfterViewCheckedMethod = (function () {
    function DirectiveWithAfterViewCheckedMethod() {
    }
    DirectiveWithAfterViewCheckedMethod.prototype.ngAfterViewChecked = function () { };
    return DirectiveWithAfterViewCheckedMethod;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlyZWN0aXZlX2xpZmVjeWNsZV9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb3JlL2xpbmtlci9kaXJlY3RpdmVfbGlmZWN5Y2xlX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiIsIkRpcmVjdGl2ZU5vSG9va3MiLCJEaXJlY3RpdmVOb0hvb2tzLmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlV2l0aE9uQ2hhbmdlc01ldGhvZCIsIkRpcmVjdGl2ZVdpdGhPbkNoYW5nZXNNZXRob2QuY29uc3RydWN0b3IiLCJEaXJlY3RpdmVXaXRoT25DaGFuZ2VzTWV0aG9kLm5nT25DaGFuZ2VzIiwiRGlyZWN0aXZlV2l0aE9uSW5pdE1ldGhvZCIsIkRpcmVjdGl2ZVdpdGhPbkluaXRNZXRob2QuY29uc3RydWN0b3IiLCJEaXJlY3RpdmVXaXRoT25Jbml0TWV0aG9kLm5nT25Jbml0IiwiRGlyZWN0aXZlV2l0aE9uQ2hlY2tNZXRob2QiLCJEaXJlY3RpdmVXaXRoT25DaGVja01ldGhvZC5jb25zdHJ1Y3RvciIsIkRpcmVjdGl2ZVdpdGhPbkNoZWNrTWV0aG9kLm5nRG9DaGVjayIsIkRpcmVjdGl2ZVdpdGhPbkRlc3Ryb3lNZXRob2QiLCJEaXJlY3RpdmVXaXRoT25EZXN0cm95TWV0aG9kLmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlV2l0aE9uRGVzdHJveU1ldGhvZC5uZ09uRGVzdHJveSIsIkRpcmVjdGl2ZVdpdGhBZnRlckNvbnRlbnRJbml0TWV0aG9kIiwiRGlyZWN0aXZlV2l0aEFmdGVyQ29udGVudEluaXRNZXRob2QuY29uc3RydWN0b3IiLCJEaXJlY3RpdmVXaXRoQWZ0ZXJDb250ZW50SW5pdE1ldGhvZC5uZ0FmdGVyQ29udGVudEluaXQiLCJEaXJlY3RpdmVXaXRoQWZ0ZXJDb250ZW50Q2hlY2tlZE1ldGhvZCIsIkRpcmVjdGl2ZVdpdGhBZnRlckNvbnRlbnRDaGVja2VkTWV0aG9kLmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlV2l0aEFmdGVyQ29udGVudENoZWNrZWRNZXRob2QubmdBZnRlckNvbnRlbnRDaGVja2VkIiwiRGlyZWN0aXZlV2l0aEFmdGVyVmlld0luaXRNZXRob2QiLCJEaXJlY3RpdmVXaXRoQWZ0ZXJWaWV3SW5pdE1ldGhvZC5jb25zdHJ1Y3RvciIsIkRpcmVjdGl2ZVdpdGhBZnRlclZpZXdJbml0TWV0aG9kLm5nQWZ0ZXJWaWV3SW5pdCIsIkRpcmVjdGl2ZVdpdGhBZnRlclZpZXdDaGVja2VkTWV0aG9kIiwiRGlyZWN0aXZlV2l0aEFmdGVyVmlld0NoZWNrZWRNZXRob2QuY29uc3RydWN0b3IiLCJEaXJlY3RpdmVXaXRoQWZ0ZXJWaWV3Q2hlY2tlZE1ldGhvZC5uZ0FmdGVyVmlld0NoZWNrZWQiXSwibWFwcGluZ3MiOiJBQUFBLGlDQWFPLDJCQUEyQixDQUFDLENBQUE7QUFFbkMsOENBQStCLHdEQUF3RCxDQUFDLENBQUE7QUFDeEYsMkJBQTZCLHFDQUFxQyxDQUFDLENBQUE7QUFFbkU7SUFDRUEsMkJBQVFBLENBQUNBLDBCQUEwQkEsRUFBRUE7UUFDbkNBLDJCQUFRQSxDQUFDQSxXQUFXQSxFQUFFQTtZQUVwQkEsMkJBQVFBLENBQUNBLGFBQWFBLEVBQUVBO2dCQUN0QkEscUJBQUVBLENBQUNBLDhEQUE4REEsRUFBRUE7b0JBQ2pFQSx5QkFBTUEsQ0FBQ0EsZ0RBQWdCQSxDQUFDQSwyQkFBY0EsQ0FBQ0EsU0FBU0EsRUFBRUEsNEJBQTRCQSxDQUFDQSxDQUFDQTt5QkFDM0VBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO2dCQUNsQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLHFCQUFFQSxDQUFDQSwyQkFBMkJBLEVBQUVBO29CQUM5QkEseUJBQU1BLENBQUNBLGdEQUFnQkEsQ0FBQ0EsMkJBQWNBLENBQUNBLFNBQVNBLEVBQUVBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ25GQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSwyQkFBUUEsQ0FBQ0EsYUFBYUEsRUFBRUE7Z0JBQ3RCQSxxQkFBRUEsQ0FBQ0EsOERBQThEQSxFQUFFQTtvQkFDakVBLHlCQUFNQSxDQUFDQSxnREFBZ0JBLENBQUNBLDJCQUFjQSxDQUFDQSxTQUFTQSxFQUFFQSw0QkFBNEJBLENBQUNBLENBQUNBO3lCQUMzRUEsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ2xCQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFSEEscUJBQUVBLENBQUNBLDJCQUEyQkEsRUFBRUE7b0JBQzlCQSx5QkFBTUEsQ0FBQ0EsZ0RBQWdCQSxDQUFDQSwyQkFBY0EsQ0FBQ0EsU0FBU0EsRUFBRUEsZ0JBQWdCQSxDQUFDQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQTtnQkFDbkZBLENBQUNBLENBQUNBLENBQUNBO1lBQ0xBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLDJCQUFRQSxDQUFDQSxVQUFVQSxFQUFFQTtnQkFDbkJBLHFCQUFFQSxDQUFDQSwyREFBMkRBLEVBQUVBO29CQUM5REEseUJBQU1BLENBQUNBLGdEQUFnQkEsQ0FBQ0EsMkJBQWNBLENBQUNBLE1BQU1BLEVBQUVBLHlCQUF5QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3hGQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFSEEscUJBQUVBLENBQUNBLDJCQUEyQkEsRUFBRUE7b0JBQzlCQSx5QkFBTUEsQ0FBQ0EsZ0RBQWdCQSxDQUFDQSwyQkFBY0EsQ0FBQ0EsTUFBTUEsRUFBRUEsZ0JBQWdCQSxDQUFDQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQTtnQkFDaEZBLENBQUNBLENBQUNBLENBQUNBO1lBQ0xBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLDJCQUFRQSxDQUFDQSxXQUFXQSxFQUFFQTtnQkFDcEJBLHFCQUFFQSxDQUFDQSw0REFBNERBLEVBQUVBO29CQUMvREEseUJBQU1BLENBQUNBLGdEQUFnQkEsQ0FBQ0EsMkJBQWNBLENBQUNBLE9BQU9BLEVBQUVBLDBCQUEwQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7Z0JBQzFGQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFSEEscUJBQUVBLENBQUNBLDJCQUEyQkEsRUFBRUE7b0JBQzlCQSx5QkFBTUEsQ0FBQ0EsZ0RBQWdCQSxDQUFDQSwyQkFBY0EsQ0FBQ0EsT0FBT0EsRUFBRUEsZ0JBQWdCQSxDQUFDQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQTtnQkFDakZBLENBQUNBLENBQUNBLENBQUNBO1lBQ0xBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLDJCQUFRQSxDQUFDQSxvQkFBb0JBLEVBQUVBO2dCQUM3QkEscUJBQUVBLENBQUNBLHFFQUFxRUEsRUFBRUE7b0JBQ3hFQSx5QkFBTUEsQ0FBQ0EsZ0RBQWdCQSxDQUFDQSwyQkFBY0EsQ0FBQ0EsZ0JBQWdCQSxFQUMvQkEsbUNBQW1DQSxDQUFDQSxDQUFDQTt5QkFDeERBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO2dCQUNsQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLHFCQUFFQSxDQUFDQSwyQkFBMkJBLEVBQUVBO29CQUM5QkEseUJBQU1BLENBQUNBLGdEQUFnQkEsQ0FBQ0EsMkJBQWNBLENBQUNBLGdCQUFnQkEsRUFBRUEsZ0JBQWdCQSxDQUFDQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQTtnQkFDMUZBLENBQUNBLENBQUNBLENBQUNBO1lBQ0xBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLDJCQUFRQSxDQUFDQSx1QkFBdUJBLEVBQUVBO2dCQUNoQ0EscUJBQUVBLENBQUNBLHdFQUF3RUEsRUFBRUE7b0JBQzNFQSx5QkFBTUEsQ0FBQ0EsZ0RBQWdCQSxDQUFDQSwyQkFBY0EsQ0FBQ0EsbUJBQW1CQSxFQUNsQ0Esc0NBQXNDQSxDQUFDQSxDQUFDQTt5QkFDM0RBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO2dCQUNsQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLHFCQUFFQSxDQUFDQSwyQkFBMkJBLEVBQUVBO29CQUM5QkEseUJBQU1BLENBQUNBLGdEQUFnQkEsQ0FBQ0EsMkJBQWNBLENBQUNBLG1CQUFtQkEsRUFBRUEsZ0JBQWdCQSxDQUFDQSxDQUFDQTt5QkFDekVBLElBQUlBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO2dCQUNuQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFHSEEsMkJBQVFBLENBQUNBLGlCQUFpQkEsRUFBRUE7Z0JBQzFCQSxxQkFBRUEsQ0FBQ0Esa0VBQWtFQSxFQUFFQTtvQkFDckVBLHlCQUFNQSxDQUFDQSxnREFBZ0JBLENBQUNBLDJCQUFjQSxDQUFDQSxhQUFhQSxFQUFFQSxnQ0FBZ0NBLENBQUNBLENBQUNBO3lCQUNuRkEsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ2xCQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFSEEscUJBQUVBLENBQUNBLDJCQUEyQkEsRUFBRUE7b0JBQzlCQSx5QkFBTUEsQ0FBQ0EsZ0RBQWdCQSxDQUFDQSwyQkFBY0EsQ0FBQ0EsYUFBYUEsRUFBRUEsZ0JBQWdCQSxDQUFDQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQTtnQkFDdkZBLENBQUNBLENBQUNBLENBQUNBO1lBQ0xBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLDJCQUFRQSxDQUFDQSxvQkFBb0JBLEVBQUVBO2dCQUM3QkEscUJBQUVBLENBQUNBLHFFQUFxRUEsRUFBRUE7b0JBQ3hFQSx5QkFBTUEsQ0FBQ0EsZ0RBQWdCQSxDQUFDQSwyQkFBY0EsQ0FBQ0EsZ0JBQWdCQSxFQUMvQkEsbUNBQW1DQSxDQUFDQSxDQUFDQTt5QkFDeERBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO2dCQUNsQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLHFCQUFFQSxDQUFDQSwyQkFBMkJBLEVBQUVBO29CQUM5QkEseUJBQU1BLENBQUNBLGdEQUFnQkEsQ0FBQ0EsMkJBQWNBLENBQUNBLGdCQUFnQkEsRUFBRUEsZ0JBQWdCQSxDQUFDQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQTtnQkFDMUZBLENBQUNBLENBQUNBLENBQUNBO1lBQ0xBLENBQUNBLENBQUNBLENBQUNBO1FBQ0xBLENBQUNBLENBQUNBLENBQUNBO0lBQ0xBLENBQUNBLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBaEdlLFlBQUksT0FnR25CLENBQUE7QUFFRDtJQUFBQztJQUF3QkMsQ0FBQ0E7SUFBREQsdUJBQUNBO0FBQURBLENBQUNBLEFBQXpCLElBQXlCO0FBRXpCO0lBQUFFO0lBRUFDLENBQUNBO0lBRENELGtEQUFXQSxHQUFYQSxVQUFZQSxDQUFDQSxJQUFHRSxDQUFDQTtJQUNuQkYsbUNBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBQUFHO0lBRUFDLENBQUNBO0lBRENELDRDQUFRQSxHQUFSQSxjQUFZRSxDQUFDQTtJQUNmRixnQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDO0FBRUQ7SUFBQUc7SUFFQUMsQ0FBQ0E7SUFEQ0QsOENBQVNBLEdBQVRBLGNBQWFFLENBQUNBO0lBQ2hCRixpQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDO0FBRUQ7SUFBQUc7SUFFQUMsQ0FBQ0E7SUFEQ0Qsa0RBQVdBLEdBQVhBLGNBQWVFLENBQUNBO0lBQ2xCRixtQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDO0FBRUQ7SUFBQUc7SUFFQUMsQ0FBQ0E7SUFEQ0QsZ0VBQWtCQSxHQUFsQkEsY0FBc0JFLENBQUNBO0lBQ3pCRiwwQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDO0FBRUQ7SUFBQUc7SUFFQUMsQ0FBQ0E7SUFEQ0Qsc0VBQXFCQSxHQUFyQkEsY0FBeUJFLENBQUNBO0lBQzVCRiw2Q0FBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDO0FBRUQ7SUFBQUc7SUFFQUMsQ0FBQ0E7SUFEQ0QsMERBQWVBLEdBQWZBLGNBQW1CRSxDQUFDQTtJQUN0QkYsdUNBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBQUFHO0lBRUFDLENBQUNBO0lBRENELGdFQUFrQkEsR0FBbEJBLGNBQXNCRSxDQUFDQTtJQUN6QkYsMENBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFzeW5jVGVzdENvbXBsZXRlcixcbiAgYmVmb3JlRWFjaCxcbiAgeGRlc2NyaWJlLFxuICBkZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICBlbCxcbiAgZXhwZWN0LFxuICBpaXQsXG4gIGluamVjdCxcbiAgaXQsXG4gIFNweU9iamVjdCxcbiAgcHJveHlcbn0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmltcG9ydCB7aGFzTGlmZWN5Y2xlSG9va30gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvbGlua2VyL2RpcmVjdGl2ZV9saWZlY3ljbGVfcmVmbGVjdG9yJztcbmltcG9ydCB7TGlmZWN5Y2xlSG9va3N9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci9pbnRlcmZhY2VzJztcblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGRlc2NyaWJlKCdDcmVhdGUgRGlyZWN0aXZlTWV0YWRhdGEnLCAoKSA9PiB7XG4gICAgZGVzY3JpYmUoJ2xpZmVjeWNsZScsICgpID0+IHtcblxuICAgICAgZGVzY3JpYmUoXCJuZ09uQ2hhbmdlc1wiLCAoKSA9PiB7XG4gICAgICAgIGl0KFwic2hvdWxkIGJlIHRydWUgd2hlbiB0aGUgZGlyZWN0aXZlIGhhcyB0aGUgbmdPbkNoYW5nZXMgbWV0aG9kXCIsICgpID0+IHtcbiAgICAgICAgICBleHBlY3QoaGFzTGlmZWN5Y2xlSG9vayhMaWZlY3ljbGVIb29rcy5PbkNoYW5nZXMsIERpcmVjdGl2ZVdpdGhPbkNoYW5nZXNNZXRob2QpKVxuICAgICAgICAgICAgICAudG9CZSh0cnVlKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaXQoXCJzaG91bGQgYmUgZmFsc2Ugb3RoZXJ3aXNlXCIsICgpID0+IHtcbiAgICAgICAgICBleHBlY3QoaGFzTGlmZWN5Y2xlSG9vayhMaWZlY3ljbGVIb29rcy5PbkNoYW5nZXMsIERpcmVjdGl2ZU5vSG9va3MpKS50b0JlKGZhbHNlKTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcblxuICAgICAgZGVzY3JpYmUoXCJuZ09uRGVzdHJveVwiLCAoKSA9PiB7XG4gICAgICAgIGl0KFwic2hvdWxkIGJlIHRydWUgd2hlbiB0aGUgZGlyZWN0aXZlIGhhcyB0aGUgbmdPbkRlc3Ryb3kgbWV0aG9kXCIsICgpID0+IHtcbiAgICAgICAgICBleHBlY3QoaGFzTGlmZWN5Y2xlSG9vayhMaWZlY3ljbGVIb29rcy5PbkRlc3Ryb3ksIERpcmVjdGl2ZVdpdGhPbkRlc3Ryb3lNZXRob2QpKVxuICAgICAgICAgICAgICAudG9CZSh0cnVlKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaXQoXCJzaG91bGQgYmUgZmFsc2Ugb3RoZXJ3aXNlXCIsICgpID0+IHtcbiAgICAgICAgICBleHBlY3QoaGFzTGlmZWN5Y2xlSG9vayhMaWZlY3ljbGVIb29rcy5PbkRlc3Ryb3ksIERpcmVjdGl2ZU5vSG9va3MpKS50b0JlKGZhbHNlKTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcblxuICAgICAgZGVzY3JpYmUoXCJuZ09uSW5pdFwiLCAoKSA9PiB7XG4gICAgICAgIGl0KFwic2hvdWxkIGJlIHRydWUgd2hlbiB0aGUgZGlyZWN0aXZlIGhhcyB0aGUgbmdPbkluaXQgbWV0aG9kXCIsICgpID0+IHtcbiAgICAgICAgICBleHBlY3QoaGFzTGlmZWN5Y2xlSG9vayhMaWZlY3ljbGVIb29rcy5PbkluaXQsIERpcmVjdGl2ZVdpdGhPbkluaXRNZXRob2QpKS50b0JlKHRydWUpO1xuICAgICAgICB9KTtcblxuICAgICAgICBpdChcInNob3VsZCBiZSBmYWxzZSBvdGhlcndpc2VcIiwgKCkgPT4ge1xuICAgICAgICAgIGV4cGVjdChoYXNMaWZlY3ljbGVIb29rKExpZmVjeWNsZUhvb2tzLk9uSW5pdCwgRGlyZWN0aXZlTm9Ib29rcykpLnRvQmUoZmFsc2UpO1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuXG4gICAgICBkZXNjcmliZShcIm5nRG9DaGVja1wiLCAoKSA9PiB7XG4gICAgICAgIGl0KFwic2hvdWxkIGJlIHRydWUgd2hlbiB0aGUgZGlyZWN0aXZlIGhhcyB0aGUgbmdEb0NoZWNrIG1ldGhvZFwiLCAoKSA9PiB7XG4gICAgICAgICAgZXhwZWN0KGhhc0xpZmVjeWNsZUhvb2soTGlmZWN5Y2xlSG9va3MuRG9DaGVjaywgRGlyZWN0aXZlV2l0aE9uQ2hlY2tNZXRob2QpKS50b0JlKHRydWUpO1xuICAgICAgICB9KTtcblxuICAgICAgICBpdChcInNob3VsZCBiZSBmYWxzZSBvdGhlcndpc2VcIiwgKCkgPT4ge1xuICAgICAgICAgIGV4cGVjdChoYXNMaWZlY3ljbGVIb29rKExpZmVjeWNsZUhvb2tzLkRvQ2hlY2ssIERpcmVjdGl2ZU5vSG9va3MpKS50b0JlKGZhbHNlKTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcblxuICAgICAgZGVzY3JpYmUoXCJuZ0FmdGVyQ29udGVudEluaXRcIiwgKCkgPT4ge1xuICAgICAgICBpdChcInNob3VsZCBiZSB0cnVlIHdoZW4gdGhlIGRpcmVjdGl2ZSBoYXMgdGhlIG5nQWZ0ZXJDb250ZW50SW5pdCBtZXRob2RcIiwgKCkgPT4ge1xuICAgICAgICAgIGV4cGVjdChoYXNMaWZlY3ljbGVIb29rKExpZmVjeWNsZUhvb2tzLkFmdGVyQ29udGVudEluaXQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRGlyZWN0aXZlV2l0aEFmdGVyQ29udGVudEluaXRNZXRob2QpKVxuICAgICAgICAgICAgICAudG9CZSh0cnVlKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaXQoXCJzaG91bGQgYmUgZmFsc2Ugb3RoZXJ3aXNlXCIsICgpID0+IHtcbiAgICAgICAgICBleHBlY3QoaGFzTGlmZWN5Y2xlSG9vayhMaWZlY3ljbGVIb29rcy5BZnRlckNvbnRlbnRJbml0LCBEaXJlY3RpdmVOb0hvb2tzKSkudG9CZShmYWxzZSk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG5cbiAgICAgIGRlc2NyaWJlKFwibmdBZnRlckNvbnRlbnRDaGVja2VkXCIsICgpID0+IHtcbiAgICAgICAgaXQoXCJzaG91bGQgYmUgdHJ1ZSB3aGVuIHRoZSBkaXJlY3RpdmUgaGFzIHRoZSBuZ0FmdGVyQ29udGVudENoZWNrZWQgbWV0aG9kXCIsICgpID0+IHtcbiAgICAgICAgICBleHBlY3QoaGFzTGlmZWN5Y2xlSG9vayhMaWZlY3ljbGVIb29rcy5BZnRlckNvbnRlbnRDaGVja2VkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERpcmVjdGl2ZVdpdGhBZnRlckNvbnRlbnRDaGVja2VkTWV0aG9kKSlcbiAgICAgICAgICAgICAgLnRvQmUodHJ1ZSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGl0KFwic2hvdWxkIGJlIGZhbHNlIG90aGVyd2lzZVwiLCAoKSA9PiB7XG4gICAgICAgICAgZXhwZWN0KGhhc0xpZmVjeWNsZUhvb2soTGlmZWN5Y2xlSG9va3MuQWZ0ZXJDb250ZW50Q2hlY2tlZCwgRGlyZWN0aXZlTm9Ib29rcykpXG4gICAgICAgICAgICAgIC50b0JlKGZhbHNlKTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcblxuXG4gICAgICBkZXNjcmliZShcIm5nQWZ0ZXJWaWV3SW5pdFwiLCAoKSA9PiB7XG4gICAgICAgIGl0KFwic2hvdWxkIGJlIHRydWUgd2hlbiB0aGUgZGlyZWN0aXZlIGhhcyB0aGUgbmdBZnRlclZpZXdJbml0IG1ldGhvZFwiLCAoKSA9PiB7XG4gICAgICAgICAgZXhwZWN0KGhhc0xpZmVjeWNsZUhvb2soTGlmZWN5Y2xlSG9va3MuQWZ0ZXJWaWV3SW5pdCwgRGlyZWN0aXZlV2l0aEFmdGVyVmlld0luaXRNZXRob2QpKVxuICAgICAgICAgICAgICAudG9CZSh0cnVlKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaXQoXCJzaG91bGQgYmUgZmFsc2Ugb3RoZXJ3aXNlXCIsICgpID0+IHtcbiAgICAgICAgICBleHBlY3QoaGFzTGlmZWN5Y2xlSG9vayhMaWZlY3ljbGVIb29rcy5BZnRlclZpZXdJbml0LCBEaXJlY3RpdmVOb0hvb2tzKSkudG9CZShmYWxzZSk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG5cbiAgICAgIGRlc2NyaWJlKFwibmdBZnRlclZpZXdDaGVja2VkXCIsICgpID0+IHtcbiAgICAgICAgaXQoXCJzaG91bGQgYmUgdHJ1ZSB3aGVuIHRoZSBkaXJlY3RpdmUgaGFzIHRoZSBuZ0FmdGVyVmlld0NoZWNrZWQgbWV0aG9kXCIsICgpID0+IHtcbiAgICAgICAgICBleHBlY3QoaGFzTGlmZWN5Y2xlSG9vayhMaWZlY3ljbGVIb29rcy5BZnRlclZpZXdDaGVja2VkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERpcmVjdGl2ZVdpdGhBZnRlclZpZXdDaGVja2VkTWV0aG9kKSlcbiAgICAgICAgICAgICAgLnRvQmUodHJ1ZSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGl0KFwic2hvdWxkIGJlIGZhbHNlIG90aGVyd2lzZVwiLCAoKSA9PiB7XG4gICAgICAgICAgZXhwZWN0KGhhc0xpZmVjeWNsZUhvb2soTGlmZWN5Y2xlSG9va3MuQWZ0ZXJWaWV3Q2hlY2tlZCwgRGlyZWN0aXZlTm9Ib29rcykpLnRvQmUoZmFsc2UpO1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9KTtcbn1cblxuY2xhc3MgRGlyZWN0aXZlTm9Ib29rcyB7fVxuXG5jbGFzcyBEaXJlY3RpdmVXaXRoT25DaGFuZ2VzTWV0aG9kIHtcbiAgbmdPbkNoYW5nZXMoXykge31cbn1cblxuY2xhc3MgRGlyZWN0aXZlV2l0aE9uSW5pdE1ldGhvZCB7XG4gIG5nT25Jbml0KCkge31cbn1cblxuY2xhc3MgRGlyZWN0aXZlV2l0aE9uQ2hlY2tNZXRob2Qge1xuICBuZ0RvQ2hlY2soKSB7fVxufVxuXG5jbGFzcyBEaXJlY3RpdmVXaXRoT25EZXN0cm95TWV0aG9kIHtcbiAgbmdPbkRlc3Ryb3koKSB7fVxufVxuXG5jbGFzcyBEaXJlY3RpdmVXaXRoQWZ0ZXJDb250ZW50SW5pdE1ldGhvZCB7XG4gIG5nQWZ0ZXJDb250ZW50SW5pdCgpIHt9XG59XG5cbmNsYXNzIERpcmVjdGl2ZVdpdGhBZnRlckNvbnRlbnRDaGVja2VkTWV0aG9kIHtcbiAgbmdBZnRlckNvbnRlbnRDaGVja2VkKCkge31cbn1cblxuY2xhc3MgRGlyZWN0aXZlV2l0aEFmdGVyVmlld0luaXRNZXRob2Qge1xuICBuZ0FmdGVyVmlld0luaXQoKSB7fVxufVxuXG5jbGFzcyBEaXJlY3RpdmVXaXRoQWZ0ZXJWaWV3Q2hlY2tlZE1ldGhvZCB7XG4gIG5nQWZ0ZXJWaWV3Q2hlY2tlZCgpIHt9XG59XG4iXX0=
 main(); 
