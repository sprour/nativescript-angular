'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var core_1 = require('angular2/core');
var common_1 = require('angular2/common');
var metadata_1 = require('angular2/src/core/metadata');
var dynamic_component_loader_1 = require('angular2/src/core/linker/dynamic_component_loader');
var element_ref_1 = require('angular2/src/core/linker/element_ref');
var dom_tokens_1 = require('angular2/src/platform/dom/dom_tokens');
var dom_adapter_1 = require('angular2/src/platform/dom/dom_adapter');
var test_component_builder_1 = require("angular2/src/testing/test_component_builder");
var exceptions_1 = require('angular2/src/facade/exceptions');
var promise_1 = require('angular2/src/facade/promise');
var lang_1 = require('angular2/src/facade/lang');
function main() {
    testing_internal_1.describe('DynamicComponentLoader', function () {
        testing_internal_1.describe("loading into a location", function () {
            testing_internal_1.it('should work', testing_internal_1.inject([dynamic_component_loader_1.DynamicComponentLoader, testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (loader, tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<location #loc></location>', directives: [Location] }))
                    .createAsync(MyComp)
                    .then(function (tc) {
                    loader.loadIntoLocation(DynamicallyLoaded, tc.elementRef, 'loc')
                        .then(function (ref) {
                        testing_internal_1.expect(tc.debugElement.nativeElement)
                            .toHaveText("Location;DynamicallyLoaded;");
                        async.done();
                    });
                });
            }));
            testing_internal_1.it('should return a disposable component ref', testing_internal_1.inject([dynamic_component_loader_1.DynamicComponentLoader, testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (loader, tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<location #loc></location>', directives: [Location] }))
                    .createAsync(MyComp)
                    .then(function (tc) {
                    loader.loadIntoLocation(DynamicallyLoaded, tc.elementRef, 'loc')
                        .then(function (ref) {
                        ref.dispose();
                        testing_internal_1.expect(tc.debugElement.nativeElement).toHaveText("Location;");
                        async.done();
                    });
                });
            }));
            testing_internal_1.it('should allow to dispose even if the location has been removed', testing_internal_1.inject([dynamic_component_loader_1.DynamicComponentLoader, testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (loader, tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<child-cmp *ngIf="ctxBoolProp"></child-cmp>',
                    directives: [common_1.NgIf, ChildComp]
                }))
                    .overrideView(ChildComp, new metadata_1.ViewMetadata({ template: '<location #loc></location>', directives: [Location] }))
                    .createAsync(MyComp)
                    .then(function (tc) {
                    tc.debugElement.componentInstance.ctxBoolProp = true;
                    tc.detectChanges();
                    var childCompEl = tc.elementRef.internalElement;
                    // TODO(juliemr): This is hideous, see if there's a better way to handle
                    // child element refs now.
                    var childElementRef = childCompEl.componentView.appElements[0].nestedViews[0].appElements[0].ref;
                    loader.loadIntoLocation(DynamicallyLoaded, childElementRef, 'loc')
                        .then(function (ref) {
                        testing_internal_1.expect(tc.debugElement.nativeElement)
                            .toHaveText("Location;DynamicallyLoaded;");
                        tc.debugElement.componentInstance.ctxBoolProp = false;
                        tc.detectChanges();
                        testing_internal_1.expect(tc.debugElement.nativeElement).toHaveText("");
                        ref.dispose();
                        testing_internal_1.expect(tc.debugElement.nativeElement).toHaveText("");
                        async.done();
                    });
                });
            }));
            testing_internal_1.it('should update host properties', testing_internal_1.inject([dynamic_component_loader_1.DynamicComponentLoader, testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (loader, tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<location #loc></location>', directives: [Location] }))
                    .createAsync(MyComp)
                    .then(function (tc) {
                    loader.loadIntoLocation(DynamicallyLoadedWithHostProps, tc.elementRef, 'loc')
                        .then(function (ref) {
                        ref.instance.id = "new value";
                        tc.detectChanges();
                        var newlyInsertedElement = dom_adapter_1.DOM.childNodes(tc.debugElement.nativeElement)[1];
                        testing_internal_1.expect(newlyInsertedElement.id).toEqual("new value");
                        async.done();
                    });
                });
            }));
            testing_internal_1.it('should leave the view tree in a consistent state if hydration fails', testing_internal_1.inject([dynamic_component_loader_1.DynamicComponentLoader, testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (loader, tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<div><location #loc></location></div>',
                    directives: [Location]
                }))
                    .createAsync(MyComp)
                    .then(function (tc) {
                    tc.debugElement;
                    promise_1.PromiseWrapper.catchError(loader.loadIntoLocation(DynamicallyLoadedThrows, tc.elementRef, 'loc'), function (error) {
                        testing_internal_1.expect(error.message).toContain("ThrownInConstructor");
                        testing_internal_1.expect(function () { return tc.detectChanges(); }).not.toThrow();
                        async.done();
                        return null;
                    });
                });
            }));
            testing_internal_1.it('should throw if the variable does not exist', testing_internal_1.inject([dynamic_component_loader_1.DynamicComponentLoader, testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (loader, tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<location #loc></location>', directives: [Location] }))
                    .createAsync(MyComp)
                    .then(function (tc) {
                    testing_internal_1.expect(function () { return loader.loadIntoLocation(DynamicallyLoadedWithHostProps, tc.elementRef, 'someUnknownVariable'); })
                        .toThrowError('Could not find variable someUnknownVariable');
                    async.done();
                });
            }));
            testing_internal_1.it('should allow to pass projectable nodes', testing_internal_1.inject([dynamic_component_loader_1.DynamicComponentLoader, testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (loader, tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div #loc></div>', directives: [] }))
                    .createAsync(MyComp)
                    .then(function (tc) {
                    loader.loadIntoLocation(DynamicallyLoadedWithNgContent, tc.elementRef, 'loc', null, [[dom_adapter_1.DOM.createTextNode('hello')]])
                        .then(function (ref) {
                        tc.detectChanges();
                        testing_internal_1.expect(tc.nativeElement).toHaveText('dynamic(hello)');
                        async.done();
                    });
                });
            }));
            testing_internal_1.it('should throw if not enough projectable nodes are passed in', testing_internal_1.inject([dynamic_component_loader_1.DynamicComponentLoader, testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (loader, tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div #loc></div>', directives: [] }))
                    .createAsync(MyComp)
                    .then(function (tc) {
                    promise_1.PromiseWrapper.catchError(loader.loadIntoLocation(DynamicallyLoadedWithNgContent, tc.elementRef, 'loc', null, []), function (e) {
                        testing_internal_1.expect(e.message).toContain("The component " + lang_1.stringify(DynamicallyLoadedWithNgContent) + " has 1 <ng-content> elements, but only 0 slots were provided");
                        async.done();
                        return null;
                    });
                });
            }));
        });
        testing_internal_1.describe("loading next to a location", function () {
            testing_internal_1.it('should work', testing_internal_1.inject([dynamic_component_loader_1.DynamicComponentLoader, testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (loader, tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<div><location #loc></location></div>',
                    directives: [Location]
                }))
                    .createAsync(MyComp)
                    .then(function (tc) {
                    loader.loadNextToLocation(DynamicallyLoaded, tc.elementRef)
                        .then(function (ref) {
                        testing_internal_1.expect(tc.debugElement.nativeElement).toHaveText("Location;");
                        testing_internal_1.expect(dom_adapter_1.DOM.nextSibling(tc.debugElement.nativeElement))
                            .toHaveText('DynamicallyLoaded;');
                        async.done();
                    });
                });
            }));
            testing_internal_1.it('should return a disposable component ref', testing_internal_1.inject([dynamic_component_loader_1.DynamicComponentLoader, testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (loader, tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<div><location #loc></location></div>',
                    directives: [Location]
                }))
                    .
                        createAsync(MyComp)
                    .then(function (tc) {
                    loader.loadNextToLocation(DynamicallyLoaded, tc.elementRef)
                        .then(function (ref) {
                        loader.loadNextToLocation(DynamicallyLoaded2, tc.elementRef)
                            .then(function (ref2) {
                            var firstSibling = dom_adapter_1.DOM.nextSibling(tc.debugElement.nativeElement);
                            var secondSibling = dom_adapter_1.DOM.nextSibling(firstSibling);
                            testing_internal_1.expect(tc.debugElement.nativeElement).toHaveText("Location;");
                            testing_internal_1.expect(firstSibling).toHaveText("DynamicallyLoaded;");
                            testing_internal_1.expect(secondSibling).toHaveText("DynamicallyLoaded2;");
                            ref2.dispose();
                            firstSibling = dom_adapter_1.DOM.nextSibling(tc.debugElement.nativeElement);
                            secondSibling = dom_adapter_1.DOM.nextSibling(firstSibling);
                            testing_internal_1.expect(secondSibling).toBeNull();
                            async.done();
                        });
                    });
                });
            }));
            testing_internal_1.it('should update host properties', testing_internal_1.inject([dynamic_component_loader_1.DynamicComponentLoader, testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (loader, tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<div><location #loc></location></div>',
                    directives: [Location]
                }))
                    .createAsync(MyComp)
                    .then(function (tc) {
                    loader.loadNextToLocation(DynamicallyLoadedWithHostProps, tc.elementRef)
                        .then(function (ref) {
                        ref.instance.id = "new value";
                        tc.detectChanges();
                        var newlyInsertedElement = dom_adapter_1.DOM.nextSibling(tc.debugElement.nativeElement);
                        testing_internal_1.expect(newlyInsertedElement.id).toEqual("new value");
                        async.done();
                    });
                });
            }));
            testing_internal_1.it('should allow to pass projectable nodes', testing_internal_1.inject([dynamic_component_loader_1.DynamicComponentLoader, testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (loader, tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '', directives: [Location] }))
                    .createAsync(MyComp)
                    .then(function (tc) {
                    loader.loadNextToLocation(DynamicallyLoadedWithNgContent, tc.elementRef, null, [[dom_adapter_1.DOM.createTextNode('hello')]])
                        .then(function (ref) {
                        tc.detectChanges();
                        var newlyInsertedElement = dom_adapter_1.DOM.nextSibling(tc.debugElement.nativeElement);
                        testing_internal_1.expect(newlyInsertedElement).toHaveText('dynamic(hello)');
                        async.done();
                    });
                });
            }));
        });
        testing_internal_1.describe('loadAsRoot', function () {
            testing_internal_1.it('should allow to create, update and destroy components', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter, dynamic_component_loader_1.DynamicComponentLoader, dom_tokens_1.DOCUMENT, core_1.Injector], function (async, loader, doc, injector) {
                var rootEl = createRootElement(doc, 'child-cmp');
                dom_adapter_1.DOM.appendChild(doc.body, rootEl);
                loader.loadAsRoot(ChildComp, null, injector)
                    .then(function (componentRef) {
                    var el = new test_component_builder_1.ComponentFixture_(componentRef);
                    testing_internal_1.expect(rootEl.parentNode).toBe(doc.body);
                    el.detectChanges();
                    testing_internal_1.expect(rootEl).toHaveText('hello');
                    componentRef.instance.ctxProp = 'new';
                    el.detectChanges();
                    testing_internal_1.expect(rootEl).toHaveText('new');
                    componentRef.dispose();
                    testing_internal_1.expect(rootEl.parentNode).toBeFalsy();
                    async.done();
                });
            }));
            testing_internal_1.it('should allow to pass projectable nodes', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter, dynamic_component_loader_1.DynamicComponentLoader, dom_tokens_1.DOCUMENT, core_1.Injector], function (async, loader, doc, injector) {
                var rootEl = createRootElement(doc, 'dummy');
                dom_adapter_1.DOM.appendChild(doc.body, rootEl);
                loader.loadAsRoot(DynamicallyLoadedWithNgContent, null, injector, null, [[dom_adapter_1.DOM.createTextNode('hello')]])
                    .then(function (_) {
                    testing_internal_1.expect(rootEl).toHaveText('dynamic(hello)');
                    async.done();
                });
            }));
        });
    });
}
exports.main = main;
function createRootElement(doc, name) {
    var nodes = dom_adapter_1.DOM.querySelectorAll(doc, name);
    for (var i = 0; i < nodes.length; i++) {
        dom_adapter_1.DOM.remove(nodes[i]);
    }
    var rootEl = testing_internal_1.el("<" + name + "></" + name + ">");
    dom_adapter_1.DOM.appendChild(doc.body, rootEl);
    return rootEl;
}
var ChildComp = (function () {
    function ChildComp() {
        this.ctxProp = 'hello';
    }
    ChildComp = __decorate([
        metadata_1.Component({ selector: 'child-cmp', template: '{{ctxProp}}' }), 
        __metadata('design:paramtypes', [])
    ], ChildComp);
    return ChildComp;
})();
var DynamicallyCreatedComponentService = (function () {
    function DynamicallyCreatedComponentService() {
    }
    return DynamicallyCreatedComponentService;
})();
var DynamicallyCreatedCmp = (function () {
    function DynamicallyCreatedCmp(a) {
        this.destroyed = false;
        this.greeting = "hello";
        this.dynamicallyCreatedComponentService = a;
    }
    DynamicallyCreatedCmp.prototype.ngOnDestroy = function () { this.destroyed = true; };
    DynamicallyCreatedCmp = __decorate([
        metadata_1.Component({
            selector: 'hello-cmp',
            viewProviders: [DynamicallyCreatedComponentService],
            template: "{{greeting}}"
        }), 
        __metadata('design:paramtypes', [DynamicallyCreatedComponentService])
    ], DynamicallyCreatedCmp);
    return DynamicallyCreatedCmp;
})();
var DynamicallyLoaded = (function () {
    function DynamicallyLoaded() {
    }
    DynamicallyLoaded = __decorate([
        metadata_1.Component({ selector: 'dummy', template: "DynamicallyLoaded;" }), 
        __metadata('design:paramtypes', [])
    ], DynamicallyLoaded);
    return DynamicallyLoaded;
})();
var DynamicallyLoadedThrows = (function () {
    function DynamicallyLoadedThrows() {
        throw new exceptions_1.BaseException("ThrownInConstructor");
    }
    DynamicallyLoadedThrows = __decorate([
        metadata_1.Component({ selector: 'dummy', template: "DynamicallyLoaded;" }), 
        __metadata('design:paramtypes', [])
    ], DynamicallyLoadedThrows);
    return DynamicallyLoadedThrows;
})();
var DynamicallyLoaded2 = (function () {
    function DynamicallyLoaded2() {
    }
    DynamicallyLoaded2 = __decorate([
        metadata_1.Component({ selector: 'dummy', template: "DynamicallyLoaded2;" }), 
        __metadata('design:paramtypes', [])
    ], DynamicallyLoaded2);
    return DynamicallyLoaded2;
})();
var DynamicallyLoadedWithHostProps = (function () {
    function DynamicallyLoadedWithHostProps() {
        this.id = "default";
    }
    DynamicallyLoadedWithHostProps = __decorate([
        metadata_1.Component({ selector: 'dummy', host: { '[id]': 'id' }, template: "DynamicallyLoadedWithHostProps;" }), 
        __metadata('design:paramtypes', [])
    ], DynamicallyLoadedWithHostProps);
    return DynamicallyLoadedWithHostProps;
})();
var DynamicallyLoadedWithNgContent = (function () {
    function DynamicallyLoadedWithNgContent() {
        this.id = "default";
    }
    DynamicallyLoadedWithNgContent = __decorate([
        metadata_1.Component({ selector: 'dummy', template: "dynamic(<ng-content></ng-content>)" }), 
        __metadata('design:paramtypes', [])
    ], DynamicallyLoadedWithNgContent);
    return DynamicallyLoadedWithNgContent;
})();
var Location = (function () {
    function Location(elementRef) {
        this.elementRef = elementRef;
    }
    Location = __decorate([
        metadata_1.Component({ selector: 'location', template: "Location;" }), 
        __metadata('design:paramtypes', [element_ref_1.ElementRef])
    ], Location);
    return Location;
})();
var MyComp = (function () {
    function MyComp() {
        this.ctxBoolProp = false;
    }
    MyComp = __decorate([
        metadata_1.Component({ selector: 'my-comp', directives: [] }), 
        __metadata('design:paramtypes', [])
    ], MyComp);
    return MyComp;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHluYW1pY19jb21wb25lbnRfbG9hZGVyX3NwZWMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L2NvcmUvbGlua2VyL2R5bmFtaWNfY29tcG9uZW50X2xvYWRlcl9zcGVjLnRzIl0sIm5hbWVzIjpbIm1haW4iLCJjcmVhdGVSb290RWxlbWVudCIsIkNoaWxkQ29tcCIsIkNoaWxkQ29tcC5jb25zdHJ1Y3RvciIsIkR5bmFtaWNhbGx5Q3JlYXRlZENvbXBvbmVudFNlcnZpY2UiLCJEeW5hbWljYWxseUNyZWF0ZWRDb21wb25lbnRTZXJ2aWNlLmNvbnN0cnVjdG9yIiwiRHluYW1pY2FsbHlDcmVhdGVkQ21wIiwiRHluYW1pY2FsbHlDcmVhdGVkQ21wLmNvbnN0cnVjdG9yIiwiRHluYW1pY2FsbHlDcmVhdGVkQ21wLm5nT25EZXN0cm95IiwiRHluYW1pY2FsbHlMb2FkZWQiLCJEeW5hbWljYWxseUxvYWRlZC5jb25zdHJ1Y3RvciIsIkR5bmFtaWNhbGx5TG9hZGVkVGhyb3dzIiwiRHluYW1pY2FsbHlMb2FkZWRUaHJvd3MuY29uc3RydWN0b3IiLCJEeW5hbWljYWxseUxvYWRlZDIiLCJEeW5hbWljYWxseUxvYWRlZDIuY29uc3RydWN0b3IiLCJEeW5hbWljYWxseUxvYWRlZFdpdGhIb3N0UHJvcHMiLCJEeW5hbWljYWxseUxvYWRlZFdpdGhIb3N0UHJvcHMuY29uc3RydWN0b3IiLCJEeW5hbWljYWxseUxvYWRlZFdpdGhOZ0NvbnRlbnQiLCJEeW5hbWljYWxseUxvYWRlZFdpdGhOZ0NvbnRlbnQuY29uc3RydWN0b3IiLCJMb2NhdGlvbiIsIkxvY2F0aW9uLmNvbnN0cnVjdG9yIiwiTXlDb21wIiwiTXlDb21wLmNvbnN0cnVjdG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxpQ0FnQk8sMkJBQTJCLENBQUMsQ0FBQTtBQUduQyxxQkFBdUIsZUFBZSxDQUFDLENBQUE7QUFDdkMsdUJBQW1CLGlCQUFpQixDQUFDLENBQUE7QUFDckMseUJBQXNDLDRCQUE0QixDQUFDLENBQUE7QUFDbkUseUNBQXFDLG1EQUFtRCxDQUFDLENBQUE7QUFDekYsNEJBQXNDLHNDQUFzQyxDQUFDLENBQUE7QUFDN0UsMkJBQXVCLHNDQUFzQyxDQUFDLENBQUE7QUFDOUQsNEJBQWtCLHVDQUF1QyxDQUFDLENBQUE7QUFDMUQsdUNBQWdDLDZDQUE2QyxDQUFDLENBQUE7QUFDOUUsMkJBQTRCLGdDQUFnQyxDQUFDLENBQUE7QUFDN0Qsd0JBQTZCLDZCQUE2QixDQUFDLENBQUE7QUFDM0QscUJBQXdCLDBCQUEwQixDQUFDLENBQUE7QUFFbkQ7SUFDRUEsMkJBQVFBLENBQUNBLHdCQUF3QkEsRUFBRUE7UUFDakMsMkJBQVEsQ0FBQyx5QkFBeUIsRUFBRTtZQUNsQyxxQkFBRSxDQUFDLGFBQWEsRUFDYix5QkFBTSxDQUFDLENBQUMsaURBQXNCLEVBQUUsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFDbEUsVUFBQyxNQUE4QixFQUFFLEdBQXlCLEVBQUUsS0FBSztnQkFDL0QsR0FBRyxDQUFDLFlBQVksQ0FDVCxNQUFNLEVBQ04sSUFBSSx1QkFBWSxDQUNaLEVBQUMsUUFBUSxFQUFFLDRCQUE0QixFQUFFLFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFDLENBQUMsQ0FBQztxQkFDeEUsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFVBQUMsRUFBRTtvQkFDUCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUM7eUJBQzNELElBQUksQ0FBQyxVQUFBLEdBQUc7d0JBQ1AseUJBQU0sQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQzs2QkFDaEMsVUFBVSxDQUFDLDZCQUE2QixDQUFDLENBQUM7d0JBQy9DLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDZixDQUFDLENBQUMsQ0FBQztnQkFDVCxDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFZCxxQkFBRSxDQUFDLDBDQUEwQyxFQUMxQyx5QkFBTSxDQUFDLENBQUMsaURBQXNCLEVBQUUsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFDbEUsVUFBQyxNQUE4QixFQUFFLEdBQXlCLEVBQUUsS0FBSztnQkFDL0QsR0FBRyxDQUFDLFlBQVksQ0FDVCxNQUFNLEVBQ04sSUFBSSx1QkFBWSxDQUNaLEVBQUMsUUFBUSxFQUFFLDRCQUE0QixFQUFFLFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFDLENBQUMsQ0FBQztxQkFDeEUsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFVBQUMsRUFBRTtvQkFFUCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUM7eUJBQzNELElBQUksQ0FBQyxVQUFBLEdBQUc7d0JBQ1AsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDO3dCQUNkLHlCQUFNLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7d0JBQzlELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDZixDQUFDLENBQUMsQ0FBQztnQkFDVCxDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFZCxxQkFBRSxDQUFDLCtEQUErRCxFQUMvRCx5QkFBTSxDQUNGLENBQUMsaURBQXNCLEVBQUUsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFDbEUsVUFBQyxNQUE4QixFQUFFLEdBQXlCLEVBQUUsS0FBSztnQkFDL0QsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixRQUFRLEVBQUUsNkNBQTZDO29CQUN2RCxVQUFVLEVBQUUsQ0FBQyxhQUFJLEVBQUUsU0FBUyxDQUFDO2lCQUM5QixDQUFDLENBQUM7cUJBQ2YsWUFBWSxDQUNULFNBQVMsRUFDVCxJQUFJLHVCQUFZLENBQ1osRUFBQyxRQUFRLEVBQUUsNEJBQTRCLEVBQUUsVUFBVSxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUMsQ0FBQyxDQUFDO3FCQUN6RSxXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxFQUFFO29CQUNQLEVBQUUsQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztvQkFDckQsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUNuQixJQUFJLFdBQVcsR0FBaUIsRUFBRSxDQUFDLFVBQVcsQ0FBQyxlQUFlLENBQUM7b0JBQy9ELHdFQUF3RTtvQkFDeEUsMEJBQTBCO29CQUMxQixJQUFJLGVBQWUsR0FDZixXQUFXLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztvQkFDL0UsTUFBTSxDQUFDLGdCQUFnQixDQUFDLGlCQUFpQixFQUFFLGVBQWUsRUFBRSxLQUFLLENBQUM7eUJBQzdELElBQUksQ0FBQyxVQUFBLEdBQUc7d0JBQ1AseUJBQU0sQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQzs2QkFDaEMsVUFBVSxDQUFDLDZCQUE2QixDQUFDLENBQUM7d0JBRS9DLEVBQUUsQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQzt3QkFDdEQsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFDO3dCQUNuQix5QkFBTSxDQUFDLEVBQUUsQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDO3dCQUVyRCxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7d0JBQ2QseUJBQU0sQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQzt3QkFDckQsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNmLENBQUMsQ0FBQyxDQUFDO2dCQUNULENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVYLHFCQUFFLENBQUMsK0JBQStCLEVBQy9CLHlCQUFNLENBQ0YsQ0FBQyxpREFBc0IsRUFBRSx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUNsRSxVQUFDLE1BQThCLEVBQUUsR0FBeUIsRUFBRSxLQUFLO2dCQUMvRCxHQUFHLENBQUMsWUFBWSxDQUNULE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQ1osRUFBQyxRQUFRLEVBQUUsNEJBQTRCLEVBQUUsVUFBVSxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUMsQ0FBQyxDQUFDO3FCQUNoRixXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxFQUFFO29CQUNQLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyw4QkFBOEIsRUFBRSxFQUFFLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQzt5QkFDeEUsSUFBSSxDQUFDLFVBQUEsR0FBRzt3QkFDUCxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsR0FBRyxXQUFXLENBQUM7d0JBRTlCLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQzt3QkFFbkIsSUFBSSxvQkFBb0IsR0FDcEIsaUJBQUcsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDckQseUJBQU0sQ0FBZSxvQkFBcUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7d0JBQ3BFLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDZixDQUFDLENBQUMsQ0FBQztnQkFDVCxDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFWCxxQkFBRSxDQUFDLHFFQUFxRSxFQUNyRSx5QkFBTSxDQUFDLENBQUMsaURBQXNCLEVBQUUsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFDbEUsVUFBQyxNQUE4QixFQUFFLEdBQXlCLEVBQUUsS0FBSztnQkFDL0QsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixRQUFRLEVBQUUsdUNBQXVDO29CQUNqRCxVQUFVLEVBQUUsQ0FBQyxRQUFRLENBQUM7aUJBQ3ZCLENBQUMsQ0FBQztxQkFDZixXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxFQUFvQjtvQkFDekIsRUFBRSxDQUFDLFlBQVksQ0FBQTtvQkFFWCx3QkFBYyxDQUFDLFVBQVUsQ0FDckIsTUFBTSxDQUFDLGdCQUFnQixDQUFDLHVCQUF1QixFQUFFLEVBQUUsQ0FBQyxVQUFVLEVBQ3RDLEtBQUssQ0FBQyxFQUM5QixVQUFBLEtBQUs7d0JBQ0gseUJBQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLHFCQUFxQixDQUFDLENBQUM7d0JBQ3ZELHlCQUFNLENBQUMsY0FBTSxPQUFBLEVBQUUsQ0FBQyxhQUFhLEVBQUUsRUFBbEIsQ0FBa0IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQzt3QkFDL0MsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUNiLE1BQU0sQ0FBQyxJQUFJLENBQUM7b0JBQ2QsQ0FBQyxDQUFDLENBQUM7Z0JBQ2IsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRWQscUJBQUUsQ0FBQyw2Q0FBNkMsRUFDN0MseUJBQU0sQ0FBQyxDQUFDLGlEQUFzQixFQUFFLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQ2xFLFVBQUMsTUFBOEIsRUFBRSxHQUF5QixFQUFFLEtBQUs7Z0JBQy9ELEdBQUcsQ0FBQyxZQUFZLENBQ1QsTUFBTSxFQUNOLElBQUksdUJBQVksQ0FDWixFQUFDLFFBQVEsRUFBRSw0QkFBNEIsRUFBRSxVQUFVLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBQyxDQUFDLENBQUM7cUJBQ3hFLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLEVBQUU7b0JBQ1AseUJBQU0sQ0FBQyxjQUFNLE9BQUEsTUFBTSxDQUFDLGdCQUFnQixDQUFDLDhCQUE4QixFQUM5QixFQUFFLENBQUMsVUFBVSxFQUFFLHFCQUFxQixDQUFDLEVBRDdELENBQzZELENBQUM7eUJBQ3RFLFlBQVksQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFDO29CQUNqRSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2YsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRWQscUJBQUUsQ0FBQyx3Q0FBd0MsRUFDeEMseUJBQU0sQ0FBQyxDQUFDLGlEQUFzQixFQUFFLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQ2xFLFVBQUMsTUFBOEIsRUFBRSxHQUF5QixFQUFFLEtBQUs7Z0JBQy9ELEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUNOLElBQUksdUJBQVksQ0FBQyxFQUFDLFFBQVEsRUFBRSxrQkFBa0IsRUFBRSxVQUFVLEVBQUUsRUFBRSxFQUFDLENBQUMsQ0FBQztxQkFDN0UsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFVBQUMsRUFBRTtvQkFDUCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsOEJBQThCLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFDN0MsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsaUJBQUcsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUNoRSxJQUFJLENBQUMsVUFBQSxHQUFHO3dCQUNQLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQzt3QkFDbkIseUJBQU0sQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7d0JBQ3RELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDZixDQUFDLENBQUMsQ0FBQztnQkFDVCxDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFZCxxQkFBRSxDQUFDLDREQUE0RCxFQUM1RCx5QkFBTSxDQUNGLENBQUMsaURBQXNCLEVBQUUsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFDbEUsVUFBQyxNQUE4QixFQUFFLEdBQXlCLEVBQUUsS0FBSztnQkFDL0QsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQ04sSUFBSSx1QkFBWSxDQUFDLEVBQUMsUUFBUSxFQUFFLGtCQUFrQixFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUMsQ0FBQyxDQUFDO3FCQUM3RSxXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxFQUFFO29CQUNQLHdCQUFjLENBQUMsVUFBVSxDQUNyQixNQUFNLENBQUMsZ0JBQWdCLENBQUMsOEJBQThCLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFDN0MsS0FBSyxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsRUFDeEMsVUFBQyxDQUFDO3dCQUNBLHlCQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FDdkIsbUJBQWlCLGdCQUFTLENBQUMsOEJBQThCLENBQUMsaUVBQThELENBQUMsQ0FBQzt3QkFDOUgsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUNiLE1BQU0sQ0FBQyxJQUFJLENBQUM7b0JBQ2QsQ0FBQyxDQUFDLENBQUM7Z0JBQ1QsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWIsQ0FBQyxDQUFDLENBQUM7UUFFSCwyQkFBUSxDQUFDLDRCQUE0QixFQUFFO1lBQ3JDLHFCQUFFLENBQUMsYUFBYSxFQUNiLHlCQUFNLENBQUMsQ0FBQyxpREFBc0IsRUFBRSx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUNsRSxVQUFDLE1BQThCLEVBQUUsR0FBeUIsRUFBRSxLQUFLO2dCQUMvRCxHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7b0JBQ3ZCLFFBQVEsRUFBRSx1Q0FBdUM7b0JBQ2pELFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQztpQkFDdkIsQ0FBQyxDQUFDO3FCQUNmLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLEVBQUU7b0JBQ1AsTUFBTSxDQUFDLGtCQUFrQixDQUFDLGlCQUFpQixFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUM7eUJBQ3RELElBQUksQ0FBQyxVQUFBLEdBQUc7d0JBQ1AseUJBQU0sQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQzt3QkFDOUQseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDOzZCQUNqRCxVQUFVLENBQUMsb0JBQW9CLENBQUMsQ0FBQzt3QkFFdEMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNmLENBQUMsQ0FBQyxDQUFDO2dCQUNULENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVkLHFCQUFFLENBQUMsMENBQTBDLEVBQzFDLHlCQUFNLENBQUMsQ0FBQyxpREFBc0IsRUFBRSx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUNsRSxVQUFDLE1BQThCLEVBQUUsR0FBeUIsRUFBRSxLQUFLO2dCQUMvRCxHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7b0JBQ3ZCLFFBQVEsRUFBRSx1Q0FBdUM7b0JBQ2pELFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQztpQkFDdkIsQ0FBQyxDQUFDOzt3QkFHaEIsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbEIsSUFBSSxDQUFDLFVBQUMsRUFBRTtvQkFDUCxNQUFNLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQzt5QkFDdEQsSUFBSSxDQUFDLFVBQUEsR0FBRzt3QkFDUCxNQUFNLENBQUMsa0JBQWtCLENBQUMsa0JBQWtCLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQzs2QkFDdkQsSUFBSSxDQUFDLFVBQUEsSUFBSTs0QkFDUixJQUFJLFlBQVksR0FDWixpQkFBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDOzRCQUNuRCxJQUFJLGFBQWEsR0FBRyxpQkFBRyxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsQ0FBQzs0QkFDbEQseUJBQU0sQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDOUQseUJBQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxVQUFVLENBQUMsb0JBQW9CLENBQUMsQ0FBQzs0QkFDdEQseUJBQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMscUJBQXFCLENBQUMsQ0FBQzs0QkFFeEQsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDOzRCQUVmLFlBQVksR0FBRyxpQkFBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDOzRCQUM5RCxhQUFhLEdBQUcsaUJBQUcsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUM7NEJBQzlDLHlCQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7NEJBRWpDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDZixDQUFDLENBQUMsQ0FBQztvQkFDVCxDQUFDLENBQUMsQ0FBQztnQkFDVCxDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFZCxxQkFBRSxDQUFDLCtCQUErQixFQUMvQix5QkFBTSxDQUFDLENBQUMsaURBQXNCLEVBQUUsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFDbEUsVUFBQyxNQUE4QixFQUFFLEdBQXlCLEVBQUUsS0FBSztnQkFDL0QsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixRQUFRLEVBQUUsdUNBQXVDO29CQUNqRCxVQUFVLEVBQUUsQ0FBQyxRQUFRLENBQUM7aUJBQ3ZCLENBQUMsQ0FBQztxQkFFZixXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxFQUFFO29CQUVQLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyw4QkFBOEIsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDO3lCQUNuRSxJQUFJLENBQUMsVUFBQSxHQUFHO3dCQUNQLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxHQUFHLFdBQVcsQ0FBQzt3QkFFOUIsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFDO3dCQUVuQixJQUFJLG9CQUFvQixHQUNwQixpQkFBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO3dCQUNuRCx5QkFBTSxDQUFlLG9CQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQzt3QkFFcEUsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNmLENBQUMsQ0FBQyxDQUFDO2dCQUNULENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVkLHFCQUFFLENBQUMsd0NBQXdDLEVBQ3hDLHlCQUFNLENBQUMsQ0FBQyxpREFBc0IsRUFBRSx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUNsRSxVQUFDLE1BQThCLEVBQUUsR0FBeUIsRUFBRSxLQUFLO2dCQUMvRCxHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUMsRUFBQyxRQUFRLEVBQUUsRUFBRSxFQUFFLFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFDLENBQUMsQ0FBQztxQkFDN0UsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFVBQUMsRUFBRTtvQkFDUCxNQUFNLENBQUMsa0JBQWtCLENBQUMsOEJBQThCLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFDN0MsSUFBSSxFQUFFLENBQUMsQ0FBQyxpQkFBRyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQzNELElBQUksQ0FBQyxVQUFBLEdBQUc7d0JBQ1AsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFDO3dCQUNuQixJQUFJLG9CQUFvQixHQUNwQixpQkFBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO3dCQUNuRCx5QkFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7d0JBQzFELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDZixDQUFDLENBQUMsQ0FBQztnQkFDVCxDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFaEIsQ0FBQyxDQUFDLENBQUM7UUFFSCwyQkFBUSxDQUFDLFlBQVksRUFBRTtZQUNyQixxQkFBRSxDQUFDLHVEQUF1RCxFQUN2RCx5QkFBTSxDQUFDLENBQUMscUNBQWtCLEVBQUUsaURBQXNCLEVBQUUscUJBQVEsRUFBRSxlQUFRLENBQUMsRUFDaEUsVUFBQyxLQUF5QixFQUFFLE1BQThCLEVBQUUsR0FBRyxFQUM5RCxRQUFrQjtnQkFDakIsSUFBSSxNQUFNLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDO2dCQUNqRCxpQkFBRyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUNsQyxNQUFNLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO3FCQUN2QyxJQUFJLENBQUMsVUFBQyxZQUFZO29CQUNqQixJQUFJLEVBQUUsR0FBRyxJQUFJLDBDQUFpQixDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUU3Qyx5QkFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUV6QyxFQUFFLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBRW5CLHlCQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUVuQyxZQUFZLENBQUMsUUFBUSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7b0JBRXRDLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFFbkIseUJBQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBRWpDLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFFdkIseUJBQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7b0JBRXRDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFZCxxQkFBRSxDQUFDLHdDQUF3QyxFQUN4Qyx5QkFBTSxDQUFDLENBQUMscUNBQWtCLEVBQUUsaURBQXNCLEVBQUUscUJBQVEsRUFBRSxlQUFRLENBQUMsRUFDaEUsVUFBQyxLQUF5QixFQUFFLE1BQThCLEVBQUUsR0FBRyxFQUM5RCxRQUFrQjtnQkFDakIsSUFBSSxNQUFNLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUM3QyxpQkFBRyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUNsQyxNQUFNLENBQUMsVUFBVSxDQUFDLDhCQUE4QixFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUNwRCxDQUFDLENBQUMsaUJBQUcsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUM3QyxJQUFJLENBQUMsVUFBQyxDQUFDO29CQUNOLHlCQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7b0JBRTVDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFaEIsQ0FBQyxDQUFDLENBQUM7SUFFTCxDQUFDLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBeFVlLFlBQUksT0F3VW5CLENBQUE7QUFFRCwyQkFBMkIsR0FBUSxFQUFFLElBQVk7SUFDL0NDLElBQUlBLEtBQUtBLEdBQUdBLGlCQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLEdBQUdBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO0lBQzVDQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFFQSxDQUFDQSxHQUFHQSxLQUFLQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQSxFQUFFQSxFQUFFQSxDQUFDQTtRQUN0Q0EsaUJBQUdBLENBQUNBLE1BQU1BLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO0lBQ3ZCQSxDQUFDQTtJQUNEQSxJQUFJQSxNQUFNQSxHQUFHQSxxQkFBRUEsQ0FBQ0EsTUFBSUEsSUFBSUEsV0FBTUEsSUFBSUEsTUFBR0EsQ0FBQ0EsQ0FBQ0E7SUFDdkNBLGlCQUFHQSxDQUFDQSxXQUFXQSxDQUFDQSxHQUFHQSxDQUFDQSxJQUFJQSxFQUFFQSxNQUFNQSxDQUFDQSxDQUFDQTtJQUNsQ0EsTUFBTUEsQ0FBQ0EsTUFBTUEsQ0FBQ0E7QUFDaEJBLENBQUNBO0FBRUQ7SUFHRUM7UUFBZ0JDLElBQUlBLENBQUNBLE9BQU9BLEdBQUdBLE9BQU9BLENBQUNBO0lBQUNBLENBQUNBO0lBSDNDRDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsV0FBV0EsRUFBRUEsUUFBUUEsRUFBRUEsYUFBYUEsRUFBQ0EsQ0FBQ0E7O2tCQUkzREE7SUFBREEsZ0JBQUNBO0FBQURBLENBQUNBLEFBSkQsSUFJQztBQUdEO0lBQUFFO0lBQTBDQyxDQUFDQTtJQUFERCx5Q0FBQ0E7QUFBREEsQ0FBQ0EsQUFBM0MsSUFBMkM7QUFFM0M7SUFVRUUsK0JBQVlBLENBQXFDQTtRQUZqREMsY0FBU0EsR0FBWUEsS0FBS0EsQ0FBQ0E7UUFHekJBLElBQUlBLENBQUNBLFFBQVFBLEdBQUdBLE9BQU9BLENBQUNBO1FBQ3hCQSxJQUFJQSxDQUFDQSxrQ0FBa0NBLEdBQUdBLENBQUNBLENBQUNBO0lBQzlDQSxDQUFDQTtJQUVERCwyQ0FBV0EsR0FBWEEsY0FBZ0JFLElBQUlBLENBQUNBLFNBQVNBLEdBQUdBLElBQUlBLENBQUNBLENBQUNBLENBQUNBO0lBZjFDRjtRQUFDQSxvQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsV0FBV0E7WUFDckJBLGFBQWFBLEVBQUVBLENBQUNBLGtDQUFrQ0EsQ0FBQ0E7WUFDbkRBLFFBQVFBLEVBQUVBLGNBQWNBO1NBQ3pCQSxDQUFDQTs7OEJBWURBO0lBQURBLDRCQUFDQTtBQUFEQSxDQUFDQSxBQWhCRCxJQWdCQztBQUVEO0lBQUFHO0lBRUFDLENBQUNBO0lBRkREO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxPQUFPQSxFQUFFQSxRQUFRQSxFQUFFQSxvQkFBb0JBLEVBQUNBLENBQUNBOzswQkFFOURBO0lBQURBLHdCQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUM7QUFFRDtJQUVFRTtRQUFnQkMsTUFBTUEsSUFBSUEsMEJBQWFBLENBQUNBLHFCQUFxQkEsQ0FBQ0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFGbkVEO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxPQUFPQSxFQUFFQSxRQUFRQSxFQUFFQSxvQkFBb0JBLEVBQUNBLENBQUNBOztnQ0FHOURBO0lBQURBLDhCQUFDQTtBQUFEQSxDQUFDQSxBQUhELElBR0M7QUFFRDtJQUFBRTtJQUVBQyxDQUFDQTtJQUZERDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsT0FBT0EsRUFBRUEsUUFBUUEsRUFBRUEscUJBQXFCQSxFQUFDQSxDQUFDQTs7MkJBRS9EQTtJQUFEQSx5QkFBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDO0FBRUQ7SUFJRUU7UUFBZ0JDLElBQUlBLENBQUNBLEVBQUVBLEdBQUdBLFNBQVNBLENBQUNBO0lBQUNBLENBQUNBO0lBSnhDRDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsT0FBT0EsRUFBRUEsSUFBSUEsRUFBRUEsRUFBQ0EsTUFBTUEsRUFBRUEsSUFBSUEsRUFBQ0EsRUFBRUEsUUFBUUEsRUFBRUEsaUNBQWlDQSxFQUFDQSxDQUFDQTs7dUNBS2pHQTtJQUFEQSxxQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFMRCxJQUtDO0FBRUQ7SUFJRUU7UUFBZ0JDLElBQUlBLENBQUNBLEVBQUVBLEdBQUdBLFNBQVNBLENBQUNBO0lBQUNBLENBQUNBO0lBSnhDRDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsT0FBT0EsRUFBRUEsUUFBUUEsRUFBRUEsb0NBQW9DQSxFQUFDQSxDQUFDQTs7dUNBSzlFQTtJQUFEQSxxQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFMRCxJQUtDO0FBRUQ7SUFJRUUsa0JBQVlBLFVBQXNCQTtRQUFJQyxJQUFJQSxDQUFDQSxVQUFVQSxHQUFHQSxVQUFVQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUp2RUQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLFVBQVVBLEVBQUVBLFFBQVFBLEVBQUVBLFdBQVdBLEVBQUNBLENBQUNBOztpQkFLeERBO0lBQURBLGVBQUNBO0FBQURBLENBQUNBLEFBTEQsSUFLQztBQUVEO0lBSUVFO1FBQWdCQyxJQUFJQSxDQUFDQSxXQUFXQSxHQUFHQSxLQUFLQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUo3Q0Q7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLFNBQVNBLEVBQUVBLFVBQVVBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOztlQUtoREE7SUFBREEsYUFBQ0E7QUFBREEsQ0FBQ0EsQUFMRCxJQUtDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXN5bmNUZXN0Q29tcGxldGVyLFxuICBiZWZvcmVFYWNoLFxuICBkZGVzY3JpYmUsXG4gIHhkZXNjcmliZSxcbiAgZGVzY3JpYmUsXG4gIGVsLFxuICBkaXNwYXRjaEV2ZW50LFxuICBleHBlY3QsXG4gIGlpdCxcbiAgaW5qZWN0LFxuICBiZWZvcmVFYWNoUHJvdmlkZXJzLFxuICBpdCxcbiAgeGl0LFxuICBUZXN0Q29tcG9uZW50QnVpbGRlcixcbiAgQ29tcG9uZW50Rml4dHVyZVxufSBmcm9tICdhbmd1bGFyMi90ZXN0aW5nX2ludGVybmFsJztcblxuaW1wb3J0IHtPbkRlc3Ryb3l9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuaW1wb3J0IHtJbmplY3Rvcn0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5pbXBvcnQge05nSWZ9IGZyb20gJ2FuZ3VsYXIyL2NvbW1vbic7XG5pbXBvcnQge0NvbXBvbmVudCwgVmlld01ldGFkYXRhfSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9tZXRhZGF0YSc7XG5pbXBvcnQge0R5bmFtaWNDb21wb25lbnRMb2FkZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci9keW5hbWljX2NvbXBvbmVudF9sb2FkZXInO1xuaW1wb3J0IHtFbGVtZW50UmVmLCBFbGVtZW50UmVmX30gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvbGlua2VyL2VsZW1lbnRfcmVmJztcbmltcG9ydCB7RE9DVU1FTlR9IGZyb20gJ2FuZ3VsYXIyL3NyYy9wbGF0Zm9ybS9kb20vZG9tX3Rva2Vucyc7XG5pbXBvcnQge0RPTX0gZnJvbSAnYW5ndWxhcjIvc3JjL3BsYXRmb3JtL2RvbS9kb21fYWRhcHRlcic7XG5pbXBvcnQge0NvbXBvbmVudEZpeHR1cmVffSBmcm9tIFwiYW5ndWxhcjIvc3JjL3Rlc3RpbmcvdGVzdF9jb21wb25lbnRfYnVpbGRlclwiO1xuaW1wb3J0IHtCYXNlRXhjZXB0aW9ufSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2V4Y2VwdGlvbnMnO1xuaW1wb3J0IHtQcm9taXNlV3JhcHBlcn0gZnJvbSAnYW5ndWxhcjIvc3JjL2ZhY2FkZS9wcm9taXNlJztcbmltcG9ydCB7c3RyaW5naWZ5fSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2xhbmcnO1xuXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpIHtcbiAgZGVzY3JpYmUoJ0R5bmFtaWNDb21wb25lbnRMb2FkZXInLCBmdW5jdGlvbigpIHtcbiAgICBkZXNjcmliZShcImxvYWRpbmcgaW50byBhIGxvY2F0aW9uXCIsICgpID0+IHtcbiAgICAgIGl0KCdzaG91bGQgd29yaycsXG4gICAgICAgICBpbmplY3QoW0R5bmFtaWNDb21wb25lbnRMb2FkZXIsIFRlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLFxuICAgICAgICAgICAgICAgIChsb2FkZXI6IER5bmFtaWNDb21wb25lbnRMb2FkZXIsIHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgICAgICAgICAgIE15Q29tcCxcbiAgICAgICAgICAgICAgICAgICAgICAgICBuZXcgVmlld01ldGFkYXRhKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGVtcGxhdGU6ICc8bG9jYXRpb24gI2xvYz48L2xvY2F0aW9uPicsIGRpcmVjdGl2ZXM6IFtMb2NhdGlvbl19KSlcbiAgICAgICAgICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgICAgICAgIC50aGVuKCh0YykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGVyLmxvYWRJbnRvTG9jYXRpb24oRHluYW1pY2FsbHlMb2FkZWQsIHRjLmVsZW1lbnRSZWYsICdsb2MnKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKHJlZiA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBlY3QodGMuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvSGF2ZVRleHQoXCJMb2NhdGlvbjtEeW5hbWljYWxseUxvYWRlZDtcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIHJldHVybiBhIGRpc3Bvc2FibGUgY29tcG9uZW50IHJlZicsXG4gICAgICAgICBpbmplY3QoW0R5bmFtaWNDb21wb25lbnRMb2FkZXIsIFRlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLFxuICAgICAgICAgICAgICAgIChsb2FkZXI6IER5bmFtaWNDb21wb25lbnRMb2FkZXIsIHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgICAgICAgICAgIE15Q29tcCxcbiAgICAgICAgICAgICAgICAgICAgICAgICBuZXcgVmlld01ldGFkYXRhKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGVtcGxhdGU6ICc8bG9jYXRpb24gI2xvYz48L2xvY2F0aW9uPicsIGRpcmVjdGl2ZXM6IFtMb2NhdGlvbl19KSlcbiAgICAgICAgICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgICAgICAgIC50aGVuKCh0YykgPT4ge1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkZXIubG9hZEludG9Mb2NhdGlvbihEeW5hbWljYWxseUxvYWRlZCwgdGMuZWxlbWVudFJlZiwgJ2xvYycpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4ocmVmID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlZi5kaXNwb3NlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBlY3QodGMuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoXCJMb2NhdGlvbjtcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIGFsbG93IHRvIGRpc3Bvc2UgZXZlbiBpZiB0aGUgbG9jYXRpb24gaGFzIGJlZW4gcmVtb3ZlZCcsXG4gICAgICAgICBpbmplY3QoXG4gICAgICAgICAgICAgW0R5bmFtaWNDb21wb25lbnRMb2FkZXIsIFRlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLFxuICAgICAgICAgICAgIChsb2FkZXI6IER5bmFtaWNDb21wb25lbnRMb2FkZXIsIHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8Y2hpbGQtY21wICpuZ0lmPVwiY3R4Qm9vbFByb3BcIj48L2NoaWxkLWNtcD4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtOZ0lmLCBDaGlsZENvbXBdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgICAgICAgIC5vdmVycmlkZVZpZXcoXG4gICAgICAgICAgICAgICAgICAgICAgIENoaWxkQ29tcCxcbiAgICAgICAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0ZW1wbGF0ZTogJzxsb2NhdGlvbiAjbG9jPjwvbG9jYXRpb24+JywgZGlyZWN0aXZlczogW0xvY2F0aW9uXX0pKVxuICAgICAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAgICAgLnRoZW4oKHRjKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICB0Yy5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UuY3R4Qm9vbFByb3AgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgdGMuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICAgICAgdmFyIGNoaWxkQ29tcEVsID0gKDxFbGVtZW50UmVmXz50Yy5lbGVtZW50UmVmKS5pbnRlcm5hbEVsZW1lbnQ7XG4gICAgICAgICAgICAgICAgICAgICAvLyBUT0RPKGp1bGllbXIpOiBUaGlzIGlzIGhpZGVvdXMsIHNlZSBpZiB0aGVyZSdzIGEgYmV0dGVyIHdheSB0byBoYW5kbGVcbiAgICAgICAgICAgICAgICAgICAgIC8vIGNoaWxkIGVsZW1lbnQgcmVmcyBub3cuXG4gICAgICAgICAgICAgICAgICAgICB2YXIgY2hpbGRFbGVtZW50UmVmID1cbiAgICAgICAgICAgICAgICAgICAgICAgICBjaGlsZENvbXBFbC5jb21wb25lbnRWaWV3LmFwcEVsZW1lbnRzWzBdLm5lc3RlZFZpZXdzWzBdLmFwcEVsZW1lbnRzWzBdLnJlZjtcbiAgICAgICAgICAgICAgICAgICAgIGxvYWRlci5sb2FkSW50b0xvY2F0aW9uKER5bmFtaWNhbGx5TG9hZGVkLCBjaGlsZEVsZW1lbnRSZWYsICdsb2MnKVxuICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKHJlZiA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICBleHBlY3QodGMuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvSGF2ZVRleHQoXCJMb2NhdGlvbjtEeW5hbWljYWxseUxvYWRlZDtcIik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHRjLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jdHhCb29sUHJvcCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgdGMuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KHRjLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KFwiXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICByZWYuZGlzcG9zZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KHRjLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KFwiXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCB1cGRhdGUgaG9zdCBwcm9wZXJ0aWVzJyxcbiAgICAgICAgIGluamVjdChcbiAgICAgICAgICAgICBbRHluYW1pY0NvbXBvbmVudExvYWRlciwgVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sXG4gICAgICAgICAgICAgKGxvYWRlcjogRHluYW1pY0NvbXBvbmVudExvYWRlciwgdGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoXG4gICAgICAgICAgICAgICAgICAgICAgTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0ZW1wbGF0ZTogJzxsb2NhdGlvbiAjbG9jPjwvbG9jYXRpb24+JywgZGlyZWN0aXZlczogW0xvY2F0aW9uXX0pKVxuICAgICAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAgICAgLnRoZW4oKHRjKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICBsb2FkZXIubG9hZEludG9Mb2NhdGlvbihEeW5hbWljYWxseUxvYWRlZFdpdGhIb3N0UHJvcHMsIHRjLmVsZW1lbnRSZWYsICdsb2MnKVxuICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKHJlZiA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICByZWYuaW5zdGFuY2UuaWQgPSBcIm5ldyB2YWx1ZVwiO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICB0Yy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBuZXdseUluc2VydGVkRWxlbWVudCA9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRE9NLmNoaWxkTm9kZXModGMuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpWzFdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KCg8SFRNTEVsZW1lbnQ+bmV3bHlJbnNlcnRlZEVsZW1lbnQpLmlkKS50b0VxdWFsKFwibmV3IHZhbHVlXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBsZWF2ZSB0aGUgdmlldyB0cmVlIGluIGEgY29uc2lzdGVudCBzdGF0ZSBpZiBoeWRyYXRpb24gZmFpbHMnLFxuICAgICAgICAgaW5qZWN0KFtEeW5hbWljQ29tcG9uZW50TG9hZGVyLCBUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSxcbiAgICAgICAgICAgICAgICAobG9hZGVyOiBEeW5hbWljQ29tcG9uZW50TG9hZGVyLCB0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPGRpdj48bG9jYXRpb24gI2xvYz48L2xvY2F0aW9uPjwvZGl2PicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW0xvY2F0aW9uXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgICAgICAgIC50aGVuKCh0YzogQ29tcG9uZW50Rml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGMuZGVidWdFbGVtZW50XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQcm9taXNlV3JhcHBlci5jYXRjaEVycm9yKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FkZXIubG9hZEludG9Mb2NhdGlvbihEeW5hbWljYWxseUxvYWRlZFRocm93cywgdGMuZWxlbWVudFJlZixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2xvYycpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcnJvciA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGVycm9yLm1lc3NhZ2UpLnRvQ29udGFpbihcIlRocm93bkluQ29uc3RydWN0b3JcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KCgpID0+IHRjLmRldGVjdENoYW5nZXMoKSkubm90LnRvVGhyb3coKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCB0aHJvdyBpZiB0aGUgdmFyaWFibGUgZG9lcyBub3QgZXhpc3QnLFxuICAgICAgICAgaW5qZWN0KFtEeW5hbWljQ29tcG9uZW50TG9hZGVyLCBUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSxcbiAgICAgICAgICAgICAgICAobG9hZGVyOiBEeW5hbWljQ29tcG9uZW50TG9hZGVyLCB0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhcbiAgICAgICAgICAgICAgICAgICAgICAgICBNeUNvbXAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RlbXBsYXRlOiAnPGxvY2F0aW9uICNsb2M+PC9sb2NhdGlvbj4nLCBkaXJlY3RpdmVzOiBbTG9jYXRpb25dfSkpXG4gICAgICAgICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgICAgICAgICAudGhlbigodGMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdCgoKSA9PiBsb2FkZXIubG9hZEludG9Mb2NhdGlvbihEeW5hbWljYWxseUxvYWRlZFdpdGhIb3N0UHJvcHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGMuZWxlbWVudFJlZiwgJ3NvbWVVbmtub3duVmFyaWFibGUnKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9UaHJvd0Vycm9yKCdDb3VsZCBub3QgZmluZCB2YXJpYWJsZSBzb21lVW5rbm93blZhcmlhYmxlJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIGFsbG93IHRvIHBhc3MgcHJvamVjdGFibGUgbm9kZXMnLFxuICAgICAgICAgaW5qZWN0KFtEeW5hbWljQ29tcG9uZW50TG9hZGVyLCBUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSxcbiAgICAgICAgICAgICAgICAobG9hZGVyOiBEeW5hbWljQ29tcG9uZW50TG9hZGVyLCB0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5ldyBWaWV3TWV0YWRhdGEoe3RlbXBsYXRlOiAnPGRpdiAjbG9jPjwvZGl2PicsIGRpcmVjdGl2ZXM6IFtdfSkpXG4gICAgICAgICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgICAgICAgICAudGhlbigodGMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRlci5sb2FkSW50b0xvY2F0aW9uKER5bmFtaWNhbGx5TG9hZGVkV2l0aE5nQ29udGVudCwgdGMuZWxlbWVudFJlZixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdsb2MnLCBudWxsLCBbW0RPTS5jcmVhdGVUZXh0Tm9kZSgnaGVsbG8nKV1dKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKHJlZiA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0Yy5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBlY3QodGMubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnZHluYW1pYyhoZWxsbyknKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgdGhyb3cgaWYgbm90IGVub3VnaCBwcm9qZWN0YWJsZSBub2RlcyBhcmUgcGFzc2VkIGluJyxcbiAgICAgICAgIGluamVjdChcbiAgICAgICAgICAgICBbRHluYW1pY0NvbXBvbmVudExvYWRlciwgVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sXG4gICAgICAgICAgICAgKGxvYWRlcjogRHluYW1pY0NvbXBvbmVudExvYWRlciwgdGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuZXcgVmlld01ldGFkYXRhKHt0ZW1wbGF0ZTogJzxkaXYgI2xvYz48L2Rpdj4nLCBkaXJlY3RpdmVzOiBbXX0pKVxuICAgICAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAgICAgLnRoZW4oKHRjKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICBQcm9taXNlV3JhcHBlci5jYXRjaEVycm9yKFxuICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRlci5sb2FkSW50b0xvY2F0aW9uKER5bmFtaWNhbGx5TG9hZGVkV2l0aE5nQ29udGVudCwgdGMuZWxlbWVudFJlZixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnbG9jJywgbnVsbCwgW10pLFxuICAgICAgICAgICAgICAgICAgICAgICAgIChlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICBleHBlY3QoZS5tZXNzYWdlKS50b0NvbnRhaW4oXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYFRoZSBjb21wb25lbnQgJHtzdHJpbmdpZnkoRHluYW1pY2FsbHlMb2FkZWRXaXRoTmdDb250ZW50KX0gaGFzIDEgPG5nLWNvbnRlbnQ+IGVsZW1lbnRzLCBidXQgb25seSAwIHNsb3RzIHdlcmUgcHJvdmlkZWRgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgIH0pKTtcblxuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoXCJsb2FkaW5nIG5leHQgdG8gYSBsb2NhdGlvblwiLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIHdvcmsnLFxuICAgICAgICAgaW5qZWN0KFtEeW5hbWljQ29tcG9uZW50TG9hZGVyLCBUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSxcbiAgICAgICAgICAgICAgICAobG9hZGVyOiBEeW5hbWljQ29tcG9uZW50TG9hZGVyLCB0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPGRpdj48bG9jYXRpb24gI2xvYz48L2xvY2F0aW9uPjwvZGl2PicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW0xvY2F0aW9uXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgICAgICAgIC50aGVuKCh0YykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGVyLmxvYWROZXh0VG9Mb2NhdGlvbihEeW5hbWljYWxseUxvYWRlZCwgdGMuZWxlbWVudFJlZilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihyZWYgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KHRjLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KFwiTG9jYXRpb247XCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5uZXh0U2libGluZyh0Yy5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvSGF2ZVRleHQoJ0R5bmFtaWNhbGx5TG9hZGVkOycpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIHJldHVybiBhIGRpc3Bvc2FibGUgY29tcG9uZW50IHJlZicsXG4gICAgICAgICBpbmplY3QoW0R5bmFtaWNDb21wb25lbnRMb2FkZXIsIFRlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLFxuICAgICAgICAgICAgICAgIChsb2FkZXI6IER5bmFtaWNDb21wb25lbnRMb2FkZXIsIHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8ZGl2Pjxsb2NhdGlvbiAjbG9jPjwvbG9jYXRpb24+PC9kaXY+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbTG9jYXRpb25dXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgICAgICAgICAgIC5cblxuICAgICAgICAgICAgICAgICAgICAgIGNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgICAgICAgICAudGhlbigodGMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRlci5sb2FkTmV4dFRvTG9jYXRpb24oRHluYW1pY2FsbHlMb2FkZWQsIHRjLmVsZW1lbnRSZWYpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4ocmVmID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRlci5sb2FkTmV4dFRvTG9jYXRpb24oRHluYW1pY2FsbHlMb2FkZWQyLCB0Yy5lbGVtZW50UmVmKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKHJlZjIgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGZpcnN0U2libGluZyA9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRE9NLm5leHRTaWJsaW5nKHRjLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBzZWNvbmRTaWJsaW5nID0gRE9NLm5leHRTaWJsaW5nKGZpcnN0U2libGluZyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBlY3QodGMuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoXCJMb2NhdGlvbjtcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBlY3QoZmlyc3RTaWJsaW5nKS50b0hhdmVUZXh0KFwiRHluYW1pY2FsbHlMb2FkZWQ7XCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KHNlY29uZFNpYmxpbmcpLnRvSGF2ZVRleHQoXCJEeW5hbWljYWxseUxvYWRlZDI7XCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWYyLmRpc3Bvc2UoKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlyc3RTaWJsaW5nID0gRE9NLm5leHRTaWJsaW5nKHRjLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlY29uZFNpYmxpbmcgPSBET00ubmV4dFNpYmxpbmcoZmlyc3RTaWJsaW5nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChzZWNvbmRTaWJsaW5nKS50b0JlTnVsbCgpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIHVwZGF0ZSBob3N0IHByb3BlcnRpZXMnLFxuICAgICAgICAgaW5qZWN0KFtEeW5hbWljQ29tcG9uZW50TG9hZGVyLCBUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSxcbiAgICAgICAgICAgICAgICAobG9hZGVyOiBEeW5hbWljQ29tcG9uZW50TG9hZGVyLCB0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPGRpdj48bG9jYXRpb24gI2xvYz48L2xvY2F0aW9uPjwvZGl2PicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW0xvY2F0aW9uXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAgICAgICAgLnRoZW4oKHRjKSA9PiB7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRlci5sb2FkTmV4dFRvTG9jYXRpb24oRHluYW1pY2FsbHlMb2FkZWRXaXRoSG9zdFByb3BzLCB0Yy5lbGVtZW50UmVmKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKHJlZiA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWYuaW5zdGFuY2UuaWQgPSBcIm5ldyB2YWx1ZVwiO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0Yy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBuZXdseUluc2VydGVkRWxlbWVudCA9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRE9NLm5leHRTaWJsaW5nKHRjLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdCgoPEhUTUxFbGVtZW50Pm5ld2x5SW5zZXJ0ZWRFbGVtZW50KS5pZCkudG9FcXVhbChcIm5ldyB2YWx1ZVwiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBhbGxvdyB0byBwYXNzIHByb2plY3RhYmxlIG5vZGVzJyxcbiAgICAgICAgIGluamVjdChbRHluYW1pY0NvbXBvbmVudExvYWRlciwgVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sXG4gICAgICAgICAgICAgICAgKGxvYWRlcjogRHluYW1pY0NvbXBvbmVudExvYWRlciwgdGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHt0ZW1wbGF0ZTogJycsIGRpcmVjdGl2ZXM6IFtMb2NhdGlvbl19KSlcbiAgICAgICAgICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgICAgICAgIC50aGVuKCh0YykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGVyLmxvYWROZXh0VG9Mb2NhdGlvbihEeW5hbWljYWxseUxvYWRlZFdpdGhOZ0NvbnRlbnQsIHRjLmVsZW1lbnRSZWYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bGwsIFtbRE9NLmNyZWF0ZVRleHROb2RlKCdoZWxsbycpXV0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4ocmVmID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRjLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBuZXdseUluc2VydGVkRWxlbWVudCA9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRE9NLm5leHRTaWJsaW5nKHRjLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChuZXdseUluc2VydGVkRWxlbWVudCkudG9IYXZlVGV4dCgnZHluYW1pYyhoZWxsbyknKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKCdsb2FkQXNSb290JywgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCBhbGxvdyB0byBjcmVhdGUsIHVwZGF0ZSBhbmQgZGVzdHJveSBjb21wb25lbnRzJyxcbiAgICAgICAgIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyLCBEeW5hbWljQ29tcG9uZW50TG9hZGVyLCBET0NVTUVOVCwgSW5qZWN0b3JdLFxuICAgICAgICAgICAgICAgIChhc3luYzogQXN5bmNUZXN0Q29tcGxldGVyLCBsb2FkZXI6IER5bmFtaWNDb21wb25lbnRMb2FkZXIsIGRvYyxcbiAgICAgICAgICAgICAgICAgaW5qZWN0b3I6IEluamVjdG9yKSA9PiB7XG4gICAgICAgICAgICAgICAgICB2YXIgcm9vdEVsID0gY3JlYXRlUm9vdEVsZW1lbnQoZG9jLCAnY2hpbGQtY21wJyk7XG4gICAgICAgICAgICAgICAgICBET00uYXBwZW5kQ2hpbGQoZG9jLmJvZHksIHJvb3RFbCk7XG4gICAgICAgICAgICAgICAgICBsb2FkZXIubG9hZEFzUm9vdChDaGlsZENvbXAsIG51bGwsIGluamVjdG9yKVxuICAgICAgICAgICAgICAgICAgICAgIC50aGVuKChjb21wb25lbnRSZWYpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBlbCA9IG5ldyBDb21wb25lbnRGaXh0dXJlXyhjb21wb25lbnRSZWYpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBlY3Qocm9vdEVsLnBhcmVudE5vZGUpLnRvQmUoZG9jLmJvZHkpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBlbC5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChyb290RWwpLnRvSGF2ZVRleHQoJ2hlbGxvJyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudFJlZi5pbnN0YW5jZS5jdHhQcm9wID0gJ25ldyc7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KHJvb3RFbCkudG9IYXZlVGV4dCgnbmV3Jyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudFJlZi5kaXNwb3NlKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChyb290RWwucGFyZW50Tm9kZSkudG9CZUZhbHN5KCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgYWxsb3cgdG8gcGFzcyBwcm9qZWN0YWJsZSBub2RlcycsXG4gICAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlciwgRHluYW1pY0NvbXBvbmVudExvYWRlciwgRE9DVU1FTlQsIEluamVjdG9yXSxcbiAgICAgICAgICAgICAgICAoYXN5bmM6IEFzeW5jVGVzdENvbXBsZXRlciwgbG9hZGVyOiBEeW5hbWljQ29tcG9uZW50TG9hZGVyLCBkb2MsXG4gICAgICAgICAgICAgICAgIGluamVjdG9yOiBJbmplY3RvcikgPT4ge1xuICAgICAgICAgICAgICAgICAgdmFyIHJvb3RFbCA9IGNyZWF0ZVJvb3RFbGVtZW50KGRvYywgJ2R1bW15Jyk7XG4gICAgICAgICAgICAgICAgICBET00uYXBwZW5kQ2hpbGQoZG9jLmJvZHksIHJvb3RFbCk7XG4gICAgICAgICAgICAgICAgICBsb2FkZXIubG9hZEFzUm9vdChEeW5hbWljYWxseUxvYWRlZFdpdGhOZ0NvbnRlbnQsIG51bGwsIGluamVjdG9yLCBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW1tET00uY3JlYXRlVGV4dE5vZGUoJ2hlbGxvJyldXSlcbiAgICAgICAgICAgICAgICAgICAgICAudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KHJvb3RFbCkudG9IYXZlVGV4dCgnZHluYW1pYyhoZWxsbyknKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0pKTtcblxuICAgIH0pO1xuXG4gIH0pO1xufVxuXG5mdW5jdGlvbiBjcmVhdGVSb290RWxlbWVudChkb2M6IGFueSwgbmFtZTogc3RyaW5nKTogYW55IHtcbiAgdmFyIG5vZGVzID0gRE9NLnF1ZXJ5U2VsZWN0b3JBbGwoZG9jLCBuYW1lKTtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBub2Rlcy5sZW5ndGg7IGkrKykge1xuICAgIERPTS5yZW1vdmUobm9kZXNbaV0pO1xuICB9XG4gIHZhciByb290RWwgPSBlbChgPCR7bmFtZX0+PC8ke25hbWV9PmApO1xuICBET00uYXBwZW5kQ2hpbGQoZG9jLmJvZHksIHJvb3RFbCk7XG4gIHJldHVybiByb290RWw7XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnY2hpbGQtY21wJywgdGVtcGxhdGU6ICd7e2N0eFByb3B9fSd9KVxuY2xhc3MgQ2hpbGRDb21wIHtcbiAgY3R4UHJvcDogc3RyaW5nO1xuICBjb25zdHJ1Y3RvcigpIHsgdGhpcy5jdHhQcm9wID0gJ2hlbGxvJzsgfVxufVxuXG5cbmNsYXNzIER5bmFtaWNhbGx5Q3JlYXRlZENvbXBvbmVudFNlcnZpY2Uge31cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnaGVsbG8tY21wJyxcbiAgdmlld1Byb3ZpZGVyczogW0R5bmFtaWNhbGx5Q3JlYXRlZENvbXBvbmVudFNlcnZpY2VdLFxuICB0ZW1wbGF0ZTogXCJ7e2dyZWV0aW5nfX1cIlxufSlcbmNsYXNzIER5bmFtaWNhbGx5Q3JlYXRlZENtcCBpbXBsZW1lbnRzIE9uRGVzdHJveSB7XG4gIGdyZWV0aW5nOiBzdHJpbmc7XG4gIGR5bmFtaWNhbGx5Q3JlYXRlZENvbXBvbmVudFNlcnZpY2U6IER5bmFtaWNhbGx5Q3JlYXRlZENvbXBvbmVudFNlcnZpY2U7XG4gIGRlc3Ryb3llZDogYm9vbGVhbiA9IGZhbHNlO1xuXG4gIGNvbnN0cnVjdG9yKGE6IER5bmFtaWNhbGx5Q3JlYXRlZENvbXBvbmVudFNlcnZpY2UpIHtcbiAgICB0aGlzLmdyZWV0aW5nID0gXCJoZWxsb1wiO1xuICAgIHRoaXMuZHluYW1pY2FsbHlDcmVhdGVkQ29tcG9uZW50U2VydmljZSA9IGE7XG4gIH1cblxuICBuZ09uRGVzdHJveSgpIHsgdGhpcy5kZXN0cm95ZWQgPSB0cnVlOyB9XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnZHVtbXknLCB0ZW1wbGF0ZTogXCJEeW5hbWljYWxseUxvYWRlZDtcIn0pXG5jbGFzcyBEeW5hbWljYWxseUxvYWRlZCB7XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnZHVtbXknLCB0ZW1wbGF0ZTogXCJEeW5hbWljYWxseUxvYWRlZDtcIn0pXG5jbGFzcyBEeW5hbWljYWxseUxvYWRlZFRocm93cyB7XG4gIGNvbnN0cnVjdG9yKCkgeyB0aHJvdyBuZXcgQmFzZUV4Y2VwdGlvbihcIlRocm93bkluQ29uc3RydWN0b3JcIik7IH1cbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdkdW1teScsIHRlbXBsYXRlOiBcIkR5bmFtaWNhbGx5TG9hZGVkMjtcIn0pXG5jbGFzcyBEeW5hbWljYWxseUxvYWRlZDIge1xufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ2R1bW15JywgaG9zdDogeydbaWRdJzogJ2lkJ30sIHRlbXBsYXRlOiBcIkR5bmFtaWNhbGx5TG9hZGVkV2l0aEhvc3RQcm9wcztcIn0pXG5jbGFzcyBEeW5hbWljYWxseUxvYWRlZFdpdGhIb3N0UHJvcHMge1xuICBpZDogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKCkgeyB0aGlzLmlkID0gXCJkZWZhdWx0XCI7IH1cbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdkdW1teScsIHRlbXBsYXRlOiBcImR5bmFtaWMoPG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50PilcIn0pXG5jbGFzcyBEeW5hbWljYWxseUxvYWRlZFdpdGhOZ0NvbnRlbnQge1xuICBpZDogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKCkgeyB0aGlzLmlkID0gXCJkZWZhdWx0XCI7IH1cbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdsb2NhdGlvbicsIHRlbXBsYXRlOiBcIkxvY2F0aW9uO1wifSlcbmNsYXNzIExvY2F0aW9uIHtcbiAgZWxlbWVudFJlZjogRWxlbWVudFJlZjtcblxuICBjb25zdHJ1Y3RvcihlbGVtZW50UmVmOiBFbGVtZW50UmVmKSB7IHRoaXMuZWxlbWVudFJlZiA9IGVsZW1lbnRSZWY7IH1cbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdteS1jb21wJywgZGlyZWN0aXZlczogW119KVxuY2xhc3MgTXlDb21wIHtcbiAgY3R4Qm9vbFByb3A6IGJvb2xlYW47XG5cbiAgY29uc3RydWN0b3IoKSB7IHRoaXMuY3R4Qm9vbFByb3AgPSBmYWxzZTsgfVxufVxuIl19
 main(); 
