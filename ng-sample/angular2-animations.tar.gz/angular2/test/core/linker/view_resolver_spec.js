'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var view_resolver_1 = require('angular2/src/core/linker/view_resolver');
var metadata_1 = require('angular2/src/core/metadata');
var SomeDir = (function () {
    function SomeDir() {
    }
    return SomeDir;
})();
var SomePipe = (function () {
    function SomePipe() {
    }
    return SomePipe;
})();
var ComponentWithView = (function () {
    function ComponentWithView() {
    }
    ComponentWithView = __decorate([
        metadata_1.Component({
            selector: 'sample',
            template: "some template",
            directives: [SomeDir],
            pipes: [SomePipe],
            styles: ["some styles"]
        }), 
        __metadata('design:paramtypes', [])
    ], ComponentWithView);
    return ComponentWithView;
})();
var ComponentWithTemplate = (function () {
    function ComponentWithTemplate() {
    }
    ComponentWithTemplate = __decorate([
        metadata_1.Component({
            selector: 'sample',
            template: "some template",
            directives: [SomeDir],
            pipes: [SomePipe],
            styles: ["some styles"]
        }), 
        __metadata('design:paramtypes', [])
    ], ComponentWithTemplate);
    return ComponentWithTemplate;
})();
var ComponentWithViewTemplate = (function () {
    function ComponentWithViewTemplate() {
    }
    ComponentWithViewTemplate = __decorate([
        metadata_1.Component({ selector: 'sample', template: "some template" }), 
        __metadata('design:paramtypes', [])
    ], ComponentWithViewTemplate);
    return ComponentWithViewTemplate;
})();
var ComponentWithViewTemplateUrl = (function () {
    function ComponentWithViewTemplateUrl() {
    }
    ComponentWithViewTemplateUrl = __decorate([
        metadata_1.Component({ selector: 'sample', templateUrl: "some template url", template: "some template" }), 
        __metadata('design:paramtypes', [])
    ], ComponentWithViewTemplateUrl);
    return ComponentWithViewTemplateUrl;
})();
var ComponentWithoutView = (function () {
    function ComponentWithoutView() {
    }
    ComponentWithoutView = __decorate([
        metadata_1.Component({ selector: 'sample' }), 
        __metadata('design:paramtypes', [])
    ], ComponentWithoutView);
    return ComponentWithoutView;
})();
var SimpleClass = (function () {
    function SimpleClass() {
    }
    return SimpleClass;
})();
function main() {
    testing_internal_1.describe("ViewResolver", function () {
        var resolver;
        testing_internal_1.beforeEach(function () { resolver = new view_resolver_1.ViewResolver(); });
        testing_internal_1.it('should read out the View metadata from the Component metadata', function () {
            var viewMetadata = resolver.resolve(ComponentWithTemplate);
            testing_internal_1.expect(viewMetadata)
                .toEqual(new metadata_1.ViewMetadata({
                template: "some template",
                directives: [SomeDir],
                pipes: [SomePipe],
                styles: ["some styles"]
            }));
        });
        testing_internal_1.it('should throw when Component has no View decorator and no template is set', function () {
            testing_internal_1.expect(function () { return resolver.resolve(ComponentWithoutView); })
                .toThrowErrorWith("Component 'ComponentWithoutView' must have either 'template' or 'templateUrl' set");
        });
        testing_internal_1.it('should throw when simple class has no View decorator and no template is set', function () {
            testing_internal_1.expect(function () { return resolver.resolve(SimpleClass); })
                .toThrowErrorWith("Could not compile 'SimpleClass' because it is not a component.");
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmlld19yZXNvbHZlcl9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb3JlL2xpbmtlci92aWV3X3Jlc29sdmVyX3NwZWMudHMiXSwibmFtZXMiOlsiU29tZURpciIsIlNvbWVEaXIuY29uc3RydWN0b3IiLCJTb21lUGlwZSIsIlNvbWVQaXBlLmNvbnN0cnVjdG9yIiwiQ29tcG9uZW50V2l0aFZpZXciLCJDb21wb25lbnRXaXRoVmlldy5jb25zdHJ1Y3RvciIsIkNvbXBvbmVudFdpdGhUZW1wbGF0ZSIsIkNvbXBvbmVudFdpdGhUZW1wbGF0ZS5jb25zdHJ1Y3RvciIsIkNvbXBvbmVudFdpdGhWaWV3VGVtcGxhdGUiLCJDb21wb25lbnRXaXRoVmlld1RlbXBsYXRlLmNvbnN0cnVjdG9yIiwiQ29tcG9uZW50V2l0aFZpZXdUZW1wbGF0ZVVybCIsIkNvbXBvbmVudFdpdGhWaWV3VGVtcGxhdGVVcmwuY29uc3RydWN0b3IiLCJDb21wb25lbnRXaXRob3V0VmlldyIsIkNvbXBvbmVudFdpdGhvdXRWaWV3LmNvbnN0cnVjdG9yIiwiU2ltcGxlQ2xhc3MiLCJTaW1wbGVDbGFzcy5jb25zdHJ1Y3RvciIsIm1haW4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLGlDQUErRCwyQkFBMkIsQ0FBQyxDQUFBO0FBQzNGLDhCQUEyQix3Q0FBd0MsQ0FBQyxDQUFBO0FBQ3BFLHlCQUFzQyw0QkFBNEIsQ0FBQyxDQUFBO0FBRW5FO0lBQUFBO0lBQWVDLENBQUNBO0lBQURELGNBQUNBO0FBQURBLENBQUNBLEFBQWhCLElBQWdCO0FBQ2hCO0lBQUFFO0lBQWdCQyxDQUFDQTtJQUFERCxlQUFDQTtBQUFEQSxDQUFDQSxBQUFqQixJQUFpQjtBQUVqQjtJQUFBRTtJQVFBQyxDQUFDQTtJQVJERDtRQUFDQSxvQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsUUFBUUE7WUFDbEJBLFFBQVFBLEVBQUVBLGVBQWVBO1lBQ3pCQSxVQUFVQSxFQUFFQSxDQUFDQSxPQUFPQSxDQUFDQTtZQUNyQkEsS0FBS0EsRUFBRUEsQ0FBQ0EsUUFBUUEsQ0FBQ0E7WUFDakJBLE1BQU1BLEVBQUVBLENBQUNBLGFBQWFBLENBQUNBO1NBQ3hCQSxDQUFDQTs7MEJBRURBO0lBQURBLHdCQUFDQTtBQUFEQSxDQUFDQSxBQVJELElBUUM7QUFFRDtJQUFBRTtJQVFBQyxDQUFDQTtJQVJERDtRQUFDQSxvQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsUUFBUUE7WUFDbEJBLFFBQVFBLEVBQUVBLGVBQWVBO1lBQ3pCQSxVQUFVQSxFQUFFQSxDQUFDQSxPQUFPQSxDQUFDQTtZQUNyQkEsS0FBS0EsRUFBRUEsQ0FBQ0EsUUFBUUEsQ0FBQ0E7WUFDakJBLE1BQU1BLEVBQUVBLENBQUNBLGFBQWFBLENBQUNBO1NBQ3hCQSxDQUFDQTs7OEJBRURBO0lBQURBLDRCQUFDQTtBQUFEQSxDQUFDQSxBQVJELElBUUM7QUFFRDtJQUFBRTtJQUVBQyxDQUFDQTtJQUZERDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsUUFBUUEsRUFBRUEsUUFBUUEsRUFBRUEsZUFBZUEsRUFBQ0EsQ0FBQ0E7O2tDQUUxREE7SUFBREEsZ0NBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBQUFFO0lBRUFDLENBQUNBO0lBRkREO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxRQUFRQSxFQUFFQSxXQUFXQSxFQUFFQSxtQkFBbUJBLEVBQUVBLFFBQVFBLEVBQUVBLGVBQWVBLEVBQUNBLENBQUNBOztxQ0FFNUZBO0lBQURBLG1DQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUM7QUFFRDtJQUFBRTtJQUVBQyxDQUFDQTtJQUZERDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsUUFBUUEsRUFBQ0EsQ0FBQ0E7OzZCQUUvQkE7SUFBREEsMkJBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUdEO0lBQUFFO0lBQW1CQyxDQUFDQTtJQUFERCxrQkFBQ0E7QUFBREEsQ0FBQ0EsQUFBcEIsSUFBb0I7QUFFcEI7SUFDRUUsMkJBQVFBLENBQUNBLGNBQWNBLEVBQUVBO1FBQ3ZCQSxJQUFJQSxRQUFzQkEsQ0FBQ0E7UUFFM0JBLDZCQUFVQSxDQUFDQSxjQUFRQSxRQUFRQSxHQUFHQSxJQUFJQSw0QkFBWUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFckRBLHFCQUFFQSxDQUFDQSwrREFBK0RBLEVBQUVBO1lBQ2xFQSxJQUFJQSxZQUFZQSxHQUFHQSxRQUFRQSxDQUFDQSxPQUFPQSxDQUFDQSxxQkFBcUJBLENBQUNBLENBQUNBO1lBQzNEQSx5QkFBTUEsQ0FBQ0EsWUFBWUEsQ0FBQ0E7aUJBQ2ZBLE9BQU9BLENBQUNBLElBQUlBLHVCQUFZQSxDQUFDQTtnQkFDeEJBLFFBQVFBLEVBQUVBLGVBQWVBO2dCQUN6QkEsVUFBVUEsRUFBRUEsQ0FBQ0EsT0FBT0EsQ0FBQ0E7Z0JBQ3JCQSxLQUFLQSxFQUFFQSxDQUFDQSxRQUFRQSxDQUFDQTtnQkFDakJBLE1BQU1BLEVBQUVBLENBQUNBLGFBQWFBLENBQUNBO2FBQ3hCQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNWQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSxxQkFBRUEsQ0FBQ0EsMEVBQTBFQSxFQUFFQTtZQUM3RUEseUJBQU1BLENBQUNBLGNBQU1BLE9BQUFBLFFBQVFBLENBQUNBLE9BQU9BLENBQUNBLG9CQUFvQkEsQ0FBQ0EsRUFBdENBLENBQXNDQSxDQUFDQTtpQkFDL0NBLGdCQUFnQkEsQ0FDYkEsbUZBQW1GQSxDQUFDQSxDQUFDQTtRQUMvRkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLDZFQUE2RUEsRUFBRUE7WUFDaEZBLHlCQUFNQSxDQUFDQSxjQUFNQSxPQUFBQSxRQUFRQSxDQUFDQSxPQUFPQSxDQUFDQSxXQUFXQSxDQUFDQSxFQUE3QkEsQ0FBNkJBLENBQUNBO2lCQUN0Q0EsZ0JBQWdCQSxDQUFDQSxnRUFBZ0VBLENBQUNBLENBQUNBO1FBQzFGQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQTVCZSxZQUFJLE9BNEJuQixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtkZGVzY3JpYmUsIGRlc2NyaWJlLCBpdCwgaWl0LCBleHBlY3QsIGJlZm9yZUVhY2h9IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuaW1wb3J0IHtWaWV3UmVzb2x2ZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci92aWV3X3Jlc29sdmVyJztcbmltcG9ydCB7Q29tcG9uZW50LCBWaWV3TWV0YWRhdGF9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL21ldGFkYXRhJztcblxuY2xhc3MgU29tZURpciB7fVxuY2xhc3MgU29tZVBpcGUge31cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnc2FtcGxlJyxcbiAgdGVtcGxhdGU6IFwic29tZSB0ZW1wbGF0ZVwiLFxuICBkaXJlY3RpdmVzOiBbU29tZURpcl0sXG4gIHBpcGVzOiBbU29tZVBpcGVdLFxuICBzdHlsZXM6IFtcInNvbWUgc3R5bGVzXCJdXG59KVxuY2xhc3MgQ29tcG9uZW50V2l0aFZpZXcge1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdzYW1wbGUnLFxuICB0ZW1wbGF0ZTogXCJzb21lIHRlbXBsYXRlXCIsXG4gIGRpcmVjdGl2ZXM6IFtTb21lRGlyXSxcbiAgcGlwZXM6IFtTb21lUGlwZV0sXG4gIHN0eWxlczogW1wic29tZSBzdHlsZXNcIl1cbn0pXG5jbGFzcyBDb21wb25lbnRXaXRoVGVtcGxhdGUge1xufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ3NhbXBsZScsIHRlbXBsYXRlOiBcInNvbWUgdGVtcGxhdGVcIn0pXG5jbGFzcyBDb21wb25lbnRXaXRoVmlld1RlbXBsYXRlIHtcbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdzYW1wbGUnLCB0ZW1wbGF0ZVVybDogXCJzb21lIHRlbXBsYXRlIHVybFwiLCB0ZW1wbGF0ZTogXCJzb21lIHRlbXBsYXRlXCJ9KVxuY2xhc3MgQ29tcG9uZW50V2l0aFZpZXdUZW1wbGF0ZVVybCB7XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnc2FtcGxlJ30pXG5jbGFzcyBDb21wb25lbnRXaXRob3V0VmlldyB7XG59XG5cblxuY2xhc3MgU2ltcGxlQ2xhc3Mge31cblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGRlc2NyaWJlKFwiVmlld1Jlc29sdmVyXCIsICgpID0+IHtcbiAgICB2YXIgcmVzb2x2ZXI6IFZpZXdSZXNvbHZlcjtcblxuICAgIGJlZm9yZUVhY2goKCkgPT4geyByZXNvbHZlciA9IG5ldyBWaWV3UmVzb2x2ZXIoKTsgfSk7XG5cbiAgICBpdCgnc2hvdWxkIHJlYWQgb3V0IHRoZSBWaWV3IG1ldGFkYXRhIGZyb20gdGhlIENvbXBvbmVudCBtZXRhZGF0YScsICgpID0+IHtcbiAgICAgIHZhciB2aWV3TWV0YWRhdGEgPSByZXNvbHZlci5yZXNvbHZlKENvbXBvbmVudFdpdGhUZW1wbGF0ZSk7XG4gICAgICBleHBlY3Qodmlld01ldGFkYXRhKVxuICAgICAgICAgIC50b0VxdWFsKG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgdGVtcGxhdGU6IFwic29tZSB0ZW1wbGF0ZVwiLFxuICAgICAgICAgICAgZGlyZWN0aXZlczogW1NvbWVEaXJdLFxuICAgICAgICAgICAgcGlwZXM6IFtTb21lUGlwZV0sXG4gICAgICAgICAgICBzdHlsZXM6IFtcInNvbWUgc3R5bGVzXCJdXG4gICAgICAgICAgfSkpO1xuICAgIH0pO1xuXG4gICAgaXQoJ3Nob3VsZCB0aHJvdyB3aGVuIENvbXBvbmVudCBoYXMgbm8gVmlldyBkZWNvcmF0b3IgYW5kIG5vIHRlbXBsYXRlIGlzIHNldCcsICgpID0+IHtcbiAgICAgIGV4cGVjdCgoKSA9PiByZXNvbHZlci5yZXNvbHZlKENvbXBvbmVudFdpdGhvdXRWaWV3KSlcbiAgICAgICAgICAudG9UaHJvd0Vycm9yV2l0aChcbiAgICAgICAgICAgICAgXCJDb21wb25lbnQgJ0NvbXBvbmVudFdpdGhvdXRWaWV3JyBtdXN0IGhhdmUgZWl0aGVyICd0ZW1wbGF0ZScgb3IgJ3RlbXBsYXRlVXJsJyBzZXRcIik7XG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIHRocm93IHdoZW4gc2ltcGxlIGNsYXNzIGhhcyBubyBWaWV3IGRlY29yYXRvciBhbmQgbm8gdGVtcGxhdGUgaXMgc2V0JywgKCkgPT4ge1xuICAgICAgZXhwZWN0KCgpID0+IHJlc29sdmVyLnJlc29sdmUoU2ltcGxlQ2xhc3MpKVxuICAgICAgICAgIC50b1Rocm93RXJyb3JXaXRoKFwiQ291bGQgbm90IGNvbXBpbGUgJ1NpbXBsZUNsYXNzJyBiZWNhdXNlIGl0IGlzIG5vdCBhIGNvbXBvbmVudC5cIik7XG4gICAgfSk7XG4gIH0pO1xufVxuIl19
 main(); 
