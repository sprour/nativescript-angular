'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var testing_internal_1 = require('angular2/testing_internal');
var dom_adapter_1 = require('angular2/src/platform/dom/dom_adapter');
var lang_1 = require('angular2/src/facade/lang');
var exceptions_1 = require('angular2/src/facade/exceptions');
var async_1 = require('angular2/src/facade/async');
var core_1 = require('angular2/core');
var common_1 = require('angular2/common');
var common_2 = require('angular2/common');
var change_detection_1 = require('angular2/src/core/change_detection/change_detection');
var metadata_1 = require('angular2/src/core/metadata');
var query_list_1 = require('angular2/src/core/linker/query_list');
var view_container_ref_1 = require('angular2/src/core/linker/view_container_ref');
var compiler_1 = require('angular2/src/core/linker/compiler');
var element_ref_1 = require('angular2/src/core/linker/element_ref');
var template_ref_1 = require('angular2/src/core/linker/template_ref');
var render_1 = require('angular2/src/core/render');
var lang_2 = require('angular2/src/facade/lang');
var ANCHOR_ELEMENT = lang_1.CONST_EXPR(new core_1.OpaqueToken('AnchorElement'));
function main() {
    if (lang_2.IS_DART) {
        declareTests();
    }
    else {
        testing_internal_1.describe('no jit', function () {
            testing_internal_1.beforeEachProviders(function () { return [
                core_1.provide(change_detection_1.ChangeDetectorGenConfig, { useValue: new change_detection_1.ChangeDetectorGenConfig(true, false, false) })
            ]; });
            declareTests();
        });
        testing_internal_1.describe('jit', function () {
            testing_internal_1.beforeEachProviders(function () { return [
                core_1.provide(change_detection_1.ChangeDetectorGenConfig, { useValue: new change_detection_1.ChangeDetectorGenConfig(true, false, true) })
            ]; });
            declareTests();
        });
    }
}
exports.main = main;
function declareTests() {
    testing_internal_1.describe('integration tests', function () {
        testing_internal_1.beforeEachProviders(function () { return [core_1.provide(ANCHOR_ELEMENT, { useValue: testing_internal_1.el('<div></div>') })]; });
        testing_internal_1.describe('react to record changes', function () {
            testing_internal_1.it('should consume text node changes', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div>{{ctxProp}}</div>' }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.ctxProp = 'Hello World!';
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('Hello World!');
                    async.done();
                });
            }));
            testing_internal_1.it('should update text node with a blank string when interpolation evaluates to null', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div>{{null}}{{ctxProp}}</div>' }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.ctxProp = null;
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('');
                    async.done();
                });
            }));
            testing_internal_1.it('should consume element binding changes', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div [id]="ctxProp"></div>' }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.ctxProp = 'Hello World!';
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.children[0].nativeElement.id).toEqual('Hello World!');
                    async.done();
                });
            }));
            testing_internal_1.it('should consume binding to aria-* attributes', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div [attr.aria-label]="ctxProp"></div>' }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.ctxProp = 'Initial aria label';
                    fixture.detectChanges();
                    testing_internal_1.expect(dom_adapter_1.DOM.getAttribute(fixture.debugElement.children[0].nativeElement, 'aria-label'))
                        .toEqual('Initial aria label');
                    fixture.debugElement.componentInstance.ctxProp = 'Changed aria label';
                    fixture.detectChanges();
                    testing_internal_1.expect(dom_adapter_1.DOM.getAttribute(fixture.debugElement.children[0].nativeElement, 'aria-label'))
                        .toEqual('Changed aria label');
                    async.done();
                });
            }));
            testing_internal_1.it('should remove an attribute when attribute expression evaluates to null', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div [attr.foo]="ctxProp"></div>' }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.ctxProp = 'bar';
                    fixture.detectChanges();
                    testing_internal_1.expect(dom_adapter_1.DOM.getAttribute(fixture.debugElement.children[0].nativeElement, 'foo'))
                        .toEqual('bar');
                    fixture.debugElement.componentInstance.ctxProp = null;
                    fixture.detectChanges();
                    testing_internal_1.expect(dom_adapter_1.DOM.hasAttribute(fixture.debugElement.children[0].nativeElement, 'foo'))
                        .toBeFalsy();
                    async.done();
                });
            }));
            testing_internal_1.it('should remove style when when style expression evaluates to null', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div [style.height.px]="ctxProp"></div>' }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.ctxProp = '10';
                    fixture.detectChanges();
                    testing_internal_1.expect(dom_adapter_1.DOM.getStyle(fixture.debugElement.children[0].nativeElement, 'height'))
                        .toEqual('10px');
                    fixture.debugElement.componentInstance.ctxProp = null;
                    fixture.detectChanges();
                    testing_internal_1.expect(dom_adapter_1.DOM.getStyle(fixture.debugElement.children[0].nativeElement, 'height'))
                        .toEqual('');
                    async.done();
                });
            }));
            testing_internal_1.it('should consume binding to property names where attr name and property name do not match', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div [tabindex]="ctxNumProp"></div>' }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.children[0].nativeElement.tabIndex).toEqual(0);
                    fixture.debugElement.componentInstance.ctxNumProp = 5;
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.children[0].nativeElement.tabIndex).toEqual(5);
                    async.done();
                });
            }));
            testing_internal_1.it('should consume binding to camel-cased properties', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<input [readOnly]="ctxBoolProp">' }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.children[0].nativeElement.readOnly).toBeFalsy();
                    fixture.debugElement.componentInstance.ctxBoolProp = true;
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.children[0].nativeElement.readOnly).toBeTruthy();
                    async.done();
                });
            }));
            testing_internal_1.it('should consume binding to innerHtml', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div innerHtml="{{ctxProp}}"></div>' }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.ctxProp = 'Some <span>HTML</span>';
                    fixture.detectChanges();
                    testing_internal_1.expect(dom_adapter_1.DOM.getInnerHTML(fixture.debugElement.children[0].nativeElement))
                        .toEqual('Some <span>HTML</span>');
                    fixture.debugElement.componentInstance.ctxProp = 'Some other <div>HTML</div>';
                    fixture.detectChanges();
                    testing_internal_1.expect(dom_adapter_1.DOM.getInnerHTML(fixture.debugElement.children[0].nativeElement))
                        .toEqual('Some other <div>HTML</div>');
                    async.done();
                });
            }));
            testing_internal_1.it('should consume binding to className using class alias', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div class="initial" [class]="ctxProp"></div>' }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var nativeEl = fixture.debugElement.children[0].nativeElement;
                    fixture.debugElement.componentInstance.ctxProp = 'foo bar';
                    fixture.detectChanges();
                    testing_internal_1.expect(nativeEl).toHaveCssClass('foo');
                    testing_internal_1.expect(nativeEl).toHaveCssClass('bar');
                    testing_internal_1.expect(nativeEl).not.toHaveCssClass('initial');
                    async.done();
                });
            }));
            testing_internal_1.it('should consume directive watch expression change.', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var tpl = '<span>' +
                    '<div my-dir [elprop]="ctxProp"></div>' +
                    '<div my-dir elprop="Hi there!"></div>' +
                    '<div my-dir elprop="Hi {{\'there!\'}}"></div>' +
                    '<div my-dir elprop="One more {{ctxProp}}"></div>' +
                    '</span>';
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: tpl, directives: [MyDir] }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.ctxProp = 'Hello World!';
                    fixture.detectChanges();
                    var containerSpan = fixture.debugElement.children[0];
                    testing_internal_1.expect(containerSpan.children[0].inject(MyDir).dirProp).toEqual('Hello World!');
                    testing_internal_1.expect(containerSpan.children[1].inject(MyDir).dirProp).toEqual('Hi there!');
                    testing_internal_1.expect(containerSpan.children[2].inject(MyDir).dirProp).toEqual('Hi there!');
                    testing_internal_1.expect(containerSpan.children[3].inject(MyDir).dirProp)
                        .toEqual('One more Hello World!');
                    async.done();
                });
            }));
            testing_internal_1.describe('pipes', function () {
                testing_internal_1.it("should support pipes in bindings", testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<div my-dir #dir="mydir" [elprop]="ctxProp | double"></div>',
                        directives: [MyDir],
                        pipes: [DoublePipe]
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        fixture.debugElement.componentInstance.ctxProp = 'a';
                        fixture.detectChanges();
                        var dir = fixture.debugElement.children[0].getLocal('dir');
                        testing_internal_1.expect(dir.dirProp).toEqual('aa');
                        async.done();
                    });
                }));
            });
            testing_internal_1.it('should support nested components.', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<child-cmp></child-cmp>', directives: [ChildComp] }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('hello');
                    async.done();
                });
            }));
            // GH issue 328 - https://github.com/angular/angular/issues/328
            testing_internal_1.it('should support different directive types on a single node', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<child-cmp my-dir [elprop]="ctxProp"></child-cmp>',
                    directives: [MyDir, ChildComp]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.ctxProp = 'Hello World!';
                    fixture.detectChanges();
                    var tc = fixture.debugElement.children[0];
                    testing_internal_1.expect(tc.inject(MyDir).dirProp).toEqual('Hello World!');
                    testing_internal_1.expect(tc.inject(ChildComp).dirProp).toEqual(null);
                    async.done();
                });
            }));
            testing_internal_1.it('should support directives where a binding attribute is not given', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    // No attribute "el-prop" specified.
                    template: '<p my-dir></p>',
                    directives: [MyDir]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) { async.done(); });
            }));
            testing_internal_1.it('should execute a given directive once, even if specified multiple times', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<p no-duplicate></p>',
                    directives: [DuplicateDir, DuplicateDir, [DuplicateDir, [DuplicateDir]]]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('noduplicate');
                    async.done();
                });
            }));
            testing_internal_1.it('should support directives where a selector matches property binding', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<p [id]="ctxProp"></p>', directives: [IdDir] }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var tc = fixture.debugElement.children[0];
                    var idDir = tc.inject(IdDir);
                    fixture.debugElement.componentInstance.ctxProp = 'some_id';
                    fixture.detectChanges();
                    testing_internal_1.expect(idDir.id).toEqual('some_id');
                    fixture.debugElement.componentInstance.ctxProp = 'other_id';
                    fixture.detectChanges();
                    testing_internal_1.expect(idDir.id).toEqual('other_id');
                    async.done();
                });
            }));
            testing_internal_1.it('should support directives where a selector matches event binding', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<p (customEvent)="doNothing()"></p>', directives: [EventDir] }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var tc = fixture.debugElement.children[0];
                    testing_internal_1.expect(tc.inject(EventDir)).not.toBe(null);
                    async.done();
                });
            }));
            testing_internal_1.it('should read directives metadata from their binding token', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<div public-api><div needs-public-api></div></div>',
                    directives: [PrivateImpl, NeedsPublicApi]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) { async.done(); });
            }));
            testing_internal_1.it('should support template directives via `<template>` elements.', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<template some-viewport var-greeting="some-tmpl"><copy-me>{{greeting}}</copy-me></template>',
                    directives: [SomeViewport]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.detectChanges();
                    var childNodesOfWrapper = dom_adapter_1.DOM.childNodes(fixture.debugElement.nativeElement);
                    // 1 template + 2 copies.
                    testing_internal_1.expect(childNodesOfWrapper.length).toBe(3);
                    testing_internal_1.expect(childNodesOfWrapper[1]).toHaveText('hello');
                    testing_internal_1.expect(childNodesOfWrapper[2]).toHaveText('again');
                    async.done();
                });
            }));
            testing_internal_1.it('should use a comment while stamping out `<template>` elements.', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<template></template>' }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var childNodesOfWrapper = dom_adapter_1.DOM.childNodes(fixture.debugElement.nativeElement);
                    testing_internal_1.expect(childNodesOfWrapper.length).toBe(1);
                    testing_internal_1.expect(dom_adapter_1.DOM.isCommentNode(childNodesOfWrapper[0])).toBe(true);
                    async.done();
                });
            }));
            testing_internal_1.it('should support template directives via `template` attribute.', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<copy-me template="some-viewport: var greeting=some-tmpl">{{greeting}}</copy-me>',
                    directives: [SomeViewport]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.detectChanges();
                    var childNodesOfWrapper = dom_adapter_1.DOM.childNodes(fixture.debugElement.nativeElement);
                    // 1 template + 2 copies.
                    testing_internal_1.expect(childNodesOfWrapper.length).toBe(3);
                    testing_internal_1.expect(childNodesOfWrapper[1]).toHaveText('hello');
                    testing_internal_1.expect(childNodesOfWrapper[2]).toHaveText('again');
                    async.done();
                });
            }));
            testing_internal_1.it('should allow to transplant embedded ProtoViews into other ViewContainers', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<some-directive><toolbar><template toolbarpart var-toolbarProp="toolbarProp">{{ctxProp}},{{toolbarProp}},<cmp-with-host></cmp-with-host></template></toolbar></some-directive>',
                    directives: [SomeDirective, CompWithHost, ToolbarComponent, ToolbarPart]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.ctxProp = 'From myComp';
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement)
                        .toHaveText('TOOLBAR(From myComp,From toolbar,Component with an injected host)');
                    async.done();
                });
            }));
            testing_internal_1.describe("variable bindings", function () {
                testing_internal_1.it('should assign a component to a var-', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<p><child-cmp var-alice></child-cmp></p>',
                        directives: [ChildComp]
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        testing_internal_1.expect(fixture.debugElement.children[0].children[0].getLocal('alice'))
                            .toBeAnInstanceOf(ChildComp);
                        async.done();
                    });
                }));
                testing_internal_1.it('should assign a directive to a var-', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<div><div export-dir #localdir="dir"></div></div>',
                        directives: [ExportDir]
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        testing_internal_1.expect(fixture.debugElement.children[0].children[0].getLocal('localdir'))
                            .toBeAnInstanceOf(ExportDir);
                        async.done();
                    });
                }));
                testing_internal_1.it('should make the assigned component accessible in property bindings', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<p><child-cmp var-alice></child-cmp>{{alice.ctxProp}}</p>',
                        directives: [ChildComp]
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        fixture.detectChanges();
                        testing_internal_1.expect(fixture.debugElement.nativeElement)
                            .toHaveText('hellohello'); // this first one is the
                        // component, the second one is
                        // the text binding
                        async.done();
                    });
                }));
                testing_internal_1.it('should assign two component instances each with a var-', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<p><child-cmp var-alice></child-cmp><child-cmp var-bob></child-cmp></p>',
                        directives: [ChildComp]
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        var childCmp = fixture.debugElement.children[0].children[0];
                        testing_internal_1.expect(childCmp.getLocal('alice')).toBeAnInstanceOf(ChildComp);
                        testing_internal_1.expect(childCmp.getLocal('bob')).toBeAnInstanceOf(ChildComp);
                        testing_internal_1.expect(childCmp.getLocal('alice')).not.toBe(childCmp.getLocal('bob'));
                        async.done();
                    });
                }));
                testing_internal_1.it('should assign the component instance to a var- with shorthand syntax', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<child-cmp #alice></child-cmp>',
                        directives: [ChildComp]
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        testing_internal_1.expect(fixture.debugElement.children[0].getLocal('alice'))
                            .toBeAnInstanceOf(ChildComp);
                        async.done();
                    });
                }));
                testing_internal_1.it('should assign the element instance to a user-defined variable', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<div><div var-alice><i>Hello</i></div></div>'
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        var value = fixture.debugElement.children[0].children[0].getLocal('alice');
                        testing_internal_1.expect(value).not.toBe(null);
                        testing_internal_1.expect(value.tagName.toLowerCase()).toEqual('div');
                        async.done();
                    });
                }));
                testing_internal_1.it('should preserve case', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<p><child-cmp var-superAlice></child-cmp></p>',
                        directives: [ChildComp]
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        testing_internal_1.expect(fixture.debugElement.children[0].children[0].getLocal('superAlice'))
                            .toBeAnInstanceOf(ChildComp);
                        async.done();
                    });
                }));
                testing_internal_1.it('should allow to use variables in a for loop', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<template ngFor [ngForOf]="[1]" var-i><child-cmp-no-template #cmp></child-cmp-no-template>{{i}}-{{cmp.ctxProp}}</template>',
                        directives: [ChildCompNoTemplate, common_1.NgFor]
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        fixture.detectChanges();
                        // Get the element at index 2, since index 0 is the <template>.
                        testing_internal_1.expect(dom_adapter_1.DOM.childNodes(fixture.debugElement.nativeElement)[2])
                            .toHaveText("1-hello");
                        async.done();
                    });
                }));
            });
            testing_internal_1.describe("OnPush components", function () {
                testing_internal_1.it("should use ChangeDetectorRef to manually request a check", testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<push-cmp-with-ref #cmp></push-cmp-with-ref>',
                        directives: [[[PushCmpWithRef]]]
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        var cmp = fixture.debugElement.children[0].getLocal('cmp');
                        fixture.detectChanges();
                        testing_internal_1.expect(cmp.numberOfChecks).toEqual(1);
                        fixture.detectChanges();
                        testing_internal_1.expect(cmp.numberOfChecks).toEqual(1);
                        cmp.propagate();
                        fixture.detectChanges();
                        testing_internal_1.expect(cmp.numberOfChecks).toEqual(2);
                        async.done();
                    });
                }));
                testing_internal_1.it("should be checked when its bindings got updated", testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<push-cmp [prop]="ctxProp" #cmp></push-cmp>',
                        directives: [[[PushCmp]]]
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        var cmp = fixture.debugElement.children[0].getLocal('cmp');
                        fixture.debugElement.componentInstance.ctxProp = "one";
                        fixture.detectChanges();
                        testing_internal_1.expect(cmp.numberOfChecks).toEqual(1);
                        fixture.debugElement.componentInstance.ctxProp = "two";
                        fixture.detectChanges();
                        testing_internal_1.expect(cmp.numberOfChecks).toEqual(2);
                        async.done();
                    });
                }));
                if (dom_adapter_1.DOM.supportsDOMEvents()) {
                    testing_internal_1.it("should allow to destroy a component from within a host event handler", testing_internal_1.inject([testing_internal_1.TestComponentBuilder], testing_internal_1.fakeAsync(function (tcb) {
                        var fixture;
                        tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                            template: '<push-cmp-with-host-event></push-cmp-with-host-event>',
                            directives: [[[PushCmpWithHostEvent]]]
                        }))
                            .createAsync(MyComp)
                            .then(function (root) { fixture = root; });
                        testing_internal_1.tick();
                        fixture.detectChanges();
                        var cmpEl = fixture.debugElement.children[0];
                        var cmp = cmpEl.inject(PushCmpWithHostEvent);
                        cmp.ctxCallback = function (_) { return fixture.destroy(); };
                        testing_internal_1.expect(function () { return cmpEl.triggerEventHandler('click', {}); }).not.toThrow();
                    })));
                }
                testing_internal_1.it('should not affect updating properties on the component', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<push-cmp-with-ref [prop]="ctxProp" #cmp></push-cmp-with-ref>',
                        directives: [[[PushCmpWithRef]]]
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        var cmp = fixture.debugElement.children[0].getLocal('cmp');
                        fixture.debugElement.componentInstance.ctxProp = "one";
                        fixture.detectChanges();
                        testing_internal_1.expect(cmp.prop).toEqual("one");
                        fixture.debugElement.componentInstance.ctxProp = "two";
                        fixture.detectChanges();
                        testing_internal_1.expect(cmp.prop).toEqual("two");
                        async.done();
                    });
                }));
                if (dom_adapter_1.DOM.supportsDOMEvents()) {
                    testing_internal_1.it('should be checked when an async pipe requests a check', testing_internal_1.inject([testing_internal_1.TestComponentBuilder], testing_internal_1.fakeAsync(function (tcb) {
                        tcb = tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                            template: '<push-cmp-with-async #cmp></push-cmp-with-async>',
                            directives: [[[PushCmpWithAsyncPipe]]]
                        }));
                        var fixture;
                        tcb.createAsync(MyComp).then(function (root) { fixture = root; });
                        testing_internal_1.tick();
                        var cmp = fixture.debugElement.children[0].getLocal('cmp');
                        fixture.detectChanges();
                        testing_internal_1.expect(cmp.numberOfChecks).toEqual(1);
                        fixture.detectChanges();
                        fixture.detectChanges();
                        testing_internal_1.expect(cmp.numberOfChecks).toEqual(1);
                        cmp.resolve(2);
                        testing_internal_1.tick();
                        fixture.detectChanges();
                        testing_internal_1.expect(cmp.numberOfChecks).toEqual(2);
                    })));
                }
            });
            testing_internal_1.it('should create a component that injects an @Host', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: "\n            <some-directive>\n              <p>\n                <cmp-with-host #child></cmp-with-host>\n              </p>\n            </some-directive>",
                    directives: [SomeDirective, CompWithHost]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var childComponent = fixture.debugElement.children[0].getLocal('child');
                    testing_internal_1.expect(childComponent.myHost).toBeAnInstanceOf(SomeDirective);
                    async.done();
                });
            }));
            testing_internal_1.it('should create a component that injects an @Host through viewcontainer directive', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: "\n            <some-directive>\n              <p *ngIf=\"true\">\n                <cmp-with-host #child></cmp-with-host>\n              </p>\n            </some-directive>",
                    directives: [SomeDirective, CompWithHost, common_1.NgIf]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.detectChanges();
                    var tc = fixture.debugElement.children[0].children[0].children[0];
                    var childComponent = tc.getLocal('child');
                    testing_internal_1.expect(childComponent.myHost).toBeAnInstanceOf(SomeDirective);
                    async.done();
                });
            }));
            testing_internal_1.it('should support events via EventEmitter on regular elements', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<div emitter listener></div>',
                    directives: [DirectiveEmittingEvent, DirectiveListeningEvent]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var tc = fixture.debugElement.children[0];
                    var emitter = tc.inject(DirectiveEmittingEvent);
                    var listener = tc.inject(DirectiveListeningEvent);
                    testing_internal_1.expect(listener.msg).toEqual('');
                    var eventCount = 0;
                    async_1.ObservableWrapper.subscribe(emitter.event, function (_) {
                        eventCount++;
                        if (eventCount === 1) {
                            testing_internal_1.expect(listener.msg).toEqual('fired !');
                            fixture.destroy();
                            emitter.fireEvent('fired again !');
                        }
                        else {
                            testing_internal_1.expect(listener.msg).toEqual('fired !');
                            async.done();
                        }
                    });
                    emitter.fireEvent('fired !');
                });
            }));
            testing_internal_1.it('should support events via EventEmitter on template elements', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<template emitter listener (event)="ctxProp=$event"></template>',
                    directives: [DirectiveEmittingEvent, DirectiveListeningEvent]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var tc = fixture.debugElement.childNodes[0];
                    var emitter = tc.inject(DirectiveEmittingEvent);
                    var myComp = fixture.debugElement.inject(MyComp);
                    var listener = tc.inject(DirectiveListeningEvent);
                    myComp.ctxProp = '';
                    testing_internal_1.expect(listener.msg).toEqual('');
                    async_1.ObservableWrapper.subscribe(emitter.event, function (_) {
                        testing_internal_1.expect(listener.msg).toEqual('fired !');
                        testing_internal_1.expect(myComp.ctxProp).toEqual('fired !');
                        async.done();
                    });
                    emitter.fireEvent('fired !');
                });
            }));
            testing_internal_1.it('should support [()] syntax', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<div [(control)]="ctxProp" two-way></div>',
                    directives: [DirectiveWithTwoWayBinding]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var tc = fixture.debugElement.children[0];
                    var dir = tc.inject(DirectiveWithTwoWayBinding);
                    fixture.debugElement.componentInstance.ctxProp = 'one';
                    fixture.detectChanges();
                    testing_internal_1.expect(dir.control).toEqual('one');
                    async_1.ObservableWrapper.subscribe(dir.controlChange, function (_) {
                        testing_internal_1.expect(fixture.debugElement.componentInstance.ctxProp).toEqual('two');
                        async.done();
                    });
                    dir.triggerChange('two');
                });
            }));
            testing_internal_1.it('should support render events', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div listener></div>', directives: [DirectiveListeningDomEvent] }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var tc = fixture.debugElement.children[0];
                    var listener = tc.inject(DirectiveListeningDomEvent);
                    testing_internal_1.dispatchEvent(tc.nativeElement, 'domEvent');
                    testing_internal_1.expect(listener.eventTypes)
                        .toEqual(['domEvent', 'body_domEvent', 'document_domEvent', 'window_domEvent']);
                    fixture.destroy();
                    listener.eventTypes = [];
                    testing_internal_1.dispatchEvent(tc.nativeElement, 'domEvent');
                    testing_internal_1.expect(listener.eventTypes).toEqual([]);
                    async.done();
                });
            }));
            testing_internal_1.it('should support render global events', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div listener></div>', directives: [DirectiveListeningDomEvent] }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var tc = fixture.debugElement.children[0];
                    var listener = tc.inject(DirectiveListeningDomEvent);
                    testing_internal_1.dispatchEvent(dom_adapter_1.DOM.getGlobalEventTarget("window"), 'domEvent');
                    testing_internal_1.expect(listener.eventTypes).toEqual(['window_domEvent']);
                    listener.eventTypes = [];
                    testing_internal_1.dispatchEvent(dom_adapter_1.DOM.getGlobalEventTarget("document"), 'domEvent');
                    testing_internal_1.expect(listener.eventTypes).toEqual(['document_domEvent', 'window_domEvent']);
                    fixture.destroy();
                    listener.eventTypes = [];
                    testing_internal_1.dispatchEvent(dom_adapter_1.DOM.getGlobalEventTarget("body"), 'domEvent');
                    testing_internal_1.expect(listener.eventTypes).toEqual([]);
                    async.done();
                });
            }));
            testing_internal_1.it('should support updating host element via hostAttributes', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<div update-host-attributes></div>',
                    directives: [DirectiveUpdatingHostAttributes]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.detectChanges();
                    testing_internal_1.expect(dom_adapter_1.DOM.getAttribute(fixture.debugElement.children[0].nativeElement, "role"))
                        .toEqual("button");
                    async.done();
                });
            }));
            testing_internal_1.it('should support updating host element via hostProperties', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<div update-host-properties></div>',
                    directives: [DirectiveUpdatingHostProperties]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var tc = fixture.debugElement.children[0];
                    var updateHost = tc.inject(DirectiveUpdatingHostProperties);
                    updateHost.id = "newId";
                    fixture.detectChanges();
                    testing_internal_1.expect(tc.nativeElement.id).toEqual("newId");
                    async.done();
                });
            }));
            if (dom_adapter_1.DOM.supportsDOMEvents()) {
                testing_internal_1.it('should support preventing default on render events', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<input type="checkbox" listenerprevent><input type="checkbox" listenernoprevent>',
                        directives: [
                            DirectiveListeningDomEventPrevent,
                            DirectiveListeningDomEventNoPrevent
                        ]
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        var dispatchedEvent = dom_adapter_1.DOM.createMouseEvent('click');
                        var dispatchedEvent2 = dom_adapter_1.DOM.createMouseEvent('click');
                        dom_adapter_1.DOM.dispatchEvent(fixture.debugElement.children[0].nativeElement, dispatchedEvent);
                        dom_adapter_1.DOM.dispatchEvent(fixture.debugElement.children[1].nativeElement, dispatchedEvent2);
                        testing_internal_1.expect(dom_adapter_1.DOM.isPrevented(dispatchedEvent)).toBe(true);
                        testing_internal_1.expect(dom_adapter_1.DOM.isPrevented(dispatchedEvent2)).toBe(false);
                        testing_internal_1.expect(dom_adapter_1.DOM.getChecked(fixture.debugElement.children[0].nativeElement))
                            .toBeFalsy();
                        testing_internal_1.expect(dom_adapter_1.DOM.getChecked(fixture.debugElement.children[1].nativeElement))
                            .toBeTruthy();
                        async.done();
                    });
                }));
            }
            testing_internal_1.it('should support render global events from multiple directives', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<div *ngIf="ctxBoolProp" listener listenerother></div>',
                    directives: [common_1.NgIf, DirectiveListeningDomEvent, DirectiveListeningDomEventOther]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    globalCounter = 0;
                    fixture.debugElement.componentInstance.ctxBoolProp = true;
                    fixture.detectChanges();
                    var tc = fixture.debugElement.children[0];
                    var listener = tc.inject(DirectiveListeningDomEvent);
                    var listenerother = tc.inject(DirectiveListeningDomEventOther);
                    testing_internal_1.dispatchEvent(dom_adapter_1.DOM.getGlobalEventTarget("window"), 'domEvent');
                    testing_internal_1.expect(listener.eventTypes).toEqual(['window_domEvent']);
                    testing_internal_1.expect(listenerother.eventType).toEqual('other_domEvent');
                    testing_internal_1.expect(globalCounter).toEqual(1);
                    fixture.debugElement.componentInstance.ctxBoolProp = false;
                    fixture.detectChanges();
                    testing_internal_1.dispatchEvent(dom_adapter_1.DOM.getGlobalEventTarget("window"), 'domEvent');
                    testing_internal_1.expect(globalCounter).toEqual(1);
                    fixture.debugElement.componentInstance.ctxBoolProp = true;
                    fixture.detectChanges();
                    testing_internal_1.dispatchEvent(dom_adapter_1.DOM.getGlobalEventTarget("window"), 'domEvent');
                    testing_internal_1.expect(globalCounter).toEqual(2);
                    // need to destroy to release all remaining global event listeners
                    fixture.destroy();
                    async.done();
                });
            }));
            testing_internal_1.describe('dynamic ViewContainers', function () {
                testing_internal_1.it('should allow to create a ViewContainerRef at any bound location', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter, compiler_1.Compiler], function (tcb, async, compiler) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<div><dynamic-vp #dynamic></dynamic-vp></div>',
                        directives: [DynamicViewport]
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        var tc = fixture.debugElement.children[0].children[0];
                        var dynamicVp = tc.inject(DynamicViewport);
                        dynamicVp.done.then(function (_) {
                            fixture.detectChanges();
                            testing_internal_1.expect(fixture.debugElement.children[0].children[1].nativeElement)
                                .toHaveText('dynamic greet');
                            async.done();
                        });
                    });
                }));
            });
            testing_internal_1.it('should support static attributes', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<input static type="text" title>', directives: [NeedsAttribute] }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var tc = fixture.debugElement.children[0];
                    var needsAttribute = tc.inject(NeedsAttribute);
                    testing_internal_1.expect(needsAttribute.typeAttribute).toEqual('text');
                    testing_internal_1.expect(needsAttribute.staticAttribute).toEqual('');
                    testing_internal_1.expect(needsAttribute.fooAttribute).toEqual(null);
                    async.done();
                });
            }));
        });
        testing_internal_1.describe("dependency injection", function () {
            testing_internal_1.it("should support bindings", testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: "\n            <directive-providing-injectable >\n              <directive-consuming-injectable #consuming>\n              </directive-consuming-injectable>\n            </directive-providing-injectable>\n          ",
                    directives: [DirectiveProvidingInjectable, DirectiveConsumingInjectable]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var comp = fixture.debugElement.children[0].getLocal("consuming");
                    testing_internal_1.expect(comp.injectable).toBeAnInstanceOf(InjectableService);
                    async.done();
                });
            }));
            testing_internal_1.it("should support viewProviders", testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(DirectiveProvidingInjectableInView, new metadata_1.ViewMetadata({
                    template: "\n              <directive-consuming-injectable #consuming>\n              </directive-consuming-injectable>\n          ",
                    directives: [DirectiveConsumingInjectable]
                }))
                    .createAsync(DirectiveProvidingInjectableInView)
                    .then(function (fixture) {
                    var comp = fixture.debugElement.children[0].getLocal("consuming");
                    testing_internal_1.expect(comp.injectable).toBeAnInstanceOf(InjectableService);
                    async.done();
                });
            }));
            testing_internal_1.it("should support unbounded lookup", testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: "\n            <directive-providing-injectable>\n              <directive-containing-directive-consuming-an-injectable #dir>\n              </directive-containing-directive-consuming-an-injectable>\n            </directive-providing-injectable>\n          ",
                    directives: [
                        DirectiveProvidingInjectable,
                        DirectiveContainingDirectiveConsumingAnInjectable
                    ]
                }))
                    .overrideView(DirectiveContainingDirectiveConsumingAnInjectable, new metadata_1.ViewMetadata({
                    template: "\n            <directive-consuming-injectable-unbounded></directive-consuming-injectable-unbounded>\n          ",
                    directives: [DirectiveConsumingInjectableUnbounded]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var comp = fixture.debugElement.children[0].getLocal("dir");
                    testing_internal_1.expect(comp.directive.injectable).toBeAnInstanceOf(InjectableService);
                    async.done();
                });
            }));
            testing_internal_1.it("should support the event-bus scenario", testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: "\n            <grand-parent-providing-event-bus>\n              <parent-providing-event-bus>\n                <child-consuming-event-bus>\n                </child-consuming-event-bus>\n              </parent-providing-event-bus>\n            </grand-parent-providing-event-bus>\n          ",
                    directives: [
                        GrandParentProvidingEventBus,
                        ParentProvidingEventBus,
                        ChildConsumingEventBus
                    ]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var gpComp = fixture.debugElement.children[0];
                    var parentComp = gpComp.children[0];
                    var childComp = parentComp.children[0];
                    var grandParent = gpComp.inject(GrandParentProvidingEventBus);
                    var parent = parentComp.inject(ParentProvidingEventBus);
                    var child = childComp.inject(ChildConsumingEventBus);
                    testing_internal_1.expect(grandParent.bus.name).toEqual("grandparent");
                    testing_internal_1.expect(parent.bus.name).toEqual("parent");
                    testing_internal_1.expect(parent.grandParentBus).toBe(grandParent.bus);
                    testing_internal_1.expect(child.bus).toBe(parent.bus);
                    async.done();
                });
            }));
            testing_internal_1.it("should instantiate bindings lazily", testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: "\n              <component-providing-logging-injectable #providing>\n                <directive-consuming-injectable *ngIf=\"ctxBoolProp\">\n                </directive-consuming-injectable>\n              </component-providing-logging-injectable>\n          ",
                    directives: [DirectiveConsumingInjectable, ComponentProvidingLoggingInjectable, common_1.NgIf]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    var providing = fixture.debugElement.children[0].getLocal("providing");
                    testing_internal_1.expect(providing.created).toBe(false);
                    fixture.debugElement.componentInstance.ctxBoolProp = true;
                    fixture.detectChanges();
                    testing_internal_1.expect(providing.created).toBe(true);
                    async.done();
                });
            }));
        });
        testing_internal_1.describe("corner cases", function () {
            testing_internal_1.it('should remove script tags from templates', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: "\n            <script>alert(\"Ooops\");</script>\n            <div>before<script>alert(\"Ooops\");</script><span>inside</span>after</div>"
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    testing_internal_1.expect(dom_adapter_1.DOM.querySelectorAll(fixture.debugElement.nativeElement, 'script').length)
                        .toEqual(0);
                    async.done();
                });
            }));
        });
        testing_internal_1.describe("error handling", function () {
            testing_internal_1.it('should report a meaningful error when a directive is missing annotation', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb = tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '', directives: [SomeDirectiveMissingAnnotation] }));
                async_1.PromiseWrapper.catchError(tcb.createAsync(MyComp), function (e) {
                    testing_internal_1.expect(e.message).toEqual("No Directive annotation found on " + lang_1.stringify(SomeDirectiveMissingAnnotation));
                    async.done();
                    return null;
                });
            }));
            testing_internal_1.it('should report a meaningful error when a component is missing view annotation', testing_internal_1.inject([testing_internal_1.TestComponentBuilder], function (tcb) {
                try {
                    tcb.createAsync(ComponentWithoutView);
                }
                catch (e) {
                    testing_internal_1.expect(e.message).toContain("must have either 'template' or 'templateUrl' set.");
                    return null;
                }
            }));
            testing_internal_1.it('should report a meaningful error when a directive is null', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb = tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ directives: [[null]], template: '' }));
                async_1.PromiseWrapper.catchError(tcb.createAsync(MyComp), function (e) {
                    testing_internal_1.expect(e.message).toEqual("Unexpected directive value 'null' on the View of component '" + lang_1.stringify(MyComp) + "'");
                    async.done();
                    return null;
                });
            }));
            testing_internal_1.it('should provide an error context when an error happens in DI', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb =
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        directives: [DirectiveThrowingAnError],
                        template: "<directive-throwing-error></directive-throwing-error>"
                    }));
                async_1.PromiseWrapper.catchError(tcb.createAsync(MyComp), function (e) {
                    var c = e.context;
                    testing_internal_1.expect(dom_adapter_1.DOM.nodeName(c.element).toUpperCase()).toEqual("DIRECTIVE-THROWING-ERROR");
                    testing_internal_1.expect(dom_adapter_1.DOM.nodeName(c.componentElement).toUpperCase()).toEqual("DIV");
                    testing_internal_1.expect(c.injector).toBeAnInstanceOf(core_1.Injector);
                    async.done();
                    return null;
                });
            }));
            testing_internal_1.it('should provide an error context when an error happens in change detection', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb = tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: "<input [value]=\"one.two.three\" #local>" }));
                tcb.createAsync(MyComp).then(function (fixture) {
                    try {
                        fixture.detectChanges();
                        throw "Should throw";
                    }
                    catch (e) {
                        var c = e.context;
                        testing_internal_1.expect(dom_adapter_1.DOM.nodeName(c.element).toUpperCase()).toEqual("INPUT");
                        testing_internal_1.expect(dom_adapter_1.DOM.nodeName(c.componentElement).toUpperCase()).toEqual("DIV");
                        testing_internal_1.expect(c.injector).toBeAnInstanceOf(core_1.Injector);
                        testing_internal_1.expect(c.expression).toContain("one.two.three");
                        testing_internal_1.expect(c.context).toBe(fixture.debugElement.componentInstance);
                        testing_internal_1.expect(c.locals["local"]).toBeDefined();
                    }
                    async.done();
                });
            }));
            testing_internal_1.it('should provide an error context when an error happens in change detection (text node)', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb = tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: "{{one.two.three}}" }));
                tcb.createAsync(MyComp).then(function (fixture) {
                    try {
                        fixture.detectChanges();
                        throw "Should throw";
                    }
                    catch (e) {
                        var c = e.context;
                        testing_internal_1.expect(c.element).toBeNull();
                        testing_internal_1.expect(c.injector).toBeNull();
                    }
                    async.done();
                });
            }));
            if (dom_adapter_1.DOM.supportsDOMEvents()) {
                testing_internal_1.it('should provide an error context when an error happens in an event handler', testing_internal_1.inject([testing_internal_1.TestComponentBuilder], testing_internal_1.fakeAsync(function (tcb) {
                    tcb = tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: "<span emitter listener (event)=\"throwError()\" #local></span>",
                        directives: [DirectiveEmittingEvent, DirectiveListeningEvent]
                    }));
                    var fixture;
                    tcb.createAsync(MyComp).then(function (root) { fixture = root; });
                    testing_internal_1.tick();
                    var tc = fixture.debugElement.children[0];
                    tc.inject(DirectiveEmittingEvent).fireEvent("boom");
                    try {
                        testing_internal_1.tick();
                        throw "Should throw";
                    }
                    catch (e) {
                        testing_internal_1.clearPendingTimers();
                        var c = e.context;
                        testing_internal_1.expect(dom_adapter_1.DOM.nodeName(c.element).toUpperCase()).toEqual("SPAN");
                        testing_internal_1.expect(dom_adapter_1.DOM.nodeName(c.componentElement).toUpperCase()).toEqual("DIV");
                        testing_internal_1.expect(c.injector).toBeAnInstanceOf(core_1.Injector);
                        testing_internal_1.expect(c.context).toBe(fixture.debugElement.componentInstance);
                        testing_internal_1.expect(c.locals["local"]).toBeDefined();
                    }
                })));
            }
            if (!lang_2.IS_DART) {
                testing_internal_1.it('should report a meaningful error when a directive is undefined', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    var undefinedValue;
                    tcb = tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ directives: [undefinedValue], template: '' }));
                    async_1.PromiseWrapper.catchError(tcb.createAsync(MyComp), function (e) {
                        testing_internal_1.expect(e.message).toEqual("Unexpected directive value 'undefined' on the View of component '" + lang_1.stringify(MyComp) + "'");
                        async.done();
                        return null;
                    });
                }));
            }
            testing_internal_1.it('should specify a location of an error that happened during change detection (text)', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '{{a.b}}' }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    testing_internal_1.expect(function () { return fixture.detectChanges(); })
                        .toThrowError(testing_internal_1.containsRegexp("{{a.b}} in " + lang_1.stringify(MyComp)));
                    async.done();
                });
            }));
            testing_internal_1.it('should specify a location of an error that happened during change detection (element property)', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div [title]="a.b"></div>' }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    testing_internal_1.expect(function () { return fixture.detectChanges(); })
                        .toThrowError(testing_internal_1.containsRegexp("a.b in " + lang_1.stringify(MyComp)));
                    async.done();
                });
            }));
            testing_internal_1.it('should specify a location of an error that happened during change detection (directive property)', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<child-cmp [title]="a.b"></child-cmp>',
                    directives: [ChildComp]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    testing_internal_1.expect(function () { return fixture.detectChanges(); })
                        .toThrowError(testing_internal_1.containsRegexp("a.b in " + lang_1.stringify(MyComp)));
                    async.done();
                });
            }));
        });
        testing_internal_1.it('should support imperative views', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                template: '<simple-imp-cmp></simple-imp-cmp>',
                directives: [SimpleImperativeViewComponent]
            }))
                .createAsync(MyComp)
                .then(function (fixture) {
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('hello imp view');
                async.done();
            });
        }));
        testing_internal_1.it('should support moving embedded views around', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter, ANCHOR_ELEMENT], function (tcb, async, anchorElement) {
            tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                template: '<div><div *someImpvp="ctxBoolProp">hello</div></div>',
                directives: [SomeImperativeViewport]
            }))
                .createAsync(MyComp)
                .then(function (fixture) {
                fixture.detectChanges();
                testing_internal_1.expect(anchorElement).toHaveText('');
                fixture.debugElement.componentInstance.ctxBoolProp = true;
                fixture.detectChanges();
                testing_internal_1.expect(anchorElement).toHaveText('hello');
                fixture.debugElement.componentInstance.ctxBoolProp = false;
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('');
                async.done();
            });
        }));
        testing_internal_1.describe('Property bindings', function () {
            if (!lang_2.IS_DART) {
                testing_internal_1.it('should throw on bindings to unknown properties', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb =
                        tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div unknown="{{ctxProp}}"></div>' }));
                    async_1.PromiseWrapper.catchError(tcb.createAsync(MyComp), function (e) {
                        testing_internal_1.expect(e.message).toEqual("Template parse errors:\nCan't bind to 'unknown' since it isn't a known native property (\"<div [ERROR ->]unknown=\"{{ctxProp}}\"></div>\"): MyComp@0:5");
                        async.done();
                        return null;
                    });
                }));
                testing_internal_1.it('should not throw for property binding to a non-existing property when there is a matching directive property', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div my-dir [elprop]="ctxProp"></div>', directives: [MyDir] }))
                        .createAsync(MyComp)
                        .then(function (val) { async.done(); });
                }));
            }
            testing_internal_1.it('should not be created when there is a directive with the same property', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<span [title]="ctxProp"></span>',
                    directives: [DirectiveWithTitle]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.ctxProp = "TITLE";
                    fixture.detectChanges();
                    var el = dom_adapter_1.DOM.querySelector(fixture.debugElement.nativeElement, "span");
                    testing_internal_1.expect(lang_1.isBlank(el.title) || el.title == '').toBeTruthy();
                    async.done();
                });
            }));
            testing_internal_1.it('should work when a directive uses hostProperty to update the DOM element', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<span [title]="ctxProp"></span>',
                    directives: [DirectiveWithTitleAndHostProperty]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.ctxProp = "TITLE";
                    fixture.detectChanges();
                    var el = dom_adapter_1.DOM.querySelector(fixture.debugElement.nativeElement, "span");
                    testing_internal_1.expect(el.title).toEqual("TITLE");
                    async.done();
                });
            }));
        });
        testing_internal_1.describe('logging property updates', function () {
            testing_internal_1.beforeEachProviders(function () { return [
                core_1.provide(change_detection_1.ChangeDetectorGenConfig, { useValue: new change_detection_1.ChangeDetectorGenConfig(true, true, false) })
            ]; });
            testing_internal_1.it('should reflect property values as attributes', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var tpl = '<div>' +
                    '<div my-dir [elprop]="ctxProp"></div>' +
                    '</div>';
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: tpl, directives: [MyDir] }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.ctxProp = 'hello';
                    fixture.detectChanges();
                    testing_internal_1.expect(dom_adapter_1.DOM.getInnerHTML(fixture.debugElement.nativeElement))
                        .toContain('ng-reflect-dir-prop="hello"');
                    async.done();
                });
            }));
            testing_internal_1.it('should reflect property values on template comments', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var tpl = '<template [ngIf]="ctxBoolProp"></template>';
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: tpl, directives: [common_1.NgIf] }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.ctxBoolProp = true;
                    fixture.detectChanges();
                    testing_internal_1.expect(dom_adapter_1.DOM.getInnerHTML(fixture.debugElement.nativeElement))
                        .toContain('"ng\-reflect\-ng\-if"\: "true"');
                    async.done();
                });
            }));
        });
        testing_internal_1.describe('different proto view storages', function () {
            function runWithMode(mode) {
                return testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: "<!--" + mode + "--><div>{{ctxProp}}</div>" }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        fixture.debugElement.componentInstance.ctxProp = 'Hello World!';
                        fixture.detectChanges();
                        testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('Hello World!');
                        async.done();
                    });
                });
            }
            testing_internal_1.it('should work with storing DOM nodes', runWithMode('cache'));
            testing_internal_1.it('should work with serializing the DOM nodes', runWithMode('nocache'));
        });
        // Disabled until a solution is found, refs:
        // - https://github.com/angular/angular/issues/776
        // - https://github.com/angular/angular/commit/81f3f32
        testing_internal_1.xdescribe('Missing directive checks', function () {
            function expectCompileError(tcb, inlineTpl, errMessage, done) {
                tcb = tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: inlineTpl }));
                async_1.PromiseWrapper.then(tcb.createAsync(MyComp), function (value) {
                    throw new exceptions_1.BaseException("Test failure: should not have come here as an exception was expected");
                }, function (err) {
                    testing_internal_1.expect(err.message).toEqual(errMessage);
                    done();
                });
            }
            if (lang_1.assertionsEnabled()) {
                testing_internal_1.it('should raise an error if no directive is registered for a template with template bindings', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    expectCompileError(tcb, '<div><div template="if: foo"></div></div>', 'Missing directive to handle \'if\' in <div template="if: foo">', function () { return async.done(); });
                }));
                testing_internal_1.it('should raise an error for missing template directive (1)', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    expectCompileError(tcb, '<div><template foo></template></div>', 'Missing directive to handle: <template foo>', function () { return async.done(); });
                }));
                testing_internal_1.it('should raise an error for missing template directive (2)', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    expectCompileError(tcb, '<div><template *ngIf="condition"></template></div>', 'Missing directive to handle: <template *ngIf="condition">', function () { return async.done(); });
                }));
                testing_internal_1.it('should raise an error for missing template directive (3)', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    expectCompileError(tcb, '<div *ngIf="condition"></div>', 'Missing directive to handle \'if\' in MyComp: <div *ngIf="condition">', function () { return async.done(); });
                }));
            }
        });
        testing_internal_1.describe('property decorators', function () {
            testing_internal_1.it('should support property decorators', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<with-prop-decorators elProp="aaa"></with-prop-decorators>',
                    directives: [DirectiveWithPropDecorators]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.detectChanges();
                    var dir = fixture.debugElement.children[0].inject(DirectiveWithPropDecorators);
                    testing_internal_1.expect(dir.dirProp).toEqual("aaa");
                    async.done();
                });
            }));
            testing_internal_1.it('should support host binding decorators', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<with-prop-decorators></with-prop-decorators>',
                    directives: [DirectiveWithPropDecorators]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.detectChanges();
                    var dir = fixture.debugElement.children[0].inject(DirectiveWithPropDecorators);
                    dir.myAttr = "aaa";
                    fixture.detectChanges();
                    testing_internal_1.expect(dom_adapter_1.DOM.getOuterHTML(fixture.debugElement.children[0].nativeElement))
                        .toContain('my-attr="aaa"');
                    async.done();
                });
            }));
            if (dom_adapter_1.DOM.supportsDOMEvents()) {
                testing_internal_1.it('should support event decorators', testing_internal_1.inject([testing_internal_1.TestComponentBuilder], testing_internal_1.fakeAsync(function (tcb) {
                    tcb = tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: "<with-prop-decorators (elEvent)=\"ctxProp='called'\">",
                        directives: [DirectiveWithPropDecorators]
                    }));
                    var fixture;
                    tcb.createAsync(MyComp).then(function (root) { fixture = root; });
                    testing_internal_1.tick();
                    var emitter = fixture.debugElement.children[0].inject(DirectiveWithPropDecorators);
                    emitter.fireEvent('fired !');
                    testing_internal_1.tick();
                    testing_internal_1.expect(fixture.debugElement.componentInstance.ctxProp).toEqual("called");
                })));
                testing_internal_1.it('should support host listener decorators', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                        template: '<with-prop-decorators></with-prop-decorators>',
                        directives: [DirectiveWithPropDecorators]
                    }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        fixture.detectChanges();
                        var dir = fixture.debugElement.children[0].inject(DirectiveWithPropDecorators);
                        var native = fixture.debugElement.children[0].nativeElement;
                        dom_adapter_1.DOM.dispatchEvent(native, dom_adapter_1.DOM.createMouseEvent('click'));
                        testing_internal_1.expect(dir.target).toBe(native);
                        async.done();
                    });
                }));
            }
            testing_internal_1.it('should support defining views in the component decorator', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.overrideView(MyComp, new metadata_1.ViewMetadata({
                    template: '<component-with-template></component-with-template>',
                    directives: [ComponentWithTemplate]
                }))
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.detectChanges();
                    var native = fixture.debugElement.children[0].nativeElement;
                    testing_internal_1.expect(native).toHaveText("No View Decorator: 123");
                    async.done();
                });
            }));
        });
        if (dom_adapter_1.DOM.supportsDOMEvents()) {
            testing_internal_1.describe('svg', function () {
                testing_internal_1.it('should support svg elements', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<svg><use xlink:href="Port" /></svg>' }))
                        .createAsync(MyComp)
                        .then(function (fixture) {
                        var el = fixture.debugElement.nativeElement;
                        var svg = dom_adapter_1.DOM.childNodes(el)[0];
                        var use = dom_adapter_1.DOM.childNodes(svg)[0];
                        testing_internal_1.expect(dom_adapter_1.DOM.getProperty(svg, 'namespaceURI'))
                            .toEqual('http://www.w3.org/2000/svg');
                        testing_internal_1.expect(dom_adapter_1.DOM.getProperty(use, 'namespaceURI'))
                            .toEqual('http://www.w3.org/2000/svg');
                        if (!lang_2.IS_DART) {
                            var firstAttribute = dom_adapter_1.DOM.getProperty(use, 'attributes')[0];
                            testing_internal_1.expect(firstAttribute.name).toEqual('xlink:href');
                            testing_internal_1.expect(firstAttribute.namespaceURI).toEqual('http://www.w3.org/1999/xlink');
                        }
                        else {
                            // For Dart where '_Attr' has no instance getter 'namespaceURI'
                            testing_internal_1.expect(dom_adapter_1.DOM.getOuterHTML(use)).toContain('xmlns:xlink');
                        }
                        async.done();
                    });
                }));
            });
            testing_internal_1.describe('attributes', function () {
                testing_internal_1.it('should support attributes with namespace', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(SomeCmp, new metadata_1.ViewMetadata({ template: '<svg:use xlink:href="#id" />' }))
                        .createAsync(SomeCmp)
                        .then(function (fixture) {
                        var useEl = dom_adapter_1.DOM.firstChild(fixture.debugElement.nativeElement);
                        testing_internal_1.expect(dom_adapter_1.DOM.getAttributeNS(useEl, 'http://www.w3.org/1999/xlink', 'href'))
                            .toEqual('#id');
                        async.done();
                    });
                }));
                testing_internal_1.it('should support binding to attributes with namespace', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                    tcb.overrideView(SomeCmp, new metadata_1.ViewMetadata({ template: '<svg:use [attr.xlink:href]="value" />' }))
                        .createAsync(SomeCmp)
                        .then(function (fixture) {
                        var cmp = fixture.debugElement.componentInstance;
                        var useEl = dom_adapter_1.DOM.firstChild(fixture.debugElement.nativeElement);
                        cmp.value = "#id";
                        fixture.detectChanges();
                        testing_internal_1.expect(dom_adapter_1.DOM.getAttributeNS(useEl, 'http://www.w3.org/1999/xlink', 'href'))
                            .toEqual('#id');
                        cmp.value = null;
                        fixture.detectChanges();
                        testing_internal_1.expect(dom_adapter_1.DOM.hasAttributeNS(useEl, 'http://www.w3.org/1999/xlink', 'href'))
                            .toEqual(false);
                        async.done();
                    });
                }));
            });
        }
    });
}
var MyService = (function () {
    function MyService() {
        this.greeting = 'hello';
    }
    MyService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], MyService);
    return MyService;
})();
var SimpleImperativeViewComponent = (function () {
    function SimpleImperativeViewComponent(self, renderer) {
        var hostElement = self.nativeElement;
        dom_adapter_1.DOM.appendChild(hostElement, testing_internal_1.el('hello imp view'));
    }
    SimpleImperativeViewComponent = __decorate([
        metadata_1.Component({ selector: 'simple-imp-cmp', template: '' }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [element_ref_1.ElementRef, render_1.Renderer])
    ], SimpleImperativeViewComponent);
    return SimpleImperativeViewComponent;
})();
var DynamicViewport = (function () {
    function DynamicViewport(vc, compiler) {
        var myService = new MyService();
        myService.greeting = 'dynamic greet';
        var bindings = core_1.Injector.resolve([core_1.provide(MyService, { useValue: myService })]);
        this.done = compiler.compileInHost(ChildCompUsingService)
            .then(function (hostPv) { vc.createHostView(hostPv, 0, bindings); });
    }
    DynamicViewport = __decorate([
        metadata_1.Directive({ selector: 'dynamic-vp' }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [view_container_ref_1.ViewContainerRef, compiler_1.Compiler])
    ], DynamicViewport);
    return DynamicViewport;
})();
var MyDir = (function () {
    function MyDir() {
        this.dirProp = '';
    }
    MyDir = __decorate([
        metadata_1.Directive({ selector: '[my-dir]', inputs: ['dirProp: elprop'], exportAs: 'mydir' }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], MyDir);
    return MyDir;
})();
var DirectiveWithTitle = (function () {
    function DirectiveWithTitle() {
    }
    DirectiveWithTitle = __decorate([
        metadata_1.Directive({ selector: '[title]', inputs: ['title'] }), 
        __metadata('design:paramtypes', [])
    ], DirectiveWithTitle);
    return DirectiveWithTitle;
})();
var DirectiveWithTitleAndHostProperty = (function () {
    function DirectiveWithTitleAndHostProperty() {
    }
    DirectiveWithTitleAndHostProperty = __decorate([
        metadata_1.Directive({ selector: '[title]', inputs: ['title'], host: { '[title]': 'title' } }), 
        __metadata('design:paramtypes', [])
    ], DirectiveWithTitleAndHostProperty);
    return DirectiveWithTitleAndHostProperty;
})();
var PushCmp = (function () {
    function PushCmp() {
        this.numberOfChecks = 0;
    }
    Object.defineProperty(PushCmp.prototype, "field", {
        get: function () {
            this.numberOfChecks++;
            return "fixed";
        },
        enumerable: true,
        configurable: true
    });
    PushCmp = __decorate([
        metadata_1.Component({
            selector: 'push-cmp',
            inputs: ['prop'],
            changeDetection: change_detection_1.ChangeDetectionStrategy.OnPush,
            template: '{{field}}'
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], PushCmp);
    return PushCmp;
})();
var PushCmpWithRef = (function () {
    function PushCmpWithRef(ref) {
        this.numberOfChecks = 0;
        this.ref = ref;
    }
    Object.defineProperty(PushCmpWithRef.prototype, "field", {
        get: function () {
            this.numberOfChecks++;
            return "fixed";
        },
        enumerable: true,
        configurable: true
    });
    PushCmpWithRef.prototype.propagate = function () { this.ref.markForCheck(); };
    PushCmpWithRef = __decorate([
        metadata_1.Component({
            selector: 'push-cmp-with-ref',
            inputs: ['prop'],
            changeDetection: change_detection_1.ChangeDetectionStrategy.OnPush,
            template: '{{field}}'
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [change_detection_1.ChangeDetectorRef])
    ], PushCmpWithRef);
    return PushCmpWithRef;
})();
var PushCmpWithHostEvent = (function () {
    function PushCmpWithHostEvent() {
        this.ctxCallback = function (_) { };
    }
    PushCmpWithHostEvent = __decorate([
        metadata_1.Component({
            selector: 'push-cmp-with-host-event',
            host: { '(click)': 'ctxCallback($event)' },
            changeDetection: change_detection_1.ChangeDetectionStrategy.OnPush,
            template: ''
        }), 
        __metadata('design:paramtypes', [])
    ], PushCmpWithHostEvent);
    return PushCmpWithHostEvent;
})();
var PushCmpWithAsyncPipe = (function () {
    function PushCmpWithAsyncPipe() {
        this.numberOfChecks = 0;
        this.completer = async_1.PromiseWrapper.completer();
        this.promise = this.completer.promise;
    }
    Object.defineProperty(PushCmpWithAsyncPipe.prototype, "field", {
        get: function () {
            this.numberOfChecks++;
            return this.promise;
        },
        enumerable: true,
        configurable: true
    });
    PushCmpWithAsyncPipe.prototype.resolve = function (value) { this.completer.resolve(value); };
    PushCmpWithAsyncPipe = __decorate([
        metadata_1.Component({
            selector: 'push-cmp-with-async',
            changeDetection: change_detection_1.ChangeDetectionStrategy.OnPush,
            template: '{{field | async}}',
            pipes: [common_2.AsyncPipe]
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], PushCmpWithAsyncPipe);
    return PushCmpWithAsyncPipe;
})();
var MyComp = (function () {
    function MyComp() {
        this.ctxProp = 'initial value';
        this.ctxNumProp = 0;
        this.ctxBoolProp = false;
    }
    MyComp.prototype.throwError = function () { throw 'boom'; };
    MyComp = __decorate([
        metadata_1.Component({ selector: 'my-comp', directives: [] }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], MyComp);
    return MyComp;
})();
var ChildComp = (function () {
    function ChildComp(service) {
        this.ctxProp = service.greeting;
        this.dirProp = null;
    }
    ChildComp = __decorate([
        metadata_1.Component({
            selector: 'child-cmp',
            inputs: ['dirProp'],
            viewProviders: [MyService],
            directives: [MyDir],
            template: '{{ctxProp}}'
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [MyService])
    ], ChildComp);
    return ChildComp;
})();
var ChildCompNoTemplate = (function () {
    function ChildCompNoTemplate() {
        this.ctxProp = 'hello';
    }
    ChildCompNoTemplate = __decorate([
        metadata_1.Component({ selector: 'child-cmp-no-template', directives: [], template: '' }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], ChildCompNoTemplate);
    return ChildCompNoTemplate;
})();
var ChildCompUsingService = (function () {
    function ChildCompUsingService(service) {
        this.ctxProp = service.greeting;
    }
    ChildCompUsingService = __decorate([
        metadata_1.Component({ selector: 'child-cmp-svc', template: '{{ctxProp}}' }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [MyService])
    ], ChildCompUsingService);
    return ChildCompUsingService;
})();
var SomeDirective = (function () {
    function SomeDirective() {
    }
    SomeDirective = __decorate([
        metadata_1.Directive({ selector: 'some-directive' }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], SomeDirective);
    return SomeDirective;
})();
var SomeDirectiveMissingAnnotation = (function () {
    function SomeDirectiveMissingAnnotation() {
    }
    return SomeDirectiveMissingAnnotation;
})();
var CompWithHost = (function () {
    function CompWithHost(someComp) {
        this.myHost = someComp;
    }
    CompWithHost = __decorate([
        metadata_1.Component({
            selector: 'cmp-with-host',
            template: '<p>Component with an injected host</p>',
            directives: [SomeDirective]
        }),
        core_1.Injectable(),
        __param(0, core_1.Host()), 
        __metadata('design:paramtypes', [SomeDirective])
    ], CompWithHost);
    return CompWithHost;
})();
var ChildComp2 = (function () {
    function ChildComp2(service) {
        this.ctxProp = service.greeting;
        this.dirProp = null;
    }
    ChildComp2 = __decorate([
        metadata_1.Component({ selector: '[child-cmp2]', viewProviders: [MyService] }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [MyService])
    ], ChildComp2);
    return ChildComp2;
})();
var SomeViewport = (function () {
    function SomeViewport(container, templateRef) {
        container.createEmbeddedView(templateRef).setLocal('some-tmpl', 'hello');
        container.createEmbeddedView(templateRef).setLocal('some-tmpl', 'again');
    }
    SomeViewport = __decorate([
        metadata_1.Directive({ selector: '[some-viewport]' }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [view_container_ref_1.ViewContainerRef, template_ref_1.TemplateRef])
    ], SomeViewport);
    return SomeViewport;
})();
var DoublePipe = (function () {
    function DoublePipe() {
    }
    DoublePipe.prototype.ngOnDestroy = function () { };
    DoublePipe.prototype.transform = function (value, args) {
        if (args === void 0) { args = null; }
        return "" + value + value;
    };
    DoublePipe = __decorate([
        metadata_1.Pipe({ name: 'double' }), 
        __metadata('design:paramtypes', [])
    ], DoublePipe);
    return DoublePipe;
})();
var DirectiveEmittingEvent = (function () {
    function DirectiveEmittingEvent() {
        this.msg = '';
        this.event = new async_1.EventEmitter();
    }
    DirectiveEmittingEvent.prototype.fireEvent = function (msg) { async_1.ObservableWrapper.callEmit(this.event, msg); };
    DirectiveEmittingEvent = __decorate([
        metadata_1.Directive({ selector: '[emitter]', outputs: ['event'] }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DirectiveEmittingEvent);
    return DirectiveEmittingEvent;
})();
var DirectiveUpdatingHostAttributes = (function () {
    function DirectiveUpdatingHostAttributes() {
    }
    DirectiveUpdatingHostAttributes = __decorate([
        metadata_1.Directive({ selector: '[update-host-attributes]', host: { 'role': 'button' } }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DirectiveUpdatingHostAttributes);
    return DirectiveUpdatingHostAttributes;
})();
var DirectiveUpdatingHostProperties = (function () {
    function DirectiveUpdatingHostProperties() {
        this.id = "one";
    }
    DirectiveUpdatingHostProperties = __decorate([
        metadata_1.Directive({ selector: '[update-host-properties]', host: { '[id]': 'id' } }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DirectiveUpdatingHostProperties);
    return DirectiveUpdatingHostProperties;
})();
var DirectiveListeningEvent = (function () {
    function DirectiveListeningEvent() {
        this.msg = '';
    }
    DirectiveListeningEvent.prototype.onEvent = function (msg) { this.msg = msg; };
    DirectiveListeningEvent = __decorate([
        metadata_1.Directive({ selector: '[listener]', host: { '(event)': 'onEvent($event)' } }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DirectiveListeningEvent);
    return DirectiveListeningEvent;
})();
var DirectiveListeningDomEvent = (function () {
    function DirectiveListeningDomEvent() {
        this.eventTypes = [];
    }
    DirectiveListeningDomEvent.prototype.onEvent = function (eventType) { this.eventTypes.push(eventType); };
    DirectiveListeningDomEvent.prototype.onWindowEvent = function (eventType) { this.eventTypes.push("window_" + eventType); };
    DirectiveListeningDomEvent.prototype.onDocumentEvent = function (eventType) { this.eventTypes.push("document_" + eventType); };
    DirectiveListeningDomEvent.prototype.onBodyEvent = function (eventType) { this.eventTypes.push("body_" + eventType); };
    DirectiveListeningDomEvent = __decorate([
        metadata_1.Directive({
            selector: '[listener]',
            host: {
                '(domEvent)': 'onEvent($event.type)',
                '(window:domEvent)': 'onWindowEvent($event.type)',
                '(document:domEvent)': 'onDocumentEvent($event.type)',
                '(body:domEvent)': 'onBodyEvent($event.type)'
            }
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DirectiveListeningDomEvent);
    return DirectiveListeningDomEvent;
})();
var globalCounter = 0;
var DirectiveListeningDomEventOther = (function () {
    function DirectiveListeningDomEventOther() {
        this.eventType = '';
    }
    DirectiveListeningDomEventOther.prototype.onEvent = function (eventType) {
        globalCounter++;
        this.eventType = "other_" + eventType;
    };
    DirectiveListeningDomEventOther = __decorate([
        metadata_1.Directive({ selector: '[listenerother]', host: { '(window:domEvent)': 'onEvent($event.type)' } }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DirectiveListeningDomEventOther);
    return DirectiveListeningDomEventOther;
})();
var DirectiveListeningDomEventPrevent = (function () {
    function DirectiveListeningDomEventPrevent() {
    }
    DirectiveListeningDomEventPrevent.prototype.onEvent = function (event) { return false; };
    DirectiveListeningDomEventPrevent = __decorate([
        metadata_1.Directive({ selector: '[listenerprevent]', host: { '(click)': 'onEvent($event)' } }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DirectiveListeningDomEventPrevent);
    return DirectiveListeningDomEventPrevent;
})();
var DirectiveListeningDomEventNoPrevent = (function () {
    function DirectiveListeningDomEventNoPrevent() {
    }
    DirectiveListeningDomEventNoPrevent.prototype.onEvent = function (event) { return true; };
    DirectiveListeningDomEventNoPrevent = __decorate([
        metadata_1.Directive({ selector: '[listenernoprevent]', host: { '(click)': 'onEvent($event)' } }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DirectiveListeningDomEventNoPrevent);
    return DirectiveListeningDomEventNoPrevent;
})();
var IdDir = (function () {
    function IdDir() {
    }
    IdDir = __decorate([
        metadata_1.Directive({ selector: '[id]', inputs: ['id'] }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], IdDir);
    return IdDir;
})();
var EventDir = (function () {
    function EventDir() {
        this.customEvent = new async_1.EventEmitter();
    }
    EventDir.prototype.doSomething = function () { };
    __decorate([
        metadata_1.Output(), 
        __metadata('design:type', Object)
    ], EventDir.prototype, "customEvent", void 0);
    EventDir = __decorate([
        metadata_1.Directive({ selector: '[customEvent]' }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], EventDir);
    return EventDir;
})();
var NeedsAttribute = (function () {
    function NeedsAttribute(typeAttribute, staticAttribute, fooAttribute) {
        this.typeAttribute = typeAttribute;
        this.staticAttribute = staticAttribute;
        this.fooAttribute = fooAttribute;
    }
    NeedsAttribute = __decorate([
        metadata_1.Directive({ selector: '[static]' }),
        core_1.Injectable(),
        __param(0, metadata_1.Attribute('type')),
        __param(1, metadata_1.Attribute('static')),
        __param(2, metadata_1.Attribute('foo')), 
        __metadata('design:paramtypes', [String, String, String])
    ], NeedsAttribute);
    return NeedsAttribute;
})();
var PublicApi = (function () {
    function PublicApi() {
    }
    PublicApi = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], PublicApi);
    return PublicApi;
})();
var PrivateImpl = (function (_super) {
    __extends(PrivateImpl, _super);
    function PrivateImpl() {
        _super.apply(this, arguments);
    }
    PrivateImpl = __decorate([
        metadata_1.Directive({
            selector: '[public-api]',
            providers: [new core_1.Provider(PublicApi, { useExisting: PrivateImpl, deps: [] })]
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], PrivateImpl);
    return PrivateImpl;
})(PublicApi);
var NeedsPublicApi = (function () {
    function NeedsPublicApi(api) {
        testing_internal_1.expect(api instanceof PrivateImpl).toBe(true);
    }
    NeedsPublicApi = __decorate([
        metadata_1.Directive({ selector: '[needs-public-api]' }),
        core_1.Injectable(),
        __param(0, core_1.Host()), 
        __metadata('design:paramtypes', [PublicApi])
    ], NeedsPublicApi);
    return NeedsPublicApi;
})();
var ToolbarPart = (function () {
    function ToolbarPart(templateRef) {
        this.templateRef = templateRef;
    }
    ToolbarPart = __decorate([
        metadata_1.Directive({ selector: '[toolbarpart]' }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [template_ref_1.TemplateRef])
    ], ToolbarPart);
    return ToolbarPart;
})();
var ToolbarViewContainer = (function () {
    function ToolbarViewContainer(vc) {
        this.vc = vc;
    }
    Object.defineProperty(ToolbarViewContainer.prototype, "toolbarVc", {
        set: function (part) {
            var view = this.vc.createEmbeddedView(part.templateRef, 0);
            view.setLocal('toolbarProp', 'From toolbar');
        },
        enumerable: true,
        configurable: true
    });
    ToolbarViewContainer = __decorate([
        metadata_1.Directive({ selector: '[toolbarVc]', inputs: ['toolbarVc'] }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [view_container_ref_1.ViewContainerRef])
    ], ToolbarViewContainer);
    return ToolbarViewContainer;
})();
var ToolbarComponent = (function () {
    function ToolbarComponent(query) {
        this.ctxProp = 'hello world';
        this.query = query;
    }
    ToolbarComponent = __decorate([
        metadata_1.Component({
            selector: 'toolbar',
            template: 'TOOLBAR(<div *ngFor="var part of query" [toolbarVc]="part"></div>)',
            directives: [ToolbarViewContainer, common_1.NgFor]
        }),
        core_1.Injectable(),
        __param(0, metadata_1.Query(ToolbarPart)), 
        __metadata('design:paramtypes', [query_list_1.QueryList])
    ], ToolbarComponent);
    return ToolbarComponent;
})();
var DirectiveWithTwoWayBinding = (function () {
    function DirectiveWithTwoWayBinding() {
        this.controlChange = new async_1.EventEmitter();
        this.control = null;
    }
    DirectiveWithTwoWayBinding.prototype.triggerChange = function (value) { async_1.ObservableWrapper.callEmit(this.controlChange, value); };
    DirectiveWithTwoWayBinding = __decorate([
        metadata_1.Directive({ selector: '[two-way]', inputs: ['control'], outputs: ['controlChange'] }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DirectiveWithTwoWayBinding);
    return DirectiveWithTwoWayBinding;
})();
var InjectableService = (function () {
    function InjectableService() {
    }
    InjectableService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], InjectableService);
    return InjectableService;
})();
function createInjectableWithLogging(inj) {
    inj.get(ComponentProvidingLoggingInjectable).created = true;
    return new InjectableService();
}
var ComponentProvidingLoggingInjectable = (function () {
    function ComponentProvidingLoggingInjectable() {
        this.created = false;
    }
    ComponentProvidingLoggingInjectable = __decorate([
        metadata_1.Component({
            selector: 'component-providing-logging-injectable',
            providers: [
                new core_1.Provider(InjectableService, { useFactory: createInjectableWithLogging, deps: [core_1.Injector] })
            ],
            template: ''
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], ComponentProvidingLoggingInjectable);
    return ComponentProvidingLoggingInjectable;
})();
var DirectiveProvidingInjectable = (function () {
    function DirectiveProvidingInjectable() {
    }
    DirectiveProvidingInjectable = __decorate([
        metadata_1.Directive({ selector: 'directive-providing-injectable', providers: [[InjectableService]] }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DirectiveProvidingInjectable);
    return DirectiveProvidingInjectable;
})();
var DirectiveProvidingInjectableInView = (function () {
    function DirectiveProvidingInjectableInView() {
    }
    DirectiveProvidingInjectableInView = __decorate([
        metadata_1.Component({
            selector: 'directive-providing-injectable',
            viewProviders: [[InjectableService]],
            template: ''
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DirectiveProvidingInjectableInView);
    return DirectiveProvidingInjectableInView;
})();
var DirectiveProvidingInjectableInHostAndView = (function () {
    function DirectiveProvidingInjectableInHostAndView() {
    }
    DirectiveProvidingInjectableInHostAndView = __decorate([
        metadata_1.Component({
            selector: 'directive-providing-injectable',
            providers: [new core_1.Provider(InjectableService, { useValue: 'host' })],
            viewProviders: [new core_1.Provider(InjectableService, { useValue: 'view' })],
            template: ''
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DirectiveProvidingInjectableInHostAndView);
    return DirectiveProvidingInjectableInHostAndView;
})();
var DirectiveConsumingInjectable = (function () {
    function DirectiveConsumingInjectable(injectable) {
        this.injectable = injectable;
    }
    DirectiveConsumingInjectable = __decorate([
        metadata_1.Component({ selector: 'directive-consuming-injectable', template: '' }),
        core_1.Injectable(),
        __param(0, core_1.Host()),
        __param(0, core_1.Inject(InjectableService)), 
        __metadata('design:paramtypes', [Object])
    ], DirectiveConsumingInjectable);
    return DirectiveConsumingInjectable;
})();
var DirectiveContainingDirectiveConsumingAnInjectable = (function () {
    function DirectiveContainingDirectiveConsumingAnInjectable() {
    }
    DirectiveContainingDirectiveConsumingAnInjectable = __decorate([
        metadata_1.Component({ selector: 'directive-containing-directive-consuming-an-injectable' }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DirectiveContainingDirectiveConsumingAnInjectable);
    return DirectiveContainingDirectiveConsumingAnInjectable;
})();
var DirectiveConsumingInjectableUnbounded = (function () {
    function DirectiveConsumingInjectableUnbounded(injectable, parent) {
        this.injectable = injectable;
        parent.directive = this;
    }
    DirectiveConsumingInjectableUnbounded = __decorate([
        metadata_1.Component({ selector: 'directive-consuming-injectable-unbounded', template: '' }),
        core_1.Injectable(),
        __param(1, core_1.SkipSelf()), 
        __metadata('design:paramtypes', [InjectableService, DirectiveContainingDirectiveConsumingAnInjectable])
    ], DirectiveConsumingInjectableUnbounded);
    return DirectiveConsumingInjectableUnbounded;
})();
var EventBus = (function () {
    function EventBus(parentEventBus, name) {
        this.parentEventBus = parentEventBus;
        this.name = name;
    }
    EventBus = __decorate([
        lang_1.CONST(), 
        __metadata('design:paramtypes', [EventBus, String])
    ], EventBus);
    return EventBus;
})();
var GrandParentProvidingEventBus = (function () {
    function GrandParentProvidingEventBus(bus) {
        this.bus = bus;
    }
    GrandParentProvidingEventBus = __decorate([
        metadata_1.Directive({
            selector: 'grand-parent-providing-event-bus',
            providers: [new core_1.Provider(EventBus, { useValue: new EventBus(null, "grandparent") })]
        }), 
        __metadata('design:paramtypes', [EventBus])
    ], GrandParentProvidingEventBus);
    return GrandParentProvidingEventBus;
})();
function createParentBus(peb) {
    return new EventBus(peb, "parent");
}
var ParentProvidingEventBus = (function () {
    function ParentProvidingEventBus(bus, grandParentBus) {
        this.bus = bus;
        this.grandParentBus = grandParentBus;
    }
    ParentProvidingEventBus = __decorate([
        metadata_1.Component({
            selector: 'parent-providing-event-bus',
            providers: [
                new core_1.Provider(EventBus, { useFactory: createParentBus, deps: [[EventBus, new core_1.SkipSelfMetadata()]] })
            ],
            directives: [core_1.forwardRef(function () { return ChildConsumingEventBus; })],
            template: "\n    <child-consuming-event-bus></child-consuming-event-bus>\n  "
        }),
        __param(1, core_1.SkipSelf()), 
        __metadata('design:paramtypes', [EventBus, EventBus])
    ], ParentProvidingEventBus);
    return ParentProvidingEventBus;
})();
var ChildConsumingEventBus = (function () {
    function ChildConsumingEventBus(bus) {
        this.bus = bus;
    }
    ChildConsumingEventBus = __decorate([
        metadata_1.Directive({ selector: 'child-consuming-event-bus' }),
        __param(0, core_1.SkipSelf()), 
        __metadata('design:paramtypes', [EventBus])
    ], ChildConsumingEventBus);
    return ChildConsumingEventBus;
})();
var SomeImperativeViewport = (function () {
    function SomeImperativeViewport(vc, templateRef, anchor) {
        this.vc = vc;
        this.templateRef = templateRef;
        this.view = null;
        this.anchor = anchor;
    }
    Object.defineProperty(SomeImperativeViewport.prototype, "someImpvp", {
        set: function (value) {
            if (lang_1.isPresent(this.view)) {
                this.vc.clear();
                this.view = null;
            }
            if (value) {
                this.view = this.vc.createEmbeddedView(this.templateRef);
                var nodes = this.view.rootNodes;
                for (var i = 0; i < nodes.length; i++) {
                    dom_adapter_1.DOM.appendChild(this.anchor, nodes[i]);
                }
            }
        },
        enumerable: true,
        configurable: true
    });
    SomeImperativeViewport = __decorate([
        metadata_1.Directive({ selector: '[someImpvp]', inputs: ['someImpvp'] }),
        core_1.Injectable(),
        __param(2, core_1.Inject(ANCHOR_ELEMENT)), 
        __metadata('design:paramtypes', [view_container_ref_1.ViewContainerRef, template_ref_1.TemplateRef, Object])
    ], SomeImperativeViewport);
    return SomeImperativeViewport;
})();
var ExportDir = (function () {
    function ExportDir() {
    }
    ExportDir = __decorate([
        metadata_1.Directive({ selector: '[export-dir]', exportAs: 'dir' }), 
        __metadata('design:paramtypes', [])
    ], ExportDir);
    return ExportDir;
})();
var ComponentWithoutView = (function () {
    function ComponentWithoutView() {
    }
    ComponentWithoutView = __decorate([
        metadata_1.Component({ selector: 'comp' }), 
        __metadata('design:paramtypes', [])
    ], ComponentWithoutView);
    return ComponentWithoutView;
})();
var DuplicateDir = (function () {
    function DuplicateDir(elRef) {
        dom_adapter_1.DOM.setText(elRef.nativeElement, dom_adapter_1.DOM.getText(elRef.nativeElement) + 'noduplicate');
    }
    DuplicateDir = __decorate([
        metadata_1.Directive({ selector: '[no-duplicate]' }), 
        __metadata('design:paramtypes', [element_ref_1.ElementRef])
    ], DuplicateDir);
    return DuplicateDir;
})();
var OtherDuplicateDir = (function () {
    function OtherDuplicateDir(elRef) {
        dom_adapter_1.DOM.setText(elRef.nativeElement, dom_adapter_1.DOM.getText(elRef.nativeElement) + 'othernoduplicate');
    }
    OtherDuplicateDir = __decorate([
        metadata_1.Directive({ selector: '[no-duplicate]' }), 
        __metadata('design:paramtypes', [element_ref_1.ElementRef])
    ], OtherDuplicateDir);
    return OtherDuplicateDir;
})();
var DirectiveThrowingAnError = (function () {
    function DirectiveThrowingAnError() {
        throw new exceptions_1.BaseException("BOOM");
    }
    DirectiveThrowingAnError = __decorate([
        metadata_1.Directive({ selector: 'directive-throwing-error' }), 
        __metadata('design:paramtypes', [])
    ], DirectiveThrowingAnError);
    return DirectiveThrowingAnError;
})();
var ComponentWithTemplate = (function () {
    function ComponentWithTemplate() {
        this.items = [1, 2, 3];
    }
    ComponentWithTemplate = __decorate([
        metadata_1.Component({
            selector: 'component-with-template',
            directives: [common_1.NgFor],
            template: "No View Decorator: <div *ngFor=\"#item of items\">{{item}}</div>"
        }), 
        __metadata('design:paramtypes', [])
    ], ComponentWithTemplate);
    return ComponentWithTemplate;
})();
var DirectiveWithPropDecorators = (function () {
    function DirectiveWithPropDecorators() {
        this.event = new async_1.EventEmitter();
    }
    DirectiveWithPropDecorators.prototype.onClick = function (target) {
        this.target = target;
    };
    DirectiveWithPropDecorators.prototype.fireEvent = function (msg) { async_1.ObservableWrapper.callEmit(this.event, msg); };
    __decorate([
        metadata_1.Input('elProp'), 
        __metadata('design:type', String)
    ], DirectiveWithPropDecorators.prototype, "dirProp", void 0);
    __decorate([
        metadata_1.Output('elEvent'), 
        __metadata('design:type', Object)
    ], DirectiveWithPropDecorators.prototype, "event", void 0);
    __decorate([
        metadata_1.HostBinding("attr.my-attr"), 
        __metadata('design:type', String)
    ], DirectiveWithPropDecorators.prototype, "myAttr", void 0);
    __decorate([
        metadata_1.HostListener("click", ["$event.target"]), 
        __metadata('design:type', Function), 
        __metadata('design:paramtypes', [Object]), 
        __metadata('design:returntype', void 0)
    ], DirectiveWithPropDecorators.prototype, "onClick", null);
    DirectiveWithPropDecorators = __decorate([
        metadata_1.Directive({ selector: 'with-prop-decorators' }), 
        __metadata('design:paramtypes', [])
    ], DirectiveWithPropDecorators);
    return DirectiveWithPropDecorators;
})();
var SomeCmp = (function () {
    function SomeCmp() {
    }
    SomeCmp = __decorate([
        metadata_1.Component({ selector: 'some-cmp' }), 
        __metadata('design:paramtypes', [])
    ], SomeCmp);
    return SomeCmp;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW50ZWdyYXRpb25fc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29yZS9saW5rZXIvaW50ZWdyYXRpb25fc3BlYy50cyJdLCJuYW1lcyI6WyJtYWluIiwiZGVjbGFyZVRlc3RzIiwicnVuV2l0aE1vZGUiLCJleHBlY3RDb21waWxlRXJyb3IiLCJNeVNlcnZpY2UiLCJNeVNlcnZpY2UuY29uc3RydWN0b3IiLCJTaW1wbGVJbXBlcmF0aXZlVmlld0NvbXBvbmVudCIsIlNpbXBsZUltcGVyYXRpdmVWaWV3Q29tcG9uZW50LmNvbnN0cnVjdG9yIiwiRHluYW1pY1ZpZXdwb3J0IiwiRHluYW1pY1ZpZXdwb3J0LmNvbnN0cnVjdG9yIiwiTXlEaXIiLCJNeURpci5jb25zdHJ1Y3RvciIsIkRpcmVjdGl2ZVdpdGhUaXRsZSIsIkRpcmVjdGl2ZVdpdGhUaXRsZS5jb25zdHJ1Y3RvciIsIkRpcmVjdGl2ZVdpdGhUaXRsZUFuZEhvc3RQcm9wZXJ0eSIsIkRpcmVjdGl2ZVdpdGhUaXRsZUFuZEhvc3RQcm9wZXJ0eS5jb25zdHJ1Y3RvciIsIlB1c2hDbXAiLCJQdXNoQ21wLmNvbnN0cnVjdG9yIiwiUHVzaENtcC5maWVsZCIsIlB1c2hDbXBXaXRoUmVmIiwiUHVzaENtcFdpdGhSZWYuY29uc3RydWN0b3IiLCJQdXNoQ21wV2l0aFJlZi5maWVsZCIsIlB1c2hDbXBXaXRoUmVmLnByb3BhZ2F0ZSIsIlB1c2hDbXBXaXRoSG9zdEV2ZW50IiwiUHVzaENtcFdpdGhIb3N0RXZlbnQuY29uc3RydWN0b3IiLCJQdXNoQ21wV2l0aEFzeW5jUGlwZSIsIlB1c2hDbXBXaXRoQXN5bmNQaXBlLmNvbnN0cnVjdG9yIiwiUHVzaENtcFdpdGhBc3luY1BpcGUuZmllbGQiLCJQdXNoQ21wV2l0aEFzeW5jUGlwZS5yZXNvbHZlIiwiTXlDb21wIiwiTXlDb21wLmNvbnN0cnVjdG9yIiwiTXlDb21wLnRocm93RXJyb3IiLCJDaGlsZENvbXAiLCJDaGlsZENvbXAuY29uc3RydWN0b3IiLCJDaGlsZENvbXBOb1RlbXBsYXRlIiwiQ2hpbGRDb21wTm9UZW1wbGF0ZS5jb25zdHJ1Y3RvciIsIkNoaWxkQ29tcFVzaW5nU2VydmljZSIsIkNoaWxkQ29tcFVzaW5nU2VydmljZS5jb25zdHJ1Y3RvciIsIlNvbWVEaXJlY3RpdmUiLCJTb21lRGlyZWN0aXZlLmNvbnN0cnVjdG9yIiwiU29tZURpcmVjdGl2ZU1pc3NpbmdBbm5vdGF0aW9uIiwiU29tZURpcmVjdGl2ZU1pc3NpbmdBbm5vdGF0aW9uLmNvbnN0cnVjdG9yIiwiQ29tcFdpdGhIb3N0IiwiQ29tcFdpdGhIb3N0LmNvbnN0cnVjdG9yIiwiQ2hpbGRDb21wMiIsIkNoaWxkQ29tcDIuY29uc3RydWN0b3IiLCJTb21lVmlld3BvcnQiLCJTb21lVmlld3BvcnQuY29uc3RydWN0b3IiLCJEb3VibGVQaXBlIiwiRG91YmxlUGlwZS5jb25zdHJ1Y3RvciIsIkRvdWJsZVBpcGUubmdPbkRlc3Ryb3kiLCJEb3VibGVQaXBlLnRyYW5zZm9ybSIsIkRpcmVjdGl2ZUVtaXR0aW5nRXZlbnQiLCJEaXJlY3RpdmVFbWl0dGluZ0V2ZW50LmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlRW1pdHRpbmdFdmVudC5maXJlRXZlbnQiLCJEaXJlY3RpdmVVcGRhdGluZ0hvc3RBdHRyaWJ1dGVzIiwiRGlyZWN0aXZlVXBkYXRpbmdIb3N0QXR0cmlidXRlcy5jb25zdHJ1Y3RvciIsIkRpcmVjdGl2ZVVwZGF0aW5nSG9zdFByb3BlcnRpZXMiLCJEaXJlY3RpdmVVcGRhdGluZ0hvc3RQcm9wZXJ0aWVzLmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlTGlzdGVuaW5nRXZlbnQiLCJEaXJlY3RpdmVMaXN0ZW5pbmdFdmVudC5jb25zdHJ1Y3RvciIsIkRpcmVjdGl2ZUxpc3RlbmluZ0V2ZW50Lm9uRXZlbnQiLCJEaXJlY3RpdmVMaXN0ZW5pbmdEb21FdmVudCIsIkRpcmVjdGl2ZUxpc3RlbmluZ0RvbUV2ZW50LmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlTGlzdGVuaW5nRG9tRXZlbnQub25FdmVudCIsIkRpcmVjdGl2ZUxpc3RlbmluZ0RvbUV2ZW50Lm9uV2luZG93RXZlbnQiLCJEaXJlY3RpdmVMaXN0ZW5pbmdEb21FdmVudC5vbkRvY3VtZW50RXZlbnQiLCJEaXJlY3RpdmVMaXN0ZW5pbmdEb21FdmVudC5vbkJvZHlFdmVudCIsIkRpcmVjdGl2ZUxpc3RlbmluZ0RvbUV2ZW50T3RoZXIiLCJEaXJlY3RpdmVMaXN0ZW5pbmdEb21FdmVudE90aGVyLmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlTGlzdGVuaW5nRG9tRXZlbnRPdGhlci5vbkV2ZW50IiwiRGlyZWN0aXZlTGlzdGVuaW5nRG9tRXZlbnRQcmV2ZW50IiwiRGlyZWN0aXZlTGlzdGVuaW5nRG9tRXZlbnRQcmV2ZW50LmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlTGlzdGVuaW5nRG9tRXZlbnRQcmV2ZW50Lm9uRXZlbnQiLCJEaXJlY3RpdmVMaXN0ZW5pbmdEb21FdmVudE5vUHJldmVudCIsIkRpcmVjdGl2ZUxpc3RlbmluZ0RvbUV2ZW50Tm9QcmV2ZW50LmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlTGlzdGVuaW5nRG9tRXZlbnROb1ByZXZlbnQub25FdmVudCIsIklkRGlyIiwiSWREaXIuY29uc3RydWN0b3IiLCJFdmVudERpciIsIkV2ZW50RGlyLmNvbnN0cnVjdG9yIiwiRXZlbnREaXIuZG9Tb21ldGhpbmciLCJOZWVkc0F0dHJpYnV0ZSIsIk5lZWRzQXR0cmlidXRlLmNvbnN0cnVjdG9yIiwiUHVibGljQXBpIiwiUHVibGljQXBpLmNvbnN0cnVjdG9yIiwiUHJpdmF0ZUltcGwiLCJQcml2YXRlSW1wbC5jb25zdHJ1Y3RvciIsIk5lZWRzUHVibGljQXBpIiwiTmVlZHNQdWJsaWNBcGkuY29uc3RydWN0b3IiLCJUb29sYmFyUGFydCIsIlRvb2xiYXJQYXJ0LmNvbnN0cnVjdG9yIiwiVG9vbGJhclZpZXdDb250YWluZXIiLCJUb29sYmFyVmlld0NvbnRhaW5lci5jb25zdHJ1Y3RvciIsIlRvb2xiYXJWaWV3Q29udGFpbmVyLnRvb2xiYXJWYyIsIlRvb2xiYXJDb21wb25lbnQiLCJUb29sYmFyQ29tcG9uZW50LmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlV2l0aFR3b1dheUJpbmRpbmciLCJEaXJlY3RpdmVXaXRoVHdvV2F5QmluZGluZy5jb25zdHJ1Y3RvciIsIkRpcmVjdGl2ZVdpdGhUd29XYXlCaW5kaW5nLnRyaWdnZXJDaGFuZ2UiLCJJbmplY3RhYmxlU2VydmljZSIsIkluamVjdGFibGVTZXJ2aWNlLmNvbnN0cnVjdG9yIiwiY3JlYXRlSW5qZWN0YWJsZVdpdGhMb2dnaW5nIiwiQ29tcG9uZW50UHJvdmlkaW5nTG9nZ2luZ0luamVjdGFibGUiLCJDb21wb25lbnRQcm92aWRpbmdMb2dnaW5nSW5qZWN0YWJsZS5jb25zdHJ1Y3RvciIsIkRpcmVjdGl2ZVByb3ZpZGluZ0luamVjdGFibGUiLCJEaXJlY3RpdmVQcm92aWRpbmdJbmplY3RhYmxlLmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlUHJvdmlkaW5nSW5qZWN0YWJsZUluVmlldyIsIkRpcmVjdGl2ZVByb3ZpZGluZ0luamVjdGFibGVJblZpZXcuY29uc3RydWN0b3IiLCJEaXJlY3RpdmVQcm92aWRpbmdJbmplY3RhYmxlSW5Ib3N0QW5kVmlldyIsIkRpcmVjdGl2ZVByb3ZpZGluZ0luamVjdGFibGVJbkhvc3RBbmRWaWV3LmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlQ29uc3VtaW5nSW5qZWN0YWJsZSIsIkRpcmVjdGl2ZUNvbnN1bWluZ0luamVjdGFibGUuY29uc3RydWN0b3IiLCJEaXJlY3RpdmVDb250YWluaW5nRGlyZWN0aXZlQ29uc3VtaW5nQW5JbmplY3RhYmxlIiwiRGlyZWN0aXZlQ29udGFpbmluZ0RpcmVjdGl2ZUNvbnN1bWluZ0FuSW5qZWN0YWJsZS5jb25zdHJ1Y3RvciIsIkRpcmVjdGl2ZUNvbnN1bWluZ0luamVjdGFibGVVbmJvdW5kZWQiLCJEaXJlY3RpdmVDb25zdW1pbmdJbmplY3RhYmxlVW5ib3VuZGVkLmNvbnN0cnVjdG9yIiwiRXZlbnRCdXMiLCJFdmVudEJ1cy5jb25zdHJ1Y3RvciIsIkdyYW5kUGFyZW50UHJvdmlkaW5nRXZlbnRCdXMiLCJHcmFuZFBhcmVudFByb3ZpZGluZ0V2ZW50QnVzLmNvbnN0cnVjdG9yIiwiY3JlYXRlUGFyZW50QnVzIiwiUGFyZW50UHJvdmlkaW5nRXZlbnRCdXMiLCJQYXJlbnRQcm92aWRpbmdFdmVudEJ1cy5jb25zdHJ1Y3RvciIsIkNoaWxkQ29uc3VtaW5nRXZlbnRCdXMiLCJDaGlsZENvbnN1bWluZ0V2ZW50QnVzLmNvbnN0cnVjdG9yIiwiU29tZUltcGVyYXRpdmVWaWV3cG9ydCIsIlNvbWVJbXBlcmF0aXZlVmlld3BvcnQuY29uc3RydWN0b3IiLCJTb21lSW1wZXJhdGl2ZVZpZXdwb3J0LnNvbWVJbXB2cCIsIkV4cG9ydERpciIsIkV4cG9ydERpci5jb25zdHJ1Y3RvciIsIkNvbXBvbmVudFdpdGhvdXRWaWV3IiwiQ29tcG9uZW50V2l0aG91dFZpZXcuY29uc3RydWN0b3IiLCJEdXBsaWNhdGVEaXIiLCJEdXBsaWNhdGVEaXIuY29uc3RydWN0b3IiLCJPdGhlckR1cGxpY2F0ZURpciIsIk90aGVyRHVwbGljYXRlRGlyLmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlVGhyb3dpbmdBbkVycm9yIiwiRGlyZWN0aXZlVGhyb3dpbmdBbkVycm9yLmNvbnN0cnVjdG9yIiwiQ29tcG9uZW50V2l0aFRlbXBsYXRlIiwiQ29tcG9uZW50V2l0aFRlbXBsYXRlLmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlV2l0aFByb3BEZWNvcmF0b3JzIiwiRGlyZWN0aXZlV2l0aFByb3BEZWNvcmF0b3JzLmNvbnN0cnVjdG9yIiwiRGlyZWN0aXZlV2l0aFByb3BEZWNvcmF0b3JzLm9uQ2xpY2siLCJEaXJlY3RpdmVXaXRoUHJvcERlY29yYXRvcnMuZmlyZUV2ZW50IiwiU29tZUNtcCIsIlNvbWVDbXAuY29uc3RydWN0b3IiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsaUNBcUJPLDJCQUEyQixDQUFDLENBQUE7QUFHbkMsNEJBQWtCLHVDQUF1QyxDQUFDLENBQUE7QUFDMUQscUJBVU8sMEJBQTBCLENBQUMsQ0FBQTtBQUNsQywyQkFBOEMsZ0NBQWdDLENBQUMsQ0FBQTtBQUMvRSxzQkFLTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLHFCQWFPLGVBQWUsQ0FBQyxDQUFBO0FBRXZCLHVCQUEwQixpQkFBaUIsQ0FBQyxDQUFBO0FBRTVDLHVCQUF3QixpQkFBaUIsQ0FBQyxDQUFBO0FBRTFDLGlDQUtPLHFEQUFxRCxDQUFDLENBQUE7QUFFN0QseUJBV08sNEJBQTRCLENBQUMsQ0FBQTtBQUVwQywyQkFBd0IscUNBQXFDLENBQUMsQ0FBQTtBQUU5RCxtQ0FBK0IsNkNBQTZDLENBQUMsQ0FBQTtBQUc3RSx5QkFBdUIsbUNBQW1DLENBQUMsQ0FBQTtBQUMzRCw0QkFBeUIsc0NBQXNDLENBQUMsQ0FBQTtBQUNoRSw2QkFBMEIsdUNBQXVDLENBQUMsQ0FBQTtBQUVsRSx1QkFBdUIsMEJBQTBCLENBQUMsQ0FBQTtBQUNsRCxxQkFBc0IsMEJBQTBCLENBQUMsQ0FBQTtBQUVqRCxJQUFNLGNBQWMsR0FBRyxpQkFBVSxDQUFDLElBQUksa0JBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO0FBRXBFO0lBQ0VBLEVBQUVBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLENBQUNBLENBQUNBO1FBQ1pBLFlBQVlBLEVBQUVBLENBQUNBO0lBQ2pCQSxDQUFDQTtJQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtRQUNOQSwyQkFBUUEsQ0FBQ0EsUUFBUUEsRUFBRUE7WUFDakJBLHNDQUFtQkEsQ0FBQ0EsY0FBTUEsT0FBQUE7Z0JBQ3hCQSxjQUFPQSxDQUFDQSwwQ0FBdUJBLEVBQ3ZCQSxFQUFDQSxRQUFRQSxFQUFFQSxJQUFJQSwwQ0FBdUJBLENBQUNBLElBQUlBLEVBQUVBLEtBQUtBLEVBQUVBLEtBQUtBLENBQUNBLEVBQUNBLENBQUNBO2FBQ3JFQSxFQUh5QkEsQ0FHekJBLENBQUNBLENBQUNBO1lBQ0hBLFlBQVlBLEVBQUVBLENBQUNBO1FBQ2pCQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsS0FBS0EsRUFBRUE7WUFDZEEsc0NBQW1CQSxDQUFDQSxjQUFNQSxPQUFBQTtnQkFDeEJBLGNBQU9BLENBQUNBLDBDQUF1QkEsRUFDdkJBLEVBQUNBLFFBQVFBLEVBQUVBLElBQUlBLDBDQUF1QkEsQ0FBQ0EsSUFBSUEsRUFBRUEsS0FBS0EsRUFBRUEsSUFBSUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7YUFDcEVBLEVBSHlCQSxDQUd6QkEsQ0FBQ0EsQ0FBQ0E7WUFDSEEsWUFBWUEsRUFBRUEsQ0FBQ0E7UUFDakJBLENBQUNBLENBQUNBLENBQUNBO0lBQ0xBLENBQUNBO0FBQ0hBLENBQUNBO0FBcEJlLFlBQUksT0FvQm5CLENBQUE7QUFFRDtJQUNFQywyQkFBUUEsQ0FBQ0EsbUJBQW1CQSxFQUFFQTtRQUU1QixzQ0FBbUIsQ0FBQyxjQUFNLE9BQUEsQ0FBQyxjQUFPLENBQUMsY0FBYyxFQUFFLEVBQUMsUUFBUSxFQUFFLHFCQUFFLENBQUMsYUFBYSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQXhELENBQXdELENBQUMsQ0FBQztRQUVwRiwyQkFBUSxDQUFDLHlCQUF5QixFQUFFO1lBQ2xDLHFCQUFFLENBQUMsa0NBQWtDLEVBQ2xDLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUNsRixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUMsRUFBQyxRQUFRLEVBQUUsd0JBQXdCLEVBQUMsQ0FBQyxDQUFDO3FCQUMzRSxXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUNaLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsT0FBTyxHQUFHLGNBQWMsQ0FBQztvQkFFaEUsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUN4Qix5QkFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO29CQUN0RSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2YsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRVAscUJBQUUsQ0FBQyxrRkFBa0YsRUFDbEYseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBQ2xGLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQyxFQUFDLFFBQVEsRUFBRSxnQ0FBZ0MsRUFBQyxDQUFDLENBQUM7cUJBQ25GLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBQ1osT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO29CQUV0RCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBQ3hCLHlCQUFNLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7b0JBQzFELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLHdDQUF3QyxFQUN4Qyx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDLEVBQUMsUUFBUSxFQUFFLDRCQUE0QixFQUFDLENBQUMsQ0FBQztxQkFDL0UsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBTztvQkFFWixPQUFPLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxjQUFjLENBQUM7b0JBQ2hFLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFFeEIseUJBQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDO29CQUNsRixLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2YsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRVAscUJBQUUsQ0FBQyw2Q0FBNkMsRUFDN0MseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBQ2xGLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUNOLElBQUksdUJBQVksQ0FBQyxFQUFDLFFBQVEsRUFBRSx5Q0FBeUMsRUFBQyxDQUFDLENBQUM7cUJBRXBGLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBQ1osT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsb0JBQW9CLENBQUM7b0JBQ3RFLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFDeEIseUJBQU0sQ0FDRixpQkFBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUUsWUFBWSxDQUFDLENBQUM7eUJBQzlFLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO29CQUVuQyxPQUFPLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxvQkFBb0IsQ0FBQztvQkFDdEUsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUN4Qix5QkFBTSxDQUNGLGlCQUFHLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxZQUFZLENBQUMsQ0FBQzt5QkFDOUUsT0FBTyxDQUFDLG9CQUFvQixDQUFDLENBQUM7b0JBRW5DLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLHdFQUF3RSxFQUN4RSx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQ04sSUFBSSx1QkFBWSxDQUFDLEVBQUMsUUFBUSxFQUFFLGtDQUFrQyxFQUFDLENBQUMsQ0FBQztxQkFFN0UsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBTztvQkFFWixPQUFPLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7b0JBQ3ZELE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFDeEIseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7eUJBQzFFLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFFcEIsT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO29CQUN0RCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBQ3hCLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO3lCQUMxRSxTQUFTLEVBQUUsQ0FBQztvQkFFakIsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVQLHFCQUFFLENBQUMsa0VBQWtFLEVBQ2xFLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUNsRixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFDTixJQUFJLHVCQUFZLENBQUMsRUFBQyxRQUFRLEVBQUUseUNBQXlDLEVBQUMsQ0FBQyxDQUFDO3FCQUVwRixXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUVaLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztvQkFDdEQsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUN4Qix5QkFBTSxDQUFDLGlCQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUMsQ0FBQzt5QkFDekUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUVyQixPQUFPLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7b0JBQ3RELE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFDeEIseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDLENBQUM7eUJBQ3pFLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFFakIsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVQLHFCQUFFLENBQUMseUZBQXlGLEVBQ3pGLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUNsRixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFDTixJQUFJLHVCQUFZLENBQUMsRUFBQyxRQUFRLEVBQUUscUNBQXFDLEVBQUMsQ0FBQyxDQUFDO3FCQUVoRixXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUVaLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFDeEIseUJBQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUUzRSxPQUFPLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUM7b0JBQ3RELE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFDeEIseUJBQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUUzRSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2YsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRVAscUJBQUUsQ0FBQyxrREFBa0QsRUFDbEQseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBQ2xGLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUNOLElBQUksdUJBQVksQ0FBQyxFQUFDLFFBQVEsRUFBRSxrQ0FBa0MsRUFBQyxDQUFDLENBQUM7cUJBRTdFLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBRVosT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUN4Qix5QkFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFFNUUsT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO29CQUMxRCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBQ3hCLHlCQUFNLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDO29CQUU3RSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2YsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRVAscUJBQUUsQ0FBQyxxQ0FBcUMsRUFDckMseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBQ2xGLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUNOLElBQUksdUJBQVksQ0FBQyxFQUFDLFFBQVEsRUFBRSxxQ0FBcUMsRUFBQyxDQUFDLENBQUM7cUJBRWhGLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBRVosT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsd0JBQXdCLENBQUM7b0JBQzFFLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFDeEIseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQzt5QkFDbkUsT0FBTyxDQUFDLHdCQUF3QixDQUFDLENBQUM7b0JBRXZDLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsT0FBTyxHQUFHLDRCQUE0QixDQUFDO29CQUM5RSxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBQ3hCLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7eUJBQ25FLE9BQU8sQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO29CQUUzQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2YsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRVAscUJBQUUsQ0FBQyx1REFBdUQsRUFDdkQseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBQ2xGLEdBQUcsQ0FBQyxZQUFZLENBQ1QsTUFBTSxFQUNOLElBQUksdUJBQVksQ0FBQyxFQUFDLFFBQVEsRUFBRSwrQ0FBK0MsRUFBQyxDQUFDLENBQUM7cUJBRWhGLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBQ1osSUFBSSxRQUFRLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDO29CQUM5RCxPQUFPLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUM7b0JBQzNELE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFFeEIseUJBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3ZDLHlCQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN2Qyx5QkFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUM7b0JBRS9DLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLG1EQUFtRCxFQUNuRCx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsSUFBSSxHQUFHLEdBQUcsUUFBUTtvQkFDUix1Q0FBdUM7b0JBQ3ZDLHVDQUF1QztvQkFDdkMsK0NBQStDO29CQUMvQyxrREFBa0Q7b0JBQ2xELFNBQVMsQ0FBQztnQkFDcEIsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDLEVBQUMsUUFBUSxFQUFFLEdBQUcsRUFBRSxVQUFVLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBQyxDQUFDLENBQUM7cUJBRTNFLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBQ1osT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsY0FBYyxDQUFDO29CQUNoRSxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBRXhCLElBQUksYUFBYSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUVyRCx5QkFBTSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQztvQkFDaEYseUJBQU0sQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQzdFLHlCQUFNLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUM3RSx5QkFBTSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQzt5QkFDbEQsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUM7b0JBQ3RDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCwyQkFBUSxDQUFDLE9BQU8sRUFBRTtnQkFDaEIscUJBQUUsQ0FBQyxrQ0FBa0MsRUFDbEMseUJBQU0sQ0FDRixDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7b0JBQzNFLEdBQUcsQ0FBQyxZQUFZLENBQ1QsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQzt3QkFDdkIsUUFBUSxFQUFFLDZEQUE2RDt3QkFDdkUsVUFBVSxFQUFFLENBQUMsS0FBSyxDQUFDO3dCQUNuQixLQUFLLEVBQUUsQ0FBQyxVQUFVLENBQUM7cUJBQ3BCLENBQUMsQ0FBQzt5QkFFTCxXQUFXLENBQUMsTUFBTSxDQUFDO3lCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO3dCQUNaLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQzt3QkFDckQsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO3dCQUV4QixJQUFJLEdBQUcsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQzNELHlCQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDbEMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNmLENBQUMsQ0FBQyxDQUFDO2dCQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDYixDQUFDLENBQUMsQ0FBQztZQUVILHFCQUFFLENBQUMsbUNBQW1DLEVBQ25DLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUNsRixHQUFHLENBQUMsWUFBWSxDQUNULE1BQU0sRUFDTixJQUFJLHVCQUFZLENBQUMsRUFBQyxRQUFRLEVBQUUseUJBQXlCLEVBQUUsVUFBVSxFQUFFLENBQUMsU0FBUyxDQUFDLEVBQUMsQ0FBQyxDQUFDO3FCQUVuRixXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUVaLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFFeEIseUJBQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDL0QsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVQLCtEQUErRDtZQUMvRCxxQkFBRSxDQUFDLDJEQUEyRCxFQUMzRCx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixRQUFRLEVBQUUsbURBQW1EO29CQUM3RCxVQUFVLEVBQUUsQ0FBQyxLQUFLLEVBQUUsU0FBUyxDQUFDO2lCQUMvQixDQUFDLENBQUM7cUJBRWYsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBTztvQkFFWixPQUFPLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxjQUFjLENBQUM7b0JBQ2hFLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFFeEIsSUFBSSxFQUFFLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRTFDLHlCQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUM7b0JBQ3pELHlCQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRW5ELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLGtFQUFrRSxFQUNsRSx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixvQ0FBb0M7b0JBQ3BDLFFBQVEsRUFBRSxnQkFBZ0I7b0JBQzFCLFVBQVUsRUFBRSxDQUFDLEtBQUssQ0FBQztpQkFDcEIsQ0FBQyxDQUFDO3FCQUVmLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU8sSUFBTyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRVAscUJBQUUsQ0FBQyx5RUFBeUUsRUFDekUseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBQ2xGLEdBQUcsQ0FBQyxZQUFZLENBQ1QsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQztvQkFDdkIsUUFBUSxFQUFFLHNCQUFzQjtvQkFDaEMsVUFBVSxFQUFFLENBQUMsWUFBWSxFQUFFLFlBQVksRUFBRSxDQUFDLFlBQVksRUFBRSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7aUJBQ3pFLENBQUMsQ0FBQztxQkFDTCxXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUNaLHlCQUFNLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUM7b0JBQ3JFLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLHFFQUFxRSxFQUNyRSx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUNaLEVBQUMsUUFBUSxFQUFFLHdCQUF3QixFQUFFLFVBQVUsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFDLENBQUMsQ0FBQztxQkFFbkYsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBTztvQkFDWixJQUFJLEVBQUUsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDMUMsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFFN0IsT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDO29CQUMzRCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBQ3hCLHlCQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFFcEMsT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDO29CQUM1RCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBQ3hCLHlCQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFFckMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVQLHFCQUFFLENBQUMsa0VBQWtFLEVBQ2xFLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUNsRixHQUFHLENBQUMsWUFBWSxDQUNULE1BQU0sRUFDTixJQUFJLHVCQUFZLENBQ1osRUFBQyxRQUFRLEVBQUUscUNBQXFDLEVBQUUsVUFBVSxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUMsQ0FBQyxDQUFDO3FCQUVqRixXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUNaLElBQUksRUFBRSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMxQyx5QkFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUMzQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2YsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRVAscUJBQUUsQ0FBQywwREFBMEQsRUFDMUQseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBQ2xGLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQztvQkFDdkIsUUFBUSxFQUFFLG9EQUFvRDtvQkFDOUQsVUFBVSxFQUFFLENBQUMsV0FBVyxFQUFFLGNBQWMsQ0FBQztpQkFDMUMsQ0FBQyxDQUFDO3FCQUVmLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU8sSUFBTyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRVAscUJBQUUsQ0FBQywrREFBK0QsRUFDL0QseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBQ2xGLEdBQUcsQ0FBQyxZQUFZLENBQ1QsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQztvQkFDdkIsUUFBUSxFQUNKLDZGQUE2RjtvQkFDakcsVUFBVSxFQUFFLENBQUMsWUFBWSxDQUFDO2lCQUMzQixDQUFDLENBQUM7cUJBRUwsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBTztvQkFFWixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBRXhCLElBQUksbUJBQW1CLEdBQUcsaUJBQUcsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQztvQkFDN0UseUJBQXlCO29CQUN6Qix5QkFBTSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDM0MseUJBQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDbkQseUJBQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDbkQsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVQLHFCQUFFLENBQUMsZ0VBQWdFLEVBQ2hFLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUNsRixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUMsRUFBQyxRQUFRLEVBQUUsdUJBQXVCLEVBQUMsQ0FBQyxDQUFDO3FCQUUxRSxXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUNaLElBQUksbUJBQW1CLEdBQUcsaUJBQUcsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQztvQkFDN0UseUJBQU0sQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzNDLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDN0QsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVQLHFCQUFFLENBQUMsOERBQThELEVBQzlELHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUNsRixHQUFHLENBQUMsWUFBWSxDQUNULE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7b0JBQ3ZCLFFBQVEsRUFDSixrRkFBa0Y7b0JBQ3RGLFVBQVUsRUFBRSxDQUFDLFlBQVksQ0FBQztpQkFDM0IsQ0FBQyxDQUFDO3FCQUVMLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBQ1osT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUV4QixJQUFJLG1CQUFtQixHQUFHLGlCQUFHLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUM7b0JBQzdFLHlCQUF5QjtvQkFDekIseUJBQU0sQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzNDLHlCQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQ25ELHlCQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQ25ELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLDBFQUEwRSxFQUMxRSx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FDVCxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixRQUFRLEVBQ0osZ0xBQWdMO29CQUNwTCxVQUFVLEVBQUUsQ0FBQyxhQUFhLEVBQUUsWUFBWSxFQUFFLGdCQUFnQixFQUFFLFdBQVcsQ0FBQztpQkFDekUsQ0FBQyxDQUFDO3FCQUNMLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBQ1osT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsYUFBYSxDQUFDO29CQUMvRCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBRXhCLHlCQUFNLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUM7eUJBQ3JDLFVBQVUsQ0FDUCxtRUFBbUUsQ0FBQyxDQUFDO29CQUU3RSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2YsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRVAsMkJBQVEsQ0FBQyxtQkFBbUIsRUFBRTtnQkFDNUIscUJBQUUsQ0FBQyxxQ0FBcUMsRUFDckMseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQzFDLFVBQUMsR0FBeUIsRUFBRSxLQUFLO29CQUM3QixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7d0JBQ3ZCLFFBQVEsRUFBRSwwQ0FBMEM7d0JBQ3BELFVBQVUsRUFBRSxDQUFDLFNBQVMsQ0FBQztxQkFDeEIsQ0FBQyxDQUFDO3lCQUVmLFdBQVcsQ0FBQyxNQUFNLENBQUM7eUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87d0JBQ1oseUJBQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDOzZCQUNqRSxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQzt3QkFFakMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNmLENBQUMsQ0FBQyxDQUFBO2dCQUFBLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRXhCLHFCQUFFLENBQUMscUNBQXFDLEVBQ3JDLHlCQUFNLENBQ0YsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO29CQUMzRSxHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7d0JBQ3ZCLFFBQVEsRUFBRSxtREFBbUQ7d0JBQzdELFVBQVUsRUFBRSxDQUFDLFNBQVMsQ0FBQztxQkFDeEIsQ0FBQyxDQUFDO3lCQUVmLFdBQVcsQ0FBQyxNQUFNLENBQUM7eUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87d0JBQ1oseUJBQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDOzZCQUNwRSxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQzt3QkFFakMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNmLENBQUMsQ0FBQyxDQUFDO2dCQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRVgscUJBQUUsQ0FBQyxvRUFBb0UsRUFDcEUseUJBQU0sQ0FDRixDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQzFDLFVBQUMsR0FBeUIsRUFBRSxLQUFLO29CQUM3QixHQUFHLENBQUMsWUFBWSxDQUNULE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7d0JBQ3ZCLFFBQVEsRUFBRSwyREFBMkQ7d0JBQ3JFLFVBQVUsRUFBRSxDQUFDLFNBQVMsQ0FBQztxQkFDeEIsQ0FBQyxDQUFDO3lCQUVMLFdBQVcsQ0FBQyxNQUFNLENBQUM7eUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87d0JBQ1osT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO3dCQUV4Qix5QkFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDOzZCQUNyQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBRSx3QkFBd0I7d0JBQ3hCLCtCQUErQjt3QkFDL0IsbUJBQW1CO3dCQUNuRCxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2YsQ0FBQyxDQUFDLENBQUE7Z0JBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFckIscUJBQUUsQ0FBQyx3REFBd0QsRUFDeEQseUJBQU0sQ0FDRixDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQzFDLFVBQUMsR0FBeUIsRUFBRSxLQUFLO29CQUM3QixHQUFHLENBQUMsWUFBWSxDQUNULE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7d0JBQ3ZCLFFBQVEsRUFDSix5RUFBeUU7d0JBQzdFLFVBQVUsRUFBRSxDQUFDLFNBQVMsQ0FBQztxQkFDeEIsQ0FBQyxDQUFDO3lCQUVMLFdBQVcsQ0FBQyxNQUFNLENBQUM7eUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87d0JBQ1osSUFBSSxRQUFRLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUU1RCx5QkFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQzt3QkFDL0QseUJBQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUM7d0JBQzdELHlCQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUV0RSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2YsQ0FBQyxDQUFDLENBQUE7Z0JBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFckIscUJBQUUsQ0FBQyxzRUFBc0UsRUFDdEUseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQzFDLFVBQUMsR0FBeUIsRUFDekIsS0FBSztvQkFBTSxHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7d0JBQ3ZCLFFBQVEsRUFBRSxnQ0FBZ0M7d0JBQzFDLFVBQVUsRUFBRSxDQUFDLFNBQVMsQ0FBQztxQkFDeEIsQ0FBQyxDQUFDO3lCQUVmLFdBQVcsQ0FBQyxNQUFNLENBQUM7eUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87d0JBRVoseUJBQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7NkJBQ3JELGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUVqQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2YsQ0FBQyxDQUFDLENBQUE7Z0JBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFaEMscUJBQUUsQ0FBQywrREFBK0QsRUFDL0QseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQzFDLFVBQUMsR0FBeUIsRUFBRSxLQUFLO29CQUM3QixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7d0JBQ3ZCLFFBQVEsRUFBRSw4Q0FBOEM7cUJBQ3pELENBQUMsQ0FBQzt5QkFFZixXQUFXLENBQUMsTUFBTSxDQUFDO3lCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO3dCQUVaLElBQUksS0FBSyxHQUNMLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7d0JBQ25FLHlCQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDN0IseUJBQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUVuRCxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2YsQ0FBQyxDQUFDLENBQUE7Z0JBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFeEIscUJBQUUsQ0FBQyxzQkFBc0IsRUFDdEIseUJBQU0sQ0FDRixDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7b0JBQzNFLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQzt3QkFDdkIsUUFBUSxFQUFFLCtDQUErQzt3QkFDekQsVUFBVSxFQUFFLENBQUMsU0FBUyxDQUFDO3FCQUN4QixDQUFDLENBQUM7eUJBRWYsV0FBVyxDQUFDLE1BQU0sQ0FBQzt5QkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBTzt3QkFDWix5QkFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUM7NkJBQ3RFLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUVqQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2YsQ0FBQyxDQUFDLENBQUM7Z0JBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFWCxxQkFBRSxDQUFDLDZDQUE2QyxFQUM3Qyx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQ3pCLEtBQUs7b0JBQ3ZELEdBQUcsQ0FBQyxZQUFZLENBQ1QsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQzt3QkFDdkIsUUFBUSxFQUNKLDRIQUE0SDt3QkFDaEksVUFBVSxFQUFFLENBQUMsbUJBQW1CLEVBQUUsY0FBSyxDQUFDO3FCQUN6QyxDQUFDLENBQUM7eUJBRUwsV0FBVyxDQUFDLE1BQU0sQ0FBQzt5QkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBTzt3QkFDWixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7d0JBQ3hCLCtEQUErRDt3QkFDL0QseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzZCQUN4RCxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7d0JBRTNCLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDZixDQUFDLENBQUMsQ0FBQztnQkFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUM7WUFFSCwyQkFBUSxDQUFDLG1CQUFtQixFQUFFO2dCQUM1QixxQkFBRSxDQUFDLDBEQUEwRCxFQUMxRCx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFDMUMsVUFBQyxHQUF5QixFQUFFLEtBQUs7b0JBRTdCLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQzt3QkFDdkIsUUFBUSxFQUFFLDhDQUE4Qzt3QkFDeEQsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7cUJBQ2pDLENBQUMsQ0FBQzt5QkFFZixXQUFXLENBQUMsTUFBTSxDQUFDO3lCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO3dCQUVaLElBQUksR0FBRyxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFFM0QsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO3dCQUN4Qix5QkFBTSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRXRDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQzt3QkFDeEIseUJBQU0sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUV0QyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7d0JBRWhCLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQzt3QkFDeEIseUJBQU0sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN0QyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2YsQ0FBQyxDQUFDLENBQUE7Z0JBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFeEIscUJBQUUsQ0FBQyxpREFBaUQsRUFDakQseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQzFDLFVBQUMsR0FBeUIsRUFBRSxLQUFLO29CQUU3QixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7d0JBQ3ZCLFFBQVEsRUFBRSw2Q0FBNkM7d0JBQ3ZELFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO3FCQUMxQixDQUFDLENBQUM7eUJBRWYsV0FBVyxDQUFDLE1BQU0sQ0FBQzt5QkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBTzt3QkFDWixJQUFJLEdBQUcsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBRTNELE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQzt3QkFDdkQsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO3dCQUN4Qix5QkFBTSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRXRDLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQzt3QkFDdkQsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO3dCQUN4Qix5QkFBTSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRXRDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDZixDQUFDLENBQUMsQ0FBQTtnQkFBQSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUV4QixFQUFFLENBQUMsQ0FBQyxpQkFBRyxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUM1QixxQkFBRSxDQUFDLHNFQUFzRSxFQUN0RSx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLENBQUMsRUFBRSw0QkFBUyxDQUFDLFVBQUMsR0FBeUI7d0JBRTFELElBQUksT0FBeUIsQ0FBQzt3QkFDOUIsR0FBRyxDQUFDLFlBQVksQ0FDVCxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDOzRCQUN2QixRQUFRLEVBQUUsdURBQXVEOzRCQUNqRSxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDO3lCQUN2QyxDQUFDLENBQUM7NkJBRUwsV0FBVyxDQUFDLE1BQU0sQ0FBQzs2QkFDbkIsSUFBSSxDQUFDLFVBQUEsSUFBSSxJQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDdkMsdUJBQUksRUFBRSxDQUFDO3dCQUNQLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQzt3QkFFeEIsSUFBSSxLQUFLLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzdDLElBQUksR0FBRyxHQUF5QixLQUFLLENBQUMsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUM7d0JBQ25FLEdBQUcsQ0FBQyxXQUFXLEdBQUcsVUFBQyxDQUFDLElBQUssT0FBQSxPQUFPLENBQUMsT0FBTyxFQUFFLEVBQWpCLENBQWlCLENBQUM7d0JBRTNDLHlCQUFNLENBQUMsY0FBTSxPQUFBLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLEVBQVMsRUFBRSxDQUFDLEVBQTdDLENBQTZDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7b0JBQzVFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakIsQ0FBQztnQkFFRCxxQkFBRSxDQUFDLHdEQUF3RCxFQUN4RCx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFDMUMsVUFBQyxHQUF5QixFQUFFLEtBQUs7b0JBQzdCLEdBQUcsQ0FBQyxZQUFZLENBQ1QsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQzt3QkFDdkIsUUFBUSxFQUNKLCtEQUErRDt3QkFDbkUsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7cUJBQ2pDLENBQUMsQ0FBQzt5QkFFTCxXQUFXLENBQUMsTUFBTSxDQUFDO3lCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO3dCQUVaLElBQUksR0FBRyxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFFM0QsT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO3dCQUN2RCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7d0JBQ3hCLHlCQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFFaEMsT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO3dCQUN2RCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7d0JBQ3hCLHlCQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFFaEMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNmLENBQUMsQ0FBQyxDQUFBO2dCQUFBLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRXhCLEVBQUUsQ0FBQyxDQUFDLGlCQUFHLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBQzVCLHFCQUFFLENBQUMsdURBQXVELEVBQ3ZELHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsQ0FBQyxFQUFFLDRCQUFTLENBQUMsVUFBQyxHQUF5Qjt3QkFDMUQsR0FBRyxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQ2xCLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7NEJBQ3ZCLFFBQVEsRUFBRSxrREFBa0Q7NEJBQzVELFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUM7eUJBQ3ZDLENBQUMsQ0FBQyxDQUFDO3dCQUVSLElBQUksT0FBeUIsQ0FBQzt3QkFDOUIsR0FBRyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQSxJQUFJLElBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUMxRCx1QkFBSSxFQUFFLENBQUM7d0JBRVAsSUFBSSxHQUFHLEdBQ0gsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUNyRCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7d0JBQ3hCLHlCQUFNLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFdEMsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO3dCQUN4QixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7d0JBQ3hCLHlCQUFNLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFdEMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDZix1QkFBSSxFQUFFLENBQUM7d0JBRVAsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO3dCQUN4Qix5QkFBTSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakIsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQyxpREFBaUQsRUFDakQseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQzFDLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUM3QixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7b0JBQ3ZCLFFBQVEsRUFBRSw4SkFLbkI7b0JBQ1MsVUFBVSxFQUFFLENBQUMsYUFBYSxFQUFFLFlBQVksQ0FBQztpQkFDMUMsQ0FBQyxDQUFDO3FCQUVmLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBRVosSUFBSSxjQUFjLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUN4RSx5QkFBTSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztvQkFFOUQsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxDQUFBO1lBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUV4QixxQkFBRSxDQUFDLGlGQUFpRixFQUNqRix5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixRQUFRLEVBQUUsNktBS1Y7b0JBQ0EsVUFBVSxFQUFFLENBQUMsYUFBYSxFQUFFLFlBQVksRUFBRSxhQUFJLENBQUM7aUJBQ2hELENBQUMsQ0FBQztxQkFFZixXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUNaLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFFeEIsSUFBSSxFQUFFLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFFbEUsSUFBSSxjQUFjLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDMUMseUJBQU0sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLENBQUM7b0JBRTlELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLDREQUE0RCxFQUM1RCx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixRQUFRLEVBQUUsOEJBQThCO29CQUN4QyxVQUFVLEVBQUUsQ0FBQyxzQkFBc0IsRUFBRSx1QkFBdUIsQ0FBQztpQkFDOUQsQ0FBQyxDQUFDO3FCQUVmLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBRVosSUFBSSxFQUFFLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzFDLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsQ0FBQztvQkFDaEQsSUFBSSxRQUFRLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO29CQUVsRCx5QkFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7b0JBQ2pDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztvQkFFbkIseUJBQWlCLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsVUFBQyxDQUFDO3dCQUMzQyxVQUFVLEVBQUUsQ0FBQzt3QkFDYixFQUFFLENBQUMsQ0FBQyxVQUFVLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDckIseUJBQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDOzRCQUN4QyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7NEJBQ2xCLE9BQU8sQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLENBQUM7d0JBQ3JDLENBQUM7d0JBQUMsSUFBSSxDQUFDLENBQUM7NEJBQ04seUJBQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDOzRCQUN4QyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ2YsQ0FBQztvQkFDSCxDQUFDLENBQUMsQ0FBQztvQkFFSCxPQUFPLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUUvQixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLDZEQUE2RCxFQUM3RCx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FDVCxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixRQUFRLEVBQUUsaUVBQWlFO29CQUMzRSxVQUFVLEVBQUUsQ0FBQyxzQkFBc0IsRUFBRSx1QkFBdUIsQ0FBQztpQkFDOUQsQ0FBQyxDQUFDO3FCQUVMLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBRVosSUFBSSxFQUFFLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRTVDLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsQ0FBQztvQkFDaEQsSUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ2pELElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsdUJBQXVCLENBQUMsQ0FBQztvQkFFbEQsTUFBTSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQ3BCLHlCQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFFakMseUJBQWlCLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsVUFBQyxDQUFDO3dCQUMzQyx5QkFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7d0JBQ3hDLHlCQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQzt3QkFDMUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNmLENBQUMsQ0FBQyxDQUFDO29CQUVILE9BQU8sQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQy9CLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVQLHFCQUFFLENBQUMsNEJBQTRCLEVBQzVCLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUNsRixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7b0JBQ3ZCLFFBQVEsRUFBRSwyQ0FBMkM7b0JBQ3JELFVBQVUsRUFBRSxDQUFDLDBCQUEwQixDQUFDO2lCQUN6QyxDQUFDLENBQUM7cUJBRWYsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBTztvQkFDWixJQUFJLEVBQUUsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDMUMsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO29CQUVoRCxPQUFPLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7b0JBQ3ZELE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFFeEIseUJBQU0sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUVuQyx5QkFBaUIsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxVQUFDLENBQUM7d0JBQy9DLHlCQUFNLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3RFLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDZixDQUFDLENBQUMsQ0FBQztvQkFFSCxHQUFHLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUMzQixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLDhCQUE4QixFQUM5Qix5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FDVCxNQUFNLEVBQ04sSUFBSSx1QkFBWSxDQUNaLEVBQUMsUUFBUSxFQUFFLHNCQUFzQixFQUFFLFVBQVUsRUFBRSxDQUFDLDBCQUEwQixDQUFDLEVBQUMsQ0FBQyxDQUFDO3FCQUVwRixXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUVaLElBQUksRUFBRSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMxQyxJQUFJLFFBQVEsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLDBCQUEwQixDQUFDLENBQUM7b0JBRXJELGdDQUFhLENBQUMsRUFBRSxDQUFDLGFBQWEsRUFBRSxVQUFVLENBQUMsQ0FBQztvQkFFNUMseUJBQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDO3lCQUN0QixPQUFPLENBQ0osQ0FBQyxVQUFVLEVBQUUsZUFBZSxFQUFFLG1CQUFtQixFQUFFLGlCQUFpQixDQUFDLENBQUMsQ0FBQztvQkFFL0UsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO29CQUNsQixRQUFRLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDekIsZ0NBQWEsQ0FBQyxFQUFFLENBQUMsYUFBYSxFQUFFLFVBQVUsQ0FBQyxDQUFDO29CQUM1Qyx5QkFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7b0JBRXhDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLHFDQUFxQyxFQUNyQyx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FDVCxNQUFNLEVBQ04sSUFBSSx1QkFBWSxDQUNaLEVBQUMsUUFBUSxFQUFFLHNCQUFzQixFQUFFLFVBQVUsRUFBRSxDQUFDLDBCQUEwQixDQUFDLEVBQUMsQ0FBQyxDQUFDO3FCQUVwRixXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUNaLElBQUksRUFBRSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMxQyxJQUFJLFFBQVEsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLDBCQUEwQixDQUFDLENBQUM7b0JBQ3JELGdDQUFhLENBQUMsaUJBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztvQkFDOUQseUJBQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO29CQUV6RCxRQUFRLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDekIsZ0NBQWEsQ0FBQyxpQkFBRyxDQUFDLG9CQUFvQixDQUFDLFVBQVUsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO29CQUNoRSx5QkFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxtQkFBbUIsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7b0JBRTlFLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDbEIsUUFBUSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ3pCLGdDQUFhLENBQUMsaUJBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztvQkFDNUQseUJBQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO29CQUV4QyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2YsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRVAscUJBQUUsQ0FBQyx5REFBeUQsRUFDekQseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBQ2xGLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQztvQkFDdkIsUUFBUSxFQUFFLG9DQUFvQztvQkFDOUMsVUFBVSxFQUFFLENBQUMsK0JBQStCLENBQUM7aUJBQzlDLENBQUMsQ0FBQztxQkFFZixXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUNaLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFFeEIseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUM7eUJBQzNFLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFFdkIsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVQLHFCQUFFLENBQUMseURBQXlELEVBQ3pELHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUNsRixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7b0JBQ3ZCLFFBQVEsRUFBRSxvQ0FBb0M7b0JBQzlDLFVBQVUsRUFBRSxDQUFDLCtCQUErQixDQUFDO2lCQUM5QyxDQUFDLENBQUM7cUJBRWYsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBTztvQkFDWixJQUFJLEVBQUUsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDMUMsSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO29CQUU1RCxVQUFVLENBQUMsRUFBRSxHQUFHLE9BQU8sQ0FBQztvQkFFeEIsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUV4Qix5QkFBTSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUU3QyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2YsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBR1AsRUFBRSxDQUFDLENBQUMsaUJBQUcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDNUIscUJBQUUsQ0FBQyxvREFBb0QsRUFDcEQseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUN6QixLQUFLO29CQUN2RCxHQUFHLENBQUMsWUFBWSxDQUNULE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7d0JBQ3ZCLFFBQVEsRUFDSixrRkFBa0Y7d0JBQ3RGLFVBQVUsRUFBRTs0QkFDVixpQ0FBaUM7NEJBQ2pDLG1DQUFtQzt5QkFDcEM7cUJBQ0YsQ0FBQyxDQUFDO3lCQUVMLFdBQVcsQ0FBQyxNQUFNLENBQUM7eUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87d0JBQ1osSUFBSSxlQUFlLEdBQUcsaUJBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQzt3QkFDcEQsSUFBSSxnQkFBZ0IsR0FBRyxpQkFBRyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO3dCQUNyRCxpQkFBRyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQzlDLGVBQWUsQ0FBQyxDQUFDO3dCQUNuQyxpQkFBRyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQzlDLGdCQUFnQixDQUFDLENBQUM7d0JBQ3BDLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3BELHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDdEQseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQzs2QkFDakUsU0FBUyxFQUFFLENBQUM7d0JBQ2pCLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7NkJBQ2pFLFVBQVUsRUFBRSxDQUFDO3dCQUNsQixLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2YsQ0FBQyxDQUFDLENBQUM7Z0JBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNULENBQUM7WUFFRCxxQkFBRSxDQUFDLDhEQUE4RCxFQUM5RCx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FDVCxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixRQUFRLEVBQUUsd0RBQXdEO29CQUNsRSxVQUFVLEVBQ04sQ0FBQyxhQUFJLEVBQUUsMEJBQTBCLEVBQUUsK0JBQStCLENBQUM7aUJBQ3hFLENBQUMsQ0FBQztxQkFFTCxXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUNaLGFBQWEsR0FBRyxDQUFDLENBQUM7b0JBQ2xCLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztvQkFDMUQsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUV4QixJQUFJLEVBQUUsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFFMUMsSUFBSSxRQUFRLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO29CQUNyRCxJQUFJLGFBQWEsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLCtCQUErQixDQUFDLENBQUM7b0JBQy9ELGdDQUFhLENBQUMsaUJBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztvQkFDOUQseUJBQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO29CQUN6RCx5QkFBTSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztvQkFDMUQseUJBQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBR2pDLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztvQkFDM0QsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUN4QixnQ0FBYSxDQUFDLGlCQUFHLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7b0JBQzlELHlCQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUVqQyxPQUFPLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7b0JBQzFELE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFDeEIsZ0NBQWEsQ0FBQyxpQkFBRyxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO29CQUM5RCx5QkFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFFakMsa0VBQWtFO29CQUNsRSxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7b0JBRWxCLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCwyQkFBUSxDQUFDLHdCQUF3QixFQUFFO2dCQUNqQyxxQkFBRSxDQUFDLGlFQUFpRSxFQUNqRSx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLEVBQUUsbUJBQVEsQ0FBQyxFQUNwRCxVQUFDLEdBQXlCLEVBQUUsS0FBSyxFQUFFLFFBQVE7b0JBQ3pDLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQzt3QkFDdkIsUUFBUSxFQUFFLCtDQUErQzt3QkFDekQsVUFBVSxFQUFFLENBQUMsZUFBZSxDQUFDO3FCQUM5QixDQUFDLENBQUM7eUJBRWYsV0FBVyxDQUFDLE1BQU0sQ0FBQzt5QkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBTzt3QkFDWixJQUFJLEVBQUUsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3RELElBQUksU0FBUyxHQUFvQixFQUFFLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDO3dCQUM1RCxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFDLENBQUM7NEJBQ3BCLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQzs0QkFDeEIseUJBQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDO2lDQUM3RCxVQUFVLENBQUMsZUFBZSxDQUFDLENBQUM7NEJBQ2pDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDZixDQUFDLENBQUMsQ0FBQztvQkFDTCxDQUFDLENBQUMsQ0FBQztnQkFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRWhCLENBQUMsQ0FBQyxDQUFDO1lBRUgscUJBQUUsQ0FBQyxrQ0FBa0MsRUFDbEMseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBQ2xGLEdBQUcsQ0FBQyxZQUFZLENBQ1QsTUFBTSxFQUNOLElBQUksdUJBQVksQ0FDWixFQUFDLFFBQVEsRUFBRSxrQ0FBa0MsRUFBRSxVQUFVLEVBQUUsQ0FBQyxjQUFjLENBQUMsRUFBQyxDQUFDLENBQUM7cUJBQ3BGLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBQ1osSUFBSSxFQUFFLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzFDLElBQUksY0FBYyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUM7b0JBQy9DLHlCQUFNLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDckQseUJBQU0sQ0FBQyxjQUFjLENBQUMsZUFBZSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO29CQUNuRCx5QkFBTSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRWxELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQztRQUVILDJCQUFRLENBQUMsc0JBQXNCLEVBQUU7WUFDL0IscUJBQUUsQ0FBQyx5QkFBeUIsRUFDekIseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBQ2xGLEdBQUcsQ0FBQyxZQUFZLENBQ1QsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQztvQkFDdkIsUUFBUSxFQUFFLHdOQUtuQjtvQkFDUyxVQUFVLEVBQUUsQ0FBQyw0QkFBNEIsRUFBRSw0QkFBNEIsQ0FBQztpQkFDekUsQ0FBQyxDQUFDO3FCQUNMLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBQ1osSUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUNsRSx5QkFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO29CQUU1RCxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2YsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRVAscUJBQUUsQ0FBQyw4QkFBOEIsRUFDOUIseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBQ2xGLEdBQUcsQ0FBQyxZQUFZLENBQUMsa0NBQWtDLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUNuRCxRQUFRLEVBQUUsMEhBRzdCO29CQUNtQixVQUFVLEVBQUUsQ0FBQyw0QkFBNEIsQ0FBQztpQkFDM0MsQ0FBQyxDQUFDO3FCQUNmLFdBQVcsQ0FBQyxrQ0FBa0MsQ0FBQztxQkFDL0MsSUFBSSxDQUFDLFVBQUMsT0FBTztvQkFDWixJQUFJLElBQUksR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQ2xFLHlCQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLGlCQUFpQixDQUFDLENBQUM7b0JBRTVELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLGlDQUFpQyxFQUNqQyx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixRQUFRLEVBQUUsaVFBSzdCO29CQUNtQixVQUFVLEVBQUU7d0JBQ1YsNEJBQTRCO3dCQUM1QixpREFBaUQ7cUJBQ2xEO2lCQUNGLENBQUMsQ0FBQztxQkFDZixZQUFZLENBQUMsaURBQWlELEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUNsRSxRQUFRLEVBQUUsaUhBRTlCO29CQUNvQixVQUFVLEVBQUUsQ0FBQyxxQ0FBcUMsQ0FBQztpQkFDcEQsQ0FBQyxDQUFDO3FCQUVoQixXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUNaLElBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDNUQseUJBQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLGlCQUFpQixDQUFDLENBQUM7b0JBRXRFLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLHVDQUF1QyxFQUN2Qyx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixRQUFRLEVBQUUsbVNBTzdCO29CQUNtQixVQUFVLEVBQUU7d0JBQ1YsNEJBQTRCO3dCQUM1Qix1QkFBdUI7d0JBQ3ZCLHNCQUFzQjtxQkFDdkI7aUJBQ0YsQ0FBQyxDQUFDO3FCQUNmLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBQ1osSUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzlDLElBQUksVUFBVSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3BDLElBQUksU0FBUyxHQUFHLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRXZDLElBQUksV0FBVyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsNEJBQTRCLENBQUMsQ0FBQztvQkFDOUQsSUFBSSxNQUFNLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO29CQUN4RCxJQUFJLEtBQUssR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLENBQUM7b0JBRXJELHlCQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7b0JBQ3BELHlCQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQzFDLHlCQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ3BELHlCQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBRW5DLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLG9DQUFvQyxFQUNwQyx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FDVCxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixRQUFRLEVBQUUscVFBS25CO29CQUNTLFVBQVUsRUFDTixDQUFDLDRCQUE0QixFQUFFLG1DQUFtQyxFQUFFLGFBQUksQ0FBQztpQkFDOUUsQ0FBQyxDQUFDO3FCQUNMLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBQ1osSUFBSSxTQUFTLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUN2RSx5QkFBTSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBRXRDLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztvQkFDMUQsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUV4Qix5QkFBTSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRXJDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQztRQUVILDJCQUFRLENBQUMsY0FBYyxFQUFFO1lBQ3ZCLHFCQUFFLENBQUMsMENBQTBDLEVBQzFDLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUNsRixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7b0JBQ3ZCLFFBQVEsRUFBRSwySUFFOEM7aUJBQ3pELENBQUMsQ0FBQztxQkFDZixXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUNaLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUM7eUJBQzVFLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDaEIsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNULENBQUMsQ0FBQyxDQUFDO1FBRUgsMkJBQVEsQ0FBQyxnQkFBZ0IsRUFBRTtZQUN6QixxQkFBRSxDQUFDLHlFQUF5RSxFQUN6RSx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQ2xCLE1BQU0sRUFDTixJQUFJLHVCQUFZLENBQUMsRUFBQyxRQUFRLEVBQUUsRUFBRSxFQUFFLFVBQVUsRUFBRSxDQUFDLDhCQUE4QixDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRXBGLHNCQUFjLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLEVBQUUsVUFBQyxDQUFDO29CQUNuRCx5QkFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQ3JCLHNDQUFvQyxnQkFBUyxDQUFDLDhCQUE4QixDQUFHLENBQUMsQ0FBQztvQkFDckYsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNiLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQ2QsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRVAscUJBQUUsQ0FBQyw4RUFBOEUsRUFDOUUseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixDQUFDLEVBQUUsVUFBQyxHQUF5QjtnQkFDdkQsSUFBSSxDQUFDO29CQUNILEdBQUcsQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsQ0FBQztnQkFDeEMsQ0FBRTtnQkFBQSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNYLHlCQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxtREFBbUQsQ0FBQyxDQUFDO29CQUNqRixNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUNkLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRVAscUJBQUUsQ0FBQywyREFBMkQsRUFDM0QseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBRWxGLEdBQUcsR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUMsRUFBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBQyxDQUFDLENBQUMsQ0FBQztnQkFFdkYsc0JBQWMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRSxVQUFDLENBQUM7b0JBQ25ELHlCQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FDckIsaUVBQStELGdCQUFTLENBQUMsTUFBTSxDQUFDLE1BQUcsQ0FBQyxDQUFDO29CQUN6RixLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2IsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDZCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLDZEQUE2RCxFQUM3RCx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFFbEYsR0FBRztvQkFDQyxHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7d0JBQ3ZCLFVBQVUsRUFBRSxDQUFDLHdCQUF3QixDQUFDO3dCQUN0QyxRQUFRLEVBQUUsdURBQXVEO3FCQUNsRSxDQUFDLENBQUMsQ0FBQztnQkFFekIsc0JBQWMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRSxVQUFDLENBQUM7b0JBQ25ELElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUM7b0JBQ2xCLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLDBCQUEwQixDQUFDLENBQUM7b0JBQ2xGLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3RFLHlCQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLGVBQVEsQ0FBQyxDQUFDO29CQUM5QyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2IsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDZCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLDJFQUEyRSxFQUMzRSx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFFbEYsR0FBRyxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQ2xCLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUMsRUFBQyxRQUFRLEVBQUUsMENBQXdDLEVBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRXBGLEdBQUcsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUEsT0FBTztvQkFDbEMsSUFBSSxDQUFDO3dCQUNILE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQzt3QkFDeEIsTUFBTSxjQUFjLENBQUM7b0JBQ3ZCLENBQUU7b0JBQUEsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDWCxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDO3dCQUNsQix5QkFBTSxDQUFDLGlCQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQzt3QkFDL0QseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDdEUseUJBQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsZUFBUSxDQUFDLENBQUM7d0JBQzlDLHlCQUFNLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsQ0FBQzt3QkFDaEQseUJBQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsQ0FBQzt3QkFDL0QseUJBQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7b0JBQzFDLENBQUM7b0JBRUQsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVQLHFCQUFFLENBQUMsdUZBQXVGLEVBQ3ZGLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUVsRixHQUFHLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDLEVBQUMsUUFBUSxFQUFFLG1CQUFtQixFQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVsRixHQUFHLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFBLE9BQU87b0JBQ2xDLElBQUksQ0FBQzt3QkFDSCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7d0JBQ3hCLE1BQU0sY0FBYyxDQUFDO29CQUN2QixDQUFFO29CQUFBLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ1gsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQzt3QkFDbEIseUJBQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7d0JBQzdCLHlCQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUNoQyxDQUFDO29CQUVELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxFQUFFLENBQUMsQ0FBQyxpQkFBRyxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUM1QixxQkFBRSxDQUFDLDJFQUEyRSxFQUMzRSx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLENBQUMsRUFBRSw0QkFBUyxDQUFDLFVBQUMsR0FBeUI7b0JBRTFELEdBQUcsR0FBRyxHQUFHLENBQUMsWUFBWSxDQUNsQixNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO3dCQUN2QixRQUFRLEVBQUUsZ0VBQThEO3dCQUN4RSxVQUFVLEVBQUUsQ0FBQyxzQkFBc0IsRUFBRSx1QkFBdUIsQ0FBQztxQkFDOUQsQ0FBQyxDQUFDLENBQUM7b0JBRVIsSUFBSSxPQUF5QixDQUFDO29CQUM5QixHQUFHLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFBLElBQUksSUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzFELHVCQUFJLEVBQUUsQ0FBQztvQkFFUCxJQUFJLEVBQUUsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDMUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFFcEQsSUFBSSxDQUFDO3dCQUNILHVCQUFJLEVBQUUsQ0FBQzt3QkFDUCxNQUFNLGNBQWMsQ0FBQztvQkFDdkIsQ0FBRTtvQkFBQSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNYLHFDQUFrQixFQUFFLENBQUM7d0JBRXJCLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUM7d0JBQ2xCLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUM5RCx5QkFBTSxDQUFDLGlCQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUN0RSx5QkFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFRLENBQUMsQ0FBQzt3QkFDOUMseUJBQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsQ0FBQzt3QkFDL0QseUJBQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7b0JBQzFDLENBQUM7Z0JBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2pCLENBQUM7WUFFRCxFQUFFLENBQUMsQ0FBQyxDQUFDLGNBQU8sQ0FBQyxDQUFDLENBQUM7Z0JBQ2IscUJBQUUsQ0FBQyxnRUFBZ0UsRUFDaEUseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUN6QixLQUFLO29CQUV2RCxJQUFJLGNBQWMsQ0FBQztvQkFFbkIsR0FBRyxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUNOLElBQUksdUJBQVksQ0FBQyxFQUFDLFVBQVUsRUFBRSxDQUFDLGNBQWMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRXZGLHNCQUFjLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLEVBQUUsVUFBQyxDQUFDO3dCQUNuRCx5QkFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQ3JCLHNFQUFvRSxnQkFBUyxDQUFDLE1BQU0sQ0FBQyxNQUFHLENBQUMsQ0FBQzt3QkFDOUYsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUNiLE1BQU0sQ0FBQyxJQUFJLENBQUM7b0JBQ2QsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNULENBQUM7WUFFRCxxQkFBRSxDQUFDLG9GQUFvRixFQUNwRix5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFDMUMsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBRTdCLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQyxFQUFDLFFBQVEsRUFBRSxTQUFTLEVBQUMsQ0FBQyxDQUFDO3FCQUU1RCxXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUNaLHlCQUFNLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxhQUFhLEVBQUUsRUFBdkIsQ0FBdUIsQ0FBQzt5QkFDaEMsWUFBWSxDQUFDLGlDQUFjLENBQUMsZ0JBQWMsZ0JBQVMsQ0FBQyxNQUFNLENBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ3JFLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQTtZQUFBLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFeEIscUJBQUUsQ0FBQyxnR0FBZ0csRUFDaEcseUJBQU0sQ0FDRixDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQzFDLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUU3QixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUMsRUFBQyxRQUFRLEVBQUUsMkJBQTJCLEVBQUMsQ0FBQyxDQUFDO3FCQUU5RSxXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUNaLHlCQUFNLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxhQUFhLEVBQUUsRUFBdkIsQ0FBdUIsQ0FBQzt5QkFDaEMsWUFBWSxDQUFDLGlDQUFjLENBQUMsWUFBVSxnQkFBUyxDQUFDLE1BQU0sQ0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDakUsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxDQUFBO1lBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVyQixxQkFBRSxDQUFDLGtHQUFrRyxFQUNsRyx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFDMUMsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBRTdCLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQztvQkFDdkIsUUFBUSxFQUFFLHVDQUF1QztvQkFDakQsVUFBVSxFQUFFLENBQUMsU0FBUyxDQUFDO2lCQUN4QixDQUFDLENBQUM7cUJBRWYsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBTztvQkFDWix5QkFBTSxDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsYUFBYSxFQUFFLEVBQXZCLENBQXVCLENBQUM7eUJBQ2hDLFlBQVksQ0FBQyxpQ0FBYyxDQUFDLFlBQVUsZ0JBQVMsQ0FBQyxNQUFNLENBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ2pFLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQTtZQUFBLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUM7UUFFSCxxQkFBRSxDQUFDLGlDQUFpQyxFQUNqQyx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztZQUNsRixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7Z0JBQ3ZCLFFBQVEsRUFBRSxtQ0FBbUM7Z0JBQzdDLFVBQVUsRUFBRSxDQUFDLDZCQUE2QixDQUFDO2FBQzVDLENBQUMsQ0FBQztpQkFDZixXQUFXLENBQUMsTUFBTSxDQUFDO2lCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO2dCQUNaLHlCQUFNLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztnQkFDeEUsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRVAscUJBQUUsQ0FBQyw2Q0FBNkMsRUFDN0MseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixFQUFFLGNBQWMsQ0FBQyxFQUMxRCxVQUFDLEdBQXlCLEVBQUUsS0FBSyxFQUFFLGFBQWE7WUFDOUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO2dCQUN2QixRQUFRLEVBQUUsc0RBQXNEO2dCQUNoRSxVQUFVLEVBQUUsQ0FBQyxzQkFBc0IsQ0FBQzthQUNyQyxDQUFDLENBQUM7aUJBQ2YsV0FBVyxDQUFDLE1BQU0sQ0FBQztpQkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBeUI7Z0JBQzlCLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDeEIseUJBQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBRXJDLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztnQkFDMUQsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUV4Qix5QkFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFFMUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO2dCQUMzRCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3hCLHlCQUFNLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBRTFELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNmLENBQUMsQ0FBQyxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVkLDJCQUFRLENBQUMsbUJBQW1CLEVBQUU7WUFDNUIsRUFBRSxDQUFDLENBQUMsQ0FBQyxjQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUNiLHFCQUFFLENBQUMsZ0RBQWdELEVBQ2hELHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFDekIsS0FBSztvQkFDdkQsR0FBRzt3QkFDQyxHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFDTixJQUFJLHVCQUFZLENBQUMsRUFBQyxRQUFRLEVBQUUsbUNBQW1DLEVBQUMsQ0FBQyxDQUFDLENBQUE7b0JBRS9FLHNCQUFjLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLEVBQUUsVUFBQyxDQUFDO3dCQUNuRCx5QkFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQ3JCLHdKQUFvSixDQUFDLENBQUM7d0JBQzFKLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDYixNQUFNLENBQUMsSUFBSSxDQUFDO29CQUNkLENBQUMsQ0FBQyxDQUFDO2dCQUNiLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRVAscUJBQUUsQ0FBQyw4R0FBOEcsRUFDOUcseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUN6QixLQUFLO29CQUN2RCxHQUFHLENBQUMsWUFBWSxDQUNULE1BQU0sRUFDTixJQUFJLHVCQUFZLENBQ1osRUFBQyxRQUFRLEVBQUUsdUNBQXVDLEVBQUUsVUFBVSxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUMsQ0FBQyxDQUFDO3lCQUNoRixXQUFXLENBQUMsTUFBTSxDQUFDO3lCQUNuQixJQUFJLENBQUMsVUFBQyxHQUFHLElBQU8sS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3hDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDO1lBRUQscUJBQUUsQ0FBQyx3RUFBd0UsRUFDeEUseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBQ2xGLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQztvQkFDdkIsUUFBUSxFQUFFLGlDQUFpQztvQkFDM0MsVUFBVSxFQUFFLENBQUMsa0JBQWtCLENBQUM7aUJBQ2pDLENBQUMsQ0FBQztxQkFDZixXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUNaLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztvQkFDekQsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUV4QixJQUFJLEVBQUUsR0FBRyxpQkFBRyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztvQkFDdkUseUJBQU0sQ0FBQyxjQUFPLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUM7b0JBRXpELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFFZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLDBFQUEwRSxFQUMxRSx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixRQUFRLEVBQUUsaUNBQWlDO29CQUMzQyxVQUFVLEVBQUUsQ0FBQyxpQ0FBaUMsQ0FBQztpQkFDaEQsQ0FBQyxDQUFDO3FCQUNmLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBQ1osT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO29CQUN6RCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBRXhCLElBQUksRUFBRSxHQUFHLGlCQUFHLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDO29CQUN2RSx5QkFBTSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBRWxDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFFZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQztRQUVILDJCQUFRLENBQUMsMEJBQTBCLEVBQUU7WUFDbkMsc0NBQW1CLENBQUMsY0FBTSxPQUFBO2dCQUN4QixjQUFPLENBQUMsMENBQXVCLEVBQ3ZCLEVBQUMsUUFBUSxFQUFFLElBQUksMENBQXVCLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsRUFBQyxDQUFDO2FBQ3BFLEVBSHlCLENBR3pCLENBQUMsQ0FBQztZQUVILHFCQUFFLENBQUMsOENBQThDLEVBQzlDLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUNsRixJQUFJLEdBQUcsR0FBRyxPQUFPO29CQUNQLHVDQUF1QztvQkFDdkMsUUFBUSxDQUFDO2dCQUNuQixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUMsRUFBQyxRQUFRLEVBQUUsR0FBRyxFQUFFLFVBQVUsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFDLENBQUMsQ0FBQztxQkFFM0UsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBTztvQkFDWixPQUFPLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7b0JBQ3pELE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFFeEIseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO3lCQUN2RCxTQUFTLENBQUMsNkJBQTZCLENBQUMsQ0FBQztvQkFDOUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVQLHFCQUFFLENBQUMscURBQXFELEVBQ3JELHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUNsRixJQUFJLEdBQUcsR0FBRyw0Q0FBNEMsQ0FBQztnQkFDdkQsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDLEVBQUMsUUFBUSxFQUFFLEdBQUcsRUFBRSxVQUFVLEVBQUUsQ0FBQyxhQUFJLENBQUMsRUFBQyxDQUFDLENBQUM7cUJBRTFFLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBQ1osT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO29CQUMxRCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBRXhCLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQzt5QkFDdkQsU0FBUyxDQUFDLGdDQUFnQyxDQUFDLENBQUM7b0JBQ2pELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQztRQUVILDJCQUFRLENBQUMsK0JBQStCLEVBQUU7WUFDeEMscUJBQXFCLElBQVk7Z0JBQy9CQyxNQUFNQSxDQUFDQSx5QkFBTUEsQ0FDVEEsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtvQkFDM0VBLEdBQUdBLENBQUNBLFlBQVlBLENBQUNBLE1BQU1BLEVBQ05BLElBQUlBLHVCQUFZQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxTQUFPQSxJQUFJQSw4QkFBMkJBLEVBQUNBLENBQUNBLENBQUNBO3lCQUNqRkEsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7eUJBQ25CQSxJQUFJQSxDQUFDQSxVQUFDQSxPQUFPQTt3QkFDWkEsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxPQUFPQSxHQUFHQSxjQUFjQSxDQUFDQTt3QkFFaEVBLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO3dCQUN4QkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLGNBQWNBLENBQUNBLENBQUNBO3dCQUN0RUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7b0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO2dCQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQTtZQUVELHFCQUFFLENBQUMsb0NBQW9DLEVBQUUsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7WUFFL0QscUJBQUUsQ0FBQyw0Q0FBNEMsRUFBRSxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztRQUMzRSxDQUFDLENBQUMsQ0FBQztRQUVILDRDQUE0QztRQUM1QyxrREFBa0Q7UUFDbEQsc0RBQXNEO1FBQ3RELDRCQUFTLENBQUMsMEJBQTBCLEVBQUU7WUFDcEMsNEJBQTRCLEdBQUcsRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFFLElBQUk7Z0JBQzFEQyxHQUFHQSxHQUFHQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUFDQSxNQUFNQSxFQUFFQSxJQUFJQSx1QkFBWUEsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsU0FBU0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3hFQSxzQkFBY0EsQ0FBQ0EsSUFBSUEsQ0FDZkEsR0FBR0EsQ0FBQ0EsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsRUFDdkJBLFVBQUNBLEtBQUtBO29CQUNKQSxNQUFNQSxJQUFJQSwwQkFBYUEsQ0FDbkJBLHNFQUFzRUEsQ0FBQ0EsQ0FBQ0E7Z0JBQzlFQSxDQUFDQSxFQUNEQSxVQUFDQSxHQUFHQTtvQkFDRkEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLFVBQVVBLENBQUNBLENBQUNBO29CQUN4Q0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ1RBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBO1lBRUQsRUFBRSxDQUFDLENBQUMsd0JBQWlCLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ3hCLHFCQUFFLENBQUMsMkZBQTJGLEVBQzNGLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFDekIsS0FBSztvQkFDdkQsa0JBQWtCLENBQUMsR0FBRyxFQUFFLDJDQUEyQyxFQUNoRCxnRUFBZ0UsRUFDaEUsY0FBTSxPQUFBLEtBQUssQ0FBQyxJQUFJLEVBQUUsRUFBWixDQUFZLENBQUMsQ0FBQztnQkFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFUCxxQkFBRSxDQUFDLDBEQUEwRCxFQUMxRCx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQ3pCLEtBQUs7b0JBQ3ZELGtCQUFrQixDQUFDLEdBQUcsRUFBRSxzQ0FBc0MsRUFDM0MsNkNBQTZDLEVBQUUsY0FBTSxPQUFBLEtBQUssQ0FBQyxJQUFJLEVBQUUsRUFBWixDQUFZLENBQUMsQ0FBQztnQkFDeEYsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFUCxxQkFBRSxDQUFDLDBEQUEwRCxFQUMxRCx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFDMUMsVUFBQyxHQUF5QixFQUFFLEtBQUs7b0JBQy9CLGtCQUFrQixDQUFDLEdBQUcsRUFBRSxvREFBb0QsRUFDekQsMkRBQTJELEVBQzNELGNBQU0sT0FBQSxLQUFLLENBQUMsSUFBSSxFQUFFLEVBQVosQ0FBWSxDQUFDLENBQUM7Z0JBQ3pDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRWQscUJBQUUsQ0FBQywwREFBMEQsRUFDMUQseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQzFDLFVBQUMsR0FBeUIsRUFBRSxLQUFLO29CQUMvQixrQkFBa0IsQ0FDZCxHQUFHLEVBQUUsK0JBQStCLEVBQ3BDLHVFQUF1RSxFQUN2RSxjQUFNLE9BQUEsS0FBSyxDQUFDLElBQUksRUFBRSxFQUFaLENBQVksQ0FBQyxDQUFDO2dCQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2hCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILDJCQUFRLENBQUMscUJBQXFCLEVBQUU7WUFDOUIscUJBQUUsQ0FBQyxvQ0FBb0MsRUFDcEMseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7Z0JBQ2xGLEdBQUcsQ0FBQyxZQUFZLENBQ1QsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQztvQkFDdkIsUUFBUSxFQUFFLDREQUE0RDtvQkFDdEUsVUFBVSxFQUFFLENBQUMsMkJBQTJCLENBQUM7aUJBQzFDLENBQUMsQ0FBQztxQkFDTCxXQUFXLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO29CQUNaLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFDeEIsSUFBSSxHQUFHLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLDJCQUEyQixDQUFDLENBQUM7b0JBQy9FLHlCQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDbkMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNmLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVQLHFCQUFFLENBQUMsd0NBQXdDLEVBQ3hDLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFBRSxLQUFLO2dCQUNsRixHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLHVCQUFZLENBQUM7b0JBQ3ZCLFFBQVEsRUFBRSwrQ0FBK0M7b0JBQ3pELFVBQVUsRUFBRSxDQUFDLDJCQUEyQixDQUFDO2lCQUMxQyxDQUFDLENBQUM7cUJBQ2YsV0FBVyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFVBQUMsT0FBTztvQkFDWixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBQ3hCLElBQUksR0FBRyxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO29CQUMvRSxHQUFHLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztvQkFFbkIsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUN4Qix5QkFBTSxDQUFDLGlCQUFHLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDO3lCQUNuRSxTQUFTLENBQUMsZUFBZSxDQUFDLENBQUM7b0JBQ2hDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxFQUFFLENBQUMsQ0FBQyxpQkFBRyxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUM1QixxQkFBRSxDQUFDLGlDQUFpQyxFQUNqQyx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLENBQUMsRUFBRSw0QkFBUyxDQUFDLFVBQUMsR0FBeUI7b0JBQzFELEdBQUcsR0FBRyxHQUFHLENBQUMsWUFBWSxDQUNsQixNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO3dCQUN2QixRQUFRLEVBQUUsdURBQXFEO3dCQUMvRCxVQUFVLEVBQUUsQ0FBQywyQkFBMkIsQ0FBQztxQkFDMUMsQ0FBQyxDQUFDLENBQUM7b0JBRVIsSUFBSSxPQUF5QixDQUFDO29CQUM5QixHQUFHLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFBLElBQUksSUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzFELHVCQUFJLEVBQUUsQ0FBQztvQkFFUCxJQUFJLE9BQU8sR0FDUCxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsMkJBQTJCLENBQUMsQ0FBQztvQkFDekUsT0FBTyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFFN0IsdUJBQUksRUFBRSxDQUFDO29CQUVQLHlCQUFNLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQzNFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFHZixxQkFBRSxDQUFDLHlDQUF5QyxFQUN6Qyx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQ3pCLEtBQUs7b0JBQ3ZELEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLElBQUksdUJBQVksQ0FBQzt3QkFDdkIsUUFBUSxFQUFFLCtDQUErQzt3QkFDekQsVUFBVSxFQUFFLENBQUMsMkJBQTJCLENBQUM7cUJBQzFDLENBQUMsQ0FBQzt5QkFDZixXQUFXLENBQUMsTUFBTSxDQUFDO3lCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO3dCQUNaLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQzt3QkFDeEIsSUFBSSxHQUFHLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLDJCQUEyQixDQUFDLENBQUM7d0JBQy9FLElBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQzt3QkFDNUQsaUJBQUcsQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLGlCQUFHLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzt3QkFFekQseUJBQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUNoQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2YsQ0FBQyxDQUFDLENBQUM7Z0JBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNULENBQUM7WUFFRCxxQkFBRSxDQUFDLDBEQUEwRCxFQUMxRCx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQUUsS0FBSztnQkFDbEYsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSx1QkFBWSxDQUFDO29CQUN2QixRQUFRLEVBQUUscURBQXFEO29CQUMvRCxVQUFVLEVBQUUsQ0FBQyxxQkFBcUIsQ0FBQztpQkFDcEMsQ0FBQyxDQUFDO3FCQUNmLFdBQVcsQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxVQUFDLE9BQU87b0JBQ1osT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUN4QixJQUFJLE1BQU0sR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUM7b0JBQzVELHlCQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxDQUFDLHdCQUF3QixDQUFDLENBQUM7b0JBQ3BELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDZixDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQztRQUdILEVBQUUsQ0FBQyxDQUFDLGlCQUFHLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDNUIsMkJBQVEsQ0FBQyxLQUFLLEVBQUU7Z0JBQ2QscUJBQUUsQ0FBQyw2QkFBNkIsRUFDN0IseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUN6QixLQUFLO29CQUN2RCxHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFDTixJQUFJLHVCQUFZLENBQUMsRUFBQyxRQUFRLEVBQUUsc0NBQXNDLEVBQUMsQ0FBQyxDQUFDO3lCQUNqRixXQUFXLENBQUMsTUFBTSxDQUFDO3lCQUNuQixJQUFJLENBQUMsVUFBQyxPQUFPO3dCQUNaLElBQUksRUFBRSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDO3dCQUM1QyxJQUFJLEdBQUcsR0FBRyxpQkFBRyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDaEMsSUFBSSxHQUFHLEdBQUcsaUJBQUcsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ2pDLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxXQUFXLENBQVUsR0FBRyxFQUFFLGNBQWMsQ0FBQyxDQUFDOzZCQUNoRCxPQUFPLENBQUMsNEJBQTRCLENBQUMsQ0FBQzt3QkFDM0MseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFdBQVcsQ0FBVSxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7NkJBQ2hELE9BQU8sQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO3dCQUUzQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGNBQU8sQ0FBQyxDQUFDLENBQUM7NEJBQ2IsSUFBSSxjQUFjLEdBQUcsaUJBQUcsQ0FBQyxXQUFXLENBQVUsR0FBRyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUNwRSx5QkFBTSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7NEJBQ2xELHlCQUFNLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDLE9BQU8sQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO3dCQUM5RSxDQUFDO3dCQUFDLElBQUksQ0FBQyxDQUFDOzRCQUNOLCtEQUErRDs0QkFDL0QseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFlBQVksQ0FBYyxHQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsQ0FBQzt3QkFDdEUsQ0FBQzt3QkFFRCxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2YsQ0FBQyxDQUFDLENBQUM7Z0JBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVULENBQUMsQ0FBQyxDQUFDO1lBRUgsMkJBQVEsQ0FBQyxZQUFZLEVBQUU7Z0JBRXJCLHFCQUFFLENBQUMsMENBQTBDLEVBQzFDLHlCQUFNLENBQUMsQ0FBQyx1Q0FBb0IsRUFBRSxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsR0FBeUIsRUFDekIsS0FBSztvQkFDdkQsR0FBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsSUFBSSx1QkFBWSxDQUFDLEVBQUMsUUFBUSxFQUFFLDhCQUE4QixFQUFDLENBQUMsQ0FBQzt5QkFDbEYsV0FBVyxDQUFDLE9BQU8sQ0FBQzt5QkFDcEIsSUFBSSxDQUFDLFVBQUMsT0FBTzt3QkFDWixJQUFJLEtBQUssR0FBRyxpQkFBRyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO3dCQUMvRCx5QkFBTSxDQUFDLGlCQUFHLENBQUMsY0FBYyxDQUFDLEtBQUssRUFBRSw4QkFBOEIsRUFBRSxNQUFNLENBQUMsQ0FBQzs2QkFDcEUsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUNwQixLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2YsQ0FBQyxDQUFDLENBQUM7Z0JBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFUCxxQkFBRSxDQUFDLHFEQUFxRCxFQUNyRCx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLEVBQUUscUNBQWtCLENBQUMsRUFBRSxVQUFDLEdBQXlCLEVBQ3pCLEtBQUs7b0JBQ3ZELEdBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUNQLElBQUksdUJBQVksQ0FBQyxFQUFDLFFBQVEsRUFBRSx1Q0FBdUMsRUFBQyxDQUFDLENBQUM7eUJBQ2xGLFdBQVcsQ0FBQyxPQUFPLENBQUM7eUJBQ3BCLElBQUksQ0FBQyxVQUFDLE9BQU87d0JBQ1osSUFBSSxHQUFHLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQzt3QkFDakQsSUFBSSxLQUFLLEdBQUcsaUJBQUcsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQzt3QkFFL0QsR0FBRyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7d0JBQ2xCLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQzt3QkFFeEIseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLGNBQWMsQ0FBQyxLQUFLLEVBQUUsOEJBQThCLEVBQUUsTUFBTSxDQUFDLENBQUM7NkJBQ3BFLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFFcEIsR0FBRyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7d0JBQ2pCLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQzt3QkFFeEIseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLGNBQWMsQ0FBQyxLQUFLLEVBQUUsOEJBQThCLEVBQUUsTUFBTSxDQUFDLENBQUM7NkJBQ3BFLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFFcEIsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNmLENBQUMsQ0FBQyxDQUFDO2dCQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUM7SUFDSCxDQUFDLENBQUNGLENBQUNBO0FBQ0xBLENBQUNBO0FBRUQ7SUFHRUc7UUFBZ0JDLElBQUlBLENBQUNBLFFBQVFBLEdBQUdBLE9BQU9BLENBQUNBO0lBQUNBLENBQUNBO0lBSDVDRDtRQUFDQSxpQkFBVUEsRUFBRUE7O2tCQUlaQTtJQUFEQSxnQkFBQ0E7QUFBREEsQ0FBQ0EsQUFKRCxJQUlDO0FBRUQ7SUFLRUUsdUNBQVlBLElBQWdCQSxFQUFFQSxRQUFrQkE7UUFDOUNDLElBQUlBLFdBQVdBLEdBQUdBLElBQUlBLENBQUNBLGFBQWFBLENBQUNBO1FBQ3JDQSxpQkFBR0EsQ0FBQ0EsV0FBV0EsQ0FBQ0EsV0FBV0EsRUFBRUEscUJBQUVBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDckRBLENBQUNBO0lBUkhEO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxnQkFBZ0JBLEVBQUVBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBO1FBQ3JEQSxpQkFBVUEsRUFBRUE7O3NDQVFaQTtJQUFEQSxvQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFURCxJQVNDO0FBRUQ7SUFJRUUseUJBQVlBLEVBQW9CQSxFQUFFQSxRQUFrQkE7UUFDbERDLElBQUlBLFNBQVNBLEdBQUdBLElBQUlBLFNBQVNBLEVBQUVBLENBQUNBO1FBQ2hDQSxTQUFTQSxDQUFDQSxRQUFRQSxHQUFHQSxlQUFlQSxDQUFDQTtRQUVyQ0EsSUFBSUEsUUFBUUEsR0FBR0EsZUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsY0FBT0EsQ0FBQ0EsU0FBU0EsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsU0FBU0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDN0VBLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLFFBQVFBLENBQUNBLGFBQWFBLENBQUNBLHFCQUFxQkEsQ0FBQ0E7YUFDeENBLElBQUlBLENBQUNBLFVBQUNBLE1BQU1BLElBQU1BLEVBQUVBLENBQUNBLGNBQWNBLENBQUNBLE1BQU1BLEVBQUVBLENBQUNBLEVBQUVBLFFBQVFBLENBQUNBLENBQUFBLENBQUFBLENBQUNBLENBQUNBLENBQUNBO0lBQzlFQSxDQUFDQTtJQVhIRDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsWUFBWUEsRUFBQ0EsQ0FBQ0E7UUFDbkNBLGlCQUFVQSxFQUFFQTs7d0JBV1pBO0lBQURBLHNCQUFDQTtBQUFEQSxDQUFDQSxBQVpELElBWUM7QUFFRDtJQUlFRTtRQUFnQkMsSUFBSUEsQ0FBQ0EsT0FBT0EsR0FBR0EsRUFBRUEsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFKdENEO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxVQUFVQSxFQUFFQSxNQUFNQSxFQUFFQSxDQUFDQSxpQkFBaUJBLENBQUNBLEVBQUVBLFFBQVFBLEVBQUVBLE9BQU9BLEVBQUNBLENBQUNBO1FBQ2pGQSxpQkFBVUEsRUFBRUE7O2NBSVpBO0lBQURBLFlBQUNBO0FBQURBLENBQUNBLEFBTEQsSUFLQztBQUVEO0lBQUFFO0lBR0FDLENBQUNBO0lBSEREO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxTQUFTQSxFQUFFQSxNQUFNQSxFQUFFQSxDQUFDQSxPQUFPQSxDQUFDQSxFQUFDQSxDQUFDQTs7MkJBR25EQTtJQUFEQSx5QkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFBQUU7SUFHQUMsQ0FBQ0E7SUFIREQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLFNBQVNBLEVBQUVBLE1BQU1BLEVBQUVBLENBQUNBLE9BQU9BLENBQUNBLEVBQUVBLElBQUlBLEVBQUVBLEVBQUNBLFNBQVNBLEVBQUVBLE9BQU9BLEVBQUNBLEVBQUNBLENBQUNBOzswQ0FHL0VBO0lBQURBLHdDQUFDQTtBQUFEQSxDQUFDQSxBQUhELElBR0M7QUFFRDtJQVdFRTtRQUFnQkMsSUFBSUEsQ0FBQ0EsY0FBY0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFFMUNELHNCQUFJQSwwQkFBS0E7YUFBVEE7WUFDRUUsSUFBSUEsQ0FBQ0EsY0FBY0EsRUFBRUEsQ0FBQ0E7WUFDdEJBLE1BQU1BLENBQUNBLE9BQU9BLENBQUNBO1FBQ2pCQSxDQUFDQTs7O09BQUFGO0lBaEJIQTtRQUFDQSxvQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsVUFBVUE7WUFDcEJBLE1BQU1BLEVBQUVBLENBQUNBLE1BQU1BLENBQUNBO1lBQ2hCQSxlQUFlQSxFQUFFQSwwQ0FBdUJBLENBQUNBLE1BQU1BO1lBQy9DQSxRQUFRQSxFQUFFQSxXQUFXQTtTQUN0QkEsQ0FBQ0E7UUFDREEsaUJBQVVBLEVBQUVBOztnQkFXWkE7SUFBREEsY0FBQ0E7QUFBREEsQ0FBQ0EsQUFqQkQsSUFpQkM7QUFFRDtJQVlFRyx3QkFBWUEsR0FBc0JBO1FBQ2hDQyxJQUFJQSxDQUFDQSxjQUFjQSxHQUFHQSxDQUFDQSxDQUFDQTtRQUN4QkEsSUFBSUEsQ0FBQ0EsR0FBR0EsR0FBR0EsR0FBR0EsQ0FBQ0E7SUFDakJBLENBQUNBO0lBRURELHNCQUFJQSxpQ0FBS0E7YUFBVEE7WUFDRUUsSUFBSUEsQ0FBQ0EsY0FBY0EsRUFBRUEsQ0FBQ0E7WUFDdEJBLE1BQU1BLENBQUNBLE9BQU9BLENBQUNBO1FBQ2pCQSxDQUFDQTs7O09BQUFGO0lBRURBLGtDQUFTQSxHQUFUQSxjQUFjRyxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxZQUFZQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtJQXRCMUNIO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxtQkFBbUJBO1lBQzdCQSxNQUFNQSxFQUFFQSxDQUFDQSxNQUFNQSxDQUFDQTtZQUNoQkEsZUFBZUEsRUFBRUEsMENBQXVCQSxDQUFDQSxNQUFNQTtZQUMvQ0EsUUFBUUEsRUFBRUEsV0FBV0E7U0FDdEJBLENBQUNBO1FBQ0RBLGlCQUFVQSxFQUFFQTs7dUJBaUJaQTtJQUFEQSxxQkFBQ0E7QUFBREEsQ0FBQ0EsQUF2QkQsSUF1QkM7QUFFRDtJQUFBSTtRQU9FQyxnQkFBV0EsR0FBYUEsVUFBQ0EsQ0FBQ0EsSUFBTUEsQ0FBQ0EsQ0FBQ0E7SUFDcENBLENBQUNBO0lBUkREO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSwwQkFBMEJBO1lBQ3BDQSxJQUFJQSxFQUFFQSxFQUFDQSxTQUFTQSxFQUFFQSxxQkFBcUJBLEVBQUNBO1lBQ3hDQSxlQUFlQSxFQUFFQSwwQ0FBdUJBLENBQUNBLE1BQU1BO1lBQy9DQSxRQUFRQSxFQUFFQSxFQUFFQTtTQUNiQSxDQUFDQTs7NkJBR0RBO0lBQURBLDJCQUFDQTtBQUFEQSxDQUFDQSxBQVJELElBUUM7QUFFRDtJQVlFRTtRQUpBQyxtQkFBY0EsR0FBV0EsQ0FBQ0EsQ0FBQ0E7UUFLekJBLElBQUlBLENBQUNBLFNBQVNBLEdBQUdBLHNCQUFjQSxDQUFDQSxTQUFTQSxFQUFFQSxDQUFDQTtRQUM1Q0EsSUFBSUEsQ0FBQ0EsT0FBT0EsR0FBR0EsSUFBSUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsT0FBT0EsQ0FBQ0E7SUFDeENBLENBQUNBO0lBRURELHNCQUFJQSx1Q0FBS0E7YUFBVEE7WUFDRUUsSUFBSUEsQ0FBQ0EsY0FBY0EsRUFBRUEsQ0FBQ0E7WUFDdEJBLE1BQU1BLENBQUNBLElBQUlBLENBQUNBLE9BQU9BLENBQUNBO1FBQ3RCQSxDQUFDQTs7O09BQUFGO0lBRURBLHNDQUFPQSxHQUFQQSxVQUFRQSxLQUFLQSxJQUFJRyxJQUFJQSxDQUFDQSxTQUFTQSxDQUFDQSxPQUFPQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQXRCbkRIO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxxQkFBcUJBO1lBQy9CQSxlQUFlQSxFQUFFQSwwQ0FBdUJBLENBQUNBLE1BQU1BO1lBQy9DQSxRQUFRQSxFQUFFQSxtQkFBbUJBO1lBQzdCQSxLQUFLQSxFQUFFQSxDQUFDQSxrQkFBU0EsQ0FBQ0E7U0FDbkJBLENBQUNBO1FBQ0RBLGlCQUFVQSxFQUFFQTs7NkJBaUJaQTtJQUFEQSwyQkFBQ0E7QUFBREEsQ0FBQ0EsQUF2QkQsSUF1QkM7QUFFRDtJQU1FSTtRQUNFQyxJQUFJQSxDQUFDQSxPQUFPQSxHQUFHQSxlQUFlQSxDQUFDQTtRQUMvQkEsSUFBSUEsQ0FBQ0EsVUFBVUEsR0FBR0EsQ0FBQ0EsQ0FBQ0E7UUFDcEJBLElBQUlBLENBQUNBLFdBQVdBLEdBQUdBLEtBQUtBLENBQUNBO0lBQzNCQSxDQUFDQTtJQUVERCwyQkFBVUEsR0FBVkEsY0FBZUUsTUFBTUEsTUFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFaaENGO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxTQUFTQSxFQUFFQSxVQUFVQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTtRQUNoREEsaUJBQVVBLEVBQUVBOztlQVlaQTtJQUFEQSxhQUFDQTtBQUFEQSxDQUFDQSxBQWJELElBYUM7QUFFRDtJQVdFRyxtQkFBWUEsT0FBa0JBO1FBQzVCQyxJQUFJQSxDQUFDQSxPQUFPQSxHQUFHQSxPQUFPQSxDQUFDQSxRQUFRQSxDQUFDQTtRQUNoQ0EsSUFBSUEsQ0FBQ0EsT0FBT0EsR0FBR0EsSUFBSUEsQ0FBQ0E7SUFDdEJBLENBQUNBO0lBZEhEO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxXQUFXQTtZQUNyQkEsTUFBTUEsRUFBRUEsQ0FBQ0EsU0FBU0EsQ0FBQ0E7WUFDbkJBLGFBQWFBLEVBQUVBLENBQUNBLFNBQVNBLENBQUNBO1lBQzFCQSxVQUFVQSxFQUFFQSxDQUFDQSxLQUFLQSxDQUFDQTtZQUNuQkEsUUFBUUEsRUFBRUEsYUFBYUE7U0FDeEJBLENBQUNBO1FBQ0RBLGlCQUFVQSxFQUFFQTs7a0JBUVpBO0lBQURBLGdCQUFDQTtBQUFEQSxDQUFDQSxBQWZELElBZUM7QUFFRDtJQUFBRTtRQUdFQyxZQUFPQSxHQUFXQSxPQUFPQSxDQUFDQTtJQUM1QkEsQ0FBQ0E7SUFKREQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLHVCQUF1QkEsRUFBRUEsVUFBVUEsRUFBRUEsRUFBRUEsRUFBRUEsUUFBUUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7UUFDNUVBLGlCQUFVQSxFQUFFQTs7NEJBR1pBO0lBQURBLDBCQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQUlFRSwrQkFBWUEsT0FBa0JBO1FBQUlDLElBQUlBLENBQUNBLE9BQU9BLEdBQUdBLE9BQU9BLENBQUNBLFFBQVFBLENBQUNBO0lBQUNBLENBQUNBO0lBSnRFRDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsZUFBZUEsRUFBRUEsUUFBUUEsRUFBRUEsYUFBYUEsRUFBQ0EsQ0FBQ0E7UUFDL0RBLGlCQUFVQSxFQUFFQTs7OEJBSVpBO0lBQURBLDRCQUFDQTtBQUFEQSxDQUFDQSxBQUxELElBS0M7QUFFRDtJQUFBRTtJQUdBQyxDQUFDQTtJQUhERDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsZ0JBQWdCQSxFQUFDQSxDQUFDQTtRQUN2Q0EsaUJBQVVBLEVBQUVBOztzQkFFWkE7SUFBREEsb0JBQUNBO0FBQURBLENBQUNBLEFBSEQsSUFHQztBQUVEO0lBQUFFO0lBQXNDQyxDQUFDQTtJQUFERCxxQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFBdkMsSUFBdUM7QUFFdkM7SUFRRUUsc0JBQW9CQSxRQUF1QkE7UUFBSUMsSUFBSUEsQ0FBQ0EsTUFBTUEsR0FBR0EsUUFBUUEsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFSMUVEO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxlQUFlQTtZQUN6QkEsUUFBUUEsRUFBRUEsd0NBQXdDQTtZQUNsREEsVUFBVUEsRUFBRUEsQ0FBQ0EsYUFBYUEsQ0FBQ0E7U0FDNUJBLENBQUNBO1FBQ0RBLGlCQUFVQSxFQUFFQTtRQUdDQSxXQUFDQSxXQUFJQSxFQUFFQSxDQUFBQTs7cUJBQ3BCQTtJQUFEQSxtQkFBQ0E7QUFBREEsQ0FBQ0EsQUFURCxJQVNDO0FBRUQ7SUFLRUUsb0JBQVlBLE9BQWtCQTtRQUM1QkMsSUFBSUEsQ0FBQ0EsT0FBT0EsR0FBR0EsT0FBT0EsQ0FBQ0EsUUFBUUEsQ0FBQ0E7UUFDaENBLElBQUlBLENBQUNBLE9BQU9BLEdBQUdBLElBQUlBLENBQUNBO0lBQ3RCQSxDQUFDQTtJQVJIRDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsY0FBY0EsRUFBRUEsYUFBYUEsRUFBRUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7UUFDakVBLGlCQUFVQSxFQUFFQTs7bUJBUVpBO0lBQURBLGlCQUFDQTtBQUFEQSxDQUFDQSxBQVRELElBU0M7QUFFRDtJQUdFRSxzQkFBWUEsU0FBMkJBLEVBQUVBLFdBQXdCQTtRQUMvREMsU0FBU0EsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQSxRQUFRQSxDQUFDQSxXQUFXQSxFQUFFQSxPQUFPQSxDQUFDQSxDQUFDQTtRQUN6RUEsU0FBU0EsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQSxRQUFRQSxDQUFDQSxXQUFXQSxFQUFFQSxPQUFPQSxDQUFDQSxDQUFDQTtJQUMzRUEsQ0FBQ0E7SUFOSEQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLGlCQUFpQkEsRUFBQ0EsQ0FBQ0E7UUFDeENBLGlCQUFVQSxFQUFFQTs7cUJBTVpBO0lBQURBLG1CQUFDQTtBQUFEQSxDQUFDQSxBQVBELElBT0M7QUFFRDtJQUFBRTtJQUlBQyxDQUFDQTtJQUZDRCxnQ0FBV0EsR0FBWEEsY0FBZUUsQ0FBQ0E7SUFDaEJGLDhCQUFTQSxHQUFUQSxVQUFVQSxLQUFLQSxFQUFFQSxJQUFXQTtRQUFYRyxvQkFBV0EsR0FBWEEsV0FBV0E7UUFBSUEsTUFBTUEsQ0FBQ0EsS0FBR0EsS0FBS0EsR0FBR0EsS0FBT0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFIOURIO1FBQUNBLGVBQUlBLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLFFBQVFBLEVBQUNBLENBQUNBOzttQkFJdEJBO0lBQURBLGlCQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQU1FSTtRQUNFQyxJQUFJQSxDQUFDQSxHQUFHQSxHQUFHQSxFQUFFQSxDQUFDQTtRQUNkQSxJQUFJQSxDQUFDQSxLQUFLQSxHQUFHQSxJQUFJQSxvQkFBWUEsRUFBRUEsQ0FBQ0E7SUFDbENBLENBQUNBO0lBRURELDBDQUFTQSxHQUFUQSxVQUFVQSxHQUFXQSxJQUFJRSx5QkFBaUJBLENBQUNBLFFBQVFBLENBQUNBLElBQUlBLENBQUNBLEtBQUtBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO0lBWHpFRjtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsV0FBV0EsRUFBRUEsT0FBT0EsRUFBRUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7UUFDdERBLGlCQUFVQSxFQUFFQTs7K0JBV1pBO0lBQURBLDZCQUFDQTtBQUFEQSxDQUFDQSxBQVpELElBWUM7QUFFRDtJQUFBRztJQUdBQyxDQUFDQTtJQUhERDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsMEJBQTBCQSxFQUFFQSxJQUFJQSxFQUFFQSxFQUFDQSxNQUFNQSxFQUFFQSxRQUFRQSxFQUFDQSxFQUFDQSxDQUFDQTtRQUMzRUEsaUJBQVVBLEVBQUVBOzt3Q0FFWkE7SUFBREEsc0NBQUNBO0FBQURBLENBQUNBLEFBSEQsSUFHQztBQUVEO0lBS0VFO1FBQWdCQyxJQUFJQSxDQUFDQSxFQUFFQSxHQUFHQSxLQUFLQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUxwQ0Q7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLDBCQUEwQkEsRUFBRUEsSUFBSUEsRUFBRUEsRUFBQ0EsTUFBTUEsRUFBRUEsSUFBSUEsRUFBQ0EsRUFBQ0EsQ0FBQ0E7UUFDdkVBLGlCQUFVQSxFQUFFQTs7d0NBS1pBO0lBQURBLHNDQUFDQTtBQUFEQSxDQUFDQSxBQU5ELElBTUM7QUFFRDtJQUtFRTtRQUFnQkMsSUFBSUEsQ0FBQ0EsR0FBR0EsR0FBR0EsRUFBRUEsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFFaENELHlDQUFPQSxHQUFQQSxVQUFRQSxHQUFXQSxJQUFJRSxJQUFJQSxDQUFDQSxHQUFHQSxHQUFHQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQTtJQVAxQ0Y7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLFlBQVlBLEVBQUVBLElBQUlBLEVBQUVBLEVBQUNBLFNBQVNBLEVBQUVBLGlCQUFpQkEsRUFBQ0EsRUFBQ0EsQ0FBQ0E7UUFDekVBLGlCQUFVQSxFQUFFQTs7Z0NBT1pBO0lBQURBLDhCQUFDQTtBQUFEQSxDQUFDQSxBQVJELElBUUM7QUFFRDtJQUFBRztRQVdFQyxlQUFVQSxHQUFhQSxFQUFFQSxDQUFDQTtJQUs1QkEsQ0FBQ0E7SUFKQ0QsNENBQU9BLEdBQVBBLFVBQVFBLFNBQWlCQSxJQUFJRSxJQUFJQSxDQUFDQSxVQUFVQSxDQUFDQSxJQUFJQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUMvREYsa0RBQWFBLEdBQWJBLFVBQWNBLFNBQWlCQSxJQUFJRyxJQUFJQSxDQUFDQSxVQUFVQSxDQUFDQSxJQUFJQSxDQUFDQSxTQUFTQSxHQUFHQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUNqRkgsb0RBQWVBLEdBQWZBLFVBQWdCQSxTQUFpQkEsSUFBSUksSUFBSUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsV0FBV0EsR0FBR0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDckZKLGdEQUFXQSxHQUFYQSxVQUFZQSxTQUFpQkEsSUFBSUssSUFBSUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsT0FBT0EsR0FBR0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFmL0VMO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxZQUFZQTtZQUN0QkEsSUFBSUEsRUFBRUE7Z0JBQ0pBLFlBQVlBLEVBQUVBLHNCQUFzQkE7Z0JBQ3BDQSxtQkFBbUJBLEVBQUVBLDRCQUE0QkE7Z0JBQ2pEQSxxQkFBcUJBLEVBQUVBLDhCQUE4QkE7Z0JBQ3JEQSxpQkFBaUJBLEVBQUVBLDBCQUEwQkE7YUFDOUNBO1NBQ0ZBLENBQUNBO1FBQ0RBLGlCQUFVQSxFQUFFQTs7bUNBT1pBO0lBQURBLGlDQUFDQTtBQUFEQSxDQUFDQSxBQWhCRCxJQWdCQztBQUVELElBQUksYUFBYSxHQUFHLENBQUMsQ0FBQztBQUN0QjtJQUlFTTtRQUFnQkMsSUFBSUEsQ0FBQ0EsU0FBU0EsR0FBR0EsRUFBRUEsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFDdENELGlEQUFPQSxHQUFQQSxVQUFRQSxTQUFpQkE7UUFDdkJFLGFBQWFBLEVBQUVBLENBQUNBO1FBQ2hCQSxJQUFJQSxDQUFDQSxTQUFTQSxHQUFHQSxRQUFRQSxHQUFHQSxTQUFTQSxDQUFDQTtJQUN4Q0EsQ0FBQ0E7SUFSSEY7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLGlCQUFpQkEsRUFBRUEsSUFBSUEsRUFBRUEsRUFBQ0EsbUJBQW1CQSxFQUFFQSxzQkFBc0JBLEVBQUNBLEVBQUNBLENBQUNBO1FBQzdGQSxpQkFBVUEsRUFBRUE7O3dDQVFaQTtJQUFEQSxzQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFURCxJQVNDO0FBRUQ7SUFBQUc7SUFJQUMsQ0FBQ0E7SUFEQ0QsbURBQU9BLEdBQVBBLFVBQVFBLEtBQUtBLElBQUlFLE1BQU1BLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBO0lBSGxDRjtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsbUJBQW1CQSxFQUFFQSxJQUFJQSxFQUFFQSxFQUFDQSxTQUFTQSxFQUFFQSxpQkFBaUJBLEVBQUNBLEVBQUNBLENBQUNBO1FBQ2hGQSxpQkFBVUEsRUFBRUE7OzBDQUdaQTtJQUFEQSx3Q0FBQ0E7QUFBREEsQ0FBQ0EsQUFKRCxJQUlDO0FBRUQ7SUFBQUc7SUFJQUMsQ0FBQ0E7SUFEQ0QscURBQU9BLEdBQVBBLFVBQVFBLEtBQUtBLElBQUlFLE1BQU1BLENBQUNBLElBQUlBLENBQUNBLENBQUNBLENBQUNBO0lBSGpDRjtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEscUJBQXFCQSxFQUFFQSxJQUFJQSxFQUFFQSxFQUFDQSxTQUFTQSxFQUFFQSxpQkFBaUJBLEVBQUNBLEVBQUNBLENBQUNBO1FBQ2xGQSxpQkFBVUEsRUFBRUE7OzRDQUdaQTtJQUFEQSwwQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFKRCxJQUlDO0FBRUQ7SUFBQUc7SUFJQUMsQ0FBQ0E7SUFKREQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLE1BQU1BLEVBQUVBLE1BQU1BLEVBQUVBLENBQUNBLElBQUlBLENBQUNBLEVBQUNBLENBQUNBO1FBQzdDQSxpQkFBVUEsRUFBRUE7O2NBR1pBO0lBQURBLFlBQUNBO0FBQURBLENBQUNBLEFBSkQsSUFJQztBQUVEO0lBQUFFO1FBR1lDLGdCQUFXQSxHQUFHQSxJQUFJQSxvQkFBWUEsRUFBRUEsQ0FBQ0E7SUFFN0NBLENBQUNBO0lBRENELDhCQUFXQSxHQUFYQSxjQUFlRSxDQUFDQTtJQURoQkY7UUFBQ0EsaUJBQU1BLEVBQUVBOztPQUFDQSxpQ0FBV0EsVUFBc0JBO0lBSDdDQTtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsZUFBZUEsRUFBQ0EsQ0FBQ0E7UUFDdENBLGlCQUFVQSxFQUFFQTs7aUJBSVpBO0lBQURBLGVBQUNBO0FBQURBLENBQUNBLEFBTEQsSUFLQztBQUVEO0lBTUVHLHdCQUErQkEsYUFBcUJBLEVBQ25CQSxlQUF1QkEsRUFDMUJBLFlBQW9CQTtRQUNoREMsSUFBSUEsQ0FBQ0EsYUFBYUEsR0FBR0EsYUFBYUEsQ0FBQ0E7UUFDbkNBLElBQUlBLENBQUNBLGVBQWVBLEdBQUdBLGVBQWVBLENBQUNBO1FBQ3ZDQSxJQUFJQSxDQUFDQSxZQUFZQSxHQUFHQSxZQUFZQSxDQUFDQTtJQUNuQ0EsQ0FBQ0E7SUFaSEQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLFVBQVVBLEVBQUNBLENBQUNBO1FBQ2pDQSxpQkFBVUEsRUFBRUE7UUFLQ0EsV0FBQ0Esb0JBQVNBLENBQUNBLE1BQU1BLENBQUNBLENBQUFBO1FBQ2xCQSxXQUFDQSxvQkFBU0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQUE7UUFDcEJBLFdBQUNBLG9CQUFTQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFBQTs7dUJBSzlCQTtJQUFEQSxxQkFBQ0E7QUFBREEsQ0FBQ0EsQUFiRCxJQWFDO0FBRUQ7SUFBQUU7SUFFQUMsQ0FBQ0E7SUFGREQ7UUFBQ0EsaUJBQVVBLEVBQUVBOztrQkFFWkE7SUFBREEsZ0JBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBSzBCRSwrQkFBU0E7SUFMbkNBO1FBSzBCQyw4QkFBU0E7SUFDbkNBLENBQUNBO0lBTkREO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxjQUFjQTtZQUN4QkEsU0FBU0EsRUFBRUEsQ0FBQ0EsSUFBSUEsZUFBUUEsQ0FBQ0EsU0FBU0EsRUFBRUEsRUFBQ0EsV0FBV0EsRUFBRUEsV0FBV0EsRUFBRUEsSUFBSUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0E7U0FDM0VBLENBQUNBO1FBQ0RBLGlCQUFVQSxFQUFFQTs7b0JBRVpBO0lBQURBLGtCQUFDQTtBQUFEQSxDQUFDQSxBQU5ELEVBSzBCLFNBQVMsRUFDbEM7QUFFRDtJQUdFRSx3QkFBb0JBLEdBQWNBO1FBQUlDLHlCQUFNQSxDQUFDQSxHQUFHQSxZQUFZQSxXQUFXQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUh4RkQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLG9CQUFvQkEsRUFBQ0EsQ0FBQ0E7UUFDM0NBLGlCQUFVQSxFQUFFQTtRQUVDQSxXQUFDQSxXQUFJQSxFQUFFQSxDQUFBQTs7dUJBQ3BCQTtJQUFEQSxxQkFBQ0E7QUFBREEsQ0FBQ0EsQUFKRCxJQUlDO0FBRUQ7SUFJRUUscUJBQVlBLFdBQXdCQTtRQUFJQyxJQUFJQSxDQUFDQSxXQUFXQSxHQUFHQSxXQUFXQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUozRUQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLGVBQWVBLEVBQUNBLENBQUNBO1FBQ3RDQSxpQkFBVUEsRUFBRUE7O29CQUlaQTtJQUFEQSxrQkFBQ0E7QUFBREEsQ0FBQ0EsQUFMRCxJQUtDO0FBRUQ7SUFJRUUsOEJBQVlBLEVBQW9CQTtRQUFJQyxJQUFJQSxDQUFDQSxFQUFFQSxHQUFHQSxFQUFFQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUVuREQsc0JBQUlBLDJDQUFTQTthQUFiQSxVQUFjQSxJQUFpQkE7WUFDN0JFLElBQUlBLElBQUlBLEdBQUdBLElBQUlBLENBQUNBLEVBQUVBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsV0FBV0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDM0RBLElBQUlBLENBQUNBLFFBQVFBLENBQUNBLGFBQWFBLEVBQUVBLGNBQWNBLENBQUNBLENBQUNBO1FBQy9DQSxDQUFDQTs7O09BQUFGO0lBVEhBO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxhQUFhQSxFQUFFQSxNQUFNQSxFQUFFQSxDQUFDQSxXQUFXQSxDQUFDQSxFQUFDQSxDQUFDQTtRQUMzREEsaUJBQVVBLEVBQUVBOzs2QkFTWkE7SUFBREEsMkJBQUNBO0FBQURBLENBQUNBLEFBVkQsSUFVQztBQUVEO0lBVUVHLDBCQUFnQ0EsS0FBNkJBO1FBQzNEQyxJQUFJQSxDQUFDQSxPQUFPQSxHQUFHQSxhQUFhQSxDQUFDQTtRQUM3QkEsSUFBSUEsQ0FBQ0EsS0FBS0EsR0FBR0EsS0FBS0EsQ0FBQ0E7SUFDckJBLENBQUNBO0lBYkhEO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxTQUFTQTtZQUNuQkEsUUFBUUEsRUFBRUEsb0VBQW9FQTtZQUM5RUEsVUFBVUEsRUFBRUEsQ0FBQ0Esb0JBQW9CQSxFQUFFQSxjQUFLQSxDQUFDQTtTQUMxQ0EsQ0FBQ0E7UUFDREEsaUJBQVVBLEVBQUVBO1FBS0NBLFdBQUNBLGdCQUFLQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFBQTs7eUJBSWhDQTtJQUFEQSx1QkFBQ0E7QUFBREEsQ0FBQ0EsQUFkRCxJQWNDO0FBRUQ7SUFBQUU7UUFHRUMsa0JBQWFBLEdBQUdBLElBQUlBLG9CQUFZQSxFQUFFQSxDQUFDQTtRQUNuQ0EsWUFBT0EsR0FBR0EsSUFBSUEsQ0FBQ0E7SUFHakJBLENBQUNBO0lBRENELGtEQUFhQSxHQUFiQSxVQUFjQSxLQUFLQSxJQUFJRSx5QkFBaUJBLENBQUNBLFFBQVFBLENBQUNBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO0lBTmpGRjtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsV0FBV0EsRUFBRUEsTUFBTUEsRUFBRUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsRUFBRUEsT0FBT0EsRUFBRUEsQ0FBQ0EsZUFBZUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7UUFDbkZBLGlCQUFVQSxFQUFFQTs7bUNBTVpBO0lBQURBLGlDQUFDQTtBQUFEQSxDQUFDQSxBQVBELElBT0M7QUFFRDtJQUFBRztJQUVBQyxDQUFDQTtJQUZERDtRQUFDQSxpQkFBVUEsRUFBRUE7OzBCQUVaQTtJQUFEQSx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDO0FBRUQscUNBQXFDLEdBQWE7SUFDaERFLEdBQUdBLENBQUNBLEdBQUdBLENBQUNBLG1DQUFtQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsR0FBR0EsSUFBSUEsQ0FBQ0E7SUFDNURBLE1BQU1BLENBQUNBLElBQUlBLGlCQUFpQkEsRUFBRUEsQ0FBQ0E7QUFDakNBLENBQUNBO0FBRUQ7SUFBQUM7UUFTRUMsWUFBT0EsR0FBWUEsS0FBS0EsQ0FBQ0E7SUFDM0JBLENBQUNBO0lBVkREO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSx3Q0FBd0NBO1lBQ2xEQSxTQUFTQSxFQUFFQTtnQkFDVEEsSUFBSUEsZUFBUUEsQ0FBQ0EsaUJBQWlCQSxFQUFFQSxFQUFDQSxVQUFVQSxFQUFFQSwyQkFBMkJBLEVBQUVBLElBQUlBLEVBQUVBLENBQUNBLGVBQVFBLENBQUNBLEVBQUNBLENBQUNBO2FBQzdGQTtZQUNEQSxRQUFRQSxFQUFFQSxFQUFFQTtTQUNiQSxDQUFDQTtRQUNEQSxpQkFBVUEsRUFBRUE7OzRDQUdaQTtJQUFEQSwwQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFWRCxJQVVDO0FBR0Q7SUFBQUU7SUFHQUMsQ0FBQ0E7SUFIREQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLGdDQUFnQ0EsRUFBRUEsU0FBU0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQSxFQUFDQSxDQUFDQTtRQUN6RkEsaUJBQVVBLEVBQUVBOztxQ0FFWkE7SUFBREEsbUNBQUNBO0FBQURBLENBQUNBLEFBSEQsSUFHQztBQUVEO0lBQUFFO0lBT0FDLENBQUNBO0lBUEREO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxnQ0FBZ0NBO1lBQzFDQSxhQUFhQSxFQUFFQSxDQUFDQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBO1lBQ3BDQSxRQUFRQSxFQUFFQSxFQUFFQTtTQUNiQSxDQUFDQTtRQUNEQSxpQkFBVUEsRUFBRUE7OzJDQUVaQTtJQUFEQSx5Q0FBQ0E7QUFBREEsQ0FBQ0EsQUFQRCxJQU9DO0FBRUQ7SUFBQUU7SUFRQUMsQ0FBQ0E7SUFSREQ7UUFBQ0Esb0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLGdDQUFnQ0E7WUFDMUNBLFNBQVNBLEVBQUVBLENBQUNBLElBQUlBLGVBQVFBLENBQUNBLGlCQUFpQkEsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsTUFBTUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDaEVBLGFBQWFBLEVBQUVBLENBQUNBLElBQUlBLGVBQVFBLENBQUNBLGlCQUFpQkEsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsTUFBTUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDcEVBLFFBQVFBLEVBQUVBLEVBQUVBO1NBQ2JBLENBQUNBO1FBQ0RBLGlCQUFVQSxFQUFFQTs7a0RBRVpBO0lBQURBLGdEQUFDQTtBQUFEQSxDQUFDQSxBQVJELElBUUM7QUFHRDtJQUtFRSxzQ0FBK0NBLFVBQVVBO1FBQUlDLElBQUlBLENBQUNBLFVBQVVBLEdBQUdBLFVBQVVBLENBQUNBO0lBQUNBLENBQUNBO0lBTDlGRDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsZ0NBQWdDQSxFQUFFQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTtRQUNyRUEsaUJBQVVBLEVBQUVBO1FBSUNBLFdBQUNBLFdBQUlBLEVBQUVBLENBQUFBO1FBQUNBLFdBQUNBLGFBQU1BLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQUE7O3FDQUMvQ0E7SUFBREEsbUNBQUNBO0FBQURBLENBQUNBLEFBTkQsSUFNQztBQUlEO0lBQUFFO0lBSUFDLENBQUNBO0lBSkREO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSx3REFBd0RBLEVBQUNBLENBQUNBO1FBQy9FQSxpQkFBVUEsRUFBRUE7OzBEQUdaQTtJQUFEQSx3REFBQ0E7QUFBREEsQ0FBQ0EsQUFKRCxJQUlDO0FBRUQ7SUFLRUUsK0NBQVlBLFVBQTZCQSxFQUNqQkEsTUFBeURBO1FBQy9FQyxJQUFJQSxDQUFDQSxVQUFVQSxHQUFHQSxVQUFVQSxDQUFDQTtRQUM3QkEsTUFBTUEsQ0FBQ0EsU0FBU0EsR0FBR0EsSUFBSUEsQ0FBQ0E7SUFDMUJBLENBQUNBO0lBVEhEO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSwwQ0FBMENBLEVBQUVBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBO1FBQy9FQSxpQkFBVUEsRUFBRUE7UUFLQ0EsV0FBQ0EsZUFBUUEsRUFBRUEsQ0FBQUE7OzhDQUl4QkE7SUFBREEsNENBQUNBO0FBQURBLENBQUNBLEFBVkQsSUFVQztBQUdEO0lBS0VFLGtCQUFZQSxjQUF3QkEsRUFBRUEsSUFBWUE7UUFDaERDLElBQUlBLENBQUNBLGNBQWNBLEdBQUdBLGNBQWNBLENBQUNBO1FBQ3JDQSxJQUFJQSxDQUFDQSxJQUFJQSxHQUFHQSxJQUFJQSxDQUFDQTtJQUNuQkEsQ0FBQ0E7SUFSSEQ7UUFBQ0EsWUFBS0EsRUFBRUE7O2lCQVNQQTtJQUFEQSxlQUFDQTtBQUFEQSxDQUFDQSxBQVRELElBU0M7QUFFRDtJQU9FRSxzQ0FBWUEsR0FBYUE7UUFBSUMsSUFBSUEsQ0FBQ0EsR0FBR0EsR0FBR0EsR0FBR0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFQaEREO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxrQ0FBa0NBO1lBQzVDQSxTQUFTQSxFQUFFQSxDQUFDQSxJQUFJQSxlQUFRQSxDQUFDQSxRQUFRQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxJQUFJQSxRQUFRQSxDQUFDQSxJQUFJQSxFQUFFQSxhQUFhQSxDQUFDQSxFQUFDQSxDQUFDQSxDQUFDQTtTQUNuRkEsQ0FBQ0E7O3FDQUtEQTtJQUFEQSxtQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFSRCxJQVFDO0FBRUQseUJBQXlCLEdBQUc7SUFDMUJFLE1BQU1BLENBQUNBLElBQUlBLFFBQVFBLENBQUNBLEdBQUdBLEVBQUVBLFFBQVFBLENBQUNBLENBQUNBO0FBQ3JDQSxDQUFDQTtBQUVEO0lBZUVDLGlDQUFZQSxHQUFhQSxFQUFjQSxjQUF3QkE7UUFDN0RDLElBQUlBLENBQUNBLEdBQUdBLEdBQUdBLEdBQUdBLENBQUNBO1FBQ2ZBLElBQUlBLENBQUNBLGNBQWNBLEdBQUdBLGNBQWNBLENBQUNBO0lBQ3ZDQSxDQUFDQTtJQWxCSEQ7UUFBQ0Esb0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLDRCQUE0QkE7WUFDdENBLFNBQVNBLEVBQUVBO2dCQUNUQSxJQUFJQSxlQUFRQSxDQUFDQSxRQUFRQSxFQUNSQSxFQUFDQSxVQUFVQSxFQUFFQSxlQUFlQSxFQUFFQSxJQUFJQSxFQUFFQSxDQUFDQSxDQUFDQSxRQUFRQSxFQUFFQSxJQUFJQSx1QkFBZ0JBLEVBQUVBLENBQUNBLENBQUNBLEVBQUNBLENBQUNBO2FBQ3hGQTtZQUNEQSxVQUFVQSxFQUFFQSxDQUFDQSxpQkFBVUEsQ0FBQ0EsY0FBTUEsT0FBQUEsc0JBQXNCQSxFQUF0QkEsQ0FBc0JBLENBQUNBLENBQUNBO1lBQ3REQSxRQUFRQSxFQUFFQSxtRUFFVEE7U0FDRkEsQ0FBQ0E7UUFLMkJBLFdBQUNBLGVBQVFBLEVBQUVBLENBQUFBOztnQ0FJdkNBO0lBQURBLDhCQUFDQTtBQUFEQSxDQUFDQSxBQW5CRCxJQW1CQztBQUVEO0lBSUVFLGdDQUF3QkEsR0FBYUE7UUFBSUMsSUFBSUEsQ0FBQ0EsR0FBR0EsR0FBR0EsR0FBR0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFKNUREO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSwyQkFBMkJBLEVBQUNBLENBQUNBO1FBSXJDQSxXQUFDQSxlQUFRQSxFQUFFQSxDQUFBQTs7K0JBQ3hCQTtJQUFEQSw2QkFBQ0E7QUFBREEsQ0FBQ0EsQUFMRCxJQUtDO0FBRUQ7SUFLRUUsZ0NBQW1CQSxFQUFvQkEsRUFBU0EsV0FBd0JBLEVBQ3BDQSxNQUFNQTtRQUR2QkMsT0FBRUEsR0FBRkEsRUFBRUEsQ0FBa0JBO1FBQVNBLGdCQUFXQSxHQUFYQSxXQUFXQSxDQUFhQTtRQUV0RUEsSUFBSUEsQ0FBQ0EsSUFBSUEsR0FBR0EsSUFBSUEsQ0FBQ0E7UUFDakJBLElBQUlBLENBQUNBLE1BQU1BLEdBQUdBLE1BQU1BLENBQUNBO0lBQ3ZCQSxDQUFDQTtJQUVERCxzQkFBSUEsNkNBQVNBO2FBQWJBLFVBQWNBLEtBQWNBO1lBQzFCRSxFQUFFQSxDQUFDQSxDQUFDQSxnQkFBU0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3pCQSxJQUFJQSxDQUFDQSxFQUFFQSxDQUFDQSxLQUFLQSxFQUFFQSxDQUFDQTtnQkFDaEJBLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLElBQUlBLENBQUNBO1lBQ25CQSxDQUFDQTtZQUNEQSxFQUFFQSxDQUFDQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDVkEsSUFBSUEsQ0FBQ0EsSUFBSUEsR0FBR0EsSUFBSUEsQ0FBQ0EsRUFBRUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxJQUFJQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQTtnQkFDekRBLElBQUlBLEtBQUtBLEdBQUdBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLFNBQVNBLENBQUNBO2dCQUNoQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsR0FBR0EsS0FBS0EsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0EsRUFBRUEsRUFBRUEsQ0FBQ0E7b0JBQ3RDQSxpQkFBR0EsQ0FBQ0EsV0FBV0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUEsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3pDQSxDQUFDQTtZQUNIQSxDQUFDQTtRQUNIQSxDQUFDQTs7O09BQUFGO0lBdkJIQTtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsYUFBYUEsRUFBRUEsTUFBTUEsRUFBRUEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7UUFDM0RBLGlCQUFVQSxFQUFFQTtRQUtDQSxXQUFDQSxhQUFNQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFBQTs7K0JBa0JwQ0E7SUFBREEsNkJBQUNBO0FBQURBLENBQUNBLEFBeEJELElBd0JDO0FBRUQ7SUFBQUc7SUFFQUMsQ0FBQ0E7SUFGREQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLGNBQWNBLEVBQUVBLFFBQVFBLEVBQUVBLEtBQUtBLEVBQUNBLENBQUNBOztrQkFFdERBO0lBQURBLGdCQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUM7QUFFRDtJQUFBRTtJQUVBQyxDQUFDQTtJQUZERDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsTUFBTUEsRUFBQ0EsQ0FBQ0E7OzZCQUU3QkE7SUFBREEsMkJBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBRUVFLHNCQUFZQSxLQUFpQkE7UUFDM0JDLGlCQUFHQSxDQUFDQSxPQUFPQSxDQUFDQSxLQUFLQSxDQUFDQSxhQUFhQSxFQUFFQSxpQkFBR0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsR0FBR0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7SUFDckZBLENBQUNBO0lBSkhEO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxnQkFBZ0JBLEVBQUNBLENBQUNBOztxQkFLdkNBO0lBQURBLG1CQUFDQTtBQUFEQSxDQUFDQSxBQUxELElBS0M7QUFFRDtJQUVFRSwyQkFBWUEsS0FBaUJBO1FBQzNCQyxpQkFBR0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsYUFBYUEsRUFBRUEsaUJBQUdBLENBQUNBLE9BQU9BLENBQUNBLEtBQUtBLENBQUNBLGFBQWFBLENBQUNBLEdBQUdBLGtCQUFrQkEsQ0FBQ0EsQ0FBQ0E7SUFDMUZBLENBQUNBO0lBSkhEO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxnQkFBZ0JBLEVBQUNBLENBQUNBOzswQkFLdkNBO0lBQURBLHdCQUFDQTtBQUFEQSxDQUFDQSxBQUxELElBS0M7QUFFRDtJQUVFRTtRQUFnQkMsTUFBTUEsSUFBSUEsMEJBQWFBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBRnBERDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsMEJBQTBCQSxFQUFDQSxDQUFDQTs7aUNBR2pEQTtJQUFEQSwrQkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFBQUU7UUFNRUMsVUFBS0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDcEJBLENBQUNBO0lBUEREO1FBQUNBLG9CQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSx5QkFBeUJBO1lBQ25DQSxVQUFVQSxFQUFFQSxDQUFDQSxjQUFLQSxDQUFDQTtZQUNuQkEsUUFBUUEsRUFBRUEsa0VBQWdFQTtTQUMzRUEsQ0FBQ0E7OzhCQUdEQTtJQUFEQSw0QkFBQ0E7QUFBREEsQ0FBQ0EsQUFQRCxJQU9DO0FBRUQ7SUFBQUU7UUFLcUJDLFVBQUtBLEdBQUdBLElBQUlBLG9CQUFZQSxFQUFFQSxDQUFDQTtJQVNoREEsQ0FBQ0E7SUFMQ0QsNkNBQU9BLEdBRFBBLFVBQ1FBLE1BQU1BO1FBQ1pFLElBQUlBLENBQUNBLE1BQU1BLEdBQUdBLE1BQU1BLENBQUNBO0lBQ3ZCQSxDQUFDQTtJQUVERiwrQ0FBU0EsR0FBVEEsVUFBVUEsR0FBR0EsSUFBSUcseUJBQWlCQSxDQUFDQSxRQUFRQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQVQvREg7UUFBQ0EsZ0JBQUtBLENBQUNBLFFBQVFBLENBQUNBOztPQUFDQSxnREFBT0EsVUFBU0E7SUFDakNBO1FBQUNBLGlCQUFNQSxDQUFDQSxTQUFTQSxDQUFDQTs7T0FBQ0EsOENBQUtBLFVBQXNCQTtJQUU5Q0E7UUFBQ0Esc0JBQVdBLENBQUNBLGNBQWNBLENBQUNBOztPQUFDQSwrQ0FBTUEsVUFBU0E7SUFDNUNBO1FBQUNBLHVCQUFZQSxDQUFDQSxPQUFPQSxFQUFFQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQTs7OztPQUN6Q0EsZ0RBQU9BLFFBRU5BO0lBWEhBO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxzQkFBc0JBLEVBQUNBLENBQUNBOztvQ0FjN0NBO0lBQURBLGtDQUFDQTtBQUFEQSxDQUFDQSxBQWRELElBY0M7QUFFRDtJQUFBSTtJQUdBQyxDQUFDQTtJQUhERDtRQUFDQSxvQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsVUFBVUEsRUFBQ0EsQ0FBQ0E7O2dCQUdqQ0E7SUFBREEsY0FBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXN5bmNUZXN0Q29tcGxldGVyLFxuICBiZWZvcmVFYWNoLFxuICBkZGVzY3JpYmUsXG4gIHhkZXNjcmliZSxcbiAgZGVzY3JpYmUsXG4gIGVsLFxuICBkaXNwYXRjaEV2ZW50LFxuICBleHBlY3QsXG4gIGlpdCxcbiAgaW5qZWN0LFxuICBiZWZvcmVFYWNoUHJvdmlkZXJzLFxuICBpdCxcbiAgeGl0LFxuICBjb250YWluc1JlZ2V4cCxcbiAgc3RyaW5naWZ5RWxlbWVudCxcbiAgVGVzdENvbXBvbmVudEJ1aWxkZXIsXG4gIGZha2VBc3luYyxcbiAgdGljayxcbiAgY2xlYXJQZW5kaW5nVGltZXJzLFxuICBDb21wb25lbnRGaXh0dXJlXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5cbmltcG9ydCB7RE9NfSBmcm9tICdhbmd1bGFyMi9zcmMvcGxhdGZvcm0vZG9tL2RvbV9hZGFwdGVyJztcbmltcG9ydCB7XG4gIFR5cGUsXG4gIGlzUHJlc2VudCxcbiAgYXNzZXJ0aW9uc0VuYWJsZWQsXG4gIGlzSnNPYmplY3QsXG4gIGdsb2JhbCxcbiAgc3RyaW5naWZ5LFxuICBpc0JsYW5rLFxuICBDT05TVCxcbiAgQ09OU1RfRVhQUlxufSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2xhbmcnO1xuaW1wb3J0IHtCYXNlRXhjZXB0aW9uLCBXcmFwcGVkRXhjZXB0aW9ufSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2V4Y2VwdGlvbnMnO1xuaW1wb3J0IHtcbiAgUHJvbWlzZVdyYXBwZXIsXG4gIEV2ZW50RW1pdHRlcixcbiAgT2JzZXJ2YWJsZVdyYXBwZXIsXG4gIFByb21pc2VDb21wbGV0ZXIsXG59IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvYXN5bmMnO1xuXG5pbXBvcnQge1xuICBJbmplY3RvcixcbiAgYmluZCxcbiAgcHJvdmlkZSxcbiAgSW5qZWN0YWJsZSxcbiAgUHJvdmlkZXIsXG4gIGZvcndhcmRSZWYsXG4gIE9wYXF1ZVRva2VuLFxuICBJbmplY3QsXG4gIEhvc3QsXG4gIFNraXBTZWxmLFxuICBTa2lwU2VsZk1ldGFkYXRhLFxuICBPbkRlc3Ryb3lcbn0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5cbmltcG9ydCB7TmdJZiwgTmdGb3J9IGZyb20gJ2FuZ3VsYXIyL2NvbW1vbic7XG5cbmltcG9ydCB7QXN5bmNQaXBlfSBmcm9tICdhbmd1bGFyMi9jb21tb24nO1xuXG5pbXBvcnQge1xuICBQaXBlVHJhbnNmb3JtLFxuICBDaGFuZ2VEZXRlY3RvclJlZixcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIENoYW5nZURldGVjdG9yR2VuQ29uZmlnXG59IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2NoYW5nZV9kZXRlY3Rpb24vY2hhbmdlX2RldGVjdGlvbic7XG5cbmltcG9ydCB7XG4gIERpcmVjdGl2ZSxcbiAgQ29tcG9uZW50LFxuICBWaWV3TWV0YWRhdGEsXG4gIEF0dHJpYnV0ZSxcbiAgUXVlcnksXG4gIFBpcGUsXG4gIElucHV0LFxuICBPdXRwdXQsXG4gIEhvc3RCaW5kaW5nLFxuICBIb3N0TGlzdGVuZXJcbn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvbWV0YWRhdGEnO1xuXG5pbXBvcnQge1F1ZXJ5TGlzdH0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvbGlua2VyL3F1ZXJ5X2xpc3QnO1xuXG5pbXBvcnQge1ZpZXdDb250YWluZXJSZWZ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci92aWV3X2NvbnRhaW5lcl9yZWYnO1xuaW1wb3J0IHtFbWJlZGRlZFZpZXdSZWZ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci92aWV3X3JlZic7XG5cbmltcG9ydCB7Q29tcGlsZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci9jb21waWxlcic7XG5pbXBvcnQge0VsZW1lbnRSZWZ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci9lbGVtZW50X3JlZic7XG5pbXBvcnQge1RlbXBsYXRlUmVmfSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9saW5rZXIvdGVtcGxhdGVfcmVmJztcblxuaW1wb3J0IHtSZW5kZXJlcn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvcmVuZGVyJztcbmltcG9ydCB7SVNfREFSVH0gZnJvbSAnYW5ndWxhcjIvc3JjL2ZhY2FkZS9sYW5nJztcblxuY29uc3QgQU5DSE9SX0VMRU1FTlQgPSBDT05TVF9FWFBSKG5ldyBPcGFxdWVUb2tlbignQW5jaG9yRWxlbWVudCcpKTtcblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGlmIChJU19EQVJUKSB7XG4gICAgZGVjbGFyZVRlc3RzKCk7XG4gIH0gZWxzZSB7XG4gICAgZGVzY3JpYmUoJ25vIGppdCcsICgpID0+IHtcbiAgICAgIGJlZm9yZUVhY2hQcm92aWRlcnMoKCkgPT4gW1xuICAgICAgICBwcm92aWRlKENoYW5nZURldGVjdG9yR2VuQ29uZmlnLFxuICAgICAgICAgICAgICAgIHt1c2VWYWx1ZTogbmV3IENoYW5nZURldGVjdG9yR2VuQ29uZmlnKHRydWUsIGZhbHNlLCBmYWxzZSl9KVxuICAgICAgXSk7XG4gICAgICBkZWNsYXJlVGVzdHMoKTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKCdqaXQnLCAoKSA9PiB7XG4gICAgICBiZWZvcmVFYWNoUHJvdmlkZXJzKCgpID0+IFtcbiAgICAgICAgcHJvdmlkZShDaGFuZ2VEZXRlY3RvckdlbkNvbmZpZyxcbiAgICAgICAgICAgICAgICB7dXNlVmFsdWU6IG5ldyBDaGFuZ2VEZXRlY3RvckdlbkNvbmZpZyh0cnVlLCBmYWxzZSwgdHJ1ZSl9KVxuICAgICAgXSk7XG4gICAgICBkZWNsYXJlVGVzdHMoKTtcbiAgICB9KTtcbiAgfVxufVxuXG5mdW5jdGlvbiBkZWNsYXJlVGVzdHMoKSB7XG4gIGRlc2NyaWJlKCdpbnRlZ3JhdGlvbiB0ZXN0cycsIGZ1bmN0aW9uKCkge1xuXG4gICAgYmVmb3JlRWFjaFByb3ZpZGVycygoKSA9PiBbcHJvdmlkZShBTkNIT1JfRUxFTUVOVCwge3VzZVZhbHVlOiBlbCgnPGRpdj48L2Rpdj4nKX0pXSk7XG5cbiAgICBkZXNjcmliZSgncmVhY3QgdG8gcmVjb3JkIGNoYW5nZXMnLCBmdW5jdGlvbigpIHtcbiAgICAgIGl0KCdzaG91bGQgY29uc3VtZSB0ZXh0IG5vZGUgY2hhbmdlcycsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe3RlbXBsYXRlOiAnPGRpdj57e2N0eFByb3B9fTwvZGl2Pid9KSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jdHhQcm9wID0gJ0hlbGxvIFdvcmxkISc7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdIZWxsbyBXb3JsZCEnKTtcbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgdXBkYXRlIHRleHQgbm9kZSB3aXRoIGEgYmxhbmsgc3RyaW5nIHdoZW4gaW50ZXJwb2xhdGlvbiBldmFsdWF0ZXMgdG8gbnVsbCcsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe3RlbXBsYXRlOiAnPGRpdj57e251bGx9fXt7Y3R4UHJvcH19PC9kaXY+J30pKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eFByb3AgPSBudWxsO1xuXG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnJyk7XG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIGNvbnN1bWUgZWxlbWVudCBiaW5kaW5nIGNoYW5nZXMnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHt0ZW1wbGF0ZTogJzxkaXYgW2lkXT1cImN0eFByb3BcIj48L2Rpdj4nfSkpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcblxuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jdHhQcm9wID0gJ0hlbGxvIFdvcmxkISc7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5uYXRpdmVFbGVtZW50LmlkKS50b0VxdWFsKCdIZWxsbyBXb3JsZCEnKTtcbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgY29uc3VtZSBiaW5kaW5nIHRvIGFyaWEtKiBhdHRyaWJ1dGVzJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuZXcgVmlld01ldGFkYXRhKHt0ZW1wbGF0ZTogJzxkaXYgW2F0dHIuYXJpYS1sYWJlbF09XCJjdHhQcm9wXCI+PC9kaXY+J30pKVxuXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UuY3R4UHJvcCA9ICdJbml0aWFsIGFyaWEgbGFiZWwnO1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KFxuICAgICAgICAgICAgICAgICAgICAgRE9NLmdldEF0dHJpYnV0ZShmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5uYXRpdmVFbGVtZW50LCAnYXJpYS1sYWJlbCcpKVxuICAgICAgICAgICAgICAgICAgICAgLnRvRXF1YWwoJ0luaXRpYWwgYXJpYSBsYWJlbCcpO1xuXG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eFByb3AgPSAnQ2hhbmdlZCBhcmlhIGxhYmVsJztcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChcbiAgICAgICAgICAgICAgICAgICAgIERPTS5nZXRBdHRyaWJ1dGUoZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0ubmF0aXZlRWxlbWVudCwgJ2FyaWEtbGFiZWwnKSlcbiAgICAgICAgICAgICAgICAgICAgIC50b0VxdWFsKCdDaGFuZ2VkIGFyaWEgbGFiZWwnKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCByZW1vdmUgYW4gYXR0cmlidXRlIHdoZW4gYXR0cmlidXRlIGV4cHJlc3Npb24gZXZhbHVhdGVzIHRvIG51bGwnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5ldyBWaWV3TWV0YWRhdGEoe3RlbXBsYXRlOiAnPGRpdiBbYXR0ci5mb29dPVwiY3R4UHJvcFwiPjwvZGl2Pid9KSlcblxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UuY3R4UHJvcCA9ICdiYXInO1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5nZXRBdHRyaWJ1dGUoZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0ubmF0aXZlRWxlbWVudCwgJ2ZvbycpKVxuICAgICAgICAgICAgICAgICAgICAgLnRvRXF1YWwoJ2JhcicpO1xuXG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eFByb3AgPSBudWxsO1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5oYXNBdHRyaWJ1dGUoZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0ubmF0aXZlRWxlbWVudCwgJ2ZvbycpKVxuICAgICAgICAgICAgICAgICAgICAgLnRvQmVGYWxzeSgpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIHJlbW92ZSBzdHlsZSB3aGVuIHdoZW4gc3R5bGUgZXhwcmVzc2lvbiBldmFsdWF0ZXMgdG8gbnVsbCcsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6ICc8ZGl2IFtzdHlsZS5oZWlnaHQucHhdPVwiY3R4UHJvcFwiPjwvZGl2Pid9KSlcblxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UuY3R4UHJvcCA9ICcxMCc7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoRE9NLmdldFN0eWxlKGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLm5hdGl2ZUVsZW1lbnQsICdoZWlnaHQnKSlcbiAgICAgICAgICAgICAgICAgICAgIC50b0VxdWFsKCcxMHB4Jyk7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UuY3R4UHJvcCA9IG51bGw7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoRE9NLmdldFN0eWxlKGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLm5hdGl2ZUVsZW1lbnQsICdoZWlnaHQnKSlcbiAgICAgICAgICAgICAgICAgICAgIC50b0VxdWFsKCcnKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBjb25zdW1lIGJpbmRpbmcgdG8gcHJvcGVydHkgbmFtZXMgd2hlcmUgYXR0ciBuYW1lIGFuZCBwcm9wZXJ0eSBuYW1lIGRvIG5vdCBtYXRjaCcsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6ICc8ZGl2IFt0YWJpbmRleF09XCJjdHhOdW1Qcm9wXCI+PC9kaXY+J30pKVxuXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcblxuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLm5hdGl2ZUVsZW1lbnQudGFiSW5kZXgpLnRvRXF1YWwoMCk7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UuY3R4TnVtUHJvcCA9IDU7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0ubmF0aXZlRWxlbWVudC50YWJJbmRleCkudG9FcXVhbCg1KTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBjb25zdW1lIGJpbmRpbmcgdG8gY2FtZWwtY2FzZWQgcHJvcGVydGllcycsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6ICc8aW5wdXQgW3JlYWRPbmx5XT1cImN0eEJvb2xQcm9wXCI+J30pKVxuXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcblxuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLm5hdGl2ZUVsZW1lbnQucmVhZE9ubHkpLnRvQmVGYWxzeSgpO1xuXG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eEJvb2xQcm9wID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5uYXRpdmVFbGVtZW50LnJlYWRPbmx5KS50b0JlVHJ1dGh5KCk7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgY29uc3VtZSBiaW5kaW5nIHRvIGlubmVySHRtbCcsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6ICc8ZGl2IGlubmVySHRtbD1cInt7Y3R4UHJvcH19XCI+PC9kaXY+J30pKVxuXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcblxuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jdHhQcm9wID0gJ1NvbWUgPHNwYW4+SFRNTDwvc3Bhbj4nO1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5nZXRJbm5lckhUTUwoZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0ubmF0aXZlRWxlbWVudCkpXG4gICAgICAgICAgICAgICAgICAgICAudG9FcXVhbCgnU29tZSA8c3Bhbj5IVE1MPC9zcGFuPicpO1xuXG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eFByb3AgPSAnU29tZSBvdGhlciA8ZGl2PkhUTUw8L2Rpdj4nO1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5nZXRJbm5lckhUTUwoZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0ubmF0aXZlRWxlbWVudCkpXG4gICAgICAgICAgICAgICAgICAgICAudG9FcXVhbCgnU29tZSBvdGhlciA8ZGl2PkhUTUw8L2Rpdj4nKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBjb25zdW1lIGJpbmRpbmcgdG8gY2xhc3NOYW1lIHVzaW5nIGNsYXNzIGFsaWFzJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgICAgTXlDb21wLFxuICAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6ICc8ZGl2IGNsYXNzPVwiaW5pdGlhbFwiIFtjbGFzc109XCJjdHhQcm9wXCI+PC9kaXY+J30pKVxuXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgdmFyIG5hdGl2ZUVsID0gZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0ubmF0aXZlRWxlbWVudDtcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UuY3R4UHJvcCA9ICdmb28gYmFyJztcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KG5hdGl2ZUVsKS50b0hhdmVDc3NDbGFzcygnZm9vJyk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChuYXRpdmVFbCkudG9IYXZlQ3NzQ2xhc3MoJ2JhcicpO1xuICAgICAgICAgICAgICAgICBleHBlY3QobmF0aXZlRWwpLm5vdC50b0hhdmVDc3NDbGFzcygnaW5pdGlhbCcpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIGNvbnN1bWUgZGlyZWN0aXZlIHdhdGNoIGV4cHJlc3Npb24gY2hhbmdlLicsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdmFyIHRwbCA9ICc8c3Bhbj4nICtcbiAgICAgICAgICAgICAgICAgICAgICc8ZGl2IG15LWRpciBbZWxwcm9wXT1cImN0eFByb3BcIj48L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICc8ZGl2IG15LWRpciBlbHByb3A9XCJIaSB0aGVyZSFcIj48L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICc8ZGl2IG15LWRpciBlbHByb3A9XCJIaSB7e1xcJ3RoZXJlIVxcJ319XCI+PC9kaXY+JyArXG4gICAgICAgICAgICAgICAgICAgICAnPGRpdiBteS1kaXIgZWxwcm9wPVwiT25lIG1vcmUge3tjdHhQcm9wfX1cIj48L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICc8L3NwYW4+JztcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe3RlbXBsYXRlOiB0cGwsIGRpcmVjdGl2ZXM6IFtNeURpcl19KSlcblxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eFByb3AgPSAnSGVsbG8gV29ybGQhJztcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgdmFyIGNvbnRhaW5lclNwYW4gPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXTtcblxuICAgICAgICAgICAgICAgICBleHBlY3QoY29udGFpbmVyU3Bhbi5jaGlsZHJlblswXS5pbmplY3QoTXlEaXIpLmRpclByb3ApLnRvRXF1YWwoJ0hlbGxvIFdvcmxkIScpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoY29udGFpbmVyU3Bhbi5jaGlsZHJlblsxXS5pbmplY3QoTXlEaXIpLmRpclByb3ApLnRvRXF1YWwoJ0hpIHRoZXJlIScpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoY29udGFpbmVyU3Bhbi5jaGlsZHJlblsyXS5pbmplY3QoTXlEaXIpLmRpclByb3ApLnRvRXF1YWwoJ0hpIHRoZXJlIScpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoY29udGFpbmVyU3Bhbi5jaGlsZHJlblszXS5pbmplY3QoTXlEaXIpLmRpclByb3ApXG4gICAgICAgICAgICAgICAgICAgICAudG9FcXVhbCgnT25lIG1vcmUgSGVsbG8gV29ybGQhJyk7XG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBkZXNjcmliZSgncGlwZXMnLCAoKSA9PiB7XG4gICAgICAgIGl0KFwic2hvdWxkIHN1cHBvcnQgcGlwZXMgaW4gYmluZGluZ3NcIixcbiAgICAgICAgICAgaW5qZWN0KFxuICAgICAgICAgICAgICAgW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhcbiAgICAgICAgICAgICAgICAgICAgICAgIE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPGRpdiBteS1kaXIgI2Rpcj1cIm15ZGlyXCIgW2VscHJvcF09XCJjdHhQcm9wIHwgZG91YmxlXCI+PC9kaXY+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW015RGlyXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGlwZXM6IFtEb3VibGVQaXBlXVxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG5cbiAgICAgICAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jdHhQcm9wID0gJ2EnO1xuICAgICAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGlyID0gZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uZ2V0TG9jYWwoJ2RpcicpO1xuICAgICAgICAgICAgICAgICAgICAgICBleHBlY3QoZGlyLmRpclByb3ApLnRvRXF1YWwoJ2FhJyk7XG4gICAgICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgfSkpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCBuZXN0ZWQgY29tcG9uZW50cy4nLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoXG4gICAgICAgICAgICAgICAgICBNeUNvbXAsXG4gICAgICAgICAgICAgICAgICBuZXcgVmlld01ldGFkYXRhKHt0ZW1wbGF0ZTogJzxjaGlsZC1jbXA+PC9jaGlsZC1jbXA+JywgZGlyZWN0aXZlczogW0NoaWxkQ29tcF19KSlcblxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ2hlbGxvJyk7XG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICAvLyBHSCBpc3N1ZSAzMjggLSBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2lzc3Vlcy8zMjhcbiAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCBkaWZmZXJlbnQgZGlyZWN0aXZlIHR5cGVzIG9uIGEgc2luZ2xlIG5vZGUnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPGNoaWxkLWNtcCBteS1kaXIgW2VscHJvcF09XCJjdHhQcm9wXCI+PC9jaGlsZC1jbXA+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtNeURpciwgQ2hpbGRDb21wXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcblxuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jdHhQcm9wID0gJ0hlbGxvIFdvcmxkISc7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIHZhciB0YyA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdCh0Yy5pbmplY3QoTXlEaXIpLmRpclByb3ApLnRvRXF1YWwoJ0hlbGxvIFdvcmxkIScpO1xuICAgICAgICAgICAgICAgICBleHBlY3QodGMuaW5qZWN0KENoaWxkQ29tcCkuZGlyUHJvcCkudG9FcXVhbChudWxsKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IGRpcmVjdGl2ZXMgd2hlcmUgYSBiaW5kaW5nIGF0dHJpYnV0ZSBpcyBub3QgZ2l2ZW4nLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE5vIGF0dHJpYnV0ZSBcImVsLXByb3BcIiBzcGVjaWZpZWQuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJzxwIG15LWRpcj48L3A+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtNeURpcl1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7IGFzeW5jLmRvbmUoKTsgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgZXhlY3V0ZSBhIGdpdmVuIGRpcmVjdGl2ZSBvbmNlLCBldmVuIGlmIHNwZWNpZmllZCBtdWx0aXBsZSB0aW1lcycsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhcbiAgICAgICAgICAgICAgICAgIE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPHAgbm8tZHVwbGljYXRlPjwvcD4nLFxuICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbRHVwbGljYXRlRGlyLCBEdXBsaWNhdGVEaXIsIFtEdXBsaWNhdGVEaXIsIFtEdXBsaWNhdGVEaXJdXV1cbiAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdub2R1cGxpY2F0ZScpO1xuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IGRpcmVjdGl2ZXMgd2hlcmUgYSBzZWxlY3RvciBtYXRjaGVzIHByb3BlcnR5IGJpbmRpbmcnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0ZW1wbGF0ZTogJzxwIFtpZF09XCJjdHhQcm9wXCI+PC9wPicsIGRpcmVjdGl2ZXM6IFtJZERpcl19KSlcblxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIHZhciB0YyA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdO1xuICAgICAgICAgICAgICAgICB2YXIgaWREaXIgPSB0Yy5pbmplY3QoSWREaXIpO1xuXG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eFByb3AgPSAnc29tZV9pZCc7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoaWREaXIuaWQpLnRvRXF1YWwoJ3NvbWVfaWQnKTtcblxuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jdHhQcm9wID0gJ290aGVyX2lkJztcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChpZERpci5pZCkudG9FcXVhbCgnb3RoZXJfaWQnKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IGRpcmVjdGl2ZXMgd2hlcmUgYSBzZWxlY3RvciBtYXRjaGVzIGV2ZW50IGJpbmRpbmcnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoXG4gICAgICAgICAgICAgICAgICBNeUNvbXAsXG4gICAgICAgICAgICAgICAgICBuZXcgVmlld01ldGFkYXRhKFxuICAgICAgICAgICAgICAgICAgICAgIHt0ZW1wbGF0ZTogJzxwIChjdXN0b21FdmVudCk9XCJkb05vdGhpbmcoKVwiPjwvcD4nLCBkaXJlY3RpdmVzOiBbRXZlbnREaXJdfSkpXG5cbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICB2YXIgdGMgPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KHRjLmluamVjdChFdmVudERpcikpLm5vdC50b0JlKG51bGwpO1xuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCByZWFkIGRpcmVjdGl2ZXMgbWV0YWRhdGEgZnJvbSB0aGVpciBiaW5kaW5nIHRva2VuJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJzxkaXYgcHVibGljLWFwaT48ZGl2IG5lZWRzLXB1YmxpYy1hcGk+PC9kaXY+PC9kaXY+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtQcml2YXRlSW1wbCwgTmVlZHNQdWJsaWNBcGldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG5cbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4geyBhc3luYy5kb25lKCk7IH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIHN1cHBvcnQgdGVtcGxhdGUgZGlyZWN0aXZlcyB2aWEgYDx0ZW1wbGF0ZT5gIGVsZW1lbnRzLicsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhcbiAgICAgICAgICAgICAgICAgIE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOlxuICAgICAgICAgICAgICAgICAgICAgICAgJzx0ZW1wbGF0ZSBzb21lLXZpZXdwb3J0IHZhci1ncmVldGluZz1cInNvbWUtdG1wbFwiPjxjb3B5LW1lPnt7Z3JlZXRpbmd9fTwvY29weS1tZT48L3RlbXBsYXRlPicsXG4gICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtTb21lVmlld3BvcnRdXG4gICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgdmFyIGNoaWxkTm9kZXNPZldyYXBwZXIgPSBET00uY2hpbGROb2RlcyhmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KTtcbiAgICAgICAgICAgICAgICAgLy8gMSB0ZW1wbGF0ZSArIDIgY29waWVzLlxuICAgICAgICAgICAgICAgICBleHBlY3QoY2hpbGROb2Rlc09mV3JhcHBlci5sZW5ndGgpLnRvQmUoMyk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChjaGlsZE5vZGVzT2ZXcmFwcGVyWzFdKS50b0hhdmVUZXh0KCdoZWxsbycpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoY2hpbGROb2Rlc09mV3JhcHBlclsyXSkudG9IYXZlVGV4dCgnYWdhaW4nKTtcbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgdXNlIGEgY29tbWVudCB3aGlsZSBzdGFtcGluZyBvdXQgYDx0ZW1wbGF0ZT5gIGVsZW1lbnRzLicsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe3RlbXBsYXRlOiAnPHRlbXBsYXRlPjwvdGVtcGxhdGU+J30pKVxuXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgdmFyIGNoaWxkTm9kZXNPZldyYXBwZXIgPSBET00uY2hpbGROb2RlcyhmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGNoaWxkTm9kZXNPZldyYXBwZXIubGVuZ3RoKS50b0JlKDEpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoRE9NLmlzQ29tbWVudE5vZGUoY2hpbGROb2Rlc09mV3JhcHBlclswXSkpLnRvQmUodHJ1ZSk7XG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIHN1cHBvcnQgdGVtcGxhdGUgZGlyZWN0aXZlcyB2aWEgYHRlbXBsYXRlYCBhdHRyaWJ1dGUuJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgICAgTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6XG4gICAgICAgICAgICAgICAgICAgICAgICAnPGNvcHktbWUgdGVtcGxhdGU9XCJzb21lLXZpZXdwb3J0OiB2YXIgZ3JlZXRpbmc9c29tZS10bXBsXCI+e3tncmVldGluZ319PC9jb3B5LW1lPicsXG4gICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtTb21lVmlld3BvcnRdXG4gICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIHZhciBjaGlsZE5vZGVzT2ZXcmFwcGVyID0gRE9NLmNoaWxkTm9kZXMoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCk7XG4gICAgICAgICAgICAgICAgIC8vIDEgdGVtcGxhdGUgKyAyIGNvcGllcy5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KGNoaWxkTm9kZXNPZldyYXBwZXIubGVuZ3RoKS50b0JlKDMpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoY2hpbGROb2Rlc09mV3JhcHBlclsxXSkudG9IYXZlVGV4dCgnaGVsbG8nKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGNoaWxkTm9kZXNPZldyYXBwZXJbMl0pLnRvSGF2ZVRleHQoJ2FnYWluJyk7XG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIGFsbG93IHRvIHRyYW5zcGxhbnQgZW1iZWRkZWQgUHJvdG9WaWV3cyBpbnRvIG90aGVyIFZpZXdDb250YWluZXJzJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgICAgTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6XG4gICAgICAgICAgICAgICAgICAgICAgICAnPHNvbWUtZGlyZWN0aXZlPjx0b29sYmFyPjx0ZW1wbGF0ZSB0b29sYmFycGFydCB2YXItdG9vbGJhclByb3A9XCJ0b29sYmFyUHJvcFwiPnt7Y3R4UHJvcH19LHt7dG9vbGJhclByb3B9fSw8Y21wLXdpdGgtaG9zdD48L2NtcC13aXRoLWhvc3Q+PC90ZW1wbGF0ZT48L3Rvb2xiYXI+PC9zb21lLWRpcmVjdGl2ZT4nLFxuICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbU29tZURpcmVjdGl2ZSwgQ29tcFdpdGhIb3N0LCBUb29sYmFyQ29tcG9uZW50LCBUb29sYmFyUGFydF1cbiAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eFByb3AgPSAnRnJvbSBteUNvbXAnO1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudClcbiAgICAgICAgICAgICAgICAgICAgIC50b0hhdmVUZXh0KFxuICAgICAgICAgICAgICAgICAgICAgICAgICdUT09MQkFSKEZyb20gbXlDb21wLEZyb20gdG9vbGJhcixDb21wb25lbnQgd2l0aCBhbiBpbmplY3RlZCBob3N0KScpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBkZXNjcmliZShcInZhcmlhYmxlIGJpbmRpbmdzXCIsICgpID0+IHtcbiAgICAgICAgaXQoJ3Nob3VsZCBhc3NpZ24gYSBjb21wb25lbnQgdG8gYSB2YXItJyxcbiAgICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSxcbiAgICAgICAgICAgICAgICAgICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8cD48Y2hpbGQtY21wIHZhci1hbGljZT48L2NoaWxkLWNtcD48L3A+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW0NoaWxkQ29tcF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmNoaWxkcmVuWzBdLmdldExvY2FsKCdhbGljZScpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9CZUFuSW5zdGFuY2VPZihDaGlsZENvbXApO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9KX0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIGFzc2lnbiBhIGRpcmVjdGl2ZSB0byBhIHZhci0nLFxuICAgICAgICAgICBpbmplY3QoXG4gICAgICAgICAgICAgICBbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJzxkaXY+PGRpdiBleHBvcnQtZGlyICNsb2NhbGRpcj1cImRpclwiPjwvZGl2PjwvZGl2PicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbRXhwb3J0RGlyXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuXG4gICAgICAgICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmNoaWxkcmVuWzBdLmdldExvY2FsKCdsb2NhbGRpcicpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvQmVBbkluc3RhbmNlT2YoRXhwb3J0RGlyKTtcblxuICAgICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgIH0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIG1ha2UgdGhlIGFzc2lnbmVkIGNvbXBvbmVudCBhY2Nlc3NpYmxlIGluIHByb3BlcnR5IGJpbmRpbmdzJyxcbiAgICAgICAgICAgaW5qZWN0KFxuICAgICAgICAgICAgICAgW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLFxuICAgICAgICAgICAgICAgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJzxwPjxjaGlsZC1jbXAgdmFyLWFsaWNlPjwvY2hpbGQtY21wPnt7YWxpY2UuY3R4UHJvcH19PC9wPicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW0NoaWxkQ29tcF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG5cbiAgICAgICAgICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9IYXZlVGV4dCgnaGVsbG9oZWxsbycpOyAgLy8gdGhpcyBmaXJzdCBvbmUgaXMgdGhlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb21wb25lbnQsIHRoZSBzZWNvbmQgb25lIGlzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB0aGUgdGV4dCBiaW5kaW5nXG4gICAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICB9KX0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIGFzc2lnbiB0d28gY29tcG9uZW50IGluc3RhbmNlcyBlYWNoIHdpdGggYSB2YXItJyxcbiAgICAgICAgICAgaW5qZWN0KFxuICAgICAgICAgICAgICAgW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLFxuICAgICAgICAgICAgICAgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJzxwPjxjaGlsZC1jbXAgdmFyLWFsaWNlPjwvY2hpbGQtY21wPjxjaGlsZC1jbXAgdmFyLWJvYj48L2NoaWxkLWNtcD48L3A+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbQ2hpbGRDb21wXVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjaGlsZENtcCA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmNoaWxkcmVuWzBdO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGNoaWxkQ21wLmdldExvY2FsKCdhbGljZScpKS50b0JlQW5JbnN0YW5jZU9mKENoaWxkQ29tcCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGNoaWxkQ21wLmdldExvY2FsKCdib2InKSkudG9CZUFuSW5zdGFuY2VPZihDaGlsZENvbXApO1xuICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChjaGlsZENtcC5nZXRMb2NhbCgnYWxpY2UnKSkubm90LnRvQmUoY2hpbGRDbXAuZ2V0TG9jYWwoJ2JvYicpKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgfSl9KSk7XG5cbiAgICAgICAgaXQoJ3Nob3VsZCBhc3NpZ24gdGhlIGNvbXBvbmVudCBpbnN0YW5jZSB0byBhIHZhci0gd2l0aCBzaG9ydGhhbmQgc3ludGF4JyxcbiAgICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSxcbiAgICAgICAgICAgICAgICAgICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLFxuICAgICAgICAgICAgICAgICAgIGFzeW5jKSA9PiB7dGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPGNoaWxkLWNtcCAjYWxpY2U+PC9jaGlsZC1jbXA+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbQ2hpbGRDb21wXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmdldExvY2FsKCdhbGljZScpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0JlQW5JbnN0YW5jZU9mKENoaWxkQ29tcCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIGFzc2lnbiB0aGUgZWxlbWVudCBpbnN0YW5jZSB0byBhIHVzZXItZGVmaW5lZCB2YXJpYWJsZScsXG4gICAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sXG4gICAgICAgICAgICAgICAgICAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPGRpdj48ZGl2IHZhci1hbGljZT48aT5IZWxsbzwvaT48L2Rpdj48L2Rpdj4nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHZhbHVlID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uY2hpbGRyZW5bMF0uZ2V0TG9jYWwoJ2FsaWNlJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KHZhbHVlKS5ub3QudG9CZShudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBlY3QodmFsdWUudGFnTmFtZS50b0xvd2VyQ2FzZSgpKS50b0VxdWFsKCdkaXYnKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9KSk7XG5cbiAgICAgICAgaXQoJ3Nob3VsZCBwcmVzZXJ2ZSBjYXNlJyxcbiAgICAgICAgICAgaW5qZWN0KFxuICAgICAgICAgICAgICAgW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8cD48Y2hpbGQtY21wIHZhci1zdXBlckFsaWNlPjwvY2hpbGQtY21wPjwvcD4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW0NoaWxkQ29tcF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5jaGlsZHJlblswXS5nZXRMb2NhbCgnc3VwZXJBbGljZScpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvQmVBbkluc3RhbmNlT2YoQ2hpbGRDb21wKTtcblxuICAgICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgIH0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIGFsbG93IHRvIHVzZSB2YXJpYWJsZXMgaW4gYSBmb3IgbG9vcCcsXG4gICAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMpID0+IHtcbiAgICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgICAgICBNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAnPHRlbXBsYXRlIG5nRm9yIFtuZ0Zvck9mXT1cIlsxXVwiIHZhci1pPjxjaGlsZC1jbXAtbm8tdGVtcGxhdGUgI2NtcD48L2NoaWxkLWNtcC1uby10ZW1wbGF0ZT57e2l9fS17e2NtcC5jdHhQcm9wfX08L3RlbXBsYXRlPicsXG4gICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW0NoaWxkQ29tcE5vVGVtcGxhdGUsIE5nRm9yXVxuICAgICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICAgIC8vIEdldCB0aGUgZWxlbWVudCBhdCBpbmRleCAyLCBzaW5jZSBpbmRleCAwIGlzIHRoZSA8dGVtcGxhdGU+LlxuICAgICAgICAgICAgICAgICAgIGV4cGVjdChET00uY2hpbGROb2RlcyhmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KVsyXSlcbiAgICAgICAgICAgICAgICAgICAgICAgLnRvSGF2ZVRleHQoXCIxLWhlbGxvXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgfSkpO1xuICAgICAgfSk7XG5cbiAgICAgIGRlc2NyaWJlKFwiT25QdXNoIGNvbXBvbmVudHNcIiwgKCkgPT4ge1xuICAgICAgICBpdChcInNob3VsZCB1c2UgQ2hhbmdlRGV0ZWN0b3JSZWYgdG8gbWFudWFsbHkgcmVxdWVzdCBhIGNoZWNrXCIsXG4gICAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sXG4gICAgICAgICAgICAgICAgICAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcblxuICAgICAgICAgICAgICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8cHVzaC1jbXAtd2l0aC1yZWYgI2NtcD48L3B1c2gtY21wLXdpdGgtcmVmPicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtbW1B1c2hDbXBXaXRoUmVmXV1dXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNtcCA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmdldExvY2FsKCdjbXAnKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChjbXAubnVtYmVyT2ZDaGVja3MpLnRvRXF1YWwoMSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBlY3QoY21wLm51bWJlck9mQ2hlY2tzKS50b0VxdWFsKDEpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY21wLnByb3BhZ2F0ZSgpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGNtcC5udW1iZXJPZkNoZWNrcykudG9FcXVhbCgyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pfSkpO1xuXG4gICAgICAgIGl0KFwic2hvdWxkIGJlIGNoZWNrZWQgd2hlbiBpdHMgYmluZGluZ3MgZ290IHVwZGF0ZWRcIixcbiAgICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSxcbiAgICAgICAgICAgICAgICAgICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuXG4gICAgICAgICAgICAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJzxwdXNoLWNtcCBbcHJvcF09XCJjdHhQcm9wXCIgI2NtcD48L3B1c2gtY21wPicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtbW1B1c2hDbXBdXV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNtcCA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmdldExvY2FsKCdjbXAnKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eFByb3AgPSBcIm9uZVwiO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChjbXAubnVtYmVyT2ZDaGVja3MpLnRvRXF1YWwoMSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jdHhQcm9wID0gXCJ0d29cIjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBlY3QoY21wLm51bWJlck9mQ2hlY2tzKS50b0VxdWFsKDIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9KX0pKTtcblxuICAgICAgICBpZiAoRE9NLnN1cHBvcnRzRE9NRXZlbnRzKCkpIHtcbiAgICAgICAgICBpdChcInNob3VsZCBhbGxvdyB0byBkZXN0cm95IGEgY29tcG9uZW50IGZyb20gd2l0aGluIGEgaG9zdCBldmVudCBoYW5kbGVyXCIsXG4gICAgICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlcl0sIGZha2VBc3luYygodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlcikgPT4ge1xuXG4gICAgICAgICAgICAgICAgICAgICAgdmFyIGZpeHR1cmU6IENvbXBvbmVudEZpeHR1cmU7XG4gICAgICAgICAgICAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJzxwdXNoLWNtcC13aXRoLWhvc3QtZXZlbnQ+PC9wdXNoLWNtcC13aXRoLWhvc3QtZXZlbnQ+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbW1tQdXNoQ21wV2l0aEhvc3RFdmVudF1dXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihyb290ID0+IHsgZml4dHVyZSA9IHJvb3Q7IH0pO1xuICAgICAgICAgICAgICAgICAgICAgIHRpY2soKTtcbiAgICAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICAgICAgIHZhciBjbXBFbCA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdO1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBjbXA6IFB1c2hDbXBXaXRoSG9zdEV2ZW50ID0gY21wRWwuaW5qZWN0KFB1c2hDbXBXaXRoSG9zdEV2ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICBjbXAuY3R4Q2FsbGJhY2sgPSAoXykgPT4gZml4dHVyZS5kZXN0cm95KCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICBleHBlY3QoKCkgPT4gY21wRWwudHJpZ2dlckV2ZW50SGFuZGxlcignY2xpY2snLCA8RXZlbnQ+e30pKS5ub3QudG9UaHJvdygpO1xuICAgICAgICAgICAgICAgICAgICB9KSkpO1xuICAgICAgICB9XG5cbiAgICAgICAgaXQoJ3Nob3VsZCBub3QgYWZmZWN0IHVwZGF0aW5nIHByb3BlcnRpZXMgb24gdGhlIGNvbXBvbmVudCcsXG4gICAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sXG4gICAgICAgICAgICAgICAgICAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnPHB1c2gtY21wLXdpdGgtcmVmIFtwcm9wXT1cImN0eFByb3BcIiAjY21wPjwvcHVzaC1jbXAtd2l0aC1yZWY+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbW1tQdXNoQ21wV2l0aFJlZl1dXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNtcCA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmdldExvY2FsKCdjbXAnKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eFByb3AgPSBcIm9uZVwiO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChjbXAucHJvcCkudG9FcXVhbChcIm9uZVwiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eFByb3AgPSBcInR3b1wiO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChjbXAucHJvcCkudG9FcXVhbChcInR3b1wiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9KSk7XG5cbiAgICAgICAgaWYgKERPTS5zdXBwb3J0c0RPTUV2ZW50cygpKSB7XG4gICAgICAgICAgaXQoJ3Nob3VsZCBiZSBjaGVja2VkIHdoZW4gYW4gYXN5bmMgcGlwZSByZXF1ZXN0cyBhIGNoZWNrJyxcbiAgICAgICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyXSwgZmFrZUFzeW5jKCh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgdGNiID0gdGNiLm92ZXJyaWRlVmlldyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJzxwdXNoLWNtcC13aXRoLWFzeW5jICNjbXA+PC9wdXNoLWNtcC13aXRoLWFzeW5jPicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW1tbUHVzaENtcFdpdGhBc3luY1BpcGVdXV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgdmFyIGZpeHR1cmU6IENvbXBvbmVudEZpeHR1cmU7XG4gICAgICAgICAgICAgICAgICAgICAgdGNiLmNyZWF0ZUFzeW5jKE15Q29tcCkudGhlbihyb290ID0+IHsgZml4dHVyZSA9IHJvb3Q7IH0pO1xuICAgICAgICAgICAgICAgICAgICAgIHRpY2soKTtcblxuICAgICAgICAgICAgICAgICAgICAgIHZhciBjbXA6IFB1c2hDbXBXaXRoQXN5bmNQaXBlID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uZ2V0TG9jYWwoJ2NtcCcpO1xuICAgICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChjbXAubnVtYmVyT2ZDaGVja3MpLnRvRXF1YWwoMSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgICAgICBleHBlY3QoY21wLm51bWJlck9mQ2hlY2tzKS50b0VxdWFsKDEpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgY21wLnJlc29sdmUoMik7XG4gICAgICAgICAgICAgICAgICAgICAgdGljaygpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGNtcC5udW1iZXJPZkNoZWNrcykudG9FcXVhbCgyKTtcbiAgICAgICAgICAgICAgICAgICAgfSkpKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgY3JlYXRlIGEgY29tcG9uZW50IHRoYXQgaW5qZWN0cyBhbiBASG9zdCcsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLFxuICAgICAgICAgICAgICAgICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogYFxuICAgICAgICAgICAgPHNvbWUtZGlyZWN0aXZlPlxuICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICA8Y21wLXdpdGgtaG9zdCAjY2hpbGQ+PC9jbXAtd2l0aC1ob3N0PlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L3NvbWUtZGlyZWN0aXZlPmAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbU29tZURpcmVjdGl2ZSwgQ29tcFdpdGhIb3N0XVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgY2hpbGRDb21wb25lbnQgPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5nZXRMb2NhbCgnY2hpbGQnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGNoaWxkQ29tcG9uZW50Lm15SG9zdCkudG9CZUFuSW5zdGFuY2VPZihTb21lRGlyZWN0aXZlKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KX0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBjcmVhdGUgYSBjb21wb25lbnQgdGhhdCBpbmplY3RzIGFuIEBIb3N0IHRocm91Z2ggdmlld2NvbnRhaW5lciBkaXJlY3RpdmUnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiBgXG4gICAgICAgICAgICA8c29tZS1kaXJlY3RpdmU+XG4gICAgICAgICAgICAgIDxwICpuZ0lmPVwidHJ1ZVwiPlxuICAgICAgICAgICAgICAgIDxjbXAtd2l0aC1ob3N0ICNjaGlsZD48L2NtcC13aXRoLWhvc3Q+XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvc29tZS1kaXJlY3RpdmU+YCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtTb21lRGlyZWN0aXZlLCBDb21wV2l0aEhvc3QsIE5nSWZdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG5cbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICB2YXIgdGMgPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5jaGlsZHJlblswXS5jaGlsZHJlblswXTtcblxuICAgICAgICAgICAgICAgICB2YXIgY2hpbGRDb21wb25lbnQgPSB0Yy5nZXRMb2NhbCgnY2hpbGQnKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGNoaWxkQ29tcG9uZW50Lm15SG9zdCkudG9CZUFuSW5zdGFuY2VPZihTb21lRGlyZWN0aXZlKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IGV2ZW50cyB2aWEgRXZlbnRFbWl0dGVyIG9uIHJlZ3VsYXIgZWxlbWVudHMnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPGRpdiBlbWl0dGVyIGxpc3RlbmVyPjwvZGl2PicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbRGlyZWN0aXZlRW1pdHRpbmdFdmVudCwgRGlyZWN0aXZlTGlzdGVuaW5nRXZlbnRdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG5cbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuXG4gICAgICAgICAgICAgICAgIHZhciB0YyA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdO1xuICAgICAgICAgICAgICAgICB2YXIgZW1pdHRlciA9IHRjLmluamVjdChEaXJlY3RpdmVFbWl0dGluZ0V2ZW50KTtcbiAgICAgICAgICAgICAgICAgdmFyIGxpc3RlbmVyID0gdGMuaW5qZWN0KERpcmVjdGl2ZUxpc3RlbmluZ0V2ZW50KTtcblxuICAgICAgICAgICAgICAgICBleHBlY3QobGlzdGVuZXIubXNnKS50b0VxdWFsKCcnKTtcbiAgICAgICAgICAgICAgICAgdmFyIGV2ZW50Q291bnQgPSAwO1xuXG4gICAgICAgICAgICAgICAgIE9ic2VydmFibGVXcmFwcGVyLnN1YnNjcmliZShlbWl0dGVyLmV2ZW50LCAoXykgPT4ge1xuICAgICAgICAgICAgICAgICAgIGV2ZW50Q291bnQrKztcbiAgICAgICAgICAgICAgICAgICBpZiAoZXZlbnRDb3VudCA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGxpc3RlbmVyLm1zZykudG9FcXVhbCgnZmlyZWQgIScpO1xuICAgICAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXN0cm95KCk7XG4gICAgICAgICAgICAgICAgICAgICBlbWl0dGVyLmZpcmVFdmVudCgnZmlyZWQgYWdhaW4gIScpO1xuICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICBleHBlY3QobGlzdGVuZXIubXNnKS50b0VxdWFsKCdmaXJlZCAhJyk7XG4gICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgICBlbWl0dGVyLmZpcmVFdmVudCgnZmlyZWQgIScpO1xuXG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IGV2ZW50cyB2aWEgRXZlbnRFbWl0dGVyIG9uIHRlbXBsYXRlIGVsZW1lbnRzJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgICAgTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8dGVtcGxhdGUgZW1pdHRlciBsaXN0ZW5lciAoZXZlbnQpPVwiY3R4UHJvcD0kZXZlbnRcIj48L3RlbXBsYXRlPicsXG4gICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtEaXJlY3RpdmVFbWl0dGluZ0V2ZW50LCBEaXJlY3RpdmVMaXN0ZW5pbmdFdmVudF1cbiAgICAgICAgICAgICAgICAgIH0pKVxuXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcblxuICAgICAgICAgICAgICAgICB2YXIgdGMgPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZE5vZGVzWzBdO1xuXG4gICAgICAgICAgICAgICAgIHZhciBlbWl0dGVyID0gdGMuaW5qZWN0KERpcmVjdGl2ZUVtaXR0aW5nRXZlbnQpO1xuICAgICAgICAgICAgICAgICB2YXIgbXlDb21wID0gZml4dHVyZS5kZWJ1Z0VsZW1lbnQuaW5qZWN0KE15Q29tcCk7XG4gICAgICAgICAgICAgICAgIHZhciBsaXN0ZW5lciA9IHRjLmluamVjdChEaXJlY3RpdmVMaXN0ZW5pbmdFdmVudCk7XG5cbiAgICAgICAgICAgICAgICAgbXlDb21wLmN0eFByb3AgPSAnJztcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGxpc3RlbmVyLm1zZykudG9FcXVhbCgnJyk7XG5cbiAgICAgICAgICAgICAgICAgT2JzZXJ2YWJsZVdyYXBwZXIuc3Vic2NyaWJlKGVtaXR0ZXIuZXZlbnQsIChfKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGxpc3RlbmVyLm1zZykudG9FcXVhbCgnZmlyZWQgIScpO1xuICAgICAgICAgICAgICAgICAgIGV4cGVjdChteUNvbXAuY3R4UHJvcCkudG9FcXVhbCgnZmlyZWQgIScpO1xuICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgZW1pdHRlci5maXJlRXZlbnQoJ2ZpcmVkICEnKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIHN1cHBvcnQgWygpXSBzeW50YXgnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPGRpdiBbKGNvbnRyb2wpXT1cImN0eFByb3BcIiB0d28td2F5PjwvZGl2PicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbRGlyZWN0aXZlV2l0aFR3b1dheUJpbmRpbmddXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG5cbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICB2YXIgdGMgPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXTtcbiAgICAgICAgICAgICAgICAgdmFyIGRpciA9IHRjLmluamVjdChEaXJlY3RpdmVXaXRoVHdvV2F5QmluZGluZyk7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UuY3R4UHJvcCA9ICdvbmUnO1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICBleHBlY3QoZGlyLmNvbnRyb2wpLnRvRXF1YWwoJ29uZScpO1xuXG4gICAgICAgICAgICAgICAgIE9ic2VydmFibGVXcmFwcGVyLnN1YnNjcmliZShkaXIuY29udHJvbENoYW5nZSwgKF8pID0+IHtcbiAgICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UuY3R4UHJvcCkudG9FcXVhbCgndHdvJyk7XG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgICBkaXIudHJpZ2dlckNoYW5nZSgndHdvJyk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IHJlbmRlciBldmVudHMnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoXG4gICAgICAgICAgICAgICAgICBNeUNvbXAsXG4gICAgICAgICAgICAgICAgICBuZXcgVmlld01ldGFkYXRhKFxuICAgICAgICAgICAgICAgICAgICAgIHt0ZW1wbGF0ZTogJzxkaXYgbGlzdGVuZXI+PC9kaXY+JywgZGlyZWN0aXZlczogW0RpcmVjdGl2ZUxpc3RlbmluZ0RvbUV2ZW50XX0pKVxuXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcblxuICAgICAgICAgICAgICAgICB2YXIgdGMgPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXTtcbiAgICAgICAgICAgICAgICAgdmFyIGxpc3RlbmVyID0gdGMuaW5qZWN0KERpcmVjdGl2ZUxpc3RlbmluZ0RvbUV2ZW50KTtcblxuICAgICAgICAgICAgICAgICBkaXNwYXRjaEV2ZW50KHRjLm5hdGl2ZUVsZW1lbnQsICdkb21FdmVudCcpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChsaXN0ZW5lci5ldmVudFR5cGVzKVxuICAgICAgICAgICAgICAgICAgICAgLnRvRXF1YWwoXG4gICAgICAgICAgICAgICAgICAgICAgICAgWydkb21FdmVudCcsICdib2R5X2RvbUV2ZW50JywgJ2RvY3VtZW50X2RvbUV2ZW50JywgJ3dpbmRvd19kb21FdmVudCddKTtcblxuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlc3Ryb3koKTtcbiAgICAgICAgICAgICAgICAgbGlzdGVuZXIuZXZlbnRUeXBlcyA9IFtdO1xuICAgICAgICAgICAgICAgICBkaXNwYXRjaEV2ZW50KHRjLm5hdGl2ZUVsZW1lbnQsICdkb21FdmVudCcpO1xuICAgICAgICAgICAgICAgICBleHBlY3QobGlzdGVuZXIuZXZlbnRUeXBlcykudG9FcXVhbChbXSk7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCByZW5kZXIgZ2xvYmFsIGV2ZW50cycsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhcbiAgICAgICAgICAgICAgICAgIE15Q29tcCxcbiAgICAgICAgICAgICAgICAgIG5ldyBWaWV3TWV0YWRhdGEoXG4gICAgICAgICAgICAgICAgICAgICAge3RlbXBsYXRlOiAnPGRpdiBsaXN0ZW5lcj48L2Rpdj4nLCBkaXJlY3RpdmVzOiBbRGlyZWN0aXZlTGlzdGVuaW5nRG9tRXZlbnRdfSkpXG5cbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICB2YXIgdGMgPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXTtcbiAgICAgICAgICAgICAgICAgdmFyIGxpc3RlbmVyID0gdGMuaW5qZWN0KERpcmVjdGl2ZUxpc3RlbmluZ0RvbUV2ZW50KTtcbiAgICAgICAgICAgICAgICAgZGlzcGF0Y2hFdmVudChET00uZ2V0R2xvYmFsRXZlbnRUYXJnZXQoXCJ3aW5kb3dcIiksICdkb21FdmVudCcpO1xuICAgICAgICAgICAgICAgICBleHBlY3QobGlzdGVuZXIuZXZlbnRUeXBlcykudG9FcXVhbChbJ3dpbmRvd19kb21FdmVudCddKTtcblxuICAgICAgICAgICAgICAgICBsaXN0ZW5lci5ldmVudFR5cGVzID0gW107XG4gICAgICAgICAgICAgICAgIGRpc3BhdGNoRXZlbnQoRE9NLmdldEdsb2JhbEV2ZW50VGFyZ2V0KFwiZG9jdW1lbnRcIiksICdkb21FdmVudCcpO1xuICAgICAgICAgICAgICAgICBleHBlY3QobGlzdGVuZXIuZXZlbnRUeXBlcykudG9FcXVhbChbJ2RvY3VtZW50X2RvbUV2ZW50JywgJ3dpbmRvd19kb21FdmVudCddKTtcblxuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlc3Ryb3koKTtcbiAgICAgICAgICAgICAgICAgbGlzdGVuZXIuZXZlbnRUeXBlcyA9IFtdO1xuICAgICAgICAgICAgICAgICBkaXNwYXRjaEV2ZW50KERPTS5nZXRHbG9iYWxFdmVudFRhcmdldChcImJvZHlcIiksICdkb21FdmVudCcpO1xuICAgICAgICAgICAgICAgICBleHBlY3QobGlzdGVuZXIuZXZlbnRUeXBlcykudG9FcXVhbChbXSk7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCB1cGRhdGluZyBob3N0IGVsZW1lbnQgdmlhIGhvc3RBdHRyaWJ1dGVzJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJzxkaXYgdXBkYXRlLWhvc3QtYXR0cmlidXRlcz48L2Rpdj4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW0RpcmVjdGl2ZVVwZGF0aW5nSG9zdEF0dHJpYnV0ZXNdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG5cbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICBleHBlY3QoRE9NLmdldEF0dHJpYnV0ZShmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5uYXRpdmVFbGVtZW50LCBcInJvbGVcIikpXG4gICAgICAgICAgICAgICAgICAgICAudG9FcXVhbChcImJ1dHRvblwiKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IHVwZGF0aW5nIGhvc3QgZWxlbWVudCB2aWEgaG9zdFByb3BlcnRpZXMnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPGRpdiB1cGRhdGUtaG9zdC1wcm9wZXJ0aWVzPjwvZGl2PicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbRGlyZWN0aXZlVXBkYXRpbmdIb3N0UHJvcGVydGllc11cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIHZhciB0YyA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdO1xuICAgICAgICAgICAgICAgICB2YXIgdXBkYXRlSG9zdCA9IHRjLmluamVjdChEaXJlY3RpdmVVcGRhdGluZ0hvc3RQcm9wZXJ0aWVzKTtcblxuICAgICAgICAgICAgICAgICB1cGRhdGVIb3N0LmlkID0gXCJuZXdJZFwiO1xuXG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdCh0Yy5uYXRpdmVFbGVtZW50LmlkKS50b0VxdWFsKFwibmV3SWRcIik7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cblxuICAgICAgaWYgKERPTS5zdXBwb3J0c0RPTUV2ZW50cygpKSB7XG4gICAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCBwcmV2ZW50aW5nIGRlZmF1bHQgb24gcmVuZGVyIGV2ZW50cycsXG4gICAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMpID0+IHtcbiAgICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgICAgICBNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAnPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGxpc3RlbmVycHJldmVudD48aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgbGlzdGVuZXJub3ByZXZlbnQ+JyxcbiAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICBEaXJlY3RpdmVMaXN0ZW5pbmdEb21FdmVudFByZXZlbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICBEaXJlY3RpdmVMaXN0ZW5pbmdEb21FdmVudE5vUHJldmVudFxuICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSkpXG5cbiAgICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgICB2YXIgZGlzcGF0Y2hlZEV2ZW50ID0gRE9NLmNyZWF0ZU1vdXNlRXZlbnQoJ2NsaWNrJyk7XG4gICAgICAgICAgICAgICAgICAgdmFyIGRpc3BhdGNoZWRFdmVudDIgPSBET00uY3JlYXRlTW91c2VFdmVudCgnY2xpY2snKTtcbiAgICAgICAgICAgICAgICAgICBET00uZGlzcGF0Y2hFdmVudChmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5uYXRpdmVFbGVtZW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BhdGNoZWRFdmVudCk7XG4gICAgICAgICAgICAgICAgICAgRE9NLmRpc3BhdGNoRXZlbnQoZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMV0ubmF0aXZlRWxlbWVudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwYXRjaGVkRXZlbnQyKTtcbiAgICAgICAgICAgICAgICAgICBleHBlY3QoRE9NLmlzUHJldmVudGVkKGRpc3BhdGNoZWRFdmVudCkpLnRvQmUodHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5pc1ByZXZlbnRlZChkaXNwYXRjaGVkRXZlbnQyKSkudG9CZShmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5nZXRDaGVja2VkKGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLm5hdGl2ZUVsZW1lbnQpKVxuICAgICAgICAgICAgICAgICAgICAgICAudG9CZUZhbHN5KCk7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5nZXRDaGVja2VkKGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzFdLm5hdGl2ZUVsZW1lbnQpKVxuICAgICAgICAgICAgICAgICAgICAgICAudG9CZVRydXRoeSgpO1xuICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0pKTtcbiAgICAgIH1cblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IHJlbmRlciBnbG9iYWwgZXZlbnRzIGZyb20gbXVsdGlwbGUgZGlyZWN0aXZlcycsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhcbiAgICAgICAgICAgICAgICAgIE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPGRpdiAqbmdJZj1cImN0eEJvb2xQcm9wXCIgbGlzdGVuZXIgbGlzdGVuZXJvdGhlcj48L2Rpdj4nLFxuICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOlxuICAgICAgICAgICAgICAgICAgICAgICAgW05nSWYsIERpcmVjdGl2ZUxpc3RlbmluZ0RvbUV2ZW50LCBEaXJlY3RpdmVMaXN0ZW5pbmdEb21FdmVudE90aGVyXVxuICAgICAgICAgICAgICAgICAgfSkpXG5cbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICBnbG9iYWxDb3VudGVyID0gMDtcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UuY3R4Qm9vbFByb3AgPSB0cnVlO1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICB2YXIgdGMgPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXTtcblxuICAgICAgICAgICAgICAgICB2YXIgbGlzdGVuZXIgPSB0Yy5pbmplY3QoRGlyZWN0aXZlTGlzdGVuaW5nRG9tRXZlbnQpO1xuICAgICAgICAgICAgICAgICB2YXIgbGlzdGVuZXJvdGhlciA9IHRjLmluamVjdChEaXJlY3RpdmVMaXN0ZW5pbmdEb21FdmVudE90aGVyKTtcbiAgICAgICAgICAgICAgICAgZGlzcGF0Y2hFdmVudChET00uZ2V0R2xvYmFsRXZlbnRUYXJnZXQoXCJ3aW5kb3dcIiksICdkb21FdmVudCcpO1xuICAgICAgICAgICAgICAgICBleHBlY3QobGlzdGVuZXIuZXZlbnRUeXBlcykudG9FcXVhbChbJ3dpbmRvd19kb21FdmVudCddKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGxpc3RlbmVyb3RoZXIuZXZlbnRUeXBlKS50b0VxdWFsKCdvdGhlcl9kb21FdmVudCcpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoZ2xvYmFsQ291bnRlcikudG9FcXVhbCgxKTtcblxuXG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eEJvb2xQcm9wID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBkaXNwYXRjaEV2ZW50KERPTS5nZXRHbG9iYWxFdmVudFRhcmdldChcIndpbmRvd1wiKSwgJ2RvbUV2ZW50Jyk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChnbG9iYWxDb3VudGVyKS50b0VxdWFsKDEpO1xuXG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eEJvb2xQcm9wID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgIGRpc3BhdGNoRXZlbnQoRE9NLmdldEdsb2JhbEV2ZW50VGFyZ2V0KFwid2luZG93XCIpLCAnZG9tRXZlbnQnKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGdsb2JhbENvdW50ZXIpLnRvRXF1YWwoMik7XG5cbiAgICAgICAgICAgICAgICAgLy8gbmVlZCB0byBkZXN0cm95IHRvIHJlbGVhc2UgYWxsIHJlbWFpbmluZyBnbG9iYWwgZXZlbnQgbGlzdGVuZXJzXG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVzdHJveSgpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBkZXNjcmliZSgnZHluYW1pYyBWaWV3Q29udGFpbmVycycsICgpID0+IHtcbiAgICAgICAgaXQoJ3Nob3VsZCBhbGxvdyB0byBjcmVhdGUgYSBWaWV3Q29udGFpbmVyUmVmIGF0IGFueSBib3VuZCBsb2NhdGlvbicsXG4gICAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlciwgQ29tcGlsZXJdLFxuICAgICAgICAgICAgICAgICAgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jLCBjb21waWxlcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJzxkaXY+PGR5bmFtaWMtdnAgI2R5bmFtaWM+PC9keW5hbWljLXZwPjwvZGl2PicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbRHluYW1pY1ZpZXdwb3J0XVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHRjID0gZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uY2hpbGRyZW5bMF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBkeW5hbWljVnA6IER5bmFtaWNWaWV3cG9ydCA9IHRjLmluamVjdChEeW5hbWljVmlld3BvcnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBkeW5hbWljVnAuZG9uZS50aGVuKChfKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmNoaWxkcmVuWzFdLm5hdGl2ZUVsZW1lbnQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0hhdmVUZXh0KCdkeW5hbWljIGdyZWV0Jyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IHN0YXRpYyBhdHRyaWJ1dGVzJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgICAgTXlDb21wLFxuICAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YShcbiAgICAgICAgICAgICAgICAgICAgICB7dGVtcGxhdGU6ICc8aW5wdXQgc3RhdGljIHR5cGU9XCJ0ZXh0XCIgdGl0bGU+JywgZGlyZWN0aXZlczogW05lZWRzQXR0cmlidXRlXX0pKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIHZhciB0YyA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdO1xuICAgICAgICAgICAgICAgICB2YXIgbmVlZHNBdHRyaWJ1dGUgPSB0Yy5pbmplY3QoTmVlZHNBdHRyaWJ1dGUpO1xuICAgICAgICAgICAgICAgICBleHBlY3QobmVlZHNBdHRyaWJ1dGUudHlwZUF0dHJpYnV0ZSkudG9FcXVhbCgndGV4dCcpO1xuICAgICAgICAgICAgICAgICBleHBlY3QobmVlZHNBdHRyaWJ1dGUuc3RhdGljQXR0cmlidXRlKS50b0VxdWFsKCcnKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KG5lZWRzQXR0cmlidXRlLmZvb0F0dHJpYnV0ZSkudG9FcXVhbChudWxsKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKFwiZGVwZW5kZW5jeSBpbmplY3Rpb25cIiwgKCkgPT4ge1xuICAgICAgaXQoXCJzaG91bGQgc3VwcG9ydCBiaW5kaW5nc1wiLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoXG4gICAgICAgICAgICAgICAgICBNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogYFxuICAgICAgICAgICAgPGRpcmVjdGl2ZS1wcm92aWRpbmctaW5qZWN0YWJsZSA+XG4gICAgICAgICAgICAgIDxkaXJlY3RpdmUtY29uc3VtaW5nLWluamVjdGFibGUgI2NvbnN1bWluZz5cbiAgICAgICAgICAgICAgPC9kaXJlY3RpdmUtY29uc3VtaW5nLWluamVjdGFibGU+XG4gICAgICAgICAgICA8L2RpcmVjdGl2ZS1wcm92aWRpbmctaW5qZWN0YWJsZT5cbiAgICAgICAgICBgLFxuICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbRGlyZWN0aXZlUHJvdmlkaW5nSW5qZWN0YWJsZSwgRGlyZWN0aXZlQ29uc3VtaW5nSW5qZWN0YWJsZV1cbiAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIHZhciBjb21wID0gZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uZ2V0TG9jYWwoXCJjb25zdW1pbmdcIik7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChjb21wLmluamVjdGFibGUpLnRvQmVBbkluc3RhbmNlT2YoSW5qZWN0YWJsZVNlcnZpY2UpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdChcInNob3VsZCBzdXBwb3J0IHZpZXdQcm92aWRlcnNcIixcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KERpcmVjdGl2ZVByb3ZpZGluZ0luamVjdGFibGVJblZpZXcsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6IGBcbiAgICAgICAgICAgICAgPGRpcmVjdGl2ZS1jb25zdW1pbmctaW5qZWN0YWJsZSAjY29uc3VtaW5nPlxuICAgICAgICAgICAgICA8L2RpcmVjdGl2ZS1jb25zdW1pbmctaW5qZWN0YWJsZT5cbiAgICAgICAgICBgLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW0RpcmVjdGl2ZUNvbnN1bWluZ0luamVjdGFibGVdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoRGlyZWN0aXZlUHJvdmlkaW5nSW5qZWN0YWJsZUluVmlldylcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIHZhciBjb21wID0gZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uZ2V0TG9jYWwoXCJjb25zdW1pbmdcIik7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChjb21wLmluamVjdGFibGUpLnRvQmVBbkluc3RhbmNlT2YoSW5qZWN0YWJsZVNlcnZpY2UpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdChcInNob3VsZCBzdXBwb3J0IHVuYm91bmRlZCBsb29rdXBcIixcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogYFxuICAgICAgICAgICAgPGRpcmVjdGl2ZS1wcm92aWRpbmctaW5qZWN0YWJsZT5cbiAgICAgICAgICAgICAgPGRpcmVjdGl2ZS1jb250YWluaW5nLWRpcmVjdGl2ZS1jb25zdW1pbmctYW4taW5qZWN0YWJsZSAjZGlyPlxuICAgICAgICAgICAgICA8L2RpcmVjdGl2ZS1jb250YWluaW5nLWRpcmVjdGl2ZS1jb25zdW1pbmctYW4taW5qZWN0YWJsZT5cbiAgICAgICAgICAgIDwvZGlyZWN0aXZlLXByb3ZpZGluZy1pbmplY3RhYmxlPlxuICAgICAgICAgIGAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERpcmVjdGl2ZVByb3ZpZGluZ0luamVjdGFibGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERpcmVjdGl2ZUNvbnRhaW5pbmdEaXJlY3RpdmVDb25zdW1pbmdBbkluamVjdGFibGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAgIC5vdmVycmlkZVZpZXcoRGlyZWN0aXZlQ29udGFpbmluZ0RpcmVjdGl2ZUNvbnN1bWluZ0FuSW5qZWN0YWJsZSwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6IGBcbiAgICAgICAgICAgIDxkaXJlY3RpdmUtY29uc3VtaW5nLWluamVjdGFibGUtdW5ib3VuZGVkPjwvZGlyZWN0aXZlLWNvbnN1bWluZy1pbmplY3RhYmxlLXVuYm91bmRlZD5cbiAgICAgICAgICBgLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtEaXJlY3RpdmVDb25zdW1pbmdJbmplY3RhYmxlVW5ib3VuZGVkXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIHZhciBjb21wID0gZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uZ2V0TG9jYWwoXCJkaXJcIik7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChjb21wLmRpcmVjdGl2ZS5pbmplY3RhYmxlKS50b0JlQW5JbnN0YW5jZU9mKEluamVjdGFibGVTZXJ2aWNlKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoXCJzaG91bGQgc3VwcG9ydCB0aGUgZXZlbnQtYnVzIHNjZW5hcmlvXCIsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6IGBcbiAgICAgICAgICAgIDxncmFuZC1wYXJlbnQtcHJvdmlkaW5nLWV2ZW50LWJ1cz5cbiAgICAgICAgICAgICAgPHBhcmVudC1wcm92aWRpbmctZXZlbnQtYnVzPlxuICAgICAgICAgICAgICAgIDxjaGlsZC1jb25zdW1pbmctZXZlbnQtYnVzPlxuICAgICAgICAgICAgICAgIDwvY2hpbGQtY29uc3VtaW5nLWV2ZW50LWJ1cz5cbiAgICAgICAgICAgICAgPC9wYXJlbnQtcHJvdmlkaW5nLWV2ZW50LWJ1cz5cbiAgICAgICAgICAgIDwvZ3JhbmQtcGFyZW50LXByb3ZpZGluZy1ldmVudC1idXM+XG4gICAgICAgICAgYCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR3JhbmRQYXJlbnRQcm92aWRpbmdFdmVudEJ1cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGFyZW50UHJvdmlkaW5nRXZlbnRCdXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoaWxkQ29uc3VtaW5nRXZlbnRCdXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICB2YXIgZ3BDb21wID0gZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF07XG4gICAgICAgICAgICAgICAgIHZhciBwYXJlbnRDb21wID0gZ3BDb21wLmNoaWxkcmVuWzBdO1xuICAgICAgICAgICAgICAgICB2YXIgY2hpbGRDb21wID0gcGFyZW50Q29tcC5jaGlsZHJlblswXTtcblxuICAgICAgICAgICAgICAgICB2YXIgZ3JhbmRQYXJlbnQgPSBncENvbXAuaW5qZWN0KEdyYW5kUGFyZW50UHJvdmlkaW5nRXZlbnRCdXMpO1xuICAgICAgICAgICAgICAgICB2YXIgcGFyZW50ID0gcGFyZW50Q29tcC5pbmplY3QoUGFyZW50UHJvdmlkaW5nRXZlbnRCdXMpO1xuICAgICAgICAgICAgICAgICB2YXIgY2hpbGQgPSBjaGlsZENvbXAuaW5qZWN0KENoaWxkQ29uc3VtaW5nRXZlbnRCdXMpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChncmFuZFBhcmVudC5idXMubmFtZSkudG9FcXVhbChcImdyYW5kcGFyZW50XCIpO1xuICAgICAgICAgICAgICAgICBleHBlY3QocGFyZW50LmJ1cy5uYW1lKS50b0VxdWFsKFwicGFyZW50XCIpO1xuICAgICAgICAgICAgICAgICBleHBlY3QocGFyZW50LmdyYW5kUGFyZW50QnVzKS50b0JlKGdyYW5kUGFyZW50LmJ1cyk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChjaGlsZC5idXMpLnRvQmUocGFyZW50LmJ1cyk7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KFwic2hvdWxkIGluc3RhbnRpYXRlIGJpbmRpbmdzIGxhemlseVwiLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoXG4gICAgICAgICAgICAgICAgICBNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogYFxuICAgICAgICAgICAgICA8Y29tcG9uZW50LXByb3ZpZGluZy1sb2dnaW5nLWluamVjdGFibGUgI3Byb3ZpZGluZz5cbiAgICAgICAgICAgICAgICA8ZGlyZWN0aXZlLWNvbnN1bWluZy1pbmplY3RhYmxlICpuZ0lmPVwiY3R4Qm9vbFByb3BcIj5cbiAgICAgICAgICAgICAgICA8L2RpcmVjdGl2ZS1jb25zdW1pbmctaW5qZWN0YWJsZT5cbiAgICAgICAgICAgICAgPC9jb21wb25lbnQtcHJvdmlkaW5nLWxvZ2dpbmctaW5qZWN0YWJsZT5cbiAgICAgICAgICBgLFxuICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOlxuICAgICAgICAgICAgICAgICAgICAgICAgW0RpcmVjdGl2ZUNvbnN1bWluZ0luamVjdGFibGUsIENvbXBvbmVudFByb3ZpZGluZ0xvZ2dpbmdJbmplY3RhYmxlLCBOZ0lmXVxuICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgdmFyIHByb3ZpZGluZyA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmdldExvY2FsKFwicHJvdmlkaW5nXCIpO1xuICAgICAgICAgICAgICAgICBleHBlY3QocHJvdmlkaW5nLmNyZWF0ZWQpLnRvQmUoZmFsc2UpO1xuXG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eEJvb2xQcm9wID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KHByb3ZpZGluZy5jcmVhdGVkKS50b0JlKHRydWUpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoXCJjb3JuZXIgY2FzZXNcIiwgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCByZW1vdmUgc2NyaXB0IHRhZ3MgZnJvbSB0ZW1wbGF0ZXMnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiBgXG4gICAgICAgICAgICA8c2NyaXB0PmFsZXJ0KFwiT29vcHNcIik7PC9zY3JpcHQ+XG4gICAgICAgICAgICA8ZGl2PmJlZm9yZTxzY3JpcHQ+YWxlcnQoXCJPb29wc1wiKTs8L3NjcmlwdD48c3Bhbj5pbnNpZGU8L3NwYW4+YWZ0ZXI8L2Rpdj5gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5xdWVyeVNlbGVjdG9yQWxsKGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQsICdzY3JpcHQnKS5sZW5ndGgpXG4gICAgICAgICAgICAgICAgICAgICAudG9FcXVhbCgwKTtcbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG4gICAgfSk7XG5cbiAgICBkZXNjcmliZShcImVycm9yIGhhbmRsaW5nXCIsICgpID0+IHtcbiAgICAgIGl0KCdzaG91bGQgcmVwb3J0IGEgbWVhbmluZ2Z1bCBlcnJvciB3aGVuIGEgZGlyZWN0aXZlIGlzIG1pc3NpbmcgYW5ub3RhdGlvbicsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiID0gdGNiLm92ZXJyaWRlVmlldyhcbiAgICAgICAgICAgICAgIE15Q29tcCxcbiAgICAgICAgICAgICAgIG5ldyBWaWV3TWV0YWRhdGEoe3RlbXBsYXRlOiAnJywgZGlyZWN0aXZlczogW1NvbWVEaXJlY3RpdmVNaXNzaW5nQW5ub3RhdGlvbl19KSk7XG5cbiAgICAgICAgICAgUHJvbWlzZVdyYXBwZXIuY2F0Y2hFcnJvcih0Y2IuY3JlYXRlQXN5bmMoTXlDb21wKSwgKGUpID0+IHtcbiAgICAgICAgICAgICBleHBlY3QoZS5tZXNzYWdlKS50b0VxdWFsKFxuICAgICAgICAgICAgICAgICBgTm8gRGlyZWN0aXZlIGFubm90YXRpb24gZm91bmQgb24gJHtzdHJpbmdpZnkoU29tZURpcmVjdGl2ZU1pc3NpbmdBbm5vdGF0aW9uKX1gKTtcbiAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIHJlcG9ydCBhIG1lYW5pbmdmdWwgZXJyb3Igd2hlbiBhIGNvbXBvbmVudCBpcyBtaXNzaW5nIHZpZXcgYW5ub3RhdGlvbicsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIpID0+IHtcbiAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICB0Y2IuY3JlYXRlQXN5bmMoQ29tcG9uZW50V2l0aG91dFZpZXcpO1xuICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgZXhwZWN0KGUubWVzc2FnZSkudG9Db250YWluKGBtdXN0IGhhdmUgZWl0aGVyICd0ZW1wbGF0ZScgb3IgJ3RlbXBsYXRlVXJsJyBzZXQuYCk7XG4gICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgIH1cbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCByZXBvcnQgYSBtZWFuaW5nZnVsIGVycm9yIHdoZW4gYSBkaXJlY3RpdmUgaXMgbnVsbCcsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcblxuICAgICAgICAgICB0Y2IgPSB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7ZGlyZWN0aXZlczogW1tudWxsXV0sIHRlbXBsYXRlOiAnJ30pKTtcblxuICAgICAgICAgICBQcm9taXNlV3JhcHBlci5jYXRjaEVycm9yKHRjYi5jcmVhdGVBc3luYyhNeUNvbXApLCAoZSkgPT4ge1xuICAgICAgICAgICAgIGV4cGVjdChlLm1lc3NhZ2UpLnRvRXF1YWwoXG4gICAgICAgICAgICAgICAgIGBVbmV4cGVjdGVkIGRpcmVjdGl2ZSB2YWx1ZSAnbnVsbCcgb24gdGhlIFZpZXcgb2YgY29tcG9uZW50ICcke3N0cmluZ2lmeShNeUNvbXApfSdgKTtcbiAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIHByb3ZpZGUgYW4gZXJyb3IgY29udGV4dCB3aGVuIGFuIGVycm9yIGhhcHBlbnMgaW4gREknLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG5cbiAgICAgICAgICAgdGNiID1cbiAgICAgICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbRGlyZWN0aXZlVGhyb3dpbmdBbkVycm9yXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogYDxkaXJlY3RpdmUtdGhyb3dpbmctZXJyb3I+PC9kaXJlY3RpdmUtdGhyb3dpbmctZXJyb3I+YFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgICAgUHJvbWlzZVdyYXBwZXIuY2F0Y2hFcnJvcih0Y2IuY3JlYXRlQXN5bmMoTXlDb21wKSwgKGUpID0+IHtcbiAgICAgICAgICAgICB2YXIgYyA9IGUuY29udGV4dDtcbiAgICAgICAgICAgICBleHBlY3QoRE9NLm5vZGVOYW1lKGMuZWxlbWVudCkudG9VcHBlckNhc2UoKSkudG9FcXVhbChcIkRJUkVDVElWRS1USFJPV0lORy1FUlJPUlwiKTtcbiAgICAgICAgICAgICBleHBlY3QoRE9NLm5vZGVOYW1lKGMuY29tcG9uZW50RWxlbWVudCkudG9VcHBlckNhc2UoKSkudG9FcXVhbChcIkRJVlwiKTtcbiAgICAgICAgICAgICBleHBlY3QoYy5pbmplY3RvcikudG9CZUFuSW5zdGFuY2VPZihJbmplY3Rvcik7XG4gICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBwcm92aWRlIGFuIGVycm9yIGNvbnRleHQgd2hlbiBhbiBlcnJvciBoYXBwZW5zIGluIGNoYW5nZSBkZXRlY3Rpb24nLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG5cbiAgICAgICAgICAgdGNiID0gdGNiLm92ZXJyaWRlVmlldyhcbiAgICAgICAgICAgICAgIE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6IGA8aW5wdXQgW3ZhbHVlXT1cIm9uZS50d28udGhyZWVcIiAjbG9jYWw+YH0pKTtcblxuICAgICAgICAgICB0Y2IuY3JlYXRlQXN5bmMoTXlDb21wKS50aGVuKGZpeHR1cmUgPT4ge1xuICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIHRocm93IFwiU2hvdWxkIHRocm93XCI7XG4gICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgdmFyIGMgPSBlLmNvbnRleHQ7XG4gICAgICAgICAgICAgICBleHBlY3QoRE9NLm5vZGVOYW1lKGMuZWxlbWVudCkudG9VcHBlckNhc2UoKSkudG9FcXVhbChcIklOUFVUXCIpO1xuICAgICAgICAgICAgICAgZXhwZWN0KERPTS5ub2RlTmFtZShjLmNvbXBvbmVudEVsZW1lbnQpLnRvVXBwZXJDYXNlKCkpLnRvRXF1YWwoXCJESVZcIik7XG4gICAgICAgICAgICAgICBleHBlY3QoYy5pbmplY3RvcikudG9CZUFuSW5zdGFuY2VPZihJbmplY3Rvcik7XG4gICAgICAgICAgICAgICBleHBlY3QoYy5leHByZXNzaW9uKS50b0NvbnRhaW4oXCJvbmUudHdvLnRocmVlXCIpO1xuICAgICAgICAgICAgICAgZXhwZWN0KGMuY29udGV4dCkudG9CZShmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZSk7XG4gICAgICAgICAgICAgICBleHBlY3QoYy5sb2NhbHNbXCJsb2NhbFwiXSkudG9CZURlZmluZWQoKTtcbiAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIHByb3ZpZGUgYW4gZXJyb3IgY29udGV4dCB3aGVuIGFuIGVycm9yIGhhcHBlbnMgaW4gY2hhbmdlIGRldGVjdGlvbiAodGV4dCBub2RlKScsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcblxuICAgICAgICAgICB0Y2IgPSB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6IGB7e29uZS50d28udGhyZWV9fWB9KSk7XG5cbiAgICAgICAgICAgdGNiLmNyZWF0ZUFzeW5jKE15Q29tcCkudGhlbihmaXh0dXJlID0+IHtcbiAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICB0aHJvdyBcIlNob3VsZCB0aHJvd1wiO1xuICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgIHZhciBjID0gZS5jb250ZXh0O1xuICAgICAgICAgICAgICAgZXhwZWN0KGMuZWxlbWVudCkudG9CZU51bGwoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChjLmluamVjdG9yKS50b0JlTnVsbCgpO1xuICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGlmIChET00uc3VwcG9ydHNET01FdmVudHMoKSkgeyAgLy8gdGhpcyBpcyByZXF1aXJlZCB0byB1c2UgZmFrZUFzeW5jXG4gICAgICAgIGl0KCdzaG91bGQgcHJvdmlkZSBhbiBlcnJvciBjb250ZXh0IHdoZW4gYW4gZXJyb3IgaGFwcGVucyBpbiBhbiBldmVudCBoYW5kbGVyJyxcbiAgICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlcl0sIGZha2VBc3luYygodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlcikgPT4ge1xuXG4gICAgICAgICAgICAgICAgICAgIHRjYiA9IHRjYi5vdmVycmlkZVZpZXcoXG4gICAgICAgICAgICAgICAgICAgICAgICBNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogYDxzcGFuIGVtaXR0ZXIgbGlzdGVuZXIgKGV2ZW50KT1cInRocm93RXJyb3IoKVwiICNsb2NhbD48L3NwYW4+YCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW0RpcmVjdGl2ZUVtaXR0aW5nRXZlbnQsIERpcmVjdGl2ZUxpc3RlbmluZ0V2ZW50XVxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgICAgICAgICAgICAgIHZhciBmaXh0dXJlOiBDb21wb25lbnRGaXh0dXJlO1xuICAgICAgICAgICAgICAgICAgICB0Y2IuY3JlYXRlQXN5bmMoTXlDb21wKS50aGVuKHJvb3QgPT4geyBmaXh0dXJlID0gcm9vdDsgfSk7XG4gICAgICAgICAgICAgICAgICAgIHRpY2soKTtcblxuICAgICAgICAgICAgICAgICAgICB2YXIgdGMgPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXTtcbiAgICAgICAgICAgICAgICAgICAgdGMuaW5qZWN0KERpcmVjdGl2ZUVtaXR0aW5nRXZlbnQpLmZpcmVFdmVudChcImJvb21cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICB0aWNrKCk7XG4gICAgICAgICAgICAgICAgICAgICAgdGhyb3cgXCJTaG91bGQgdGhyb3dcIjtcbiAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgICAgICAgIGNsZWFyUGVuZGluZ1RpbWVycygpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgdmFyIGMgPSBlLmNvbnRleHQ7XG4gICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5ub2RlTmFtZShjLmVsZW1lbnQpLnRvVXBwZXJDYXNlKCkpLnRvRXF1YWwoXCJTUEFOXCIpO1xuICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChET00ubm9kZU5hbWUoYy5jb21wb25lbnRFbGVtZW50KS50b1VwcGVyQ2FzZSgpKS50b0VxdWFsKFwiRElWXCIpO1xuICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChjLmluamVjdG9yKS50b0JlQW5JbnN0YW5jZU9mKEluamVjdG9yKTtcbiAgICAgICAgICAgICAgICAgICAgICBleHBlY3QoYy5jb250ZXh0KS50b0JlKGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlKTtcbiAgICAgICAgICAgICAgICAgICAgICBleHBlY3QoYy5sb2NhbHNbXCJsb2NhbFwiXSkudG9CZURlZmluZWQoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfSkpKTtcbiAgICAgIH1cblxuICAgICAgaWYgKCFJU19EQVJUKSB7XG4gICAgICAgIGl0KCdzaG91bGQgcmVwb3J0IGEgbWVhbmluZ2Z1bCBlcnJvciB3aGVuIGEgZGlyZWN0aXZlIGlzIHVuZGVmaW5lZCcsXG4gICAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMpID0+IHtcblxuICAgICAgICAgICAgIHZhciB1bmRlZmluZWRWYWx1ZTtcblxuICAgICAgICAgICAgIHRjYiA9IHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YSh7ZGlyZWN0aXZlczogW3VuZGVmaW5lZFZhbHVlXSwgdGVtcGxhdGU6ICcnfSkpO1xuXG4gICAgICAgICAgICAgUHJvbWlzZVdyYXBwZXIuY2F0Y2hFcnJvcih0Y2IuY3JlYXRlQXN5bmMoTXlDb21wKSwgKGUpID0+IHtcbiAgICAgICAgICAgICAgIGV4cGVjdChlLm1lc3NhZ2UpLnRvRXF1YWwoXG4gICAgICAgICAgICAgICAgICAgYFVuZXhwZWN0ZWQgZGlyZWN0aXZlIHZhbHVlICd1bmRlZmluZWQnIG9uIHRoZSBWaWV3IG9mIGNvbXBvbmVudCAnJHtzdHJpbmdpZnkoTXlDb21wKX0nYCk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgfSkpO1xuICAgICAgfVxuXG4gICAgICBpdCgnc2hvdWxkIHNwZWNpZnkgYSBsb2NhdGlvbiBvZiBhbiBlcnJvciB0aGF0IGhhcHBlbmVkIGR1cmluZyBjaGFuZ2UgZGV0ZWN0aW9uICh0ZXh0KScsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLFxuICAgICAgICAgICAgICAgICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuXG4gICAgICAgICAgICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHt0ZW1wbGF0ZTogJ3t7YS5ifX0nfSkpXG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBleHBlY3QoKCkgPT4gZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9UaHJvd0Vycm9yKGNvbnRhaW5zUmVnZXhwKGB7e2EuYn19IGluICR7c3RyaW5naWZ5KE15Q29tcCl9YCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KX0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBzcGVjaWZ5IGEgbG9jYXRpb24gb2YgYW4gZXJyb3IgdGhhdCBoYXBwZW5lZCBkdXJpbmcgY2hhbmdlIGRldGVjdGlvbiAoZWxlbWVudCBwcm9wZXJ0eSknLFxuICAgICAgICAgaW5qZWN0KFxuICAgICAgICAgICAgIFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSxcbiAgICAgICAgICAgICAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcblxuICAgICAgICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6ICc8ZGl2IFt0aXRsZV09XCJhLmJcIj48L2Rpdj4nfSkpXG5cbiAgICAgICAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICBleHBlY3QoKCkgPT4gZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAudG9UaHJvd0Vycm9yKGNvbnRhaW5zUmVnZXhwKGBhLmIgaW4gJHtzdHJpbmdpZnkoTXlDb21wKX1gKSk7XG4gICAgICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgICAgIH0pfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIHNwZWNpZnkgYSBsb2NhdGlvbiBvZiBhbiBlcnJvciB0aGF0IGhhcHBlbmVkIGR1cmluZyBjaGFuZ2UgZGV0ZWN0aW9uIChkaXJlY3RpdmUgcHJvcGVydHkpJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sXG4gICAgICAgICAgICAgICAgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG5cbiAgICAgICAgICAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8Y2hpbGQtY21wIFt0aXRsZV09XCJhLmJcIj48L2NoaWxkLWNtcD4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW0NoaWxkQ29tcF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcblxuICAgICAgICAgICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdCgoKSA9PiBmaXh0dXJlLmRldGVjdENoYW5nZXMoKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b1Rocm93RXJyb3IoY29udGFpbnNSZWdleHAoYGEuYiBpbiAke3N0cmluZ2lmeShNeUNvbXApfWApKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSl9KSk7XG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIHN1cHBvcnQgaW1wZXJhdGl2ZSB2aWV3cycsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8c2ltcGxlLWltcC1jbXA+PC9zaW1wbGUtaW1wLWNtcD4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtTaW1wbGVJbXBlcmF0aXZlVmlld0NvbXBvbmVudF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ2hlbGxvIGltcCB2aWV3Jyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBzdXBwb3J0IG1vdmluZyBlbWJlZGRlZCB2aWV3cyBhcm91bmQnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlciwgQU5DSE9SX0VMRU1FTlRdLFxuICAgICAgICAgICAgICAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMsIGFuY2hvckVsZW1lbnQpID0+IHtcbiAgICAgICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiAnPGRpdj48ZGl2ICpzb21lSW1wdnA9XCJjdHhCb29sUHJvcFwiPmhlbGxvPC9kaXY+PC9kaXY+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW1NvbWVJbXBlcmF0aXZlVmlld3BvcnRdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmU6IENvbXBvbmVudEZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgICAgICBleHBlY3QoYW5jaG9yRWxlbWVudCkudG9IYXZlVGV4dCgnJyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jdHhCb29sUHJvcCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICBleHBlY3QoYW5jaG9yRWxlbWVudCkudG9IYXZlVGV4dCgnaGVsbG8nKTtcblxuICAgICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eEJvb2xQcm9wID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJycpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfSkpO1xuXG4gICAgZGVzY3JpYmUoJ1Byb3BlcnR5IGJpbmRpbmdzJywgKCkgPT4ge1xuICAgICAgaWYgKCFJU19EQVJUKSB7XG4gICAgICAgIGl0KCdzaG91bGQgdGhyb3cgb24gYmluZGluZ3MgdG8gdW5rbm93biBwcm9wZXJ0aWVzJyxcbiAgICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3luYykgPT4ge1xuICAgICAgICAgICAgIHRjYiA9XG4gICAgICAgICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5ldyBWaWV3TWV0YWRhdGEoe3RlbXBsYXRlOiAnPGRpdiB1bmtub3duPVwie3tjdHhQcm9wfX1cIj48L2Rpdj4nfSkpXG5cbiAgICAgICAgICAgICAgICAgICAgIFByb21pc2VXcmFwcGVyLmNhdGNoRXJyb3IodGNiLmNyZWF0ZUFzeW5jKE15Q29tcCksIChlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChlLm1lc3NhZ2UpLnRvRXF1YWwoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBgVGVtcGxhdGUgcGFyc2UgZXJyb3JzOlxcbkNhbid0IGJpbmQgdG8gJ3Vua25vd24nIHNpbmNlIGl0IGlzbid0IGEga25vd24gbmF0aXZlIHByb3BlcnR5IChcIjxkaXYgW0VSUk9SIC0+XXVua25vd249XCJ7e2N0eFByb3B9fVwiPjwvZGl2PlwiKTogTXlDb21wQDA6NWApO1xuICAgICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIG5vdCB0aHJvdyBmb3IgcHJvcGVydHkgYmluZGluZyB0byBhIG5vbi1leGlzdGluZyBwcm9wZXJ0eSB3aGVuIHRoZXJlIGlzIGEgbWF0Y2hpbmcgZGlyZWN0aXZlIHByb3BlcnR5JyxcbiAgICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3luYykgPT4ge1xuICAgICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoXG4gICAgICAgICAgICAgICAgICAgIE15Q29tcCxcbiAgICAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YShcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0ZW1wbGF0ZTogJzxkaXYgbXktZGlyIFtlbHByb3BdPVwiY3R4UHJvcFwiPjwvZGl2PicsIGRpcmVjdGl2ZXM6IFtNeURpcl19KSlcbiAgICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgICAgLnRoZW4oKHZhbCkgPT4geyBhc3luYy5kb25lKCk7IH0pO1xuICAgICAgICAgICB9KSk7XG4gICAgICB9XG5cbiAgICAgIGl0KCdzaG91bGQgbm90IGJlIGNyZWF0ZWQgd2hlbiB0aGVyZSBpcyBhIGRpcmVjdGl2ZSB3aXRoIHRoZSBzYW1lIHByb3BlcnR5JyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJzxzcGFuIFt0aXRsZV09XCJjdHhQcm9wXCI+PC9zcGFuPicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbRGlyZWN0aXZlV2l0aFRpdGxlXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eFByb3AgPSBcIlRJVExFXCI7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIHZhciBlbCA9IERPTS5xdWVyeVNlbGVjdG9yKGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQsIFwic3BhblwiKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGlzQmxhbmsoZWwudGl0bGUpIHx8IGVsLnRpdGxlID09ICcnKS50b0JlVHJ1dGh5KCk7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuXG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCB3b3JrIHdoZW4gYSBkaXJlY3RpdmUgdXNlcyBob3N0UHJvcGVydHkgdG8gdXBkYXRlIHRoZSBET00gZWxlbWVudCcsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8c3BhbiBbdGl0bGVdPVwiY3R4UHJvcFwiPjwvc3Bhbj4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW0RpcmVjdGl2ZVdpdGhUaXRsZUFuZEhvc3RQcm9wZXJ0eV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jdHhQcm9wID0gXCJUSVRMRVwiO1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICB2YXIgZWwgPSBET00ucXVlcnlTZWxlY3RvcihmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50LCBcInNwYW5cIik7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChlbC50aXRsZSkudG9FcXVhbChcIlRJVExFXCIpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcblxuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG4gICAgfSk7XG5cbiAgICBkZXNjcmliZSgnbG9nZ2luZyBwcm9wZXJ0eSB1cGRhdGVzJywgKCkgPT4ge1xuICAgICAgYmVmb3JlRWFjaFByb3ZpZGVycygoKSA9PiBbXG4gICAgICAgIHByb3ZpZGUoQ2hhbmdlRGV0ZWN0b3JHZW5Db25maWcsXG4gICAgICAgICAgICAgICAge3VzZVZhbHVlOiBuZXcgQ2hhbmdlRGV0ZWN0b3JHZW5Db25maWcodHJ1ZSwgdHJ1ZSwgZmFsc2UpfSlcbiAgICAgIF0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHJlZmxlY3QgcHJvcGVydHkgdmFsdWVzIGFzIGF0dHJpYnV0ZXMnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHZhciB0cGwgPSAnPGRpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICc8ZGl2IG15LWRpciBbZWxwcm9wXT1cImN0eFByb3BcIj48L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICc8L2Rpdj4nO1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6IHRwbCwgZGlyZWN0aXZlczogW015RGlyXX0pKVxuXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UuY3R4UHJvcCA9ICdoZWxsbyc7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChET00uZ2V0SW5uZXJIVE1MKGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpKVxuICAgICAgICAgICAgICAgICAgICAgLnRvQ29udGFpbignbmctcmVmbGVjdC1kaXItcHJvcD1cImhlbGxvXCInKTtcbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcmVmbGVjdCBwcm9wZXJ0eSB2YWx1ZXMgb24gdGVtcGxhdGUgY29tbWVudHMnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHZhciB0cGwgPSAnPHRlbXBsYXRlIFtuZ0lmXT1cImN0eEJvb2xQcm9wXCI+PC90ZW1wbGF0ZT4nO1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6IHRwbCwgZGlyZWN0aXZlczogW05nSWZdfSkpXG5cbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5jdHhCb29sUHJvcCA9IHRydWU7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChET00uZ2V0SW5uZXJIVE1MKGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpKVxuICAgICAgICAgICAgICAgICAgICAgLnRvQ29udGFpbignXCJuZ1xcLXJlZmxlY3RcXC1uZ1xcLWlmXCJcXDogXCJ0cnVlXCInKTtcbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG4gICAgfSk7XG5cbiAgICBkZXNjcmliZSgnZGlmZmVyZW50IHByb3RvIHZpZXcgc3RvcmFnZXMnLCAoKSA9PiB7XG4gICAgICBmdW5jdGlvbiBydW5XaXRoTW9kZShtb2RlOiBzdHJpbmcpIHtcbiAgICAgICAgcmV0dXJuIGluamVjdChcbiAgICAgICAgICAgIFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5ldyBWaWV3TWV0YWRhdGEoe3RlbXBsYXRlOiBgPCEtLSR7bW9kZX0tLT48ZGl2Pnt7Y3R4UHJvcH19PC9kaXY+YH0pKVxuICAgICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmN0eFByb3AgPSAnSGVsbG8gV29ybGQhJztcblxuICAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ0hlbGxvIFdvcmxkIScpO1xuICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICBpdCgnc2hvdWxkIHdvcmsgd2l0aCBzdG9yaW5nIERPTSBub2RlcycsIHJ1bldpdGhNb2RlKCdjYWNoZScpKTtcblxuICAgICAgaXQoJ3Nob3VsZCB3b3JrIHdpdGggc2VyaWFsaXppbmcgdGhlIERPTSBub2RlcycsIHJ1bldpdGhNb2RlKCdub2NhY2hlJykpO1xuICAgIH0pO1xuXG4gICAgLy8gRGlzYWJsZWQgdW50aWwgYSBzb2x1dGlvbiBpcyBmb3VuZCwgcmVmczpcbiAgICAvLyAtIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvaXNzdWVzLzc3NlxuICAgIC8vIC0gaHR0cHM6Ly9naXRodWIuY29tL2FuZ3VsYXIvYW5ndWxhci9jb21taXQvODFmM2YzMlxuICAgIHhkZXNjcmliZSgnTWlzc2luZyBkaXJlY3RpdmUgY2hlY2tzJywgKCkgPT4ge1xuICAgICAgZnVuY3Rpb24gZXhwZWN0Q29tcGlsZUVycm9yKHRjYiwgaW5saW5lVHBsLCBlcnJNZXNzYWdlLCBkb25lKSB7XG4gICAgICAgIHRjYiA9IHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHt0ZW1wbGF0ZTogaW5saW5lVHBsfSkpO1xuICAgICAgICBQcm9taXNlV3JhcHBlci50aGVuKFxuICAgICAgICAgICAgdGNiLmNyZWF0ZUFzeW5jKE15Q29tcCksXG4gICAgICAgICAgICAodmFsdWUpID0+IHtcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IEJhc2VFeGNlcHRpb24oXG4gICAgICAgICAgICAgICAgICBcIlRlc3QgZmFpbHVyZTogc2hvdWxkIG5vdCBoYXZlIGNvbWUgaGVyZSBhcyBhbiBleGNlcHRpb24gd2FzIGV4cGVjdGVkXCIpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIChlcnIpID0+IHtcbiAgICAgICAgICAgICAgZXhwZWN0KGVyci5tZXNzYWdlKS50b0VxdWFsKGVyck1lc3NhZ2UpO1xuICAgICAgICAgICAgICBkb25lKCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgaWYgKGFzc2VydGlvbnNFbmFibGVkKCkpIHtcbiAgICAgICAgaXQoJ3Nob3VsZCByYWlzZSBhbiBlcnJvciBpZiBubyBkaXJlY3RpdmUgaXMgcmVnaXN0ZXJlZCBmb3IgYSB0ZW1wbGF0ZSB3aXRoIHRlbXBsYXRlIGJpbmRpbmdzJyxcbiAgICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3luYykgPT4ge1xuICAgICAgICAgICAgIGV4cGVjdENvbXBpbGVFcnJvcih0Y2IsICc8ZGl2PjxkaXYgdGVtcGxhdGU9XCJpZjogZm9vXCI+PC9kaXY+PC9kaXY+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ01pc3NpbmcgZGlyZWN0aXZlIHRvIGhhbmRsZSBcXCdpZlxcJyBpbiA8ZGl2IHRlbXBsYXRlPVwiaWY6IGZvb1wiPicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICgpID0+IGFzeW5jLmRvbmUoKSk7XG4gICAgICAgICAgIH0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIHJhaXNlIGFuIGVycm9yIGZvciBtaXNzaW5nIHRlbXBsYXRlIGRpcmVjdGl2ZSAoMSknLFxuICAgICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgZXhwZWN0Q29tcGlsZUVycm9yKHRjYiwgJzxkaXY+PHRlbXBsYXRlIGZvbz48L3RlbXBsYXRlPjwvZGl2PicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdNaXNzaW5nIGRpcmVjdGl2ZSB0byBoYW5kbGU6IDx0ZW1wbGF0ZSBmb28+JywgKCkgPT4gYXN5bmMuZG9uZSgpKTtcbiAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIGl0KCdzaG91bGQgcmFpc2UgYW4gZXJyb3IgZm9yIG1pc3NpbmcgdGVtcGxhdGUgZGlyZWN0aXZlICgyKScsXG4gICAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sXG4gICAgICAgICAgICAgICAgICAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgZXhwZWN0Q29tcGlsZUVycm9yKHRjYiwgJzxkaXY+PHRlbXBsYXRlICpuZ0lmPVwiY29uZGl0aW9uXCI+PC90ZW1wbGF0ZT48L2Rpdj4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ01pc3NpbmcgZGlyZWN0aXZlIHRvIGhhbmRsZTogPHRlbXBsYXRlICpuZ0lmPVwiY29uZGl0aW9uXCI+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICgpID0+IGFzeW5jLmRvbmUoKSk7XG4gICAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgaXQoJ3Nob3VsZCByYWlzZSBhbiBlcnJvciBmb3IgbWlzc2luZyB0ZW1wbGF0ZSBkaXJlY3RpdmUgKDMpJyxcbiAgICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSxcbiAgICAgICAgICAgICAgICAgICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBleHBlY3RDb21waWxlRXJyb3IoXG4gICAgICAgICAgICAgICAgICAgICAgICB0Y2IsICc8ZGl2ICpuZ0lmPVwiY29uZGl0aW9uXCI+PC9kaXY+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICdNaXNzaW5nIGRpcmVjdGl2ZSB0byBoYW5kbGUgXFwnaWZcXCcgaW4gTXlDb21wOiA8ZGl2ICpuZ0lmPVwiY29uZGl0aW9uXCI+JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICgpID0+IGFzeW5jLmRvbmUoKSk7XG4gICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBkZXNjcmliZSgncHJvcGVydHkgZGVjb3JhdG9ycycsICgpID0+IHtcbiAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCBwcm9wZXJ0eSBkZWNvcmF0b3JzJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgICAgTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8d2l0aC1wcm9wLWRlY29yYXRvcnMgZWxQcm9wPVwiYWFhXCI+PC93aXRoLXByb3AtZGVjb3JhdG9ycz4nLFxuICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbRGlyZWN0aXZlV2l0aFByb3BEZWNvcmF0b3JzXVxuICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgIHZhciBkaXIgPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5pbmplY3QoRGlyZWN0aXZlV2l0aFByb3BEZWNvcmF0b3JzKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGRpci5kaXJQcm9wKS50b0VxdWFsKFwiYWFhXCIpO1xuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IGhvc3QgYmluZGluZyBkZWNvcmF0b3JzJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVWaWV3KE15Q29tcCwgbmV3IFZpZXdNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogJzx3aXRoLXByb3AtZGVjb3JhdG9ycz48L3dpdGgtcHJvcC1kZWNvcmF0b3JzPicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbRGlyZWN0aXZlV2l0aFByb3BEZWNvcmF0b3JzXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICB2YXIgZGlyID0gZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uaW5qZWN0KERpcmVjdGl2ZVdpdGhQcm9wRGVjb3JhdG9ycyk7XG4gICAgICAgICAgICAgICAgIGRpci5teUF0dHIgPSBcImFhYVwiO1xuXG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoRE9NLmdldE91dGVySFRNTChmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5uYXRpdmVFbGVtZW50KSlcbiAgICAgICAgICAgICAgICAgICAgIC50b0NvbnRhaW4oJ215LWF0dHI9XCJhYWFcIicpO1xuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaWYgKERPTS5zdXBwb3J0c0RPTUV2ZW50cygpKSB7XG4gICAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCBldmVudCBkZWNvcmF0b3JzJyxcbiAgICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlcl0sIGZha2VBc3luYygodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0Y2IgPSB0Y2Iub3ZlcnJpZGVWaWV3KFxuICAgICAgICAgICAgICAgICAgICAgICAgTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6IGA8d2l0aC1wcm9wLWRlY29yYXRvcnMgKGVsRXZlbnQpPVwiY3R4UHJvcD0nY2FsbGVkJ1wiPmAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtEaXJlY3RpdmVXaXRoUHJvcERlY29yYXRvcnNdXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgICAgICAgICAgICAgdmFyIGZpeHR1cmU6IENvbXBvbmVudEZpeHR1cmU7XG4gICAgICAgICAgICAgICAgICAgIHRjYi5jcmVhdGVBc3luYyhNeUNvbXApLnRoZW4ocm9vdCA9PiB7IGZpeHR1cmUgPSByb290OyB9KTtcbiAgICAgICAgICAgICAgICAgICAgdGljaygpO1xuXG4gICAgICAgICAgICAgICAgICAgIHZhciBlbWl0dGVyID1cbiAgICAgICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmluamVjdChEaXJlY3RpdmVXaXRoUHJvcERlY29yYXRvcnMpO1xuICAgICAgICAgICAgICAgICAgICBlbWl0dGVyLmZpcmVFdmVudCgnZmlyZWQgIScpO1xuXG4gICAgICAgICAgICAgICAgICAgIHRpY2soKTtcblxuICAgICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UuY3R4UHJvcCkudG9FcXVhbChcImNhbGxlZFwiKTtcbiAgICAgICAgICAgICAgICAgIH0pKSk7XG5cblxuICAgICAgICBpdCgnc2hvdWxkIHN1cHBvcnQgaG9zdCBsaXN0ZW5lciBkZWNvcmF0b3JzJyxcbiAgICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3luYykgPT4ge1xuICAgICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLCBuZXcgVmlld01ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8d2l0aC1wcm9wLWRlY29yYXRvcnM+PC93aXRoLXByb3AtZGVjb3JhdG9ycz4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3RpdmVzOiBbRGlyZWN0aXZlV2l0aFByb3BEZWNvcmF0b3JzXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgICAgdmFyIGRpciA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmluamVjdChEaXJlY3RpdmVXaXRoUHJvcERlY29yYXRvcnMpO1xuICAgICAgICAgICAgICAgICAgIHZhciBuYXRpdmUgPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5uYXRpdmVFbGVtZW50O1xuICAgICAgICAgICAgICAgICAgIERPTS5kaXNwYXRjaEV2ZW50KG5hdGl2ZSwgRE9NLmNyZWF0ZU1vdXNlRXZlbnQoJ2NsaWNrJykpO1xuXG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGRpci50YXJnZXQpLnRvQmUobmF0aXZlKTtcbiAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICB9KSk7XG4gICAgICB9XG5cbiAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCBkZWZpbmluZyB2aWV3cyBpbiB0aGUgY29tcG9uZW50IGRlY29yYXRvcicsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhNeUNvbXAsIG5ldyBWaWV3TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGU6ICc8Y29tcG9uZW50LXdpdGgtdGVtcGxhdGU+PC9jb21wb25lbnQtd2l0aC10ZW1wbGF0ZT4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW0NvbXBvbmVudFdpdGhUZW1wbGF0ZV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgdmFyIG5hdGl2ZSA9IGZpeHR1cmUuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLm5hdGl2ZUVsZW1lbnQ7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChuYXRpdmUpLnRvSGF2ZVRleHQoXCJObyBWaWV3IERlY29yYXRvcjogMTIzXCIpO1xuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcbiAgICB9KTtcblxuXG4gICAgaWYgKERPTS5zdXBwb3J0c0RPTUV2ZW50cygpKSB7XG4gICAgICBkZXNjcmliZSgnc3ZnJywgKCkgPT4ge1xuICAgICAgICBpdCgnc2hvdWxkIHN1cHBvcnQgc3ZnIGVsZW1lbnRzJyxcbiAgICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3luYykgPT4ge1xuICAgICAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoTXlDb21wLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6ICc8c3ZnPjx1c2UgeGxpbms6aHJlZj1cIlBvcnRcIiAvPjwvc3ZnPid9KSlcbiAgICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgICB2YXIgZWwgPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50O1xuICAgICAgICAgICAgICAgICAgIHZhciBzdmcgPSBET00uY2hpbGROb2RlcyhlbClbMF07XG4gICAgICAgICAgICAgICAgICAgdmFyIHVzZSA9IERPTS5jaGlsZE5vZGVzKHN2ZylbMF07XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5nZXRQcm9wZXJ0eSg8RWxlbWVudD5zdmcsICduYW1lc3BhY2VVUkknKSlcbiAgICAgICAgICAgICAgICAgICAgICAgLnRvRXF1YWwoJ2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJyk7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5nZXRQcm9wZXJ0eSg8RWxlbWVudD51c2UsICduYW1lc3BhY2VVUkknKSlcbiAgICAgICAgICAgICAgICAgICAgICAgLnRvRXF1YWwoJ2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJyk7XG5cbiAgICAgICAgICAgICAgICAgICBpZiAoIUlTX0RBUlQpIHtcbiAgICAgICAgICAgICAgICAgICAgIHZhciBmaXJzdEF0dHJpYnV0ZSA9IERPTS5nZXRQcm9wZXJ0eSg8RWxlbWVudD51c2UsICdhdHRyaWJ1dGVzJylbMF07XG4gICAgICAgICAgICAgICAgICAgICBleHBlY3QoZmlyc3RBdHRyaWJ1dGUubmFtZSkudG9FcXVhbCgneGxpbms6aHJlZicpO1xuICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGZpcnN0QXR0cmlidXRlLm5hbWVzcGFjZVVSSSkudG9FcXVhbCgnaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluaycpO1xuICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAvLyBGb3IgRGFydCB3aGVyZSAnX0F0dHInIGhhcyBubyBpbnN0YW5jZSBnZXR0ZXIgJ25hbWVzcGFjZVVSSSdcbiAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChET00uZ2V0T3V0ZXJIVE1MKDxIVE1MRWxlbWVudD51c2UpKS50b0NvbnRhaW4oJ3htbG5zOnhsaW5rJyk7XG4gICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgfSkpO1xuXG4gICAgICB9KTtcblxuICAgICAgZGVzY3JpYmUoJ2F0dHJpYnV0ZXMnLCAoKSA9PiB7XG5cbiAgICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IGF0dHJpYnV0ZXMgd2l0aCBuYW1lc3BhY2UnLFxuICAgICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhTb21lQ21wLCBuZXcgVmlld01ldGFkYXRhKHt0ZW1wbGF0ZTogJzxzdmc6dXNlIHhsaW5rOmhyZWY9XCIjaWRcIiAvPid9KSlcbiAgICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKFNvbWVDbXApXG4gICAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgbGV0IHVzZUVsID0gRE9NLmZpcnN0Q2hpbGQoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCk7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5nZXRBdHRyaWJ1dGVOUyh1c2VFbCwgJ2h0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsnLCAnaHJlZicpKVxuICAgICAgICAgICAgICAgICAgICAgICAudG9FcXVhbCgnI2lkJyk7XG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCBiaW5kaW5nIHRvIGF0dHJpYnV0ZXMgd2l0aCBuYW1lc3BhY2UnLFxuICAgICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgdGNiLm92ZXJyaWRlVmlldyhTb21lQ21wLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6ICc8c3ZnOnVzZSBbYXR0ci54bGluazpocmVmXT1cInZhbHVlXCIgLz4nfSkpXG4gICAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhTb21lQ21wKVxuICAgICAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgIGxldCBjbXAgPSBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZTtcbiAgICAgICAgICAgICAgICAgICBsZXQgdXNlRWwgPSBET00uZmlyc3RDaGlsZChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KTtcblxuICAgICAgICAgICAgICAgICAgIGNtcC52YWx1ZSA9IFwiI2lkXCI7XG4gICAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgICBleHBlY3QoRE9NLmdldEF0dHJpYnV0ZU5TKHVzZUVsLCAnaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluaycsICdocmVmJykpXG4gICAgICAgICAgICAgICAgICAgICAgIC50b0VxdWFsKCcjaWQnKTtcblxuICAgICAgICAgICAgICAgICAgIGNtcC52YWx1ZSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgICBleHBlY3QoRE9NLmhhc0F0dHJpYnV0ZU5TKHVzZUVsLCAnaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluaycsICdocmVmJykpXG4gICAgICAgICAgICAgICAgICAgICAgIC50b0VxdWFsKGZhbHNlKTtcblxuICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0pKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfSk7XG59XG5cbkBJbmplY3RhYmxlKClcbmNsYXNzIE15U2VydmljZSB7XG4gIGdyZWV0aW5nOiBzdHJpbmc7XG4gIGNvbnN0cnVjdG9yKCkgeyB0aGlzLmdyZWV0aW5nID0gJ2hlbGxvJzsgfVxufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ3NpbXBsZS1pbXAtY21wJywgdGVtcGxhdGU6ICcnfSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIFNpbXBsZUltcGVyYXRpdmVWaWV3Q29tcG9uZW50IHtcbiAgZG9uZTtcblxuICBjb25zdHJ1Y3RvcihzZWxmOiBFbGVtZW50UmVmLCByZW5kZXJlcjogUmVuZGVyZXIpIHtcbiAgICB2YXIgaG9zdEVsZW1lbnQgPSBzZWxmLm5hdGl2ZUVsZW1lbnQ7XG4gICAgRE9NLmFwcGVuZENoaWxkKGhvc3RFbGVtZW50LCBlbCgnaGVsbG8gaW1wIHZpZXcnKSk7XG4gIH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdkeW5hbWljLXZwJ30pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBEeW5hbWljVmlld3BvcnQge1xuICBkb25lOiBQcm9taXNlPGFueT47XG4gIGNvbnN0cnVjdG9yKHZjOiBWaWV3Q29udGFpbmVyUmVmLCBjb21waWxlcjogQ29tcGlsZXIpIHtcbiAgICB2YXIgbXlTZXJ2aWNlID0gbmV3IE15U2VydmljZSgpO1xuICAgIG15U2VydmljZS5ncmVldGluZyA9ICdkeW5hbWljIGdyZWV0JztcblxuICAgIHZhciBiaW5kaW5ncyA9IEluamVjdG9yLnJlc29sdmUoW3Byb3ZpZGUoTXlTZXJ2aWNlLCB7dXNlVmFsdWU6IG15U2VydmljZX0pXSk7XG4gICAgdGhpcy5kb25lID0gY29tcGlsZXIuY29tcGlsZUluSG9zdChDaGlsZENvbXBVc2luZ1NlcnZpY2UpXG4gICAgICAgICAgICAgICAgICAgIC50aGVuKChob3N0UHYpID0+IHt2Yy5jcmVhdGVIb3N0Vmlldyhob3N0UHYsIDAsIGJpbmRpbmdzKX0pO1xuICB9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnW215LWRpcl0nLCBpbnB1dHM6IFsnZGlyUHJvcDogZWxwcm9wJ10sIGV4cG9ydEFzOiAnbXlkaXInfSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIE15RGlyIHtcbiAgZGlyUHJvcDogc3RyaW5nO1xuICBjb25zdHJ1Y3RvcigpIHsgdGhpcy5kaXJQcm9wID0gJyc7IH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdbdGl0bGVdJywgaW5wdXRzOiBbJ3RpdGxlJ119KVxuY2xhc3MgRGlyZWN0aXZlV2l0aFRpdGxlIHtcbiAgdGl0bGU6IHN0cmluZztcbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdbdGl0bGVdJywgaW5wdXRzOiBbJ3RpdGxlJ10sIGhvc3Q6IHsnW3RpdGxlXSc6ICd0aXRsZSd9fSlcbmNsYXNzIERpcmVjdGl2ZVdpdGhUaXRsZUFuZEhvc3RQcm9wZXJ0eSB7XG4gIHRpdGxlOiBzdHJpbmc7XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ3B1c2gtY21wJyxcbiAgaW5wdXRzOiBbJ3Byb3AnXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG4gIHRlbXBsYXRlOiAne3tmaWVsZH19J1xufSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIFB1c2hDbXAge1xuICBudW1iZXJPZkNoZWNrczogbnVtYmVyO1xuICBwcm9wO1xuXG4gIGNvbnN0cnVjdG9yKCkgeyB0aGlzLm51bWJlck9mQ2hlY2tzID0gMDsgfVxuXG4gIGdldCBmaWVsZCgpIHtcbiAgICB0aGlzLm51bWJlck9mQ2hlY2tzKys7XG4gICAgcmV0dXJuIFwiZml4ZWRcIjtcbiAgfVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdwdXNoLWNtcC13aXRoLXJlZicsXG4gIGlucHV0czogWydwcm9wJ10sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxuICB0ZW1wbGF0ZTogJ3t7ZmllbGR9fSdcbn0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBQdXNoQ21wV2l0aFJlZiB7XG4gIG51bWJlck9mQ2hlY2tzOiBudW1iZXI7XG4gIHJlZjogQ2hhbmdlRGV0ZWN0b3JSZWY7XG4gIHByb3A7XG5cbiAgY29uc3RydWN0b3IocmVmOiBDaGFuZ2VEZXRlY3RvclJlZikge1xuICAgIHRoaXMubnVtYmVyT2ZDaGVja3MgPSAwO1xuICAgIHRoaXMucmVmID0gcmVmO1xuICB9XG5cbiAgZ2V0IGZpZWxkKCkge1xuICAgIHRoaXMubnVtYmVyT2ZDaGVja3MrKztcbiAgICByZXR1cm4gXCJmaXhlZFwiO1xuICB9XG5cbiAgcHJvcGFnYXRlKCkgeyB0aGlzLnJlZi5tYXJrRm9yQ2hlY2soKTsgfVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdwdXNoLWNtcC13aXRoLWhvc3QtZXZlbnQnLFxuICBob3N0OiB7JyhjbGljayknOiAnY3R4Q2FsbGJhY2soJGV2ZW50KSd9LFxuICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcbiAgdGVtcGxhdGU6ICcnXG59KVxuY2xhc3MgUHVzaENtcFdpdGhIb3N0RXZlbnQge1xuICBjdHhDYWxsYmFjazogRnVuY3Rpb24gPSAoXykgPT4ge307XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ3B1c2gtY21wLXdpdGgtYXN5bmMnLFxuICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcbiAgdGVtcGxhdGU6ICd7e2ZpZWxkIHwgYXN5bmN9fScsXG4gIHBpcGVzOiBbQXN5bmNQaXBlXVxufSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIFB1c2hDbXBXaXRoQXN5bmNQaXBlIHtcbiAgbnVtYmVyT2ZDaGVja3M6IG51bWJlciA9IDA7XG4gIHByb21pc2U6IFByb21pc2U8YW55PjtcbiAgY29tcGxldGVyOiBQcm9taXNlQ29tcGxldGVyPGFueT47XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5jb21wbGV0ZXIgPSBQcm9taXNlV3JhcHBlci5jb21wbGV0ZXIoKTtcbiAgICB0aGlzLnByb21pc2UgPSB0aGlzLmNvbXBsZXRlci5wcm9taXNlO1xuICB9XG5cbiAgZ2V0IGZpZWxkKCkge1xuICAgIHRoaXMubnVtYmVyT2ZDaGVja3MrKztcbiAgICByZXR1cm4gdGhpcy5wcm9taXNlO1xuICB9XG5cbiAgcmVzb2x2ZSh2YWx1ZSkgeyB0aGlzLmNvbXBsZXRlci5yZXNvbHZlKHZhbHVlKTsgfVxufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ215LWNvbXAnLCBkaXJlY3RpdmVzOiBbXX0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBNeUNvbXAge1xuICBjdHhQcm9wOiBzdHJpbmc7XG4gIGN0eE51bVByb3A6IG51bWJlcjtcbiAgY3R4Qm9vbFByb3A6IGJvb2xlYW47XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMuY3R4UHJvcCA9ICdpbml0aWFsIHZhbHVlJztcbiAgICB0aGlzLmN0eE51bVByb3AgPSAwO1xuICAgIHRoaXMuY3R4Qm9vbFByb3AgPSBmYWxzZTtcbiAgfVxuXG4gIHRocm93RXJyb3IoKSB7IHRocm93ICdib29tJzsgfVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdjaGlsZC1jbXAnLFxuICBpbnB1dHM6IFsnZGlyUHJvcCddLFxuICB2aWV3UHJvdmlkZXJzOiBbTXlTZXJ2aWNlXSxcbiAgZGlyZWN0aXZlczogW015RGlyXSxcbiAgdGVtcGxhdGU6ICd7e2N0eFByb3B9fSdcbn0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBDaGlsZENvbXAge1xuICBjdHhQcm9wOiBzdHJpbmc7XG4gIGRpclByb3A6IHN0cmluZztcbiAgY29uc3RydWN0b3Ioc2VydmljZTogTXlTZXJ2aWNlKSB7XG4gICAgdGhpcy5jdHhQcm9wID0gc2VydmljZS5ncmVldGluZztcbiAgICB0aGlzLmRpclByb3AgPSBudWxsO1xuICB9XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnY2hpbGQtY21wLW5vLXRlbXBsYXRlJywgZGlyZWN0aXZlczogW10sIHRlbXBsYXRlOiAnJ30pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBDaGlsZENvbXBOb1RlbXBsYXRlIHtcbiAgY3R4UHJvcDogc3RyaW5nID0gJ2hlbGxvJztcbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdjaGlsZC1jbXAtc3ZjJywgdGVtcGxhdGU6ICd7e2N0eFByb3B9fSd9KVxuQEluamVjdGFibGUoKVxuY2xhc3MgQ2hpbGRDb21wVXNpbmdTZXJ2aWNlIHtcbiAgY3R4UHJvcDogc3RyaW5nO1xuICBjb25zdHJ1Y3RvcihzZXJ2aWNlOiBNeVNlcnZpY2UpIHsgdGhpcy5jdHhQcm9wID0gc2VydmljZS5ncmVldGluZzsgfVxufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJ3NvbWUtZGlyZWN0aXZlJ30pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBTb21lRGlyZWN0aXZlIHtcbn1cblxuY2xhc3MgU29tZURpcmVjdGl2ZU1pc3NpbmdBbm5vdGF0aW9uIHt9XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2NtcC13aXRoLWhvc3QnLFxuICB0ZW1wbGF0ZTogJzxwPkNvbXBvbmVudCB3aXRoIGFuIGluamVjdGVkIGhvc3Q8L3A+JyxcbiAgZGlyZWN0aXZlczogW1NvbWVEaXJlY3RpdmVdXG59KVxuQEluamVjdGFibGUoKVxuY2xhc3MgQ29tcFdpdGhIb3N0IHtcbiAgbXlIb3N0OiBTb21lRGlyZWN0aXZlO1xuICBjb25zdHJ1Y3RvcihASG9zdCgpIHNvbWVDb21wOiBTb21lRGlyZWN0aXZlKSB7IHRoaXMubXlIb3N0ID0gc29tZUNvbXA7IH1cbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdbY2hpbGQtY21wMl0nLCB2aWV3UHJvdmlkZXJzOiBbTXlTZXJ2aWNlXX0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBDaGlsZENvbXAyIHtcbiAgY3R4UHJvcDogc3RyaW5nO1xuICBkaXJQcm9wOiBzdHJpbmc7XG4gIGNvbnN0cnVjdG9yKHNlcnZpY2U6IE15U2VydmljZSkge1xuICAgIHRoaXMuY3R4UHJvcCA9IHNlcnZpY2UuZ3JlZXRpbmc7XG4gICAgdGhpcy5kaXJQcm9wID0gbnVsbDtcbiAgfVxufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJ1tzb21lLXZpZXdwb3J0XSd9KVxuQEluamVjdGFibGUoKVxuY2xhc3MgU29tZVZpZXdwb3J0IHtcbiAgY29uc3RydWN0b3IoY29udGFpbmVyOiBWaWV3Q29udGFpbmVyUmVmLCB0ZW1wbGF0ZVJlZjogVGVtcGxhdGVSZWYpIHtcbiAgICBjb250YWluZXIuY3JlYXRlRW1iZWRkZWRWaWV3KHRlbXBsYXRlUmVmKS5zZXRMb2NhbCgnc29tZS10bXBsJywgJ2hlbGxvJyk7XG4gICAgY29udGFpbmVyLmNyZWF0ZUVtYmVkZGVkVmlldyh0ZW1wbGF0ZVJlZikuc2V0TG9jYWwoJ3NvbWUtdG1wbCcsICdhZ2FpbicpO1xuICB9XG59XG5cbkBQaXBlKHtuYW1lOiAnZG91YmxlJ30pXG5jbGFzcyBEb3VibGVQaXBlIGltcGxlbWVudHMgUGlwZVRyYW5zZm9ybSwgT25EZXN0cm95IHtcbiAgbmdPbkRlc3Ryb3koKSB7fVxuICB0cmFuc2Zvcm0odmFsdWUsIGFyZ3MgPSBudWxsKSB7IHJldHVybiBgJHt2YWx1ZX0ke3ZhbHVlfWA7IH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdbZW1pdHRlcl0nLCBvdXRwdXRzOiBbJ2V2ZW50J119KVxuQEluamVjdGFibGUoKVxuY2xhc3MgRGlyZWN0aXZlRW1pdHRpbmdFdmVudCB7XG4gIG1zZzogc3RyaW5nO1xuICBldmVudDogRXZlbnRFbWl0dGVyPGFueT47XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5tc2cgPSAnJztcbiAgICB0aGlzLmV2ZW50ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuICB9XG5cbiAgZmlyZUV2ZW50KG1zZzogc3RyaW5nKSB7IE9ic2VydmFibGVXcmFwcGVyLmNhbGxFbWl0KHRoaXMuZXZlbnQsIG1zZyk7IH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdbdXBkYXRlLWhvc3QtYXR0cmlidXRlc10nLCBob3N0OiB7J3JvbGUnOiAnYnV0dG9uJ319KVxuQEluamVjdGFibGUoKVxuY2xhc3MgRGlyZWN0aXZlVXBkYXRpbmdIb3N0QXR0cmlidXRlcyB7XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnW3VwZGF0ZS1ob3N0LXByb3BlcnRpZXNdJywgaG9zdDogeydbaWRdJzogJ2lkJ319KVxuQEluamVjdGFibGUoKVxuY2xhc3MgRGlyZWN0aXZlVXBkYXRpbmdIb3N0UHJvcGVydGllcyB7XG4gIGlkOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IoKSB7IHRoaXMuaWQgPSBcIm9uZVwiOyB9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnW2xpc3RlbmVyXScsIGhvc3Q6IHsnKGV2ZW50KSc6ICdvbkV2ZW50KCRldmVudCknfX0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBEaXJlY3RpdmVMaXN0ZW5pbmdFdmVudCB7XG4gIG1zZzogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKCkgeyB0aGlzLm1zZyA9ICcnOyB9XG5cbiAgb25FdmVudChtc2c6IHN0cmluZykgeyB0aGlzLm1zZyA9IG1zZzsgfVxufVxuXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdbbGlzdGVuZXJdJyxcbiAgaG9zdDoge1xuICAgICcoZG9tRXZlbnQpJzogJ29uRXZlbnQoJGV2ZW50LnR5cGUpJyxcbiAgICAnKHdpbmRvdzpkb21FdmVudCknOiAnb25XaW5kb3dFdmVudCgkZXZlbnQudHlwZSknLFxuICAgICcoZG9jdW1lbnQ6ZG9tRXZlbnQpJzogJ29uRG9jdW1lbnRFdmVudCgkZXZlbnQudHlwZSknLFxuICAgICcoYm9keTpkb21FdmVudCknOiAnb25Cb2R5RXZlbnQoJGV2ZW50LnR5cGUpJ1xuICB9XG59KVxuQEluamVjdGFibGUoKVxuY2xhc3MgRGlyZWN0aXZlTGlzdGVuaW5nRG9tRXZlbnQge1xuICBldmVudFR5cGVzOiBzdHJpbmdbXSA9IFtdO1xuICBvbkV2ZW50KGV2ZW50VHlwZTogc3RyaW5nKSB7IHRoaXMuZXZlbnRUeXBlcy5wdXNoKGV2ZW50VHlwZSk7IH1cbiAgb25XaW5kb3dFdmVudChldmVudFR5cGU6IHN0cmluZykgeyB0aGlzLmV2ZW50VHlwZXMucHVzaChcIndpbmRvd19cIiArIGV2ZW50VHlwZSk7IH1cbiAgb25Eb2N1bWVudEV2ZW50KGV2ZW50VHlwZTogc3RyaW5nKSB7IHRoaXMuZXZlbnRUeXBlcy5wdXNoKFwiZG9jdW1lbnRfXCIgKyBldmVudFR5cGUpOyB9XG4gIG9uQm9keUV2ZW50KGV2ZW50VHlwZTogc3RyaW5nKSB7IHRoaXMuZXZlbnRUeXBlcy5wdXNoKFwiYm9keV9cIiArIGV2ZW50VHlwZSk7IH1cbn1cblxudmFyIGdsb2JhbENvdW50ZXIgPSAwO1xuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdbbGlzdGVuZXJvdGhlcl0nLCBob3N0OiB7Jyh3aW5kb3c6ZG9tRXZlbnQpJzogJ29uRXZlbnQoJGV2ZW50LnR5cGUpJ319KVxuQEluamVjdGFibGUoKVxuY2xhc3MgRGlyZWN0aXZlTGlzdGVuaW5nRG9tRXZlbnRPdGhlciB7XG4gIGV2ZW50VHlwZTogc3RyaW5nO1xuICBjb25zdHJ1Y3RvcigpIHsgdGhpcy5ldmVudFR5cGUgPSAnJzsgfVxuICBvbkV2ZW50KGV2ZW50VHlwZTogc3RyaW5nKSB7XG4gICAgZ2xvYmFsQ291bnRlcisrO1xuICAgIHRoaXMuZXZlbnRUeXBlID0gXCJvdGhlcl9cIiArIGV2ZW50VHlwZTtcbiAgfVxufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJ1tsaXN0ZW5lcnByZXZlbnRdJywgaG9zdDogeycoY2xpY2spJzogJ29uRXZlbnQoJGV2ZW50KSd9fSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIERpcmVjdGl2ZUxpc3RlbmluZ0RvbUV2ZW50UHJldmVudCB7XG4gIG9uRXZlbnQoZXZlbnQpIHsgcmV0dXJuIGZhbHNlOyB9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnW2xpc3RlbmVybm9wcmV2ZW50XScsIGhvc3Q6IHsnKGNsaWNrKSc6ICdvbkV2ZW50KCRldmVudCknfX0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBEaXJlY3RpdmVMaXN0ZW5pbmdEb21FdmVudE5vUHJldmVudCB7XG4gIG9uRXZlbnQoZXZlbnQpIHsgcmV0dXJuIHRydWU7IH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdbaWRdJywgaW5wdXRzOiBbJ2lkJ119KVxuQEluamVjdGFibGUoKVxuY2xhc3MgSWREaXIge1xuICBpZDogc3RyaW5nO1xufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJ1tjdXN0b21FdmVudF0nfSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIEV2ZW50RGlyIHtcbiAgQE91dHB1dCgpIGN1c3RvbUV2ZW50ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuICBkb1NvbWV0aGluZygpIHt9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnW3N0YXRpY10nfSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIE5lZWRzQXR0cmlidXRlIHtcbiAgdHlwZUF0dHJpYnV0ZTtcbiAgc3RhdGljQXR0cmlidXRlO1xuICBmb29BdHRyaWJ1dGU7XG4gIGNvbnN0cnVjdG9yKEBBdHRyaWJ1dGUoJ3R5cGUnKSB0eXBlQXR0cmlidXRlOiBTdHJpbmcsXG4gICAgICAgICAgICAgIEBBdHRyaWJ1dGUoJ3N0YXRpYycpIHN0YXRpY0F0dHJpYnV0ZTogU3RyaW5nLFxuICAgICAgICAgICAgICBAQXR0cmlidXRlKCdmb28nKSBmb29BdHRyaWJ1dGU6IFN0cmluZykge1xuICAgIHRoaXMudHlwZUF0dHJpYnV0ZSA9IHR5cGVBdHRyaWJ1dGU7XG4gICAgdGhpcy5zdGF0aWNBdHRyaWJ1dGUgPSBzdGF0aWNBdHRyaWJ1dGU7XG4gICAgdGhpcy5mb29BdHRyaWJ1dGUgPSBmb29BdHRyaWJ1dGU7XG4gIH1cbn1cblxuQEluamVjdGFibGUoKVxuY2xhc3MgUHVibGljQXBpIHtcbn1cblxuQERpcmVjdGl2ZSh7XG4gIHNlbGVjdG9yOiAnW3B1YmxpYy1hcGldJyxcbiAgcHJvdmlkZXJzOiBbbmV3IFByb3ZpZGVyKFB1YmxpY0FwaSwge3VzZUV4aXN0aW5nOiBQcml2YXRlSW1wbCwgZGVwczogW119KV1cbn0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBQcml2YXRlSW1wbCBleHRlbmRzIFB1YmxpY0FwaSB7XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnW25lZWRzLXB1YmxpYy1hcGldJ30pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBOZWVkc1B1YmxpY0FwaSB7XG4gIGNvbnN0cnVjdG9yKEBIb3N0KCkgYXBpOiBQdWJsaWNBcGkpIHsgZXhwZWN0KGFwaSBpbnN0YW5jZW9mIFByaXZhdGVJbXBsKS50b0JlKHRydWUpOyB9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnW3Rvb2xiYXJwYXJ0XSd9KVxuQEluamVjdGFibGUoKVxuY2xhc3MgVG9vbGJhclBhcnQge1xuICB0ZW1wbGF0ZVJlZjogVGVtcGxhdGVSZWY7XG4gIGNvbnN0cnVjdG9yKHRlbXBsYXRlUmVmOiBUZW1wbGF0ZVJlZikgeyB0aGlzLnRlbXBsYXRlUmVmID0gdGVtcGxhdGVSZWY7IH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdbdG9vbGJhclZjXScsIGlucHV0czogWyd0b29sYmFyVmMnXX0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBUb29sYmFyVmlld0NvbnRhaW5lciB7XG4gIHZjOiBWaWV3Q29udGFpbmVyUmVmO1xuICBjb25zdHJ1Y3Rvcih2YzogVmlld0NvbnRhaW5lclJlZikgeyB0aGlzLnZjID0gdmM7IH1cblxuICBzZXQgdG9vbGJhclZjKHBhcnQ6IFRvb2xiYXJQYXJ0KSB7XG4gICAgdmFyIHZpZXcgPSB0aGlzLnZjLmNyZWF0ZUVtYmVkZGVkVmlldyhwYXJ0LnRlbXBsYXRlUmVmLCAwKTtcbiAgICB2aWV3LnNldExvY2FsKCd0b29sYmFyUHJvcCcsICdGcm9tIHRvb2xiYXInKTtcbiAgfVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICd0b29sYmFyJyxcbiAgdGVtcGxhdGU6ICdUT09MQkFSKDxkaXYgKm5nRm9yPVwidmFyIHBhcnQgb2YgcXVlcnlcIiBbdG9vbGJhclZjXT1cInBhcnRcIj48L2Rpdj4pJyxcbiAgZGlyZWN0aXZlczogW1Rvb2xiYXJWaWV3Q29udGFpbmVyLCBOZ0Zvcl1cbn0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBUb29sYmFyQ29tcG9uZW50IHtcbiAgcXVlcnk6IFF1ZXJ5TGlzdDxUb29sYmFyUGFydD47XG4gIGN0eFByb3A6IHN0cmluZztcblxuICBjb25zdHJ1Y3RvcihAUXVlcnkoVG9vbGJhclBhcnQpIHF1ZXJ5OiBRdWVyeUxpc3Q8VG9vbGJhclBhcnQ+KSB7XG4gICAgdGhpcy5jdHhQcm9wID0gJ2hlbGxvIHdvcmxkJztcbiAgICB0aGlzLnF1ZXJ5ID0gcXVlcnk7XG4gIH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdbdHdvLXdheV0nLCBpbnB1dHM6IFsnY29udHJvbCddLCBvdXRwdXRzOiBbJ2NvbnRyb2xDaGFuZ2UnXX0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBEaXJlY3RpdmVXaXRoVHdvV2F5QmluZGluZyB7XG4gIGNvbnRyb2xDaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gIGNvbnRyb2wgPSBudWxsO1xuXG4gIHRyaWdnZXJDaGFuZ2UodmFsdWUpIHsgT2JzZXJ2YWJsZVdyYXBwZXIuY2FsbEVtaXQodGhpcy5jb250cm9sQ2hhbmdlLCB2YWx1ZSk7IH1cbn1cblxuQEluamVjdGFibGUoKVxuY2xhc3MgSW5qZWN0YWJsZVNlcnZpY2Uge1xufVxuXG5mdW5jdGlvbiBjcmVhdGVJbmplY3RhYmxlV2l0aExvZ2dpbmcoaW5qOiBJbmplY3Rvcikge1xuICBpbmouZ2V0KENvbXBvbmVudFByb3ZpZGluZ0xvZ2dpbmdJbmplY3RhYmxlKS5jcmVhdGVkID0gdHJ1ZTtcbiAgcmV0dXJuIG5ldyBJbmplY3RhYmxlU2VydmljZSgpO1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdjb21wb25lbnQtcHJvdmlkaW5nLWxvZ2dpbmctaW5qZWN0YWJsZScsXG4gIHByb3ZpZGVyczogW1xuICAgIG5ldyBQcm92aWRlcihJbmplY3RhYmxlU2VydmljZSwge3VzZUZhY3Rvcnk6IGNyZWF0ZUluamVjdGFibGVXaXRoTG9nZ2luZywgZGVwczogW0luamVjdG9yXX0pXG4gIF0sXG4gIHRlbXBsYXRlOiAnJ1xufSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIENvbXBvbmVudFByb3ZpZGluZ0xvZ2dpbmdJbmplY3RhYmxlIHtcbiAgY3JlYXRlZDogYm9vbGVhbiA9IGZhbHNlO1xufVxuXG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnZGlyZWN0aXZlLXByb3ZpZGluZy1pbmplY3RhYmxlJywgcHJvdmlkZXJzOiBbW0luamVjdGFibGVTZXJ2aWNlXV19KVxuQEluamVjdGFibGUoKVxuY2xhc3MgRGlyZWN0aXZlUHJvdmlkaW5nSW5qZWN0YWJsZSB7XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2RpcmVjdGl2ZS1wcm92aWRpbmctaW5qZWN0YWJsZScsXG4gIHZpZXdQcm92aWRlcnM6IFtbSW5qZWN0YWJsZVNlcnZpY2VdXSxcbiAgdGVtcGxhdGU6ICcnXG59KVxuQEluamVjdGFibGUoKVxuY2xhc3MgRGlyZWN0aXZlUHJvdmlkaW5nSW5qZWN0YWJsZUluVmlldyB7XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2RpcmVjdGl2ZS1wcm92aWRpbmctaW5qZWN0YWJsZScsXG4gIHByb3ZpZGVyczogW25ldyBQcm92aWRlcihJbmplY3RhYmxlU2VydmljZSwge3VzZVZhbHVlOiAnaG9zdCd9KV0sXG4gIHZpZXdQcm92aWRlcnM6IFtuZXcgUHJvdmlkZXIoSW5qZWN0YWJsZVNlcnZpY2UsIHt1c2VWYWx1ZTogJ3ZpZXcnfSldLFxuICB0ZW1wbGF0ZTogJydcbn0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBEaXJlY3RpdmVQcm92aWRpbmdJbmplY3RhYmxlSW5Ib3N0QW5kVmlldyB7XG59XG5cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdkaXJlY3RpdmUtY29uc3VtaW5nLWluamVjdGFibGUnLCB0ZW1wbGF0ZTogJyd9KVxuQEluamVjdGFibGUoKVxuY2xhc3MgRGlyZWN0aXZlQ29uc3VtaW5nSW5qZWN0YWJsZSB7XG4gIGluamVjdGFibGU7XG5cbiAgY29uc3RydWN0b3IoQEhvc3QoKSBASW5qZWN0KEluamVjdGFibGVTZXJ2aWNlKSBpbmplY3RhYmxlKSB7IHRoaXMuaW5qZWN0YWJsZSA9IGluamVjdGFibGU7IH1cbn1cblxuXG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnZGlyZWN0aXZlLWNvbnRhaW5pbmctZGlyZWN0aXZlLWNvbnN1bWluZy1hbi1pbmplY3RhYmxlJ30pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBEaXJlY3RpdmVDb250YWluaW5nRGlyZWN0aXZlQ29uc3VtaW5nQW5JbmplY3RhYmxlIHtcbiAgZGlyZWN0aXZlO1xufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ2RpcmVjdGl2ZS1jb25zdW1pbmctaW5qZWN0YWJsZS11bmJvdW5kZWQnLCB0ZW1wbGF0ZTogJyd9KVxuQEluamVjdGFibGUoKVxuY2xhc3MgRGlyZWN0aXZlQ29uc3VtaW5nSW5qZWN0YWJsZVVuYm91bmRlZCB7XG4gIGluamVjdGFibGU7XG5cbiAgY29uc3RydWN0b3IoaW5qZWN0YWJsZTogSW5qZWN0YWJsZVNlcnZpY2UsXG4gICAgICAgICAgICAgIEBTa2lwU2VsZigpIHBhcmVudDogRGlyZWN0aXZlQ29udGFpbmluZ0RpcmVjdGl2ZUNvbnN1bWluZ0FuSW5qZWN0YWJsZSkge1xuICAgIHRoaXMuaW5qZWN0YWJsZSA9IGluamVjdGFibGU7XG4gICAgcGFyZW50LmRpcmVjdGl2ZSA9IHRoaXM7XG4gIH1cbn1cblxuXG5AQ09OU1QoKVxuY2xhc3MgRXZlbnRCdXMge1xuICBwYXJlbnRFdmVudEJ1czogRXZlbnRCdXM7XG4gIG5hbWU6IHN0cmluZztcblxuICBjb25zdHJ1Y3RvcihwYXJlbnRFdmVudEJ1czogRXZlbnRCdXMsIG5hbWU6IHN0cmluZykge1xuICAgIHRoaXMucGFyZW50RXZlbnRCdXMgPSBwYXJlbnRFdmVudEJ1cztcbiAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICB9XG59XG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ2dyYW5kLXBhcmVudC1wcm92aWRpbmctZXZlbnQtYnVzJyxcbiAgcHJvdmlkZXJzOiBbbmV3IFByb3ZpZGVyKEV2ZW50QnVzLCB7dXNlVmFsdWU6IG5ldyBFdmVudEJ1cyhudWxsLCBcImdyYW5kcGFyZW50XCIpfSldXG59KVxuY2xhc3MgR3JhbmRQYXJlbnRQcm92aWRpbmdFdmVudEJ1cyB7XG4gIGJ1czogRXZlbnRCdXM7XG5cbiAgY29uc3RydWN0b3IoYnVzOiBFdmVudEJ1cykgeyB0aGlzLmJ1cyA9IGJ1czsgfVxufVxuXG5mdW5jdGlvbiBjcmVhdGVQYXJlbnRCdXMocGViKSB7XG4gIHJldHVybiBuZXcgRXZlbnRCdXMocGViLCBcInBhcmVudFwiKTtcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAncGFyZW50LXByb3ZpZGluZy1ldmVudC1idXMnLFxuICBwcm92aWRlcnM6IFtcbiAgICBuZXcgUHJvdmlkZXIoRXZlbnRCdXMsXG4gICAgICAgICAgICAgICAgIHt1c2VGYWN0b3J5OiBjcmVhdGVQYXJlbnRCdXMsIGRlcHM6IFtbRXZlbnRCdXMsIG5ldyBTa2lwU2VsZk1ldGFkYXRhKCldXX0pXG4gIF0sXG4gIGRpcmVjdGl2ZXM6IFtmb3J3YXJkUmVmKCgpID0+IENoaWxkQ29uc3VtaW5nRXZlbnRCdXMpXSxcbiAgdGVtcGxhdGU6IGBcbiAgICA8Y2hpbGQtY29uc3VtaW5nLWV2ZW50LWJ1cz48L2NoaWxkLWNvbnN1bWluZy1ldmVudC1idXM+XG4gIGBcbn0pXG5jbGFzcyBQYXJlbnRQcm92aWRpbmdFdmVudEJ1cyB7XG4gIGJ1czogRXZlbnRCdXM7XG4gIGdyYW5kUGFyZW50QnVzOiBFdmVudEJ1cztcblxuICBjb25zdHJ1Y3RvcihidXM6IEV2ZW50QnVzLCBAU2tpcFNlbGYoKSBncmFuZFBhcmVudEJ1czogRXZlbnRCdXMpIHtcbiAgICB0aGlzLmJ1cyA9IGJ1cztcbiAgICB0aGlzLmdyYW5kUGFyZW50QnVzID0gZ3JhbmRQYXJlbnRCdXM7XG4gIH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdjaGlsZC1jb25zdW1pbmctZXZlbnQtYnVzJ30pXG5jbGFzcyBDaGlsZENvbnN1bWluZ0V2ZW50QnVzIHtcbiAgYnVzOiBFdmVudEJ1cztcblxuICBjb25zdHJ1Y3RvcihAU2tpcFNlbGYoKSBidXM6IEV2ZW50QnVzKSB7IHRoaXMuYnVzID0gYnVzOyB9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnW3NvbWVJbXB2cF0nLCBpbnB1dHM6IFsnc29tZUltcHZwJ119KVxuQEluamVjdGFibGUoKVxuY2xhc3MgU29tZUltcGVyYXRpdmVWaWV3cG9ydCB7XG4gIHZpZXc6IEVtYmVkZGVkVmlld1JlZjtcbiAgYW5jaG9yO1xuICBjb25zdHJ1Y3RvcihwdWJsaWMgdmM6IFZpZXdDb250YWluZXJSZWYsIHB1YmxpYyB0ZW1wbGF0ZVJlZjogVGVtcGxhdGVSZWYsXG4gICAgICAgICAgICAgIEBJbmplY3QoQU5DSE9SX0VMRU1FTlQpIGFuY2hvcikge1xuICAgIHRoaXMudmlldyA9IG51bGw7XG4gICAgdGhpcy5hbmNob3IgPSBhbmNob3I7XG4gIH1cblxuICBzZXQgc29tZUltcHZwKHZhbHVlOiBib29sZWFuKSB7XG4gICAgaWYgKGlzUHJlc2VudCh0aGlzLnZpZXcpKSB7XG4gICAgICB0aGlzLnZjLmNsZWFyKCk7XG4gICAgICB0aGlzLnZpZXcgPSBudWxsO1xuICAgIH1cbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIHRoaXMudmlldyA9IHRoaXMudmMuY3JlYXRlRW1iZWRkZWRWaWV3KHRoaXMudGVtcGxhdGVSZWYpO1xuICAgICAgdmFyIG5vZGVzID0gdGhpcy52aWV3LnJvb3ROb2RlcztcbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbm9kZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgRE9NLmFwcGVuZENoaWxkKHRoaXMuYW5jaG9yLCBub2Rlc1tpXSk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnW2V4cG9ydC1kaXJdJywgZXhwb3J0QXM6ICdkaXInfSlcbmNsYXNzIEV4cG9ydERpciB7XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnY29tcCd9KVxuY2xhc3MgQ29tcG9uZW50V2l0aG91dFZpZXcge1xufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJ1tuby1kdXBsaWNhdGVdJ30pXG5jbGFzcyBEdXBsaWNhdGVEaXIge1xuICBjb25zdHJ1Y3RvcihlbFJlZjogRWxlbWVudFJlZikge1xuICAgIERPTS5zZXRUZXh0KGVsUmVmLm5hdGl2ZUVsZW1lbnQsIERPTS5nZXRUZXh0KGVsUmVmLm5hdGl2ZUVsZW1lbnQpICsgJ25vZHVwbGljYXRlJyk7XG4gIH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdbbm8tZHVwbGljYXRlXSd9KVxuY2xhc3MgT3RoZXJEdXBsaWNhdGVEaXIge1xuICBjb25zdHJ1Y3RvcihlbFJlZjogRWxlbWVudFJlZikge1xuICAgIERPTS5zZXRUZXh0KGVsUmVmLm5hdGl2ZUVsZW1lbnQsIERPTS5nZXRUZXh0KGVsUmVmLm5hdGl2ZUVsZW1lbnQpICsgJ290aGVybm9kdXBsaWNhdGUnKTtcbiAgfVxufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJ2RpcmVjdGl2ZS10aHJvd2luZy1lcnJvcid9KVxuY2xhc3MgRGlyZWN0aXZlVGhyb3dpbmdBbkVycm9yIHtcbiAgY29uc3RydWN0b3IoKSB7IHRocm93IG5ldyBCYXNlRXhjZXB0aW9uKFwiQk9PTVwiKTsgfVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdjb21wb25lbnQtd2l0aC10ZW1wbGF0ZScsXG4gIGRpcmVjdGl2ZXM6IFtOZ0Zvcl0sXG4gIHRlbXBsYXRlOiBgTm8gVmlldyBEZWNvcmF0b3I6IDxkaXYgKm5nRm9yPVwiI2l0ZW0gb2YgaXRlbXNcIj57e2l0ZW19fTwvZGl2PmBcbn0pXG5jbGFzcyBDb21wb25lbnRXaXRoVGVtcGxhdGUge1xuICBpdGVtcyA9IFsxLCAyLCAzXTtcbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICd3aXRoLXByb3AtZGVjb3JhdG9ycyd9KVxuY2xhc3MgRGlyZWN0aXZlV2l0aFByb3BEZWNvcmF0b3JzIHtcbiAgdGFyZ2V0O1xuXG4gIEBJbnB1dCgnZWxQcm9wJykgZGlyUHJvcDogc3RyaW5nO1xuICBAT3V0cHV0KCdlbEV2ZW50JykgZXZlbnQgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG5cbiAgQEhvc3RCaW5kaW5nKFwiYXR0ci5teS1hdHRyXCIpIG15QXR0cjogc3RyaW5nO1xuICBASG9zdExpc3RlbmVyKFwiY2xpY2tcIiwgW1wiJGV2ZW50LnRhcmdldFwiXSlcbiAgb25DbGljayh0YXJnZXQpIHtcbiAgICB0aGlzLnRhcmdldCA9IHRhcmdldDtcbiAgfVxuXG4gIGZpcmVFdmVudChtc2cpIHsgT2JzZXJ2YWJsZVdyYXBwZXIuY2FsbEVtaXQodGhpcy5ldmVudCwgbXNnKTsgfVxufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ3NvbWUtY21wJ30pXG5jbGFzcyBTb21lQ21wIHtcbiAgdmFsdWU6IGFueTtcbn1cbiJdfQ==
 main(); 
