'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
// TODO(tbosch): clang-format screws this up, see https://github.com/angular/clang-format/issues/11.
// Enable clang-format here again when this is fixed.
// clang-format off
var testing_internal_1 = require('angular2/testing_internal');
var spies_1 = require('../spies');
var lang_1 = require('angular2/src/facade/lang');
var collection_1 = require('angular2/src/facade/collection');
var element_1 = require('angular2/src/core/linker/element');
var resolved_metadata_cache_1 = require('angular2/src/core/linker/resolved_metadata_cache');
var directive_resolver_1 = require('angular2/src/core/linker/directive_resolver');
var metadata_1 = require('angular2/src/core/metadata');
var core_1 = require('angular2/core');
var core_2 = require('angular2/core');
var view_container_ref_1 = require('angular2/src/core/linker/view_container_ref');
var template_ref_1 = require('angular2/src/core/linker/template_ref');
var element_ref_1 = require('angular2/src/core/linker/element_ref');
var change_detection_1 = require('angular2/src/core/change_detection/change_detection');
var change_detector_ref_1 = require('angular2/src/core/change_detection/change_detector_ref');
var query_list_1 = require('angular2/src/core/linker/query_list');
var view_1 = require("angular2/src/core/linker/view");
var view_type_1 = require("angular2/src/core/linker/view_type");
var SimpleDirective = (function () {
    function SimpleDirective() {
    }
    SimpleDirective = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], SimpleDirective);
    return SimpleDirective;
})();
var SimpleService = (function () {
    function SimpleService() {
    }
    return SimpleService;
})();
var SomeOtherDirective = (function () {
    function SomeOtherDirective() {
    }
    SomeOtherDirective = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], SomeOtherDirective);
    return SomeOtherDirective;
})();
var _constructionCount;
var CountingDirective = (function () {
    function CountingDirective() {
        this.count = _constructionCount;
        _constructionCount += 1;
    }
    CountingDirective = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], CountingDirective);
    return CountingDirective;
})();
var FancyCountingDirective = (function (_super) {
    __extends(FancyCountingDirective, _super);
    function FancyCountingDirective() {
        _super.call(this);
    }
    FancyCountingDirective = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], FancyCountingDirective);
    return FancyCountingDirective;
})(CountingDirective);
var NeedsDirective = (function () {
    function NeedsDirective(dependency) {
        this.dependency = dependency;
    }
    NeedsDirective = __decorate([
        core_1.Directive({ selector: '' }),
        __param(0, core_2.Self()), 
        __metadata('design:paramtypes', [SimpleDirective])
    ], NeedsDirective);
    return NeedsDirective;
})();
var OptionallyNeedsDirective = (function () {
    function OptionallyNeedsDirective(dependency) {
        this.dependency = dependency;
    }
    OptionallyNeedsDirective = __decorate([
        core_1.Directive({ selector: '' }),
        __param(0, core_2.Self()),
        __param(0, core_2.Optional()), 
        __metadata('design:paramtypes', [SimpleDirective])
    ], OptionallyNeedsDirective);
    return OptionallyNeedsDirective;
})();
var NeeedsDirectiveFromHost = (function () {
    function NeeedsDirectiveFromHost(dependency) {
        this.dependency = dependency;
    }
    NeeedsDirectiveFromHost = __decorate([
        core_1.Directive({ selector: '' }),
        __param(0, core_2.Host()), 
        __metadata('design:paramtypes', [SimpleDirective])
    ], NeeedsDirectiveFromHost);
    return NeeedsDirectiveFromHost;
})();
var NeedsDirectiveFromHostShadowDom = (function () {
    function NeedsDirectiveFromHostShadowDom(dependency) {
        this.dependency = dependency;
    }
    NeedsDirectiveFromHostShadowDom = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [SimpleDirective])
    ], NeedsDirectiveFromHostShadowDom);
    return NeedsDirectiveFromHostShadowDom;
})();
var NeedsService = (function () {
    function NeedsService(service) {
        this.service = service;
    }
    NeedsService = __decorate([
        core_1.Directive({ selector: '' }),
        __param(0, core_2.Inject("service")), 
        __metadata('design:paramtypes', [Object])
    ], NeedsService);
    return NeedsService;
})();
var NeedsServiceFromHost = (function () {
    function NeedsServiceFromHost(service) {
        this.service = service;
    }
    NeedsServiceFromHost = __decorate([
        core_1.Directive({ selector: '' }),
        __param(0, core_2.Host()),
        __param(0, core_2.Inject("service")), 
        __metadata('design:paramtypes', [Object])
    ], NeedsServiceFromHost);
    return NeedsServiceFromHost;
})();
var HasEventEmitter = (function () {
    function HasEventEmitter() {
        this.emitter = "emitter";
    }
    return HasEventEmitter;
})();
var NeedsAttribute = (function () {
    function NeedsAttribute(typeAttribute, titleAttribute, fooAttribute) {
        this.typeAttribute = typeAttribute;
        this.titleAttribute = titleAttribute;
        this.fooAttribute = fooAttribute;
    }
    NeedsAttribute = __decorate([
        core_1.Directive({ selector: '' }),
        __param(0, metadata_1.Attribute('type')),
        __param(1, metadata_1.Attribute('title')),
        __param(2, metadata_1.Attribute('foo')), 
        __metadata('design:paramtypes', [String, String, String])
    ], NeedsAttribute);
    return NeedsAttribute;
})();
var NeedsAttributeNoType = (function () {
    function NeedsAttributeNoType(fooAttribute) {
        this.fooAttribute = fooAttribute;
    }
    NeedsAttributeNoType = __decorate([
        core_1.Directive({ selector: '' }),
        __param(0, metadata_1.Attribute('foo')), 
        __metadata('design:paramtypes', [Object])
    ], NeedsAttributeNoType);
    return NeedsAttributeNoType;
})();
var NeedsQuery = (function () {
    function NeedsQuery(query) {
        this.query = query;
    }
    NeedsQuery = __decorate([
        core_1.Directive({ selector: '' }),
        __param(0, metadata_1.Query(CountingDirective)), 
        __metadata('design:paramtypes', [query_list_1.QueryList])
    ], NeedsQuery);
    return NeedsQuery;
})();
var NeedsViewQuery = (function () {
    function NeedsViewQuery(query) {
        this.query = query;
    }
    NeedsViewQuery = __decorate([
        core_1.Directive({ selector: '' }),
        __param(0, metadata_1.ViewQuery(CountingDirective)), 
        __metadata('design:paramtypes', [query_list_1.QueryList])
    ], NeedsViewQuery);
    return NeedsViewQuery;
})();
var NeedsQueryByVarBindings = (function () {
    function NeedsQueryByVarBindings(query) {
        this.query = query;
    }
    NeedsQueryByVarBindings = __decorate([
        core_1.Directive({ selector: '' }),
        __param(0, metadata_1.Query("one,two")), 
        __metadata('design:paramtypes', [query_list_1.QueryList])
    ], NeedsQueryByVarBindings);
    return NeedsQueryByVarBindings;
})();
var NeedsTemplateRefQuery = (function () {
    function NeedsTemplateRefQuery(query) {
        this.query = query;
    }
    NeedsTemplateRefQuery = __decorate([
        core_1.Directive({ selector: '' }),
        __param(0, metadata_1.Query(template_ref_1.TemplateRef)), 
        __metadata('design:paramtypes', [query_list_1.QueryList])
    ], NeedsTemplateRefQuery);
    return NeedsTemplateRefQuery;
})();
var NeedsElementRef = (function () {
    function NeedsElementRef(ref) {
        this.elementRef = ref;
    }
    NeedsElementRef = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [element_ref_1.ElementRef])
    ], NeedsElementRef);
    return NeedsElementRef;
})();
var NeedsViewContainer = (function () {
    function NeedsViewContainer(vc) {
        this.viewContainer = vc;
    }
    NeedsViewContainer = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [view_container_ref_1.ViewContainerRef])
    ], NeedsViewContainer);
    return NeedsViewContainer;
})();
var NeedsTemplateRef = (function () {
    function NeedsTemplateRef(ref) {
        this.templateRef = ref;
    }
    NeedsTemplateRef = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [template_ref_1.TemplateRef])
    ], NeedsTemplateRef);
    return NeedsTemplateRef;
})();
var OptionallyInjectsTemplateRef = (function () {
    function OptionallyInjectsTemplateRef(ref) {
        this.templateRef = ref;
    }
    OptionallyInjectsTemplateRef = __decorate([
        core_1.Directive({ selector: '' }),
        __param(0, core_2.Optional()), 
        __metadata('design:paramtypes', [template_ref_1.TemplateRef])
    ], OptionallyInjectsTemplateRef);
    return OptionallyInjectsTemplateRef;
})();
var DirectiveNeedsChangeDetectorRef = (function () {
    function DirectiveNeedsChangeDetectorRef(changeDetectorRef) {
        this.changeDetectorRef = changeDetectorRef;
    }
    DirectiveNeedsChangeDetectorRef = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [change_detection_1.ChangeDetectorRef])
    ], DirectiveNeedsChangeDetectorRef);
    return DirectiveNeedsChangeDetectorRef;
})();
var ComponentNeedsChangeDetectorRef = (function () {
    function ComponentNeedsChangeDetectorRef(changeDetectorRef) {
        this.changeDetectorRef = changeDetectorRef;
    }
    ComponentNeedsChangeDetectorRef = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [change_detection_1.ChangeDetectorRef])
    ], ComponentNeedsChangeDetectorRef);
    return ComponentNeedsChangeDetectorRef;
})();
var PipeNeedsChangeDetectorRef = (function () {
    function PipeNeedsChangeDetectorRef(changeDetectorRef) {
        this.changeDetectorRef = changeDetectorRef;
    }
    PipeNeedsChangeDetectorRef = __decorate([
        core_2.Injectable(), 
        __metadata('design:paramtypes', [change_detection_1.ChangeDetectorRef])
    ], PipeNeedsChangeDetectorRef);
    return PipeNeedsChangeDetectorRef;
})();
var A_Needs_B = (function () {
    function A_Needs_B(dep) {
    }
    return A_Needs_B;
})();
var B_Needs_A = (function () {
    function B_Needs_A(dep) {
    }
    return B_Needs_A;
})();
var DirectiveWithDestroy = (function () {
    function DirectiveWithDestroy() {
        this.ngOnDestroyCounter = 0;
    }
    DirectiveWithDestroy.prototype.ngOnDestroy = function () { this.ngOnDestroyCounter++; };
    return DirectiveWithDestroy;
})();
var D0 = (function () {
    function D0() {
    }
    D0 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D0);
    return D0;
})();
var D1 = (function () {
    function D1() {
    }
    D1 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D1);
    return D1;
})();
var D2 = (function () {
    function D2() {
    }
    D2 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D2);
    return D2;
})();
var D3 = (function () {
    function D3() {
    }
    D3 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D3);
    return D3;
})();
var D4 = (function () {
    function D4() {
    }
    D4 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D4);
    return D4;
})();
var D5 = (function () {
    function D5() {
    }
    D5 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D5);
    return D5;
})();
var D6 = (function () {
    function D6() {
    }
    D6 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D6);
    return D6;
})();
var D7 = (function () {
    function D7() {
    }
    D7 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D7);
    return D7;
})();
var D8 = (function () {
    function D8() {
    }
    D8 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D8);
    return D8;
})();
var D9 = (function () {
    function D9() {
    }
    D9 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D9);
    return D9;
})();
var D10 = (function () {
    function D10() {
    }
    D10 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D10);
    return D10;
})();
var D11 = (function () {
    function D11() {
    }
    D11 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D11);
    return D11;
})();
var D12 = (function () {
    function D12() {
    }
    D12 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D12);
    return D12;
})();
var D13 = (function () {
    function D13() {
    }
    D13 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D13);
    return D13;
})();
var D14 = (function () {
    function D14() {
    }
    D14 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D14);
    return D14;
})();
var D15 = (function () {
    function D15() {
    }
    D15 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D15);
    return D15;
})();
var D16 = (function () {
    function D16() {
    }
    D16 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D16);
    return D16;
})();
var D17 = (function () {
    function D17() {
    }
    D17 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D17);
    return D17;
})();
var D18 = (function () {
    function D18() {
    }
    D18 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D18);
    return D18;
})();
var D19 = (function () {
    function D19() {
    }
    D19 = __decorate([
        core_1.Directive({ selector: '' }), 
        __metadata('design:paramtypes', [])
    ], D19);
    return D19;
})();
function main() {
    // An injector with more than 10 providers will switch to the dynamic strategy
    var dynamicStrategyDirectives = [D0, D1, D2, D3, D4, D5, D6, D7, D8, D9, D10, D11, D12, D13, D14, D15, D16, D17, D18, D19];
    var resolvedMetadataCache;
    var mockDirectiveMeta;
    var directiveResolver;
    var dummyView;
    var dummyViewFactory;
    function createView(type, containerAppElement, imperativelyCreatedProviders, rootInjector, pipes) {
        if (containerAppElement === void 0) { containerAppElement = null; }
        if (imperativelyCreatedProviders === void 0) { imperativelyCreatedProviders = null; }
        if (rootInjector === void 0) { rootInjector = null; }
        if (pipes === void 0) { pipes = null; }
        if (lang_1.isBlank(pipes)) {
            pipes = [];
        }
        var proto = view_1.AppProtoView.create(resolvedMetadataCache, type, pipes, {});
        var cd = new spies_1.SpyChangeDetector();
        cd.prop('ref', new change_detector_ref_1.ChangeDetectorRef_(cd));
        var view = new view_1.AppView(proto, null, new spies_1.SpyAppViewManager(), [], containerAppElement, imperativelyCreatedProviders, rootInjector, cd);
        view.init([], [], [], []);
        return view;
    }
    function protoAppElement(index, directives, attributes, dirVariableBindings) {
        if (attributes === void 0) { attributes = null; }
        if (dirVariableBindings === void 0) { dirVariableBindings = null; }
        return element_1.AppProtoElement.create(resolvedMetadataCache, index, attributes, directives, dirVariableBindings);
    }
    function appElement(parent, directives, view, embeddedViewFactory, attributes, dirVariableBindings) {
        if (view === void 0) { view = null; }
        if (embeddedViewFactory === void 0) { embeddedViewFactory = null; }
        if (attributes === void 0) { attributes = null; }
        if (dirVariableBindings === void 0) { dirVariableBindings = null; }
        if (lang_1.isBlank(view)) {
            view = dummyView;
        }
        var proto = protoAppElement(0, directives, attributes, dirVariableBindings);
        var el = new element_1.AppElement(proto, view, parent, null, embeddedViewFactory);
        view.appElements.push(el);
        return el;
    }
    function parentChildElements(parentDirectives, childDirectives, view) {
        if (view === void 0) { view = null; }
        if (lang_1.isBlank(view)) {
            view = dummyView;
        }
        var parent = appElement(null, parentDirectives, view);
        var child = appElement(parent, childDirectives, view);
        return child;
    }
    function hostShadowElement(hostDirectives, viewDirectives) {
        var host = appElement(null, hostDirectives);
        var view = createView(view_type_1.ViewType.COMPONENT, host);
        host.attachComponentView(view);
        return appElement(null, viewDirectives, view);
    }
    function init() {
        testing_internal_1.beforeEachBindings(function () {
            var delegateDirectiveResolver = new directive_resolver_1.DirectiveResolver();
            directiveResolver = new spies_1.SpyDirectiveResolver();
            directiveResolver.spy('resolve').andCallFake(function (directiveType) {
                var result = mockDirectiveMeta.get(directiveType);
                if (lang_1.isBlank(result)) {
                    result = delegateDirectiveResolver.resolve(directiveType);
                }
                return result;
            });
            return [
                core_2.provide(directive_resolver_1.DirectiveResolver, { useValue: directiveResolver })
            ];
        });
        testing_internal_1.beforeEach(testing_internal_1.inject([resolved_metadata_cache_1.ResolvedMetadataCache], function (_metadataCache) {
            mockDirectiveMeta = new Map();
            resolvedMetadataCache = _metadataCache;
            dummyView = createView(view_type_1.ViewType.HOST);
            dummyViewFactory = function () { };
            _constructionCount = 0;
        }));
    }
    testing_internal_1.describe("ProtoAppElement", function () {
        init();
        testing_internal_1.describe('inline strategy', function () {
            testing_internal_1.it("should allow for direct access using getProviderAtIndex", function () {
                var proto = protoAppElement(0, [SimpleDirective]);
                testing_internal_1.expect(proto.getProviderAtIndex(0)).toBeAnInstanceOf(element_1.DirectiveProvider);
                testing_internal_1.expect(function () { return proto.getProviderAtIndex(-1); }).toThrowError('Index -1 is out-of-bounds.');
                testing_internal_1.expect(function () { return proto.getProviderAtIndex(10); }).toThrowError('Index 10 is out-of-bounds.');
            });
        });
        testing_internal_1.describe('dynamic strategy', function () {
            testing_internal_1.it("should allow for direct access using getProviderAtIndex", function () {
                var proto = protoAppElement(0, dynamicStrategyDirectives);
                testing_internal_1.expect(proto.getProviderAtIndex(0)).toBeAnInstanceOf(element_1.DirectiveProvider);
                testing_internal_1.expect(function () { return proto.getProviderAtIndex(-1); }).toThrowError('Index -1 is out-of-bounds.');
                testing_internal_1.expect(function () { return proto.getProviderAtIndex(dynamicStrategyDirectives.length - 1); }).not.toThrow();
                testing_internal_1.expect(function () { return proto.getProviderAtIndex(dynamicStrategyDirectives.length); })
                    .toThrowError("Index " + dynamicStrategyDirectives.length + " is out-of-bounds.");
            });
        });
        testing_internal_1.describe(".create", function () {
            testing_internal_1.it("should collect providers from all directives", function () {
                mockDirectiveMeta.set(SimpleDirective, new metadata_1.DirectiveMetadata({ providers: [core_2.provide('injectable1', { useValue: 'injectable1' })] }));
                mockDirectiveMeta.set(SomeOtherDirective, new metadata_1.DirectiveMetadata({
                    providers: [core_2.provide('injectable2', { useValue: 'injectable2' })]
                }));
                var pel = protoAppElement(0, [
                    SimpleDirective,
                    SomeOtherDirective
                ]);
                testing_internal_1.expect(pel.getProviderAtIndex(0).key.token).toBe(SimpleDirective);
                testing_internal_1.expect(pel.getProviderAtIndex(1).key.token).toBe(SomeOtherDirective);
                testing_internal_1.expect(pel.getProviderAtIndex(2).key.token).toEqual("injectable1");
                testing_internal_1.expect(pel.getProviderAtIndex(3).key.token).toEqual("injectable2");
            });
            testing_internal_1.it("should collect view providers from the component", function () {
                mockDirectiveMeta.set(SimpleDirective, new metadata_1.ComponentMetadata({
                    viewProviders: [core_2.provide('injectable1', { useValue: 'injectable1' })]
                }));
                var pel = protoAppElement(0, [SimpleDirective]);
                testing_internal_1.expect(pel.getProviderAtIndex(0).key.token).toBe(SimpleDirective);
                testing_internal_1.expect(pel.getProviderAtIndex(1).key.token).toEqual("injectable1");
            });
            testing_internal_1.it("should flatten nested arrays in viewProviders and providers", function () {
                mockDirectiveMeta.set(SimpleDirective, new metadata_1.ComponentMetadata({
                    viewProviders: [[[core_2.provide('view', { useValue: 'view' })]]],
                    providers: [[[core_2.provide('host', { useValue: 'host' })]]]
                }));
                var pel = protoAppElement(0, [SimpleDirective]);
                testing_internal_1.expect(pel.getProviderAtIndex(0).key.token).toBe(SimpleDirective);
                testing_internal_1.expect(pel.getProviderAtIndex(1).key.token).toEqual("view");
                testing_internal_1.expect(pel.getProviderAtIndex(2).key.token).toEqual("host");
            });
            testing_internal_1.it('should support an arbitrary number of providers', function () {
                var pel = protoAppElement(0, dynamicStrategyDirectives);
                testing_internal_1.expect(pel.getProviderAtIndex(0).key.token).toBe(D0);
                testing_internal_1.expect(pel.getProviderAtIndex(19).key.token).toBe(D19);
            });
        });
    });
    testing_internal_1.describe("AppElement", function () {
        init();
        [{ strategy: 'inline', directives: [] }, { strategy: 'dynamic',
                directives: dynamicStrategyDirectives }].forEach(function (context) {
            var extraDirectives = context['directives'];
            testing_internal_1.describe(context['strategy'] + " strategy", function () {
                testing_internal_1.describe("injection", function () {
                    testing_internal_1.it("should instantiate directives that have no dependencies", function () {
                        var directives = collection_1.ListWrapper.concat([SimpleDirective], extraDirectives);
                        var el = appElement(null, directives);
                        testing_internal_1.expect(el.get(SimpleDirective)).toBeAnInstanceOf(SimpleDirective);
                    });
                    testing_internal_1.it("should instantiate directives that depend on an arbitrary number of directives", function () {
                        var directives = collection_1.ListWrapper.concat([SimpleDirective, NeedsDirective], extraDirectives);
                        var el = appElement(null, directives);
                        var d = el.get(NeedsDirective);
                        testing_internal_1.expect(d).toBeAnInstanceOf(NeedsDirective);
                        testing_internal_1.expect(d.dependency).toBeAnInstanceOf(SimpleDirective);
                    });
                    testing_internal_1.it("should instantiate providers that have dependencies with set visibility", function () {
                        mockDirectiveMeta.set(SimpleDirective, new metadata_1.ComponentMetadata({
                            providers: [core_2.provide('injectable1', { useValue: 'injectable1' })]
                        }));
                        mockDirectiveMeta.set(SomeOtherDirective, new metadata_1.ComponentMetadata({
                            providers: [
                                core_2.provide('injectable1', { useValue: 'new-injectable1' }),
                                core_2.provide('injectable2', { useFactory: function (val) { return (val + "-injectable2"); },
                                    deps: [[new core_2.InjectMetadata('injectable1'), new core_2.SkipSelfMetadata()]] })
                            ]
                        }));
                        var childInj = parentChildElements(collection_1.ListWrapper.concat([SimpleDirective], extraDirectives), [SomeOtherDirective]);
                        testing_internal_1.expect(childInj.get('injectable2')).toEqual('injectable1-injectable2');
                    });
                    testing_internal_1.it("should instantiate providers that have dependencies", function () {
                        var providers = [
                            core_2.provide('injectable1', { useValue: 'injectable1' }),
                            core_2.provide('injectable2', { useFactory: function (val) { return (val + "-injectable2"); },
                                deps: ['injectable1'] })
                        ];
                        mockDirectiveMeta.set(SimpleDirective, new metadata_1.DirectiveMetadata({ providers: providers }));
                        var el = appElement(null, collection_1.ListWrapper.concat([SimpleDirective], extraDirectives));
                        testing_internal_1.expect(el.get('injectable2')).toEqual('injectable1-injectable2');
                    });
                    testing_internal_1.it("should instantiate viewProviders that have dependencies", function () {
                        var viewProviders = [
                            core_2.provide('injectable1', { useValue: 'injectable1' }),
                            core_2.provide('injectable2', { useFactory: function (val) { return (val + "-injectable2"); },
                                deps: ['injectable1'] })
                        ];
                        mockDirectiveMeta.set(SimpleDirective, new metadata_1.ComponentMetadata({
                            viewProviders: viewProviders }));
                        var el = appElement(null, collection_1.ListWrapper.concat([SimpleDirective], extraDirectives));
                        testing_internal_1.expect(el.get('injectable2')).toEqual('injectable1-injectable2');
                    });
                    testing_internal_1.it("should instantiate components that depend on viewProviders providers", function () {
                        mockDirectiveMeta.set(NeedsService, new metadata_1.ComponentMetadata({
                            viewProviders: [core_2.provide('service', { useValue: 'service' })]
                        }));
                        var el = appElement(null, collection_1.ListWrapper.concat([NeedsService], extraDirectives));
                        testing_internal_1.expect(el.get(NeedsService).service).toEqual('service');
                    });
                    testing_internal_1.it("should instantiate providers lazily", function () {
                        var created = false;
                        mockDirectiveMeta.set(SimpleDirective, new metadata_1.ComponentMetadata({
                            providers: [core_2.provide('service', { useFactory: function () { return created = true; } })]
                        }));
                        var el = appElement(null, collection_1.ListWrapper.concat([SimpleDirective], extraDirectives));
                        testing_internal_1.expect(created).toBe(false);
                        el.get('service');
                        testing_internal_1.expect(created).toBe(true);
                    });
                    testing_internal_1.it("should instantiate view providers lazily", function () {
                        var created = false;
                        mockDirectiveMeta.set(SimpleDirective, new metadata_1.ComponentMetadata({
                            viewProviders: [core_2.provide('service', { useFactory: function () { return created = true; } })]
                        }));
                        var el = appElement(null, collection_1.ListWrapper.concat([SimpleDirective], extraDirectives));
                        testing_internal_1.expect(created).toBe(false);
                        el.get('service');
                        testing_internal_1.expect(created).toBe(true);
                    });
                    testing_internal_1.it("should not instantiate other directives that depend on viewProviders providers", function () {
                        mockDirectiveMeta.set(SimpleDirective, new metadata_1.ComponentMetadata({
                            viewProviders: [core_2.provide("service", { useValue: "service" })]
                        }));
                        testing_internal_1.expect(function () { appElement(null, collection_1.ListWrapper.concat([SimpleDirective, NeedsService], extraDirectives)); })
                            .toThrowError(testing_internal_1.containsRegexp("No provider for service! (" + lang_1.stringify(NeedsService) + " -> service)"));
                    });
                    testing_internal_1.it("should instantiate directives that depend on providers of other directives", function () {
                        mockDirectiveMeta.set(SimpleDirective, new metadata_1.ComponentMetadata({
                            providers: [core_2.provide('service', { useValue: 'hostService' })] }));
                        var shadowInj = hostShadowElement(collection_1.ListWrapper.concat([SimpleDirective], extraDirectives), collection_1.ListWrapper.concat([NeedsService], extraDirectives));
                        testing_internal_1.expect(shadowInj.get(NeedsService).service).toEqual('hostService');
                    });
                    testing_internal_1.it("should instantiate directives that depend on view providers of a component", function () {
                        mockDirectiveMeta.set(SimpleDirective, new metadata_1.ComponentMetadata({
                            viewProviders: [core_2.provide('service', { useValue: 'hostService' })] }));
                        var shadowInj = hostShadowElement(collection_1.ListWrapper.concat([SimpleDirective], extraDirectives), collection_1.ListWrapper.concat([NeedsService], extraDirectives));
                        testing_internal_1.expect(shadowInj.get(NeedsService).service).toEqual('hostService');
                    });
                    testing_internal_1.it("should instantiate directives in a root embedded view that depend on view providers of a component", function () {
                        mockDirectiveMeta.set(SimpleDirective, new metadata_1.ComponentMetadata({
                            viewProviders: [core_2.provide('service', { useValue: 'hostService' })] }));
                        var host = appElement(null, collection_1.ListWrapper.concat([SimpleDirective], extraDirectives));
                        var componenetView = createView(view_type_1.ViewType.COMPONENT, host);
                        host.attachComponentView(componenetView);
                        var anchor = appElement(null, [], componenetView);
                        var embeddedView = createView(view_type_1.ViewType.EMBEDDED, anchor);
                        var rootEmbeddedEl = appElement(null, collection_1.ListWrapper.concat([NeedsService], extraDirectives), embeddedView);
                        testing_internal_1.expect(rootEmbeddedEl.get(NeedsService).service).toEqual('hostService');
                    });
                    testing_internal_1.it("should instantiate directives that depend on imperatively created injector (bootstrap)", function () {
                        var rootInjector = core_2.Injector.resolveAndCreate([
                            core_2.provide("service", { useValue: 'appService' })
                        ]);
                        var view = createView(view_type_1.ViewType.HOST, null, null, rootInjector);
                        testing_internal_1.expect(appElement(null, [NeedsService], view).get(NeedsService).service).toEqual('appService');
                        testing_internal_1.expect(function () { return appElement(null, [NeedsServiceFromHost], view); }).toThrowError();
                    });
                    testing_internal_1.it("should instantiate directives that depend on imperatively created providers (root injector)", function () {
                        var imperativelyCreatedProviders = core_2.Injector.resolve([
                            core_2.provide("service", { useValue: 'appService' })
                        ]);
                        var containerAppElement = appElement(null, []);
                        var view = createView(view_type_1.ViewType.HOST, containerAppElement, imperativelyCreatedProviders, null);
                        testing_internal_1.expect(appElement(null, [NeedsService], view).get(NeedsService).service).toEqual('appService');
                        testing_internal_1.expect(appElement(null, [NeedsServiceFromHost], view).get(NeedsServiceFromHost).service).toEqual('appService');
                    });
                    testing_internal_1.it("should not instantiate a directive in a view that has a host dependency on providers" +
                        " of the component", function () {
                        mockDirectiveMeta.set(SomeOtherDirective, new metadata_1.DirectiveMetadata({
                            providers: [core_2.provide('service', { useValue: 'hostService' })] }));
                        testing_internal_1.expect(function () {
                            hostShadowElement(collection_1.ListWrapper.concat([SomeOtherDirective], extraDirectives), collection_1.ListWrapper.concat([NeedsServiceFromHost], extraDirectives));
                        }).toThrowError(new RegExp("No provider for service!"));
                    });
                    testing_internal_1.it("should not instantiate a directive in a view that has a host dependency on providers" +
                        " of a decorator directive", function () {
                        mockDirectiveMeta.set(SomeOtherDirective, new metadata_1.DirectiveMetadata({
                            providers: [core_2.provide('service', { useValue: 'hostService' })] }));
                        testing_internal_1.expect(function () {
                            hostShadowElement(collection_1.ListWrapper.concat([SimpleDirective, SomeOtherDirective], extraDirectives), collection_1.ListWrapper.concat([NeedsServiceFromHost], extraDirectives));
                        }).toThrowError(new RegExp("No provider for service!"));
                    });
                    testing_internal_1.it("should get directives", function () {
                        var child = hostShadowElement(collection_1.ListWrapper.concat([SomeOtherDirective, SimpleDirective], extraDirectives), [NeedsDirectiveFromHostShadowDom]);
                        var d = child.get(NeedsDirectiveFromHostShadowDom);
                        testing_internal_1.expect(d).toBeAnInstanceOf(NeedsDirectiveFromHostShadowDom);
                        testing_internal_1.expect(d.dependency).toBeAnInstanceOf(SimpleDirective);
                    });
                    testing_internal_1.it("should get directives from the host", function () {
                        var child = parentChildElements(collection_1.ListWrapper.concat([SimpleDirective], extraDirectives), [NeeedsDirectiveFromHost]);
                        var d = child.get(NeeedsDirectiveFromHost);
                        testing_internal_1.expect(d).toBeAnInstanceOf(NeeedsDirectiveFromHost);
                        testing_internal_1.expect(d.dependency).toBeAnInstanceOf(SimpleDirective);
                    });
                    testing_internal_1.it("should throw when a dependency cannot be resolved", function () {
                        testing_internal_1.expect(function () { return appElement(null, collection_1.ListWrapper.concat([NeeedsDirectiveFromHost], extraDirectives)); })
                            .toThrowError(testing_internal_1.containsRegexp("No provider for " + lang_1.stringify(SimpleDirective) + "! (" + lang_1.stringify(NeeedsDirectiveFromHost) + " -> " + lang_1.stringify(SimpleDirective) + ")"));
                    });
                    testing_internal_1.it("should inject null when an optional dependency cannot be resolved", function () {
                        var el = appElement(null, collection_1.ListWrapper.concat([OptionallyNeedsDirective], extraDirectives));
                        var d = el.get(OptionallyNeedsDirective);
                        testing_internal_1.expect(d.dependency).toEqual(null);
                    });
                    testing_internal_1.it("should allow for direct access using getDirectiveAtIndex", function () {
                        var providers = collection_1.ListWrapper.concat([SimpleDirective], extraDirectives);
                        var el = appElement(null, providers);
                        var firsIndexOut = providers.length > 10 ? providers.length : 10;
                        testing_internal_1.expect(el.getDirectiveAtIndex(0)).toBeAnInstanceOf(SimpleDirective);
                        testing_internal_1.expect(function () { return el.getDirectiveAtIndex(-1); }).toThrowError('Index -1 is out-of-bounds.');
                        testing_internal_1.expect(function () { return el.getDirectiveAtIndex(firsIndexOut); })
                            .toThrowError("Index " + firsIndexOut + " is out-of-bounds.");
                    });
                    testing_internal_1.it("should instantiate directives that depend on the containing component", function () {
                        mockDirectiveMeta.set(SimpleDirective, new metadata_1.ComponentMetadata());
                        var shadow = hostShadowElement(collection_1.ListWrapper.concat([SimpleDirective], extraDirectives), [NeeedsDirectiveFromHost]);
                        var d = shadow.get(NeeedsDirectiveFromHost);
                        testing_internal_1.expect(d).toBeAnInstanceOf(NeeedsDirectiveFromHost);
                        testing_internal_1.expect(d.dependency).toBeAnInstanceOf(SimpleDirective);
                    });
                    testing_internal_1.it("should not instantiate directives that depend on other directives in the containing component's ElementInjector", function () {
                        mockDirectiveMeta.set(SomeOtherDirective, new metadata_1.ComponentMetadata());
                        testing_internal_1.expect(function () {
                            hostShadowElement(collection_1.ListWrapper.concat([SomeOtherDirective, SimpleDirective], extraDirectives), [NeedsDirective]);
                        })
                            .toThrowError(testing_internal_1.containsRegexp("No provider for " + lang_1.stringify(SimpleDirective) + "! (" + lang_1.stringify(NeedsDirective) + " -> " + lang_1.stringify(SimpleDirective) + ")"));
                    });
                });
                testing_internal_1.describe('static attributes', function () {
                    testing_internal_1.it('should be injectable', function () {
                        var el = appElement(null, collection_1.ListWrapper.concat([NeedsAttribute], extraDirectives), null, null, {
                            'type': 'text',
                            'title': ''
                        });
                        var needsAttribute = el.get(NeedsAttribute);
                        testing_internal_1.expect(needsAttribute.typeAttribute).toEqual('text');
                        testing_internal_1.expect(needsAttribute.titleAttribute).toEqual('');
                        testing_internal_1.expect(needsAttribute.fooAttribute).toEqual(null);
                    });
                    testing_internal_1.it('should be injectable without type annotation', function () {
                        var el = appElement(null, collection_1.ListWrapper.concat([NeedsAttributeNoType], extraDirectives), null, null, { 'foo': 'bar' });
                        var needsAttribute = el.get(NeedsAttributeNoType);
                        testing_internal_1.expect(needsAttribute.fooAttribute).toEqual('bar');
                    });
                });
                testing_internal_1.describe("refs", function () {
                    testing_internal_1.it("should inject ElementRef", function () {
                        var el = appElement(null, collection_1.ListWrapper.concat([NeedsElementRef], extraDirectives));
                        testing_internal_1.expect(el.get(NeedsElementRef).elementRef).toBe(el.ref);
                    });
                    testing_internal_1.it("should inject ChangeDetectorRef of the component's view into the component via a proxy", function () {
                        mockDirectiveMeta.set(ComponentNeedsChangeDetectorRef, new metadata_1.ComponentMetadata());
                        var host = appElement(null, collection_1.ListWrapper.concat([ComponentNeedsChangeDetectorRef], extraDirectives));
                        var view = createView(view_type_1.ViewType.COMPONENT, host);
                        host.attachComponentView(view);
                        host.get(ComponentNeedsChangeDetectorRef).changeDetectorRef.markForCheck();
                        testing_internal_1.expect(view.changeDetector.spy('markPathToRootAsCheckOnce')).toHaveBeenCalled();
                    });
                    testing_internal_1.it("should inject ChangeDetectorRef of the containing component into directives", function () {
                        mockDirectiveMeta.set(DirectiveNeedsChangeDetectorRef, new metadata_1.DirectiveMetadata());
                        var view = createView(view_type_1.ViewType.HOST);
                        var el = appElement(null, collection_1.ListWrapper.concat([DirectiveNeedsChangeDetectorRef], extraDirectives), view);
                        testing_internal_1.expect(el.get(DirectiveNeedsChangeDetectorRef).changeDetectorRef).toBe(view.changeDetector.ref);
                    });
                    testing_internal_1.it('should inject ViewContainerRef', function () {
                        var el = appElement(null, collection_1.ListWrapper.concat([NeedsViewContainer], extraDirectives));
                        testing_internal_1.expect(el.get(NeedsViewContainer).viewContainer).toBeAnInstanceOf(view_container_ref_1.ViewContainerRef_);
                    });
                    testing_internal_1.it("should inject TemplateRef", function () {
                        var el = appElement(null, collection_1.ListWrapper.concat([NeedsTemplateRef], extraDirectives), null, dummyViewFactory);
                        testing_internal_1.expect(el.get(NeedsTemplateRef).templateRef.elementRef).toBe(el.ref);
                    });
                    testing_internal_1.it("should throw if there is no TemplateRef", function () {
                        testing_internal_1.expect(function () { return appElement(null, collection_1.ListWrapper.concat([NeedsTemplateRef], extraDirectives)); })
                            .toThrowError("No provider for TemplateRef! (" + lang_1.stringify(NeedsTemplateRef) + " -> TemplateRef)");
                    });
                    testing_internal_1.it('should inject null if there is no TemplateRef when the dependency is optional', function () {
                        var el = appElement(null, collection_1.ListWrapper.concat([OptionallyInjectsTemplateRef], extraDirectives));
                        var instance = el.get(OptionallyInjectsTemplateRef);
                        testing_internal_1.expect(instance.templateRef).toBeNull();
                    });
                });
                testing_internal_1.describe('queries', function () {
                    function expectDirectives(query, type, expectedIndex) {
                        var currentCount = 0;
                        testing_internal_1.expect(query.length).toEqual(expectedIndex.length);
                        collection_1.iterateListLike(query, function (i) {
                            testing_internal_1.expect(i).toBeAnInstanceOf(type);
                            testing_internal_1.expect(i.count).toBe(expectedIndex[currentCount]);
                            currentCount += 1;
                        });
                    }
                    testing_internal_1.it('should be injectable', function () {
                        var el = appElement(null, collection_1.ListWrapper.concat([NeedsQuery], extraDirectives));
                        testing_internal_1.expect(el.get(NeedsQuery).query).toBeAnInstanceOf(query_list_1.QueryList);
                    });
                    testing_internal_1.it('should contain directives on the same injector', function () {
                        var el = appElement(null, collection_1.ListWrapper.concat([
                            NeedsQuery,
                            CountingDirective
                        ], extraDirectives));
                        el.ngAfterContentChecked();
                        expectDirectives(el.get(NeedsQuery).query, CountingDirective, [0]);
                    });
                    testing_internal_1.it('should contain TemplateRefs on the same injector', function () {
                        var el = appElement(null, collection_1.ListWrapper.concat([
                            NeedsTemplateRefQuery
                        ], extraDirectives), null, dummyViewFactory);
                        el.ngAfterContentChecked();
                        testing_internal_1.expect(el.get(NeedsTemplateRefQuery).query.first).toBeAnInstanceOf(template_ref_1.TemplateRef_);
                    });
                    testing_internal_1.it('should contain the element when no directives are bound to the var provider', function () {
                        var dirs = [NeedsQueryByVarBindings];
                        var dirVariableBindings = {
                            "one": null // element
                        };
                        var el = appElement(null, dirs.concat(extraDirectives), null, null, null, dirVariableBindings);
                        el.ngAfterContentChecked();
                        testing_internal_1.expect(el.get(NeedsQueryByVarBindings).query.first).toBe(el.ref);
                    });
                    testing_internal_1.it('should contain directives on the same injector when querying by variable providers' +
                        'in the order of var providers specified in the query', function () {
                        var dirs = [NeedsQueryByVarBindings, NeedsDirective, SimpleDirective];
                        var dirVariableBindings = {
                            "one": 2,
                            "two": 1 // 1 is the index of NeedsDirective
                        };
                        var el = appElement(null, dirs.concat(extraDirectives), null, null, null, dirVariableBindings);
                        el.ngAfterContentChecked();
                        // NeedsQueryByVarBindings queries "one,two", so SimpleDirective should be before NeedsDirective
                        testing_internal_1.expect(el.get(NeedsQueryByVarBindings).query.first).toBeAnInstanceOf(SimpleDirective);
                        testing_internal_1.expect(el.get(NeedsQueryByVarBindings).query.last).toBeAnInstanceOf(NeedsDirective);
                    });
                    testing_internal_1.it('should contain directives on the same and a child injector in construction order', function () {
                        var parent = appElement(null, [NeedsQuery, CountingDirective]);
                        appElement(parent, collection_1.ListWrapper.concat([CountingDirective], extraDirectives));
                        parent.ngAfterContentChecked();
                        expectDirectives(parent.get(NeedsQuery).query, CountingDirective, [0, 1]);
                    });
                });
            });
        });
    });
}
exports.main = main;
var ContextWithHandler = (function () {
    function ContextWithHandler(handler) {
        this.handler = handler;
    }
    return ContextWithHandler;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWxlbWVudF9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb3JlL2xpbmtlci9lbGVtZW50X3NwZWMudHMiXSwibmFtZXMiOlsiU2ltcGxlRGlyZWN0aXZlIiwiU2ltcGxlRGlyZWN0aXZlLmNvbnN0cnVjdG9yIiwiU2ltcGxlU2VydmljZSIsIlNpbXBsZVNlcnZpY2UuY29uc3RydWN0b3IiLCJTb21lT3RoZXJEaXJlY3RpdmUiLCJTb21lT3RoZXJEaXJlY3RpdmUuY29uc3RydWN0b3IiLCJDb3VudGluZ0RpcmVjdGl2ZSIsIkNvdW50aW5nRGlyZWN0aXZlLmNvbnN0cnVjdG9yIiwiRmFuY3lDb3VudGluZ0RpcmVjdGl2ZSIsIkZhbmN5Q291bnRpbmdEaXJlY3RpdmUuY29uc3RydWN0b3IiLCJOZWVkc0RpcmVjdGl2ZSIsIk5lZWRzRGlyZWN0aXZlLmNvbnN0cnVjdG9yIiwiT3B0aW9uYWxseU5lZWRzRGlyZWN0aXZlIiwiT3B0aW9uYWxseU5lZWRzRGlyZWN0aXZlLmNvbnN0cnVjdG9yIiwiTmVlZWRzRGlyZWN0aXZlRnJvbUhvc3QiLCJOZWVlZHNEaXJlY3RpdmVGcm9tSG9zdC5jb25zdHJ1Y3RvciIsIk5lZWRzRGlyZWN0aXZlRnJvbUhvc3RTaGFkb3dEb20iLCJOZWVkc0RpcmVjdGl2ZUZyb21Ib3N0U2hhZG93RG9tLmNvbnN0cnVjdG9yIiwiTmVlZHNTZXJ2aWNlIiwiTmVlZHNTZXJ2aWNlLmNvbnN0cnVjdG9yIiwiTmVlZHNTZXJ2aWNlRnJvbUhvc3QiLCJOZWVkc1NlcnZpY2VGcm9tSG9zdC5jb25zdHJ1Y3RvciIsIkhhc0V2ZW50RW1pdHRlciIsIkhhc0V2ZW50RW1pdHRlci5jb25zdHJ1Y3RvciIsIk5lZWRzQXR0cmlidXRlIiwiTmVlZHNBdHRyaWJ1dGUuY29uc3RydWN0b3IiLCJOZWVkc0F0dHJpYnV0ZU5vVHlwZSIsIk5lZWRzQXR0cmlidXRlTm9UeXBlLmNvbnN0cnVjdG9yIiwiTmVlZHNRdWVyeSIsIk5lZWRzUXVlcnkuY29uc3RydWN0b3IiLCJOZWVkc1ZpZXdRdWVyeSIsIk5lZWRzVmlld1F1ZXJ5LmNvbnN0cnVjdG9yIiwiTmVlZHNRdWVyeUJ5VmFyQmluZGluZ3MiLCJOZWVkc1F1ZXJ5QnlWYXJCaW5kaW5ncy5jb25zdHJ1Y3RvciIsIk5lZWRzVGVtcGxhdGVSZWZRdWVyeSIsIk5lZWRzVGVtcGxhdGVSZWZRdWVyeS5jb25zdHJ1Y3RvciIsIk5lZWRzRWxlbWVudFJlZiIsIk5lZWRzRWxlbWVudFJlZi5jb25zdHJ1Y3RvciIsIk5lZWRzVmlld0NvbnRhaW5lciIsIk5lZWRzVmlld0NvbnRhaW5lci5jb25zdHJ1Y3RvciIsIk5lZWRzVGVtcGxhdGVSZWYiLCJOZWVkc1RlbXBsYXRlUmVmLmNvbnN0cnVjdG9yIiwiT3B0aW9uYWxseUluamVjdHNUZW1wbGF0ZVJlZiIsIk9wdGlvbmFsbHlJbmplY3RzVGVtcGxhdGVSZWYuY29uc3RydWN0b3IiLCJEaXJlY3RpdmVOZWVkc0NoYW5nZURldGVjdG9yUmVmIiwiRGlyZWN0aXZlTmVlZHNDaGFuZ2VEZXRlY3RvclJlZi5jb25zdHJ1Y3RvciIsIkNvbXBvbmVudE5lZWRzQ2hhbmdlRGV0ZWN0b3JSZWYiLCJDb21wb25lbnROZWVkc0NoYW5nZURldGVjdG9yUmVmLmNvbnN0cnVjdG9yIiwiUGlwZU5lZWRzQ2hhbmdlRGV0ZWN0b3JSZWYiLCJQaXBlTmVlZHNDaGFuZ2VEZXRlY3RvclJlZi5jb25zdHJ1Y3RvciIsIkFfTmVlZHNfQiIsIkFfTmVlZHNfQi5jb25zdHJ1Y3RvciIsIkJfTmVlZHNfQSIsIkJfTmVlZHNfQS5jb25zdHJ1Y3RvciIsIkRpcmVjdGl2ZVdpdGhEZXN0cm95IiwiRGlyZWN0aXZlV2l0aERlc3Ryb3kuY29uc3RydWN0b3IiLCJEaXJlY3RpdmVXaXRoRGVzdHJveS5uZ09uRGVzdHJveSIsIkQwIiwiRDAuY29uc3RydWN0b3IiLCJEMSIsIkQxLmNvbnN0cnVjdG9yIiwiRDIiLCJEMi5jb25zdHJ1Y3RvciIsIkQzIiwiRDMuY29uc3RydWN0b3IiLCJENCIsIkQ0LmNvbnN0cnVjdG9yIiwiRDUiLCJENS5jb25zdHJ1Y3RvciIsIkQ2IiwiRDYuY29uc3RydWN0b3IiLCJENyIsIkQ3LmNvbnN0cnVjdG9yIiwiRDgiLCJEOC5jb25zdHJ1Y3RvciIsIkQ5IiwiRDkuY29uc3RydWN0b3IiLCJEMTAiLCJEMTAuY29uc3RydWN0b3IiLCJEMTEiLCJEMTEuY29uc3RydWN0b3IiLCJEMTIiLCJEMTIuY29uc3RydWN0b3IiLCJEMTMiLCJEMTMuY29uc3RydWN0b3IiLCJEMTQiLCJEMTQuY29uc3RydWN0b3IiLCJEMTUiLCJEMTUuY29uc3RydWN0b3IiLCJEMTYiLCJEMTYuY29uc3RydWN0b3IiLCJEMTciLCJEMTcuY29uc3RydWN0b3IiLCJEMTgiLCJEMTguY29uc3RydWN0b3IiLCJEMTkiLCJEMTkuY29uc3RydWN0b3IiLCJtYWluIiwibWFpbi5jcmVhdGVWaWV3IiwibWFpbi5wcm90b0FwcEVsZW1lbnQiLCJtYWluLmFwcEVsZW1lbnQiLCJtYWluLnBhcmVudENoaWxkRWxlbWVudHMiLCJtYWluLmhvc3RTaGFkb3dFbGVtZW50IiwibWFpbi5pbml0IiwibWFpbi5leHBlY3REaXJlY3RpdmVzIiwiQ29udGV4dFdpdGhIYW5kbGVyIiwiQ29udGV4dFdpdGhIYW5kbGVyLmNvbnN0cnVjdG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9HQUFvRztBQUNwRyxxREFBcUQ7QUFDckQsbUJBQW1CO0FBQ25CLGlDQWNPLDJCQUEyQixDQUFDLENBQUE7QUFDbkMsc0JBQStHLFVBQVUsQ0FBQyxDQUFBO0FBQzFILHFCQUFrRCwwQkFBMEIsQ0FBQyxDQUFBO0FBRTdFLDJCQUtPLGdDQUFnQyxDQUFDLENBQUE7QUFDeEMsd0JBSU8sa0NBQWtDLENBQUMsQ0FBQTtBQUMxQyx3Q0FBb0Msa0RBQWtELENBQUMsQ0FBQTtBQUN2RixtQ0FBZ0MsNkNBQTZDLENBQUMsQ0FBQTtBQUM5RSx5QkFPTyw0QkFBNEIsQ0FBQyxDQUFBO0FBQ3BDLHFCQUFtQyxlQUFlLENBQUMsQ0FBQTtBQUNuRCxxQkFBOEksZUFBZSxDQUFDLENBQUE7QUFDOUosbUNBQWtELDZDQUE2QyxDQUFDLENBQUE7QUFDaEcsNkJBQXdDLHVDQUF1QyxDQUFDLENBQUE7QUFDaEYsNEJBQXlCLHNDQUFzQyxDQUFDLENBQUE7QUFDaEUsaUNBQXNFLHFEQUFxRCxDQUFDLENBQUE7QUFDNUgsb0NBQWlDLHdEQUF3RCxDQUFDLENBQUE7QUFDMUYsMkJBQXdCLHFDQUFxQyxDQUFDLENBQUE7QUFDOUQscUJBQW9DLCtCQUErQixDQUFDLENBQUE7QUFDcEUsMEJBQXVCLG9DQUFvQyxDQUFDLENBQUE7QUFFNUQ7SUFBQUE7SUFDdUJDLENBQUNBO0lBRHhCRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7O3dCQUNGQTtJQUFEQSxzQkFBQ0E7QUFBREEsQ0FBQ0EsQUFEeEIsSUFDd0I7QUFFeEI7SUFBQUU7SUFBcUJDLENBQUNBO0lBQURELG9CQUFDQTtBQUFEQSxDQUFDQSxBQUF0QixJQUFzQjtBQUV0QjtJQUFBRTtJQUMwQkMsQ0FBQ0E7SUFEM0JEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7MkJBQ0NBO0lBQURBLHlCQUFDQTtBQUFEQSxDQUFDQSxBQUQzQixJQUMyQjtBQUUzQixJQUFJLGtCQUFrQixDQUFDO0FBQ3ZCO0lBR0VFO1FBQ0VDLElBQUlBLENBQUNBLEtBQUtBLEdBQUdBLGtCQUFrQkEsQ0FBQ0E7UUFDaENBLGtCQUFrQkEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7SUFDMUJBLENBQUNBO0lBTkhEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7MEJBT3pCQTtJQUFEQSx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFQRCxJQU9DO0FBRUQ7SUFDcUNFLDBDQUFpQkE7SUFDcERBO1FBQWdCQyxpQkFBT0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFGNUJEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7K0JBR3pCQTtJQUFEQSw2QkFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxFQUNxQyxpQkFBaUIsRUFFckQ7QUFFRDtJQUdFRSx3QkFBb0JBLFVBQTJCQTtRQUFJQyxJQUFJQSxDQUFDQSxVQUFVQSxHQUFHQSxVQUFVQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUhwRkQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBO1FBR1pBLFdBQUNBLFdBQUlBLEVBQUVBLENBQUFBOzt1QkFDcEJBO0lBQURBLHFCQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQUdFRSxrQ0FBZ0NBLFVBQTJCQTtRQUFJQyxJQUFJQSxDQUFDQSxVQUFVQSxHQUFHQSxVQUFVQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUhoR0Q7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBO1FBR1pBLFdBQUNBLFdBQUlBLEVBQUVBLENBQUFBO1FBQUNBLFdBQUNBLGVBQVFBLEVBQUVBLENBQUFBOztpQ0FDaENBO0lBQURBLCtCQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQUdFRSxpQ0FBb0JBLFVBQTJCQTtRQUFJQyxJQUFJQSxDQUFDQSxVQUFVQSxHQUFHQSxVQUFVQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUhwRkQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBO1FBR1pBLFdBQUNBLFdBQUlBLEVBQUVBLENBQUFBOztnQ0FDcEJBO0lBQURBLDhCQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQUdFRSx5Q0FBWUEsVUFBMkJBO1FBQUlDLElBQUlBLENBQUNBLFVBQVVBLEdBQUdBLFVBQVVBLENBQUNBO0lBQUNBLENBQUNBO0lBSDVFRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7O3dDQUl6QkE7SUFBREEsc0NBQUNBO0FBQURBLENBQUNBLEFBSkQsSUFJQztBQUVEO0lBR0VFLHNCQUErQkEsT0FBT0E7UUFBSUMsSUFBSUEsQ0FBQ0EsT0FBT0EsR0FBR0EsT0FBT0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFIckVEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTtRQUdaQSxXQUFDQSxhQUFNQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFBQTs7cUJBQy9CQTtJQUFEQSxtQkFBQ0E7QUFBREEsQ0FBQ0EsQUFKRCxJQUlDO0FBRUQ7SUFHRUUsOEJBQXVDQSxPQUFPQTtRQUFJQyxJQUFJQSxDQUFDQSxPQUFPQSxHQUFHQSxPQUFPQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUg3RUQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBO1FBR1pBLFdBQUNBLFdBQUlBLEVBQUVBLENBQUFBO1FBQUNBLFdBQUNBLGFBQU1BLENBQUNBLFNBQVNBLENBQUNBLENBQUFBOzs2QkFDdkNBO0lBQURBLDJCQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQUVFRTtRQUFnQkMsSUFBSUEsQ0FBQ0EsT0FBT0EsR0FBR0EsU0FBU0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFDN0NELHNCQUFDQTtBQUFEQSxDQUFDQSxBQUhELElBR0M7QUFFRDtJQUtFRSx3QkFBK0JBLGFBQXFCQSxFQUFzQkEsY0FBc0JBLEVBQ2xFQSxZQUFvQkE7UUFDaERDLElBQUlBLENBQUNBLGFBQWFBLEdBQUdBLGFBQWFBLENBQUNBO1FBQ25DQSxJQUFJQSxDQUFDQSxjQUFjQSxHQUFHQSxjQUFjQSxDQUFDQTtRQUNyQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsR0FBR0EsWUFBWUEsQ0FBQ0E7SUFDbkNBLENBQUNBO0lBVkhEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTtRQUtaQSxXQUFDQSxvQkFBU0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQUE7UUFBd0JBLFdBQUNBLG9CQUFTQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFBQTtRQUM3REEsV0FBQ0Esb0JBQVNBLENBQUNBLEtBQUtBLENBQUNBLENBQUFBOzt1QkFLOUJBO0lBQURBLHFCQUFDQTtBQUFEQSxDQUFDQSxBQVhELElBV0M7QUFFRDtJQUdFRSw4QkFBOEJBLFlBQVlBO1FBQUlDLElBQUlBLENBQUNBLFlBQVlBLEdBQUdBLFlBQVlBLENBQUNBO0lBQUNBLENBQUNBO0lBSG5GRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7UUFHWkEsV0FBQ0Esb0JBQVNBLENBQUNBLEtBQUtBLENBQUNBLENBQUFBOzs2QkFDOUJBO0lBQURBLDJCQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQUdFRSxvQkFBc0NBLEtBQW1DQTtRQUFJQyxJQUFJQSxDQUFDQSxLQUFLQSxHQUFHQSxLQUFLQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUhwR0Q7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBO1FBR1pBLFdBQUNBLGdCQUFLQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUFBOzttQkFDdENBO0lBQURBLGlCQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQUdFRSx3QkFBMENBLEtBQW1DQTtRQUFJQyxJQUFJQSxDQUFDQSxLQUFLQSxHQUFHQSxLQUFLQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUh4R0Q7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBO1FBR1pBLFdBQUNBLG9CQUFTQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUFBOzt1QkFDMUNBO0lBQURBLHFCQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQUdFRSxpQ0FBOEJBLEtBQXFCQTtRQUFJQyxJQUFJQSxDQUFDQSxLQUFLQSxHQUFHQSxLQUFLQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUg5RUQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBO1FBR1pBLFdBQUNBLGdCQUFLQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFBQTs7Z0NBQzlCQTtJQUFEQSw4QkFBQ0E7QUFBREEsQ0FBQ0EsQUFKRCxJQUlDO0FBRUQ7SUFHRUUsK0JBQWdDQSxLQUE2QkE7UUFBSUMsSUFBSUEsQ0FBQ0EsS0FBS0EsR0FBR0EsS0FBS0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFIeEZEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTtRQUdaQSxXQUFDQSxnQkFBS0EsQ0FBQ0EsMEJBQVdBLENBQUNBLENBQUFBOzs4QkFDaENBO0lBQURBLDRCQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQUdFRSx5QkFBWUEsR0FBZUE7UUFBSUMsSUFBSUEsQ0FBQ0EsVUFBVUEsR0FBR0EsR0FBR0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFIekREO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7d0JBSXpCQTtJQUFEQSxzQkFBQ0E7QUFBREEsQ0FBQ0EsQUFKRCxJQUlDO0FBRUQ7SUFHRUUsNEJBQVlBLEVBQW9CQTtRQUFJQyxJQUFJQSxDQUFDQSxhQUFhQSxHQUFHQSxFQUFFQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUhoRUQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOzsyQkFJekJBO0lBQURBLHlCQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQUdFRSwwQkFBWUEsR0FBZ0JBO1FBQUlDLElBQUlBLENBQUNBLFdBQVdBLEdBQUdBLEdBQUdBLENBQUNBO0lBQUNBLENBQUNBO0lBSDNERDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7O3lCQUl6QkE7SUFBREEsdUJBQUNBO0FBQURBLENBQUNBLEFBSkQsSUFJQztBQUVEO0lBR0VFLHNDQUF3QkEsR0FBZ0JBO1FBQUlDLElBQUlBLENBQUNBLFdBQVdBLEdBQUdBLEdBQUdBLENBQUNBO0lBQUNBLENBQUNBO0lBSHZFRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7UUFHWkEsV0FBQ0EsZUFBUUEsRUFBRUEsQ0FBQUE7O3FDQUN4QkE7SUFBREEsbUNBQUNBO0FBQURBLENBQUNBLEFBSkQsSUFJQztBQUVEO0lBRUVFLHlDQUFtQkEsaUJBQW9DQTtRQUFwQ0Msc0JBQWlCQSxHQUFqQkEsaUJBQWlCQSxDQUFtQkE7SUFBR0EsQ0FBQ0E7SUFGN0REO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7d0NBR3pCQTtJQUFEQSxzQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFFRUUseUNBQW1CQSxpQkFBb0NBO1FBQXBDQyxzQkFBaUJBLEdBQWpCQSxpQkFBaUJBLENBQW1CQTtJQUFHQSxDQUFDQTtJQUY3REQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOzt3Q0FHekJBO0lBQURBLHNDQUFDQTtBQUFEQSxDQUFDQSxBQUhELElBR0M7QUFFRDtJQUVFRSxvQ0FBbUJBLGlCQUFvQ0E7UUFBcENDLHNCQUFpQkEsR0FBakJBLGlCQUFpQkEsQ0FBbUJBO0lBQUdBLENBQUNBO0lBRjdERDtRQUFDQSxpQkFBVUEsRUFBRUE7O21DQUdaQTtJQUFEQSxpQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFDRUUsbUJBQVlBLEdBQUdBO0lBQUdDLENBQUNBO0lBQ3JCRCxnQkFBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDO0FBRUQ7SUFDRUUsbUJBQVlBLEdBQUdBO0lBQUdDLENBQUNBO0lBQ3JCRCxnQkFBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDO0FBRUQ7SUFHRUU7UUFBZ0JDLElBQUlBLENBQUNBLGtCQUFrQkEsR0FBR0EsQ0FBQ0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFFOUNELDBDQUFXQSxHQUFYQSxjQUFnQkUsSUFBSUEsQ0FBQ0Esa0JBQWtCQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUM5Q0YsMkJBQUNBO0FBQURBLENBQUNBLEFBTkQsSUFNQztBQUVEO0lBQUFHO0lBQ1VDLENBQUNBO0lBRFhEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7V0FDZkE7SUFBREEsU0FBQ0E7QUFBREEsQ0FBQ0EsQUFEWCxJQUNXO0FBQ1g7SUFBQUU7SUFDVUMsQ0FBQ0E7SUFEWEQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOztXQUNmQTtJQUFEQSxTQUFDQTtBQUFEQSxDQUFDQSxBQURYLElBQ1c7QUFDWDtJQUFBRTtJQUNVQyxDQUFDQTtJQURYRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7O1dBQ2ZBO0lBQURBLFNBQUNBO0FBQURBLENBQUNBLEFBRFgsSUFDVztBQUNYO0lBQUFFO0lBQ1VDLENBQUNBO0lBRFhEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7V0FDZkE7SUFBREEsU0FBQ0E7QUFBREEsQ0FBQ0EsQUFEWCxJQUNXO0FBQ1g7SUFBQUU7SUFDVUMsQ0FBQ0E7SUFEWEQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOztXQUNmQTtJQUFEQSxTQUFDQTtBQUFEQSxDQUFDQSxBQURYLElBQ1c7QUFDWDtJQUFBRTtJQUNVQyxDQUFDQTtJQURYRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7O1dBQ2ZBO0lBQURBLFNBQUNBO0FBQURBLENBQUNBLEFBRFgsSUFDVztBQUNYO0lBQUFFO0lBQ1VDLENBQUNBO0lBRFhEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7V0FDZkE7SUFBREEsU0FBQ0E7QUFBREEsQ0FBQ0EsQUFEWCxJQUNXO0FBQ1g7SUFBQUU7SUFDVUMsQ0FBQ0E7SUFEWEQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOztXQUNmQTtJQUFEQSxTQUFDQTtBQUFEQSxDQUFDQSxBQURYLElBQ1c7QUFDWDtJQUFBRTtJQUNVQyxDQUFDQTtJQURYRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7O1dBQ2ZBO0lBQURBLFNBQUNBO0FBQURBLENBQUNBLEFBRFgsSUFDVztBQUNYO0lBQUFFO0lBQ1VDLENBQUNBO0lBRFhEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7V0FDZkE7SUFBREEsU0FBQ0E7QUFBREEsQ0FBQ0EsQUFEWCxJQUNXO0FBQ1g7SUFBQUU7SUFDV0MsQ0FBQ0E7SUFEWkQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOztZQUNkQTtJQUFEQSxVQUFDQTtBQUFEQSxDQUFDQSxBQURaLElBQ1k7QUFDWjtJQUFBRTtJQUNXQyxDQUFDQTtJQURaRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7O1lBQ2RBO0lBQURBLFVBQUNBO0FBQURBLENBQUNBLEFBRFosSUFDWTtBQUNaO0lBQUFFO0lBQ1dDLENBQUNBO0lBRFpEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7WUFDZEE7SUFBREEsVUFBQ0E7QUFBREEsQ0FBQ0EsQUFEWixJQUNZO0FBQ1o7SUFBQUU7SUFDV0MsQ0FBQ0E7SUFEWkQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOztZQUNkQTtJQUFEQSxVQUFDQTtBQUFEQSxDQUFDQSxBQURaLElBQ1k7QUFDWjtJQUFBRTtJQUNXQyxDQUFDQTtJQURaRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7O1lBQ2RBO0lBQURBLFVBQUNBO0FBQURBLENBQUNBLEFBRFosSUFDWTtBQUNaO0lBQUFFO0lBQ1dDLENBQUNBO0lBRFpEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7WUFDZEE7SUFBREEsVUFBQ0E7QUFBREEsQ0FBQ0EsQUFEWixJQUNZO0FBQ1o7SUFBQUU7SUFDV0MsQ0FBQ0E7SUFEWkQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOztZQUNkQTtJQUFEQSxVQUFDQTtBQUFEQSxDQUFDQSxBQURaLElBQ1k7QUFDWjtJQUFBRTtJQUNXQyxDQUFDQTtJQURaRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7O1lBQ2RBO0lBQURBLFVBQUNBO0FBQURBLENBQUNBLEFBRFosSUFDWTtBQUNaO0lBQUFFO0lBQ1dDLENBQUNBO0lBRFpEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7WUFDZEE7SUFBREEsVUFBQ0E7QUFBREEsQ0FBQ0EsQUFEWixJQUNZO0FBQ1o7SUFBQUU7SUFDV0MsQ0FBQ0E7SUFEWkQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOztZQUNkQTtJQUFEQSxVQUFDQTtBQUFEQSxDQUFDQSxBQURaLElBQ1k7QUFFWjtJQUNFRSw4RUFBOEVBO0lBQzlFQSxJQUFJQSx5QkFBeUJBLEdBQUdBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBO0lBQzNIQSxJQUFJQSxxQkFBMkNBLENBQUNBO0lBQ2hEQSxJQUFJQSxpQkFBOENBLENBQUNBO0lBQ25EQSxJQUFJQSxpQkFBc0NBLENBQUNBO0lBQzNDQSxJQUFJQSxTQUFpQkEsQ0FBQ0E7SUFDdEJBLElBQUlBLGdCQUF5QkEsQ0FBQ0E7SUFFOUJBLG9CQUFvQkEsSUFBY0EsRUFBRUEsbUJBQXFDQSxFQUFFQSw0QkFBdURBLEVBQUVBLFlBQTZCQSxFQUFFQSxLQUFvQkE7UUFBbkpDLG1DQUFxQ0EsR0FBckNBLDBCQUFxQ0E7UUFBRUEsNENBQXVEQSxHQUF2REEsbUNBQXVEQTtRQUFFQSw0QkFBNkJBLEdBQTdCQSxtQkFBNkJBO1FBQUVBLHFCQUFvQkEsR0FBcEJBLFlBQW9CQTtRQUNyTEEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsY0FBT0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDbkJBLEtBQUtBLEdBQUdBLEVBQUVBLENBQUNBO1FBQ2JBLENBQUNBO1FBQ0RBLElBQUlBLEtBQUtBLEdBQUdBLG1CQUFZQSxDQUFDQSxNQUFNQSxDQUFDQSxxQkFBcUJBLEVBQUVBLElBQUlBLEVBQUVBLEtBQUtBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBO1FBQ3hFQSxJQUFJQSxFQUFFQSxHQUFHQSxJQUFJQSx5QkFBaUJBLEVBQUVBLENBQUNBO1FBQ2pDQSxFQUFFQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxFQUFFQSxJQUFJQSx3Q0FBa0JBLENBQU1BLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO1FBRWhEQSxJQUFJQSxJQUFJQSxHQUFHQSxJQUFJQSxjQUFPQSxDQUFDQSxLQUFLQSxFQUFFQSxJQUFJQSxFQUFPQSxJQUFJQSx5QkFBaUJBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLG1CQUFtQkEsRUFBRUEsNEJBQTRCQSxFQUFFQSxZQUFZQSxFQUFRQSxFQUFFQSxDQUFDQSxDQUFDQTtRQUNqSkEsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsQ0FBQ0EsQ0FBQ0E7UUFDMUJBLE1BQU1BLENBQUNBLElBQUlBLENBQUNBO0lBQ2RBLENBQUNBO0lBRURELHlCQUF5QkEsS0FBS0EsRUFBRUEsVUFBa0JBLEVBQUVBLFVBQXdDQSxFQUFFQSxtQkFBZ0RBO1FBQTFGRSwwQkFBd0NBLEdBQXhDQSxpQkFBd0NBO1FBQUVBLG1DQUFnREEsR0FBaERBLDBCQUFnREE7UUFDNUlBLE1BQU1BLENBQUNBLHlCQUFlQSxDQUFDQSxNQUFNQSxDQUFDQSxxQkFBcUJBLEVBQUVBLEtBQUtBLEVBQUVBLFVBQVVBLEVBQUVBLFVBQVVBLEVBQUVBLG1CQUFtQkEsQ0FBQ0EsQ0FBQ0E7SUFDM0dBLENBQUNBO0lBRURGLG9CQUFvQkEsTUFBa0JBLEVBQUVBLFVBQWtCQSxFQUN4Q0EsSUFBb0JBLEVBQUVBLG1CQUFvQ0EsRUFBRUEsVUFBd0NBLEVBQUVBLG1CQUFnREE7UUFBdEpHLG9CQUFvQkEsR0FBcEJBLFdBQW9CQTtRQUFFQSxtQ0FBb0NBLEdBQXBDQSwwQkFBb0NBO1FBQUVBLDBCQUF3Q0EsR0FBeENBLGlCQUF3Q0E7UUFBRUEsbUNBQWdEQSxHQUFoREEsMEJBQWdEQTtRQUN0S0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsY0FBT0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDbEJBLElBQUlBLEdBQUdBLFNBQVNBLENBQUNBO1FBQ25CQSxDQUFDQTtRQUNEQSxJQUFJQSxLQUFLQSxHQUFHQSxlQUFlQSxDQUFDQSxDQUFDQSxFQUFFQSxVQUFVQSxFQUFFQSxVQUFVQSxFQUFFQSxtQkFBbUJBLENBQUNBLENBQUNBO1FBQzVFQSxJQUFJQSxFQUFFQSxHQUFHQSxJQUFJQSxvQkFBVUEsQ0FBQ0EsS0FBS0EsRUFBRUEsSUFBSUEsRUFBRUEsTUFBTUEsRUFBRUEsSUFBSUEsRUFBRUEsbUJBQW1CQSxDQUFDQSxDQUFDQTtRQUN4RUEsSUFBSUEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7UUFDMUJBLE1BQU1BLENBQUNBLEVBQUVBLENBQUNBO0lBQ1pBLENBQUNBO0lBRURILDZCQUE2QkEsZ0JBQXdCQSxFQUFFQSxlQUFzQkEsRUFBRUEsSUFBb0JBO1FBQXBCSSxvQkFBb0JBLEdBQXBCQSxXQUFvQkE7UUFDakdBLEVBQUVBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLElBQUlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ2xCQSxJQUFJQSxHQUFHQSxTQUFTQSxDQUFDQTtRQUNuQkEsQ0FBQ0E7UUFDREEsSUFBSUEsTUFBTUEsR0FBR0EsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFBRUEsZ0JBQWdCQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtRQUN0REEsSUFBSUEsS0FBS0EsR0FBR0EsVUFBVUEsQ0FBQ0EsTUFBTUEsRUFBRUEsZUFBZUEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7UUFFdERBLE1BQU1BLENBQUNBLEtBQUtBLENBQUNBO0lBQ2ZBLENBQUNBO0lBRURKLDJCQUEyQkEsY0FBc0JBLEVBQ3BCQSxjQUFzQkE7UUFDakRLLElBQUlBLElBQUlBLEdBQUdBLFVBQVVBLENBQUNBLElBQUlBLEVBQUVBLGNBQWNBLENBQUNBLENBQUNBO1FBQzVDQSxJQUFJQSxJQUFJQSxHQUFHQSxVQUFVQSxDQUFDQSxvQkFBUUEsQ0FBQ0EsU0FBU0EsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7UUFDaERBLElBQUlBLENBQUNBLG1CQUFtQkEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7UUFFL0JBLE1BQU1BLENBQUNBLFVBQVVBLENBQUNBLElBQUlBLEVBQUVBLGNBQWNBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO0lBQ2hEQSxDQUFDQTtJQUVETDtRQUNFTSxxQ0FBa0JBLENBQUNBO1lBQ2pCQSxJQUFJQSx5QkFBeUJBLEdBQUdBLElBQUlBLHNDQUFpQkEsRUFBRUEsQ0FBQ0E7WUFDeERBLGlCQUFpQkEsR0FBR0EsSUFBSUEsNEJBQW9CQSxFQUFFQSxDQUFDQTtZQUMvQ0EsaUJBQWlCQSxDQUFDQSxHQUFHQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQSxXQUFXQSxDQUFFQSxVQUFDQSxhQUFhQTtnQkFDMURBLElBQUlBLE1BQU1BLEdBQUdBLGlCQUFpQkEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ2xEQSxFQUFFQSxDQUFDQSxDQUFDQSxjQUFPQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDcEJBLE1BQU1BLEdBQUdBLHlCQUF5QkEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7Z0JBQzVEQSxDQUFDQTtnQkFDREEsTUFBTUEsQ0FBQ0EsTUFBTUEsQ0FBQ0E7WUFDaEJBLENBQUNBLENBQUNBLENBQUNBO1lBQ0hBLE1BQU1BLENBQUNBO2dCQUNMQSxjQUFPQSxDQUFDQSxzQ0FBaUJBLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLGlCQUFpQkEsRUFBQ0EsQ0FBQ0E7YUFDMURBLENBQUNBO1FBQ0pBLENBQUNBLENBQUNBLENBQUNBO1FBQ0hBLDZCQUFVQSxDQUFDQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsK0NBQXFCQSxDQUFDQSxFQUFFQSxVQUFDQSxjQUFjQTtZQUN4REEsaUJBQWlCQSxHQUFHQSxJQUFJQSxHQUFHQSxFQUEyQkEsQ0FBQ0E7WUFDdkRBLHFCQUFxQkEsR0FBR0EsY0FBY0EsQ0FBQ0E7WUFDdkNBLFNBQVNBLEdBQUdBLFVBQVVBLENBQUNBLG9CQUFRQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtZQUN0Q0EsZ0JBQWdCQSxHQUFHQSxjQUFPQSxDQUFDQSxDQUFDQTtZQUM1QkEsa0JBQWtCQSxHQUFHQSxDQUFDQSxDQUFDQTtRQUN6QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDTkEsQ0FBQ0E7SUFFRE4sMkJBQVFBLENBQUNBLGlCQUFpQkEsRUFBRUE7UUFDMUJBLElBQUlBLEVBQUVBLENBQUNBO1FBRVBBLDJCQUFRQSxDQUFDQSxpQkFBaUJBLEVBQUVBO1lBQzFCQSxxQkFBRUEsQ0FBQ0EseURBQXlEQSxFQUFFQTtnQkFDNURBLElBQUlBLEtBQUtBLEdBQUdBLGVBQWVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLGVBQWVBLENBQUNBLENBQUNBLENBQUNBO2dCQUVsREEseUJBQU1BLENBQUNBLEtBQUtBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSwyQkFBaUJBLENBQUNBLENBQUNBO2dCQUN4RUEseUJBQU1BLENBQUNBLGNBQU1BLE9BQUFBLEtBQUtBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBNUJBLENBQTRCQSxDQUFDQSxDQUFDQSxZQUFZQSxDQUFDQSw0QkFBNEJBLENBQUNBLENBQUNBO2dCQUN0RkEseUJBQU1BLENBQUNBLGNBQU1BLE9BQUFBLEtBQUtBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBNUJBLENBQTRCQSxDQUFDQSxDQUFDQSxZQUFZQSxDQUFDQSw0QkFBNEJBLENBQUNBLENBQUNBO1lBQ3hGQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0Esa0JBQWtCQSxFQUFFQTtZQUMzQkEscUJBQUVBLENBQUNBLHlEQUF5REEsRUFBRUE7Z0JBQzVEQSxJQUFJQSxLQUFLQSxHQUFHQSxlQUFlQSxDQUFDQSxDQUFDQSxFQUFFQSx5QkFBeUJBLENBQUNBLENBQUNBO2dCQUUxREEseUJBQU1BLENBQUNBLEtBQUtBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSwyQkFBaUJBLENBQUNBLENBQUNBO2dCQUN4RUEseUJBQU1BLENBQUNBLGNBQU1BLE9BQUFBLEtBQUtBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBNUJBLENBQTRCQSxDQUFDQSxDQUFDQSxZQUFZQSxDQUFDQSw0QkFBNEJBLENBQUNBLENBQUNBO2dCQUN0RkEseUJBQU1BLENBQUNBLGNBQU1BLE9BQUFBLEtBQUtBLENBQUNBLGtCQUFrQkEsQ0FBQ0EseUJBQXlCQSxDQUFDQSxNQUFNQSxHQUFHQSxDQUFDQSxDQUFDQSxFQUE5REEsQ0FBOERBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLE9BQU9BLEVBQUVBLENBQUNBO2dCQUMzRkEseUJBQU1BLENBQUNBLGNBQU1BLE9BQUFBLEtBQUtBLENBQUNBLGtCQUFrQkEsQ0FBQ0EseUJBQXlCQSxDQUFDQSxNQUFNQSxDQUFDQSxFQUExREEsQ0FBMERBLENBQUNBO3FCQUNuRUEsWUFBWUEsQ0FBQ0EsV0FBU0EseUJBQXlCQSxDQUFDQSxNQUFNQSx1QkFBb0JBLENBQUNBLENBQUNBO1lBQ25GQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsU0FBU0EsRUFBRUE7WUFDbEJBLHFCQUFFQSxDQUFDQSw4Q0FBOENBLEVBQUVBO2dCQUNqREEsaUJBQWlCQSxDQUFDQSxHQUFHQSxDQUFDQSxlQUFlQSxFQUFFQSxJQUFJQSw0QkFBaUJBLENBQUNBLEVBQUNBLFNBQVNBLEVBQUVBLENBQUNBLGNBQU9BLENBQUNBLGFBQWFBLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLGFBQWFBLEVBQUNBLENBQUNBLENBQUNBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUNoSUEsaUJBQWlCQSxDQUFDQSxHQUFHQSxDQUFDQSxrQkFBa0JBLEVBQUVBLElBQUlBLDRCQUFpQkEsQ0FBQ0E7b0JBQzVEQSxTQUFTQSxFQUFFQSxDQUFDQSxjQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxhQUFhQSxFQUFDQSxDQUFDQSxDQUFDQTtpQkFDL0RBLENBQUNBLENBQUNBLENBQUNBO2dCQUNOQSxJQUFJQSxHQUFHQSxHQUFHQSxlQUFlQSxDQUFFQSxDQUFDQSxFQUFFQTtvQkFDNUJBLGVBQWVBO29CQUNmQSxrQkFBa0JBO2lCQUNuQkEsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxrQkFBa0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLGVBQWVBLENBQUNBLENBQUNBO2dCQUNsRUEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxDQUFDQTtnQkFDckVBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxrQkFBa0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLGFBQWFBLENBQUNBLENBQUNBO2dCQUNuRUEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7WUFDckVBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxrREFBa0RBLEVBQUVBO2dCQUNyREEsaUJBQWlCQSxDQUFDQSxHQUFHQSxDQUFDQSxlQUFlQSxFQUFFQSxJQUFJQSw0QkFBaUJBLENBQUNBO29CQUN2Q0EsYUFBYUEsRUFBRUEsQ0FBQ0EsY0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsYUFBYUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0E7aUJBQ25FQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDeEJBLElBQUlBLEdBQUdBLEdBQUdBLGVBQWVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLGVBQWVBLENBQUNBLENBQUNBLENBQUNBO2dCQUVoREEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ2xFQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtZQUNyRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDZEQUE2REEsRUFBRUE7Z0JBQ2hFQSxpQkFBaUJBLENBQUNBLEdBQUdBLENBQUNBLGVBQWVBLEVBQUVBLElBQUlBLDRCQUFpQkEsQ0FBQ0E7b0JBQ3JEQSxhQUFhQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxjQUFPQSxDQUFDQSxNQUFNQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxNQUFNQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDeERBLFNBQVNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLE1BQU1BLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLE1BQU1BLEVBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2lCQUNyREEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ1ZBLElBQUlBLEdBQUdBLEdBQUdBLGVBQWVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLGVBQWVBLENBQUNBLENBQUNBLENBQUNBO2dCQUVoREEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ2xFQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTtnQkFDNURBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxrQkFBa0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO1lBQzlEQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsaURBQWlEQSxFQUFFQTtnQkFDcERBLElBQUlBLEdBQUdBLEdBQUdBLGVBQWVBLENBQUNBLENBQUNBLEVBQUVBLHlCQUF5QkEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3hEQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtnQkFDckRBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxrQkFBa0JBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO1lBQ3pEQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUVIQSwyQkFBUUEsQ0FBQ0EsWUFBWUEsRUFBRUE7UUFDckJBLElBQUlBLEVBQUVBLENBQUNBO1FBRVBBLENBQUNBLEVBQUVBLFFBQVFBLEVBQUVBLFFBQVFBLEVBQUVBLFVBQVVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLFFBQVFBLEVBQUVBLFNBQVNBO2dCQUM1REEsVUFBVUEsRUFBRUEseUJBQXlCQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxVQUFDQSxPQUFPQTtZQUV6REEsSUFBSUEsZUFBZUEsR0FBR0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0E7WUFDNUNBLDJCQUFRQSxDQUFJQSxPQUFPQSxDQUFDQSxVQUFVQSxDQUFDQSxjQUFXQSxFQUFFQTtnQkFFMUNBLDJCQUFRQSxDQUFDQSxXQUFXQSxFQUFFQTtvQkFDcEJBLHFCQUFFQSxDQUFDQSx5REFBeURBLEVBQUVBO3dCQUM1REEsSUFBSUEsVUFBVUEsR0FBR0Esd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLGVBQWVBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLENBQUNBO3dCQUN4RUEsSUFBSUEsRUFBRUEsR0FBR0EsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFBRUEsVUFBVUEsQ0FBQ0EsQ0FBQ0E7d0JBQ3RDQSx5QkFBTUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQTtvQkFDcEVBLENBQUNBLENBQUNBLENBQUNBO29CQUVIQSxxQkFBRUEsQ0FBQ0EsZ0ZBQWdGQSxFQUFFQTt3QkFDbkZBLElBQUlBLFVBQVVBLEdBQUdBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxlQUFlQSxFQUFFQSxjQUFjQSxDQUFDQSxFQUFFQSxlQUFlQSxDQUFDQSxDQUFDQTt3QkFDeEZBLElBQUlBLEVBQUVBLEdBQUdBLFVBQVVBLENBQUNBLElBQUlBLEVBQUVBLFVBQVVBLENBQUNBLENBQUNBO3dCQUV0Q0EsSUFBSUEsQ0FBQ0EsR0FBR0EsRUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsY0FBY0EsQ0FBQ0EsQ0FBQ0E7d0JBRS9CQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQTt3QkFDM0NBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLGVBQWVBLENBQUNBLENBQUNBO29CQUN6REEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHFCQUFFQSxDQUFDQSx5RUFBeUVBLEVBQ3pFQTt3QkFDRSxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsZUFBZSxFQUFFLElBQUksNEJBQWlCLENBQUM7NEJBQzFELFNBQVMsRUFBRSxDQUFDLGNBQU8sQ0FBQyxhQUFhLEVBQUUsRUFBQyxRQUFRLEVBQUUsYUFBYSxFQUFDLENBQUMsQ0FBQzt5QkFDL0QsQ0FBQyxDQUFDLENBQUM7d0JBQ0wsaUJBQWlCLENBQUMsR0FBRyxDQUFDLGtCQUFrQixFQUFFLElBQUksNEJBQWlCLENBQUM7NEJBQzdELFNBQVMsRUFBRTtnQ0FDVCxjQUFPLENBQUMsYUFBYSxFQUFFLEVBQUMsUUFBUSxFQUFDLGlCQUFpQixFQUFDLENBQUM7Z0NBQ3BELGNBQU8sQ0FBQyxhQUFhLEVBQUUsRUFBQyxVQUFVLEVBQ3ZCLFVBQUMsR0FBRyxJQUFLLE9BQUEsQ0FBRyxHQUFHLGtCQUFjLEVBQXBCLENBQW9CO29DQUM3QixJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUkscUJBQWMsQ0FBQyxhQUFhLENBQUMsRUFBRSxJQUFJLHVCQUFnQixFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUM7NkJBQ2pGO3lCQUNGLENBQUMsQ0FBQyxDQUFDO3dCQUNMLElBQUksUUFBUSxHQUFHLG1CQUFtQixDQUM5Qix3QkFBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLGVBQWUsQ0FBQyxFQUFFLGVBQWUsQ0FBQyxFQUN0RCxDQUFDLGtCQUFrQixDQUFDLENBQ3ZCLENBQUM7d0JBQ0YseUJBQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLHlCQUF5QixDQUFDLENBQUM7b0JBQ3pFLENBQUMsQ0FBQ0EsQ0FBQ0E7b0JBRU5BLHFCQUFFQSxDQUFDQSxxREFBcURBLEVBQUVBO3dCQUN4REEsSUFBSUEsU0FBU0EsR0FBR0E7NEJBQ1JBLGNBQU9BLENBQUNBLGFBQWFBLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLGFBQWFBLEVBQUNBLENBQUNBOzRCQUNqREEsY0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsRUFBQ0EsVUFBVUEsRUFDMUJBLFVBQUNBLEdBQUdBLElBQUtBLE9BQUFBLENBQUdBLEdBQUdBLGtCQUFjQSxFQUFwQkEsQ0FBb0JBO2dDQUM3QkEsSUFBSUEsRUFBRUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7eUJBQ2hDQSxDQUFDQTt3QkFDUkEsaUJBQWlCQSxDQUFDQSxHQUFHQSxDQUFDQSxlQUFlQSxFQUFFQSxJQUFJQSw0QkFBaUJBLENBQUNBLEVBQUNBLFNBQVNBLEVBQUVBLFNBQVNBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBO3dCQUN0RkEsSUFBSUEsRUFBRUEsR0FBR0EsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFBRUEsd0JBQVdBLENBQUNBLE1BQU1BLENBQ3hDQSxDQUFDQSxlQUFlQSxDQUFDQSxFQUFFQSxlQUFlQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFFekNBLHlCQUFNQSxDQUFDQSxFQUFFQSxDQUFDQSxHQUFHQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSx5QkFBeUJBLENBQUNBLENBQUNBO29CQUNuRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHFCQUFFQSxDQUFDQSx5REFBeURBLEVBQUVBO3dCQUM1REEsSUFBSUEsYUFBYUEsR0FBR0E7NEJBQ1pBLGNBQU9BLENBQUNBLGFBQWFBLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLGFBQWFBLEVBQUNBLENBQUNBOzRCQUNqREEsY0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsRUFBQ0EsVUFBVUEsRUFDaENBLFVBQUNBLEdBQUdBLElBQUtBLE9BQUFBLENBQUdBLEdBQUdBLGtCQUFjQSxFQUFwQkEsQ0FBb0JBO2dDQUN2QkEsSUFBSUEsRUFBRUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7eUJBQ2hDQSxDQUFDQTt3QkFFUkEsaUJBQWlCQSxDQUFDQSxHQUFHQSxDQUFDQSxlQUFlQSxFQUFFQSxJQUFJQSw0QkFBaUJBLENBQUNBOzRCQUN2REEsYUFBYUEsRUFBRUEsYUFBYUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQ3RDQSxJQUFJQSxFQUFFQSxHQUFHQSxVQUFVQSxDQUFDQSxJQUFJQSxFQUFFQSx3QkFBV0EsQ0FBQ0EsTUFBTUEsQ0FDeENBLENBQUNBLGVBQWVBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLENBQUNBLENBQUNBO3dCQUN6Q0EseUJBQU1BLENBQUNBLEVBQUVBLENBQUNBLEdBQUdBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLHlCQUF5QkEsQ0FBQ0EsQ0FBQ0E7b0JBQ25FQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFSEEscUJBQUVBLENBQUNBLHNFQUFzRUEsRUFBRUE7d0JBQ3pFQSxpQkFBaUJBLENBQUNBLEdBQUdBLENBQUNBLFlBQVlBLEVBQUVBLElBQUlBLDRCQUFpQkEsQ0FBQ0E7NEJBQ3hEQSxhQUFhQSxFQUFFQSxDQUFDQSxjQUFPQSxDQUFDQSxTQUFTQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxTQUFTQSxFQUFDQSxDQUFDQSxDQUFDQTt5QkFDM0RBLENBQUNBLENBQUNBLENBQUNBO3dCQUNKQSxJQUFJQSxFQUFFQSxHQUFHQSxVQUFVQSxDQUFDQSxJQUFJQSxFQUNwQkEsd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLFlBQVlBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLENBQUNBLENBQUNBO3dCQUN6REEseUJBQU1BLENBQUNBLEVBQUVBLENBQUNBLEdBQUdBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLFNBQVNBLENBQUNBLENBQUNBO29CQUMxREEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHFCQUFFQSxDQUFDQSxxQ0FBcUNBLEVBQUVBO3dCQUN4Q0EsSUFBSUEsT0FBT0EsR0FBR0EsS0FBS0EsQ0FBQ0E7d0JBQ3BCQSxpQkFBaUJBLENBQUNBLEdBQUdBLENBQUNBLGVBQWVBLEVBQUVBLElBQUlBLDRCQUFpQkEsQ0FBQ0E7NEJBQzNEQSxTQUFTQSxFQUFFQSxDQUFDQSxjQUFPQSxDQUFDQSxTQUFTQSxFQUFFQSxFQUFDQSxVQUFVQSxFQUFFQSxjQUFNQSxPQUFBQSxPQUFPQSxHQUFHQSxJQUFJQSxFQUFkQSxDQUFjQSxFQUFDQSxDQUFDQSxDQUFDQTt5QkFDcEVBLENBQUNBLENBQUNBLENBQUNBO3dCQUNKQSxJQUFJQSxFQUFFQSxHQUFHQSxVQUFVQSxDQUFDQSxJQUFJQSxFQUNwQkEsd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLGVBQWVBLENBQUNBLEVBQ2pCQSxlQUFlQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFFekNBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQTt3QkFFNUJBLEVBQUVBLENBQUNBLEdBQUdBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBO3dCQUVsQkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO29CQUM3QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHFCQUFFQSxDQUFDQSwwQ0FBMENBLEVBQUVBO3dCQUM3Q0EsSUFBSUEsT0FBT0EsR0FBR0EsS0FBS0EsQ0FBQ0E7d0JBQ3BCQSxpQkFBaUJBLENBQUNBLEdBQUdBLENBQUNBLGVBQWVBLEVBQUVBLElBQUlBLDRCQUFpQkEsQ0FBQ0E7NEJBQ3BDQSxhQUFhQSxFQUFFQSxDQUFDQSxjQUFPQSxDQUFDQSxTQUFTQSxFQUFFQSxFQUFDQSxVQUFVQSxFQUFFQSxjQUFNQSxPQUFBQSxPQUFPQSxHQUFHQSxJQUFJQSxFQUFkQSxDQUFjQSxFQUFDQSxDQUFDQSxDQUFDQTt5QkFDeEVBLENBQUNBLENBQUNBLENBQUNBO3dCQUMzQkEsSUFBSUEsRUFBRUEsR0FBR0EsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFDcEJBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxlQUFlQSxDQUFDQSxFQUNqQkEsZUFBZUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBRXpDQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0E7d0JBRTVCQSxFQUFFQSxDQUFDQSxHQUFHQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQTt3QkFFbEJBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtvQkFDN0JBLENBQUNBLENBQUNBLENBQUNBO29CQUVIQSxxQkFBRUEsQ0FBQ0EsZ0ZBQWdGQSxFQUNoRkE7d0JBQ0VBLGlCQUFpQkEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsZUFBZUEsRUFDckNBLElBQUlBLDRCQUFpQkEsQ0FBQ0E7NEJBQ3BCQSxhQUFhQSxFQUFFQSxDQUFDQSxjQUFPQSxDQUFDQSxTQUFTQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxTQUFTQSxFQUFDQSxDQUFDQSxDQUFDQTt5QkFDM0RBLENBQUNBLENBQUNBLENBQUNBO3dCQUNKQSx5QkFBTUEsQ0FBQ0EsY0FBUUEsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFBRUEsd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLGVBQWVBLEVBQUVBLFlBQVlBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBOzZCQUNwR0EsWUFBWUEsQ0FBQ0EsaUNBQWNBLENBQ3hCQSwrQkFBNkJBLGdCQUFTQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBZUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ2hGQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFTkEscUJBQUVBLENBQUNBLDRFQUE0RUEsRUFBRUE7d0JBQy9FQSxpQkFBaUJBLENBQUNBLEdBQUdBLENBQUNBLGVBQWVBLEVBQUVBLElBQUlBLDRCQUFpQkEsQ0FBQ0E7NEJBQ25EQSxTQUFTQSxFQUFFQSxDQUFDQSxjQUFPQSxDQUFDQSxTQUFTQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxhQUFhQSxFQUFDQSxDQUFDQSxDQUFDQSxFQUFDQSxDQUFDQSxDQUM3REEsQ0FBQ0E7d0JBQ1ZBLElBQUlBLFNBQVNBLEdBQUdBLGlCQUFpQkEsQ0FDN0JBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxlQUFlQSxDQUFDQSxFQUFFQSxlQUFlQSxDQUFDQSxFQUN0REEsd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLFlBQVlBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLENBQ3REQSxDQUFDQTt3QkFDRkEseUJBQU1BLENBQUNBLFNBQVNBLENBQUNBLEdBQUdBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLGFBQWFBLENBQUNBLENBQUNBO29CQUNyRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHFCQUFFQSxDQUFDQSw0RUFBNEVBLEVBQUVBO3dCQUMvRUEsaUJBQWlCQSxDQUFDQSxHQUFHQSxDQUFDQSxlQUFlQSxFQUFFQSxJQUFJQSw0QkFBaUJBLENBQUNBOzRCQUNuREEsYUFBYUEsRUFBRUEsQ0FBQ0EsY0FBT0EsQ0FBQ0EsU0FBU0EsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsYUFBYUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0EsQ0FDakVBLENBQUNBO3dCQUNWQSxJQUFJQSxTQUFTQSxHQUFHQSxpQkFBaUJBLENBQzdCQSx3QkFBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsZUFBZUEsQ0FBQ0EsRUFBRUEsZUFBZUEsQ0FBQ0EsRUFDdERBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxZQUFZQSxDQUFDQSxFQUFFQSxlQUFlQSxDQUFDQSxDQUN0REEsQ0FBQ0E7d0JBQ0ZBLHlCQUFNQSxDQUFDQSxTQUFTQSxDQUFDQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtvQkFDckVBLENBQUNBLENBQUNBLENBQUNBO29CQUVIQSxxQkFBRUEsQ0FBQ0Esb0dBQW9HQSxFQUFFQTt3QkFDdkdBLGlCQUFpQkEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsZUFBZUEsRUFBRUEsSUFBSUEsNEJBQWlCQSxDQUFDQTs0QkFDbkRBLGFBQWFBLEVBQUVBLENBQUNBLGNBQU9BLENBQUNBLFNBQVNBLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLGFBQWFBLEVBQUNBLENBQUNBLENBQUNBLEVBQUNBLENBQUNBLENBQ2pFQSxDQUFDQTt3QkFDVkEsSUFBSUEsSUFBSUEsR0FBR0EsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFBRUEsd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLGVBQWVBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLENBQUNBLENBQUNBO3dCQUNwRkEsSUFBSUEsY0FBY0EsR0FBR0EsVUFBVUEsQ0FBQ0Esb0JBQVFBLENBQUNBLFNBQVNBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO3dCQUMxREEsSUFBSUEsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQTt3QkFFekNBLElBQUlBLE1BQU1BLEdBQUdBLFVBQVVBLENBQUNBLElBQUlBLEVBQUVBLEVBQUVBLEVBQUVBLGNBQWNBLENBQUNBLENBQUNBO3dCQUNsREEsSUFBSUEsWUFBWUEsR0FBR0EsVUFBVUEsQ0FBQ0Esb0JBQVFBLENBQUNBLFFBQVFBLEVBQUVBLE1BQU1BLENBQUNBLENBQUNBO3dCQUV6REEsSUFBSUEsY0FBY0EsR0FBR0EsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFBRUEsd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLFlBQVlBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLEVBQUVBLFlBQVlBLENBQUNBLENBQUNBO3dCQUN6R0EseUJBQU1BLENBQUNBLGNBQWNBLENBQUNBLEdBQUdBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLGFBQWFBLENBQUNBLENBQUNBO29CQUMxRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHFCQUFFQSxDQUFDQSx3RkFBd0ZBLEVBQUVBO3dCQUMzRkEsSUFBSUEsWUFBWUEsR0FBR0EsZUFBUUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQTs0QkFDM0NBLGNBQU9BLENBQUNBLFNBQVNBLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLFlBQVlBLEVBQUNBLENBQUNBO3lCQUM3Q0EsQ0FBQ0EsQ0FBQ0E7d0JBQ0hBLElBQUlBLElBQUlBLEdBQUdBLFVBQVVBLENBQUNBLG9CQUFRQSxDQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxFQUFFQSxZQUFZQSxDQUFDQSxDQUFDQTt3QkFDL0RBLHlCQUFNQSxDQUFDQSxVQUFVQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQSxZQUFZQSxDQUFDQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQTt3QkFFL0ZBLHlCQUFNQSxDQUFDQSxjQUFNQSxPQUFBQSxVQUFVQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQSxvQkFBb0JBLENBQUNBLEVBQUVBLElBQUlBLENBQUNBLEVBQTlDQSxDQUE4Q0EsQ0FBQ0EsQ0FBQ0EsWUFBWUEsRUFBRUEsQ0FBQ0E7b0JBQzlFQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFSEEscUJBQUVBLENBQUNBLDZGQUE2RkEsRUFBRUE7d0JBQ2hHQSxJQUFJQSw0QkFBNEJBLEdBQUdBLGVBQVFBLENBQUNBLE9BQU9BLENBQUNBOzRCQUNsREEsY0FBT0EsQ0FBQ0EsU0FBU0EsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsWUFBWUEsRUFBQ0EsQ0FBQ0E7eUJBQzdDQSxDQUFDQSxDQUFDQTt3QkFDSEEsSUFBSUEsbUJBQW1CQSxHQUFHQSxVQUFVQSxDQUFDQSxJQUFJQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQTt3QkFDL0NBLElBQUlBLElBQUlBLEdBQUdBLFVBQVVBLENBQUNBLG9CQUFRQSxDQUFDQSxJQUFJQSxFQUFFQSxtQkFBbUJBLEVBQUVBLDRCQUE0QkEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7d0JBQzlGQSx5QkFBTUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0E7d0JBQy9GQSx5QkFBTUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0Esb0JBQW9CQSxDQUFDQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxvQkFBb0JBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLENBQUNBO29CQUNqSEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHFCQUFFQSxDQUFDQSxzRkFBc0ZBO3dCQUN2RkEsbUJBQW1CQSxFQUFFQTt3QkFDckJBLGlCQUFpQkEsQ0FBQ0EsR0FBR0EsQ0FBQ0Esa0JBQWtCQSxFQUFFQSxJQUFJQSw0QkFBaUJBLENBQUNBOzRCQUN4REEsU0FBU0EsRUFBRUEsQ0FBQ0EsY0FBT0EsQ0FBQ0EsU0FBU0EsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsYUFBYUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0EsQ0FDL0RBLENBQUNBO3dCQUNOQSx5QkFBTUEsQ0FBQ0E7NEJBQ0xBLGlCQUFpQkEsQ0FDZkEsd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsRUFBRUEsZUFBZUEsQ0FBQ0EsRUFDekRBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxvQkFBb0JBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLENBQzVEQSxDQUFDQTt3QkFDSkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsSUFBSUEsTUFBTUEsQ0FBQ0EsMEJBQTBCQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDMURBLENBQUNBLENBQUNBLENBQUNBO29CQUVIQSxxQkFBRUEsQ0FBQ0Esc0ZBQXNGQTt3QkFDdkZBLDJCQUEyQkEsRUFBRUE7d0JBQzdCQSxpQkFBaUJBLENBQUNBLEdBQUdBLENBQUNBLGtCQUFrQkEsRUFBRUEsSUFBSUEsNEJBQWlCQSxDQUFDQTs0QkFDdERBLFNBQVNBLEVBQUVBLENBQUNBLGNBQU9BLENBQUNBLFNBQVNBLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLGFBQWFBLEVBQUNBLENBQUNBLENBQUNBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBO3dCQUN4RUEseUJBQU1BLENBQUNBOzRCQUNMQSxpQkFBaUJBLENBQ2ZBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxlQUFlQSxFQUFFQSxrQkFBa0JBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLEVBQzFFQSx3QkFBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0Esb0JBQW9CQSxDQUFDQSxFQUFFQSxlQUFlQSxDQUFDQSxDQUM1REEsQ0FBQ0E7d0JBQ0pBLENBQUNBLENBQUNBLENBQUNBLFlBQVlBLENBQUNBLElBQUlBLE1BQU1BLENBQUNBLDBCQUEwQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQzFEQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFSEEscUJBQUVBLENBQUNBLHVCQUF1QkEsRUFBRUE7d0JBQzFCQSxJQUFJQSxLQUFLQSxHQUFHQSxpQkFBaUJBLENBQ3pCQSx3QkFBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0Esa0JBQWtCQSxFQUFFQSxlQUFlQSxDQUFDQSxFQUFFQSxlQUFlQSxDQUFDQSxFQUMxRUEsQ0FBQ0EsK0JBQStCQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFFdkNBLElBQUlBLENBQUNBLEdBQUdBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLCtCQUErQkEsQ0FBQ0EsQ0FBQ0E7d0JBRW5EQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSwrQkFBK0JBLENBQUNBLENBQUNBO3dCQUM1REEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0E7b0JBQ3pEQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFSEEscUJBQUVBLENBQUNBLHFDQUFxQ0EsRUFBRUE7d0JBQ3hDQSxJQUFJQSxLQUFLQSxHQUFHQSxtQkFBbUJBLENBQUNBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxlQUFlQSxDQUFDQSxFQUFFQSxlQUFlQSxDQUFDQSxFQUNyREEsQ0FBQ0EsdUJBQXVCQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFFNURBLElBQUlBLENBQUNBLEdBQUdBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0E7d0JBRTNDQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBO3dCQUNwREEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0E7b0JBQ3pEQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFSEEscUJBQUVBLENBQUNBLG1EQUFtREEsRUFBRUE7d0JBQ3REQSx5QkFBTUEsQ0FBQ0EsY0FBTUEsT0FBQUEsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFBRUEsd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsRUFBRUEsZUFBZUEsQ0FBQ0EsQ0FBQ0EsRUFBaEZBLENBQWdGQSxDQUFDQTs2QkFDekZBLFlBQVlBLENBQUNBLGlDQUFjQSxDQUN4QkEscUJBQW1CQSxnQkFBU0EsQ0FBQ0EsZUFBZUEsQ0FBQ0EsV0FBT0EsZ0JBQVNBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsWUFBUUEsZ0JBQVNBLENBQUNBLGVBQWVBLENBQUNBLE1BQUlBLENBQUNBLENBQUNBLENBQUNBO29CQUN6SUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHFCQUFFQSxDQUFDQSxtRUFBbUVBLEVBQUVBO3dCQUN0RUEsSUFBSUEsRUFBRUEsR0FBR0EsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFBRUEsd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLHdCQUF3QkEsQ0FBQ0EsRUFBRUEsZUFBZUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQzNGQSxJQUFJQSxDQUFDQSxHQUFHQSxFQUFFQSxDQUFDQSxHQUFHQSxDQUFDQSx3QkFBd0JBLENBQUNBLENBQUNBO3dCQUN6Q0EseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLElBQUlBLENBQUNBLENBQUNBO29CQUNyQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHFCQUFFQSxDQUFDQSwwREFBMERBLEVBQUVBO3dCQUM3REEsSUFBSUEsU0FBU0EsR0FDVEEsd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLGVBQWVBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLENBQUNBO3dCQUUzREEsSUFBSUEsRUFBRUEsR0FBR0EsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFBRUEsU0FBU0EsQ0FBQ0EsQ0FBQ0E7d0JBRXJDQSxJQUFJQSxZQUFZQSxHQUFHQSxTQUFTQSxDQUFDQSxNQUFNQSxHQUFHQSxFQUFFQSxHQUFHQSxTQUFTQSxDQUFDQSxNQUFNQSxHQUFHQSxFQUFFQSxDQUFDQTt3QkFFakVBLHlCQUFNQSxDQUFDQSxFQUFFQSxDQUFDQSxtQkFBbUJBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0E7d0JBQ3BFQSx5QkFBTUEsQ0FBQ0EsY0FBTUEsT0FBQUEsRUFBRUEsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUExQkEsQ0FBMEJBLENBQUNBLENBQUNBLFlBQVlBLENBQUNBLDRCQUE0QkEsQ0FBQ0EsQ0FBQ0E7d0JBQ3BGQSx5QkFBTUEsQ0FBQ0EsY0FBTUEsT0FBQUEsRUFBRUEsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxZQUFZQSxDQUFDQSxFQUFwQ0EsQ0FBb0NBLENBQUNBOzZCQUM3Q0EsWUFBWUEsQ0FBQ0EsV0FBU0EsWUFBWUEsdUJBQW9CQSxDQUFDQSxDQUFDQTtvQkFDL0RBLENBQUNBLENBQUNBLENBQUNBO29CQUVIQSxxQkFBRUEsQ0FBQ0EsdUVBQXVFQSxFQUFFQTt3QkFDMUVBLGlCQUFpQkEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsZUFBZUEsRUFBRUEsSUFBSUEsNEJBQWlCQSxFQUFFQSxDQUFDQSxDQUFDQTt3QkFDaEVBLElBQUlBLE1BQU1BLEdBQUdBLGlCQUFpQkEsQ0FBQ0Esd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLGVBQWVBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLEVBQ3BEQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBLENBQUNBO3dCQUU1REEsSUFBSUEsQ0FBQ0EsR0FBR0EsTUFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsdUJBQXVCQSxDQUFDQSxDQUFDQTt3QkFDNUNBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0E7d0JBQ3BEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQTtvQkFDekRBLENBQUNBLENBQUNBLENBQUNBO29CQUVIQSxxQkFBRUEsQ0FBQ0EsaUhBQWlIQSxFQUNqSEE7d0JBQ0VBLGlCQUFpQkEsQ0FBQ0EsR0FBR0EsQ0FBQ0Esa0JBQWtCQSxFQUFFQSxJQUFJQSw0QkFBaUJBLEVBQUVBLENBQUNBLENBQUNBO3dCQUNuRUEseUJBQU1BLENBQUNBOzRCQUVFQSxpQkFBaUJBLENBQ2JBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxrQkFBa0JBLEVBQUVBLGVBQWVBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLEVBQzFFQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDeEJBLENBQUNBLENBQUNBOzZCQUNKQSxZQUFZQSxDQUFDQSxpQ0FBY0EsQ0FDeEJBLHFCQUFtQkEsZ0JBQVNBLENBQUNBLGVBQWVBLENBQUNBLFdBQU9BLGdCQUFTQSxDQUFDQSxjQUFjQSxDQUFDQSxZQUFRQSxnQkFBU0EsQ0FBQ0EsZUFBZUEsQ0FBQ0EsTUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ2hJQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDUkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLDJCQUFRQSxDQUFDQSxtQkFBbUJBLEVBQUVBO29CQUM1QkEscUJBQUVBLENBQUNBLHNCQUFzQkEsRUFBRUE7d0JBQ3pCQSxJQUFJQSxFQUFFQSxHQUFHQSxVQUFVQSxDQUFDQSxJQUFJQSxFQUFFQSx3QkFBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsY0FBY0EsQ0FBQ0EsRUFBRUEsZUFBZUEsQ0FBQ0EsRUFBRUEsSUFBSUEsRUFBRUEsSUFBSUEsRUFBRUE7NEJBQzNGQSxNQUFNQSxFQUFFQSxNQUFNQTs0QkFDZEEsT0FBT0EsRUFBRUEsRUFBRUE7eUJBQ1pBLENBQUNBLENBQUNBO3dCQUNIQSxJQUFJQSxjQUFjQSxHQUFHQSxFQUFFQSxDQUFDQSxHQUFHQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQTt3QkFFNUNBLHlCQUFNQSxDQUFDQSxjQUFjQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTt3QkFDckRBLHlCQUFNQSxDQUFDQSxjQUFjQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTt3QkFDbERBLHlCQUFNQSxDQUFDQSxjQUFjQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtvQkFDcERBLENBQUNBLENBQUNBLENBQUNBO29CQUVIQSxxQkFBRUEsQ0FBQ0EsOENBQThDQSxFQUFFQTt3QkFDakRBLElBQUlBLEVBQUVBLEdBQUdBLFVBQVVBLENBQUNBLElBQUlBLEVBQUVBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxvQkFBb0JBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLEVBQUVBLElBQUlBLEVBQ3hFQSxJQUFJQSxFQUFFQSxFQUFDQSxLQUFLQSxFQUFFQSxLQUFLQSxFQUFDQSxDQUFDQSxDQUFDQTt3QkFDekNBLElBQUlBLGNBQWNBLEdBQUdBLEVBQUVBLENBQUNBLEdBQUdBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsQ0FBQ0E7d0JBRWxEQSx5QkFBTUEsQ0FBQ0EsY0FBY0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0E7b0JBQ3JEQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLDJCQUFRQSxDQUFDQSxNQUFNQSxFQUFFQTtvQkFDZkEscUJBQUVBLENBQUNBLDBCQUEwQkEsRUFBRUE7d0JBQzdCQSxJQUFJQSxFQUFFQSxHQUFHQSxVQUFVQSxDQUFDQSxJQUFJQSxFQUFFQSx3QkFBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsZUFBZUEsQ0FBQ0EsRUFBRUEsZUFBZUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQ2xGQSx5QkFBTUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7b0JBQzFEQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFSEEscUJBQUVBLENBQUNBLHdGQUF3RkEsRUFBRUE7d0JBQzNGQSxpQkFBaUJBLENBQUNBLEdBQUdBLENBQUNBLCtCQUErQkEsRUFBRUEsSUFBSUEsNEJBQWlCQSxFQUFFQSxDQUFDQSxDQUFDQTt3QkFDaEZBLElBQUlBLElBQUlBLEdBQUdBLFVBQVVBLENBQUNBLElBQUlBLEVBQUVBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSwrQkFBK0JBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLENBQUNBLENBQUNBO3dCQUNwR0EsSUFBSUEsSUFBSUEsR0FBR0EsVUFBVUEsQ0FBQ0Esb0JBQVFBLENBQUNBLFNBQVNBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO3dCQUNoREEsSUFBSUEsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTt3QkFDL0JBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLCtCQUErQkEsQ0FBQ0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxZQUFZQSxFQUFFQSxDQUFDQTt3QkFDM0VBLHlCQUFNQSxDQUFPQSxJQUFJQSxDQUFDQSxjQUFlQSxDQUFDQSxHQUFHQSxDQUFDQSwyQkFBMkJBLENBQUNBLENBQUNBLENBQUNBLGdCQUFnQkEsRUFBRUEsQ0FBQ0E7b0JBQ3pGQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFSEEscUJBQUVBLENBQUNBLDZFQUE2RUEsRUFBRUE7d0JBQ2hGQSxpQkFBaUJBLENBQUNBLEdBQUdBLENBQUNBLCtCQUErQkEsRUFBRUEsSUFBSUEsNEJBQWlCQSxFQUFFQSxDQUFDQSxDQUFDQTt3QkFDaEZBLElBQUlBLElBQUlBLEdBQUdBLFVBQVVBLENBQUNBLG9CQUFRQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTt3QkFDckNBLElBQUlBLEVBQUVBLEdBQUdBLFVBQVVBLENBQUNBLElBQUlBLEVBQUVBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSwrQkFBK0JBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO3dCQUN4R0EseUJBQU1BLENBQUNBLEVBQUVBLENBQUNBLEdBQUdBLENBQUNBLCtCQUErQkEsQ0FBQ0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxJQUFJQSxDQUFDQSxjQUFjQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtvQkFDbEdBLENBQUNBLENBQUNBLENBQUNBO29CQUVIQSxxQkFBRUEsQ0FBQ0EsZ0NBQWdDQSxFQUFFQTt3QkFDbkNBLElBQUlBLEVBQUVBLEdBQUdBLFVBQVVBLENBQUNBLElBQUlBLEVBQUVBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxrQkFBa0JBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLENBQUNBLENBQUNBO3dCQUNyRkEseUJBQU1BLENBQUNBLEVBQUVBLENBQUNBLEdBQUdBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxzQ0FBaUJBLENBQUNBLENBQUNBO29CQUN2RkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHFCQUFFQSxDQUFDQSwyQkFBMkJBLEVBQUVBO3dCQUM5QkEsSUFBSUEsRUFBRUEsR0FBR0EsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFBRUEsd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsRUFBRUEsZUFBZUEsQ0FBQ0EsRUFBRUEsSUFBSUEsRUFBRUEsZ0JBQWdCQSxDQUFDQSxDQUFDQTt3QkFDM0dBLHlCQUFNQSxDQUFDQSxFQUFFQSxDQUFDQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLFdBQVdBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLEVBQUVBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO29CQUN2RUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHFCQUFFQSxDQUFDQSx5Q0FBeUNBLEVBQUVBO3dCQUM1Q0EseUJBQU1BLENBQUNBLGNBQU1BLE9BQUFBLFVBQVVBLENBQUNBLElBQUlBLEVBQUVBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLENBQUNBLEVBQXpFQSxDQUF5RUEsQ0FBQ0E7NkJBQ2xGQSxZQUFZQSxDQUNUQSxtQ0FBaUNBLGdCQUFTQSxDQUFDQSxnQkFBZ0JBLENBQUNBLHFCQUFtQkEsQ0FBQ0EsQ0FBQ0E7b0JBQzNGQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFSEEscUJBQUVBLENBQUNBLCtFQUErRUEsRUFBRUE7d0JBQ2xGQSxJQUFJQSxFQUFFQSxHQUFHQSxVQUFVQSxDQUFDQSxJQUFJQSxFQUFFQSx3QkFBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsNEJBQTRCQSxDQUFDQSxFQUFFQSxlQUFlQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDL0ZBLElBQUlBLFFBQVFBLEdBQUdBLEVBQUVBLENBQUNBLEdBQUdBLENBQUNBLDRCQUE0QkEsQ0FBQ0EsQ0FBQ0E7d0JBQ3BEQSx5QkFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0E7b0JBQzFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLDJCQUFRQSxDQUFDQSxTQUFTQSxFQUFFQTtvQkFDbEJBLDBCQUEwQkEsS0FBcUJBLEVBQUVBLElBQUlBLEVBQUVBLGFBQWFBO3dCQUNsRU8sSUFBSUEsWUFBWUEsR0FBR0EsQ0FBQ0EsQ0FBQ0E7d0JBQ3JCQSx5QkFBTUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7d0JBQ25EQSw0QkFBZUEsQ0FBQ0EsS0FBS0EsRUFBRUEsVUFBQ0EsQ0FBQ0E7NEJBQ3ZCQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTs0QkFDakNBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxhQUFhQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQSxDQUFDQTs0QkFDbERBLFlBQVlBLElBQUlBLENBQUNBLENBQUNBO3dCQUNwQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ0xBLENBQUNBO29CQUVEUCxxQkFBRUEsQ0FBQ0Esc0JBQXNCQSxFQUFFQTt3QkFDekJBLElBQUlBLEVBQUVBLEdBQ0ZBLFVBQVVBLENBQUNBLElBQUlBLEVBQUVBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxFQUFFQSxlQUFlQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDeEVBLHlCQUFNQSxDQUFDQSxFQUFFQSxDQUFDQSxHQUFHQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLHNCQUFTQSxDQUFDQSxDQUFDQTtvQkFDL0RBLENBQUNBLENBQUNBLENBQUNBO29CQUVIQSxxQkFBRUEsQ0FBQ0EsZ0RBQWdEQSxFQUFFQTt3QkFDbkRBLElBQUlBLEVBQUVBLEdBQUdBLFVBQVVBLENBQUNBLElBQUlBLEVBQUVBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQTs0QkFDekNBLFVBQVVBOzRCQUNWQSxpQkFBaUJBO3lCQUNsQkEsRUFBRUEsZUFBZUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBRXZCQSxFQUFFQSxDQUFDQSxxQkFBcUJBLEVBQUVBLENBQUNBO3dCQUUzQkEsZ0JBQWdCQSxDQUFDQSxFQUFFQSxDQUFDQSxHQUFHQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxLQUFLQSxFQUFFQSxpQkFBaUJBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUNyRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHFCQUFFQSxDQUFDQSxrREFBa0RBLEVBQUVBO3dCQUNyREEsSUFBSUEsRUFBRUEsR0FBR0EsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFBRUEsd0JBQVdBLENBQUNBLE1BQU1BLENBQUNBOzRCQUN6Q0EscUJBQXFCQTt5QkFDdEJBLEVBQUVBLGVBQWVBLENBQUNBLEVBQUVBLElBQUlBLEVBQUVBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0E7d0JBRS9DQSxFQUFFQSxDQUFDQSxxQkFBcUJBLEVBQUVBLENBQUNBO3dCQUUzQkEseUJBQU1BLENBQUNBLEVBQUVBLENBQUNBLEdBQUdBLENBQUNBLHFCQUFxQkEsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSwyQkFBWUEsQ0FBQ0EsQ0FBQ0E7b0JBQ25GQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFSEEscUJBQUVBLENBQUNBLDZFQUE2RUEsRUFBRUE7d0JBQ2hGQSxJQUFJQSxJQUFJQSxHQUFVQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBO3dCQUU1Q0EsSUFBSUEsbUJBQW1CQSxHQUF5QkE7NEJBQzlDQSxLQUFLQSxFQUFFQSxJQUFJQSxDQUFDQSxVQUFVQTt5QkFDdkJBLENBQUNBO3dCQUVGQSxJQUFJQSxFQUFFQSxHQUFHQSxVQUFVQSxDQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQSxNQUFNQSxDQUFDQSxlQUFlQSxDQUFDQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxFQUFFQSxtQkFBbUJBLENBQUNBLENBQUNBO3dCQUUvRkEsRUFBRUEsQ0FBQ0EscUJBQXFCQSxFQUFFQSxDQUFDQTt3QkFFM0JBLHlCQUFNQSxDQUFDQSxFQUFFQSxDQUFDQSxHQUFHQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLEVBQUVBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO29CQUNuRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHFCQUFFQSxDQUFDQSxvRkFBb0ZBO3dCQUNyRkEsc0RBQXNEQSxFQUFFQTt3QkFDeERBLElBQUlBLElBQUlBLEdBQVVBLENBQUNBLHVCQUF1QkEsRUFBRUEsY0FBY0EsRUFBRUEsZUFBZUEsQ0FBQ0EsQ0FBQ0E7d0JBRTdFQSxJQUFJQSxtQkFBbUJBLEdBQXlCQTs0QkFDOUNBLEtBQUtBLEVBQUVBLENBQUNBOzRCQUNSQSxLQUFLQSxFQUFFQSxDQUFDQSxDQUFDQSxtQ0FBbUNBO3lCQUM3Q0EsQ0FBQ0E7d0JBRUZBLElBQUlBLEVBQUVBLEdBQUdBLFVBQVVBLENBQUNBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLE1BQU1BLENBQUNBLGVBQWVBLENBQUNBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLEVBQUVBLG1CQUFtQkEsQ0FBQ0EsQ0FBQ0E7d0JBRS9GQSxFQUFFQSxDQUFDQSxxQkFBcUJBLEVBQUVBLENBQUNBO3dCQUUzQkEsZ0dBQWdHQTt3QkFDaEdBLHlCQUFNQSxDQUFDQSxFQUFFQSxDQUFDQSxHQUFHQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0E7d0JBQ3RGQSx5QkFBTUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsdUJBQXVCQSxDQUFDQSxDQUFDQSxLQUFLQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLGNBQWNBLENBQUNBLENBQUNBO29CQUN0RkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLHFCQUFFQSxDQUFDQSxrRkFBa0ZBLEVBQUVBO3dCQUNyRkEsSUFBSUEsTUFBTUEsR0FBR0EsVUFBVUEsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0EsVUFBVUEsRUFBRUEsaUJBQWlCQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDL0RBLFVBQVVBLENBQUNBLE1BQU1BLEVBQUVBLHdCQUFXQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxpQkFBaUJBLENBQUNBLEVBQUVBLGVBQWVBLENBQUNBLENBQUNBLENBQUNBO3dCQUU3RUEsTUFBTUEsQ0FBQ0EscUJBQXFCQSxFQUFFQSxDQUFDQTt3QkFFL0JBLGdCQUFnQkEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0EsS0FBS0EsRUFBRUEsaUJBQWlCQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDNUVBLENBQUNBLENBQUNBLENBQUNBO2dCQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQXJrQmUsWUFBSSxPQXFrQm5CLENBQUE7QUFFRDtJQUVFUSw0QkFBWUEsT0FBT0E7UUFBSUMsSUFBSUEsQ0FBQ0EsT0FBT0EsR0FBR0EsT0FBT0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFDbERELHlCQUFDQTtBQUFEQSxDQUFDQSxBQUhELElBR0MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUT0RPKHRib3NjaCk6IGNsYW5nLWZvcm1hdCBzY3Jld3MgdGhpcyB1cCwgc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2NsYW5nLWZvcm1hdC9pc3N1ZXMvMTEuXG4vLyBFbmFibGUgY2xhbmctZm9ybWF0IGhlcmUgYWdhaW4gd2hlbiB0aGlzIGlzIGZpeGVkLlxuLy8gY2xhbmctZm9ybWF0IG9mZlxuaW1wb3J0IHtcbiAgZGVzY3JpYmUsXG4gIGRkZXNjcmliZSxcbiAgaXQsXG4gIGlpdCxcbiAgeGl0LFxuICB4ZGVzY3JpYmUsXG4gIGV4cGVjdCxcbiAgYmVmb3JlRWFjaCxcbiAgYmVmb3JlRWFjaEJpbmRpbmdzLFxuICBpbmplY3QsXG4gIEFzeW5jVGVzdENvbXBsZXRlcixcbiAgZWwsXG4gIGNvbnRhaW5zUmVnZXhwXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuaW1wb3J0IHtTcHlWaWV3LCBTcHlFbGVtZW50UmVmLCBTcHlEaXJlY3RpdmVSZXNvbHZlciwgU3B5UHJvdG9WaWV3LCBTcHlDaGFuZ2VEZXRlY3RvciwgU3B5QXBwVmlld01hbmFnZXJ9IGZyb20gJy4uL3NwaWVzJztcbmltcG9ydCB7aXNCbGFuaywgaXNQcmVzZW50LCBzdHJpbmdpZnksIFR5cGV9IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvbGFuZyc7XG5pbXBvcnQge1Jlc29sdmVkUHJvdmlkZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2RpJztcbmltcG9ydCB7XG4gIExpc3RXcmFwcGVyLFxuICBNYXBXcmFwcGVyLFxuICBTdHJpbmdNYXBXcmFwcGVyLFxuICBpdGVyYXRlTGlzdExpa2Vcbn0gZnJvbSAnYW5ndWxhcjIvc3JjL2ZhY2FkZS9jb2xsZWN0aW9uJztcbmltcG9ydCB7XG4gIEFwcFByb3RvRWxlbWVudCxcbiAgQXBwRWxlbWVudCxcbiAgRGlyZWN0aXZlUHJvdmlkZXJcbn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvbGlua2VyL2VsZW1lbnQnO1xuaW1wb3J0IHtSZXNvbHZlZE1ldGFkYXRhQ2FjaGV9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci9yZXNvbHZlZF9tZXRhZGF0YV9jYWNoZSc7XG5pbXBvcnQge0RpcmVjdGl2ZVJlc29sdmVyfSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9saW5rZXIvZGlyZWN0aXZlX3Jlc29sdmVyJztcbmltcG9ydCB7XG4gIEF0dHJpYnV0ZSxcbiAgUXVlcnksXG4gIFZpZXdRdWVyeSxcbiAgQ29tcG9uZW50TWV0YWRhdGEsXG4gIERpcmVjdGl2ZU1ldGFkYXRhLFxuICBWaWV3RW5jYXBzdWxhdGlvblxufSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9tZXRhZGF0YSc7XG5pbXBvcnQge09uRGVzdHJveSwgRGlyZWN0aXZlfSBmcm9tICdhbmd1bGFyMi9jb3JlJztcbmltcG9ydCB7cHJvdmlkZSwgSW5qZWN0b3IsIFByb3ZpZGVyLCBPcHRpb25hbCwgSW5qZWN0LCBJbmplY3RhYmxlLCBTZWxmLCBTa2lwU2VsZiwgSW5qZWN0TWV0YWRhdGEsIEhvc3QsIEhvc3RNZXRhZGF0YSwgU2tpcFNlbGZNZXRhZGF0YX0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5pbXBvcnQge1ZpZXdDb250YWluZXJSZWYsIFZpZXdDb250YWluZXJSZWZffSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9saW5rZXIvdmlld19jb250YWluZXJfcmVmJztcbmltcG9ydCB7VGVtcGxhdGVSZWYsIFRlbXBsYXRlUmVmX30gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvbGlua2VyL3RlbXBsYXRlX3JlZic7XG5pbXBvcnQge0VsZW1lbnRSZWZ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci9lbGVtZW50X3JlZic7XG5pbXBvcnQge0R5bmFtaWNDaGFuZ2VEZXRlY3RvciwgQ2hhbmdlRGV0ZWN0b3JSZWYsIFBhcnNlciwgTGV4ZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2NoYW5nZV9kZXRlY3Rpb24vY2hhbmdlX2RldGVjdGlvbic7XG5pbXBvcnQge0NoYW5nZURldGVjdG9yUmVmX30gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvY2hhbmdlX2RldGVjdGlvbi9jaGFuZ2VfZGV0ZWN0b3JfcmVmJztcbmltcG9ydCB7UXVlcnlMaXN0fSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9saW5rZXIvcXVlcnlfbGlzdCc7XG5pbXBvcnQge0FwcFZpZXcsIEFwcFByb3RvVmlld30gZnJvbSBcImFuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci92aWV3XCI7XG5pbXBvcnQge1ZpZXdUeXBlfSBmcm9tIFwiYW5ndWxhcjIvc3JjL2NvcmUvbGlua2VyL3ZpZXdfdHlwZVwiO1xuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgU2ltcGxlRGlyZWN0aXZlIHt9XG5cbmNsYXNzIFNpbXBsZVNlcnZpY2Uge31cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICcnfSlcbmNsYXNzIFNvbWVPdGhlckRpcmVjdGl2ZSB7fVxuXG52YXIgX2NvbnN0cnVjdGlvbkNvdW50O1xuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICcnfSlcbmNsYXNzIENvdW50aW5nRGlyZWN0aXZlIHtcbiAgY291bnQ6IG51bWJlcjtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5jb3VudCA9IF9jb25zdHJ1Y3Rpb25Db3VudDtcbiAgICBfY29uc3RydWN0aW9uQ291bnQgKz0gMTtcbiAgfVxufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRmFuY3lDb3VudGluZ0RpcmVjdGl2ZSBleHRlbmRzIENvdW50aW5nRGlyZWN0aXZlIHtcbiAgY29uc3RydWN0b3IoKSB7IHN1cGVyKCk7IH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICcnfSlcbmNsYXNzIE5lZWRzRGlyZWN0aXZlIHtcbiAgZGVwZW5kZW5jeTogU2ltcGxlRGlyZWN0aXZlO1xuICBjb25zdHJ1Y3RvcihAU2VsZigpIGRlcGVuZGVuY3k6IFNpbXBsZURpcmVjdGl2ZSkgeyB0aGlzLmRlcGVuZGVuY3kgPSBkZXBlbmRlbmN5OyB9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnJ30pXG5jbGFzcyBPcHRpb25hbGx5TmVlZHNEaXJlY3RpdmUge1xuICBkZXBlbmRlbmN5OiBTaW1wbGVEaXJlY3RpdmU7XG4gIGNvbnN0cnVjdG9yKEBTZWxmKCkgQE9wdGlvbmFsKCkgZGVwZW5kZW5jeTogU2ltcGxlRGlyZWN0aXZlKSB7IHRoaXMuZGVwZW5kZW5jeSA9IGRlcGVuZGVuY3k7IH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICcnfSlcbmNsYXNzIE5lZWVkc0RpcmVjdGl2ZUZyb21Ib3N0IHtcbiAgZGVwZW5kZW5jeTogU2ltcGxlRGlyZWN0aXZlO1xuICBjb25zdHJ1Y3RvcihASG9zdCgpIGRlcGVuZGVuY3k6IFNpbXBsZURpcmVjdGl2ZSkgeyB0aGlzLmRlcGVuZGVuY3kgPSBkZXBlbmRlbmN5OyB9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnJ30pXG5jbGFzcyBOZWVkc0RpcmVjdGl2ZUZyb21Ib3N0U2hhZG93RG9tIHtcbiAgZGVwZW5kZW5jeTogU2ltcGxlRGlyZWN0aXZlO1xuICBjb25zdHJ1Y3RvcihkZXBlbmRlbmN5OiBTaW1wbGVEaXJlY3RpdmUpIHsgdGhpcy5kZXBlbmRlbmN5ID0gZGVwZW5kZW5jeTsgfVxufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgTmVlZHNTZXJ2aWNlIHtcbiAgc2VydmljZTogYW55O1xuICBjb25zdHJ1Y3RvcihASW5qZWN0KFwic2VydmljZVwiKSBzZXJ2aWNlKSB7IHRoaXMuc2VydmljZSA9IHNlcnZpY2U7IH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICcnfSlcbmNsYXNzIE5lZWRzU2VydmljZUZyb21Ib3N0IHtcbiAgc2VydmljZTogYW55O1xuICBjb25zdHJ1Y3RvcihASG9zdCgpIEBJbmplY3QoXCJzZXJ2aWNlXCIpIHNlcnZpY2UpIHsgdGhpcy5zZXJ2aWNlID0gc2VydmljZTsgfVxufVxuXG5jbGFzcyBIYXNFdmVudEVtaXR0ZXIge1xuICBlbWl0dGVyO1xuICBjb25zdHJ1Y3RvcigpIHsgdGhpcy5lbWl0dGVyID0gXCJlbWl0dGVyXCI7IH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICcnfSlcbmNsYXNzIE5lZWRzQXR0cmlidXRlIHtcbiAgdHlwZUF0dHJpYnV0ZTtcbiAgdGl0bGVBdHRyaWJ1dGU7XG4gIGZvb0F0dHJpYnV0ZTtcbiAgY29uc3RydWN0b3IoQEF0dHJpYnV0ZSgndHlwZScpIHR5cGVBdHRyaWJ1dGU6IFN0cmluZywgQEF0dHJpYnV0ZSgndGl0bGUnKSB0aXRsZUF0dHJpYnV0ZTogU3RyaW5nLFxuICAgICAgICAgICAgICBAQXR0cmlidXRlKCdmb28nKSBmb29BdHRyaWJ1dGU6IFN0cmluZykge1xuICAgIHRoaXMudHlwZUF0dHJpYnV0ZSA9IHR5cGVBdHRyaWJ1dGU7XG4gICAgdGhpcy50aXRsZUF0dHJpYnV0ZSA9IHRpdGxlQXR0cmlidXRlO1xuICAgIHRoaXMuZm9vQXR0cmlidXRlID0gZm9vQXR0cmlidXRlO1xuICB9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnJ30pXG5jbGFzcyBOZWVkc0F0dHJpYnV0ZU5vVHlwZSB7XG4gIGZvb0F0dHJpYnV0ZTtcbiAgY29uc3RydWN0b3IoQEF0dHJpYnV0ZSgnZm9vJykgZm9vQXR0cmlidXRlKSB7IHRoaXMuZm9vQXR0cmlidXRlID0gZm9vQXR0cmlidXRlOyB9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnJ30pXG5jbGFzcyBOZWVkc1F1ZXJ5IHtcbiAgcXVlcnk6IFF1ZXJ5TGlzdDxDb3VudGluZ0RpcmVjdGl2ZT47XG4gIGNvbnN0cnVjdG9yKEBRdWVyeShDb3VudGluZ0RpcmVjdGl2ZSkgcXVlcnk6IFF1ZXJ5TGlzdDxDb3VudGluZ0RpcmVjdGl2ZT4pIHsgdGhpcy5xdWVyeSA9IHF1ZXJ5OyB9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnJ30pXG5jbGFzcyBOZWVkc1ZpZXdRdWVyeSB7XG4gIHF1ZXJ5OiBRdWVyeUxpc3Q8Q291bnRpbmdEaXJlY3RpdmU+O1xuICBjb25zdHJ1Y3RvcihAVmlld1F1ZXJ5KENvdW50aW5nRGlyZWN0aXZlKSBxdWVyeTogUXVlcnlMaXN0PENvdW50aW5nRGlyZWN0aXZlPikgeyB0aGlzLnF1ZXJ5ID0gcXVlcnk7IH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICcnfSlcbmNsYXNzIE5lZWRzUXVlcnlCeVZhckJpbmRpbmdzIHtcbiAgcXVlcnk6IFF1ZXJ5TGlzdDxhbnk+O1xuICBjb25zdHJ1Y3RvcihAUXVlcnkoXCJvbmUsdHdvXCIpIHF1ZXJ5OiBRdWVyeUxpc3Q8YW55PikgeyB0aGlzLnF1ZXJ5ID0gcXVlcnk7IH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICcnfSlcbmNsYXNzIE5lZWRzVGVtcGxhdGVSZWZRdWVyeSB7XG4gIHF1ZXJ5OiBRdWVyeUxpc3Q8VGVtcGxhdGVSZWY+O1xuICBjb25zdHJ1Y3RvcihAUXVlcnkoVGVtcGxhdGVSZWYpIHF1ZXJ5OiBRdWVyeUxpc3Q8VGVtcGxhdGVSZWY+KSB7IHRoaXMucXVlcnkgPSBxdWVyeTsgfVxufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgTmVlZHNFbGVtZW50UmVmIHtcbiAgZWxlbWVudFJlZjtcbiAgY29uc3RydWN0b3IocmVmOiBFbGVtZW50UmVmKSB7IHRoaXMuZWxlbWVudFJlZiA9IHJlZjsgfVxufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgTmVlZHNWaWV3Q29udGFpbmVyIHtcbiAgdmlld0NvbnRhaW5lcjtcbiAgY29uc3RydWN0b3IodmM6IFZpZXdDb250YWluZXJSZWYpIHsgdGhpcy52aWV3Q29udGFpbmVyID0gdmM7IH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICcnfSlcbmNsYXNzIE5lZWRzVGVtcGxhdGVSZWYge1xuICB0ZW1wbGF0ZVJlZjtcbiAgY29uc3RydWN0b3IocmVmOiBUZW1wbGF0ZVJlZikgeyB0aGlzLnRlbXBsYXRlUmVmID0gcmVmOyB9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnJ30pXG5jbGFzcyBPcHRpb25hbGx5SW5qZWN0c1RlbXBsYXRlUmVmIHtcbiAgdGVtcGxhdGVSZWY7XG4gIGNvbnN0cnVjdG9yKEBPcHRpb25hbCgpIHJlZjogVGVtcGxhdGVSZWYpIHsgdGhpcy50ZW1wbGF0ZVJlZiA9IHJlZjsgfVxufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRGlyZWN0aXZlTmVlZHNDaGFuZ2VEZXRlY3RvclJlZiB7XG4gIGNvbnN0cnVjdG9yKHB1YmxpYyBjaGFuZ2VEZXRlY3RvclJlZjogQ2hhbmdlRGV0ZWN0b3JSZWYpIHt9XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnJ30pXG5jbGFzcyBDb21wb25lbnROZWVkc0NoYW5nZURldGVjdG9yUmVmIHtcbiAgY29uc3RydWN0b3IocHVibGljIGNoYW5nZURldGVjdG9yUmVmOiBDaGFuZ2VEZXRlY3RvclJlZikge31cbn1cblxuQEluamVjdGFibGUoKVxuY2xhc3MgUGlwZU5lZWRzQ2hhbmdlRGV0ZWN0b3JSZWYge1xuICBjb25zdHJ1Y3RvcihwdWJsaWMgY2hhbmdlRGV0ZWN0b3JSZWY6IENoYW5nZURldGVjdG9yUmVmKSB7fVxufVxuXG5jbGFzcyBBX05lZWRzX0Ige1xuICBjb25zdHJ1Y3RvcihkZXApIHt9XG59XG5cbmNsYXNzIEJfTmVlZHNfQSB7XG4gIGNvbnN0cnVjdG9yKGRlcCkge31cbn1cblxuY2xhc3MgRGlyZWN0aXZlV2l0aERlc3Ryb3kgaW1wbGVtZW50cyBPbkRlc3Ryb3kge1xuICBuZ09uRGVzdHJveUNvdW50ZXI6IG51bWJlcjtcblxuICBjb25zdHJ1Y3RvcigpIHsgdGhpcy5uZ09uRGVzdHJveUNvdW50ZXIgPSAwOyB9XG5cbiAgbmdPbkRlc3Ryb3koKSB7IHRoaXMubmdPbkRlc3Ryb3lDb3VudGVyKys7IH1cbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICcnfSlcbmNsYXNzIEQwIHt9XG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRDEge31cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnJ30pXG5jbGFzcyBEMiB7fVxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICcnfSlcbmNsYXNzIEQzIHt9XG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRDQge31cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnJ30pXG5jbGFzcyBENSB7fVxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICcnfSlcbmNsYXNzIEQ2IHt9XG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRDcge31cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnJ30pXG5jbGFzcyBEOCB7fVxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICcnfSlcbmNsYXNzIEQ5IHt9XG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRDEwIHt9XG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRDExIHt9XG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRDEyIHt9XG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRDEzIHt9XG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRDE0IHt9XG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRDE1IHt9XG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRDE2IHt9XG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRDE3IHt9XG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRDE4IHt9XG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJyd9KVxuY2xhc3MgRDE5IHt9XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICAvLyBBbiBpbmplY3RvciB3aXRoIG1vcmUgdGhhbiAxMCBwcm92aWRlcnMgd2lsbCBzd2l0Y2ggdG8gdGhlIGR5bmFtaWMgc3RyYXRlZ3lcbiAgdmFyIGR5bmFtaWNTdHJhdGVneURpcmVjdGl2ZXMgPSBbRDAsIEQxLCBEMiwgRDMsIEQ0LCBENSwgRDYsIEQ3LCBEOCwgRDksIEQxMCwgRDExLCBEMTIsIEQxMywgRDE0LCBEMTUsIEQxNiwgRDE3LCBEMTgsIEQxOV07XG4gIHZhciByZXNvbHZlZE1ldGFkYXRhQ2FjaGU6UmVzb2x2ZWRNZXRhZGF0YUNhY2hlO1xuICB2YXIgbW9ja0RpcmVjdGl2ZU1ldGE6TWFwPFR5cGUsIERpcmVjdGl2ZU1ldGFkYXRhPjtcbiAgdmFyIGRpcmVjdGl2ZVJlc29sdmVyOlNweURpcmVjdGl2ZVJlc29sdmVyO1xuICB2YXIgZHVtbXlWaWV3OkFwcFZpZXc7XG4gIHZhciBkdW1teVZpZXdGYWN0b3J5OkZ1bmN0aW9uO1xuXG4gIGZ1bmN0aW9uIGNyZWF0ZVZpZXcodHlwZTogVmlld1R5cGUsIGNvbnRhaW5lckFwcEVsZW1lbnQ6QXBwRWxlbWVudCA9IG51bGwsIGltcGVyYXRpdmVseUNyZWF0ZWRQcm92aWRlcnM6IFJlc29sdmVkUHJvdmlkZXJbXSA9IG51bGwsIHJvb3RJbmplY3RvcjogSW5qZWN0b3IgPSBudWxsLCBwaXBlczogVHlwZVtdID0gbnVsbCk6QXBwVmlldyB7XG4gICAgaWYgKGlzQmxhbmsocGlwZXMpKSB7XG4gICAgICBwaXBlcyA9IFtdO1xuICAgIH1cbiAgICB2YXIgcHJvdG8gPSBBcHBQcm90b1ZpZXcuY3JlYXRlKHJlc29sdmVkTWV0YWRhdGFDYWNoZSwgdHlwZSwgcGlwZXMsIHt9KTtcbiAgICB2YXIgY2QgPSBuZXcgU3B5Q2hhbmdlRGV0ZWN0b3IoKTtcbiAgICBjZC5wcm9wKCdyZWYnLCBuZXcgQ2hhbmdlRGV0ZWN0b3JSZWZfKDxhbnk+Y2QpKTtcblxuICAgIHZhciB2aWV3ID0gbmV3IEFwcFZpZXcocHJvdG8sIG51bGwsIDxhbnk+bmV3IFNweUFwcFZpZXdNYW5hZ2VyKCksIFtdLCBjb250YWluZXJBcHBFbGVtZW50LCBpbXBlcmF0aXZlbHlDcmVhdGVkUHJvdmlkZXJzLCByb290SW5qZWN0b3IsIDxhbnk+IGNkKTtcbiAgICB2aWV3LmluaXQoW10sIFtdLCBbXSwgW10pO1xuICAgIHJldHVybiB2aWV3O1xuICB9XG5cbiAgZnVuY3Rpb24gcHJvdG9BcHBFbGVtZW50KGluZGV4LCBkaXJlY3RpdmVzOiBUeXBlW10sIGF0dHJpYnV0ZXM6IHtba2V5OnN0cmluZ106c3RyaW5nfSA9IG51bGwsIGRpclZhcmlhYmxlQmluZGluZ3M6e1trZXk6c3RyaW5nXTpudW1iZXJ9ID0gbnVsbCkge1xuICAgIHJldHVybiBBcHBQcm90b0VsZW1lbnQuY3JlYXRlKHJlc29sdmVkTWV0YWRhdGFDYWNoZSwgaW5kZXgsIGF0dHJpYnV0ZXMsIGRpcmVjdGl2ZXMsIGRpclZhcmlhYmxlQmluZGluZ3MpO1xuICB9XG5cbiAgZnVuY3Rpb24gYXBwRWxlbWVudChwYXJlbnQ6IEFwcEVsZW1lbnQsIGRpcmVjdGl2ZXM6IFR5cGVbXSxcbiAgICAgICAgICAgICAgICAgICAgdmlldzogQXBwVmlldyA9IG51bGwsIGVtYmVkZGVkVmlld0ZhY3Rvcnk6IEZ1bmN0aW9uID0gbnVsbCwgYXR0cmlidXRlczoge1trZXk6c3RyaW5nXTpzdHJpbmd9ID0gbnVsbCwgZGlyVmFyaWFibGVCaW5kaW5nczp7W2tleTpzdHJpbmddOm51bWJlcn0gPSBudWxsKSB7XG4gICAgaWYgKGlzQmxhbmsodmlldykpIHtcbiAgICAgIHZpZXcgPSBkdW1teVZpZXc7XG4gICAgfVxuICAgIHZhciBwcm90byA9IHByb3RvQXBwRWxlbWVudCgwLCBkaXJlY3RpdmVzLCBhdHRyaWJ1dGVzLCBkaXJWYXJpYWJsZUJpbmRpbmdzKTtcbiAgICB2YXIgZWwgPSBuZXcgQXBwRWxlbWVudChwcm90bywgdmlldywgcGFyZW50LCBudWxsLCBlbWJlZGRlZFZpZXdGYWN0b3J5KTtcbiAgICB2aWV3LmFwcEVsZW1lbnRzLnB1c2goZWwpO1xuICAgIHJldHVybiBlbDtcbiAgfVxuXG4gIGZ1bmN0aW9uIHBhcmVudENoaWxkRWxlbWVudHMocGFyZW50RGlyZWN0aXZlczogVHlwZVtdLCBjaGlsZERpcmVjdGl2ZXM6VHlwZVtdLCB2aWV3OiBBcHBWaWV3ID0gbnVsbCkge1xuICAgIGlmIChpc0JsYW5rKHZpZXcpKSB7XG4gICAgICB2aWV3ID0gZHVtbXlWaWV3O1xuICAgIH1cbiAgICB2YXIgcGFyZW50ID0gYXBwRWxlbWVudChudWxsLCBwYXJlbnREaXJlY3RpdmVzLCB2aWV3KTtcbiAgICB2YXIgY2hpbGQgPSBhcHBFbGVtZW50KHBhcmVudCwgY2hpbGREaXJlY3RpdmVzLCB2aWV3KTtcblxuICAgIHJldHVybiBjaGlsZDtcbiAgfVxuXG4gIGZ1bmN0aW9uIGhvc3RTaGFkb3dFbGVtZW50KGhvc3REaXJlY3RpdmVzOiBUeXBlW10sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld0RpcmVjdGl2ZXM6IFR5cGVbXSk6IEFwcEVsZW1lbnQge1xuICAgIHZhciBob3N0ID0gYXBwRWxlbWVudChudWxsLCBob3N0RGlyZWN0aXZlcyk7XG4gICAgdmFyIHZpZXcgPSBjcmVhdGVWaWV3KFZpZXdUeXBlLkNPTVBPTkVOVCwgaG9zdCk7XG4gICAgaG9zdC5hdHRhY2hDb21wb25lbnRWaWV3KHZpZXcpO1xuXG4gICAgcmV0dXJuIGFwcEVsZW1lbnQobnVsbCwgdmlld0RpcmVjdGl2ZXMsIHZpZXcpO1xuICB9XG5cbiAgZnVuY3Rpb24gaW5pdCgpIHtcbiAgICBiZWZvcmVFYWNoQmluZGluZ3MoKCkgPT4ge1xuICAgICAgdmFyIGRlbGVnYXRlRGlyZWN0aXZlUmVzb2x2ZXIgPSBuZXcgRGlyZWN0aXZlUmVzb2x2ZXIoKTtcbiAgICAgIGRpcmVjdGl2ZVJlc29sdmVyID0gbmV3IFNweURpcmVjdGl2ZVJlc29sdmVyKCk7XG4gICAgICBkaXJlY3RpdmVSZXNvbHZlci5zcHkoJ3Jlc29sdmUnKS5hbmRDYWxsRmFrZSggKGRpcmVjdGl2ZVR5cGUpID0+IHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IG1vY2tEaXJlY3RpdmVNZXRhLmdldChkaXJlY3RpdmVUeXBlKTtcbiAgICAgICAgaWYgKGlzQmxhbmsocmVzdWx0KSkge1xuICAgICAgICAgIHJlc3VsdCA9IGRlbGVnYXRlRGlyZWN0aXZlUmVzb2x2ZXIucmVzb2x2ZShkaXJlY3RpdmVUeXBlKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gW1xuICAgICAgICBwcm92aWRlKERpcmVjdGl2ZVJlc29sdmVyLCB7dXNlVmFsdWU6IGRpcmVjdGl2ZVJlc29sdmVyfSlcbiAgICAgIF07XG4gICAgfSk7XG4gICAgYmVmb3JlRWFjaChpbmplY3QoW1Jlc29sdmVkTWV0YWRhdGFDYWNoZV0sIChfbWV0YWRhdGFDYWNoZSkgPT4ge1xuICAgICAgbW9ja0RpcmVjdGl2ZU1ldGEgPSBuZXcgTWFwPFR5cGUsIERpcmVjdGl2ZU1ldGFkYXRhPigpO1xuICAgICAgcmVzb2x2ZWRNZXRhZGF0YUNhY2hlID0gX21ldGFkYXRhQ2FjaGU7XG4gICAgICBkdW1teVZpZXcgPSBjcmVhdGVWaWV3KFZpZXdUeXBlLkhPU1QpO1xuICAgICAgZHVtbXlWaWV3RmFjdG9yeSA9ICgpID0+IHt9O1xuICAgICAgX2NvbnN0cnVjdGlvbkNvdW50ID0gMDtcbiAgICB9KSk7XG4gIH1cblxuICBkZXNjcmliZShcIlByb3RvQXBwRWxlbWVudFwiLCAoKSA9PiB7XG4gICAgaW5pdCgpO1xuXG4gICAgZGVzY3JpYmUoJ2lubGluZSBzdHJhdGVneScsICgpID0+IHtcbiAgICAgIGl0KFwic2hvdWxkIGFsbG93IGZvciBkaXJlY3QgYWNjZXNzIHVzaW5nIGdldFByb3ZpZGVyQXRJbmRleFwiLCAoKSA9PiB7XG4gICAgICAgIHZhciBwcm90byA9IHByb3RvQXBwRWxlbWVudCgwLCBbU2ltcGxlRGlyZWN0aXZlXSk7XG5cbiAgICAgICAgZXhwZWN0KHByb3RvLmdldFByb3ZpZGVyQXRJbmRleCgwKSkudG9CZUFuSW5zdGFuY2VPZihEaXJlY3RpdmVQcm92aWRlcik7XG4gICAgICAgIGV4cGVjdCgoKSA9PiBwcm90by5nZXRQcm92aWRlckF0SW5kZXgoLTEpKS50b1Rocm93RXJyb3IoJ0luZGV4IC0xIGlzIG91dC1vZi1ib3VuZHMuJyk7XG4gICAgICAgIGV4cGVjdCgoKSA9PiBwcm90by5nZXRQcm92aWRlckF0SW5kZXgoMTApKS50b1Rocm93RXJyb3IoJ0luZGV4IDEwIGlzIG91dC1vZi1ib3VuZHMuJyk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKCdkeW5hbWljIHN0cmF0ZWd5JywgKCkgPT4ge1xuICAgICAgaXQoXCJzaG91bGQgYWxsb3cgZm9yIGRpcmVjdCBhY2Nlc3MgdXNpbmcgZ2V0UHJvdmlkZXJBdEluZGV4XCIsICgpID0+IHtcbiAgICAgICAgdmFyIHByb3RvID0gcHJvdG9BcHBFbGVtZW50KDAsIGR5bmFtaWNTdHJhdGVneURpcmVjdGl2ZXMpO1xuXG4gICAgICAgIGV4cGVjdChwcm90by5nZXRQcm92aWRlckF0SW5kZXgoMCkpLnRvQmVBbkluc3RhbmNlT2YoRGlyZWN0aXZlUHJvdmlkZXIpO1xuICAgICAgICBleHBlY3QoKCkgPT4gcHJvdG8uZ2V0UHJvdmlkZXJBdEluZGV4KC0xKSkudG9UaHJvd0Vycm9yKCdJbmRleCAtMSBpcyBvdXQtb2YtYm91bmRzLicpO1xuICAgICAgICBleHBlY3QoKCkgPT4gcHJvdG8uZ2V0UHJvdmlkZXJBdEluZGV4KGR5bmFtaWNTdHJhdGVneURpcmVjdGl2ZXMubGVuZ3RoIC0gMSkpLm5vdC50b1Rocm93KCk7XG4gICAgICAgIGV4cGVjdCgoKSA9PiBwcm90by5nZXRQcm92aWRlckF0SW5kZXgoZHluYW1pY1N0cmF0ZWd5RGlyZWN0aXZlcy5sZW5ndGgpKVxuICAgICAgICAgICAgLnRvVGhyb3dFcnJvcihgSW5kZXggJHtkeW5hbWljU3RyYXRlZ3lEaXJlY3RpdmVzLmxlbmd0aH0gaXMgb3V0LW9mLWJvdW5kcy5gKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoXCIuY3JlYXRlXCIsICgpID0+IHtcbiAgICAgIGl0KFwic2hvdWxkIGNvbGxlY3QgcHJvdmlkZXJzIGZyb20gYWxsIGRpcmVjdGl2ZXNcIiwgKCkgPT4ge1xuICAgICAgICBtb2NrRGlyZWN0aXZlTWV0YS5zZXQoU2ltcGxlRGlyZWN0aXZlLCBuZXcgRGlyZWN0aXZlTWV0YWRhdGEoe3Byb3ZpZGVyczogW3Byb3ZpZGUoJ2luamVjdGFibGUxJywge3VzZVZhbHVlOiAnaW5qZWN0YWJsZTEnfSldfSkpO1xuICAgICAgICBtb2NrRGlyZWN0aXZlTWV0YS5zZXQoU29tZU90aGVyRGlyZWN0aXZlLCBuZXcgRGlyZWN0aXZlTWV0YWRhdGEoe1xuICAgICAgICAgICAgcHJvdmlkZXJzOiBbcHJvdmlkZSgnaW5qZWN0YWJsZTInLCB7dXNlVmFsdWU6ICdpbmplY3RhYmxlMid9KV1cbiAgICAgICAgICB9KSk7XG4gICAgICAgIHZhciBwZWwgPSBwcm90b0FwcEVsZW1lbnQoIDAsIFtcbiAgICAgICAgICBTaW1wbGVEaXJlY3RpdmUsXG4gICAgICAgICAgU29tZU90aGVyRGlyZWN0aXZlXG4gICAgICAgIF0pO1xuXG4gICAgICAgIGV4cGVjdChwZWwuZ2V0UHJvdmlkZXJBdEluZGV4KDApLmtleS50b2tlbikudG9CZShTaW1wbGVEaXJlY3RpdmUpO1xuICAgICAgICBleHBlY3QocGVsLmdldFByb3ZpZGVyQXRJbmRleCgxKS5rZXkudG9rZW4pLnRvQmUoU29tZU90aGVyRGlyZWN0aXZlKTtcbiAgICAgICAgZXhwZWN0KHBlbC5nZXRQcm92aWRlckF0SW5kZXgoMikua2V5LnRva2VuKS50b0VxdWFsKFwiaW5qZWN0YWJsZTFcIik7XG4gICAgICAgIGV4cGVjdChwZWwuZ2V0UHJvdmlkZXJBdEluZGV4KDMpLmtleS50b2tlbikudG9FcXVhbChcImluamVjdGFibGUyXCIpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KFwic2hvdWxkIGNvbGxlY3QgdmlldyBwcm92aWRlcnMgZnJvbSB0aGUgY29tcG9uZW50XCIsICgpID0+IHtcbiAgICAgICAgbW9ja0RpcmVjdGl2ZU1ldGEuc2V0KFNpbXBsZURpcmVjdGl2ZSwgbmV3IENvbXBvbmVudE1ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdQcm92aWRlcnM6IFtwcm92aWRlKCdpbmplY3RhYmxlMScsIHt1c2VWYWx1ZTogJ2luamVjdGFibGUxJ30pXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgdmFyIHBlbCA9IHByb3RvQXBwRWxlbWVudCgwLCBbU2ltcGxlRGlyZWN0aXZlXSk7XG5cbiAgICAgICAgZXhwZWN0KHBlbC5nZXRQcm92aWRlckF0SW5kZXgoMCkua2V5LnRva2VuKS50b0JlKFNpbXBsZURpcmVjdGl2ZSk7XG4gICAgICAgIGV4cGVjdChwZWwuZ2V0UHJvdmlkZXJBdEluZGV4KDEpLmtleS50b2tlbikudG9FcXVhbChcImluamVjdGFibGUxXCIpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KFwic2hvdWxkIGZsYXR0ZW4gbmVzdGVkIGFycmF5cyBpbiB2aWV3UHJvdmlkZXJzIGFuZCBwcm92aWRlcnNcIiwgKCkgPT4ge1xuICAgICAgICBtb2NrRGlyZWN0aXZlTWV0YS5zZXQoU2ltcGxlRGlyZWN0aXZlLCBuZXcgQ29tcG9uZW50TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgIHZpZXdQcm92aWRlcnM6IFtbW3Byb3ZpZGUoJ3ZpZXcnLCB7dXNlVmFsdWU6ICd2aWV3J30pXV1dLFxuICAgICAgICAgICAgICAgIHByb3ZpZGVyczogW1tbcHJvdmlkZSgnaG9zdCcsIHt1c2VWYWx1ZTogJ2hvc3QnfSldXV1cbiAgICAgICAgICAgICAgfSkpO1xuICAgICAgICB2YXIgcGVsID0gcHJvdG9BcHBFbGVtZW50KDAsIFtTaW1wbGVEaXJlY3RpdmVdKTtcblxuICAgICAgICBleHBlY3QocGVsLmdldFByb3ZpZGVyQXRJbmRleCgwKS5rZXkudG9rZW4pLnRvQmUoU2ltcGxlRGlyZWN0aXZlKTtcbiAgICAgICAgZXhwZWN0KHBlbC5nZXRQcm92aWRlckF0SW5kZXgoMSkua2V5LnRva2VuKS50b0VxdWFsKFwidmlld1wiKTtcbiAgICAgICAgZXhwZWN0KHBlbC5nZXRQcm92aWRlckF0SW5kZXgoMikua2V5LnRva2VuKS50b0VxdWFsKFwiaG9zdFwiKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHN1cHBvcnQgYW4gYXJiaXRyYXJ5IG51bWJlciBvZiBwcm92aWRlcnMnLCAoKSA9PiB7XG4gICAgICAgIHZhciBwZWwgPSBwcm90b0FwcEVsZW1lbnQoMCwgZHluYW1pY1N0cmF0ZWd5RGlyZWN0aXZlcyk7XG4gICAgICAgIGV4cGVjdChwZWwuZ2V0UHJvdmlkZXJBdEluZGV4KDApLmtleS50b2tlbikudG9CZShEMCk7XG4gICAgICAgIGV4cGVjdChwZWwuZ2V0UHJvdmlkZXJBdEluZGV4KDE5KS5rZXkudG9rZW4pLnRvQmUoRDE5KTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9KTtcblxuICBkZXNjcmliZShcIkFwcEVsZW1lbnRcIiwgKCkgPT4ge1xuICAgIGluaXQoKTtcblxuICAgIFt7IHN0cmF0ZWd5OiAnaW5saW5lJywgZGlyZWN0aXZlczogW10gfSwgeyBzdHJhdGVneTogJ2R5bmFtaWMnLFxuICAgICAgZGlyZWN0aXZlczogZHluYW1pY1N0cmF0ZWd5RGlyZWN0aXZlcyB9XS5mb3JFYWNoKChjb250ZXh0KSA9PiB7XG5cbiAgICAgIHZhciBleHRyYURpcmVjdGl2ZXMgPSBjb250ZXh0WydkaXJlY3RpdmVzJ107XG4gICAgICBkZXNjcmliZShgJHtjb250ZXh0WydzdHJhdGVneSddfSBzdHJhdGVneWAsICgpID0+IHtcblxuICAgICAgICBkZXNjcmliZShcImluamVjdGlvblwiLCAoKSA9PiB7XG4gICAgICAgICAgaXQoXCJzaG91bGQgaW5zdGFudGlhdGUgZGlyZWN0aXZlcyB0aGF0IGhhdmUgbm8gZGVwZW5kZW5jaWVzXCIsICgpID0+IHtcbiAgICAgICAgICAgIHZhciBkaXJlY3RpdmVzID0gTGlzdFdyYXBwZXIuY29uY2F0KFtTaW1wbGVEaXJlY3RpdmVdLCBleHRyYURpcmVjdGl2ZXMpO1xuICAgICAgICAgICAgdmFyIGVsID0gYXBwRWxlbWVudChudWxsLCBkaXJlY3RpdmVzKTtcbiAgICAgICAgICAgIGV4cGVjdChlbC5nZXQoU2ltcGxlRGlyZWN0aXZlKSkudG9CZUFuSW5zdGFuY2VPZihTaW1wbGVEaXJlY3RpdmUpO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgaXQoXCJzaG91bGQgaW5zdGFudGlhdGUgZGlyZWN0aXZlcyB0aGF0IGRlcGVuZCBvbiBhbiBhcmJpdHJhcnkgbnVtYmVyIG9mIGRpcmVjdGl2ZXNcIiwgKCkgPT4ge1xuICAgICAgICAgICAgdmFyIGRpcmVjdGl2ZXMgPSBMaXN0V3JhcHBlci5jb25jYXQoW1NpbXBsZURpcmVjdGl2ZSwgTmVlZHNEaXJlY3RpdmVdLCBleHRyYURpcmVjdGl2ZXMpO1xuICAgICAgICAgICAgdmFyIGVsID0gYXBwRWxlbWVudChudWxsLCBkaXJlY3RpdmVzKTtcblxuICAgICAgICAgICAgdmFyIGQgPSBlbC5nZXQoTmVlZHNEaXJlY3RpdmUpO1xuXG4gICAgICAgICAgICBleHBlY3QoZCkudG9CZUFuSW5zdGFuY2VPZihOZWVkc0RpcmVjdGl2ZSk7XG4gICAgICAgICAgICBleHBlY3QoZC5kZXBlbmRlbmN5KS50b0JlQW5JbnN0YW5jZU9mKFNpbXBsZURpcmVjdGl2ZSk7XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBpdChcInNob3VsZCBpbnN0YW50aWF0ZSBwcm92aWRlcnMgdGhhdCBoYXZlIGRlcGVuZGVuY2llcyB3aXRoIHNldCB2aXNpYmlsaXR5XCIsXG4gICAgICAgICAgICAgZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICBtb2NrRGlyZWN0aXZlTWV0YS5zZXQoU2ltcGxlRGlyZWN0aXZlLCBuZXcgQ29tcG9uZW50TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgcHJvdmlkZXJzOiBbcHJvdmlkZSgnaW5qZWN0YWJsZTEnLCB7dXNlVmFsdWU6ICdpbmplY3RhYmxlMSd9KV1cbiAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICBtb2NrRGlyZWN0aXZlTWV0YS5zZXQoU29tZU90aGVyRGlyZWN0aXZlLCBuZXcgQ29tcG9uZW50TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgcHJvdmlkZXJzOiBbXG4gICAgICAgICAgICAgICAgICAgIHByb3ZpZGUoJ2luamVjdGFibGUxJywge3VzZVZhbHVlOiduZXctaW5qZWN0YWJsZTEnfSksXG4gICAgICAgICAgICAgICAgICAgIHByb3ZpZGUoJ2luamVjdGFibGUyJywge3VzZUZhY3Rvcnk6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHZhbCkgPT4gYCR7dmFsfS1pbmplY3RhYmxlMmAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVwczogW1tuZXcgSW5qZWN0TWV0YWRhdGEoJ2luamVjdGFibGUxJyksIG5ldyBTa2lwU2VsZk1ldGFkYXRhKCldXX0pXG4gICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgdmFyIGNoaWxkSW5qID0gcGFyZW50Q2hpbGRFbGVtZW50cyhcbiAgICAgICAgICAgICAgICAgICBMaXN0V3JhcHBlci5jb25jYXQoW1NpbXBsZURpcmVjdGl2ZV0sIGV4dHJhRGlyZWN0aXZlcyksXG4gICAgICAgICAgICAgICAgICAgW1NvbWVPdGhlckRpcmVjdGl2ZV1cbiAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICBleHBlY3QoY2hpbGRJbmouZ2V0KCdpbmplY3RhYmxlMicpKS50b0VxdWFsKCdpbmplY3RhYmxlMS1pbmplY3RhYmxlMicpO1xuICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgaXQoXCJzaG91bGQgaW5zdGFudGlhdGUgcHJvdmlkZXJzIHRoYXQgaGF2ZSBkZXBlbmRlbmNpZXNcIiwgKCkgPT4ge1xuICAgICAgICAgICAgdmFyIHByb3ZpZGVycyA9IFtcbiAgICAgICAgICAgICAgICAgICAgcHJvdmlkZSgnaW5qZWN0YWJsZTEnLCB7dXNlVmFsdWU6ICdpbmplY3RhYmxlMSd9KSxcbiAgICAgICAgICAgICAgICAgICAgcHJvdmlkZSgnaW5qZWN0YWJsZTInLCB7dXNlRmFjdG9yeTpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAodmFsKSA9PiBgJHt2YWx9LWluamVjdGFibGUyYCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXBzOiBbJ2luamVjdGFibGUxJ119KVxuICAgICAgICAgICAgICAgICAgXTtcbiAgICAgICAgICAgIG1vY2tEaXJlY3RpdmVNZXRhLnNldChTaW1wbGVEaXJlY3RpdmUsIG5ldyBEaXJlY3RpdmVNZXRhZGF0YSh7cHJvdmlkZXJzOiBwcm92aWRlcnN9KSk7XG4gICAgICAgICAgICB2YXIgZWwgPSBhcHBFbGVtZW50KG51bGwsIExpc3RXcmFwcGVyLmNvbmNhdChcbiAgICAgICAgICAgICAgICBbU2ltcGxlRGlyZWN0aXZlXSwgZXh0cmFEaXJlY3RpdmVzKSk7XG5cbiAgICAgICAgICAgIGV4cGVjdChlbC5nZXQoJ2luamVjdGFibGUyJykpLnRvRXF1YWwoJ2luamVjdGFibGUxLWluamVjdGFibGUyJyk7XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBpdChcInNob3VsZCBpbnN0YW50aWF0ZSB2aWV3UHJvdmlkZXJzIHRoYXQgaGF2ZSBkZXBlbmRlbmNpZXNcIiwgKCkgPT4ge1xuICAgICAgICAgICAgdmFyIHZpZXdQcm92aWRlcnMgPSBbXG4gICAgICAgICAgICAgICAgICAgIHByb3ZpZGUoJ2luamVjdGFibGUxJywge3VzZVZhbHVlOiAnaW5qZWN0YWJsZTEnfSksXG4gICAgICAgICAgICAgICAgICAgIHByb3ZpZGUoJ2luamVjdGFibGUyJywge3VzZUZhY3Rvcnk6XG4gICAgICAgICAgICAgICAgICAgICAgKHZhbCkgPT4gYCR7dmFsfS1pbmplY3RhYmxlMmAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVwczogWydpbmplY3RhYmxlMSddfSlcbiAgICAgICAgICAgICAgICAgIF07XG5cbiAgICAgICAgICAgIG1vY2tEaXJlY3RpdmVNZXRhLnNldChTaW1wbGVEaXJlY3RpdmUsIG5ldyBDb21wb25lbnRNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICB2aWV3UHJvdmlkZXJzOiB2aWV3UHJvdmlkZXJzfSkpO1xuICAgICAgICAgICAgdmFyIGVsID0gYXBwRWxlbWVudChudWxsLCBMaXN0V3JhcHBlci5jb25jYXQoXG4gICAgICAgICAgICAgICAgW1NpbXBsZURpcmVjdGl2ZV0sIGV4dHJhRGlyZWN0aXZlcykpO1xuICAgICAgICAgICAgZXhwZWN0KGVsLmdldCgnaW5qZWN0YWJsZTInKSkudG9FcXVhbCgnaW5qZWN0YWJsZTEtaW5qZWN0YWJsZTInKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KFwic2hvdWxkIGluc3RhbnRpYXRlIGNvbXBvbmVudHMgdGhhdCBkZXBlbmQgb24gdmlld1Byb3ZpZGVycyBwcm92aWRlcnNcIiwgKCkgPT4ge1xuICAgICAgICAgICAgbW9ja0RpcmVjdGl2ZU1ldGEuc2V0KE5lZWRzU2VydmljZSwgbmV3IENvbXBvbmVudE1ldGFkYXRhKHtcbiAgICAgICAgICAgICAgdmlld1Byb3ZpZGVyczogW3Byb3ZpZGUoJ3NlcnZpY2UnLCB7dXNlVmFsdWU6ICdzZXJ2aWNlJ30pXVxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgdmFyIGVsID0gYXBwRWxlbWVudChudWxsLFxuICAgICAgICAgICAgICAgIExpc3RXcmFwcGVyLmNvbmNhdChbTmVlZHNTZXJ2aWNlXSwgZXh0cmFEaXJlY3RpdmVzKSk7XG4gICAgICAgICAgICBleHBlY3QoZWwuZ2V0KE5lZWRzU2VydmljZSkuc2VydmljZSkudG9FcXVhbCgnc2VydmljZScpO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgaXQoXCJzaG91bGQgaW5zdGFudGlhdGUgcHJvdmlkZXJzIGxhemlseVwiLCAoKSA9PiB7XG4gICAgICAgICAgICB2YXIgY3JlYXRlZCA9IGZhbHNlO1xuICAgICAgICAgICAgbW9ja0RpcmVjdGl2ZU1ldGEuc2V0KFNpbXBsZURpcmVjdGl2ZSwgbmV3IENvbXBvbmVudE1ldGFkYXRhKHtcbiAgICAgICAgICAgICAgcHJvdmlkZXJzOiBbcHJvdmlkZSgnc2VydmljZScsIHt1c2VGYWN0b3J5OiAoKSA9PiBjcmVhdGVkID0gdHJ1ZX0pXVxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgdmFyIGVsID0gYXBwRWxlbWVudChudWxsLFxuICAgICAgICAgICAgICAgIExpc3RXcmFwcGVyLmNvbmNhdChbU2ltcGxlRGlyZWN0aXZlXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXh0cmFEaXJlY3RpdmVzKSk7XG5cbiAgICAgICAgICAgIGV4cGVjdChjcmVhdGVkKS50b0JlKGZhbHNlKTtcblxuICAgICAgICAgICAgZWwuZ2V0KCdzZXJ2aWNlJyk7XG5cbiAgICAgICAgICAgIGV4cGVjdChjcmVhdGVkKS50b0JlKHRydWUpO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgaXQoXCJzaG91bGQgaW5zdGFudGlhdGUgdmlldyBwcm92aWRlcnMgbGF6aWx5XCIsICgpID0+IHtcbiAgICAgICAgICAgIHZhciBjcmVhdGVkID0gZmFsc2U7XG4gICAgICAgICAgICBtb2NrRGlyZWN0aXZlTWV0YS5zZXQoU2ltcGxlRGlyZWN0aXZlLCBuZXcgQ29tcG9uZW50TWV0YWRhdGEoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdQcm92aWRlcnM6IFtwcm92aWRlKCdzZXJ2aWNlJywge3VzZUZhY3Rvcnk6ICgpID0+IGNyZWF0ZWQgPSB0cnVlfSldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIHZhciBlbCA9IGFwcEVsZW1lbnQobnVsbCxcbiAgICAgICAgICAgICAgICBMaXN0V3JhcHBlci5jb25jYXQoW1NpbXBsZURpcmVjdGl2ZV0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4dHJhRGlyZWN0aXZlcykpO1xuXG4gICAgICAgICAgICBleHBlY3QoY3JlYXRlZCkudG9CZShmYWxzZSk7XG5cbiAgICAgICAgICAgIGVsLmdldCgnc2VydmljZScpO1xuXG4gICAgICAgICAgICBleHBlY3QoY3JlYXRlZCkudG9CZSh0cnVlKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KFwic2hvdWxkIG5vdCBpbnN0YW50aWF0ZSBvdGhlciBkaXJlY3RpdmVzIHRoYXQgZGVwZW5kIG9uIHZpZXdQcm92aWRlcnMgcHJvdmlkZXJzXCIsXG4gICAgICAgICAgICAgKCkgPT4ge1xuICAgICAgICAgICAgICAgbW9ja0RpcmVjdGl2ZU1ldGEuc2V0KFNpbXBsZURpcmVjdGl2ZSxcbiAgICAgICAgICAgICAgIG5ldyBDb21wb25lbnRNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgIHZpZXdQcm92aWRlcnM6IFtwcm92aWRlKFwic2VydmljZVwiLCB7dXNlVmFsdWU6IFwic2VydmljZVwifSldXG4gICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICBleHBlY3QoKCkgPT4geyBhcHBFbGVtZW50KG51bGwsIExpc3RXcmFwcGVyLmNvbmNhdChbU2ltcGxlRGlyZWN0aXZlLCBOZWVkc1NlcnZpY2VdLCBleHRyYURpcmVjdGl2ZXMpKTsgfSlcbiAgICAgICAgICAgICAgICAgICAudG9UaHJvd0Vycm9yKGNvbnRhaW5zUmVnZXhwKFxuICAgICAgICAgICAgICAgICAgICAgICBgTm8gcHJvdmlkZXIgZm9yIHNlcnZpY2UhICgke3N0cmluZ2lmeShOZWVkc1NlcnZpY2UpIH0gLT4gc2VydmljZSlgKSk7XG4gICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICBpdChcInNob3VsZCBpbnN0YW50aWF0ZSBkaXJlY3RpdmVzIHRoYXQgZGVwZW5kIG9uIHByb3ZpZGVycyBvZiBvdGhlciBkaXJlY3RpdmVzXCIsICgpID0+IHtcbiAgICAgICAgICAgIG1vY2tEaXJlY3RpdmVNZXRhLnNldChTaW1wbGVEaXJlY3RpdmUsIG5ldyBDb21wb25lbnRNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgcHJvdmlkZXJzOiBbcHJvdmlkZSgnc2VydmljZScsIHt1c2VWYWx1ZTogJ2hvc3RTZXJ2aWNlJ30pXX0pXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB2YXIgc2hhZG93SW5qID0gaG9zdFNoYWRvd0VsZW1lbnQoXG4gICAgICAgICAgICAgICAgTGlzdFdyYXBwZXIuY29uY2F0KFtTaW1wbGVEaXJlY3RpdmVdLCBleHRyYURpcmVjdGl2ZXMpLFxuICAgICAgICAgICAgICAgIExpc3RXcmFwcGVyLmNvbmNhdChbTmVlZHNTZXJ2aWNlXSwgZXh0cmFEaXJlY3RpdmVzKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGV4cGVjdChzaGFkb3dJbmouZ2V0KE5lZWRzU2VydmljZSkuc2VydmljZSkudG9FcXVhbCgnaG9zdFNlcnZpY2UnKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KFwic2hvdWxkIGluc3RhbnRpYXRlIGRpcmVjdGl2ZXMgdGhhdCBkZXBlbmQgb24gdmlldyBwcm92aWRlcnMgb2YgYSBjb21wb25lbnRcIiwgKCkgPT4ge1xuICAgICAgICAgICAgbW9ja0RpcmVjdGl2ZU1ldGEuc2V0KFNpbXBsZURpcmVjdGl2ZSwgbmV3IENvbXBvbmVudE1ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICB2aWV3UHJvdmlkZXJzOiBbcHJvdmlkZSgnc2VydmljZScsIHt1c2VWYWx1ZTogJ2hvc3RTZXJ2aWNlJ30pXX0pXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB2YXIgc2hhZG93SW5qID0gaG9zdFNoYWRvd0VsZW1lbnQoXG4gICAgICAgICAgICAgICAgTGlzdFdyYXBwZXIuY29uY2F0KFtTaW1wbGVEaXJlY3RpdmVdLCBleHRyYURpcmVjdGl2ZXMpLFxuICAgICAgICAgICAgICAgIExpc3RXcmFwcGVyLmNvbmNhdChbTmVlZHNTZXJ2aWNlXSwgZXh0cmFEaXJlY3RpdmVzKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGV4cGVjdChzaGFkb3dJbmouZ2V0KE5lZWRzU2VydmljZSkuc2VydmljZSkudG9FcXVhbCgnaG9zdFNlcnZpY2UnKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KFwic2hvdWxkIGluc3RhbnRpYXRlIGRpcmVjdGl2ZXMgaW4gYSByb290IGVtYmVkZGVkIHZpZXcgdGhhdCBkZXBlbmQgb24gdmlldyBwcm92aWRlcnMgb2YgYSBjb21wb25lbnRcIiwgKCkgPT4ge1xuICAgICAgICAgICAgbW9ja0RpcmVjdGl2ZU1ldGEuc2V0KFNpbXBsZURpcmVjdGl2ZSwgbmV3IENvbXBvbmVudE1ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICB2aWV3UHJvdmlkZXJzOiBbcHJvdmlkZSgnc2VydmljZScsIHt1c2VWYWx1ZTogJ2hvc3RTZXJ2aWNlJ30pXX0pXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB2YXIgaG9zdCA9IGFwcEVsZW1lbnQobnVsbCwgTGlzdFdyYXBwZXIuY29uY2F0KFtTaW1wbGVEaXJlY3RpdmVdLCBleHRyYURpcmVjdGl2ZXMpKTtcbiAgICAgICAgICAgIHZhciBjb21wb25lbmV0VmlldyA9IGNyZWF0ZVZpZXcoVmlld1R5cGUuQ09NUE9ORU5ULCBob3N0KTtcbiAgICAgICAgICAgIGhvc3QuYXR0YWNoQ29tcG9uZW50Vmlldyhjb21wb25lbmV0Vmlldyk7XG5cbiAgICAgICAgICAgIHZhciBhbmNob3IgPSBhcHBFbGVtZW50KG51bGwsIFtdLCBjb21wb25lbmV0Vmlldyk7XG4gICAgICAgICAgICB2YXIgZW1iZWRkZWRWaWV3ID0gY3JlYXRlVmlldyhWaWV3VHlwZS5FTUJFRERFRCwgYW5jaG9yKTtcblxuICAgICAgICAgICAgdmFyIHJvb3RFbWJlZGRlZEVsID0gYXBwRWxlbWVudChudWxsLCBMaXN0V3JhcHBlci5jb25jYXQoW05lZWRzU2VydmljZV0sIGV4dHJhRGlyZWN0aXZlcyksIGVtYmVkZGVkVmlldyk7XG4gICAgICAgICAgICBleHBlY3Qocm9vdEVtYmVkZGVkRWwuZ2V0KE5lZWRzU2VydmljZSkuc2VydmljZSkudG9FcXVhbCgnaG9zdFNlcnZpY2UnKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KFwic2hvdWxkIGluc3RhbnRpYXRlIGRpcmVjdGl2ZXMgdGhhdCBkZXBlbmQgb24gaW1wZXJhdGl2ZWx5IGNyZWF0ZWQgaW5qZWN0b3IgKGJvb3RzdHJhcClcIiwgKCkgPT4ge1xuICAgICAgICAgICAgdmFyIHJvb3RJbmplY3RvciA9IEluamVjdG9yLnJlc29sdmVBbmRDcmVhdGUoW1xuICAgICAgICAgICAgICBwcm92aWRlKFwic2VydmljZVwiLCB7dXNlVmFsdWU6ICdhcHBTZXJ2aWNlJ30pXG4gICAgICAgICAgICBdKTtcbiAgICAgICAgICAgIHZhciB2aWV3ID0gY3JlYXRlVmlldyhWaWV3VHlwZS5IT1NULCBudWxsLCBudWxsLCByb290SW5qZWN0b3IpO1xuICAgICAgICAgICAgZXhwZWN0KGFwcEVsZW1lbnQobnVsbCwgW05lZWRzU2VydmljZV0sIHZpZXcpLmdldChOZWVkc1NlcnZpY2UpLnNlcnZpY2UpLnRvRXF1YWwoJ2FwcFNlcnZpY2UnKTtcblxuICAgICAgICAgICAgZXhwZWN0KCgpID0+IGFwcEVsZW1lbnQobnVsbCwgW05lZWRzU2VydmljZUZyb21Ib3N0XSwgdmlldykpLnRvVGhyb3dFcnJvcigpO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgaXQoXCJzaG91bGQgaW5zdGFudGlhdGUgZGlyZWN0aXZlcyB0aGF0IGRlcGVuZCBvbiBpbXBlcmF0aXZlbHkgY3JlYXRlZCBwcm92aWRlcnMgKHJvb3QgaW5qZWN0b3IpXCIsICgpID0+IHtcbiAgICAgICAgICAgIHZhciBpbXBlcmF0aXZlbHlDcmVhdGVkUHJvdmlkZXJzID0gSW5qZWN0b3IucmVzb2x2ZShbXG4gICAgICAgICAgICAgIHByb3ZpZGUoXCJzZXJ2aWNlXCIsIHt1c2VWYWx1ZTogJ2FwcFNlcnZpY2UnfSlcbiAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgdmFyIGNvbnRhaW5lckFwcEVsZW1lbnQgPSBhcHBFbGVtZW50KG51bGwsIFtdKTtcbiAgICAgICAgICAgIHZhciB2aWV3ID0gY3JlYXRlVmlldyhWaWV3VHlwZS5IT1NULCBjb250YWluZXJBcHBFbGVtZW50LCBpbXBlcmF0aXZlbHlDcmVhdGVkUHJvdmlkZXJzLCBudWxsKTtcbiAgICAgICAgICAgIGV4cGVjdChhcHBFbGVtZW50KG51bGwsIFtOZWVkc1NlcnZpY2VdLCB2aWV3KS5nZXQoTmVlZHNTZXJ2aWNlKS5zZXJ2aWNlKS50b0VxdWFsKCdhcHBTZXJ2aWNlJyk7XG4gICAgICAgICAgICBleHBlY3QoYXBwRWxlbWVudChudWxsLCBbTmVlZHNTZXJ2aWNlRnJvbUhvc3RdLCB2aWV3KS5nZXQoTmVlZHNTZXJ2aWNlRnJvbUhvc3QpLnNlcnZpY2UpLnRvRXF1YWwoJ2FwcFNlcnZpY2UnKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KFwic2hvdWxkIG5vdCBpbnN0YW50aWF0ZSBhIGRpcmVjdGl2ZSBpbiBhIHZpZXcgdGhhdCBoYXMgYSBob3N0IGRlcGVuZGVuY3kgb24gcHJvdmlkZXJzXCIrXG4gICAgICAgICAgICBcIiBvZiB0aGUgY29tcG9uZW50XCIsICgpID0+IHtcbiAgICAgICAgICAgIG1vY2tEaXJlY3RpdmVNZXRhLnNldChTb21lT3RoZXJEaXJlY3RpdmUsIG5ldyBEaXJlY3RpdmVNZXRhZGF0YSh7XG4gICAgICAgICAgICAgICAgICAgIHByb3ZpZGVyczogW3Byb3ZpZGUoJ3NlcnZpY2UnLCB7dXNlVmFsdWU6ICdob3N0U2VydmljZSd9KV19KVxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICBleHBlY3QoKCkgPT4ge1xuICAgICAgICAgICAgICBob3N0U2hhZG93RWxlbWVudChcbiAgICAgICAgICAgICAgICBMaXN0V3JhcHBlci5jb25jYXQoW1NvbWVPdGhlckRpcmVjdGl2ZV0sIGV4dHJhRGlyZWN0aXZlcyksXG4gICAgICAgICAgICAgICAgTGlzdFdyYXBwZXIuY29uY2F0KFtOZWVkc1NlcnZpY2VGcm9tSG9zdF0sIGV4dHJhRGlyZWN0aXZlcylcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pLnRvVGhyb3dFcnJvcihuZXcgUmVnRXhwKFwiTm8gcHJvdmlkZXIgZm9yIHNlcnZpY2UhXCIpKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KFwic2hvdWxkIG5vdCBpbnN0YW50aWF0ZSBhIGRpcmVjdGl2ZSBpbiBhIHZpZXcgdGhhdCBoYXMgYSBob3N0IGRlcGVuZGVuY3kgb24gcHJvdmlkZXJzXCIrXG4gICAgICAgICAgICBcIiBvZiBhIGRlY29yYXRvciBkaXJlY3RpdmVcIiwgKCkgPT4ge1xuICAgICAgICAgICAgbW9ja0RpcmVjdGl2ZU1ldGEuc2V0KFNvbWVPdGhlckRpcmVjdGl2ZSwgbmV3IERpcmVjdGl2ZU1ldGFkYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICBwcm92aWRlcnM6IFtwcm92aWRlKCdzZXJ2aWNlJywge3VzZVZhbHVlOiAnaG9zdFNlcnZpY2UnfSldfSkpO1xuICAgICAgICAgICAgZXhwZWN0KCgpID0+IHtcbiAgICAgICAgICAgICAgaG9zdFNoYWRvd0VsZW1lbnQoXG4gICAgICAgICAgICAgICAgTGlzdFdyYXBwZXIuY29uY2F0KFtTaW1wbGVEaXJlY3RpdmUsIFNvbWVPdGhlckRpcmVjdGl2ZV0sIGV4dHJhRGlyZWN0aXZlcyksXG4gICAgICAgICAgICAgICAgTGlzdFdyYXBwZXIuY29uY2F0KFtOZWVkc1NlcnZpY2VGcm9tSG9zdF0sIGV4dHJhRGlyZWN0aXZlcylcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pLnRvVGhyb3dFcnJvcihuZXcgUmVnRXhwKFwiTm8gcHJvdmlkZXIgZm9yIHNlcnZpY2UhXCIpKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KFwic2hvdWxkIGdldCBkaXJlY3RpdmVzXCIsICgpID0+IHtcbiAgICAgICAgICAgIHZhciBjaGlsZCA9IGhvc3RTaGFkb3dFbGVtZW50KFxuICAgICAgICAgICAgICAgIExpc3RXcmFwcGVyLmNvbmNhdChbU29tZU90aGVyRGlyZWN0aXZlLCBTaW1wbGVEaXJlY3RpdmVdLCBleHRyYURpcmVjdGl2ZXMpLFxuICAgICAgICAgICAgICAgIFtOZWVkc0RpcmVjdGl2ZUZyb21Ib3N0U2hhZG93RG9tXSk7XG5cbiAgICAgICAgICAgIHZhciBkID0gY2hpbGQuZ2V0KE5lZWRzRGlyZWN0aXZlRnJvbUhvc3RTaGFkb3dEb20pO1xuXG4gICAgICAgICAgICBleHBlY3QoZCkudG9CZUFuSW5zdGFuY2VPZihOZWVkc0RpcmVjdGl2ZUZyb21Ib3N0U2hhZG93RG9tKTtcbiAgICAgICAgICAgIGV4cGVjdChkLmRlcGVuZGVuY3kpLnRvQmVBbkluc3RhbmNlT2YoU2ltcGxlRGlyZWN0aXZlKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KFwic2hvdWxkIGdldCBkaXJlY3RpdmVzIGZyb20gdGhlIGhvc3RcIiwgKCkgPT4ge1xuICAgICAgICAgICAgdmFyIGNoaWxkID0gcGFyZW50Q2hpbGRFbGVtZW50cyhMaXN0V3JhcHBlci5jb25jYXQoW1NpbXBsZURpcmVjdGl2ZV0sIGV4dHJhRGlyZWN0aXZlcyksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbTmVlZWRzRGlyZWN0aXZlRnJvbUhvc3RdKTtcblxuICAgICAgICAgICAgdmFyIGQgPSBjaGlsZC5nZXQoTmVlZWRzRGlyZWN0aXZlRnJvbUhvc3QpO1xuXG4gICAgICAgICAgICBleHBlY3QoZCkudG9CZUFuSW5zdGFuY2VPZihOZWVlZHNEaXJlY3RpdmVGcm9tSG9zdCk7XG4gICAgICAgICAgICBleHBlY3QoZC5kZXBlbmRlbmN5KS50b0JlQW5JbnN0YW5jZU9mKFNpbXBsZURpcmVjdGl2ZSk7XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBpdChcInNob3VsZCB0aHJvdyB3aGVuIGEgZGVwZW5kZW5jeSBjYW5ub3QgYmUgcmVzb2x2ZWRcIiwgKCkgPT4ge1xuICAgICAgICAgICAgZXhwZWN0KCgpID0+IGFwcEVsZW1lbnQobnVsbCwgTGlzdFdyYXBwZXIuY29uY2F0KFtOZWVlZHNEaXJlY3RpdmVGcm9tSG9zdF0sIGV4dHJhRGlyZWN0aXZlcykpKVxuICAgICAgICAgICAgICAgIC50b1Rocm93RXJyb3IoY29udGFpbnNSZWdleHAoXG4gICAgICAgICAgICAgICAgICAgIGBObyBwcm92aWRlciBmb3IgJHtzdHJpbmdpZnkoU2ltcGxlRGlyZWN0aXZlKSB9ISAoJHtzdHJpbmdpZnkoTmVlZWRzRGlyZWN0aXZlRnJvbUhvc3QpIH0gLT4gJHtzdHJpbmdpZnkoU2ltcGxlRGlyZWN0aXZlKSB9KWApKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KFwic2hvdWxkIGluamVjdCBudWxsIHdoZW4gYW4gb3B0aW9uYWwgZGVwZW5kZW5jeSBjYW5ub3QgYmUgcmVzb2x2ZWRcIiwgKCkgPT4ge1xuICAgICAgICAgICAgdmFyIGVsID0gYXBwRWxlbWVudChudWxsLCBMaXN0V3JhcHBlci5jb25jYXQoW09wdGlvbmFsbHlOZWVkc0RpcmVjdGl2ZV0sIGV4dHJhRGlyZWN0aXZlcykpO1xuICAgICAgICAgICAgdmFyIGQgPSBlbC5nZXQoT3B0aW9uYWxseU5lZWRzRGlyZWN0aXZlKTtcbiAgICAgICAgICAgIGV4cGVjdChkLmRlcGVuZGVuY3kpLnRvRXF1YWwobnVsbCk7XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBpdChcInNob3VsZCBhbGxvdyBmb3IgZGlyZWN0IGFjY2VzcyB1c2luZyBnZXREaXJlY3RpdmVBdEluZGV4XCIsICgpID0+IHtcbiAgICAgICAgICAgIHZhciBwcm92aWRlcnMgPVxuICAgICAgICAgICAgICAgIExpc3RXcmFwcGVyLmNvbmNhdChbU2ltcGxlRGlyZWN0aXZlXSwgZXh0cmFEaXJlY3RpdmVzKTtcblxuICAgICAgICAgICAgdmFyIGVsID0gYXBwRWxlbWVudChudWxsLCBwcm92aWRlcnMpO1xuXG4gICAgICAgICAgICB2YXIgZmlyc0luZGV4T3V0ID0gcHJvdmlkZXJzLmxlbmd0aCA+IDEwID8gcHJvdmlkZXJzLmxlbmd0aCA6IDEwO1xuXG4gICAgICAgICAgICBleHBlY3QoZWwuZ2V0RGlyZWN0aXZlQXRJbmRleCgwKSkudG9CZUFuSW5zdGFuY2VPZihTaW1wbGVEaXJlY3RpdmUpO1xuICAgICAgICAgICAgZXhwZWN0KCgpID0+IGVsLmdldERpcmVjdGl2ZUF0SW5kZXgoLTEpKS50b1Rocm93RXJyb3IoJ0luZGV4IC0xIGlzIG91dC1vZi1ib3VuZHMuJyk7XG4gICAgICAgICAgICBleHBlY3QoKCkgPT4gZWwuZ2V0RGlyZWN0aXZlQXRJbmRleChmaXJzSW5kZXhPdXQpKVxuICAgICAgICAgICAgICAgIC50b1Rocm93RXJyb3IoYEluZGV4ICR7Zmlyc0luZGV4T3V0fSBpcyBvdXQtb2YtYm91bmRzLmApO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgaXQoXCJzaG91bGQgaW5zdGFudGlhdGUgZGlyZWN0aXZlcyB0aGF0IGRlcGVuZCBvbiB0aGUgY29udGFpbmluZyBjb21wb25lbnRcIiwgKCkgPT4ge1xuICAgICAgICAgICAgbW9ja0RpcmVjdGl2ZU1ldGEuc2V0KFNpbXBsZURpcmVjdGl2ZSwgbmV3IENvbXBvbmVudE1ldGFkYXRhKCkpO1xuICAgICAgICAgICAgdmFyIHNoYWRvdyA9IGhvc3RTaGFkb3dFbGVtZW50KExpc3RXcmFwcGVyLmNvbmNhdChbU2ltcGxlRGlyZWN0aXZlXSwgZXh0cmFEaXJlY3RpdmVzKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtOZWVlZHNEaXJlY3RpdmVGcm9tSG9zdF0pO1xuXG4gICAgICAgICAgICB2YXIgZCA9IHNoYWRvdy5nZXQoTmVlZWRzRGlyZWN0aXZlRnJvbUhvc3QpO1xuICAgICAgICAgICAgZXhwZWN0KGQpLnRvQmVBbkluc3RhbmNlT2YoTmVlZWRzRGlyZWN0aXZlRnJvbUhvc3QpO1xuICAgICAgICAgICAgZXhwZWN0KGQuZGVwZW5kZW5jeSkudG9CZUFuSW5zdGFuY2VPZihTaW1wbGVEaXJlY3RpdmUpO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgaXQoXCJzaG91bGQgbm90IGluc3RhbnRpYXRlIGRpcmVjdGl2ZXMgdGhhdCBkZXBlbmQgb24gb3RoZXIgZGlyZWN0aXZlcyBpbiB0aGUgY29udGFpbmluZyBjb21wb25lbnQncyBFbGVtZW50SW5qZWN0b3JcIixcbiAgICAgICAgICAgICAoKSA9PiB7XG4gICAgICAgICAgICAgICBtb2NrRGlyZWN0aXZlTWV0YS5zZXQoU29tZU90aGVyRGlyZWN0aXZlLCBuZXcgQ29tcG9uZW50TWV0YWRhdGEoKSk7XG4gICAgICAgICAgICAgICBleHBlY3QoKCkgPT5cbiAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBob3N0U2hhZG93RWxlbWVudChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBMaXN0V3JhcHBlci5jb25jYXQoW1NvbWVPdGhlckRpcmVjdGl2ZSwgU2ltcGxlRGlyZWN0aXZlXSwgZXh0cmFEaXJlY3RpdmVzKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbTmVlZHNEaXJlY3RpdmVdKTtcbiAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgIC50b1Rocm93RXJyb3IoY29udGFpbnNSZWdleHAoXG4gICAgICAgICAgICAgICAgICAgICAgIGBObyBwcm92aWRlciBmb3IgJHtzdHJpbmdpZnkoU2ltcGxlRGlyZWN0aXZlKSB9ISAoJHtzdHJpbmdpZnkoTmVlZHNEaXJlY3RpdmUpIH0gLT4gJHtzdHJpbmdpZnkoU2ltcGxlRGlyZWN0aXZlKSB9KWApKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgZGVzY3JpYmUoJ3N0YXRpYyBhdHRyaWJ1dGVzJywgKCkgPT4ge1xuICAgICAgICAgIGl0KCdzaG91bGQgYmUgaW5qZWN0YWJsZScsICgpID0+IHtcbiAgICAgICAgICAgIHZhciBlbCA9IGFwcEVsZW1lbnQobnVsbCwgTGlzdFdyYXBwZXIuY29uY2F0KFtOZWVkc0F0dHJpYnV0ZV0sIGV4dHJhRGlyZWN0aXZlcyksIG51bGwsIG51bGwsIHtcbiAgICAgICAgICAgICAgJ3R5cGUnOiAndGV4dCcsXG4gICAgICAgICAgICAgICd0aXRsZSc6ICcnXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHZhciBuZWVkc0F0dHJpYnV0ZSA9IGVsLmdldChOZWVkc0F0dHJpYnV0ZSk7XG5cbiAgICAgICAgICAgIGV4cGVjdChuZWVkc0F0dHJpYnV0ZS50eXBlQXR0cmlidXRlKS50b0VxdWFsKCd0ZXh0Jyk7XG4gICAgICAgICAgICBleHBlY3QobmVlZHNBdHRyaWJ1dGUudGl0bGVBdHRyaWJ1dGUpLnRvRXF1YWwoJycpO1xuICAgICAgICAgICAgZXhwZWN0KG5lZWRzQXR0cmlidXRlLmZvb0F0dHJpYnV0ZSkudG9FcXVhbChudWxsKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KCdzaG91bGQgYmUgaW5qZWN0YWJsZSB3aXRob3V0IHR5cGUgYW5ub3RhdGlvbicsICgpID0+IHtcbiAgICAgICAgICAgIHZhciBlbCA9IGFwcEVsZW1lbnQobnVsbCwgTGlzdFdyYXBwZXIuY29uY2F0KFtOZWVkc0F0dHJpYnV0ZU5vVHlwZV0sIGV4dHJhRGlyZWN0aXZlcyksIG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVsbCwgeydmb28nOiAnYmFyJ30pO1xuICAgICAgICAgICAgdmFyIG5lZWRzQXR0cmlidXRlID0gZWwuZ2V0KE5lZWRzQXR0cmlidXRlTm9UeXBlKTtcblxuICAgICAgICAgICAgZXhwZWN0KG5lZWRzQXR0cmlidXRlLmZvb0F0dHJpYnV0ZSkudG9FcXVhbCgnYmFyJyk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGRlc2NyaWJlKFwicmVmc1wiLCAoKSA9PiB7XG4gICAgICAgICAgaXQoXCJzaG91bGQgaW5qZWN0IEVsZW1lbnRSZWZcIiwgKCkgPT4ge1xuICAgICAgICAgICAgdmFyIGVsID0gYXBwRWxlbWVudChudWxsLCBMaXN0V3JhcHBlci5jb25jYXQoW05lZWRzRWxlbWVudFJlZl0sIGV4dHJhRGlyZWN0aXZlcykpO1xuICAgICAgICAgICAgZXhwZWN0KGVsLmdldChOZWVkc0VsZW1lbnRSZWYpLmVsZW1lbnRSZWYpLnRvQmUoZWwucmVmKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KFwic2hvdWxkIGluamVjdCBDaGFuZ2VEZXRlY3RvclJlZiBvZiB0aGUgY29tcG9uZW50J3MgdmlldyBpbnRvIHRoZSBjb21wb25lbnQgdmlhIGEgcHJveHlcIiwgKCkgPT4ge1xuICAgICAgICAgICAgbW9ja0RpcmVjdGl2ZU1ldGEuc2V0KENvbXBvbmVudE5lZWRzQ2hhbmdlRGV0ZWN0b3JSZWYsIG5ldyBDb21wb25lbnRNZXRhZGF0YSgpKTtcbiAgICAgICAgICAgIHZhciBob3N0ID0gYXBwRWxlbWVudChudWxsLCBMaXN0V3JhcHBlci5jb25jYXQoW0NvbXBvbmVudE5lZWRzQ2hhbmdlRGV0ZWN0b3JSZWZdLCBleHRyYURpcmVjdGl2ZXMpKTtcbiAgICAgICAgICAgIHZhciB2aWV3ID0gY3JlYXRlVmlldyhWaWV3VHlwZS5DT01QT05FTlQsIGhvc3QpO1xuICAgICAgICAgICAgaG9zdC5hdHRhY2hDb21wb25lbnRWaWV3KHZpZXcpO1xuICAgICAgICAgICAgaG9zdC5nZXQoQ29tcG9uZW50TmVlZHNDaGFuZ2VEZXRlY3RvclJlZikuY2hhbmdlRGV0ZWN0b3JSZWYubWFya0ZvckNoZWNrKCk7XG4gICAgICAgICAgICBleHBlY3QoKDxhbnk+dmlldy5jaGFuZ2VEZXRlY3Rvcikuc3B5KCdtYXJrUGF0aFRvUm9vdEFzQ2hlY2tPbmNlJykpLnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KFwic2hvdWxkIGluamVjdCBDaGFuZ2VEZXRlY3RvclJlZiBvZiB0aGUgY29udGFpbmluZyBjb21wb25lbnQgaW50byBkaXJlY3RpdmVzXCIsICgpID0+IHtcbiAgICAgICAgICAgIG1vY2tEaXJlY3RpdmVNZXRhLnNldChEaXJlY3RpdmVOZWVkc0NoYW5nZURldGVjdG9yUmVmLCBuZXcgRGlyZWN0aXZlTWV0YWRhdGEoKSk7XG4gICAgICAgICAgICB2YXIgdmlldyA9IGNyZWF0ZVZpZXcoVmlld1R5cGUuSE9TVCk7XG4gICAgICAgICAgICB2YXIgZWwgPSBhcHBFbGVtZW50KG51bGwsIExpc3RXcmFwcGVyLmNvbmNhdChbRGlyZWN0aXZlTmVlZHNDaGFuZ2VEZXRlY3RvclJlZl0sIGV4dHJhRGlyZWN0aXZlcyksIHZpZXcpO1xuICAgICAgICAgICAgZXhwZWN0KGVsLmdldChEaXJlY3RpdmVOZWVkc0NoYW5nZURldGVjdG9yUmVmKS5jaGFuZ2VEZXRlY3RvclJlZikudG9CZSh2aWV3LmNoYW5nZURldGVjdG9yLnJlZik7XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBpdCgnc2hvdWxkIGluamVjdCBWaWV3Q29udGFpbmVyUmVmJywgKCkgPT4ge1xuICAgICAgICAgICAgdmFyIGVsID0gYXBwRWxlbWVudChudWxsLCBMaXN0V3JhcHBlci5jb25jYXQoW05lZWRzVmlld0NvbnRhaW5lcl0sIGV4dHJhRGlyZWN0aXZlcykpO1xuICAgICAgICAgICAgZXhwZWN0KGVsLmdldChOZWVkc1ZpZXdDb250YWluZXIpLnZpZXdDb250YWluZXIpLnRvQmVBbkluc3RhbmNlT2YoVmlld0NvbnRhaW5lclJlZl8pO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgaXQoXCJzaG91bGQgaW5qZWN0IFRlbXBsYXRlUmVmXCIsICgpID0+IHtcbiAgICAgICAgICAgIHZhciBlbCA9IGFwcEVsZW1lbnQobnVsbCwgTGlzdFdyYXBwZXIuY29uY2F0KFtOZWVkc1RlbXBsYXRlUmVmXSwgZXh0cmFEaXJlY3RpdmVzKSwgbnVsbCwgZHVtbXlWaWV3RmFjdG9yeSk7XG4gICAgICAgICAgICBleHBlY3QoZWwuZ2V0KE5lZWRzVGVtcGxhdGVSZWYpLnRlbXBsYXRlUmVmLmVsZW1lbnRSZWYpLnRvQmUoZWwucmVmKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KFwic2hvdWxkIHRocm93IGlmIHRoZXJlIGlzIG5vIFRlbXBsYXRlUmVmXCIsICgpID0+IHtcbiAgICAgICAgICAgIGV4cGVjdCgoKSA9PiBhcHBFbGVtZW50KG51bGwsIExpc3RXcmFwcGVyLmNvbmNhdChbTmVlZHNUZW1wbGF0ZVJlZl0sIGV4dHJhRGlyZWN0aXZlcykpKVxuICAgICAgICAgICAgICAgIC50b1Rocm93RXJyb3IoXG4gICAgICAgICAgICAgICAgICAgIGBObyBwcm92aWRlciBmb3IgVGVtcGxhdGVSZWYhICgke3N0cmluZ2lmeShOZWVkc1RlbXBsYXRlUmVmKSB9IC0+IFRlbXBsYXRlUmVmKWApO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgaXQoJ3Nob3VsZCBpbmplY3QgbnVsbCBpZiB0aGVyZSBpcyBubyBUZW1wbGF0ZVJlZiB3aGVuIHRoZSBkZXBlbmRlbmN5IGlzIG9wdGlvbmFsJywgKCkgPT4ge1xuICAgICAgICAgICAgdmFyIGVsID0gYXBwRWxlbWVudChudWxsLCBMaXN0V3JhcHBlci5jb25jYXQoW09wdGlvbmFsbHlJbmplY3RzVGVtcGxhdGVSZWZdLCBleHRyYURpcmVjdGl2ZXMpKTtcbiAgICAgICAgICAgIHZhciBpbnN0YW5jZSA9IGVsLmdldChPcHRpb25hbGx5SW5qZWN0c1RlbXBsYXRlUmVmKTtcbiAgICAgICAgICAgIGV4cGVjdChpbnN0YW5jZS50ZW1wbGF0ZVJlZikudG9CZU51bGwoKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgZGVzY3JpYmUoJ3F1ZXJpZXMnLCAoKSA9PiB7XG4gICAgICAgICAgZnVuY3Rpb24gZXhwZWN0RGlyZWN0aXZlcyhxdWVyeTogUXVlcnlMaXN0PGFueT4sIHR5cGUsIGV4cGVjdGVkSW5kZXgpIHtcbiAgICAgICAgICAgIHZhciBjdXJyZW50Q291bnQgPSAwO1xuICAgICAgICAgICAgZXhwZWN0KHF1ZXJ5Lmxlbmd0aCkudG9FcXVhbChleHBlY3RlZEluZGV4Lmxlbmd0aCk7XG4gICAgICAgICAgICBpdGVyYXRlTGlzdExpa2UocXVlcnksIChpKSA9PiB7XG4gICAgICAgICAgICAgIGV4cGVjdChpKS50b0JlQW5JbnN0YW5jZU9mKHR5cGUpO1xuICAgICAgICAgICAgICBleHBlY3QoaS5jb3VudCkudG9CZShleHBlY3RlZEluZGV4W2N1cnJlbnRDb3VudF0pO1xuICAgICAgICAgICAgICBjdXJyZW50Q291bnQgKz0gMTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGl0KCdzaG91bGQgYmUgaW5qZWN0YWJsZScsICgpID0+IHtcbiAgICAgICAgICAgIHZhciBlbCA9XG4gICAgICAgICAgICAgICAgYXBwRWxlbWVudChudWxsLCBMaXN0V3JhcHBlci5jb25jYXQoW05lZWRzUXVlcnldLCBleHRyYURpcmVjdGl2ZXMpKTtcbiAgICAgICAgICAgIGV4cGVjdChlbC5nZXQoTmVlZHNRdWVyeSkucXVlcnkpLnRvQmVBbkluc3RhbmNlT2YoUXVlcnlMaXN0KTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KCdzaG91bGQgY29udGFpbiBkaXJlY3RpdmVzIG9uIHRoZSBzYW1lIGluamVjdG9yJywgKCkgPT4ge1xuICAgICAgICAgICAgdmFyIGVsID0gYXBwRWxlbWVudChudWxsLCBMaXN0V3JhcHBlci5jb25jYXQoW1xuICAgICAgICAgICAgICAgIE5lZWRzUXVlcnksXG4gICAgICAgICAgICAgICAgQ291bnRpbmdEaXJlY3RpdmVcbiAgICAgICAgICAgICAgXSwgZXh0cmFEaXJlY3RpdmVzKSk7XG5cbiAgICAgICAgICAgIGVsLm5nQWZ0ZXJDb250ZW50Q2hlY2tlZCgpO1xuXG4gICAgICAgICAgICBleHBlY3REaXJlY3RpdmVzKGVsLmdldChOZWVkc1F1ZXJ5KS5xdWVyeSwgQ291bnRpbmdEaXJlY3RpdmUsIFswXSk7XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBpdCgnc2hvdWxkIGNvbnRhaW4gVGVtcGxhdGVSZWZzIG9uIHRoZSBzYW1lIGluamVjdG9yJywgKCkgPT4ge1xuICAgICAgICAgICAgdmFyIGVsID0gYXBwRWxlbWVudChudWxsLCBMaXN0V3JhcHBlci5jb25jYXQoW1xuICAgICAgICAgICAgICAgIE5lZWRzVGVtcGxhdGVSZWZRdWVyeVxuICAgICAgICAgICAgICBdLCBleHRyYURpcmVjdGl2ZXMpLCBudWxsLCBkdW1teVZpZXdGYWN0b3J5KTtcblxuICAgICAgICAgICAgZWwubmdBZnRlckNvbnRlbnRDaGVja2VkKCk7XG5cbiAgICAgICAgICAgIGV4cGVjdChlbC5nZXQoTmVlZHNUZW1wbGF0ZVJlZlF1ZXJ5KS5xdWVyeS5maXJzdCkudG9CZUFuSW5zdGFuY2VPZihUZW1wbGF0ZVJlZl8pO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgaXQoJ3Nob3VsZCBjb250YWluIHRoZSBlbGVtZW50IHdoZW4gbm8gZGlyZWN0aXZlcyBhcmUgYm91bmQgdG8gdGhlIHZhciBwcm92aWRlcicsICgpID0+IHtcbiAgICAgICAgICAgIHZhciBkaXJzOlR5cGVbXSA9IFtOZWVkc1F1ZXJ5QnlWYXJCaW5kaW5nc107XG5cbiAgICAgICAgICAgIHZhciBkaXJWYXJpYWJsZUJpbmRpbmdzOntba2V5OnN0cmluZ106bnVtYmVyfSA9IHtcbiAgICAgICAgICAgICAgXCJvbmVcIjogbnVsbCAvLyBlbGVtZW50XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICB2YXIgZWwgPSBhcHBFbGVtZW50KG51bGwsIGRpcnMuY29uY2F0KGV4dHJhRGlyZWN0aXZlcyksIG51bGwsIG51bGwsIG51bGwsIGRpclZhcmlhYmxlQmluZGluZ3MpO1xuXG4gICAgICAgICAgICBlbC5uZ0FmdGVyQ29udGVudENoZWNrZWQoKTtcblxuICAgICAgICAgICAgZXhwZWN0KGVsLmdldChOZWVkc1F1ZXJ5QnlWYXJCaW5kaW5ncykucXVlcnkuZmlyc3QpLnRvQmUoZWwucmVmKTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGl0KCdzaG91bGQgY29udGFpbiBkaXJlY3RpdmVzIG9uIHRoZSBzYW1lIGluamVjdG9yIHdoZW4gcXVlcnlpbmcgYnkgdmFyaWFibGUgcHJvdmlkZXJzJyArXG4gICAgICAgICAgICAnaW4gdGhlIG9yZGVyIG9mIHZhciBwcm92aWRlcnMgc3BlY2lmaWVkIGluIHRoZSBxdWVyeScsICgpID0+IHtcbiAgICAgICAgICAgIHZhciBkaXJzOlR5cGVbXSA9IFtOZWVkc1F1ZXJ5QnlWYXJCaW5kaW5ncywgTmVlZHNEaXJlY3RpdmUsIFNpbXBsZURpcmVjdGl2ZV07XG5cbiAgICAgICAgICAgIHZhciBkaXJWYXJpYWJsZUJpbmRpbmdzOntba2V5OnN0cmluZ106bnVtYmVyfSA9IHtcbiAgICAgICAgICAgICAgXCJvbmVcIjogMiwgLy8gMiBpcyB0aGUgaW5kZXggb2YgU2ltcGxlRGlyZWN0aXZlXG4gICAgICAgICAgICAgIFwidHdvXCI6IDEgLy8gMSBpcyB0aGUgaW5kZXggb2YgTmVlZHNEaXJlY3RpdmVcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIHZhciBlbCA9IGFwcEVsZW1lbnQobnVsbCwgZGlycy5jb25jYXQoZXh0cmFEaXJlY3RpdmVzKSwgbnVsbCwgbnVsbCwgbnVsbCwgZGlyVmFyaWFibGVCaW5kaW5ncyk7XG5cbiAgICAgICAgICAgIGVsLm5nQWZ0ZXJDb250ZW50Q2hlY2tlZCgpO1xuXG4gICAgICAgICAgICAvLyBOZWVkc1F1ZXJ5QnlWYXJCaW5kaW5ncyBxdWVyaWVzIFwib25lLHR3b1wiLCBzbyBTaW1wbGVEaXJlY3RpdmUgc2hvdWxkIGJlIGJlZm9yZSBOZWVkc0RpcmVjdGl2ZVxuICAgICAgICAgICAgZXhwZWN0KGVsLmdldChOZWVkc1F1ZXJ5QnlWYXJCaW5kaW5ncykucXVlcnkuZmlyc3QpLnRvQmVBbkluc3RhbmNlT2YoU2ltcGxlRGlyZWN0aXZlKTtcbiAgICAgICAgICAgIGV4cGVjdChlbC5nZXQoTmVlZHNRdWVyeUJ5VmFyQmluZGluZ3MpLnF1ZXJ5Lmxhc3QpLnRvQmVBbkluc3RhbmNlT2YoTmVlZHNEaXJlY3RpdmUpO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgaXQoJ3Nob3VsZCBjb250YWluIGRpcmVjdGl2ZXMgb24gdGhlIHNhbWUgYW5kIGEgY2hpbGQgaW5qZWN0b3IgaW4gY29uc3RydWN0aW9uIG9yZGVyJywgKCkgPT4ge1xuICAgICAgICAgICAgdmFyIHBhcmVudCA9IGFwcEVsZW1lbnQobnVsbCwgW05lZWRzUXVlcnksIENvdW50aW5nRGlyZWN0aXZlXSk7XG4gICAgICAgICAgICBhcHBFbGVtZW50KHBhcmVudCwgTGlzdFdyYXBwZXIuY29uY2F0KFtDb3VudGluZ0RpcmVjdGl2ZV0sIGV4dHJhRGlyZWN0aXZlcykpO1xuXG4gICAgICAgICAgICBwYXJlbnQubmdBZnRlckNvbnRlbnRDaGVja2VkKCk7XG5cbiAgICAgICAgICAgIGV4cGVjdERpcmVjdGl2ZXMocGFyZW50LmdldChOZWVkc1F1ZXJ5KS5xdWVyeSwgQ291bnRpbmdEaXJlY3RpdmUsIFswLCAxXSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH0pO1xufVxuXG5jbGFzcyBDb250ZXh0V2l0aEhhbmRsZXIge1xuICBoYW5kbGVyO1xuICBjb25zdHJ1Y3RvcihoYW5kbGVyKSB7IHRoaXMuaGFuZGxlciA9IGhhbmRsZXI7IH1cbn0iXX0=
 main(); 
