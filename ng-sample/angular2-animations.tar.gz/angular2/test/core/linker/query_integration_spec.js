'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var testing_internal_1 = require('angular2/testing_internal');
var lang_1 = require('angular2/src/facade/lang');
var async_1 = require('angular2/src/facade/async');
var core_1 = require('angular2/core');
var common_1 = require('angular2/common');
var core_2 = require('angular2/core');
function main() {
    testing_internal_1.describe('Query API', function () {
        testing_internal_1.describe("querying by directive type", function () {
            testing_internal_1.it('should contain all direct child directives in the light dom (constructor)', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<div text="1"></div>' +
                    '<needs-query text="2"><div text="3">' +
                    '<div text="too-deep"></div>' +
                    '</div></needs-query>' +
                    '<div text="4"></div>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    view.detectChanges();
                    testing_internal_1.expect(core_2.asNativeElements(view.debugElement.children)).toHaveText('2|3|');
                    async.done();
                });
            }));
            testing_internal_1.it('should contain all direct child directives in the content dom', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-content-children #q><div text="foo"></div></needs-content-children>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    view.detectChanges();
                    var q = view.debugElement.children[0].getLocal('q');
                    view.detectChanges();
                    testing_internal_1.expect(q.textDirChildren.length).toEqual(1);
                    testing_internal_1.expect(q.numberOfChildrenAfterContentInit).toEqual(1);
                    async.done();
                });
            }));
            testing_internal_1.it('should contain the first content child', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-content-child #q><div *ngIf="shouldShow" text="foo"></div></needs-content-child>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    view.debugElement.componentInstance.shouldShow = true;
                    view.detectChanges();
                    var q = view.debugElement.children[0].getLocal('q');
                    testing_internal_1.expect(q.log).toEqual([["setter", "foo"], ["init", "foo"], ["check", "foo"]]);
                    view.debugElement.componentInstance.shouldShow = false;
                    view.detectChanges();
                    // TODO: this fails right now!
                    // -> queries are not dirtied!
                    testing_internal_1.expect(q.log).toEqual([
                        ["setter", "foo"],
                        ["init", "foo"],
                        ["check", "foo"],
                        ["setter", null],
                        ["check", null]
                    ]);
                    async.done();
                });
            }));
            testing_internal_1.it('should contain the first view child', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-view-child #q></needs-view-child>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    view.detectChanges();
                    var q = view.debugElement.children[0].getLocal('q');
                    testing_internal_1.expect(q.log).toEqual([["setter", "foo"], ["init", "foo"], ["check", "foo"]]);
                    q.shouldShow = false;
                    view.detectChanges();
                    testing_internal_1.expect(q.log).toEqual([
                        ["setter", "foo"],
                        ["init", "foo"],
                        ["check", "foo"],
                        ["setter", null],
                        ["check", null]
                    ]);
                    async.done();
                });
            }));
            testing_internal_1.it('should contain the first view child accross embedded views', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-view-child #q></needs-view-child>';
                tcb.overrideTemplate(MyComp, template)
                    .overrideTemplate(NeedsViewChild, '<div *ngIf="true"><div *ngIf="shouldShow" text="foo"></div></div>')
                    .createAsync(MyComp)
                    .then(function (view) {
                    view.detectChanges();
                    var q = view.debugElement.children[0].getLocal('q');
                    testing_internal_1.expect(q.log).toEqual([["setter", "foo"], ["init", "foo"], ["check", "foo"]]);
                    q.shouldShow = false;
                    view.detectChanges();
                    testing_internal_1.expect(q.log).toEqual([
                        ["setter", "foo"],
                        ["init", "foo"],
                        ["check", "foo"],
                        ["setter", null],
                        ["check", null]
                    ]);
                    async.done();
                });
            }));
            testing_internal_1.it('should contain all directives in the light dom when descendants flag is used', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<div text="1"></div>' +
                    '<needs-query-desc text="2"><div text="3">' +
                    '<div text="4"></div>' +
                    '</div></needs-query-desc>' +
                    '<div text="5"></div>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    view.detectChanges();
                    testing_internal_1.expect(core_2.asNativeElements(view.debugElement.children)).toHaveText('2|3|4|');
                    async.done();
                });
            }));
            testing_internal_1.it('should contain all directives in the light dom', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<div text="1"></div>' +
                    '<needs-query text="2"><div text="3"></div></needs-query>' +
                    '<div text="4"></div>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    view.detectChanges();
                    testing_internal_1.expect(core_2.asNativeElements(view.debugElement.children)).toHaveText('2|3|');
                    async.done();
                });
            }));
            testing_internal_1.it('should reflect dynamically inserted directives', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<div text="1"></div>' +
                    '<needs-query text="2"><div *ngIf="shouldShow" [text]="\'3\'"></div></needs-query>' +
                    '<div text="4"></div>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    view.detectChanges();
                    testing_internal_1.expect(core_2.asNativeElements(view.debugElement.children)).toHaveText('2|');
                    view.debugElement.componentInstance.shouldShow = true;
                    view.detectChanges();
                    testing_internal_1.expect(core_2.asNativeElements(view.debugElement.children)).toHaveText('2|3|');
                    async.done();
                });
            }));
            testing_internal_1.it('should be cleanly destroyed when a query crosses view boundaries', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<div text="1"></div>' +
                    '<needs-query text="2"><div *ngIf="shouldShow" [text]="\'3\'"></div></needs-query>' +
                    '<div text="4"></div>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.shouldShow = true;
                    fixture.detectChanges();
                    fixture.destroy();
                    async.done();
                });
            }));
            testing_internal_1.it('should reflect moved directives', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<div text="1"></div>' +
                    '<needs-query text="2"><div *ngFor="var i of list" [text]="i"></div></needs-query>' +
                    '<div text="4"></div>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    view.detectChanges();
                    testing_internal_1.expect(core_2.asNativeElements(view.debugElement.children)).toHaveText('2|1d|2d|3d|');
                    view.debugElement.componentInstance.list = ['3d', '2d'];
                    view.detectChanges();
                    testing_internal_1.expect(core_2.asNativeElements(view.debugElement.children)).toHaveText('2|3d|2d|');
                    async.done();
                });
            }));
        });
        testing_internal_1.describe('query for TemplateRef', function () {
            testing_internal_1.it('should find TemplateRefs in the light and shadow dom', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-tpl><template var-x="light"></template></needs-tpl>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    view.detectChanges();
                    var needsTpl = view.debugElement.children[0].inject(NeedsTpl);
                    testing_internal_1.expect(needsTpl.vc.createEmbeddedView(needsTpl.query.first).hasLocal('light'))
                        .toBe(true);
                    testing_internal_1.expect(needsTpl.vc.createEmbeddedView(needsTpl.viewQuery.first).hasLocal('shadow'))
                        .toBe(true);
                    async.done();
                });
            }));
        });
        testing_internal_1.describe("changes", function () {
            testing_internal_1.it('should notify query on change', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-query #q>' +
                    '<div text="1"></div>' +
                    '<div *ngIf="shouldShow" text="2"></div>' +
                    '</needs-query>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    var q = view.debugElement.children[0].getLocal("q");
                    view.detectChanges();
                    async_1.ObservableWrapper.subscribe(q.query.changes, function (_) {
                        testing_internal_1.expect(q.query.first.text).toEqual("1");
                        testing_internal_1.expect(q.query.last.text).toEqual("2");
                        async.done();
                    });
                    view.debugElement.componentInstance.shouldShow = true;
                    view.detectChanges();
                });
            }));
            testing_internal_1.it("should notify child's query before notifying parent's query", testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-query-desc #q1>' +
                    '<needs-query-desc #q2>' +
                    '<div text="1"></div>' +
                    '</needs-query-desc>' +
                    '</needs-query-desc>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    var q1 = view.debugElement.children[0].getLocal("q1");
                    var q2 = view.debugElement.children[0].getLocal("q2");
                    var firedQ2 = false;
                    async_1.ObservableWrapper.subscribe(q2.query.changes, function (_) { firedQ2 = true; });
                    async_1.ObservableWrapper.subscribe(q1.query.changes, function (_) {
                        testing_internal_1.expect(firedQ2).toBe(true);
                        async.done();
                    });
                    view.detectChanges();
                });
            }));
            testing_internal_1.it('should correctly clean-up when destroyed together with the directives it is querying', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-query #q *ngIf="shouldShow"><div text="foo"></div></needs-query>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    view.debugElement.componentInstance.shouldShow = true;
                    view.detectChanges();
                    var q = view.debugElement.children[0].getLocal('q');
                    testing_internal_1.expect(q.query.length).toEqual(1);
                    view.debugElement.componentInstance.shouldShow = false;
                    view.detectChanges();
                    view.debugElement.componentInstance.shouldShow = true;
                    view.detectChanges();
                    var q2 = view.debugElement.children[0].getLocal('q');
                    testing_internal_1.expect(q2.query.length).toEqual(1);
                    async.done();
                });
            }));
        });
        testing_internal_1.describe("querying by var binding", function () {
            testing_internal_1.it('should contain all the child directives in the light dom with the given var binding', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-query-by-var-binding #q>' +
                    '<div *ngFor="#item of list" [text]="item" #textLabel="textDir"></div>' +
                    '</needs-query-by-var-binding>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    var q = view.debugElement.children[0].getLocal("q");
                    view.debugElement.componentInstance.list = ['1d', '2d'];
                    view.detectChanges();
                    testing_internal_1.expect(q.query.first.text).toEqual("1d");
                    testing_internal_1.expect(q.query.last.text).toEqual("2d");
                    async.done();
                });
            }));
            testing_internal_1.it('should support querying by multiple var bindings', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-query-by-var-bindings #q>' +
                    '<div text="one" #textLabel1="textDir"></div>' +
                    '<div text="two" #textLabel2="textDir"></div>' +
                    '</needs-query-by-var-bindings>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    var q = view.debugElement.children[0].getLocal("q");
                    view.detectChanges();
                    testing_internal_1.expect(q.query.first.text).toEqual("one");
                    testing_internal_1.expect(q.query.last.text).toEqual("two");
                    async.done();
                });
            }));
            testing_internal_1.it('should reflect dynamically inserted directives', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-query-by-var-binding #q>' +
                    '<div *ngFor="#item of list" [text]="item" #textLabel="textDir"></div>' +
                    '</needs-query-by-var-binding>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    var q = view.debugElement.children[0].getLocal("q");
                    view.debugElement.componentInstance.list = ['1d', '2d'];
                    view.detectChanges();
                    view.debugElement.componentInstance.list = ['2d', '1d'];
                    view.detectChanges();
                    testing_internal_1.expect(q.query.last.text).toEqual("1d");
                    async.done();
                });
            }));
            testing_internal_1.it('should contain all the elements in the light dom with the given var binding', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-query-by-var-binding #q>' +
                    '<div template="ngFor: #item of list">' +
                    '<div #textLabel>{{item}}</div>' +
                    '</div>' +
                    '</needs-query-by-var-binding>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    var q = view.debugElement.children[0].getLocal("q");
                    view.debugElement.componentInstance.list = ['1d', '2d'];
                    view.detectChanges();
                    testing_internal_1.expect(q.query.first.nativeElement).toHaveText("1d");
                    testing_internal_1.expect(q.query.last.nativeElement).toHaveText("2d");
                    async.done();
                });
            }));
            testing_internal_1.it('should contain all the elements in the light dom even if they get projected', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-query-and-project #q>' +
                    '<div text="hello"></div><div text="world"></div>' +
                    '</needs-query-and-project>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    view.detectChanges();
                    testing_internal_1.expect(core_2.asNativeElements(view.debugElement.children)).toHaveText('hello|world|');
                    async.done();
                });
            }));
            testing_internal_1.it('should support querying the view by using a view query', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-view-query-by-var-binding #q></needs-view-query-by-var-binding>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    var q = view.debugElement.children[0].getLocal("q");
                    view.detectChanges();
                    testing_internal_1.expect(q.query.first.nativeElement).toHaveText("text");
                    async.done();
                });
            }));
            testing_internal_1.it('should contain all child directives in the view dom', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-view-children #q></needs-view-children>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    view.detectChanges();
                    var q = view.debugElement.children[0].getLocal('q');
                    view.detectChanges();
                    testing_internal_1.expect(q.textDirChildren.length).toEqual(1);
                    testing_internal_1.expect(q.numberOfChildrenAfterViewInit).toEqual(1);
                    async.done();
                });
            }));
        });
        testing_internal_1.describe("querying in the view", function () {
            testing_internal_1.it('should contain all the elements in the view with that have the given directive', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-view-query #q><div text="ignoreme"></div></needs-view-query>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    var q = view.debugElement.children[0].getLocal("q");
                    view.detectChanges();
                    testing_internal_1.expect(q.query.map(function (d) { return d.text; })).toEqual(["1", "2", "3", "4"]);
                    async.done();
                });
            }));
            testing_internal_1.it('should not include directive present on the host element', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-view-query #q text="self"></needs-view-query>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    var q = view.debugElement.children[0].getLocal("q");
                    view.detectChanges();
                    testing_internal_1.expect(q.query.map(function (d) { return d.text; })).toEqual(["1", "2", "3", "4"]);
                    async.done();
                });
            }));
            testing_internal_1.it('should reflect changes in the component', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-view-query-if #q></needs-view-query-if>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    var q = view.debugElement.children[0].getLocal("q");
                    view.detectChanges();
                    testing_internal_1.expect(q.query.length).toBe(0);
                    q.show = true;
                    view.detectChanges();
                    testing_internal_1.expect(q.query.length).toBe(1);
                    testing_internal_1.expect(q.query.first.text).toEqual("1");
                    async.done();
                });
            }));
            testing_internal_1.it('should not be affected by other changes in the component', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-view-query-nested-if #q></needs-view-query-nested-if>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    var q = view.debugElement.children[0].getLocal("q");
                    view.detectChanges();
                    testing_internal_1.expect(q.query.length).toEqual(1);
                    testing_internal_1.expect(q.query.first.text).toEqual("1");
                    q.show = false;
                    view.detectChanges();
                    testing_internal_1.expect(q.query.length).toEqual(1);
                    testing_internal_1.expect(q.query.first.text).toEqual("1");
                    async.done();
                });
            }));
            testing_internal_1.it('should maintain directives in pre-order depth-first DOM order after dynamic insertion', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-view-query-order #q></needs-view-query-order>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    var q = view.debugElement.children[0].getLocal("q");
                    view.detectChanges();
                    testing_internal_1.expect(q.query.map(function (d) { return d.text; })).toEqual(["1", "2", "3", "4"]);
                    q.list = ["-3", "2"];
                    view.detectChanges();
                    testing_internal_1.expect(q.query.map(function (d) { return d.text; })).toEqual(["1", "-3", "2", "4"]);
                    async.done();
                });
            }));
            testing_internal_1.it('should maintain directives in pre-order depth-first DOM order after dynamic insertion', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-view-query-order-with-p #q></needs-view-query-order-with-p>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    var q = view.debugElement.children[0].getLocal("q");
                    view.detectChanges();
                    testing_internal_1.expect(q.query.map(function (d) { return d.text; })).toEqual(["1", "2", "3", "4"]);
                    q.list = ["-3", "2"];
                    view.detectChanges();
                    testing_internal_1.expect(q.query.map(function (d) { return d.text; })).toEqual(["1", "-3", "2", "4"]);
                    async.done();
                });
            }));
            testing_internal_1.it('should handle long ngFor cycles', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-view-query-order #q></needs-view-query-order>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    var q = view.debugElement.children[0].getLocal('q');
                    // no significance to 50, just a reasonably large cycle.
                    for (var i = 0; i < 50; i++) {
                        var newString = i.toString();
                        q.list = [newString];
                        view.detectChanges();
                        testing_internal_1.expect(q.query.map(function (d) { return d.text; })).toEqual(['1', newString, '4']);
                    }
                    async.done();
                });
            }));
            testing_internal_1.it('should support more than three queries', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<needs-four-queries #q><div text="1"></div></needs-four-queries>';
                tcb.overrideTemplate(MyComp, template)
                    .createAsync(MyComp)
                    .then(function (view) {
                    view.detectChanges();
                    var q = view.debugElement.children[0].getLocal('q');
                    testing_internal_1.expect(q.query1).toBeDefined();
                    testing_internal_1.expect(q.query2).toBeDefined();
                    testing_internal_1.expect(q.query3).toBeDefined();
                    testing_internal_1.expect(q.query4).toBeDefined();
                    async.done();
                });
            }));
        });
    });
}
exports.main = main;
var TextDirective = (function () {
    function TextDirective() {
    }
    TextDirective = __decorate([
        core_1.Directive({ selector: '[text]', inputs: ['text'], exportAs: 'textDir' }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], TextDirective);
    return TextDirective;
})();
var NeedsContentChildren = (function () {
    function NeedsContentChildren() {
    }
    NeedsContentChildren.prototype.ngAfterContentInit = function () { this.numberOfChildrenAfterContentInit = this.textDirChildren.length; };
    __decorate([
        core_1.ContentChildren(TextDirective), 
        __metadata('design:type', core_1.QueryList)
    ], NeedsContentChildren.prototype, "textDirChildren", void 0);
    NeedsContentChildren = __decorate([
        core_1.Component({ selector: 'needs-content-children', template: '' }), 
        __metadata('design:paramtypes', [])
    ], NeedsContentChildren);
    return NeedsContentChildren;
})();
var NeedsViewChildren = (function () {
    function NeedsViewChildren() {
    }
    NeedsViewChildren.prototype.ngAfterViewInit = function () { this.numberOfChildrenAfterViewInit = this.textDirChildren.length; };
    __decorate([
        core_1.ViewChildren(TextDirective), 
        __metadata('design:type', core_1.QueryList)
    ], NeedsViewChildren.prototype, "textDirChildren", void 0);
    NeedsViewChildren = __decorate([
        core_1.Component({ selector: 'needs-view-children', template: '<div text></div>', directives: [TextDirective] }), 
        __metadata('design:paramtypes', [])
    ], NeedsViewChildren);
    return NeedsViewChildren;
})();
var NeedsContentChild = (function () {
    function NeedsContentChild() {
        this.log = [];
    }
    Object.defineProperty(NeedsContentChild.prototype, "child", {
        get: function () { return this._child; },
        set: function (value) {
            this._child = value;
            this.log.push(['setter', lang_1.isPresent(value) ? value.text : null]);
        },
        enumerable: true,
        configurable: true
    });
    NeedsContentChild.prototype.ngAfterContentInit = function () { this.log.push(["init", lang_1.isPresent(this.child) ? this.child.text : null]); };
    NeedsContentChild.prototype.ngAfterContentChecked = function () {
        this.log.push(["check", lang_1.isPresent(this.child) ? this.child.text : null]);
    };
    __decorate([
        core_1.ContentChild(TextDirective), 
        __metadata('design:type', Object), 
        __metadata('design:paramtypes', [Object])
    ], NeedsContentChild.prototype, "child", null);
    NeedsContentChild = __decorate([
        core_1.Component({ selector: 'needs-content-child', template: '' }), 
        __metadata('design:paramtypes', [])
    ], NeedsContentChild);
    return NeedsContentChild;
})();
var NeedsViewChild = (function () {
    function NeedsViewChild() {
        this.shouldShow = true;
        this.log = [];
    }
    Object.defineProperty(NeedsViewChild.prototype, "child", {
        get: function () { return this._child; },
        set: function (value) {
            this._child = value;
            this.log.push(['setter', lang_1.isPresent(value) ? value.text : null]);
        },
        enumerable: true,
        configurable: true
    });
    NeedsViewChild.prototype.ngAfterViewInit = function () { this.log.push(["init", lang_1.isPresent(this.child) ? this.child.text : null]); };
    NeedsViewChild.prototype.ngAfterViewChecked = function () { this.log.push(["check", lang_1.isPresent(this.child) ? this.child.text : null]); };
    __decorate([
        core_1.ViewChild(TextDirective), 
        __metadata('design:type', Object), 
        __metadata('design:paramtypes', [Object])
    ], NeedsViewChild.prototype, "child", null);
    NeedsViewChild = __decorate([
        core_1.Component({
            selector: 'needs-view-child',
            template: "\n    <div *ngIf=\"shouldShow\" text=\"foo\"></div>\n  ",
            directives: [common_1.NgIf, TextDirective]
        }), 
        __metadata('design:paramtypes', [])
    ], NeedsViewChild);
    return NeedsViewChild;
})();
var InertDirective = (function () {
    function InertDirective() {
    }
    InertDirective = __decorate([
        core_1.Directive({ selector: '[dir]' }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], InertDirective);
    return InertDirective;
})();
var NeedsQuery = (function () {
    function NeedsQuery(query) {
        this.query = query;
    }
    NeedsQuery = __decorate([
        core_1.Component({
            selector: 'needs-query',
            directives: [common_1.NgFor, TextDirective],
            template: '<div text="ignoreme"></div><b *ngFor="var dir of query">{{dir.text}}|</b>'
        }),
        core_1.Injectable(),
        __param(0, core_1.Query(TextDirective)), 
        __metadata('design:paramtypes', [core_1.QueryList])
    ], NeedsQuery);
    return NeedsQuery;
})();
var NeedsFourQueries = (function () {
    function NeedsFourQueries() {
    }
    __decorate([
        core_1.ContentChild(TextDirective), 
        __metadata('design:type', TextDirective)
    ], NeedsFourQueries.prototype, "query1", void 0);
    __decorate([
        core_1.ContentChild(TextDirective), 
        __metadata('design:type', TextDirective)
    ], NeedsFourQueries.prototype, "query2", void 0);
    __decorate([
        core_1.ContentChild(TextDirective), 
        __metadata('design:type', TextDirective)
    ], NeedsFourQueries.prototype, "query3", void 0);
    __decorate([
        core_1.ContentChild(TextDirective), 
        __metadata('design:type', TextDirective)
    ], NeedsFourQueries.prototype, "query4", void 0);
    NeedsFourQueries = __decorate([
        core_1.Component({ selector: 'needs-four-queries', template: '' }), 
        __metadata('design:paramtypes', [])
    ], NeedsFourQueries);
    return NeedsFourQueries;
})();
var NeedsQueryDesc = (function () {
    function NeedsQueryDesc(query) {
        this.query = query;
    }
    NeedsQueryDesc = __decorate([
        core_1.Component({
            selector: 'needs-query-desc',
            directives: [common_1.NgFor],
            template: '<div *ngFor="var dir of query">{{dir.text}}|</div>'
        }),
        core_1.Injectable(),
        __param(0, core_1.Query(TextDirective, { descendants: true })), 
        __metadata('design:paramtypes', [core_1.QueryList])
    ], NeedsQueryDesc);
    return NeedsQueryDesc;
})();
var NeedsQueryByLabel = (function () {
    function NeedsQueryByLabel(query) {
        this.query = query;
    }
    NeedsQueryByLabel = __decorate([
        core_1.Component({ selector: 'needs-query-by-var-binding', directives: [], template: '<ng-content>' }),
        core_1.Injectable(),
        __param(0, core_1.Query("textLabel", { descendants: true })), 
        __metadata('design:paramtypes', [core_1.QueryList])
    ], NeedsQueryByLabel);
    return NeedsQueryByLabel;
})();
var NeedsViewQueryByLabel = (function () {
    function NeedsViewQueryByLabel(query) {
        this.query = query;
    }
    NeedsViewQueryByLabel = __decorate([
        core_1.Component({
            selector: 'needs-view-query-by-var-binding',
            directives: [],
            template: '<div #textLabel>text</div>'
        }),
        core_1.Injectable(),
        __param(0, core_1.ViewQuery("textLabel")), 
        __metadata('design:paramtypes', [core_1.QueryList])
    ], NeedsViewQueryByLabel);
    return NeedsViewQueryByLabel;
})();
var NeedsQueryByTwoLabels = (function () {
    function NeedsQueryByTwoLabels(query) {
        this.query = query;
    }
    NeedsQueryByTwoLabels = __decorate([
        core_1.Component({ selector: 'needs-query-by-var-bindings', directives: [], template: '<ng-content>' }),
        core_1.Injectable(),
        __param(0, core_1.Query("textLabel1,textLabel2", { descendants: true })), 
        __metadata('design:paramtypes', [core_1.QueryList])
    ], NeedsQueryByTwoLabels);
    return NeedsQueryByTwoLabels;
})();
var NeedsQueryAndProject = (function () {
    function NeedsQueryAndProject(query) {
        this.query = query;
    }
    NeedsQueryAndProject = __decorate([
        core_1.Component({
            selector: 'needs-query-and-project',
            directives: [common_1.NgFor],
            template: '<div *ngFor="var dir of query">{{dir.text}}|</div><ng-content></ng-content>'
        }),
        core_1.Injectable(),
        __param(0, core_1.Query(TextDirective)), 
        __metadata('design:paramtypes', [core_1.QueryList])
    ], NeedsQueryAndProject);
    return NeedsQueryAndProject;
})();
var NeedsViewQuery = (function () {
    function NeedsViewQuery(query) {
        this.query = query;
    }
    NeedsViewQuery = __decorate([
        core_1.Component({
            selector: 'needs-view-query',
            directives: [TextDirective],
            template: '<div text="1"><div text="2"></div></div>' +
                '<div text="3"></div><div text="4"></div>'
        }),
        core_1.Injectable(),
        __param(0, core_1.ViewQuery(TextDirective)), 
        __metadata('design:paramtypes', [core_1.QueryList])
    ], NeedsViewQuery);
    return NeedsViewQuery;
})();
var NeedsViewQueryIf = (function () {
    function NeedsViewQueryIf(query) {
        this.query = query;
        this.show = false;
    }
    NeedsViewQueryIf = __decorate([
        core_1.Component({
            selector: 'needs-view-query-if',
            directives: [common_1.NgIf, TextDirective],
            template: '<div *ngIf="show" text="1"></div>'
        }),
        core_1.Injectable(),
        __param(0, core_1.ViewQuery(TextDirective)), 
        __metadata('design:paramtypes', [core_1.QueryList])
    ], NeedsViewQueryIf);
    return NeedsViewQueryIf;
})();
var NeedsViewQueryNestedIf = (function () {
    function NeedsViewQueryNestedIf(query) {
        this.query = query;
        this.show = true;
    }
    NeedsViewQueryNestedIf = __decorate([
        core_1.Component({
            selector: 'needs-view-query-nested-if',
            directives: [common_1.NgIf, InertDirective, TextDirective],
            template: '<div text="1"><div *ngIf="show"><div dir></div></div></div>'
        }),
        core_1.Injectable(),
        __param(0, core_1.ViewQuery(TextDirective)), 
        __metadata('design:paramtypes', [core_1.QueryList])
    ], NeedsViewQueryNestedIf);
    return NeedsViewQueryNestedIf;
})();
var NeedsViewQueryOrder = (function () {
    function NeedsViewQueryOrder(query) {
        this.query = query;
        this.list = ['2', '3'];
    }
    NeedsViewQueryOrder = __decorate([
        core_1.Component({
            selector: 'needs-view-query-order',
            directives: [common_1.NgFor, TextDirective, InertDirective],
            template: '<div text="1"></div>' +
                '<div *ngFor="var i of list" [text]="i"></div>' +
                '<div text="4"></div>'
        }),
        core_1.Injectable(),
        __param(0, core_1.ViewQuery(TextDirective)), 
        __metadata('design:paramtypes', [core_1.QueryList])
    ], NeedsViewQueryOrder);
    return NeedsViewQueryOrder;
})();
var NeedsViewQueryOrderWithParent = (function () {
    function NeedsViewQueryOrderWithParent(query) {
        this.query = query;
        this.list = ['2', '3'];
    }
    NeedsViewQueryOrderWithParent = __decorate([
        core_1.Component({
            selector: 'needs-view-query-order-with-p',
            directives: [common_1.NgFor, TextDirective, InertDirective],
            template: '<div dir><div text="1"></div>' +
                '<div *ngFor="var i of list" [text]="i"></div>' +
                '<div text="4"></div></div>'
        }),
        core_1.Injectable(),
        __param(0, core_1.ViewQuery(TextDirective)), 
        __metadata('design:paramtypes', [core_1.QueryList])
    ], NeedsViewQueryOrderWithParent);
    return NeedsViewQueryOrderWithParent;
})();
var NeedsTpl = (function () {
    function NeedsTpl(viewQuery, query, vc) {
        this.vc = vc;
        this.viewQuery = viewQuery;
        this.query = query;
    }
    NeedsTpl = __decorate([
        core_1.Component({ selector: 'needs-tpl', template: '<template var-x="shadow"></template>' }),
        __param(0, core_1.ViewQuery(core_1.TemplateRef)),
        __param(1, core_1.Query(core_1.TemplateRef)), 
        __metadata('design:paramtypes', [core_1.QueryList, core_1.QueryList, core_2.ViewContainerRef])
    ], NeedsTpl);
    return NeedsTpl;
})();
var MyComp = (function () {
    function MyComp() {
        this.shouldShow = false;
        this.list = ['1d', '2d', '3d'];
    }
    MyComp = __decorate([
        core_1.Component({
            selector: 'my-comp',
            directives: [
                NeedsQuery,
                NeedsQueryDesc,
                NeedsQueryByLabel,
                NeedsQueryByTwoLabels,
                NeedsQueryAndProject,
                NeedsViewQuery,
                NeedsViewQueryIf,
                NeedsViewQueryNestedIf,
                NeedsViewQueryOrder,
                NeedsViewQueryByLabel,
                NeedsViewQueryOrderWithParent,
                NeedsContentChildren,
                NeedsViewChildren,
                NeedsViewChild,
                NeedsContentChild,
                NeedsTpl,
                TextDirective,
                InertDirective,
                common_1.NgIf,
                common_1.NgFor,
                NeedsFourQueries
            ],
            template: ''
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], MyComp);
    return MyComp;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicXVlcnlfaW50ZWdyYXRpb25fc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29yZS9saW5rZXIvcXVlcnlfaW50ZWdyYXRpb25fc3BlYy50cyJdLCJuYW1lcyI6WyJtYWluIiwiVGV4dERpcmVjdGl2ZSIsIlRleHREaXJlY3RpdmUuY29uc3RydWN0b3IiLCJOZWVkc0NvbnRlbnRDaGlsZHJlbiIsIk5lZWRzQ29udGVudENoaWxkcmVuLmNvbnN0cnVjdG9yIiwiTmVlZHNDb250ZW50Q2hpbGRyZW4ubmdBZnRlckNvbnRlbnRJbml0IiwiTmVlZHNWaWV3Q2hpbGRyZW4iLCJOZWVkc1ZpZXdDaGlsZHJlbi5jb25zdHJ1Y3RvciIsIk5lZWRzVmlld0NoaWxkcmVuLm5nQWZ0ZXJWaWV3SW5pdCIsIk5lZWRzQ29udGVudENoaWxkIiwiTmVlZHNDb250ZW50Q2hpbGQuY29uc3RydWN0b3IiLCJOZWVkc0NvbnRlbnRDaGlsZC5jaGlsZCIsIk5lZWRzQ29udGVudENoaWxkLm5nQWZ0ZXJDb250ZW50SW5pdCIsIk5lZWRzQ29udGVudENoaWxkLm5nQWZ0ZXJDb250ZW50Q2hlY2tlZCIsIk5lZWRzVmlld0NoaWxkIiwiTmVlZHNWaWV3Q2hpbGQuY29uc3RydWN0b3IiLCJOZWVkc1ZpZXdDaGlsZC5jaGlsZCIsIk5lZWRzVmlld0NoaWxkLm5nQWZ0ZXJWaWV3SW5pdCIsIk5lZWRzVmlld0NoaWxkLm5nQWZ0ZXJWaWV3Q2hlY2tlZCIsIkluZXJ0RGlyZWN0aXZlIiwiSW5lcnREaXJlY3RpdmUuY29uc3RydWN0b3IiLCJOZWVkc1F1ZXJ5IiwiTmVlZHNRdWVyeS5jb25zdHJ1Y3RvciIsIk5lZWRzRm91clF1ZXJpZXMiLCJOZWVkc0ZvdXJRdWVyaWVzLmNvbnN0cnVjdG9yIiwiTmVlZHNRdWVyeURlc2MiLCJOZWVkc1F1ZXJ5RGVzYy5jb25zdHJ1Y3RvciIsIk5lZWRzUXVlcnlCeUxhYmVsIiwiTmVlZHNRdWVyeUJ5TGFiZWwuY29uc3RydWN0b3IiLCJOZWVkc1ZpZXdRdWVyeUJ5TGFiZWwiLCJOZWVkc1ZpZXdRdWVyeUJ5TGFiZWwuY29uc3RydWN0b3IiLCJOZWVkc1F1ZXJ5QnlUd29MYWJlbHMiLCJOZWVkc1F1ZXJ5QnlUd29MYWJlbHMuY29uc3RydWN0b3IiLCJOZWVkc1F1ZXJ5QW5kUHJvamVjdCIsIk5lZWRzUXVlcnlBbmRQcm9qZWN0LmNvbnN0cnVjdG9yIiwiTmVlZHNWaWV3UXVlcnkiLCJOZWVkc1ZpZXdRdWVyeS5jb25zdHJ1Y3RvciIsIk5lZWRzVmlld1F1ZXJ5SWYiLCJOZWVkc1ZpZXdRdWVyeUlmLmNvbnN0cnVjdG9yIiwiTmVlZHNWaWV3UXVlcnlOZXN0ZWRJZiIsIk5lZWRzVmlld1F1ZXJ5TmVzdGVkSWYuY29uc3RydWN0b3IiLCJOZWVkc1ZpZXdRdWVyeU9yZGVyIiwiTmVlZHNWaWV3UXVlcnlPcmRlci5jb25zdHJ1Y3RvciIsIk5lZWRzVmlld1F1ZXJ5T3JkZXJXaXRoUGFyZW50IiwiTmVlZHNWaWV3UXVlcnlPcmRlcldpdGhQYXJlbnQuY29uc3RydWN0b3IiLCJOZWVkc1RwbCIsIk5lZWRzVHBsLmNvbnN0cnVjdG9yIiwiTXlDb21wIiwiTXlDb21wLmNvbnN0cnVjdG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSxpQ0FZTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLHFCQUF3QiwwQkFBMEIsQ0FBQyxDQUFBO0FBQ25ELHNCQUFnQywyQkFBMkIsQ0FBQyxDQUFBO0FBRTVELHFCQWlCTyxlQUFlLENBQUMsQ0FBQTtBQUN2Qix1QkFBMEIsaUJBQWlCLENBQUMsQ0FBQTtBQUM1QyxxQkFBaUQsZUFBZSxDQUFDLENBQUE7QUFFakU7SUFDRUEsMkJBQVFBLENBQUNBLFdBQVdBLEVBQUVBO1FBQ3BCQSwyQkFBUUEsQ0FBQ0EsNEJBQTRCQSxFQUFFQTtZQUNyQ0EscUJBQUVBLENBQUNBLDJFQUEyRUEsRUFDM0VBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO2dCQUNsRkEsSUFBSUEsUUFBUUEsR0FBR0Esc0JBQXNCQTtvQkFDdEJBLHNDQUFzQ0E7b0JBQ3RDQSw2QkFBNkJBO29CQUM3QkEsc0JBQXNCQTtvQkFDdEJBLHNCQUFzQkEsQ0FBQ0E7Z0JBRXRDQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLEVBQUVBLFFBQVFBLENBQUNBO3FCQUNqQ0EsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7cUJBQ25CQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtvQkFDVEEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBRXJCQSx5QkFBTUEsQ0FBQ0EsdUJBQWdCQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTtvQkFFeEVBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVQQSxxQkFBRUEsQ0FBQ0EsK0RBQStEQSxFQUMvREEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7Z0JBQ2xGQSxJQUFJQSxRQUFRQSxHQUNSQSw0RUFBNEVBLENBQUNBO2dCQUVqRkEsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxNQUFNQSxFQUFFQSxRQUFRQSxDQUFDQTtxQkFDakNBLFdBQVdBLENBQUNBLE1BQU1BLENBQUNBO3FCQUNuQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7b0JBQ1RBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUVyQkEsSUFBSUEsQ0FBQ0EsR0FBR0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7b0JBRXBEQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFFckJBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxlQUFlQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDNUNBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxnQ0FBZ0NBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUV0REEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSx3Q0FBd0NBLEVBQ3hDQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtnQkFDbEZBLElBQUlBLFFBQVFBLEdBQ1JBLHlGQUF5RkEsQ0FBQ0E7Z0JBRTlGQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLEVBQUVBLFFBQVFBLENBQUNBO3FCQUNqQ0EsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7cUJBQ25CQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtvQkFDVEEsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxVQUFVQSxHQUFHQSxJQUFJQSxDQUFDQTtvQkFDdERBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUVyQkEsSUFBSUEsQ0FBQ0EsR0FBR0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7b0JBRXBEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsRUFBRUEsS0FBS0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsTUFBTUEsRUFBRUEsS0FBS0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsT0FBT0EsRUFBRUEsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRTlFQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLFVBQVVBLEdBQUdBLEtBQUtBLENBQUNBO29CQUN2REEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBRXJCQSw4QkFBOEJBO29CQUM5QkEsOEJBQThCQTtvQkFDOUJBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQTt3QkFDcEJBLENBQUNBLFFBQVFBLEVBQUVBLEtBQUtBLENBQUNBO3dCQUNqQkEsQ0FBQ0EsTUFBTUEsRUFBRUEsS0FBS0EsQ0FBQ0E7d0JBQ2ZBLENBQUNBLE9BQU9BLEVBQUVBLEtBQUtBLENBQUNBO3dCQUNoQkEsQ0FBQ0EsUUFBUUEsRUFBRUEsSUFBSUEsQ0FBQ0E7d0JBQ2hCQSxDQUFDQSxPQUFPQSxFQUFFQSxJQUFJQSxDQUFDQTtxQkFDaEJBLENBQUNBLENBQUNBO29CQUVIQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFUEEscUJBQUVBLENBQUNBLHFDQUFxQ0EsRUFDckNBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO2dCQUNsRkEsSUFBSUEsUUFBUUEsR0FBR0EsMENBQTBDQSxDQUFDQTtnQkFFMURBLEdBQUdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsTUFBTUEsRUFBRUEsUUFBUUEsQ0FBQ0E7cUJBQ2pDQSxXQUFXQSxDQUFDQSxNQUFNQSxDQUFDQTtxQkFDbkJBLElBQUlBLENBQUNBLFVBQUNBLElBQUlBO29CQUNUQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFDckJBLElBQUlBLENBQUNBLEdBQUdBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO29CQUVwREEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLFFBQVFBLEVBQUVBLEtBQUtBLENBQUNBLEVBQUVBLENBQUNBLE1BQU1BLEVBQUVBLEtBQUtBLENBQUNBLEVBQUVBLENBQUNBLE9BQU9BLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUU5RUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsR0FBR0EsS0FBS0EsQ0FBQ0E7b0JBQ3JCQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFFckJBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQTt3QkFDcEJBLENBQUNBLFFBQVFBLEVBQUVBLEtBQUtBLENBQUNBO3dCQUNqQkEsQ0FBQ0EsTUFBTUEsRUFBRUEsS0FBS0EsQ0FBQ0E7d0JBQ2ZBLENBQUNBLE9BQU9BLEVBQUVBLEtBQUtBLENBQUNBO3dCQUNoQkEsQ0FBQ0EsUUFBUUEsRUFBRUEsSUFBSUEsQ0FBQ0E7d0JBQ2hCQSxDQUFDQSxPQUFPQSxFQUFFQSxJQUFJQSxDQUFDQTtxQkFDaEJBLENBQUNBLENBQUNBO29CQUVIQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFUEEscUJBQUVBLENBQUNBLDREQUE0REEsRUFDNURBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO2dCQUNsRkEsSUFBSUEsUUFBUUEsR0FBR0EsMENBQTBDQSxDQUFDQTtnQkFDMURBLEdBQUdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsTUFBTUEsRUFBRUEsUUFBUUEsQ0FBQ0E7cUJBQ2pDQSxnQkFBZ0JBLENBQ2JBLGNBQWNBLEVBQ2RBLG1FQUFtRUEsQ0FBQ0E7cUJBQ3ZFQSxXQUFXQSxDQUFDQSxNQUFNQSxDQUFDQTtxQkFDbkJBLElBQUlBLENBQUNBLFVBQUNBLElBQUlBO29CQUNUQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFDckJBLElBQUlBLENBQUNBLEdBQUdBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO29CQUVwREEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLFFBQVFBLEVBQUVBLEtBQUtBLENBQUNBLEVBQUVBLENBQUNBLE1BQU1BLEVBQUVBLEtBQUtBLENBQUNBLEVBQUVBLENBQUNBLE9BQU9BLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUU5RUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsR0FBR0EsS0FBS0EsQ0FBQ0E7b0JBQ3JCQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFFckJBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQTt3QkFDcEJBLENBQUNBLFFBQVFBLEVBQUVBLEtBQUtBLENBQUNBO3dCQUNqQkEsQ0FBQ0EsTUFBTUEsRUFBRUEsS0FBS0EsQ0FBQ0E7d0JBQ2ZBLENBQUNBLE9BQU9BLEVBQUVBLEtBQUtBLENBQUNBO3dCQUNoQkEsQ0FBQ0EsUUFBUUEsRUFBRUEsSUFBSUEsQ0FBQ0E7d0JBQ2hCQSxDQUFDQSxPQUFPQSxFQUFFQSxJQUFJQSxDQUFDQTtxQkFDaEJBLENBQUNBLENBQUNBO29CQUVIQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFUEEscUJBQUVBLENBQUNBLDhFQUE4RUEsRUFDOUVBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO2dCQUNsRkEsSUFBSUEsUUFBUUEsR0FBR0Esc0JBQXNCQTtvQkFDdEJBLDJDQUEyQ0E7b0JBQzNDQSxzQkFBc0JBO29CQUN0QkEsMkJBQTJCQTtvQkFDM0JBLHNCQUFzQkEsQ0FBQ0E7Z0JBRXRDQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLEVBQUVBLFFBQVFBLENBQUNBO3FCQUNqQ0EsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7cUJBQ25CQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtvQkFDVEEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBQ3JCQSx5QkFBTUEsQ0FBQ0EsdUJBQWdCQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtvQkFFMUVBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVQQSxxQkFBRUEsQ0FBQ0EsZ0RBQWdEQSxFQUNoREEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7Z0JBQ2xGQSxJQUFJQSxRQUFRQSxHQUFHQSxzQkFBc0JBO29CQUN0QkEsMERBQTBEQTtvQkFDMURBLHNCQUFzQkEsQ0FBQ0E7Z0JBRXRDQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLEVBQUVBLFFBQVFBLENBQUNBO3FCQUNqQ0EsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7cUJBQ25CQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtvQkFDVEEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBQ3JCQSx5QkFBTUEsQ0FBQ0EsdUJBQWdCQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTtvQkFFeEVBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVQQSxxQkFBRUEsQ0FBQ0EsZ0RBQWdEQSxFQUNoREEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7Z0JBQ2xGQSxJQUFJQSxRQUFRQSxHQUNSQSxzQkFBc0JBO29CQUN0QkEsbUZBQW1GQTtvQkFDbkZBLHNCQUFzQkEsQ0FBQ0E7Z0JBRTNCQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLEVBQUVBLFFBQVFBLENBQUNBO3FCQUNqQ0EsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7cUJBQ25CQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtvQkFFVEEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBQ3JCQSx5QkFBTUEsQ0FBQ0EsdUJBQWdCQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtvQkFFdEVBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsVUFBVUEsR0FBR0EsSUFBSUEsQ0FBQ0E7b0JBQ3REQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFDckJBLHlCQUFNQSxDQUFDQSx1QkFBZ0JBLENBQUNBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO29CQUV4RUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSxrRUFBa0VBLEVBQ2xFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtnQkFDbEZBLElBQUlBLFFBQVFBLEdBQ1JBLHNCQUFzQkE7b0JBQ3RCQSxtRkFBbUZBO29CQUNuRkEsc0JBQXNCQSxDQUFDQTtnQkFFM0JBLEdBQUdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsTUFBTUEsRUFBRUEsUUFBUUEsQ0FBQ0E7cUJBQ2pDQSxXQUFXQSxDQUFDQSxNQUFNQSxDQUFDQTtxQkFDbkJBLElBQUlBLENBQUNBLFVBQUNBLE9BQU9BO29CQUNaQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLFVBQVVBLEdBQUdBLElBQUlBLENBQUNBO29CQUN6REEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBQ3hCQSxPQUFPQSxDQUFDQSxPQUFPQSxFQUFFQSxDQUFDQTtvQkFFbEJBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVQQSxxQkFBRUEsQ0FBQ0EsaUNBQWlDQSxFQUNqQ0EseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7Z0JBQ2xGQSxJQUFJQSxRQUFRQSxHQUNSQSxzQkFBc0JBO29CQUN0QkEsbUZBQW1GQTtvQkFDbkZBLHNCQUFzQkEsQ0FBQ0E7Z0JBRTNCQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLEVBQUVBLFFBQVFBLENBQUNBO3FCQUNqQ0EsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7cUJBQ25CQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtvQkFDVEEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBRXJCQSx5QkFBTUEsQ0FBQ0EsdUJBQWdCQSxDQUFDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtvQkFFL0VBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsSUFBSUEsR0FBR0EsQ0FBQ0EsSUFBSUEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7b0JBQ3hEQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFDckJBLHlCQUFNQSxDQUFDQSx1QkFBZ0JBLENBQUNBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBO29CQUU1RUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLDJCQUFRQSxDQUFDQSx1QkFBdUJBLEVBQUVBO1lBQ2hDQSxxQkFBRUEsQ0FBQ0Esc0RBQXNEQSxFQUN0REEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7Z0JBQ2xGQSxJQUFJQSxRQUFRQSxHQUFHQSw0REFBNERBLENBQUNBO2dCQUM1RUEsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxNQUFNQSxFQUFFQSxRQUFRQSxDQUFDQTtxQkFDakNBLFdBQVdBLENBQUNBLE1BQU1BLENBQUNBO3FCQUNuQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7b0JBQ1RBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUNyQkEsSUFBSUEsUUFBUUEsR0FBYUEsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0E7b0JBRXhFQSx5QkFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsRUFBRUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxRQUFRQSxDQUFDQSxLQUFLQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxRQUFRQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTt5QkFDekVBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO29CQUNoQkEseUJBQU1BLENBQUNBLFFBQVFBLENBQUNBLEVBQUVBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0E7eUJBQzlFQSxJQUFJQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtvQkFFaEJBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVUQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsU0FBU0EsRUFBRUE7WUFDbEJBLHFCQUFFQSxDQUFDQSwrQkFBK0JBLEVBQy9CQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtnQkFDbEZBLElBQUlBLFFBQVFBLEdBQUdBLGtCQUFrQkE7b0JBQ2xCQSxzQkFBc0JBO29CQUN0QkEseUNBQXlDQTtvQkFDekNBLGdCQUFnQkEsQ0FBQ0E7Z0JBRWhDQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLEVBQUVBLFFBQVFBLENBQUNBO3FCQUNqQ0EsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7cUJBQ25CQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtvQkFDVEEsSUFBSUEsQ0FBQ0EsR0FBR0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7b0JBQ3BEQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFFckJBLHlCQUFpQkEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsT0FBT0EsRUFBRUEsVUFBQ0EsQ0FBQ0E7d0JBQzdDQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7d0JBQ3hDQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7d0JBQ3ZDQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtvQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRUhBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsVUFBVUEsR0FBR0EsSUFBSUEsQ0FBQ0E7b0JBQ3REQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtnQkFDdkJBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSw2REFBNkRBLEVBQzdEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtnQkFDbEZBLElBQUlBLFFBQVFBLEdBQUdBLHdCQUF3QkE7b0JBQ3hCQSx3QkFBd0JBO29CQUN4QkEsc0JBQXNCQTtvQkFDdEJBLHFCQUFxQkE7b0JBQ3JCQSxxQkFBcUJBLENBQUNBO2dCQUVyQ0EsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxNQUFNQSxFQUFFQSxRQUFRQSxDQUFDQTtxQkFDakNBLFdBQVdBLENBQUNBLE1BQU1BLENBQUNBO3FCQUNuQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7b0JBQ1RBLElBQUlBLEVBQUVBLEdBQUdBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFFBQVFBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO29CQUN0REEsSUFBSUEsRUFBRUEsR0FBR0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7b0JBRXREQSxJQUFJQSxPQUFPQSxHQUFHQSxLQUFLQSxDQUFDQTtvQkFFcEJBLHlCQUFpQkEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsT0FBT0EsRUFBRUEsVUFBQ0EsQ0FBQ0EsSUFBT0EsT0FBT0EsR0FBR0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQzFFQSx5QkFBaUJBLENBQUNBLFNBQVNBLENBQUNBLEVBQUVBLENBQUNBLEtBQUtBLENBQUNBLE9BQU9BLEVBQUVBLFVBQUNBLENBQUNBO3dCQUM5Q0EseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO3dCQUMzQkEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7b0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO29CQUVIQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtnQkFDdkJBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSxzRkFBc0ZBLEVBQ3RGQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtnQkFDbEZBLElBQUlBLFFBQVFBLEdBQUdBLHlFQUF5RUEsQ0FBQ0E7Z0JBRXpGQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLEVBQUVBLFFBQVFBLENBQUNBO3FCQUNqQ0EsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7cUJBQ25CQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtvQkFDVEEsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxVQUFVQSxHQUFHQSxJQUFJQSxDQUFDQTtvQkFDdERBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUVyQkEsSUFBSUEsQ0FBQ0EsR0FBZUEsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7b0JBRWhFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRWxDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLFVBQVVBLEdBQUdBLEtBQUtBLENBQUNBO29CQUN2REEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBRXJCQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLFVBQVVBLEdBQUdBLElBQUlBLENBQUNBO29CQUN0REEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBRXJCQSxJQUFJQSxFQUFFQSxHQUFlQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtvQkFFakVBLHlCQUFNQSxDQUFDQSxFQUFFQSxDQUFDQSxLQUFLQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFbkNBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EseUJBQXlCQSxFQUFFQTtZQUNsQ0EscUJBQUVBLENBQUNBLHFGQUFxRkEsRUFDckZBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO2dCQUNsRkEsSUFBSUEsUUFBUUEsR0FBR0EsaUNBQWlDQTtvQkFDakNBLHVFQUF1RUE7b0JBQ3ZFQSwrQkFBK0JBLENBQUNBO2dCQUUvQ0EsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxNQUFNQSxFQUFFQSxRQUFRQSxDQUFDQTtxQkFDakNBLFdBQVdBLENBQUNBLE1BQU1BLENBQUNBO3FCQUNuQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7b0JBQ1RBLElBQUlBLENBQUNBLEdBQUdBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO29CQUVwREEsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxJQUFJQSxHQUFHQSxDQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtvQkFFeERBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUVyQkEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLEtBQUtBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLElBQUlBLENBQUNBLENBQUNBO29CQUN6Q0EseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLElBQUlBLENBQUNBLENBQUNBO29CQUV4Q0EsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSxrREFBa0RBLEVBQ2xEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtnQkFDbEZBLElBQUlBLFFBQVFBLEdBQUdBLGtDQUFrQ0E7b0JBQ2xDQSw4Q0FBOENBO29CQUM5Q0EsOENBQThDQTtvQkFDOUNBLGdDQUFnQ0EsQ0FBQ0E7Z0JBRWhEQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLEVBQUVBLFFBQVFBLENBQUNBO3FCQUNqQ0EsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7cUJBQ25CQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtvQkFDVEEsSUFBSUEsQ0FBQ0EsR0FBR0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7b0JBQ3BEQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFFckJBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxLQUFLQSxDQUFDQSxLQUFLQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQTtvQkFDMUNBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxLQUFLQSxDQUFDQSxJQUFJQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQTtvQkFFekNBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVQQSxxQkFBRUEsQ0FBQ0EsZ0RBQWdEQSxFQUNoREEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7Z0JBQ2xGQSxJQUFJQSxRQUFRQSxHQUFHQSxpQ0FBaUNBO29CQUNqQ0EsdUVBQXVFQTtvQkFDdkVBLCtCQUErQkEsQ0FBQ0E7Z0JBRS9DQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLEVBQUVBLFFBQVFBLENBQUNBO3FCQUNqQ0EsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7cUJBQ25CQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtvQkFDVEEsSUFBSUEsQ0FBQ0EsR0FBR0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7b0JBRXBEQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLElBQUlBLEdBQUdBLENBQUNBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO29CQUV4REEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBRXJCQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLElBQUlBLEdBQUdBLENBQUNBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO29CQUV4REEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBRXJCQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7b0JBRXhDQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFUEEscUJBQUVBLENBQUNBLDZFQUE2RUEsRUFDN0VBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO2dCQUNsRkEsSUFBSUEsUUFBUUEsR0FBR0EsaUNBQWlDQTtvQkFDakNBLHVDQUF1Q0E7b0JBQ3ZDQSxnQ0FBZ0NBO29CQUNoQ0EsUUFBUUE7b0JBQ1JBLCtCQUErQkEsQ0FBQ0E7Z0JBRS9DQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLEVBQUVBLFFBQVFBLENBQUNBO3FCQUNqQ0EsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7cUJBQ25CQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtvQkFDVEEsSUFBSUEsQ0FBQ0EsR0FBR0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7b0JBRXBEQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLElBQUlBLEdBQUdBLENBQUNBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO29CQUV4REEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBRXJCQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7b0JBQ3JEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7b0JBRXBEQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFUEEscUJBQUVBLENBQUNBLDZFQUE2RUEsRUFDN0VBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO2dCQUNsRkEsSUFBSUEsUUFBUUEsR0FBR0EsOEJBQThCQTtvQkFDOUJBLGtEQUFrREE7b0JBQ2xEQSw0QkFBNEJBLENBQUNBO2dCQUU1Q0EsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxNQUFNQSxFQUFFQSxRQUFRQSxDQUFDQTtxQkFDakNBLFdBQVdBLENBQUNBLE1BQU1BLENBQUNBO3FCQUNuQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7b0JBQ1RBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUVyQkEseUJBQU1BLENBQUNBLHVCQUFnQkEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsY0FBY0EsQ0FBQ0EsQ0FBQ0E7b0JBRWhGQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFUEEscUJBQUVBLENBQUNBLHdEQUF3REEsRUFDeERBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO2dCQUNsRkEsSUFBSUEsUUFBUUEsR0FBR0Esd0VBQXdFQSxDQUFDQTtnQkFFeEZBLEdBQUdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsTUFBTUEsRUFBRUEsUUFBUUEsQ0FBQ0E7cUJBQ2pDQSxXQUFXQSxDQUFDQSxNQUFNQSxDQUFDQTtxQkFDbkJBLElBQUlBLENBQUNBLFVBQUNBLElBQUlBO29CQUNUQSxJQUFJQSxDQUFDQSxHQUEwQkEsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7b0JBQzNFQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFFckJBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxLQUFLQSxDQUFDQSxLQUFLQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTtvQkFFdkRBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVQQSxxQkFBRUEsQ0FBQ0EscURBQXFEQSxFQUNyREEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7Z0JBQ2xGQSxJQUFJQSxRQUFRQSxHQUFHQSxnREFBZ0RBLENBQUNBO2dCQUVoRUEsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxNQUFNQSxFQUFFQSxRQUFRQSxDQUFDQTtxQkFDakNBLFdBQVdBLENBQUNBLE1BQU1BLENBQUNBO3FCQUNuQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7b0JBQ1RBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUVyQkEsSUFBSUEsQ0FBQ0EsR0FBR0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7b0JBRXBEQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFFckJBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxlQUFlQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDNUNBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSw2QkFBNkJBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUVuREEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVRBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLDJCQUFRQSxDQUFDQSxzQkFBc0JBLEVBQUVBO1lBQy9CQSxxQkFBRUEsQ0FBQ0EsZ0ZBQWdGQSxFQUNoRkEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7Z0JBQ2xGQSxJQUFJQSxRQUFRQSxHQUFHQSxxRUFBcUVBLENBQUNBO2dCQUVyRkEsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxNQUFNQSxFQUFFQSxRQUFRQSxDQUFDQTtxQkFDakNBLFdBQVdBLENBQUNBLE1BQU1BLENBQUNBO3FCQUNuQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7b0JBQ1RBLElBQUlBLENBQUNBLEdBQW1CQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtvQkFFcEVBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUVyQkEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLFVBQUNBLENBQWdCQSxJQUFLQSxPQUFBQSxDQUFDQSxDQUFDQSxJQUFJQSxFQUFOQSxDQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxHQUFHQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFaEZBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVQQSxxQkFBRUEsQ0FBQ0EsMERBQTBEQSxFQUMxREEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7Z0JBQ2xGQSxJQUFJQSxRQUFRQSxHQUFHQSxzREFBc0RBLENBQUNBO2dCQUV0RUEsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxNQUFNQSxFQUFFQSxRQUFRQSxDQUFDQTtxQkFDakNBLFdBQVdBLENBQUNBLE1BQU1BLENBQUNBO3FCQUNuQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7b0JBQ1RBLElBQUlBLENBQUNBLEdBQW1CQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtvQkFFcEVBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUVyQkEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLFVBQUNBLENBQWdCQSxJQUFLQSxPQUFBQSxDQUFDQSxDQUFDQSxJQUFJQSxFQUFOQSxDQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxHQUFHQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFaEZBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVQQSxxQkFBRUEsQ0FBQ0EseUNBQXlDQSxFQUN6Q0EseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7Z0JBQ2xGQSxJQUFJQSxRQUFRQSxHQUFHQSxnREFBZ0RBLENBQUNBO2dCQUVoRUEsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxNQUFNQSxFQUFFQSxRQUFRQSxDQUFDQTtxQkFDakNBLFdBQVdBLENBQUNBLE1BQU1BLENBQUNBO3FCQUNuQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7b0JBQ1RBLElBQUlBLENBQUNBLEdBQXFCQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtvQkFFdEVBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUVyQkEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUUvQkEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsR0FBR0EsSUFBSUEsQ0FBQ0E7b0JBQ2RBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUNyQkEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUUvQkEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLEtBQUtBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO29CQUV4Q0EsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSwwREFBMERBLEVBQzFEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtnQkFDbEZBLElBQUlBLFFBQVFBLEdBQUdBLDhEQUE4REEsQ0FBQ0E7Z0JBRTlFQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLEVBQUVBLFFBQVFBLENBQUNBO3FCQUNqQ0EsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7cUJBQ25CQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtvQkFDVEEsSUFBSUEsQ0FBQ0EsR0FBMkJBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO29CQUU1RUEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBRXJCQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ2xDQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7b0JBRXhDQSxDQUFDQSxDQUFDQSxJQUFJQSxHQUFHQSxLQUFLQSxDQUFDQTtvQkFDZkEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBRXJCQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ2xDQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7b0JBRXhDQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFHUEEscUJBQUVBLENBQUNBLHVGQUF1RkEsRUFDdkZBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO2dCQUNsRkEsSUFBSUEsUUFBUUEsR0FBR0Esc0RBQXNEQSxDQUFDQTtnQkFFdEVBLEdBQUdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsTUFBTUEsRUFBRUEsUUFBUUEsQ0FBQ0E7cUJBQ2pDQSxXQUFXQSxDQUFDQSxNQUFNQSxDQUFDQTtxQkFDbkJBLElBQUlBLENBQUNBLFVBQUNBLElBQUlBO29CQUNUQSxJQUFJQSxDQUFDQSxHQUF3QkEsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7b0JBRXpFQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFFckJBLHlCQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxLQUFLQSxDQUFDQSxHQUFHQSxDQUFDQSxVQUFDQSxDQUFnQkEsSUFBS0EsT0FBQUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsRUFBTkEsQ0FBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBRWhGQSxDQUFDQSxDQUFDQSxJQUFJQSxHQUFHQSxDQUFDQSxJQUFJQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQTtvQkFDckJBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUdyQkEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLFVBQUNBLENBQWdCQSxJQUFLQSxPQUFBQSxDQUFDQSxDQUFDQSxJQUFJQSxFQUFOQSxDQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxHQUFHQSxFQUFFQSxJQUFJQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFakZBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVQQSxxQkFBRUEsQ0FBQ0EsdUZBQXVGQSxFQUN2RkEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7Z0JBQ2xGQSxJQUFJQSxRQUFRQSxHQUFHQSxvRUFBb0VBLENBQUNBO2dCQUVwRkEsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxNQUFNQSxFQUFFQSxRQUFRQSxDQUFDQTtxQkFDakNBLFdBQVdBLENBQUNBLE1BQU1BLENBQUNBO3FCQUNuQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBSUE7b0JBQ1RBLElBQUlBLENBQUNBLEdBQWtDQSxJQUFJQSxDQUFDQSxZQUFZQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtvQkFFbkZBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUVyQkEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLFVBQUNBLENBQWdCQSxJQUFLQSxPQUFBQSxDQUFDQSxDQUFDQSxJQUFJQSxFQUFOQSxDQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxHQUFHQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFFaEZBLENBQUNBLENBQUNBLElBQUlBLEdBQUdBLENBQUNBLElBQUlBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBO29CQUNyQkEsSUFBSUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBR3JCQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsVUFBQ0EsQ0FBZ0JBLElBQUtBLE9BQUFBLENBQUNBLENBQUNBLElBQUlBLEVBQU5BLENBQU1BLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLEdBQUdBLEVBQUVBLElBQUlBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBO29CQUVqRkEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSxpQ0FBaUNBLEVBQ2pDQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtnQkFDbEZBLElBQUlBLFFBQVFBLEdBQUdBLHNEQUFzREEsQ0FBQ0E7Z0JBRXRFQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE1BQU1BLEVBQUVBLFFBQVFBLENBQUNBO3FCQUNqQ0EsV0FBV0EsQ0FBQ0EsTUFBTUEsQ0FBQ0E7cUJBQ25CQSxJQUFJQSxDQUFDQSxVQUFDQSxJQUFJQTtvQkFDVEEsSUFBSUEsQ0FBQ0EsR0FBd0JBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO29CQUV6RUEsd0RBQXdEQTtvQkFDeERBLEdBQUdBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLEVBQUVBLENBQUNBLEdBQUdBLEVBQUVBLEVBQUVBLENBQUNBLEVBQUVBLEVBQUVBLENBQUNBO3dCQUM1QkEsSUFBSUEsU0FBU0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0E7d0JBQzdCQSxDQUFDQSxDQUFDQSxJQUFJQSxHQUFHQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQTt3QkFDckJBLElBQUlBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO3dCQUVyQkEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLFVBQUNBLENBQWdCQSxJQUFLQSxPQUFBQSxDQUFDQSxDQUFDQSxJQUFJQSxFQUFOQSxDQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxHQUFHQSxFQUFFQSxTQUFTQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDbkZBLENBQUNBO29CQUVEQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFUEEscUJBQUVBLENBQUNBLHdDQUF3Q0EsRUFDeENBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO2dCQUNsRkEsSUFBSUEsUUFBUUEsR0FBR0Esa0VBQWtFQSxDQUFDQTtnQkFFbEZBLEdBQUdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsTUFBTUEsRUFBRUEsUUFBUUEsQ0FBQ0E7cUJBQ2pDQSxXQUFXQSxDQUFDQSxNQUFNQSxDQUFDQTtxQkFDbkJBLElBQUlBLENBQUNBLFVBQUNBLElBQUlBO29CQUNUQSxJQUFJQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFFckJBLElBQUlBLENBQUNBLEdBQUdBLElBQUlBLENBQUNBLFlBQVlBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFFBQVFBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO29CQUNwREEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLFdBQVdBLEVBQUVBLENBQUNBO29CQUMvQkEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLFdBQVdBLEVBQUVBLENBQUNBO29CQUMvQkEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLFdBQVdBLEVBQUVBLENBQUNBO29CQUMvQkEseUJBQU1BLENBQUNBLENBQUNBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLFdBQVdBLEVBQUVBLENBQUNBO29CQUUvQkEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBO0lBQ0xBLENBQUNBLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBdm9CZSxZQUFJLE9BdW9CbkIsQ0FBQTtBQUVEO0lBSUVDO0lBQWVDLENBQUNBO0lBSmxCRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsUUFBUUEsRUFBRUEsTUFBTUEsRUFBRUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsRUFBRUEsUUFBUUEsRUFBRUEsU0FBU0EsRUFBQ0EsQ0FBQ0E7UUFDdEVBLGlCQUFVQSxFQUFFQTs7c0JBSVpBO0lBQURBLG9CQUFDQTtBQUFEQSxDQUFDQSxBQUxELElBS0M7QUFFRDtJQUFBRTtJQU1BQyxDQUFDQTtJQURDRCxpREFBa0JBLEdBQWxCQSxjQUF1QkUsSUFBSUEsQ0FBQ0EsZ0NBQWdDQSxHQUFHQSxJQUFJQSxDQUFDQSxlQUFlQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUg3RkY7UUFBQ0Esc0JBQWVBLENBQUNBLGFBQWFBLENBQUNBOztPQUFDQSxpREFBZUEsVUFBMkJBO0lBRjVFQTtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsd0JBQXdCQSxFQUFFQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7NkJBTTdEQTtJQUFEQSwyQkFBQ0E7QUFBREEsQ0FBQ0EsQUFORCxJQU1DO0FBRUQ7SUFBQUc7SUFPQUMsQ0FBQ0E7SUFEQ0QsMkNBQWVBLEdBQWZBLGNBQW9CRSxJQUFJQSxDQUFDQSw2QkFBNkJBLEdBQUdBLElBQUlBLENBQUNBLGVBQWVBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLENBQUNBO0lBSHZGRjtRQUFDQSxtQkFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0E7O09BQUNBLDhDQUFlQSxVQUEyQkE7SUFIekVBO1FBQUNBLGdCQUFTQSxDQUNOQSxFQUFDQSxRQUFRQSxFQUFFQSxxQkFBcUJBLEVBQUVBLFFBQVFBLEVBQUVBLGtCQUFrQkEsRUFBRUEsVUFBVUEsRUFBRUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7OzBCQU1oR0E7SUFBREEsd0JBQUNBO0FBQURBLENBQUNBLEFBUEQsSUFPQztBQUVEO0lBQUFHO1FBV0VDLFFBQUdBLEdBQUdBLEVBQUVBLENBQUNBO0lBT1hBLENBQUNBO0lBZENELHNCQUNJQSxvQ0FBS0E7YUFLVEEsY0FBY0UsTUFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7YUFObkNGLFVBQ1VBLEtBQUtBO1lBQ2JFLElBQUlBLENBQUNBLE1BQU1BLEdBQUdBLEtBQUtBLENBQUNBO1lBQ3BCQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxRQUFRQSxFQUFFQSxnQkFBU0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsR0FBR0EsS0FBS0EsQ0FBQ0EsSUFBSUEsR0FBR0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDbEVBLENBQUNBOzs7T0FBQUY7SUFLREEsOENBQWtCQSxHQUFsQkEsY0FBdUJHLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLE1BQU1BLEVBQUVBLGdCQUFTQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxHQUFHQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxJQUFJQSxHQUFHQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUVqR0gsaURBQXFCQSxHQUFyQkE7UUFDRUksSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsRUFBRUEsZ0JBQVNBLENBQUNBLElBQUlBLENBQUNBLEtBQUtBLENBQUNBLEdBQUdBLElBQUlBLENBQUNBLEtBQUtBLENBQUNBLElBQUlBLEdBQUdBLElBQUlBLENBQUNBLENBQUNBLENBQUNBO0lBQzNFQSxDQUFDQTtJQWJESjtRQUFDQSxtQkFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0E7OztPQUN4QkEsb0NBQUtBLFFBR1JBO0lBUkhBO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxxQkFBcUJBLEVBQUVBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOzswQkFrQjFEQTtJQUFEQSx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFsQkQsSUFrQkM7QUFFRDtJQUFBSztRQVNFQyxlQUFVQSxHQUFZQSxJQUFJQSxDQUFDQTtRQVUzQkEsUUFBR0EsR0FBR0EsRUFBRUEsQ0FBQ0E7SUFLWEEsQ0FBQ0E7SUFaQ0Qsc0JBQ0lBLGlDQUFLQTthQUtUQSxjQUFjRSxNQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQTthQU5uQ0YsVUFDVUEsS0FBS0E7WUFDYkUsSUFBSUEsQ0FBQ0EsTUFBTUEsR0FBR0EsS0FBS0EsQ0FBQ0E7WUFDcEJBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLFFBQVFBLEVBQUVBLGdCQUFTQSxDQUFDQSxLQUFLQSxDQUFDQSxHQUFHQSxLQUFLQSxDQUFDQSxJQUFJQSxHQUFHQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNsRUEsQ0FBQ0E7OztPQUFBRjtJQUtEQSx3Q0FBZUEsR0FBZkEsY0FBb0JHLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLE1BQU1BLEVBQUVBLGdCQUFTQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxHQUFHQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxJQUFJQSxHQUFHQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUU5RkgsMkNBQWtCQSxHQUFsQkEsY0FBdUJJLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLE9BQU9BLEVBQUVBLGdCQUFTQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxHQUFHQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxJQUFJQSxHQUFHQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQVhsR0o7UUFBQ0EsZ0JBQVNBLENBQUNBLGFBQWFBLENBQUNBOzs7T0FDckJBLGlDQUFLQSxRQUdSQTtJQWhCSEE7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLGtCQUFrQkE7WUFDNUJBLFFBQVFBLEVBQUVBLHlEQUVUQTtZQUNEQSxVQUFVQSxFQUFFQSxDQUFDQSxhQUFJQSxFQUFFQSxhQUFhQSxDQUFDQTtTQUNsQ0EsQ0FBQ0E7O3VCQWtCREE7SUFBREEscUJBQUNBO0FBQURBLENBQUNBLEFBeEJELElBd0JDO0FBRUQ7SUFHRUs7SUFBZUMsQ0FBQ0E7SUFIbEJEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxPQUFPQSxFQUFDQSxDQUFDQTtRQUM5QkEsaUJBQVVBLEVBQUVBOzt1QkFHWkE7SUFBREEscUJBQUNBO0FBQURBLENBQUNBLEFBSkQsSUFJQztBQUVEO0lBUUVFLG9CQUFrQ0EsS0FBK0JBO1FBQUlDLElBQUlBLENBQUNBLEtBQUtBLEdBQUdBLEtBQUtBLENBQUNBO0lBQUNBLENBQUNBO0lBUjVGRDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsYUFBYUE7WUFDdkJBLFVBQVVBLEVBQUVBLENBQUNBLGNBQUtBLEVBQUVBLGFBQWFBLENBQUNBO1lBQ2xDQSxRQUFRQSxFQUFFQSwyRUFBMkVBO1NBQ3RGQSxDQUFDQTtRQUNEQSxpQkFBVUEsRUFBRUE7UUFHQ0EsV0FBQ0EsWUFBS0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQUE7O21CQUNsQ0E7SUFBREEsaUJBQUNBO0FBQURBLENBQUNBLEFBVEQsSUFTQztBQUVEO0lBQUFFO0lBTUFDLENBQUNBO0lBSkNEO1FBQUNBLG1CQUFZQSxDQUFDQSxhQUFhQSxDQUFDQTs7T0FBQ0Esb0NBQU1BLFVBQWdCQTtJQUNuREE7UUFBQ0EsbUJBQVlBLENBQUNBLGFBQWFBLENBQUNBOztPQUFDQSxvQ0FBTUEsVUFBZ0JBO0lBQ25EQTtRQUFDQSxtQkFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0E7O09BQUNBLG9DQUFNQSxVQUFnQkE7SUFDbkRBO1FBQUNBLG1CQUFZQSxDQUFDQSxhQUFhQSxDQUFDQTs7T0FBQ0Esb0NBQU1BLFVBQWdCQTtJQUxyREE7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLG9CQUFvQkEsRUFBRUEsUUFBUUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7O3lCQU16REE7SUFBREEsdUJBQUNBO0FBQURBLENBQUNBLEFBTkQsSUFNQztBQUVEO0lBUUVFLHdCQUF1REEsS0FBK0JBO1FBQ3BGQyxJQUFJQSxDQUFDQSxLQUFLQSxHQUFHQSxLQUFLQSxDQUFDQTtJQUNyQkEsQ0FBQ0E7SUFWSEQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLGtCQUFrQkE7WUFDNUJBLFVBQVVBLEVBQUVBLENBQUNBLGNBQUtBLENBQUNBO1lBQ25CQSxRQUFRQSxFQUFFQSxvREFBb0RBO1NBQy9EQSxDQUFDQTtRQUNEQSxpQkFBVUEsRUFBRUE7UUFHQ0EsV0FBQ0EsWUFBS0EsQ0FBQ0EsYUFBYUEsRUFBRUEsRUFBQ0EsV0FBV0EsRUFBRUEsSUFBSUEsRUFBQ0EsQ0FBQ0EsQ0FBQUE7O3VCQUd2REE7SUFBREEscUJBQUNBO0FBQURBLENBQUNBLEFBWEQsSUFXQztBQUVEO0lBSUVFLDJCQUFxREEsS0FBcUJBO1FBQ3hFQyxJQUFJQSxDQUFDQSxLQUFLQSxHQUFHQSxLQUFLQSxDQUFDQTtJQUNyQkEsQ0FBQ0E7SUFOSEQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLDRCQUE0QkEsRUFBRUEsVUFBVUEsRUFBRUEsRUFBRUEsRUFBRUEsUUFBUUEsRUFBRUEsY0FBY0EsRUFBQ0EsQ0FBQ0E7UUFDN0ZBLGlCQUFVQSxFQUFFQTtRQUdDQSxXQUFDQSxZQUFLQSxDQUFDQSxXQUFXQSxFQUFFQSxFQUFDQSxXQUFXQSxFQUFFQSxJQUFJQSxFQUFDQSxDQUFDQSxDQUFBQTs7MEJBR3JEQTtJQUFEQSx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFQRCxJQU9DO0FBRUQ7SUFRRUUsK0JBQW9DQSxLQUFxQkE7UUFBSUMsSUFBSUEsQ0FBQ0EsS0FBS0EsR0FBR0EsS0FBS0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFScEZEO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxpQ0FBaUNBO1lBQzNDQSxVQUFVQSxFQUFFQSxFQUFFQTtZQUNkQSxRQUFRQSxFQUFFQSw0QkFBNEJBO1NBQ3ZDQSxDQUFDQTtRQUNEQSxpQkFBVUEsRUFBRUE7UUFHQ0EsV0FBQ0EsZ0JBQVNBLENBQUNBLFdBQVdBLENBQUNBLENBQUFBOzs4QkFDcENBO0lBQURBLDRCQUFDQTtBQUFEQSxDQUFDQSxBQVRELElBU0M7QUFFRDtJQUlFRSwrQkFBaUVBLEtBQXFCQTtRQUNwRkMsSUFBSUEsQ0FBQ0EsS0FBS0EsR0FBR0EsS0FBS0EsQ0FBQ0E7SUFDckJBLENBQUNBO0lBTkhEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSw2QkFBNkJBLEVBQUVBLFVBQVVBLEVBQUVBLEVBQUVBLEVBQUVBLFFBQVFBLEVBQUVBLGNBQWNBLEVBQUNBLENBQUNBO1FBQzlGQSxpQkFBVUEsRUFBRUE7UUFHQ0EsV0FBQ0EsWUFBS0EsQ0FBQ0EsdUJBQXVCQSxFQUFFQSxFQUFDQSxXQUFXQSxFQUFFQSxJQUFJQSxFQUFDQSxDQUFDQSxDQUFBQTs7OEJBR2pFQTtJQUFEQSw0QkFBQ0E7QUFBREEsQ0FBQ0EsQUFQRCxJQU9DO0FBRUQ7SUFRRUUsOEJBQWtDQSxLQUErQkE7UUFBSUMsSUFBSUEsQ0FBQ0EsS0FBS0EsR0FBR0EsS0FBS0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFSNUZEO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSx5QkFBeUJBO1lBQ25DQSxVQUFVQSxFQUFFQSxDQUFDQSxjQUFLQSxDQUFDQTtZQUNuQkEsUUFBUUEsRUFBRUEsNkVBQTZFQTtTQUN4RkEsQ0FBQ0E7UUFDREEsaUJBQVVBLEVBQUVBO1FBR0NBLFdBQUNBLFlBQUtBLENBQUNBLGFBQWFBLENBQUNBLENBQUFBOzs2QkFDbENBO0lBQURBLDJCQUFDQTtBQUFEQSxDQUFDQSxBQVRELElBU0M7QUFFRDtJQVNFRSx3QkFBc0NBLEtBQStCQTtRQUFJQyxJQUFJQSxDQUFDQSxLQUFLQSxHQUFHQSxLQUFLQSxDQUFDQTtJQUFDQSxDQUFDQTtJQVRoR0Q7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLGtCQUFrQkE7WUFDNUJBLFVBQVVBLEVBQUVBLENBQUNBLGFBQWFBLENBQUNBO1lBQzNCQSxRQUFRQSxFQUFFQSwwQ0FBMENBO2dCQUN0Q0EsMENBQTBDQTtTQUN6REEsQ0FBQ0E7UUFDREEsaUJBQVVBLEVBQUVBO1FBR0NBLFdBQUNBLGdCQUFTQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFBQTs7dUJBQ3RDQTtJQUFEQSxxQkFBQ0E7QUFBREEsQ0FBQ0EsQUFWRCxJQVVDO0FBRUQ7SUFTRUUsMEJBQXNDQSxLQUErQkE7UUFDbkVDLElBQUlBLENBQUNBLEtBQUtBLEdBQUdBLEtBQUtBLENBQUNBO1FBQ25CQSxJQUFJQSxDQUFDQSxJQUFJQSxHQUFHQSxLQUFLQSxDQUFDQTtJQUNwQkEsQ0FBQ0E7SUFaSEQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLHFCQUFxQkE7WUFDL0JBLFVBQVVBLEVBQUVBLENBQUNBLGFBQUlBLEVBQUVBLGFBQWFBLENBQUNBO1lBQ2pDQSxRQUFRQSxFQUFFQSxtQ0FBbUNBO1NBQzlDQSxDQUFDQTtRQUNEQSxpQkFBVUEsRUFBRUE7UUFJQ0EsV0FBQ0EsZ0JBQVNBLENBQUNBLGFBQWFBLENBQUNBLENBQUFBOzt5QkFJdENBO0lBQURBLHVCQUFDQTtBQUFEQSxDQUFDQSxBQWJELElBYUM7QUFHRDtJQVNFRSxnQ0FBc0NBLEtBQStCQTtRQUNuRUMsSUFBSUEsQ0FBQ0EsS0FBS0EsR0FBR0EsS0FBS0EsQ0FBQ0E7UUFDbkJBLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLElBQUlBLENBQUNBO0lBQ25CQSxDQUFDQTtJQVpIRDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsNEJBQTRCQTtZQUN0Q0EsVUFBVUEsRUFBRUEsQ0FBQ0EsYUFBSUEsRUFBRUEsY0FBY0EsRUFBRUEsYUFBYUEsQ0FBQ0E7WUFDakRBLFFBQVFBLEVBQUVBLDZEQUE2REE7U0FDeEVBLENBQUNBO1FBQ0RBLGlCQUFVQSxFQUFFQTtRQUlDQSxXQUFDQSxnQkFBU0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQUE7OytCQUl0Q0E7SUFBREEsNkJBQUNBO0FBQURBLENBQUNBLEFBYkQsSUFhQztBQUVEO0lBV0VFLDZCQUFzQ0EsS0FBK0JBO1FBQ25FQyxJQUFJQSxDQUFDQSxLQUFLQSxHQUFHQSxLQUFLQSxDQUFDQTtRQUNuQkEsSUFBSUEsQ0FBQ0EsSUFBSUEsR0FBR0EsQ0FBQ0EsR0FBR0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0E7SUFDekJBLENBQUNBO0lBZEhEO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSx3QkFBd0JBO1lBQ2xDQSxVQUFVQSxFQUFFQSxDQUFDQSxjQUFLQSxFQUFFQSxhQUFhQSxFQUFFQSxjQUFjQSxDQUFDQTtZQUNsREEsUUFBUUEsRUFBRUEsc0JBQXNCQTtnQkFDbEJBLCtDQUErQ0E7Z0JBQy9DQSxzQkFBc0JBO1NBQ3JDQSxDQUFDQTtRQUNEQSxpQkFBVUEsRUFBRUE7UUFJQ0EsV0FBQ0EsZ0JBQVNBLENBQUNBLGFBQWFBLENBQUNBLENBQUFBOzs0QkFJdENBO0lBQURBLDBCQUFDQTtBQUFEQSxDQUFDQSxBQWZELElBZUM7QUFFRDtJQVdFRSx1Q0FBc0NBLEtBQStCQTtRQUNuRUMsSUFBSUEsQ0FBQ0EsS0FBS0EsR0FBR0EsS0FBS0EsQ0FBQ0E7UUFDbkJBLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLENBQUNBLEdBQUdBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBO0lBQ3pCQSxDQUFDQTtJQWRIRDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsK0JBQStCQTtZQUN6Q0EsVUFBVUEsRUFBRUEsQ0FBQ0EsY0FBS0EsRUFBRUEsYUFBYUEsRUFBRUEsY0FBY0EsQ0FBQ0E7WUFDbERBLFFBQVFBLEVBQUVBLCtCQUErQkE7Z0JBQzNCQSwrQ0FBK0NBO2dCQUMvQ0EsNEJBQTRCQTtTQUMzQ0EsQ0FBQ0E7UUFDREEsaUJBQVVBLEVBQUVBO1FBSUNBLFdBQUNBLGdCQUFTQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFBQTs7c0NBSXRDQTtJQUFEQSxvQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFmRCxJQWVDO0FBRUQ7SUFJRUUsa0JBQW9DQSxTQUFpQ0EsRUFDckNBLEtBQTZCQSxFQUFTQSxFQUFvQkE7UUFBcEJDLE9BQUVBLEdBQUZBLEVBQUVBLENBQWtCQTtRQUN4RkEsSUFBSUEsQ0FBQ0EsU0FBU0EsR0FBR0EsU0FBU0EsQ0FBQ0E7UUFDM0JBLElBQUlBLENBQUNBLEtBQUtBLEdBQUdBLEtBQUtBLENBQUNBO0lBQ3JCQSxDQUFDQTtJQVJIRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsV0FBV0EsRUFBRUEsUUFBUUEsRUFBRUEsc0NBQXNDQSxFQUFDQSxDQUFDQTtRQUl2RUEsV0FBQ0EsZ0JBQVNBLENBQUNBLGtCQUFXQSxDQUFDQSxDQUFBQTtRQUN2QkEsV0FBQ0EsWUFBS0EsQ0FBQ0Esa0JBQVdBLENBQUNBLENBQUFBOztpQkFJaENBO0lBQURBLGVBQUNBO0FBQURBLENBQUNBLEFBVEQsSUFTQztBQUVEO0lBK0JFRTtRQUNFQyxJQUFJQSxDQUFDQSxVQUFVQSxHQUFHQSxLQUFLQSxDQUFDQTtRQUN4QkEsSUFBSUEsQ0FBQ0EsSUFBSUEsR0FBR0EsQ0FBQ0EsSUFBSUEsRUFBRUEsSUFBSUEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7SUFDakNBLENBQUNBO0lBbENIRDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsU0FBU0E7WUFDbkJBLFVBQVVBLEVBQUVBO2dCQUNWQSxVQUFVQTtnQkFDVkEsY0FBY0E7Z0JBQ2RBLGlCQUFpQkE7Z0JBQ2pCQSxxQkFBcUJBO2dCQUNyQkEsb0JBQW9CQTtnQkFDcEJBLGNBQWNBO2dCQUNkQSxnQkFBZ0JBO2dCQUNoQkEsc0JBQXNCQTtnQkFDdEJBLG1CQUFtQkE7Z0JBQ25CQSxxQkFBcUJBO2dCQUNyQkEsNkJBQTZCQTtnQkFDN0JBLG9CQUFvQkE7Z0JBQ3BCQSxpQkFBaUJBO2dCQUNqQkEsY0FBY0E7Z0JBQ2RBLGlCQUFpQkE7Z0JBQ2pCQSxRQUFRQTtnQkFDUkEsYUFBYUE7Z0JBQ2JBLGNBQWNBO2dCQUNkQSxhQUFJQTtnQkFDSkEsY0FBS0E7Z0JBQ0xBLGdCQUFnQkE7YUFDakJBO1lBQ0RBLFFBQVFBLEVBQUVBLEVBQUVBO1NBQ2JBLENBQUNBO1FBQ0RBLGlCQUFVQSxFQUFFQTs7ZUFRWkE7SUFBREEsYUFBQ0E7QUFBREEsQ0FBQ0EsQUFuQ0QsSUFtQ0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBc3luY1Rlc3RDb21wbGV0ZXIsXG4gIGJlZm9yZUVhY2gsXG4gIGRkZXNjcmliZSxcbiAgZGVzY3JpYmUsXG4gIGVsLFxuICBleHBlY3QsXG4gIGlpdCxcbiAgaW5qZWN0LFxuICBpdCxcbiAgeGl0LFxuICBUZXN0Q29tcG9uZW50QnVpbGRlcixcbn0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmltcG9ydCB7aXNQcmVzZW50fSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2xhbmcnO1xuaW1wb3J0IHtPYnNlcnZhYmxlV3JhcHBlcn0gZnJvbSAnYW5ndWxhcjIvc3JjL2ZhY2FkZS9hc3luYyc7XG5cbmltcG9ydCB7XG4gIENvbXBvbmVudCxcbiAgRGlyZWN0aXZlLFxuICBJbmplY3RhYmxlLFxuICBPcHRpb25hbCxcbiAgVGVtcGxhdGVSZWYsXG4gIFF1ZXJ5LFxuICBRdWVyeUxpc3QsXG4gIFZpZXdRdWVyeSxcbiAgQ29udGVudENoaWxkcmVuLFxuICBWaWV3Q2hpbGRyZW4sXG4gIENvbnRlbnRDaGlsZCxcbiAgVmlld0NoaWxkLFxuICBBZnRlckNvbnRlbnRJbml0LFxuICBBZnRlclZpZXdJbml0LFxuICBBZnRlckNvbnRlbnRDaGVja2VkLFxuICBBZnRlclZpZXdDaGVja2VkXG59IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuaW1wb3J0IHtOZ0lmLCBOZ0Zvcn0gZnJvbSAnYW5ndWxhcjIvY29tbW9uJztcbmltcG9ydCB7YXNOYXRpdmVFbGVtZW50cywgVmlld0NvbnRhaW5lclJlZn0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgnUXVlcnkgQVBJJywgKCkgPT4ge1xuICAgIGRlc2NyaWJlKFwicXVlcnlpbmcgYnkgZGlyZWN0aXZlIHR5cGVcIiwgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCBjb250YWluIGFsbCBkaXJlY3QgY2hpbGQgZGlyZWN0aXZlcyBpbiB0aGUgbGlnaHQgZG9tIChjb25zdHJ1Y3RvciknLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHZhciB0ZW1wbGF0ZSA9ICc8ZGl2IHRleHQ9XCIxXCI+PC9kaXY+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8bmVlZHMtcXVlcnkgdGV4dD1cIjJcIj48ZGl2IHRleHQ9XCIzXCI+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8ZGl2IHRleHQ9XCJ0b28tZGVlcFwiPjwvZGl2PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPC9kaXY+PC9uZWVkcy1xdWVyeT4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzxkaXYgdGV4dD1cIjRcIj48L2Rpdj4nO1xuXG4gICAgICAgICAgIHRjYi5vdmVycmlkZVRlbXBsYXRlKE15Q29tcCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKHZpZXcpID0+IHtcbiAgICAgICAgICAgICAgICAgdmlldy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KGFzTmF0aXZlRWxlbWVudHModmlldy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW4pKS50b0hhdmVUZXh0KCcyfDN8Jyk7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgY29udGFpbiBhbGwgZGlyZWN0IGNoaWxkIGRpcmVjdGl2ZXMgaW4gdGhlIGNvbnRlbnQgZG9tJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPVxuICAgICAgICAgICAgICAgJzxuZWVkcy1jb250ZW50LWNoaWxkcmVuICNxPjxkaXYgdGV4dD1cImZvb1wiPjwvZGl2PjwvbmVlZHMtY29udGVudC1jaGlsZHJlbj4nO1xuXG4gICAgICAgICAgIHRjYi5vdmVycmlkZVRlbXBsYXRlKE15Q29tcCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKHZpZXcpID0+IHtcbiAgICAgICAgICAgICAgICAgdmlldy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgdmFyIHEgPSB2aWV3LmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5nZXRMb2NhbCgncScpO1xuXG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChxLnRleHREaXJDaGlsZHJlbi5sZW5ndGgpLnRvRXF1YWwoMSk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChxLm51bWJlck9mQ2hpbGRyZW5BZnRlckNvbnRlbnRJbml0KS50b0VxdWFsKDEpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIGNvbnRhaW4gdGhlIGZpcnN0IGNvbnRlbnQgY2hpbGQnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHZhciB0ZW1wbGF0ZSA9XG4gICAgICAgICAgICAgICAnPG5lZWRzLWNvbnRlbnQtY2hpbGQgI3E+PGRpdiAqbmdJZj1cInNob3VsZFNob3dcIiB0ZXh0PVwiZm9vXCI+PC9kaXY+PC9uZWVkcy1jb250ZW50LWNoaWxkPic7XG5cbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoTXlDb21wLCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigodmlldykgPT4ge1xuICAgICAgICAgICAgICAgICB2aWV3LmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5zaG91bGRTaG93ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgdmlldy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgdmFyIHEgPSB2aWV3LmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5nZXRMb2NhbCgncScpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChxLmxvZykudG9FcXVhbChbW1wic2V0dGVyXCIsIFwiZm9vXCJdLCBbXCJpbml0XCIsIFwiZm9vXCJdLCBbXCJjaGVja1wiLCBcImZvb1wiXV0pO1xuXG4gICAgICAgICAgICAgICAgIHZpZXcuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLnNob3VsZFNob3cgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgdmlldy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgLy8gVE9ETzogdGhpcyBmYWlscyByaWdodCBub3chXG4gICAgICAgICAgICAgICAgIC8vIC0+IHF1ZXJpZXMgYXJlIG5vdCBkaXJ0aWVkIVxuICAgICAgICAgICAgICAgICBleHBlY3QocS5sb2cpLnRvRXF1YWwoW1xuICAgICAgICAgICAgICAgICAgIFtcInNldHRlclwiLCBcImZvb1wiXSxcbiAgICAgICAgICAgICAgICAgICBbXCJpbml0XCIsIFwiZm9vXCJdLFxuICAgICAgICAgICAgICAgICAgIFtcImNoZWNrXCIsIFwiZm9vXCJdLFxuICAgICAgICAgICAgICAgICAgIFtcInNldHRlclwiLCBudWxsXSxcbiAgICAgICAgICAgICAgICAgICBbXCJjaGVja1wiLCBudWxsXVxuICAgICAgICAgICAgICAgICBdKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBjb250YWluIHRoZSBmaXJzdCB2aWV3IGNoaWxkJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPG5lZWRzLXZpZXctY2hpbGQgI3E+PC9uZWVkcy12aWV3LWNoaWxkPic7XG5cbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoTXlDb21wLCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigodmlldykgPT4ge1xuICAgICAgICAgICAgICAgICB2aWV3LmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgdmFyIHEgPSB2aWV3LmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5nZXRMb2NhbCgncScpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChxLmxvZykudG9FcXVhbChbW1wic2V0dGVyXCIsIFwiZm9vXCJdLCBbXCJpbml0XCIsIFwiZm9vXCJdLCBbXCJjaGVja1wiLCBcImZvb1wiXV0pO1xuXG4gICAgICAgICAgICAgICAgIHEuc2hvdWxkU2hvdyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICB2aWV3LmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICBleHBlY3QocS5sb2cpLnRvRXF1YWwoW1xuICAgICAgICAgICAgICAgICAgIFtcInNldHRlclwiLCBcImZvb1wiXSxcbiAgICAgICAgICAgICAgICAgICBbXCJpbml0XCIsIFwiZm9vXCJdLFxuICAgICAgICAgICAgICAgICAgIFtcImNoZWNrXCIsIFwiZm9vXCJdLFxuICAgICAgICAgICAgICAgICAgIFtcInNldHRlclwiLCBudWxsXSxcbiAgICAgICAgICAgICAgICAgICBbXCJjaGVja1wiLCBudWxsXVxuICAgICAgICAgICAgICAgICBdKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBjb250YWluIHRoZSBmaXJzdCB2aWV3IGNoaWxkIGFjY3Jvc3MgZW1iZWRkZWQgdmlld3MnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHZhciB0ZW1wbGF0ZSA9ICc8bmVlZHMtdmlldy1jaGlsZCAjcT48L25lZWRzLXZpZXctY2hpbGQ+JztcbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoTXlDb21wLCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAgIC5vdmVycmlkZVRlbXBsYXRlKFxuICAgICAgICAgICAgICAgICAgIE5lZWRzVmlld0NoaWxkLFxuICAgICAgICAgICAgICAgICAgICc8ZGl2ICpuZ0lmPVwidHJ1ZVwiPjxkaXYgKm5nSWY9XCJzaG91bGRTaG93XCIgdGV4dD1cImZvb1wiPjwvZGl2PjwvZGl2PicpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKHZpZXcpID0+IHtcbiAgICAgICAgICAgICAgICAgdmlldy5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgIHZhciBxID0gdmlldy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uZ2V0TG9jYWwoJ3EnKTtcblxuICAgICAgICAgICAgICAgICBleHBlY3QocS5sb2cpLnRvRXF1YWwoW1tcInNldHRlclwiLCBcImZvb1wiXSwgW1wiaW5pdFwiLCBcImZvb1wiXSwgW1wiY2hlY2tcIiwgXCJmb29cIl1dKTtcblxuICAgICAgICAgICAgICAgICBxLnNob3VsZFNob3cgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgdmlldy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KHEubG9nKS50b0VxdWFsKFtcbiAgICAgICAgICAgICAgICAgICBbXCJzZXR0ZXJcIiwgXCJmb29cIl0sXG4gICAgICAgICAgICAgICAgICAgW1wiaW5pdFwiLCBcImZvb1wiXSxcbiAgICAgICAgICAgICAgICAgICBbXCJjaGVja1wiLCBcImZvb1wiXSxcbiAgICAgICAgICAgICAgICAgICBbXCJzZXR0ZXJcIiwgbnVsbF0sXG4gICAgICAgICAgICAgICAgICAgW1wiY2hlY2tcIiwgbnVsbF1cbiAgICAgICAgICAgICAgICAgXSk7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgY29udGFpbiBhbGwgZGlyZWN0aXZlcyBpbiB0aGUgbGlnaHQgZG9tIHdoZW4gZGVzY2VuZGFudHMgZmxhZyBpcyB1c2VkJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPGRpdiB0ZXh0PVwiMVwiPjwvZGl2PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPG5lZWRzLXF1ZXJ5LWRlc2MgdGV4dD1cIjJcIj48ZGl2IHRleHQ9XCIzXCI+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8ZGl2IHRleHQ9XCI0XCI+PC9kaXY+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8L2Rpdj48L25lZWRzLXF1ZXJ5LWRlc2M+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8ZGl2IHRleHQ9XCI1XCI+PC9kaXY+JztcblxuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShNeUNvbXAsIHRlbXBsYXRlKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKCh2aWV3KSA9PiB7XG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoYXNOYXRpdmVFbGVtZW50cyh2aWV3LmRlYnVnRWxlbWVudC5jaGlsZHJlbikpLnRvSGF2ZVRleHQoJzJ8M3w0fCcpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIGNvbnRhaW4gYWxsIGRpcmVjdGl2ZXMgaW4gdGhlIGxpZ2h0IGRvbScsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdmFyIHRlbXBsYXRlID0gJzxkaXYgdGV4dD1cIjFcIj48L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzxuZWVkcy1xdWVyeSB0ZXh0PVwiMlwiPjxkaXYgdGV4dD1cIjNcIj48L2Rpdj48L25lZWRzLXF1ZXJ5PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPGRpdiB0ZXh0PVwiNFwiPjwvZGl2Pic7XG5cbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoTXlDb21wLCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigodmlldykgPT4ge1xuICAgICAgICAgICAgICAgICB2aWV3LmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGFzTmF0aXZlRWxlbWVudHModmlldy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW4pKS50b0hhdmVUZXh0KCcyfDN8Jyk7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcmVmbGVjdCBkeW5hbWljYWxseSBpbnNlcnRlZCBkaXJlY3RpdmVzJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPVxuICAgICAgICAgICAgICAgJzxkaXYgdGV4dD1cIjFcIj48L2Rpdj4nICtcbiAgICAgICAgICAgICAgICc8bmVlZHMtcXVlcnkgdGV4dD1cIjJcIj48ZGl2ICpuZ0lmPVwic2hvdWxkU2hvd1wiIFt0ZXh0XT1cIlxcJzNcXCdcIj48L2Rpdj48L25lZWRzLXF1ZXJ5PicgK1xuICAgICAgICAgICAgICAgJzxkaXYgdGV4dD1cIjRcIj48L2Rpdj4nO1xuXG4gICAgICAgICAgIHRjYi5vdmVycmlkZVRlbXBsYXRlKE15Q29tcCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKHZpZXcpID0+IHtcblxuICAgICAgICAgICAgICAgICB2aWV3LmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGFzTmF0aXZlRWxlbWVudHModmlldy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW4pKS50b0hhdmVUZXh0KCcyfCcpO1xuXG4gICAgICAgICAgICAgICAgIHZpZXcuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLnNob3VsZFNob3cgPSB0cnVlO1xuICAgICAgICAgICAgICAgICB2aWV3LmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGFzTmF0aXZlRWxlbWVudHModmlldy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW4pKS50b0hhdmVUZXh0KCcyfDN8Jyk7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgYmUgY2xlYW5seSBkZXN0cm95ZWQgd2hlbiBhIHF1ZXJ5IGNyb3NzZXMgdmlldyBib3VuZGFyaWVzJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPVxuICAgICAgICAgICAgICAgJzxkaXYgdGV4dD1cIjFcIj48L2Rpdj4nICtcbiAgICAgICAgICAgICAgICc8bmVlZHMtcXVlcnkgdGV4dD1cIjJcIj48ZGl2ICpuZ0lmPVwic2hvdWxkU2hvd1wiIFt0ZXh0XT1cIlxcJzNcXCdcIj48L2Rpdj48L25lZWRzLXF1ZXJ5PicgK1xuICAgICAgICAgICAgICAgJzxkaXYgdGV4dD1cIjRcIj48L2Rpdj4nO1xuXG4gICAgICAgICAgIHRjYi5vdmVycmlkZVRlbXBsYXRlKE15Q29tcCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2Uuc2hvdWxkU2hvdyA9IHRydWU7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlc3Ryb3koKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCByZWZsZWN0IG1vdmVkIGRpcmVjdGl2ZXMnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHZhciB0ZW1wbGF0ZSA9XG4gICAgICAgICAgICAgICAnPGRpdiB0ZXh0PVwiMVwiPjwvZGl2PicgK1xuICAgICAgICAgICAgICAgJzxuZWVkcy1xdWVyeSB0ZXh0PVwiMlwiPjxkaXYgKm5nRm9yPVwidmFyIGkgb2YgbGlzdFwiIFt0ZXh0XT1cImlcIj48L2Rpdj48L25lZWRzLXF1ZXJ5PicgK1xuICAgICAgICAgICAgICAgJzxkaXYgdGV4dD1cIjRcIj48L2Rpdj4nO1xuXG4gICAgICAgICAgIHRjYi5vdmVycmlkZVRlbXBsYXRlKE15Q29tcCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKHZpZXcpID0+IHtcbiAgICAgICAgICAgICAgICAgdmlldy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KGFzTmF0aXZlRWxlbWVudHModmlldy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW4pKS50b0hhdmVUZXh0KCcyfDFkfDJkfDNkfCcpO1xuXG4gICAgICAgICAgICAgICAgIHZpZXcuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLmxpc3QgPSBbJzNkJywgJzJkJ107XG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoYXNOYXRpdmVFbGVtZW50cyh2aWV3LmRlYnVnRWxlbWVudC5jaGlsZHJlbikpLnRvSGF2ZVRleHQoJzJ8M2R8MmR8Jyk7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG4gICAgfSk7XG5cbiAgICBkZXNjcmliZSgncXVlcnkgZm9yIFRlbXBsYXRlUmVmJywgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCBmaW5kIFRlbXBsYXRlUmVmcyBpbiB0aGUgbGlnaHQgYW5kIHNoYWRvdyBkb20nLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHZhciB0ZW1wbGF0ZSA9ICc8bmVlZHMtdHBsPjx0ZW1wbGF0ZSB2YXIteD1cImxpZ2h0XCI+PC90ZW1wbGF0ZT48L25lZWRzLXRwbD4nO1xuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShNeUNvbXAsIHRlbXBsYXRlKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKCh2aWV3KSA9PiB7XG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICB2YXIgbmVlZHNUcGw6IE5lZWRzVHBsID0gdmlldy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uaW5qZWN0KE5lZWRzVHBsKTtcblxuICAgICAgICAgICAgICAgICBleHBlY3QobmVlZHNUcGwudmMuY3JlYXRlRW1iZWRkZWRWaWV3KG5lZWRzVHBsLnF1ZXJ5LmZpcnN0KS5oYXNMb2NhbCgnbGlnaHQnKSlcbiAgICAgICAgICAgICAgICAgICAgIC50b0JlKHRydWUpO1xuICAgICAgICAgICAgICAgICBleHBlY3QobmVlZHNUcGwudmMuY3JlYXRlRW1iZWRkZWRWaWV3KG5lZWRzVHBsLnZpZXdRdWVyeS5maXJzdCkuaGFzTG9jYWwoJ3NoYWRvdycpKVxuICAgICAgICAgICAgICAgICAgICAgLnRvQmUodHJ1ZSk7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKFwiY2hhbmdlc1wiLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIG5vdGlmeSBxdWVyeSBvbiBjaGFuZ2UnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHZhciB0ZW1wbGF0ZSA9ICc8bmVlZHMtcXVlcnkgI3E+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8ZGl2IHRleHQ9XCIxXCI+PC9kaXY+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8ZGl2ICpuZ0lmPVwic2hvdWxkU2hvd1wiIHRleHQ9XCIyXCI+PC9kaXY+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8L25lZWRzLXF1ZXJ5Pic7XG5cbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoTXlDb21wLCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigodmlldykgPT4ge1xuICAgICAgICAgICAgICAgICB2YXIgcSA9IHZpZXcuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmdldExvY2FsKFwicVwiKTtcbiAgICAgICAgICAgICAgICAgdmlldy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgT2JzZXJ2YWJsZVdyYXBwZXIuc3Vic2NyaWJlKHEucXVlcnkuY2hhbmdlcywgKF8pID0+IHtcbiAgICAgICAgICAgICAgICAgICBleHBlY3QocS5xdWVyeS5maXJzdC50ZXh0KS50b0VxdWFsKFwiMVwiKTtcbiAgICAgICAgICAgICAgICAgICBleHBlY3QocS5xdWVyeS5sYXN0LnRleHQpLnRvRXF1YWwoXCIyXCIpO1xuICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgdmlldy5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2Uuc2hvdWxkU2hvdyA9IHRydWU7XG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KFwic2hvdWxkIG5vdGlmeSBjaGlsZCdzIHF1ZXJ5IGJlZm9yZSBub3RpZnlpbmcgcGFyZW50J3MgcXVlcnlcIixcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPG5lZWRzLXF1ZXJ5LWRlc2MgI3ExPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPG5lZWRzLXF1ZXJ5LWRlc2MgI3EyPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPGRpdiB0ZXh0PVwiMVwiPjwvZGl2PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPC9uZWVkcy1xdWVyeS1kZXNjPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPC9uZWVkcy1xdWVyeS1kZXNjPic7XG5cbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoTXlDb21wLCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigodmlldykgPT4ge1xuICAgICAgICAgICAgICAgICB2YXIgcTEgPSB2aWV3LmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5nZXRMb2NhbChcInExXCIpO1xuICAgICAgICAgICAgICAgICB2YXIgcTIgPSB2aWV3LmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5nZXRMb2NhbChcInEyXCIpO1xuXG4gICAgICAgICAgICAgICAgIHZhciBmaXJlZFEyID0gZmFsc2U7XG5cbiAgICAgICAgICAgICAgICAgT2JzZXJ2YWJsZVdyYXBwZXIuc3Vic2NyaWJlKHEyLnF1ZXJ5LmNoYW5nZXMsIChfKSA9PiB7IGZpcmVkUTIgPSB0cnVlOyB9KTtcbiAgICAgICAgICAgICAgICAgT2JzZXJ2YWJsZVdyYXBwZXIuc3Vic2NyaWJlKHExLnF1ZXJ5LmNoYW5nZXMsIChfKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGZpcmVkUTIpLnRvQmUodHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgICB2aWV3LmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIGNvcnJlY3RseSBjbGVhbi11cCB3aGVuIGRlc3Ryb3llZCB0b2dldGhlciB3aXRoIHRoZSBkaXJlY3RpdmVzIGl0IGlzIHF1ZXJ5aW5nJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPG5lZWRzLXF1ZXJ5ICNxICpuZ0lmPVwic2hvdWxkU2hvd1wiPjxkaXYgdGV4dD1cImZvb1wiPjwvZGl2PjwvbmVlZHMtcXVlcnk+JztcblxuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShNeUNvbXAsIHRlbXBsYXRlKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKCh2aWV3KSA9PiB7XG4gICAgICAgICAgICAgICAgIHZpZXcuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLnNob3VsZFNob3cgPSB0cnVlO1xuICAgICAgICAgICAgICAgICB2aWV3LmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICB2YXIgcTogTmVlZHNRdWVyeSA9IHZpZXcuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmdldExvY2FsKCdxJyk7XG5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KHEucXVlcnkubGVuZ3RoKS50b0VxdWFsKDEpO1xuXG4gICAgICAgICAgICAgICAgIHZpZXcuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLnNob3VsZFNob3cgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgdmlldy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgdmlldy5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2Uuc2hvdWxkU2hvdyA9IHRydWU7XG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIHZhciBxMjogTmVlZHNRdWVyeSA9IHZpZXcuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmdldExvY2FsKCdxJyk7XG5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KHEyLnF1ZXJ5Lmxlbmd0aCkudG9FcXVhbCgxKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKFwicXVlcnlpbmcgYnkgdmFyIGJpbmRpbmdcIiwgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCBjb250YWluIGFsbCB0aGUgY2hpbGQgZGlyZWN0aXZlcyBpbiB0aGUgbGlnaHQgZG9tIHdpdGggdGhlIGdpdmVuIHZhciBiaW5kaW5nJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPG5lZWRzLXF1ZXJ5LWJ5LXZhci1iaW5kaW5nICNxPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPGRpdiAqbmdGb3I9XCIjaXRlbSBvZiBsaXN0XCIgW3RleHRdPVwiaXRlbVwiICN0ZXh0TGFiZWw9XCJ0ZXh0RGlyXCI+PC9kaXY+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8L25lZWRzLXF1ZXJ5LWJ5LXZhci1iaW5kaW5nPic7XG5cbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoTXlDb21wLCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigodmlldykgPT4ge1xuICAgICAgICAgICAgICAgICB2YXIgcSA9IHZpZXcuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmdldExvY2FsKFwicVwiKTtcblxuICAgICAgICAgICAgICAgICB2aWV3LmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5saXN0ID0gWycxZCcsICcyZCddO1xuXG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChxLnF1ZXJ5LmZpcnN0LnRleHQpLnRvRXF1YWwoXCIxZFwiKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KHEucXVlcnkubGFzdC50ZXh0KS50b0VxdWFsKFwiMmRcIik7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCBxdWVyeWluZyBieSBtdWx0aXBsZSB2YXIgYmluZGluZ3MnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHZhciB0ZW1wbGF0ZSA9ICc8bmVlZHMtcXVlcnktYnktdmFyLWJpbmRpbmdzICNxPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPGRpdiB0ZXh0PVwib25lXCIgI3RleHRMYWJlbDE9XCJ0ZXh0RGlyXCI+PC9kaXY+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8ZGl2IHRleHQ9XCJ0d29cIiAjdGV4dExhYmVsMj1cInRleHREaXJcIj48L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzwvbmVlZHMtcXVlcnktYnktdmFyLWJpbmRpbmdzPic7XG5cbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoTXlDb21wLCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigodmlldykgPT4ge1xuICAgICAgICAgICAgICAgICB2YXIgcSA9IHZpZXcuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmdldExvY2FsKFwicVwiKTtcbiAgICAgICAgICAgICAgICAgdmlldy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KHEucXVlcnkuZmlyc3QudGV4dCkudG9FcXVhbChcIm9uZVwiKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KHEucXVlcnkubGFzdC50ZXh0KS50b0VxdWFsKFwidHdvXCIpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIHJlZmxlY3QgZHluYW1pY2FsbHkgaW5zZXJ0ZWQgZGlyZWN0aXZlcycsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdmFyIHRlbXBsYXRlID0gJzxuZWVkcy1xdWVyeS1ieS12YXItYmluZGluZyAjcT4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzxkaXYgKm5nRm9yPVwiI2l0ZW0gb2YgbGlzdFwiIFt0ZXh0XT1cIml0ZW1cIiAjdGV4dExhYmVsPVwidGV4dERpclwiPjwvZGl2PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPC9uZWVkcy1xdWVyeS1ieS12YXItYmluZGluZz4nO1xuXG4gICAgICAgICAgIHRjYi5vdmVycmlkZVRlbXBsYXRlKE15Q29tcCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKHZpZXcpID0+IHtcbiAgICAgICAgICAgICAgICAgdmFyIHEgPSB2aWV3LmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5nZXRMb2NhbChcInFcIik7XG5cbiAgICAgICAgICAgICAgICAgdmlldy5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UubGlzdCA9IFsnMWQnLCAnMmQnXTtcblxuICAgICAgICAgICAgICAgICB2aWV3LmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICB2aWV3LmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5saXN0ID0gWycyZCcsICcxZCddO1xuXG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChxLnF1ZXJ5Lmxhc3QudGV4dCkudG9FcXVhbChcIjFkXCIpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIGNvbnRhaW4gYWxsIHRoZSBlbGVtZW50cyBpbiB0aGUgbGlnaHQgZG9tIHdpdGggdGhlIGdpdmVuIHZhciBiaW5kaW5nJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPG5lZWRzLXF1ZXJ5LWJ5LXZhci1iaW5kaW5nICNxPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPGRpdiB0ZW1wbGF0ZT1cIm5nRm9yOiAjaXRlbSBvZiBsaXN0XCI+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8ZGl2ICN0ZXh0TGFiZWw+e3tpdGVtfX08L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzwvZGl2PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPC9uZWVkcy1xdWVyeS1ieS12YXItYmluZGluZz4nO1xuXG4gICAgICAgICAgIHRjYi5vdmVycmlkZVRlbXBsYXRlKE15Q29tcCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKHZpZXcpID0+IHtcbiAgICAgICAgICAgICAgICAgdmFyIHEgPSB2aWV3LmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5nZXRMb2NhbChcInFcIik7XG5cbiAgICAgICAgICAgICAgICAgdmlldy5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2UubGlzdCA9IFsnMWQnLCAnMmQnXTtcblxuICAgICAgICAgICAgICAgICB2aWV3LmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICBleHBlY3QocS5xdWVyeS5maXJzdC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KFwiMWRcIik7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChxLnF1ZXJ5Lmxhc3QubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dChcIjJkXCIpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIGNvbnRhaW4gYWxsIHRoZSBlbGVtZW50cyBpbiB0aGUgbGlnaHQgZG9tIGV2ZW4gaWYgdGhleSBnZXQgcHJvamVjdGVkJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPG5lZWRzLXF1ZXJ5LWFuZC1wcm9qZWN0ICNxPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPGRpdiB0ZXh0PVwiaGVsbG9cIj48L2Rpdj48ZGl2IHRleHQ9XCJ3b3JsZFwiPjwvZGl2PicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPC9uZWVkcy1xdWVyeS1hbmQtcHJvamVjdD4nO1xuXG4gICAgICAgICAgIHRjYi5vdmVycmlkZVRlbXBsYXRlKE15Q29tcCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKHZpZXcpID0+IHtcbiAgICAgICAgICAgICAgICAgdmlldy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KGFzTmF0aXZlRWxlbWVudHModmlldy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW4pKS50b0hhdmVUZXh0KCdoZWxsb3x3b3JsZHwnKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IHF1ZXJ5aW5nIHRoZSB2aWV3IGJ5IHVzaW5nIGEgdmlldyBxdWVyeScsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdmFyIHRlbXBsYXRlID0gJzxuZWVkcy12aWV3LXF1ZXJ5LWJ5LXZhci1iaW5kaW5nICNxPjwvbmVlZHMtdmlldy1xdWVyeS1ieS12YXItYmluZGluZz4nO1xuXG4gICAgICAgICAgIHRjYi5vdmVycmlkZVRlbXBsYXRlKE15Q29tcCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKHZpZXcpID0+IHtcbiAgICAgICAgICAgICAgICAgdmFyIHE6IE5lZWRzVmlld1F1ZXJ5QnlMYWJlbCA9IHZpZXcuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmdldExvY2FsKFwicVwiKTtcbiAgICAgICAgICAgICAgICAgdmlldy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KHEucXVlcnkuZmlyc3QubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dChcInRleHRcIik7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgY29udGFpbiBhbGwgY2hpbGQgZGlyZWN0aXZlcyBpbiB0aGUgdmlldyBkb20nLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHZhciB0ZW1wbGF0ZSA9ICc8bmVlZHMtdmlldy1jaGlsZHJlbiAjcT48L25lZWRzLXZpZXctY2hpbGRyZW4+JztcblxuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShNeUNvbXAsIHRlbXBsYXRlKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKCh2aWV3KSA9PiB7XG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIHZhciBxID0gdmlldy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uZ2V0TG9jYWwoJ3EnKTtcblxuICAgICAgICAgICAgICAgICB2aWV3LmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICBleHBlY3QocS50ZXh0RGlyQ2hpbGRyZW4ubGVuZ3RoKS50b0VxdWFsKDEpO1xuICAgICAgICAgICAgICAgICBleHBlY3QocS5udW1iZXJPZkNoaWxkcmVuQWZ0ZXJWaWV3SW5pdCkudG9FcXVhbCgxKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoXCJxdWVyeWluZyBpbiB0aGUgdmlld1wiLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIGNvbnRhaW4gYWxsIHRoZSBlbGVtZW50cyBpbiB0aGUgdmlldyB3aXRoIHRoYXQgaGF2ZSB0aGUgZ2l2ZW4gZGlyZWN0aXZlJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPG5lZWRzLXZpZXctcXVlcnkgI3E+PGRpdiB0ZXh0PVwiaWdub3JlbWVcIj48L2Rpdj48L25lZWRzLXZpZXctcXVlcnk+JztcblxuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShNeUNvbXAsIHRlbXBsYXRlKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKCh2aWV3KSA9PiB7XG4gICAgICAgICAgICAgICAgIHZhciBxOiBOZWVkc1ZpZXdRdWVyeSA9IHZpZXcuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmdldExvY2FsKFwicVwiKTtcblxuICAgICAgICAgICAgICAgICB2aWV3LmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICBleHBlY3QocS5xdWVyeS5tYXAoKGQ6IFRleHREaXJlY3RpdmUpID0+IGQudGV4dCkpLnRvRXF1YWwoW1wiMVwiLCBcIjJcIiwgXCIzXCIsIFwiNFwiXSk7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgbm90IGluY2x1ZGUgZGlyZWN0aXZlIHByZXNlbnQgb24gdGhlIGhvc3QgZWxlbWVudCcsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdmFyIHRlbXBsYXRlID0gJzxuZWVkcy12aWV3LXF1ZXJ5ICNxIHRleHQ9XCJzZWxmXCI+PC9uZWVkcy12aWV3LXF1ZXJ5Pic7XG5cbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoTXlDb21wLCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigodmlldykgPT4ge1xuICAgICAgICAgICAgICAgICB2YXIgcTogTmVlZHNWaWV3UXVlcnkgPSB2aWV3LmRlYnVnRWxlbWVudC5jaGlsZHJlblswXS5nZXRMb2NhbChcInFcIik7XG5cbiAgICAgICAgICAgICAgICAgdmlldy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KHEucXVlcnkubWFwKChkOiBUZXh0RGlyZWN0aXZlKSA9PiBkLnRleHQpKS50b0VxdWFsKFtcIjFcIiwgXCIyXCIsIFwiM1wiLCBcIjRcIl0pO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIHJlZmxlY3QgY2hhbmdlcyBpbiB0aGUgY29tcG9uZW50JyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPG5lZWRzLXZpZXctcXVlcnktaWYgI3E+PC9uZWVkcy12aWV3LXF1ZXJ5LWlmPic7XG5cbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoTXlDb21wLCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgICAudGhlbigodmlldykgPT4ge1xuICAgICAgICAgICAgICAgICB2YXIgcTogTmVlZHNWaWV3UXVlcnlJZiA9IHZpZXcuZGVidWdFbGVtZW50LmNoaWxkcmVuWzBdLmdldExvY2FsKFwicVwiKTtcblxuICAgICAgICAgICAgICAgICB2aWV3LmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICBleHBlY3QocS5xdWVyeS5sZW5ndGgpLnRvQmUoMCk7XG5cbiAgICAgICAgICAgICAgICAgcS5zaG93ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgdmlldy5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChxLnF1ZXJ5Lmxlbmd0aCkudG9CZSgxKTtcblxuICAgICAgICAgICAgICAgICBleHBlY3QocS5xdWVyeS5maXJzdC50ZXh0KS50b0VxdWFsKFwiMVwiKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBub3QgYmUgYWZmZWN0ZWQgYnkgb3RoZXIgY2hhbmdlcyBpbiB0aGUgY29tcG9uZW50JyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPG5lZWRzLXZpZXctcXVlcnktbmVzdGVkLWlmICNxPjwvbmVlZHMtdmlldy1xdWVyeS1uZXN0ZWQtaWY+JztcblxuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShNeUNvbXAsIHRlbXBsYXRlKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKCh2aWV3KSA9PiB7XG4gICAgICAgICAgICAgICAgIHZhciBxOiBOZWVkc1ZpZXdRdWVyeU5lc3RlZElmID0gdmlldy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uZ2V0TG9jYWwoXCJxXCIpO1xuXG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChxLnF1ZXJ5Lmxlbmd0aCkudG9FcXVhbCgxKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KHEucXVlcnkuZmlyc3QudGV4dCkudG9FcXVhbChcIjFcIik7XG5cbiAgICAgICAgICAgICAgICAgcS5zaG93ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChxLnF1ZXJ5Lmxlbmd0aCkudG9FcXVhbCgxKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KHEucXVlcnkuZmlyc3QudGV4dCkudG9FcXVhbChcIjFcIik7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cblxuICAgICAgaXQoJ3Nob3VsZCBtYWludGFpbiBkaXJlY3RpdmVzIGluIHByZS1vcmRlciBkZXB0aC1maXJzdCBET00gb3JkZXIgYWZ0ZXIgZHluYW1pYyBpbnNlcnRpb24nLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHZhciB0ZW1wbGF0ZSA9ICc8bmVlZHMtdmlldy1xdWVyeS1vcmRlciAjcT48L25lZWRzLXZpZXctcXVlcnktb3JkZXI+JztcblxuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShNeUNvbXAsIHRlbXBsYXRlKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKCh2aWV3KSA9PiB7XG4gICAgICAgICAgICAgICAgIHZhciBxOiBOZWVkc1ZpZXdRdWVyeU9yZGVyID0gdmlldy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uZ2V0TG9jYWwoXCJxXCIpO1xuXG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChxLnF1ZXJ5Lm1hcCgoZDogVGV4dERpcmVjdGl2ZSkgPT4gZC50ZXh0KSkudG9FcXVhbChbXCIxXCIsIFwiMlwiLCBcIjNcIiwgXCI0XCJdKTtcblxuICAgICAgICAgICAgICAgICBxLmxpc3QgPSBbXCItM1wiLCBcIjJcIl07XG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuXG5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KHEucXVlcnkubWFwKChkOiBUZXh0RGlyZWN0aXZlKSA9PiBkLnRleHQpKS50b0VxdWFsKFtcIjFcIiwgXCItM1wiLCBcIjJcIiwgXCI0XCJdKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBtYWludGFpbiBkaXJlY3RpdmVzIGluIHByZS1vcmRlciBkZXB0aC1maXJzdCBET00gb3JkZXIgYWZ0ZXIgZHluYW1pYyBpbnNlcnRpb24nLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHZhciB0ZW1wbGF0ZSA9ICc8bmVlZHMtdmlldy1xdWVyeS1vcmRlci13aXRoLXAgI3E+PC9uZWVkcy12aWV3LXF1ZXJ5LW9yZGVyLXdpdGgtcD4nO1xuXG4gICAgICAgICAgIHRjYi5vdmVycmlkZVRlbXBsYXRlKE15Q29tcCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgICAgICAgLnRoZW4oKHZpZXcpID0+IHtcbiAgICAgICAgICAgICAgICAgdmFyIHE6IE5lZWRzVmlld1F1ZXJ5T3JkZXJXaXRoUGFyZW50ID0gdmlldy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uZ2V0TG9jYWwoXCJxXCIpO1xuXG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChxLnF1ZXJ5Lm1hcCgoZDogVGV4dERpcmVjdGl2ZSkgPT4gZC50ZXh0KSkudG9FcXVhbChbXCIxXCIsIFwiMlwiLCBcIjNcIiwgXCI0XCJdKTtcblxuICAgICAgICAgICAgICAgICBxLmxpc3QgPSBbXCItM1wiLCBcIjJcIl07XG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuXG5cbiAgICAgICAgICAgICAgICAgZXhwZWN0KHEucXVlcnkubWFwKChkOiBUZXh0RGlyZWN0aXZlKSA9PiBkLnRleHQpKS50b0VxdWFsKFtcIjFcIiwgXCItM1wiLCBcIjJcIiwgXCI0XCJdKTtcblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBoYW5kbGUgbG9uZyBuZ0ZvciBjeWNsZXMnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHZhciB0ZW1wbGF0ZSA9ICc8bmVlZHMtdmlldy1xdWVyeS1vcmRlciAjcT48L25lZWRzLXZpZXctcXVlcnktb3JkZXI+JztcblxuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShNeUNvbXAsIHRlbXBsYXRlKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKCh2aWV3KSA9PiB7XG4gICAgICAgICAgICAgICAgIHZhciBxOiBOZWVkc1ZpZXdRdWVyeU9yZGVyID0gdmlldy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uZ2V0TG9jYWwoJ3EnKTtcblxuICAgICAgICAgICAgICAgICAvLyBubyBzaWduaWZpY2FuY2UgdG8gNTAsIGp1c3QgYSByZWFzb25hYmx5IGxhcmdlIGN5Y2xlLlxuICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IDUwOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICB2YXIgbmV3U3RyaW5nID0gaS50b1N0cmluZygpO1xuICAgICAgICAgICAgICAgICAgIHEubGlzdCA9IFtuZXdTdHJpbmddO1xuICAgICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KHEucXVlcnkubWFwKChkOiBUZXh0RGlyZWN0aXZlKSA9PiBkLnRleHQpKS50b0VxdWFsKFsnMScsIG5ld1N0cmluZywgJzQnXSk7XG4gICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdXBwb3J0IG1vcmUgdGhhbiB0aHJlZSBxdWVyaWVzJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPG5lZWRzLWZvdXItcXVlcmllcyAjcT48ZGl2IHRleHQ9XCIxXCI+PC9kaXY+PC9uZWVkcy1mb3VyLXF1ZXJpZXM+JztcblxuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShNeUNvbXAsIHRlbXBsYXRlKVxuICAgICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKE15Q29tcClcbiAgICAgICAgICAgICAgIC50aGVuKCh2aWV3KSA9PiB7XG4gICAgICAgICAgICAgICAgIHZpZXcuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgICAgICAgICAgICAgIHZhciBxID0gdmlldy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW5bMF0uZ2V0TG9jYWwoJ3EnKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KHEucXVlcnkxKS50b0JlRGVmaW5lZCgpO1xuICAgICAgICAgICAgICAgICBleHBlY3QocS5xdWVyeTIpLnRvQmVEZWZpbmVkKCk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChxLnF1ZXJ5MykudG9CZURlZmluZWQoKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KHEucXVlcnk0KS50b0JlRGVmaW5lZCgpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuICAgIH0pO1xuICB9KTtcbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdbdGV4dF0nLCBpbnB1dHM6IFsndGV4dCddLCBleHBvcnRBczogJ3RleHREaXInfSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIFRleHREaXJlY3RpdmUge1xuICB0ZXh0OiBzdHJpbmc7XG4gIGNvbnN0cnVjdG9yKCkge31cbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICduZWVkcy1jb250ZW50LWNoaWxkcmVuJywgdGVtcGxhdGU6ICcnfSlcbmNsYXNzIE5lZWRzQ29udGVudENoaWxkcmVuIGltcGxlbWVudHMgQWZ0ZXJDb250ZW50SW5pdCB7XG4gIEBDb250ZW50Q2hpbGRyZW4oVGV4dERpcmVjdGl2ZSkgdGV4dERpckNoaWxkcmVuOiBRdWVyeUxpc3Q8VGV4dERpcmVjdGl2ZT47XG4gIG51bWJlck9mQ2hpbGRyZW5BZnRlckNvbnRlbnRJbml0OiBudW1iZXI7XG5cbiAgbmdBZnRlckNvbnRlbnRJbml0KCkgeyB0aGlzLm51bWJlck9mQ2hpbGRyZW5BZnRlckNvbnRlbnRJbml0ID0gdGhpcy50ZXh0RGlyQ2hpbGRyZW4ubGVuZ3RoOyB9XG59XG5cbkBDb21wb25lbnQoXG4gICAge3NlbGVjdG9yOiAnbmVlZHMtdmlldy1jaGlsZHJlbicsIHRlbXBsYXRlOiAnPGRpdiB0ZXh0PjwvZGl2PicsIGRpcmVjdGl2ZXM6IFtUZXh0RGlyZWN0aXZlXX0pXG5jbGFzcyBOZWVkc1ZpZXdDaGlsZHJlbiBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQge1xuICBAVmlld0NoaWxkcmVuKFRleHREaXJlY3RpdmUpIHRleHREaXJDaGlsZHJlbjogUXVlcnlMaXN0PFRleHREaXJlY3RpdmU+O1xuICBudW1iZXJPZkNoaWxkcmVuQWZ0ZXJWaWV3SW5pdDogbnVtYmVyO1xuXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpIHsgdGhpcy5udW1iZXJPZkNoaWxkcmVuQWZ0ZXJWaWV3SW5pdCA9IHRoaXMudGV4dERpckNoaWxkcmVuLmxlbmd0aDsgfVxufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ25lZWRzLWNvbnRlbnQtY2hpbGQnLCB0ZW1wbGF0ZTogJyd9KVxuY2xhc3MgTmVlZHNDb250ZW50Q2hpbGQgaW1wbGVtZW50cyBBZnRlckNvbnRlbnRJbml0LCBBZnRlckNvbnRlbnRDaGVja2VkIHtcbiAgX2NoaWxkOiBUZXh0RGlyZWN0aXZlO1xuXG4gIEBDb250ZW50Q2hpbGQoVGV4dERpcmVjdGl2ZSlcbiAgc2V0IGNoaWxkKHZhbHVlKSB7XG4gICAgdGhpcy5fY2hpbGQgPSB2YWx1ZTtcbiAgICB0aGlzLmxvZy5wdXNoKFsnc2V0dGVyJywgaXNQcmVzZW50KHZhbHVlKSA/IHZhbHVlLnRleHQgOiBudWxsXSk7XG4gIH1cblxuICBnZXQgY2hpbGQoKSB7IHJldHVybiB0aGlzLl9jaGlsZDsgfVxuICBsb2cgPSBbXTtcblxuICBuZ0FmdGVyQ29udGVudEluaXQoKSB7IHRoaXMubG9nLnB1c2goW1wiaW5pdFwiLCBpc1ByZXNlbnQodGhpcy5jaGlsZCkgPyB0aGlzLmNoaWxkLnRleHQgOiBudWxsXSk7IH1cblxuICBuZ0FmdGVyQ29udGVudENoZWNrZWQoKSB7XG4gICAgdGhpcy5sb2cucHVzaChbXCJjaGVja1wiLCBpc1ByZXNlbnQodGhpcy5jaGlsZCkgPyB0aGlzLmNoaWxkLnRleHQgOiBudWxsXSk7XG4gIH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbmVlZHMtdmlldy1jaGlsZCcsXG4gIHRlbXBsYXRlOiBgXG4gICAgPGRpdiAqbmdJZj1cInNob3VsZFNob3dcIiB0ZXh0PVwiZm9vXCI+PC9kaXY+XG4gIGAsXG4gIGRpcmVjdGl2ZXM6IFtOZ0lmLCBUZXh0RGlyZWN0aXZlXVxufSlcbmNsYXNzIE5lZWRzVmlld0NoaWxkIGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCxcbiAgICBBZnRlclZpZXdDaGVja2VkIHtcbiAgc2hvdWxkU2hvdzogYm9vbGVhbiA9IHRydWU7XG4gIF9jaGlsZDogVGV4dERpcmVjdGl2ZTtcblxuICBAVmlld0NoaWxkKFRleHREaXJlY3RpdmUpXG4gIHNldCBjaGlsZCh2YWx1ZSkge1xuICAgIHRoaXMuX2NoaWxkID0gdmFsdWU7XG4gICAgdGhpcy5sb2cucHVzaChbJ3NldHRlcicsIGlzUHJlc2VudCh2YWx1ZSkgPyB2YWx1ZS50ZXh0IDogbnVsbF0pO1xuICB9XG5cbiAgZ2V0IGNoaWxkKCkgeyByZXR1cm4gdGhpcy5fY2hpbGQ7IH1cbiAgbG9nID0gW107XG5cbiAgbmdBZnRlclZpZXdJbml0KCkgeyB0aGlzLmxvZy5wdXNoKFtcImluaXRcIiwgaXNQcmVzZW50KHRoaXMuY2hpbGQpID8gdGhpcy5jaGlsZC50ZXh0IDogbnVsbF0pOyB9XG5cbiAgbmdBZnRlclZpZXdDaGVja2VkKCkgeyB0aGlzLmxvZy5wdXNoKFtcImNoZWNrXCIsIGlzUHJlc2VudCh0aGlzLmNoaWxkKSA/IHRoaXMuY2hpbGQudGV4dCA6IG51bGxdKTsgfVxufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJ1tkaXJdJ30pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBJbmVydERpcmVjdGl2ZSB7XG4gIGNvbnN0cnVjdG9yKCkge31cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbmVlZHMtcXVlcnknLFxuICBkaXJlY3RpdmVzOiBbTmdGb3IsIFRleHREaXJlY3RpdmVdLFxuICB0ZW1wbGF0ZTogJzxkaXYgdGV4dD1cImlnbm9yZW1lXCI+PC9kaXY+PGIgKm5nRm9yPVwidmFyIGRpciBvZiBxdWVyeVwiPnt7ZGlyLnRleHR9fXw8L2I+J1xufSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIE5lZWRzUXVlcnkge1xuICBxdWVyeTogUXVlcnlMaXN0PFRleHREaXJlY3RpdmU+O1xuICBjb25zdHJ1Y3RvcihAUXVlcnkoVGV4dERpcmVjdGl2ZSkgcXVlcnk6IFF1ZXJ5TGlzdDxUZXh0RGlyZWN0aXZlPikgeyB0aGlzLnF1ZXJ5ID0gcXVlcnk7IH1cbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICduZWVkcy1mb3VyLXF1ZXJpZXMnLCB0ZW1wbGF0ZTogJyd9KVxuY2xhc3MgTmVlZHNGb3VyUXVlcmllcyB7XG4gIEBDb250ZW50Q2hpbGQoVGV4dERpcmVjdGl2ZSkgcXVlcnkxOiBUZXh0RGlyZWN0aXZlO1xuICBAQ29udGVudENoaWxkKFRleHREaXJlY3RpdmUpIHF1ZXJ5MjogVGV4dERpcmVjdGl2ZTtcbiAgQENvbnRlbnRDaGlsZChUZXh0RGlyZWN0aXZlKSBxdWVyeTM6IFRleHREaXJlY3RpdmU7XG4gIEBDb250ZW50Q2hpbGQoVGV4dERpcmVjdGl2ZSkgcXVlcnk0OiBUZXh0RGlyZWN0aXZlO1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICduZWVkcy1xdWVyeS1kZXNjJyxcbiAgZGlyZWN0aXZlczogW05nRm9yXSxcbiAgdGVtcGxhdGU6ICc8ZGl2ICpuZ0Zvcj1cInZhciBkaXIgb2YgcXVlcnlcIj57e2Rpci50ZXh0fX18PC9kaXY+J1xufSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIE5lZWRzUXVlcnlEZXNjIHtcbiAgcXVlcnk6IFF1ZXJ5TGlzdDxUZXh0RGlyZWN0aXZlPjtcbiAgY29uc3RydWN0b3IoQFF1ZXJ5KFRleHREaXJlY3RpdmUsIHtkZXNjZW5kYW50czogdHJ1ZX0pIHF1ZXJ5OiBRdWVyeUxpc3Q8VGV4dERpcmVjdGl2ZT4pIHtcbiAgICB0aGlzLnF1ZXJ5ID0gcXVlcnk7XG4gIH1cbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICduZWVkcy1xdWVyeS1ieS12YXItYmluZGluZycsIGRpcmVjdGl2ZXM6IFtdLCB0ZW1wbGF0ZTogJzxuZy1jb250ZW50Pid9KVxuQEluamVjdGFibGUoKVxuY2xhc3MgTmVlZHNRdWVyeUJ5TGFiZWwge1xuICBxdWVyeTogUXVlcnlMaXN0PGFueT47XG4gIGNvbnN0cnVjdG9yKEBRdWVyeShcInRleHRMYWJlbFwiLCB7ZGVzY2VuZGFudHM6IHRydWV9KSBxdWVyeTogUXVlcnlMaXN0PGFueT4pIHtcbiAgICB0aGlzLnF1ZXJ5ID0gcXVlcnk7XG4gIH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbmVlZHMtdmlldy1xdWVyeS1ieS12YXItYmluZGluZycsXG4gIGRpcmVjdGl2ZXM6IFtdLFxuICB0ZW1wbGF0ZTogJzxkaXYgI3RleHRMYWJlbD50ZXh0PC9kaXY+J1xufSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIE5lZWRzVmlld1F1ZXJ5QnlMYWJlbCB7XG4gIHF1ZXJ5OiBRdWVyeUxpc3Q8YW55PjtcbiAgY29uc3RydWN0b3IoQFZpZXdRdWVyeShcInRleHRMYWJlbFwiKSBxdWVyeTogUXVlcnlMaXN0PGFueT4pIHsgdGhpcy5xdWVyeSA9IHF1ZXJ5OyB9XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnbmVlZHMtcXVlcnktYnktdmFyLWJpbmRpbmdzJywgZGlyZWN0aXZlczogW10sIHRlbXBsYXRlOiAnPG5nLWNvbnRlbnQ+J30pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBOZWVkc1F1ZXJ5QnlUd29MYWJlbHMge1xuICBxdWVyeTogUXVlcnlMaXN0PGFueT47XG4gIGNvbnN0cnVjdG9yKEBRdWVyeShcInRleHRMYWJlbDEsdGV4dExhYmVsMlwiLCB7ZGVzY2VuZGFudHM6IHRydWV9KSBxdWVyeTogUXVlcnlMaXN0PGFueT4pIHtcbiAgICB0aGlzLnF1ZXJ5ID0gcXVlcnk7XG4gIH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbmVlZHMtcXVlcnktYW5kLXByb2plY3QnLFxuICBkaXJlY3RpdmVzOiBbTmdGb3JdLFxuICB0ZW1wbGF0ZTogJzxkaXYgKm5nRm9yPVwidmFyIGRpciBvZiBxdWVyeVwiPnt7ZGlyLnRleHR9fXw8L2Rpdj48bmctY29udGVudD48L25nLWNvbnRlbnQ+J1xufSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIE5lZWRzUXVlcnlBbmRQcm9qZWN0IHtcbiAgcXVlcnk6IFF1ZXJ5TGlzdDxUZXh0RGlyZWN0aXZlPjtcbiAgY29uc3RydWN0b3IoQFF1ZXJ5KFRleHREaXJlY3RpdmUpIHF1ZXJ5OiBRdWVyeUxpc3Q8VGV4dERpcmVjdGl2ZT4pIHsgdGhpcy5xdWVyeSA9IHF1ZXJ5OyB9XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ25lZWRzLXZpZXctcXVlcnknLFxuICBkaXJlY3RpdmVzOiBbVGV4dERpcmVjdGl2ZV0sXG4gIHRlbXBsYXRlOiAnPGRpdiB0ZXh0PVwiMVwiPjxkaXYgdGV4dD1cIjJcIj48L2Rpdj48L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAnPGRpdiB0ZXh0PVwiM1wiPjwvZGl2PjxkaXYgdGV4dD1cIjRcIj48L2Rpdj4nXG59KVxuQEluamVjdGFibGUoKVxuY2xhc3MgTmVlZHNWaWV3UXVlcnkge1xuICBxdWVyeTogUXVlcnlMaXN0PFRleHREaXJlY3RpdmU+O1xuICBjb25zdHJ1Y3RvcihAVmlld1F1ZXJ5KFRleHREaXJlY3RpdmUpIHF1ZXJ5OiBRdWVyeUxpc3Q8VGV4dERpcmVjdGl2ZT4pIHsgdGhpcy5xdWVyeSA9IHF1ZXJ5OyB9XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ25lZWRzLXZpZXctcXVlcnktaWYnLFxuICBkaXJlY3RpdmVzOiBbTmdJZiwgVGV4dERpcmVjdGl2ZV0sXG4gIHRlbXBsYXRlOiAnPGRpdiAqbmdJZj1cInNob3dcIiB0ZXh0PVwiMVwiPjwvZGl2Pidcbn0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBOZWVkc1ZpZXdRdWVyeUlmIHtcbiAgc2hvdzogYm9vbGVhbjtcbiAgcXVlcnk6IFF1ZXJ5TGlzdDxUZXh0RGlyZWN0aXZlPjtcbiAgY29uc3RydWN0b3IoQFZpZXdRdWVyeShUZXh0RGlyZWN0aXZlKSBxdWVyeTogUXVlcnlMaXN0PFRleHREaXJlY3RpdmU+KSB7XG4gICAgdGhpcy5xdWVyeSA9IHF1ZXJ5O1xuICAgIHRoaXMuc2hvdyA9IGZhbHNlO1xuICB9XG59XG5cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbmVlZHMtdmlldy1xdWVyeS1uZXN0ZWQtaWYnLFxuICBkaXJlY3RpdmVzOiBbTmdJZiwgSW5lcnREaXJlY3RpdmUsIFRleHREaXJlY3RpdmVdLFxuICB0ZW1wbGF0ZTogJzxkaXYgdGV4dD1cIjFcIj48ZGl2ICpuZ0lmPVwic2hvd1wiPjxkaXYgZGlyPjwvZGl2PjwvZGl2PjwvZGl2Pidcbn0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBOZWVkc1ZpZXdRdWVyeU5lc3RlZElmIHtcbiAgc2hvdzogYm9vbGVhbjtcbiAgcXVlcnk6IFF1ZXJ5TGlzdDxUZXh0RGlyZWN0aXZlPjtcbiAgY29uc3RydWN0b3IoQFZpZXdRdWVyeShUZXh0RGlyZWN0aXZlKSBxdWVyeTogUXVlcnlMaXN0PFRleHREaXJlY3RpdmU+KSB7XG4gICAgdGhpcy5xdWVyeSA9IHF1ZXJ5O1xuICAgIHRoaXMuc2hvdyA9IHRydWU7XG4gIH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbmVlZHMtdmlldy1xdWVyeS1vcmRlcicsXG4gIGRpcmVjdGl2ZXM6IFtOZ0ZvciwgVGV4dERpcmVjdGl2ZSwgSW5lcnREaXJlY3RpdmVdLFxuICB0ZW1wbGF0ZTogJzxkaXYgdGV4dD1cIjFcIj48L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAnPGRpdiAqbmdGb3I9XCJ2YXIgaSBvZiBsaXN0XCIgW3RleHRdPVwiaVwiPjwvZGl2PicgK1xuICAgICAgICAgICAgICAgICc8ZGl2IHRleHQ9XCI0XCI+PC9kaXY+J1xufSlcbkBJbmplY3RhYmxlKClcbmNsYXNzIE5lZWRzVmlld1F1ZXJ5T3JkZXIge1xuICBxdWVyeTogUXVlcnlMaXN0PFRleHREaXJlY3RpdmU+O1xuICBsaXN0OiBzdHJpbmdbXTtcbiAgY29uc3RydWN0b3IoQFZpZXdRdWVyeShUZXh0RGlyZWN0aXZlKSBxdWVyeTogUXVlcnlMaXN0PFRleHREaXJlY3RpdmU+KSB7XG4gICAgdGhpcy5xdWVyeSA9IHF1ZXJ5O1xuICAgIHRoaXMubGlzdCA9IFsnMicsICczJ107XG4gIH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbmVlZHMtdmlldy1xdWVyeS1vcmRlci13aXRoLXAnLFxuICBkaXJlY3RpdmVzOiBbTmdGb3IsIFRleHREaXJlY3RpdmUsIEluZXJ0RGlyZWN0aXZlXSxcbiAgdGVtcGxhdGU6ICc8ZGl2IGRpcj48ZGl2IHRleHQ9XCIxXCI+PC9kaXY+JyArXG4gICAgICAgICAgICAgICAgJzxkaXYgKm5nRm9yPVwidmFyIGkgb2YgbGlzdFwiIFt0ZXh0XT1cImlcIj48L2Rpdj4nICtcbiAgICAgICAgICAgICAgICAnPGRpdiB0ZXh0PVwiNFwiPjwvZGl2PjwvZGl2Pidcbn0pXG5ASW5qZWN0YWJsZSgpXG5jbGFzcyBOZWVkc1ZpZXdRdWVyeU9yZGVyV2l0aFBhcmVudCB7XG4gIHF1ZXJ5OiBRdWVyeUxpc3Q8VGV4dERpcmVjdGl2ZT47XG4gIGxpc3Q6IHN0cmluZ1tdO1xuICBjb25zdHJ1Y3RvcihAVmlld1F1ZXJ5KFRleHREaXJlY3RpdmUpIHF1ZXJ5OiBRdWVyeUxpc3Q8VGV4dERpcmVjdGl2ZT4pIHtcbiAgICB0aGlzLnF1ZXJ5ID0gcXVlcnk7XG4gICAgdGhpcy5saXN0ID0gWycyJywgJzMnXTtcbiAgfVxufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ25lZWRzLXRwbCcsIHRlbXBsYXRlOiAnPHRlbXBsYXRlIHZhci14PVwic2hhZG93XCI+PC90ZW1wbGF0ZT4nfSlcbmNsYXNzIE5lZWRzVHBsIHtcbiAgdmlld1F1ZXJ5OiBRdWVyeUxpc3Q8VGVtcGxhdGVSZWY+O1xuICBxdWVyeTogUXVlcnlMaXN0PFRlbXBsYXRlUmVmPjtcbiAgY29uc3RydWN0b3IoQFZpZXdRdWVyeShUZW1wbGF0ZVJlZikgdmlld1F1ZXJ5OiBRdWVyeUxpc3Q8VGVtcGxhdGVSZWY+LFxuICAgICAgICAgICAgICBAUXVlcnkoVGVtcGxhdGVSZWYpIHF1ZXJ5OiBRdWVyeUxpc3Q8VGVtcGxhdGVSZWY+LCBwdWJsaWMgdmM6IFZpZXdDb250YWluZXJSZWYpIHtcbiAgICB0aGlzLnZpZXdRdWVyeSA9IHZpZXdRdWVyeTtcbiAgICB0aGlzLnF1ZXJ5ID0gcXVlcnk7XG4gIH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbXktY29tcCcsXG4gIGRpcmVjdGl2ZXM6IFtcbiAgICBOZWVkc1F1ZXJ5LFxuICAgIE5lZWRzUXVlcnlEZXNjLFxuICAgIE5lZWRzUXVlcnlCeUxhYmVsLFxuICAgIE5lZWRzUXVlcnlCeVR3b0xhYmVscyxcbiAgICBOZWVkc1F1ZXJ5QW5kUHJvamVjdCxcbiAgICBOZWVkc1ZpZXdRdWVyeSxcbiAgICBOZWVkc1ZpZXdRdWVyeUlmLFxuICAgIE5lZWRzVmlld1F1ZXJ5TmVzdGVkSWYsXG4gICAgTmVlZHNWaWV3UXVlcnlPcmRlcixcbiAgICBOZWVkc1ZpZXdRdWVyeUJ5TGFiZWwsXG4gICAgTmVlZHNWaWV3UXVlcnlPcmRlcldpdGhQYXJlbnQsXG4gICAgTmVlZHNDb250ZW50Q2hpbGRyZW4sXG4gICAgTmVlZHNWaWV3Q2hpbGRyZW4sXG4gICAgTmVlZHNWaWV3Q2hpbGQsXG4gICAgTmVlZHNDb250ZW50Q2hpbGQsXG4gICAgTmVlZHNUcGwsXG4gICAgVGV4dERpcmVjdGl2ZSxcbiAgICBJbmVydERpcmVjdGl2ZSxcbiAgICBOZ0lmLFxuICAgIE5nRm9yLFxuICAgIE5lZWRzRm91clF1ZXJpZXNcbiAgXSxcbiAgdGVtcGxhdGU6ICcnXG59KVxuQEluamVjdGFibGUoKVxuY2xhc3MgTXlDb21wIHtcbiAgc2hvdWxkU2hvdzogYm9vbGVhbjtcbiAgbGlzdDtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5zaG91bGRTaG93ID0gZmFsc2U7XG4gICAgdGhpcy5saXN0ID0gWycxZCcsICcyZCcsICczZCddO1xuICB9XG59XG4iXX0=
 main(); 
