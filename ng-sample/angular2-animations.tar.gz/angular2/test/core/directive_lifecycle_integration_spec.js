'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var metadata_1 = require('angular2/src/core/metadata');
function main() {
    testing_internal_1.describe('directive lifecycle integration spec', function () {
        testing_internal_1.it('should invoke lifecycle methods ngOnChanges > ngOnInit > ngDoCheck > ngAfterContentChecked', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.Log, testing_internal_1.AsyncTestCompleter], function (tcb, log, async) {
            tcb.overrideView(MyComp, new metadata_1.ViewMetadata({ template: '<div [field]="123" lifecycle></div>', directives: [LifecycleCmp] }))
                .createAsync(MyComp)
                .then(function (tc) {
                tc.detectChanges();
                testing_internal_1.expect(log.result())
                    .toEqual("ngOnChanges; ngOnInit; ngDoCheck; ngAfterContentInit; ngAfterContentChecked; child_ngDoCheck; " +
                    "ngAfterViewInit; ngAfterViewChecked");
                log.clear();
                tc.detectChanges();
                testing_internal_1.expect(log.result())
                    .toEqual("ngDoCheck; ngAfterContentChecked; child_ngDoCheck; ngAfterViewChecked");
                async.done();
            });
        }));
    });
}
exports.main = main;
var LifecycleDir = (function () {
    function LifecycleDir(_log) {
        this._log = _log;
    }
    LifecycleDir.prototype.ngDoCheck = function () { this._log.add("child_ngDoCheck"); };
    LifecycleDir = __decorate([
        metadata_1.Directive({ selector: '[lifecycle-dir]' }), 
        __metadata('design:paramtypes', [testing_internal_1.Log])
    ], LifecycleDir);
    return LifecycleDir;
})();
var LifecycleCmp = (function () {
    function LifecycleCmp(_log) {
        this._log = _log;
    }
    LifecycleCmp.prototype.ngOnChanges = function (_) { this._log.add("ngOnChanges"); };
    LifecycleCmp.prototype.ngOnInit = function () { this._log.add("ngOnInit"); };
    LifecycleCmp.prototype.ngDoCheck = function () { this._log.add("ngDoCheck"); };
    LifecycleCmp.prototype.ngAfterContentInit = function () { this._log.add("ngAfterContentInit"); };
    LifecycleCmp.prototype.ngAfterContentChecked = function () { this._log.add("ngAfterContentChecked"); };
    LifecycleCmp.prototype.ngAfterViewInit = function () { this._log.add("ngAfterViewInit"); };
    LifecycleCmp.prototype.ngAfterViewChecked = function () { this._log.add("ngAfterViewChecked"); };
    LifecycleCmp = __decorate([
        metadata_1.Component({
            selector: "[lifecycle]",
            inputs: ['field'],
            template: "<div lifecycle-dir></div>",
            directives: [LifecycleDir]
        }), 
        __metadata('design:paramtypes', [testing_internal_1.Log])
    ], LifecycleCmp);
    return LifecycleCmp;
})();
var MyComp = (function () {
    function MyComp() {
    }
    MyComp = __decorate([
        metadata_1.Component({ selector: 'my-comp', directives: [] }), 
        __metadata('design:paramtypes', [])
    ], MyComp);
    return MyComp;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlyZWN0aXZlX2xpZmVjeWNsZV9pbnRlZ3JhdGlvbl9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb3JlL2RpcmVjdGl2ZV9saWZlY3ljbGVfaW50ZWdyYXRpb25fc3BlYy50cyJdLCJuYW1lcyI6WyJtYWluIiwiTGlmZWN5Y2xlRGlyIiwiTGlmZWN5Y2xlRGlyLmNvbnN0cnVjdG9yIiwiTGlmZWN5Y2xlRGlyLm5nRG9DaGVjayIsIkxpZmVjeWNsZUNtcCIsIkxpZmVjeWNsZUNtcC5jb25zdHJ1Y3RvciIsIkxpZmVjeWNsZUNtcC5uZ09uQ2hhbmdlcyIsIkxpZmVjeWNsZUNtcC5uZ09uSW5pdCIsIkxpZmVjeWNsZUNtcC5uZ0RvQ2hlY2siLCJMaWZlY3ljbGVDbXAubmdBZnRlckNvbnRlbnRJbml0IiwiTGlmZWN5Y2xlQ21wLm5nQWZ0ZXJDb250ZW50Q2hlY2tlZCIsIkxpZmVjeWNsZUNtcC5uZ0FmdGVyVmlld0luaXQiLCJMaWZlY3ljbGVDbXAubmdBZnRlclZpZXdDaGVja2VkIiwiTXlDb21wIiwiTXlDb21wLmNvbnN0cnVjdG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxpQ0FhTywyQkFBMkIsQ0FBQyxDQUFBO0FBV25DLHlCQUFpRCw0QkFBNEIsQ0FBQyxDQUFBO0FBRTlFO0lBQ0VBLDJCQUFRQSxDQUFDQSxzQ0FBc0NBLEVBQUVBO1FBRS9DQSxxQkFBRUEsQ0FBQ0EsNEZBQTRGQSxFQUM1RkEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEsc0JBQUdBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEdBQVFBLEVBQ25DQSxLQUFLQTtZQUM1REEsR0FBR0EsQ0FBQ0EsWUFBWUEsQ0FDVEEsTUFBTUEsRUFDTkEsSUFBSUEsdUJBQVlBLENBQ1pBLEVBQUNBLFFBQVFBLEVBQUVBLHFDQUFxQ0EsRUFBRUEsVUFBVUEsRUFBRUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0E7aUJBQ3JGQSxXQUFXQSxDQUFDQSxNQUFNQSxDQUFDQTtpQkFDbkJBLElBQUlBLENBQUNBLFVBQUNBLEVBQUVBO2dCQUNQQSxFQUFFQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtnQkFFbkJBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQTtxQkFDZkEsT0FBT0EsQ0FDSkEsZ0dBQWdHQTtvQkFDaEdBLHFDQUFxQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRS9DQSxHQUFHQSxDQUFDQSxLQUFLQSxFQUFFQSxDQUFDQTtnQkFDWkEsRUFBRUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7Z0JBRW5CQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0E7cUJBQ2ZBLE9BQU9BLENBQ0pBLHVFQUF1RUEsQ0FBQ0EsQ0FBQ0E7Z0JBRWpGQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtZQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQTlCZSxZQUFJLE9BOEJuQixDQUFBO0FBR0Q7SUFFRUMsc0JBQW9CQSxJQUFTQTtRQUFUQyxTQUFJQSxHQUFKQSxJQUFJQSxDQUFLQTtJQUFHQSxDQUFDQTtJQUNqQ0QsZ0NBQVNBLEdBQVRBLGNBQWNFLElBQUlBLENBQUNBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFIbkRGO1FBQUNBLG9CQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxpQkFBaUJBLEVBQUNBLENBQUNBOztxQkFJeENBO0lBQURBLG1CQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQVNFRyxzQkFBb0JBLElBQVNBO1FBQVRDLFNBQUlBLEdBQUpBLElBQUlBLENBQUtBO0lBQUdBLENBQUNBO0lBRWpDRCxrQ0FBV0EsR0FBWEEsVUFBWUEsQ0FBQ0EsSUFBSUUsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFFaERGLCtCQUFRQSxHQUFSQSxjQUFhRyxJQUFJQSxDQUFDQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUV6Q0gsZ0NBQVNBLEdBQVRBLGNBQWNJLElBQUlBLENBQUNBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO0lBRTNDSix5Q0FBa0JBLEdBQWxCQSxjQUF1QkssSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0Esb0JBQW9CQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUU3REwsNENBQXFCQSxHQUFyQkEsY0FBMEJNLElBQUlBLENBQUNBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFFbkVOLHNDQUFlQSxHQUFmQSxjQUFvQk8sSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUV2RFAseUNBQWtCQSxHQUFsQkEsY0FBdUJRLElBQUlBLENBQUNBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUF2Qi9EUjtRQUFDQSxvQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsYUFBYUE7WUFDdkJBLE1BQU1BLEVBQUVBLENBQUNBLE9BQU9BLENBQUNBO1lBQ2pCQSxRQUFRQSxFQUFFQSwyQkFBMkJBO1lBQ3JDQSxVQUFVQSxFQUFFQSxDQUFDQSxZQUFZQSxDQUFDQTtTQUMzQkEsQ0FBQ0E7O3FCQW1CREE7SUFBREEsbUJBQUNBO0FBQURBLENBQUNBLEFBeEJELElBd0JDO0FBRUQ7SUFBQVM7SUFFQUMsQ0FBQ0E7SUFGREQ7UUFBQ0Esb0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLFNBQVNBLEVBQUVBLFVBQVVBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOztlQUVoREE7SUFBREEsYUFBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXN5bmNUZXN0Q29tcGxldGVyLFxuICBiZWZvcmVFYWNoLFxuICBkZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICBleHBlY3QsXG4gIGlpdCxcbiAgaW5qZWN0LFxuICBpdCxcbiAgeGRlc2NyaWJlLFxuICB4aXQsXG4gIExvZyxcbiAgVGVzdENvbXBvbmVudEJ1aWxkZXJcbn0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmltcG9ydCB7XG4gIE9uQ2hhbmdlcyxcbiAgT25Jbml0LFxuICBEb0NoZWNrLFxuICBBZnRlckNvbnRlbnRJbml0LFxuICBBZnRlckNvbnRlbnRDaGVja2VkLFxuICBBZnRlclZpZXdJbml0LFxuICBBZnRlclZpZXdDaGVja2VkXG59IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuaW1wb3J0IHtEaXJlY3RpdmUsIENvbXBvbmVudCwgVmlld01ldGFkYXRhfSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9tZXRhZGF0YSc7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgnZGlyZWN0aXZlIGxpZmVjeWNsZSBpbnRlZ3JhdGlvbiBzcGVjJywgKCkgPT4ge1xuXG4gICAgaXQoJ3Nob3VsZCBpbnZva2UgbGlmZWN5Y2xlIG1ldGhvZHMgbmdPbkNoYW5nZXMgPiBuZ09uSW5pdCA+IG5nRG9DaGVjayA+IG5nQWZ0ZXJDb250ZW50Q2hlY2tlZCcsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgTG9nLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgbG9nOiBMb2csXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMpID0+IHtcbiAgICAgICAgIHRjYi5vdmVycmlkZVZpZXcoXG4gICAgICAgICAgICAgICAgTXlDb21wLFxuICAgICAgICAgICAgICAgIG5ldyBWaWV3TWV0YWRhdGEoXG4gICAgICAgICAgICAgICAgICAgIHt0ZW1wbGF0ZTogJzxkaXYgW2ZpZWxkXT1cIjEyM1wiIGxpZmVjeWNsZT48L2Rpdj4nLCBkaXJlY3RpdmVzOiBbTGlmZWN5Y2xlQ21wXX0pKVxuICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhNeUNvbXApXG4gICAgICAgICAgICAgLnRoZW4oKHRjKSA9PiB7XG4gICAgICAgICAgICAgICB0Yy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgIGV4cGVjdChsb2cucmVzdWx0KCkpXG4gICAgICAgICAgICAgICAgICAgLnRvRXF1YWwoXG4gICAgICAgICAgICAgICAgICAgICAgIFwibmdPbkNoYW5nZXM7IG5nT25Jbml0OyBuZ0RvQ2hlY2s7IG5nQWZ0ZXJDb250ZW50SW5pdDsgbmdBZnRlckNvbnRlbnRDaGVja2VkOyBjaGlsZF9uZ0RvQ2hlY2s7IFwiICtcbiAgICAgICAgICAgICAgICAgICAgICAgXCJuZ0FmdGVyVmlld0luaXQ7IG5nQWZ0ZXJWaWV3Q2hlY2tlZFwiKTtcblxuICAgICAgICAgICAgICAgbG9nLmNsZWFyKCk7XG4gICAgICAgICAgICAgICB0Yy5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgIGV4cGVjdChsb2cucmVzdWx0KCkpXG4gICAgICAgICAgICAgICAgICAgLnRvRXF1YWwoXG4gICAgICAgICAgICAgICAgICAgICAgIFwibmdEb0NoZWNrOyBuZ0FmdGVyQ29udGVudENoZWNrZWQ7IGNoaWxkX25nRG9DaGVjazsgbmdBZnRlclZpZXdDaGVja2VkXCIpO1xuXG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuICB9KTtcbn1cblxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJ1tsaWZlY3ljbGUtZGlyXSd9KVxuY2xhc3MgTGlmZWN5Y2xlRGlyIGltcGxlbWVudHMgRG9DaGVjayB7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgX2xvZzogTG9nKSB7fVxuICBuZ0RvQ2hlY2soKSB7IHRoaXMuX2xvZy5hZGQoXCJjaGlsZF9uZ0RvQ2hlY2tcIik7IH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiBcIltsaWZlY3ljbGVdXCIsXG4gIGlucHV0czogWydmaWVsZCddLFxuICB0ZW1wbGF0ZTogYDxkaXYgbGlmZWN5Y2xlLWRpcj48L2Rpdj5gLFxuICBkaXJlY3RpdmVzOiBbTGlmZWN5Y2xlRGlyXVxufSlcbmNsYXNzIExpZmVjeWNsZUNtcCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyxcbiAgICBPbkluaXQsIERvQ2hlY2ssIEFmdGVyQ29udGVudEluaXQsIEFmdGVyQ29udGVudENoZWNrZWQsIEFmdGVyVmlld0luaXQsIEFmdGVyVmlld0NoZWNrZWQge1xuICBmaWVsZDtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBfbG9nOiBMb2cpIHt9XG5cbiAgbmdPbkNoYW5nZXMoXykgeyB0aGlzLl9sb2cuYWRkKFwibmdPbkNoYW5nZXNcIik7IH1cblxuICBuZ09uSW5pdCgpIHsgdGhpcy5fbG9nLmFkZChcIm5nT25Jbml0XCIpOyB9XG5cbiAgbmdEb0NoZWNrKCkgeyB0aGlzLl9sb2cuYWRkKFwibmdEb0NoZWNrXCIpOyB9XG5cbiAgbmdBZnRlckNvbnRlbnRJbml0KCkgeyB0aGlzLl9sb2cuYWRkKFwibmdBZnRlckNvbnRlbnRJbml0XCIpOyB9XG5cbiAgbmdBZnRlckNvbnRlbnRDaGVja2VkKCkgeyB0aGlzLl9sb2cuYWRkKFwibmdBZnRlckNvbnRlbnRDaGVja2VkXCIpOyB9XG5cbiAgbmdBZnRlclZpZXdJbml0KCkgeyB0aGlzLl9sb2cuYWRkKFwibmdBZnRlclZpZXdJbml0XCIpOyB9XG5cbiAgbmdBZnRlclZpZXdDaGVja2VkKCkgeyB0aGlzLl9sb2cuYWRkKFwibmdBZnRlclZpZXdDaGVja2VkXCIpOyB9XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnbXktY29tcCcsIGRpcmVjdGl2ZXM6IFtdfSlcbmNsYXNzIE15Q29tcCB7XG59XG4iXX0=
 main(); 
