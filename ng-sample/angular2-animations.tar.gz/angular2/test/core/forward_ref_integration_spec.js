'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var testing_internal_1 = require('angular2/testing_internal');
var core_1 = require('angular2/core');
var common_1 = require('angular2/common');
var core_2 = require('angular2/core');
function main() {
    testing_internal_1.describe("forwardRef integration", function () {
        testing_internal_1.it('should instantiate components which are declared using forwardRef', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            tcb.createAsync(App).then(function (tc) {
                tc.detectChanges();
                testing_internal_1.expect(core_2.asNativeElements(tc.debugElement.children)).toHaveText('frame(lock)');
                async.done();
            });
        }));
    });
}
exports.main = main;
var App = (function () {
    function App() {
    }
    App = __decorate([
        core_1.Component({
            selector: 'app',
            viewProviders: [core_1.forwardRef(function () { return Frame; })],
            template: "<door><lock></lock></door>",
            directives: [core_1.forwardRef(function () { return Door; }), core_1.forwardRef(function () { return Lock; })],
        }), 
        __metadata('design:paramtypes', [])
    ], App);
    return App;
})();
var Door = (function () {
    function Door(locks, frame) {
        this.frame = frame;
        this.locks = locks;
    }
    Door = __decorate([
        core_1.Component({
            selector: 'lock',
            directives: [common_1.NgFor],
            template: "{{frame.name}}(<span *ngFor=\"var lock of locks\">{{lock.name}}</span>)",
        }),
        __param(0, core_1.Query(core_1.forwardRef(function () { return Lock; }))),
        __param(1, core_1.Inject(core_1.forwardRef(function () { return Frame; }))), 
        __metadata('design:paramtypes', [core_1.QueryList, Frame])
    ], Door);
    return Door;
})();
var Frame = (function () {
    function Frame() {
        this.name = 'frame';
    }
    return Frame;
})();
var Lock = (function () {
    function Lock() {
        this.name = 'lock';
    }
    Lock = __decorate([
        core_1.Directive({ selector: 'lock' }), 
        __metadata('design:paramtypes', [])
    ], Lock);
    return Lock;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9yd2FyZF9yZWZfaW50ZWdyYXRpb25fc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29yZS9mb3J3YXJkX3JlZl9pbnRlZ3JhdGlvbl9zcGVjLnRzIl0sIm5hbWVzIjpbIm1haW4iLCJBcHAiLCJBcHAuY29uc3RydWN0b3IiLCJEb29yIiwiRG9vci5jb25zdHJ1Y3RvciIsIkZyYW1lIiwiRnJhbWUuY29uc3RydWN0b3IiLCJMb2NrIiwiTG9jay5jb25zdHJ1Y3RvciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEsaUNBV08sMkJBQTJCLENBQUMsQ0FBQTtBQUNuQyxxQkFVTyxlQUFlLENBQUMsQ0FBQTtBQUN2Qix1QkFBb0IsaUJBQWlCLENBQUMsQ0FBQTtBQUV0QyxxQkFBK0IsZUFBZSxDQUFDLENBQUE7QUFFL0M7SUFDRUEsMkJBQVFBLENBQUNBLHdCQUF3QkEsRUFBRUE7UUFDakMscUJBQUUsQ0FBQyxtRUFBbUUsRUFDbkUseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxHQUF5QixFQUFFLEtBQUs7WUFDbEYsR0FBRyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxFQUFFO2dCQUMzQixFQUFFLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ25CLHlCQUFNLENBQUMsdUJBQWdCLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDN0UsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ1QsQ0FBQyxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQVhlLFlBQUksT0FXbkIsQ0FBQTtBQUVEO0lBQUFDO0lBT0FDLENBQUNBO0lBUEREO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxLQUFLQTtZQUNmQSxhQUFhQSxFQUFFQSxDQUFDQSxpQkFBVUEsQ0FBQ0EsY0FBTUEsT0FBQUEsS0FBS0EsRUFBTEEsQ0FBS0EsQ0FBQ0EsQ0FBQ0E7WUFDeENBLFFBQVFBLEVBQUVBLDRCQUE0QkE7WUFDdENBLFVBQVVBLEVBQUVBLENBQUNBLGlCQUFVQSxDQUFDQSxjQUFNQSxPQUFBQSxJQUFJQSxFQUFKQSxDQUFJQSxDQUFDQSxFQUFFQSxpQkFBVUEsQ0FBQ0EsY0FBTUEsT0FBQUEsSUFBSUEsRUFBSkEsQ0FBSUEsQ0FBQ0EsQ0FBQ0E7U0FDN0RBLENBQUNBOztZQUVEQTtJQUFEQSxVQUFDQTtBQUFEQSxDQUFDQSxBQVBELElBT0M7QUFFRDtJQVNFRSxjQUEyQ0EsS0FBc0JBLEVBQ3BCQSxLQUFZQTtRQUN2REMsSUFBSUEsQ0FBQ0EsS0FBS0EsR0FBR0EsS0FBS0EsQ0FBQ0E7UUFDbkJBLElBQUlBLENBQUNBLEtBQUtBLEdBQUdBLEtBQUtBLENBQUNBO0lBQ3JCQSxDQUFDQTtJQWJIRDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsTUFBTUE7WUFDaEJBLFVBQVVBLEVBQUVBLENBQUNBLGNBQUtBLENBQUNBO1lBQ25CQSxRQUFRQSxFQUFFQSx5RUFBdUVBO1NBQ2xGQSxDQUFDQTtRQUtZQSxXQUFDQSxZQUFLQSxDQUFDQSxpQkFBVUEsQ0FBQ0EsY0FBTUEsT0FBQUEsSUFBSUEsRUFBSkEsQ0FBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQUE7UUFDOUJBLFdBQUNBLGFBQU1BLENBQUNBLGlCQUFVQSxDQUFDQSxjQUFNQSxPQUFBQSxLQUFLQSxFQUFMQSxDQUFLQSxDQUFDQSxDQUFDQSxDQUFBQTs7YUFJN0NBO0lBQURBLFdBQUNBO0FBQURBLENBQUNBLEFBZEQsSUFjQztBQUVEO0lBRUVFO1FBQWdCQyxJQUFJQSxDQUFDQSxJQUFJQSxHQUFHQSxPQUFPQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUN4Q0QsWUFBQ0E7QUFBREEsQ0FBQ0EsQUFIRCxJQUdDO0FBRUQ7SUFHRUU7UUFBZ0JDLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLE1BQU1BLENBQUNBO0lBQUNBLENBQUNBO0lBSHZDRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsTUFBTUEsRUFBQ0EsQ0FBQ0E7O2FBSTdCQTtJQUFEQSxXQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBc3luY1Rlc3RDb21wbGV0ZXIsXG4gIFRlc3RDb21wb25lbnRCdWlsZGVyLFxuICBiZWZvcmVFYWNoLFxuICBkZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICBleHBlY3QsXG4gIGlpdCxcbiAgaW5qZWN0LFxuICBpdCxcbiAgeGl0XG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuaW1wb3J0IHtcbiAgYmluZCxcbiAgcHJvdmlkZSxcbiAgZm9yd2FyZFJlZixcbiAgcmVzb2x2ZUZvcndhcmRSZWYsXG4gIENvbXBvbmVudCxcbiAgRGlyZWN0aXZlLFxuICBJbmplY3QsXG4gIFF1ZXJ5LFxuICBRdWVyeUxpc3Rcbn0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5pbXBvcnQge05nRm9yfSBmcm9tICdhbmd1bGFyMi9jb21tb24nO1xuaW1wb3J0IHtUeXBlfSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2xhbmcnO1xuaW1wb3J0IHthc05hdGl2ZUVsZW1lbnRzfSBmcm9tICdhbmd1bGFyMi9jb3JlJztcblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGRlc2NyaWJlKFwiZm9yd2FyZFJlZiBpbnRlZ3JhdGlvblwiLCBmdW5jdGlvbigpIHtcbiAgICBpdCgnc2hvdWxkIGluc3RhbnRpYXRlIGNvbXBvbmVudHMgd2hpY2ggYXJlIGRlY2xhcmVkIHVzaW5nIGZvcndhcmRSZWYnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgdGNiLmNyZWF0ZUFzeW5jKEFwcCkudGhlbigodGMpID0+IHtcbiAgICAgICAgICAgdGMuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICBleHBlY3QoYXNOYXRpdmVFbGVtZW50cyh0Yy5kZWJ1Z0VsZW1lbnQuY2hpbGRyZW4pKS50b0hhdmVUZXh0KCdmcmFtZShsb2NrKScpO1xuICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICB9KTtcbiAgICAgICB9KSk7XG4gIH0pO1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdhcHAnLFxuICB2aWV3UHJvdmlkZXJzOiBbZm9yd2FyZFJlZigoKSA9PiBGcmFtZSldLFxuICB0ZW1wbGF0ZTogYDxkb29yPjxsb2NrPjwvbG9jaz48L2Rvb3I+YCxcbiAgZGlyZWN0aXZlczogW2ZvcndhcmRSZWYoKCkgPT4gRG9vciksIGZvcndhcmRSZWYoKCkgPT4gTG9jayldLFxufSlcbmNsYXNzIEFwcCB7XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2xvY2snLFxuICBkaXJlY3RpdmVzOiBbTmdGb3JdLFxuICB0ZW1wbGF0ZTogYHt7ZnJhbWUubmFtZX19KDxzcGFuICpuZ0Zvcj1cInZhciBsb2NrIG9mIGxvY2tzXCI+e3tsb2NrLm5hbWV9fTwvc3Bhbj4pYCxcbn0pXG5jbGFzcyBEb29yIHtcbiAgbG9ja3M6IFF1ZXJ5TGlzdDxMb2NrPjtcbiAgZnJhbWU6IEZyYW1lO1xuXG4gIGNvbnN0cnVjdG9yKEBRdWVyeShmb3J3YXJkUmVmKCgpID0+IExvY2spKSBsb2NrczogUXVlcnlMaXN0PExvY2s+LFxuICAgICAgICAgICAgICBASW5qZWN0KGZvcndhcmRSZWYoKCkgPT4gRnJhbWUpKSBmcmFtZTogRnJhbWUpIHtcbiAgICB0aGlzLmZyYW1lID0gZnJhbWU7XG4gICAgdGhpcy5sb2NrcyA9IGxvY2tzO1xuICB9XG59XG5cbmNsYXNzIEZyYW1lIHtcbiAgbmFtZTogc3RyaW5nO1xuICBjb25zdHJ1Y3RvcigpIHsgdGhpcy5uYW1lID0gJ2ZyYW1lJzsgfVxufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJ2xvY2snfSlcbmNsYXNzIExvY2sge1xuICBuYW1lOiBzdHJpbmc7XG4gIGNvbnN0cnVjdG9yKCkgeyB0aGlzLm5hbWUgPSAnbG9jayc7IH1cbn1cbiJdfQ==
 main(); 
