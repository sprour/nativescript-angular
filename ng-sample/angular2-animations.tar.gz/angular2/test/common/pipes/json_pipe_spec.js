'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var lang_1 = require('angular2/src/facade/lang');
var core_1 = require('angular2/core');
var common_1 = require('angular2/common');
function main() {
    testing_internal_1.describe("JsonPipe", function () {
        var regNewLine = '\n';
        var inceptionObj;
        var inceptionObjString;
        var pipe;
        function normalize(obj) { return lang_1.StringWrapper.replace(obj, regNewLine, ''); }
        testing_internal_1.beforeEach(function () {
            inceptionObj = { dream: { dream: { dream: 'Limbo' } } };
            inceptionObjString = "{\n" + "  \"dream\": {\n" + "    \"dream\": {\n" +
                "      \"dream\": \"Limbo\"\n" + "    }\n" + "  }\n" + "}";
            pipe = new common_1.JsonPipe();
        });
        testing_internal_1.describe("transform", function () {
            testing_internal_1.it("should return JSON-formatted string", function () { testing_internal_1.expect(pipe.transform(inceptionObj)).toEqual(inceptionObjString); });
            testing_internal_1.it("should return JSON-formatted string even when normalized", function () {
                var dream1 = normalize(pipe.transform(inceptionObj));
                var dream2 = normalize(inceptionObjString);
                testing_internal_1.expect(dream1).toEqual(dream2);
            });
            testing_internal_1.it("should return JSON-formatted string similar to Json.stringify", function () {
                var dream1 = normalize(pipe.transform(inceptionObj));
                var dream2 = normalize(lang_1.Json.stringify(inceptionObj));
                testing_internal_1.expect(dream1).toEqual(dream2);
            });
        });
        testing_internal_1.describe('integration', function () {
            testing_internal_1.it('should work with mutable objects', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                tcb.createAsync(TestComp).then(function (fixture) {
                    var mutable = [1];
                    fixture.debugElement.componentInstance.data = mutable;
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText("[\n  1\n]");
                    mutable.push(2);
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText("[\n  1,\n  2\n]");
                    async.done();
                });
            }));
        });
    });
}
exports.main = main;
var TestComp = (function () {
    function TestComp() {
    }
    TestComp = __decorate([
        core_1.Component({ selector: 'test-comp', template: '{{data | json}}', pipes: [common_1.JsonPipe] }), 
        __metadata('design:paramtypes', [])
    ], TestComp);
    return TestComp;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianNvbl9waXBlX3NwZWMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L2NvbW1vbi9waXBlcy9qc29uX3BpcGVfc3BlYy50cyJdLCJuYW1lcyI6WyJtYWluIiwibWFpbi5ub3JtYWxpemUiLCJUZXN0Q29tcCIsIlRlc3RDb21wLmNvbnN0cnVjdG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxpQ0FhTywyQkFBMkIsQ0FBQyxDQUFBO0FBQ25DLHFCQUF5RCwwQkFBMEIsQ0FBQyxDQUFBO0FBRXBGLHFCQUF3QixlQUFlLENBQUMsQ0FBQTtBQUN4Qyx1QkFBdUIsaUJBQWlCLENBQUMsQ0FBQTtBQUV6QztJQUNFQSwyQkFBUUEsQ0FBQ0EsVUFBVUEsRUFBRUE7UUFDbkJBLElBQUlBLFVBQVVBLEdBQUdBLElBQUlBLENBQUNBO1FBQ3RCQSxJQUFJQSxZQUFZQSxDQUFDQTtRQUNqQkEsSUFBSUEsa0JBQWtCQSxDQUFDQTtRQUN2QkEsSUFBSUEsSUFBSUEsQ0FBQ0E7UUFFVEEsbUJBQW1CQSxHQUFXQSxJQUFZQyxNQUFNQSxDQUFDQSxvQkFBYUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsR0FBR0EsRUFBRUEsVUFBVUEsRUFBRUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFOUZELDZCQUFVQSxDQUFDQTtZQUNUQSxZQUFZQSxHQUFHQSxFQUFDQSxLQUFLQSxFQUFFQSxFQUFDQSxLQUFLQSxFQUFFQSxFQUFDQSxLQUFLQSxFQUFFQSxPQUFPQSxFQUFDQSxFQUFDQSxFQUFDQSxDQUFDQTtZQUNsREEsa0JBQWtCQSxHQUFHQSxLQUFLQSxHQUFHQSxrQkFBa0JBLEdBQUdBLG9CQUFvQkE7Z0JBQ2pEQSw4QkFBOEJBLEdBQUdBLFNBQVNBLEdBQUdBLE9BQU9BLEdBQUdBLEdBQUdBLENBQUNBO1lBR2hGQSxJQUFJQSxHQUFHQSxJQUFJQSxpQkFBUUEsRUFBRUEsQ0FBQ0E7UUFDeEJBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLDJCQUFRQSxDQUFDQSxXQUFXQSxFQUFFQTtZQUNwQkEscUJBQUVBLENBQUNBLHFDQUFxQ0EsRUFDckNBLGNBQVFBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxTQUFTQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxrQkFBa0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRWhGQSxxQkFBRUEsQ0FBQ0EsMERBQTBEQSxFQUFFQTtnQkFDN0RBLElBQUlBLE1BQU1BLEdBQUdBLFNBQVNBLENBQUNBLElBQUlBLENBQUNBLFNBQVNBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBO2dCQUNyREEsSUFBSUEsTUFBTUEsR0FBR0EsU0FBU0EsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxDQUFDQTtnQkFDM0NBLHlCQUFNQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTtZQUNqQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLCtEQUErREEsRUFBRUE7Z0JBQ2xFQSxJQUFJQSxNQUFNQSxHQUFHQSxTQUFTQSxDQUFDQSxJQUFJQSxDQUFDQSxTQUFTQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDckRBLElBQUlBLE1BQU1BLEdBQUdBLFNBQVNBLENBQUNBLFdBQUlBLENBQUNBLFNBQVNBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBO2dCQUNyREEseUJBQU1BLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO1lBQ2pDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsYUFBYUEsRUFBRUE7WUFDdEJBLHFCQUFFQSxDQUFDQSxrQ0FBa0NBLEVBQ2xDQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtnQkFDbEZBLEdBQUdBLENBQUNBLFdBQVdBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLFVBQUNBLE9BQU9BO29CQUNyQ0EsSUFBSUEsT0FBT0EsR0FBYUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQzVCQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLElBQUlBLEdBQUdBLE9BQU9BLENBQUNBO29CQUN0REEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsQ0FBQ0E7b0JBRW5FQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDaEJBLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUN4QkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0E7b0JBRXpFQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7QUFDTEEsQ0FBQ0E7QUFyRGUsWUFBSSxPQXFEbkIsQ0FBQTtBQUVEO0lBQUFFO0lBR0FDLENBQUNBO0lBSEREO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxXQUFXQSxFQUFFQSxRQUFRQSxFQUFFQSxpQkFBaUJBLEVBQUVBLEtBQUtBLEVBQUVBLENBQUNBLGlCQUFRQSxDQUFDQSxFQUFDQSxDQUFDQTs7aUJBR2xGQTtJQUFEQSxlQUFDQTtBQUFEQSxDQUFDQSxBQUhELElBR0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBkZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICBpdCxcbiAgaWl0LFxuICB4aXQsXG4gIGV4cGVjdCxcbiAgYmVmb3JlRWFjaCxcbiAgYWZ0ZXJFYWNoLFxuICBBc3luY1Rlc3RDb21wbGV0ZXIsXG4gIGluamVjdCxcbiAgcHJveHksXG4gIFRlc3RDb21wb25lbnRCdWlsZGVyXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuaW1wb3J0IHtKc29uLCBSZWdFeHAsIE51bWJlcldyYXBwZXIsIFN0cmluZ1dyYXBwZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvbGFuZyc7XG5cbmltcG9ydCB7Q29tcG9uZW50fSBmcm9tICdhbmd1bGFyMi9jb3JlJztcbmltcG9ydCB7SnNvblBpcGV9IGZyb20gJ2FuZ3VsYXIyL2NvbW1vbic7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZShcIkpzb25QaXBlXCIsICgpID0+IHtcbiAgICB2YXIgcmVnTmV3TGluZSA9ICdcXG4nO1xuICAgIHZhciBpbmNlcHRpb25PYmo7XG4gICAgdmFyIGluY2VwdGlvbk9ialN0cmluZztcbiAgICB2YXIgcGlwZTtcblxuICAgIGZ1bmN0aW9uIG5vcm1hbGl6ZShvYmo6IHN0cmluZyk6IHN0cmluZyB7IHJldHVybiBTdHJpbmdXcmFwcGVyLnJlcGxhY2Uob2JqLCByZWdOZXdMaW5lLCAnJyk7IH1cblxuICAgIGJlZm9yZUVhY2goKCkgPT4ge1xuICAgICAgaW5jZXB0aW9uT2JqID0ge2RyZWFtOiB7ZHJlYW06IHtkcmVhbTogJ0xpbWJvJ319fTtcbiAgICAgIGluY2VwdGlvbk9ialN0cmluZyA9IFwie1xcblwiICsgXCIgIFxcXCJkcmVhbVxcXCI6IHtcXG5cIiArIFwiICAgIFxcXCJkcmVhbVxcXCI6IHtcXG5cIiArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBcIiAgICAgIFxcXCJkcmVhbVxcXCI6IFxcXCJMaW1ib1xcXCJcXG5cIiArIFwiICAgIH1cXG5cIiArIFwiICB9XFxuXCIgKyBcIn1cIjtcblxuXG4gICAgICBwaXBlID0gbmV3IEpzb25QaXBlKCk7XG4gICAgfSk7XG5cbiAgICBkZXNjcmliZShcInRyYW5zZm9ybVwiLCAoKSA9PiB7XG4gICAgICBpdChcInNob3VsZCByZXR1cm4gSlNPTi1mb3JtYXR0ZWQgc3RyaW5nXCIsXG4gICAgICAgICAoKSA9PiB7IGV4cGVjdChwaXBlLnRyYW5zZm9ybShpbmNlcHRpb25PYmopKS50b0VxdWFsKGluY2VwdGlvbk9ialN0cmluZyk7IH0pO1xuXG4gICAgICBpdChcInNob3VsZCByZXR1cm4gSlNPTi1mb3JtYXR0ZWQgc3RyaW5nIGV2ZW4gd2hlbiBub3JtYWxpemVkXCIsICgpID0+IHtcbiAgICAgICAgdmFyIGRyZWFtMSA9IG5vcm1hbGl6ZShwaXBlLnRyYW5zZm9ybShpbmNlcHRpb25PYmopKTtcbiAgICAgICAgdmFyIGRyZWFtMiA9IG5vcm1hbGl6ZShpbmNlcHRpb25PYmpTdHJpbmcpO1xuICAgICAgICBleHBlY3QoZHJlYW0xKS50b0VxdWFsKGRyZWFtMik7XG4gICAgICB9KTtcblxuICAgICAgaXQoXCJzaG91bGQgcmV0dXJuIEpTT04tZm9ybWF0dGVkIHN0cmluZyBzaW1pbGFyIHRvIEpzb24uc3RyaW5naWZ5XCIsICgpID0+IHtcbiAgICAgICAgdmFyIGRyZWFtMSA9IG5vcm1hbGl6ZShwaXBlLnRyYW5zZm9ybShpbmNlcHRpb25PYmopKTtcbiAgICAgICAgdmFyIGRyZWFtMiA9IG5vcm1hbGl6ZShKc29uLnN0cmluZ2lmeShpbmNlcHRpb25PYmopKTtcbiAgICAgICAgZXhwZWN0KGRyZWFtMSkudG9FcXVhbChkcmVhbTIpO1xuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICBkZXNjcmliZSgnaW50ZWdyYXRpb24nLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIHdvcmsgd2l0aCBtdXRhYmxlIG9iamVjdHMnLFxuICAgICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHRjYi5jcmVhdGVBc3luYyhUZXN0Q29tcCkudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgIGxldCBtdXRhYmxlOiBudW1iZXJbXSA9IFsxXTtcbiAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5kYXRhID0gbXV0YWJsZTtcbiAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dChcIltcXG4gIDFcXG5dXCIpO1xuXG4gICAgICAgICAgICAgbXV0YWJsZS5wdXNoKDIpO1xuICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KFwiW1xcbiAgMSxcXG4gIDJcXG5dXCIpO1xuXG4gICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcbiAgICB9KTtcbiAgfSk7XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAndGVzdC1jb21wJywgdGVtcGxhdGU6ICd7e2RhdGEgfCBqc29ufX0nLCBwaXBlczogW0pzb25QaXBlXX0pXG5jbGFzcyBUZXN0Q29tcCB7XG4gIGRhdGE6IGFueTtcbn1cbiJdfQ==
 main(); 
