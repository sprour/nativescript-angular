'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var common_1 = require('angular2/common');
function main() {
    testing_internal_1.describe("LowerCasePipe", function () {
        var upper;
        var lower;
        var pipe;
        testing_internal_1.beforeEach(function () {
            lower = 'something';
            upper = 'SOMETHING';
            pipe = new common_1.LowerCasePipe();
        });
        testing_internal_1.describe("transform", function () {
            testing_internal_1.it("should return lowercase", function () {
                var val = pipe.transform(upper);
                testing_internal_1.expect(val).toEqual(lower);
            });
            testing_internal_1.it("should lowercase when there is a new value", function () {
                var val = pipe.transform(upper);
                testing_internal_1.expect(val).toEqual(lower);
                var val2 = pipe.transform('WAT');
                testing_internal_1.expect(val2).toEqual('wat');
            });
            testing_internal_1.it("should not support other objects", function () { testing_internal_1.expect(function () { return pipe.transform(new Object()); }).toThrowError(); });
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG93ZXJjYXNlX3BpcGVfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29tbW9uL3BpcGVzL2xvd2VyY2FzZV9waXBlX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiJdLCJtYXBwaW5ncyI6IkFBQUEsaUNBU08sMkJBQTJCLENBQUMsQ0FBQTtBQUVuQyx1QkFBNEIsaUJBQWlCLENBQUMsQ0FBQTtBQUU5QztJQUNFQSwyQkFBUUEsQ0FBQ0EsZUFBZUEsRUFBRUE7UUFDeEJBLElBQUlBLEtBQUtBLENBQUNBO1FBQ1ZBLElBQUlBLEtBQUtBLENBQUNBO1FBQ1ZBLElBQUlBLElBQUlBLENBQUNBO1FBRVRBLDZCQUFVQSxDQUFDQTtZQUNUQSxLQUFLQSxHQUFHQSxXQUFXQSxDQUFDQTtZQUNwQkEsS0FBS0EsR0FBR0EsV0FBV0EsQ0FBQ0E7WUFDcEJBLElBQUlBLEdBQUdBLElBQUlBLHNCQUFhQSxFQUFFQSxDQUFDQTtRQUM3QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEsMkJBQVFBLENBQUNBLFdBQVdBLEVBQUVBO1lBQ3BCQSxxQkFBRUEsQ0FBQ0EseUJBQXlCQSxFQUFFQTtnQkFDNUJBLElBQUlBLEdBQUdBLEdBQUdBLElBQUlBLENBQUNBLFNBQVNBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO2dCQUNoQ0EseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO1lBQzdCQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsNENBQTRDQSxFQUFFQTtnQkFDL0NBLElBQUlBLEdBQUdBLEdBQUdBLElBQUlBLENBQUNBLFNBQVNBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO2dCQUNoQ0EseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO2dCQUMzQkEsSUFBSUEsSUFBSUEsR0FBR0EsSUFBSUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ2pDQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0E7WUFDOUJBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxrQ0FBa0NBLEVBQ2xDQSxjQUFRQSx5QkFBTUEsQ0FBQ0EsY0FBTUEsT0FBQUEsSUFBSUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsSUFBSUEsTUFBTUEsRUFBRUEsQ0FBQ0EsRUFBNUJBLENBQTRCQSxDQUFDQSxDQUFDQSxZQUFZQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUMzRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFFTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7QUFDTEEsQ0FBQ0E7QUE5QmUsWUFBSSxPQThCbkIsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIGRkZXNjcmliZSxcbiAgZGVzY3JpYmUsXG4gIGl0LFxuICBpaXQsXG4gIHhpdCxcbiAgZXhwZWN0LFxuICBiZWZvcmVFYWNoLFxuICBhZnRlckVhY2hcbn0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmltcG9ydCB7TG93ZXJDYXNlUGlwZX0gZnJvbSAnYW5ndWxhcjIvY29tbW9uJztcblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGRlc2NyaWJlKFwiTG93ZXJDYXNlUGlwZVwiLCAoKSA9PiB7XG4gICAgdmFyIHVwcGVyO1xuICAgIHZhciBsb3dlcjtcbiAgICB2YXIgcGlwZTtcblxuICAgIGJlZm9yZUVhY2goKCkgPT4ge1xuICAgICAgbG93ZXIgPSAnc29tZXRoaW5nJztcbiAgICAgIHVwcGVyID0gJ1NPTUVUSElORyc7XG4gICAgICBwaXBlID0gbmV3IExvd2VyQ2FzZVBpcGUoKTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKFwidHJhbnNmb3JtXCIsICgpID0+IHtcbiAgICAgIGl0KFwic2hvdWxkIHJldHVybiBsb3dlcmNhc2VcIiwgKCkgPT4ge1xuICAgICAgICB2YXIgdmFsID0gcGlwZS50cmFuc2Zvcm0odXBwZXIpO1xuICAgICAgICBleHBlY3QodmFsKS50b0VxdWFsKGxvd2VyKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdChcInNob3VsZCBsb3dlcmNhc2Ugd2hlbiB0aGVyZSBpcyBhIG5ldyB2YWx1ZVwiLCAoKSA9PiB7XG4gICAgICAgIHZhciB2YWwgPSBwaXBlLnRyYW5zZm9ybSh1cHBlcik7XG4gICAgICAgIGV4cGVjdCh2YWwpLnRvRXF1YWwobG93ZXIpO1xuICAgICAgICB2YXIgdmFsMiA9IHBpcGUudHJhbnNmb3JtKCdXQVQnKTtcbiAgICAgICAgZXhwZWN0KHZhbDIpLnRvRXF1YWwoJ3dhdCcpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KFwic2hvdWxkIG5vdCBzdXBwb3J0IG90aGVyIG9iamVjdHNcIixcbiAgICAgICAgICgpID0+IHsgZXhwZWN0KCgpID0+IHBpcGUudHJhbnNmb3JtKG5ldyBPYmplY3QoKSkpLnRvVGhyb3dFcnJvcigpOyB9KTtcbiAgICB9KTtcblxuICB9KTtcbn1cbiJdfQ==
 main(); 
