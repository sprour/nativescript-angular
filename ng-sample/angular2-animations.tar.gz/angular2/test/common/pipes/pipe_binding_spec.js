'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var pipe_provider_1 = require('angular2/src/core/pipes/pipe_provider');
var metadata_1 = require('angular2/src/core/metadata');
var MyPipe = (function () {
    function MyPipe() {
    }
    return MyPipe;
})();
function main() {
    testing_internal_1.describe("PipeProvider", function () {
        testing_internal_1.it('should create a provider out of a type', function () {
            var provider = pipe_provider_1.PipeProvider.createFromType(MyPipe, new metadata_1.Pipe({ name: 'my-pipe' }));
            testing_internal_1.expect(provider.name).toEqual('my-pipe');
            testing_internal_1.expect(provider.key.token).toEqual(MyPipe);
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGlwZV9iaW5kaW5nX3NwZWMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L2NvbW1vbi9waXBlcy9waXBlX2JpbmRpbmdfc3BlYy50cyJdLCJuYW1lcyI6WyJNeVBpcGUiLCJNeVBpcGUuY29uc3RydWN0b3IiLCJtYWluIl0sIm1hcHBpbmdzIjoiQUFBQSxpQ0FVTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLDhCQUEyQix1Q0FBdUMsQ0FBQyxDQUFBO0FBQ25FLHlCQUFtQiw0QkFBNEIsQ0FBQyxDQUFBO0FBRWhEO0lBQUFBO0lBQWNDLENBQUNBO0lBQURELGFBQUNBO0FBQURBLENBQUNBLEFBQWYsSUFBZTtBQUVmO0lBQ0VFLDJCQUFRQSxDQUFDQSxjQUFjQSxFQUFFQTtRQUN2QkEscUJBQUVBLENBQUNBLHdDQUF3Q0EsRUFBRUE7WUFDM0NBLElBQUlBLFFBQVFBLEdBQUdBLDRCQUFZQSxDQUFDQSxjQUFjQSxDQUFDQSxNQUFNQSxFQUFFQSxJQUFJQSxlQUFJQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxTQUFTQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNoRkEseUJBQU1BLENBQUNBLFFBQVFBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLFNBQVNBLENBQUNBLENBQUNBO1lBQ3pDQSx5QkFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7UUFDN0NBLENBQUNBLENBQUNBLENBQUNBO0lBQ0xBLENBQUNBLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBUmUsWUFBSSxPQVFuQixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgZGRlc2NyaWJlLFxuICB4ZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICBpdCxcbiAgaWl0LFxuICB4aXQsXG4gIGV4cGVjdCxcbiAgYmVmb3JlRWFjaCxcbiAgYWZ0ZXJFYWNoXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5pbXBvcnQge1BpcGVQcm92aWRlcn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvcGlwZXMvcGlwZV9wcm92aWRlcic7XG5pbXBvcnQge1BpcGV9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL21ldGFkYXRhJztcblxuY2xhc3MgTXlQaXBlIHt9XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZShcIlBpcGVQcm92aWRlclwiLCAoKSA9PiB7XG4gICAgaXQoJ3Nob3VsZCBjcmVhdGUgYSBwcm92aWRlciBvdXQgb2YgYSB0eXBlJywgKCkgPT4ge1xuICAgICAgdmFyIHByb3ZpZGVyID0gUGlwZVByb3ZpZGVyLmNyZWF0ZUZyb21UeXBlKE15UGlwZSwgbmV3IFBpcGUoe25hbWU6ICdteS1waXBlJ30pKTtcbiAgICAgIGV4cGVjdChwcm92aWRlci5uYW1lKS50b0VxdWFsKCdteS1waXBlJyk7XG4gICAgICBleHBlY3QocHJvdmlkZXIua2V5LnRva2VuKS50b0VxdWFsKE15UGlwZSk7XG4gICAgfSk7XG4gIH0pO1xufVxuIl19
 main(); 
