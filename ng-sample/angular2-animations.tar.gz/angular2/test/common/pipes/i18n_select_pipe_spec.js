'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var common_1 = require('angular2/common');
var pipe_resolver_1 = require('angular2/src/core/linker/pipe_resolver');
function main() {
    testing_internal_1.describe("I18nSelectPipe", function () {
        var pipe;
        var mapping = { 'male': 'Invite him.', 'female': 'Invite her.', 'other': 'Invite them.' };
        testing_internal_1.beforeEach(function () { pipe = new common_1.I18nSelectPipe(); });
        testing_internal_1.it('should be marked as pure', function () { testing_internal_1.expect(new pipe_resolver_1.PipeResolver().resolve(common_1.I18nSelectPipe).pure).toEqual(true); });
        testing_internal_1.describe("transform", function () {
            testing_internal_1.it("should return male text if value is male", function () {
                var val = pipe.transform('male', [mapping]);
                testing_internal_1.expect(val).toEqual('Invite him.');
            });
            testing_internal_1.it("should return female text if value is female", function () {
                var val = pipe.transform('female', [mapping]);
                testing_internal_1.expect(val).toEqual('Invite her.');
            });
            testing_internal_1.it("should return other text if value is anything other than male or female", function () {
                var val = pipe.transform('Anything else', [mapping]);
                testing_internal_1.expect(val).toEqual('Invite them.');
            });
            testing_internal_1.it("should use 'other' if value is undefined", function () {
                var gender;
                var val = pipe.transform(gender, [mapping]);
                testing_internal_1.expect(val).toEqual('Invite them.');
            });
            testing_internal_1.it("should not support bad arguments", function () { testing_internal_1.expect(function () { return pipe.transform('male', ['hey']); }).toThrowError(); });
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaTE4bl9zZWxlY3RfcGlwZV9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb21tb24vcGlwZXMvaTE4bl9zZWxlY3RfcGlwZV9zcGVjLnRzIl0sIm5hbWVzIjpbIm1haW4iXSwibWFwcGluZ3MiOiJBQUFBLGlDQVNPLDJCQUEyQixDQUFDLENBQUE7QUFFbkMsdUJBQTZCLGlCQUFpQixDQUFDLENBQUE7QUFDL0MsOEJBQTJCLHdDQUF3QyxDQUFDLENBQUE7QUFFcEU7SUFDRUEsMkJBQVFBLENBQUNBLGdCQUFnQkEsRUFBRUE7UUFDekJBLElBQUlBLElBQUlBLENBQUNBO1FBQ1RBLElBQUlBLE9BQU9BLEdBQUdBLEVBQUNBLE1BQU1BLEVBQUVBLGFBQWFBLEVBQUVBLFFBQVFBLEVBQUVBLGFBQWFBLEVBQUVBLE9BQU9BLEVBQUVBLGNBQWNBLEVBQUNBLENBQUNBO1FBRXhGQSw2QkFBVUEsQ0FBQ0EsY0FBUUEsSUFBSUEsR0FBR0EsSUFBSUEsdUJBQWNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRW5EQSxxQkFBRUEsQ0FBQ0EsMEJBQTBCQSxFQUMxQkEsY0FBUUEseUJBQU1BLENBQUNBLElBQUlBLDRCQUFZQSxFQUFFQSxDQUFDQSxPQUFPQSxDQUFDQSx1QkFBY0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFckZBLDJCQUFRQSxDQUFDQSxXQUFXQSxFQUFFQTtZQUNwQkEscUJBQUVBLENBQUNBLDBDQUEwQ0EsRUFBRUE7Z0JBQzdDQSxJQUFJQSxHQUFHQSxHQUFHQSxJQUFJQSxDQUFDQSxTQUFTQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDNUNBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtZQUNyQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDhDQUE4Q0EsRUFBRUE7Z0JBQ2pEQSxJQUFJQSxHQUFHQSxHQUFHQSxJQUFJQSxDQUFDQSxTQUFTQSxDQUFDQSxRQUFRQSxFQUFFQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDOUNBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtZQUNyQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLHlFQUF5RUEsRUFBRUE7Z0JBQzVFQSxJQUFJQSxHQUFHQSxHQUFHQSxJQUFJQSxDQUFDQSxTQUFTQSxDQUFDQSxlQUFlQSxFQUFFQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDckRBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQTtZQUN0Q0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDBDQUEwQ0EsRUFBRUE7Z0JBQzdDQSxJQUFJQSxNQUFNQSxDQUFDQTtnQkFDWEEsSUFBSUEsR0FBR0EsR0FBR0EsSUFBSUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzVDQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsY0FBY0EsQ0FBQ0EsQ0FBQ0E7WUFDdENBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxrQ0FBa0NBLEVBQ2xDQSxjQUFRQSx5QkFBTUEsQ0FBQ0EsY0FBTUEsT0FBQUEsSUFBSUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsRUFBL0JBLENBQStCQSxDQUFDQSxDQUFDQSxZQUFZQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUM5RUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFFTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7QUFDTEEsQ0FBQ0E7QUFyQ2UsWUFBSSxPQXFDbkIsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIGRkZXNjcmliZSxcbiAgZGVzY3JpYmUsXG4gIGl0LFxuICBpaXQsXG4gIHhpdCxcbiAgZXhwZWN0LFxuICBiZWZvcmVFYWNoLFxuICBhZnRlckVhY2hcbn0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmltcG9ydCB7STE4blNlbGVjdFBpcGV9IGZyb20gJ2FuZ3VsYXIyL2NvbW1vbic7XG5pbXBvcnQge1BpcGVSZXNvbHZlcn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvbGlua2VyL3BpcGVfcmVzb2x2ZXInO1xuXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpIHtcbiAgZGVzY3JpYmUoXCJJMThuU2VsZWN0UGlwZVwiLCAoKSA9PiB7XG4gICAgdmFyIHBpcGU7XG4gICAgdmFyIG1hcHBpbmcgPSB7J21hbGUnOiAnSW52aXRlIGhpbS4nLCAnZmVtYWxlJzogJ0ludml0ZSBoZXIuJywgJ290aGVyJzogJ0ludml0ZSB0aGVtLid9O1xuXG4gICAgYmVmb3JlRWFjaCgoKSA9PiB7IHBpcGUgPSBuZXcgSTE4blNlbGVjdFBpcGUoKTsgfSk7XG5cbiAgICBpdCgnc2hvdWxkIGJlIG1hcmtlZCBhcyBwdXJlJyxcbiAgICAgICAoKSA9PiB7IGV4cGVjdChuZXcgUGlwZVJlc29sdmVyKCkucmVzb2x2ZShJMThuU2VsZWN0UGlwZSkucHVyZSkudG9FcXVhbCh0cnVlKTsgfSk7XG5cbiAgICBkZXNjcmliZShcInRyYW5zZm9ybVwiLCAoKSA9PiB7XG4gICAgICBpdChcInNob3VsZCByZXR1cm4gbWFsZSB0ZXh0IGlmIHZhbHVlIGlzIG1hbGVcIiwgKCkgPT4ge1xuICAgICAgICB2YXIgdmFsID0gcGlwZS50cmFuc2Zvcm0oJ21hbGUnLCBbbWFwcGluZ10pO1xuICAgICAgICBleHBlY3QodmFsKS50b0VxdWFsKCdJbnZpdGUgaGltLicpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KFwic2hvdWxkIHJldHVybiBmZW1hbGUgdGV4dCBpZiB2YWx1ZSBpcyBmZW1hbGVcIiwgKCkgPT4ge1xuICAgICAgICB2YXIgdmFsID0gcGlwZS50cmFuc2Zvcm0oJ2ZlbWFsZScsIFttYXBwaW5nXSk7XG4gICAgICAgIGV4cGVjdCh2YWwpLnRvRXF1YWwoJ0ludml0ZSBoZXIuJyk7XG4gICAgICB9KTtcblxuICAgICAgaXQoXCJzaG91bGQgcmV0dXJuIG90aGVyIHRleHQgaWYgdmFsdWUgaXMgYW55dGhpbmcgb3RoZXIgdGhhbiBtYWxlIG9yIGZlbWFsZVwiLCAoKSA9PiB7XG4gICAgICAgIHZhciB2YWwgPSBwaXBlLnRyYW5zZm9ybSgnQW55dGhpbmcgZWxzZScsIFttYXBwaW5nXSk7XG4gICAgICAgIGV4cGVjdCh2YWwpLnRvRXF1YWwoJ0ludml0ZSB0aGVtLicpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KFwic2hvdWxkIHVzZSAnb3RoZXInIGlmIHZhbHVlIGlzIHVuZGVmaW5lZFwiLCAoKSA9PiB7XG4gICAgICAgIHZhciBnZW5kZXI7XG4gICAgICAgIHZhciB2YWwgPSBwaXBlLnRyYW5zZm9ybShnZW5kZXIsIFttYXBwaW5nXSk7XG4gICAgICAgIGV4cGVjdCh2YWwpLnRvRXF1YWwoJ0ludml0ZSB0aGVtLicpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KFwic2hvdWxkIG5vdCBzdXBwb3J0IGJhZCBhcmd1bWVudHNcIixcbiAgICAgICAgICgpID0+IHsgZXhwZWN0KCgpID0+IHBpcGUudHJhbnNmb3JtKCdtYWxlJywgWydoZXknXSkpLnRvVGhyb3dFcnJvcigpOyB9KTtcbiAgICB9KTtcblxuICB9KTtcbn1cbiJdfQ==
 main(); 
