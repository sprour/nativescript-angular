'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var testing_internal_1 = require('angular2/testing_internal');
var core_1 = require('angular2/core');
var pipes_1 = require('angular2/src/core/pipes/pipes');
var pipe_provider_1 = require('angular2/src/core/pipes/pipe_provider');
var PipeA = (function () {
    function PipeA() {
    }
    PipeA.prototype.transform = function (a, b) { };
    PipeA.prototype.ngOnDestroy = function () { };
    return PipeA;
})();
var PipeB = (function () {
    function PipeB(dep) {
        this.dep = dep;
    }
    PipeB.prototype.transform = function (a, b) { };
    PipeB.prototype.ngOnDestroy = function () { };
    PipeB = __decorate([
        __param(0, core_1.Inject("dep")), 
        __metadata('design:paramtypes', [Object])
    ], PipeB);
    return PipeB;
})();
function main() {
    testing_internal_1.describe("Pipes", function () {
        var injector;
        testing_internal_1.beforeEach(function () {
            injector = core_1.Injector.resolveAndCreate([core_1.provide('dep', { useValue: 'dependency' })]);
        });
        testing_internal_1.it('should instantiate a pipe', function () {
            var proto = pipes_1.ProtoPipes.fromProviders([pipe_provider_1.PipeProvider.createFromType(PipeA, new core_1.Pipe({ name: 'a' }))]);
            var pipes = new pipes_1.Pipes(proto, injector);
            testing_internal_1.expect(pipes.get("a").pipe).toBeAnInstanceOf(PipeA);
        });
        testing_internal_1.it('should throw when no pipe found', function () {
            var proto = pipes_1.ProtoPipes.fromProviders([]);
            var pipes = new pipes_1.Pipes(proto, injector);
            testing_internal_1.expect(function () { return pipes.get("invalid"); }).toThrowErrorWith("Cannot find pipe 'invalid'");
        });
        testing_internal_1.it('should inject dependencies from the provided injector', function () {
            var proto = pipes_1.ProtoPipes.fromProviders([pipe_provider_1.PipeProvider.createFromType(PipeB, new core_1.Pipe({ name: 'b' }))]);
            var pipes = new pipes_1.Pipes(proto, injector);
            testing_internal_1.expect(pipes.get("b").pipe.dep).toEqual("dependency");
        });
        testing_internal_1.it('should cache pure pipes', function () {
            var proto = pipes_1.ProtoPipes.fromProviders([pipe_provider_1.PipeProvider.createFromType(PipeA, new core_1.Pipe({ name: 'a', pure: true }))]);
            var pipes = new pipes_1.Pipes(proto, injector);
            testing_internal_1.expect(pipes.get("a").pure).toEqual(true);
            testing_internal_1.expect(pipes.get("a")).toBe(pipes.get("a"));
        });
        testing_internal_1.it('should NOT cache impure pipes', function () {
            var proto = pipes_1.ProtoPipes.fromProviders([pipe_provider_1.PipeProvider.createFromType(PipeA, new core_1.Pipe({ name: 'a', pure: false }))]);
            var pipes = new pipes_1.Pipes(proto, injector);
            testing_internal_1.expect(pipes.get("a").pure).toEqual(false);
            testing_internal_1.expect(pipes.get("a")).not.toBe(pipes.get("a"));
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGlwZXNfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29tbW9uL3BpcGVzL3BpcGVzX3NwZWMudHMiXSwibmFtZXMiOlsiUGlwZUEiLCJQaXBlQS5jb25zdHJ1Y3RvciIsIlBpcGVBLnRyYW5zZm9ybSIsIlBpcGVBLm5nT25EZXN0cm95IiwiUGlwZUIiLCJQaXBlQi5jb25zdHJ1Y3RvciIsIlBpcGVCLnRyYW5zZm9ybSIsIlBpcGVCLm5nT25EZXN0cm95IiwibWFpbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEsaUNBVU8sMkJBQTJCLENBQUMsQ0FBQTtBQUVuQyxxQkFBd0UsZUFBZSxDQUFDLENBQUE7QUFDeEYsc0JBQWdDLCtCQUErQixDQUFDLENBQUE7QUFDaEUsOEJBQTJCLHVDQUF1QyxDQUFDLENBQUE7QUFFbkU7SUFBQUE7SUFHQUMsQ0FBQ0E7SUFGQ0QseUJBQVNBLEdBQVRBLFVBQVVBLENBQUNBLEVBQUVBLENBQUNBLElBQUdFLENBQUNBO0lBQ2xCRiwyQkFBV0EsR0FBWEEsY0FBZUcsQ0FBQ0E7SUFDbEJILFlBQUNBO0FBQURBLENBQUNBLEFBSEQsSUFHQztBQUVEO0lBRUVJLGVBQTJCQSxHQUFRQTtRQUFJQyxJQUFJQSxDQUFDQSxHQUFHQSxHQUFHQSxHQUFHQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUN4REQseUJBQVNBLEdBQVRBLFVBQVVBLENBQUNBLEVBQUVBLENBQUNBLElBQUdFLENBQUNBO0lBQ2xCRiwyQkFBV0EsR0FBWEEsY0FBZUcsQ0FBQ0E7SUFKbEJIO1FBRWNBLFdBQUNBLGFBQU1BLENBQUNBLEtBQUtBLENBQUNBLENBQUFBOztjQUczQkE7SUFBREEsWUFBQ0E7QUFBREEsQ0FBQ0EsQUFMRCxJQUtDO0FBRUQ7SUFDRUksMkJBQVFBLENBQUNBLE9BQU9BLEVBQUVBO1FBQ2hCQSxJQUFJQSxRQUFRQSxDQUFDQTtRQUViQSw2QkFBVUEsQ0FBQ0E7WUFDVEEsUUFBUUEsR0FBR0EsZUFBUUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxjQUFPQSxDQUFDQSxLQUFLQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxZQUFZQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNuRkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLDJCQUEyQkEsRUFBRUE7WUFDOUJBLElBQUlBLEtBQUtBLEdBQ0xBLGtCQUFVQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSw0QkFBWUEsQ0FBQ0EsY0FBY0EsQ0FBQ0EsS0FBS0EsRUFBRUEsSUFBSUEsV0FBSUEsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsR0FBR0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDMUZBLElBQUlBLEtBQUtBLEdBQUdBLElBQUlBLGFBQUtBLENBQUNBLEtBQUtBLEVBQUVBLFFBQVFBLENBQUNBLENBQUNBO1lBRXZDQSx5QkFBTUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQTtRQUN0REEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLGlDQUFpQ0EsRUFBRUE7WUFDcENBLElBQUlBLEtBQUtBLEdBQUdBLGtCQUFVQSxDQUFDQSxhQUFhQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtZQUN6Q0EsSUFBSUEsS0FBS0EsR0FBR0EsSUFBSUEsYUFBS0EsQ0FBQ0EsS0FBS0EsRUFBRUEsUUFBUUEsQ0FBQ0EsQ0FBQ0E7WUFDdkNBLHlCQUFNQSxDQUFDQSxjQUFNQSxPQUFBQSxLQUFLQSxDQUFDQSxHQUFHQSxDQUFDQSxTQUFTQSxDQUFDQSxFQUFwQkEsQ0FBb0JBLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsNEJBQTRCQSxDQUFDQSxDQUFDQTtRQUNwRkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLHVEQUF1REEsRUFBRUE7WUFDMURBLElBQUlBLEtBQUtBLEdBQ0xBLGtCQUFVQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSw0QkFBWUEsQ0FBQ0EsY0FBY0EsQ0FBQ0EsS0FBS0EsRUFBRUEsSUFBSUEsV0FBSUEsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsR0FBR0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDMUZBLElBQUlBLEtBQUtBLEdBQUdBLElBQUlBLGFBQUtBLENBQUNBLEtBQUtBLEVBQUVBLFFBQVFBLENBQUNBLENBQUNBO1lBQ3ZDQSx5QkFBTUEsQ0FBT0EsS0FBS0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsSUFBS0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0E7UUFDL0RBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLHFCQUFFQSxDQUFDQSx5QkFBeUJBLEVBQUVBO1lBQzVCQSxJQUFJQSxLQUFLQSxHQUFHQSxrQkFBVUEsQ0FBQ0EsYUFBYUEsQ0FDaENBLENBQUNBLDRCQUFZQSxDQUFDQSxjQUFjQSxDQUFDQSxLQUFLQSxFQUFFQSxJQUFJQSxXQUFJQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxHQUFHQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUM3RUEsSUFBSUEsS0FBS0EsR0FBR0EsSUFBSUEsYUFBS0EsQ0FBQ0EsS0FBS0EsRUFBRUEsUUFBUUEsQ0FBQ0EsQ0FBQ0E7WUFFdkNBLHlCQUFNQSxDQUFDQSxLQUFLQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtZQUMxQ0EseUJBQU1BLENBQUNBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBO1FBQzlDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSxxQkFBRUEsQ0FBQ0EsK0JBQStCQSxFQUFFQTtZQUNsQ0EsSUFBSUEsS0FBS0EsR0FBR0Esa0JBQVVBLENBQUNBLGFBQWFBLENBQ2hDQSxDQUFDQSw0QkFBWUEsQ0FBQ0EsY0FBY0EsQ0FBQ0EsS0FBS0EsRUFBRUEsSUFBSUEsV0FBSUEsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsR0FBR0EsRUFBRUEsSUFBSUEsRUFBRUEsS0FBS0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDOUVBLElBQUlBLEtBQUtBLEdBQUdBLElBQUlBLGFBQUtBLENBQUNBLEtBQUtBLEVBQUVBLFFBQVFBLENBQUNBLENBQUNBO1lBRXZDQSx5QkFBTUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0E7WUFDM0NBLHlCQUFNQSxDQUFDQSxLQUFLQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNsREEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7QUFDTEEsQ0FBQ0E7QUEvQ2UsWUFBSSxPQStDbkIsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIGRkZXNjcmliZSxcbiAgeGRlc2NyaWJlLFxuICBkZXNjcmliZSxcbiAgaXQsXG4gIGlpdCxcbiAgeGl0LFxuICBleHBlY3QsXG4gIGJlZm9yZUVhY2gsXG4gIGFmdGVyRWFjaFxufSBmcm9tICdhbmd1bGFyMi90ZXN0aW5nX2ludGVybmFsJztcblxuaW1wb3J0IHtJbmplY3RvciwgSW5qZWN0LCBwcm92aWRlLCBQaXBlLCBQaXBlVHJhbnNmb3JtLCBPbkRlc3Ryb3l9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuaW1wb3J0IHtQcm90b1BpcGVzLCBQaXBlc30gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvcGlwZXMvcGlwZXMnO1xuaW1wb3J0IHtQaXBlUHJvdmlkZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL3BpcGVzL3BpcGVfcHJvdmlkZXInO1xuXG5jbGFzcyBQaXBlQSBpbXBsZW1lbnRzIFBpcGVUcmFuc2Zvcm0sIE9uRGVzdHJveSB7XG4gIHRyYW5zZm9ybShhLCBiKSB7fVxuICBuZ09uRGVzdHJveSgpIHt9XG59XG5cbmNsYXNzIFBpcGVCIGltcGxlbWVudHMgUGlwZVRyYW5zZm9ybSwgT25EZXN0cm95IHtcbiAgZGVwO1xuICBjb25zdHJ1Y3RvcihASW5qZWN0KFwiZGVwXCIpIGRlcDogYW55KSB7IHRoaXMuZGVwID0gZGVwOyB9XG4gIHRyYW5zZm9ybShhLCBiKSB7fVxuICBuZ09uRGVzdHJveSgpIHt9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZShcIlBpcGVzXCIsICgpID0+IHtcbiAgICB2YXIgaW5qZWN0b3I7XG5cbiAgICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICAgIGluamVjdG9yID0gSW5qZWN0b3IucmVzb2x2ZUFuZENyZWF0ZShbcHJvdmlkZSgnZGVwJywge3VzZVZhbHVlOiAnZGVwZW5kZW5jeSd9KV0pO1xuICAgIH0pO1xuXG4gICAgaXQoJ3Nob3VsZCBpbnN0YW50aWF0ZSBhIHBpcGUnLCAoKSA9PiB7XG4gICAgICB2YXIgcHJvdG8gPVxuICAgICAgICAgIFByb3RvUGlwZXMuZnJvbVByb3ZpZGVycyhbUGlwZVByb3ZpZGVyLmNyZWF0ZUZyb21UeXBlKFBpcGVBLCBuZXcgUGlwZSh7bmFtZTogJ2EnfSkpXSk7XG4gICAgICB2YXIgcGlwZXMgPSBuZXcgUGlwZXMocHJvdG8sIGluamVjdG9yKTtcblxuICAgICAgZXhwZWN0KHBpcGVzLmdldChcImFcIikucGlwZSkudG9CZUFuSW5zdGFuY2VPZihQaXBlQSk7XG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIHRocm93IHdoZW4gbm8gcGlwZSBmb3VuZCcsICgpID0+IHtcbiAgICAgIHZhciBwcm90byA9IFByb3RvUGlwZXMuZnJvbVByb3ZpZGVycyhbXSk7XG4gICAgICB2YXIgcGlwZXMgPSBuZXcgUGlwZXMocHJvdG8sIGluamVjdG9yKTtcbiAgICAgIGV4cGVjdCgoKSA9PiBwaXBlcy5nZXQoXCJpbnZhbGlkXCIpKS50b1Rocm93RXJyb3JXaXRoKFwiQ2Fubm90IGZpbmQgcGlwZSAnaW52YWxpZCdcIik7XG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIGluamVjdCBkZXBlbmRlbmNpZXMgZnJvbSB0aGUgcHJvdmlkZWQgaW5qZWN0b3InLCAoKSA9PiB7XG4gICAgICB2YXIgcHJvdG8gPVxuICAgICAgICAgIFByb3RvUGlwZXMuZnJvbVByb3ZpZGVycyhbUGlwZVByb3ZpZGVyLmNyZWF0ZUZyb21UeXBlKFBpcGVCLCBuZXcgUGlwZSh7bmFtZTogJ2InfSkpXSk7XG4gICAgICB2YXIgcGlwZXMgPSBuZXcgUGlwZXMocHJvdG8sIGluamVjdG9yKTtcbiAgICAgIGV4cGVjdCgoPGFueT5waXBlcy5nZXQoXCJiXCIpLnBpcGUpLmRlcCkudG9FcXVhbChcImRlcGVuZGVuY3lcIik7XG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIGNhY2hlIHB1cmUgcGlwZXMnLCAoKSA9PiB7XG4gICAgICB2YXIgcHJvdG8gPSBQcm90b1BpcGVzLmZyb21Qcm92aWRlcnMoXG4gICAgICAgICAgW1BpcGVQcm92aWRlci5jcmVhdGVGcm9tVHlwZShQaXBlQSwgbmV3IFBpcGUoe25hbWU6ICdhJywgcHVyZTogdHJ1ZX0pKV0pO1xuICAgICAgdmFyIHBpcGVzID0gbmV3IFBpcGVzKHByb3RvLCBpbmplY3Rvcik7XG5cbiAgICAgIGV4cGVjdChwaXBlcy5nZXQoXCJhXCIpLnB1cmUpLnRvRXF1YWwodHJ1ZSk7XG4gICAgICBleHBlY3QocGlwZXMuZ2V0KFwiYVwiKSkudG9CZShwaXBlcy5nZXQoXCJhXCIpKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgTk9UIGNhY2hlIGltcHVyZSBwaXBlcycsICgpID0+IHtcbiAgICAgIHZhciBwcm90byA9IFByb3RvUGlwZXMuZnJvbVByb3ZpZGVycyhcbiAgICAgICAgICBbUGlwZVByb3ZpZGVyLmNyZWF0ZUZyb21UeXBlKFBpcGVBLCBuZXcgUGlwZSh7bmFtZTogJ2EnLCBwdXJlOiBmYWxzZX0pKV0pO1xuICAgICAgdmFyIHBpcGVzID0gbmV3IFBpcGVzKHByb3RvLCBpbmplY3Rvcik7XG5cbiAgICAgIGV4cGVjdChwaXBlcy5nZXQoXCJhXCIpLnB1cmUpLnRvRXF1YWwoZmFsc2UpO1xuICAgICAgZXhwZWN0KHBpcGVzLmdldChcImFcIikpLm5vdC50b0JlKHBpcGVzLmdldChcImFcIikpO1xuICAgIH0pO1xuICB9KTtcbn1cbiJdfQ==
 main(); 
