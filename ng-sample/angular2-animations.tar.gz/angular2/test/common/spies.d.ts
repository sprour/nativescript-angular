import { SpyObject } from 'angular2/testing_internal';
export declare class SpyChangeDetectorRef extends SpyObject {
    constructor();
}
export declare class SpyNgControl extends SpyObject {
}
export declare class SpyValueAccessor extends SpyObject {
}
