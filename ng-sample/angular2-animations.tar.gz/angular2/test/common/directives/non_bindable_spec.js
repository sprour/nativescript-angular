'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var dom_adapter_1 = require('angular2/src/platform/dom/dom_adapter');
var core_1 = require('angular2/core');
var element_ref_1 = require('angular2/src/core/linker/element_ref');
function main() {
    testing_internal_1.describe('non-bindable', function () {
        testing_internal_1.it('should not interpolate children', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            var template = '<div>{{text}}<span ngNonBindable>{{text}}</span></div>';
            tcb.overrideTemplate(TestComponent, template)
                .createAsync(TestComponent)
                .then(function (fixture) {
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('foo{{text}}');
                async.done();
            });
        }));
        testing_internal_1.it('should ignore directives on child nodes', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            var template = '<div ngNonBindable><span id=child test-dec>{{text}}</span></div>';
            tcb.overrideTemplate(TestComponent, template)
                .createAsync(TestComponent)
                .then(function (fixture) {
                fixture.detectChanges();
                // We must use DOM.querySelector instead of fixture.query here
                // since the elements inside are not compiled.
                var span = dom_adapter_1.DOM.querySelector(fixture.debugElement.nativeElement, '#child');
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(span, 'compiled')).toBeFalsy();
                async.done();
            });
        }));
        testing_internal_1.it('should trigger directives on the same node', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            var template = '<div><span id=child ngNonBindable test-dec>{{text}}</span></div>';
            tcb.overrideTemplate(TestComponent, template)
                .createAsync(TestComponent)
                .then(function (fixture) {
                fixture.detectChanges();
                var span = dom_adapter_1.DOM.querySelector(fixture.debugElement.nativeElement, '#child');
                testing_internal_1.expect(dom_adapter_1.DOM.hasClass(span, 'compiled')).toBeTruthy();
                async.done();
            });
        }));
    });
}
exports.main = main;
var TestDirective = (function () {
    function TestDirective(el) {
        dom_adapter_1.DOM.addClass(el.nativeElement, 'compiled');
    }
    TestDirective = __decorate([
        core_1.Directive({ selector: '[test-dec]' }), 
        __metadata('design:paramtypes', [element_ref_1.ElementRef])
    ], TestDirective);
    return TestDirective;
})();
var TestComponent = (function () {
    function TestComponent() {
        this.text = 'foo';
    }
    TestComponent = __decorate([
        core_1.Component({ selector: 'test-cmp', directives: [TestDirective], template: '' }), 
        __metadata('design:paramtypes', [])
    ], TestComponent);
    return TestComponent;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibm9uX2JpbmRhYmxlX3NwZWMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L2NvbW1vbi9kaXJlY3RpdmVzL25vbl9iaW5kYWJsZV9zcGVjLnRzIl0sIm5hbWVzIjpbIm1haW4iLCJUZXN0RGlyZWN0aXZlIiwiVGVzdERpcmVjdGl2ZS5jb25zdHJ1Y3RvciIsIlRlc3RDb21wb25lbnQiLCJUZXN0Q29tcG9uZW50LmNvbnN0cnVjdG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxpQ0FZTywyQkFBMkIsQ0FBQyxDQUFBO0FBQ25DLDRCQUFrQix1Q0FBdUMsQ0FBQyxDQUFBO0FBQzFELHFCQUFtQyxlQUFlLENBQUMsQ0FBQTtBQUNuRCw0QkFBeUIsc0NBQXNDLENBQUMsQ0FBQTtBQUVoRTtJQUNFQSwyQkFBUUEsQ0FBQ0EsY0FBY0EsRUFBRUE7UUFDdkJBLHFCQUFFQSxDQUFDQSxpQ0FBaUNBLEVBQ2pDQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtZQUNsRkEsSUFBSUEsUUFBUUEsR0FBR0Esd0RBQXdEQSxDQUFDQTtZQUN4RUEsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxhQUFhQSxFQUFFQSxRQUFRQSxDQUFDQTtpQkFDeENBLFdBQVdBLENBQUNBLGFBQWFBLENBQUNBO2lCQUMxQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsT0FBT0E7Z0JBQ1pBLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO2dCQUN4QkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBO2dCQUNyRUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7WUFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFUEEscUJBQUVBLENBQUNBLHlDQUF5Q0EsRUFDekNBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO1lBQ2xGQSxJQUFJQSxRQUFRQSxHQUFHQSxrRUFBa0VBLENBQUNBO1lBQ2xGQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLGFBQWFBLEVBQUVBLFFBQVFBLENBQUNBO2lCQUN4Q0EsV0FBV0EsQ0FBQ0EsYUFBYUEsQ0FBQ0E7aUJBQzFCQSxJQUFJQSxDQUFDQSxVQUFDQSxPQUFPQTtnQkFDWkEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7Z0JBRXhCQSw4REFBOERBO2dCQUM5REEsOENBQThDQTtnQkFDOUNBLElBQUlBLElBQUlBLEdBQUdBLGlCQUFHQSxDQUFDQSxhQUFhQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxFQUFFQSxRQUFRQSxDQUFDQSxDQUFDQTtnQkFDM0VBLHlCQUFNQSxDQUFDQSxpQkFBR0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsSUFBSUEsRUFBRUEsVUFBVUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsU0FBU0EsRUFBRUEsQ0FBQ0E7Z0JBQ25EQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtZQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVQQSxxQkFBRUEsQ0FBQ0EsNENBQTRDQSxFQUM1Q0EseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7WUFDbEZBLElBQUlBLFFBQVFBLEdBQUdBLGtFQUFrRUEsQ0FBQ0E7WUFDbEZBLEdBQUdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsYUFBYUEsRUFBRUEsUUFBUUEsQ0FBQ0E7aUJBQ3hDQSxXQUFXQSxDQUFDQSxhQUFhQSxDQUFDQTtpQkFDMUJBLElBQUlBLENBQUNBLFVBQUNBLE9BQU9BO2dCQUNaQSxPQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtnQkFDeEJBLElBQUlBLElBQUlBLEdBQUdBLGlCQUFHQSxDQUFDQSxhQUFhQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxFQUFFQSxRQUFRQSxDQUFDQSxDQUFDQTtnQkFDM0VBLHlCQUFNQSxDQUFDQSxpQkFBR0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsSUFBSUEsRUFBRUEsVUFBVUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsVUFBVUEsRUFBRUEsQ0FBQ0E7Z0JBQ3BEQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtZQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUNUQSxDQUFDQSxDQUFDQSxDQUFBQTtBQUNKQSxDQUFDQTtBQTNDZSxZQUFJLE9BMkNuQixDQUFBO0FBRUQ7SUFFRUMsdUJBQVlBLEVBQWNBO1FBQUlDLGlCQUFHQSxDQUFDQSxRQUFRQSxDQUFDQSxFQUFFQSxDQUFDQSxhQUFhQSxFQUFFQSxVQUFVQSxDQUFDQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUY3RUQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLFlBQVlBLEVBQUNBLENBQUNBOztzQkFHbkNBO0lBQURBLG9CQUFDQTtBQUFEQSxDQUFDQSxBQUhELElBR0M7QUFFRDtJQUdFRTtRQUFnQkMsSUFBSUEsQ0FBQ0EsSUFBSUEsR0FBR0EsS0FBS0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFIdENEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxVQUFVQSxFQUFFQSxVQUFVQSxFQUFFQSxDQUFDQSxhQUFhQSxDQUFDQSxFQUFFQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7c0JBSTVFQTtJQUFEQSxvQkFBQ0E7QUFBREEsQ0FBQ0EsQUFKRCxJQUlDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXN5bmNUZXN0Q29tcGxldGVyLFxuICBUZXN0Q29tcG9uZW50QnVpbGRlcixcbiAgYmVmb3JlRWFjaCxcbiAgZGRlc2NyaWJlLFxuICBkZXNjcmliZSxcbiAgZWwsXG4gIGV4cGVjdCxcbiAgaWl0LFxuICBpbmplY3QsXG4gIGl0LFxuICB4aXQsXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuaW1wb3J0IHtET019IGZyb20gJ2FuZ3VsYXIyL3NyYy9wbGF0Zm9ybS9kb20vZG9tX2FkYXB0ZXInO1xuaW1wb3J0IHtDb21wb25lbnQsIERpcmVjdGl2ZX0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5pbXBvcnQge0VsZW1lbnRSZWZ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci9lbGVtZW50X3JlZic7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgnbm9uLWJpbmRhYmxlJywgKCkgPT4ge1xuICAgIGl0KCdzaG91bGQgbm90IGludGVycG9sYXRlIGNoaWxkcmVuJyxcbiAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgIHZhciB0ZW1wbGF0ZSA9ICc8ZGl2Pnt7dGV4dH19PHNwYW4gbmdOb25CaW5kYWJsZT57e3RleHR9fTwvc3Bhbj48L2Rpdj4nO1xuICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoVGVzdENvbXBvbmVudCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKFRlc3RDb21wb25lbnQpXG4gICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ2Zvb3t7dGV4dH19Jyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBpZ25vcmUgZGlyZWN0aXZlcyBvbiBjaGlsZCBub2RlcycsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPGRpdiBuZ05vbkJpbmRhYmxlPjxzcGFuIGlkPWNoaWxkIHRlc3QtZGVjPnt7dGV4dH19PC9zcGFuPjwvZGl2Pic7XG4gICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShUZXN0Q29tcG9uZW50LCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoVGVzdENvbXBvbmVudClcbiAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgIC8vIFdlIG11c3QgdXNlIERPTS5xdWVyeVNlbGVjdG9yIGluc3RlYWQgb2YgZml4dHVyZS5xdWVyeSBoZXJlXG4gICAgICAgICAgICAgICAvLyBzaW5jZSB0aGUgZWxlbWVudHMgaW5zaWRlIGFyZSBub3QgY29tcGlsZWQuXG4gICAgICAgICAgICAgICB2YXIgc3BhbiA9IERPTS5xdWVyeVNlbGVjdG9yKGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQsICcjY2hpbGQnKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChET00uaGFzQ2xhc3Moc3BhbiwgJ2NvbXBpbGVkJykpLnRvQmVGYWxzeSgpO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgdHJpZ2dlciBkaXJlY3RpdmVzIG9uIHRoZSBzYW1lIG5vZGUnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgdmFyIHRlbXBsYXRlID0gJzxkaXY+PHNwYW4gaWQ9Y2hpbGQgbmdOb25CaW5kYWJsZSB0ZXN0LWRlYz57e3RleHR9fTwvc3Bhbj48L2Rpdj4nO1xuICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoVGVzdENvbXBvbmVudCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKFRlc3RDb21wb25lbnQpXG4gICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgdmFyIHNwYW4gPSBET00ucXVlcnlTZWxlY3RvcihmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50LCAnI2NoaWxkJyk7XG4gICAgICAgICAgICAgICBleHBlY3QoRE9NLmhhc0NsYXNzKHNwYW4sICdjb21waWxlZCcpKS50b0JlVHJ1dGh5KCk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuICB9KVxufVxuXG5ARGlyZWN0aXZlKHtzZWxlY3RvcjogJ1t0ZXN0LWRlY10nfSlcbmNsYXNzIFRlc3REaXJlY3RpdmUge1xuICBjb25zdHJ1Y3RvcihlbDogRWxlbWVudFJlZikgeyBET00uYWRkQ2xhc3MoZWwubmF0aXZlRWxlbWVudCwgJ2NvbXBpbGVkJyk7IH1cbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICd0ZXN0LWNtcCcsIGRpcmVjdGl2ZXM6IFtUZXN0RGlyZWN0aXZlXSwgdGVtcGxhdGU6ICcnfSlcbmNsYXNzIFRlc3RDb21wb25lbnQge1xuICB0ZXh0OiBzdHJpbmc7XG4gIGNvbnN0cnVjdG9yKCkgeyB0aGlzLnRleHQgPSAnZm9vJzsgfVxufVxuIl19
 main(); 
