'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var core_1 = require('angular2/core');
var common_1 = require('angular2/common');
function main() {
    testing_internal_1.describe('switch', function () {
        testing_internal_1.beforeEachProviders(function () { return [core_1.provide(common_1.NgLocalization, { useClass: TestLocalizationMap })]; });
        testing_internal_1.it('should display the template according to the exact value', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            var template = '<div>' +
                '<ul [ngPlural]="switchValue">' +
                '<template ngPluralCase="=0"><li>you have no messages.</li></template>' +
                '<template ngPluralCase="=1"><li>you have one message.</li></template>' +
                '</ul></div>';
            tcb.overrideTemplate(TestComponent, template)
                .createAsync(TestComponent)
                .then(function (fixture) {
                fixture.debugElement.componentInstance.switchValue = 0;
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('you have no messages.');
                fixture.debugElement.componentInstance.switchValue = 1;
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('you have one message.');
                async.done();
            });
        }));
        testing_internal_1.it('should display the template according to the category', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            var template = '<div>' +
                '<ul [ngPlural]="switchValue">' +
                '<template ngPluralCase="few"><li>you have a few messages.</li></template>' +
                '<template ngPluralCase="many"><li>you have many messages.</li></template>' +
                '</ul></div>';
            tcb.overrideTemplate(TestComponent, template)
                .createAsync(TestComponent)
                .then(function (fixture) {
                fixture.debugElement.componentInstance.switchValue = 2;
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('you have a few messages.');
                fixture.debugElement.componentInstance.switchValue = 8;
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('you have many messages.');
                async.done();
            });
        }));
        testing_internal_1.it('should default to other when no matches are found', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            var template = '<div>' +
                '<ul [ngPlural]="switchValue">' +
                '<template ngPluralCase="few"><li>you have a few messages.</li></template>' +
                '<template ngPluralCase="other"><li>default message.</li></template>' +
                '</ul></div>';
            tcb.overrideTemplate(TestComponent, template)
                .createAsync(TestComponent)
                .then(function (fixture) {
                fixture.debugElement.componentInstance.switchValue = 100;
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('default message.');
                async.done();
            });
        }));
        testing_internal_1.it('should prioritize value matches over category matches', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
            var template = '<div>' +
                '<ul [ngPlural]="switchValue">' +
                '<template ngPluralCase="few"><li>you have a few messages.</li></template>' +
                '<template ngPluralCase="=2">you have two messages.</template>' +
                '</ul></div>';
            tcb.overrideTemplate(TestComponent, template)
                .createAsync(TestComponent)
                .then(function (fixture) {
                fixture.debugElement.componentInstance.switchValue = 2;
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('you have two messages.');
                fixture.debugElement.componentInstance.switchValue = 3;
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('you have a few messages.');
                async.done();
            });
        }));
    });
}
exports.main = main;
var TestLocalizationMap = (function (_super) {
    __extends(TestLocalizationMap, _super);
    function TestLocalizationMap() {
        _super.apply(this, arguments);
    }
    TestLocalizationMap.prototype.getPluralCategory = function (value) {
        if (value > 1 && value < 4) {
            return 'few';
        }
        else if (value >= 4 && value < 10) {
            return 'many';
        }
        else {
            return 'other';
        }
    };
    TestLocalizationMap = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], TestLocalizationMap);
    return TestLocalizationMap;
})(common_1.NgLocalization);
exports.TestLocalizationMap = TestLocalizationMap;
var TestComponent = (function () {
    function TestComponent() {
        this.switchValue = null;
    }
    TestComponent = __decorate([
        core_1.Component({ selector: 'test-cmp', directives: [common_1.NgPlural, common_1.NgPluralCase], template: '' }), 
        __metadata('design:paramtypes', [])
    ], TestComponent);
    return TestComponent;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmdfcGx1cmFsX3NwZWMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L2NvbW1vbi9kaXJlY3RpdmVzL25nX3BsdXJhbF9zcGVjLnRzIl0sIm5hbWVzIjpbIm1haW4iLCJUZXN0TG9jYWxpemF0aW9uTWFwIiwiVGVzdExvY2FsaXphdGlvbk1hcC5jb25zdHJ1Y3RvciIsIlRlc3RMb2NhbGl6YXRpb25NYXAuZ2V0UGx1cmFsQ2F0ZWdvcnkiLCJUZXN0Q29tcG9uZW50IiwiVGVzdENvbXBvbmVudC5jb25zdHJ1Y3RvciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBQSxpQ0FhTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLHFCQUE2QyxlQUFlLENBQUMsQ0FBQTtBQUM3RCx1QkFBcUQsaUJBQWlCLENBQUMsQ0FBQTtBQUV2RTtJQUNFQSwyQkFBUUEsQ0FBQ0EsUUFBUUEsRUFBRUE7UUFDakJBLHNDQUFtQkEsQ0FBQ0EsY0FBTUEsT0FBQUEsQ0FBQ0EsY0FBT0EsQ0FBQ0EsdUJBQWNBLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLG1CQUFtQkEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBMURBLENBQTBEQSxDQUFDQSxDQUFDQTtRQUV0RkEscUJBQUVBLENBQUNBLDBEQUEwREEsRUFDMURBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO1lBQ2xGQSxJQUFJQSxRQUFRQSxHQUFHQSxPQUFPQTtnQkFDUEEsK0JBQStCQTtnQkFDL0JBLHVFQUF1RUE7Z0JBQ3ZFQSx1RUFBdUVBO2dCQUN2RUEsYUFBYUEsQ0FBQ0E7WUFFN0JBLEdBQUdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsYUFBYUEsRUFBRUEsUUFBUUEsQ0FBQ0E7aUJBQ3hDQSxXQUFXQSxDQUFDQSxhQUFhQSxDQUFDQTtpQkFDMUJBLElBQUlBLENBQUNBLFVBQUNBLE9BQU9BO2dCQUNaQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLFdBQVdBLEdBQUdBLENBQUNBLENBQUNBO2dCQUN2REEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7Z0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsdUJBQXVCQSxDQUFDQSxDQUFDQTtnQkFFL0VBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsV0FBV0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3ZEQSxPQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtnQkFDeEJBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBO2dCQUUvRUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7WUFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFUEEscUJBQUVBLENBQUNBLHVEQUF1REEsRUFDdkRBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO1lBQ2xGQSxJQUFJQSxRQUFRQSxHQUNSQSxPQUFPQTtnQkFDUEEsK0JBQStCQTtnQkFDL0JBLDJFQUEyRUE7Z0JBQzNFQSwyRUFBMkVBO2dCQUMzRUEsYUFBYUEsQ0FBQ0E7WUFFbEJBLEdBQUdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsYUFBYUEsRUFBRUEsUUFBUUEsQ0FBQ0E7aUJBQ3hDQSxXQUFXQSxDQUFDQSxhQUFhQSxDQUFDQTtpQkFDMUJBLElBQUlBLENBQUNBLFVBQUNBLE9BQU9BO2dCQUNaQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLFdBQVdBLEdBQUdBLENBQUNBLENBQUNBO2dCQUN2REEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7Z0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsMEJBQTBCQSxDQUFDQSxDQUFDQTtnQkFFbEZBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsV0FBV0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3ZEQSxPQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtnQkFDeEJBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSx5QkFBeUJBLENBQUNBLENBQUNBO2dCQUVqRkEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7WUFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFUEEscUJBQUVBLENBQUNBLG1EQUFtREEsRUFDbkRBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO1lBQ2xGQSxJQUFJQSxRQUFRQSxHQUNSQSxPQUFPQTtnQkFDUEEsK0JBQStCQTtnQkFDL0JBLDJFQUEyRUE7Z0JBQzNFQSxxRUFBcUVBO2dCQUNyRUEsYUFBYUEsQ0FBQ0E7WUFFbEJBLEdBQUdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsYUFBYUEsRUFBRUEsUUFBUUEsQ0FBQ0E7aUJBQ3hDQSxXQUFXQSxDQUFDQSxhQUFhQSxDQUFDQTtpQkFDMUJBLElBQUlBLENBQUNBLFVBQUNBLE9BQU9BO2dCQUNaQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLFdBQVdBLEdBQUdBLEdBQUdBLENBQUNBO2dCQUN6REEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7Z0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxDQUFDQTtnQkFFMUVBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLHFCQUFFQSxDQUFDQSx1REFBdURBLEVBQ3ZEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtZQUNsRkEsSUFBSUEsUUFBUUEsR0FDUkEsT0FBT0E7Z0JBQ1BBLCtCQUErQkE7Z0JBQy9CQSwyRUFBMkVBO2dCQUMzRUEsK0RBQStEQTtnQkFDL0RBLGFBQWFBLENBQUNBO1lBRWxCQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLGFBQWFBLEVBQUVBLFFBQVFBLENBQUNBO2lCQUN4Q0EsV0FBV0EsQ0FBQ0EsYUFBYUEsQ0FBQ0E7aUJBQzFCQSxJQUFJQSxDQUFDQSxVQUFDQSxPQUFPQTtnQkFDWkEsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxXQUFXQSxHQUFHQSxDQUFDQSxDQUFDQTtnQkFDdkRBLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO2dCQUN4QkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLHdCQUF3QkEsQ0FBQ0EsQ0FBQ0E7Z0JBRWhGQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLFdBQVdBLEdBQUdBLENBQUNBLENBQUNBO2dCQUN2REEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7Z0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsMEJBQTBCQSxDQUFDQSxDQUFDQTtnQkFFbEZBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO0lBQ1RBLENBQUNBLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBL0ZlLFlBQUksT0ErRm5CLENBQUE7QUFHRDtJQUN5Q0MsdUNBQWNBO0lBRHZEQTtRQUN5Q0MsOEJBQWNBO0lBVXZEQSxDQUFDQTtJQVRDRCwrQ0FBaUJBLEdBQWpCQSxVQUFrQkEsS0FBYUE7UUFDN0JFLEVBQUVBLENBQUNBLENBQUNBLEtBQUtBLEdBQUdBLENBQUNBLElBQUlBLEtBQUtBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQzNCQSxNQUFNQSxDQUFDQSxLQUFLQSxDQUFDQTtRQUNmQSxDQUFDQTtRQUFDQSxJQUFJQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxLQUFLQSxJQUFJQSxDQUFDQSxJQUFJQSxLQUFLQSxHQUFHQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNwQ0EsTUFBTUEsQ0FBQ0EsTUFBTUEsQ0FBQ0E7UUFDaEJBLENBQUNBO1FBQUNBLElBQUlBLENBQUNBLENBQUNBO1lBQ05BLE1BQU1BLENBQUNBLE9BQU9BLENBQUNBO1FBQ2pCQSxDQUFDQTtJQUNIQSxDQUFDQTtJQVZIRjtRQUFDQSxpQkFBVUEsRUFBRUE7OzRCQVdaQTtJQUFEQSwwQkFBQ0E7QUFBREEsQ0FBQ0EsQUFYRCxFQUN5Qyx1QkFBYyxFQVV0RDtBQVZZLDJCQUFtQixzQkFVL0IsQ0FBQTtBQUdEO0lBSUVHO1FBQWdCQyxJQUFJQSxDQUFDQSxXQUFXQSxHQUFHQSxJQUFJQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUo1Q0Q7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLFVBQVVBLEVBQUVBLFVBQVVBLEVBQUVBLENBQUNBLGlCQUFRQSxFQUFFQSxxQkFBWUEsQ0FBQ0EsRUFBRUEsUUFBUUEsRUFBRUEsRUFBRUEsRUFBQ0EsQ0FBQ0E7O3NCQUtyRkE7SUFBREEsb0JBQUNBO0FBQURBLENBQUNBLEFBTEQsSUFLQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFzeW5jVGVzdENvbXBsZXRlcixcbiAgVGVzdENvbXBvbmVudEJ1aWxkZXIsXG4gIGJlZm9yZUVhY2hQcm92aWRlcnMsXG4gIGJlZm9yZUVhY2gsXG4gIGRkZXNjcmliZSxcbiAgZGVzY3JpYmUsXG4gIGVsLFxuICBleHBlY3QsXG4gIGlpdCxcbiAgaW5qZWN0LFxuICBpdCxcbiAgeGl0LFxufSBmcm9tICdhbmd1bGFyMi90ZXN0aW5nX2ludGVybmFsJztcblxuaW1wb3J0IHtDb21wb25lbnQsIEluamVjdGFibGUsIHByb3ZpZGV9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuaW1wb3J0IHtOZ1BsdXJhbCwgTmdQbHVyYWxDYXNlLCBOZ0xvY2FsaXphdGlvbn0gZnJvbSAnYW5ndWxhcjIvY29tbW9uJztcblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGRlc2NyaWJlKCdzd2l0Y2gnLCAoKSA9PiB7XG4gICAgYmVmb3JlRWFjaFByb3ZpZGVycygoKSA9PiBbcHJvdmlkZShOZ0xvY2FsaXphdGlvbiwge3VzZUNsYXNzOiBUZXN0TG9jYWxpemF0aW9uTWFwfSldKTtcblxuICAgIGl0KCdzaG91bGQgZGlzcGxheSB0aGUgdGVtcGxhdGUgYWNjb3JkaW5nIHRvIHRoZSBleGFjdCB2YWx1ZScsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPGRpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICc8dWwgW25nUGx1cmFsXT1cInN3aXRjaFZhbHVlXCI+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAnPHRlbXBsYXRlIG5nUGx1cmFsQ2FzZT1cIj0wXCI+PGxpPnlvdSBoYXZlIG5vIG1lc3NhZ2VzLjwvbGk+PC90ZW1wbGF0ZT4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICc8dGVtcGxhdGUgbmdQbHVyYWxDYXNlPVwiPTFcIj48bGk+eW91IGhhdmUgb25lIG1lc3NhZ2UuPC9saT48L3RlbXBsYXRlPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgJzwvdWw+PC9kaXY+JztcblxuICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoVGVzdENvbXBvbmVudCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKFRlc3RDb21wb25lbnQpXG4gICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLnN3aXRjaFZhbHVlID0gMDtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ3lvdSBoYXZlIG5vIG1lc3NhZ2VzLicpO1xuXG4gICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5zd2l0Y2hWYWx1ZSA9IDE7XG4gICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCd5b3UgaGF2ZSBvbmUgbWVzc2FnZS4nKTtcblxuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgZGlzcGxheSB0aGUgdGVtcGxhdGUgYWNjb3JkaW5nIHRvIHRoZSBjYXRlZ29yeScsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB2YXIgdGVtcGxhdGUgPVxuICAgICAgICAgICAgICc8ZGl2PicgK1xuICAgICAgICAgICAgICc8dWwgW25nUGx1cmFsXT1cInN3aXRjaFZhbHVlXCI+JyArXG4gICAgICAgICAgICAgJzx0ZW1wbGF0ZSBuZ1BsdXJhbENhc2U9XCJmZXdcIj48bGk+eW91IGhhdmUgYSBmZXcgbWVzc2FnZXMuPC9saT48L3RlbXBsYXRlPicgK1xuICAgICAgICAgICAgICc8dGVtcGxhdGUgbmdQbHVyYWxDYXNlPVwibWFueVwiPjxsaT55b3UgaGF2ZSBtYW55IG1lc3NhZ2VzLjwvbGk+PC90ZW1wbGF0ZT4nICtcbiAgICAgICAgICAgICAnPC91bD48L2Rpdj4nO1xuXG4gICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShUZXN0Q29tcG9uZW50LCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoVGVzdENvbXBvbmVudClcbiAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2Uuc3dpdGNoVmFsdWUgPSAyO1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgneW91IGhhdmUgYSBmZXcgbWVzc2FnZXMuJyk7XG5cbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLnN3aXRjaFZhbHVlID0gODtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ3lvdSBoYXZlIG1hbnkgbWVzc2FnZXMuJyk7XG5cbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIGRlZmF1bHQgdG8gb3RoZXIgd2hlbiBubyBtYXRjaGVzIGFyZSBmb3VuZCcsXG4gICAgICAgaW5qZWN0KFtUZXN0Q29tcG9uZW50QnVpbGRlciwgQXN5bmNUZXN0Q29tcGxldGVyXSwgKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIGFzeW5jKSA9PiB7XG4gICAgICAgICB2YXIgdGVtcGxhdGUgPVxuICAgICAgICAgICAgICc8ZGl2PicgK1xuICAgICAgICAgICAgICc8dWwgW25nUGx1cmFsXT1cInN3aXRjaFZhbHVlXCI+JyArXG4gICAgICAgICAgICAgJzx0ZW1wbGF0ZSBuZ1BsdXJhbENhc2U9XCJmZXdcIj48bGk+eW91IGhhdmUgYSBmZXcgbWVzc2FnZXMuPC9saT48L3RlbXBsYXRlPicgK1xuICAgICAgICAgICAgICc8dGVtcGxhdGUgbmdQbHVyYWxDYXNlPVwib3RoZXJcIj48bGk+ZGVmYXVsdCBtZXNzYWdlLjwvbGk+PC90ZW1wbGF0ZT4nICtcbiAgICAgICAgICAgICAnPC91bD48L2Rpdj4nO1xuXG4gICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShUZXN0Q29tcG9uZW50LCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoVGVzdENvbXBvbmVudClcbiAgICAgICAgICAgICAudGhlbigoZml4dHVyZSkgPT4ge1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2Uuc3dpdGNoVmFsdWUgPSAxMDA7XG4gICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdkZWZhdWx0IG1lc3NhZ2UuJyk7XG5cbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIHByaW9yaXRpemUgdmFsdWUgbWF0Y2hlcyBvdmVyIGNhdGVnb3J5IG1hdGNoZXMnLFxuICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgdmFyIHRlbXBsYXRlID1cbiAgICAgICAgICAgICAnPGRpdj4nICtcbiAgICAgICAgICAgICAnPHVsIFtuZ1BsdXJhbF09XCJzd2l0Y2hWYWx1ZVwiPicgK1xuICAgICAgICAgICAgICc8dGVtcGxhdGUgbmdQbHVyYWxDYXNlPVwiZmV3XCI+PGxpPnlvdSBoYXZlIGEgZmV3IG1lc3NhZ2VzLjwvbGk+PC90ZW1wbGF0ZT4nICtcbiAgICAgICAgICAgICAnPHRlbXBsYXRlIG5nUGx1cmFsQ2FzZT1cIj0yXCI+eW91IGhhdmUgdHdvIG1lc3NhZ2VzLjwvdGVtcGxhdGU+JyArXG4gICAgICAgICAgICAgJzwvdWw+PC9kaXY+JztcblxuICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoVGVzdENvbXBvbmVudCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgLmNyZWF0ZUFzeW5jKFRlc3RDb21wb25lbnQpXG4gICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLnN3aXRjaFZhbHVlID0gMjtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ3lvdSBoYXZlIHR3byBtZXNzYWdlcy4nKTtcblxuICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2Uuc3dpdGNoVmFsdWUgPSAzO1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgneW91IGhhdmUgYSBmZXcgbWVzc2FnZXMuJyk7XG5cbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG4gIH0pO1xufVxuXG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBUZXN0TG9jYWxpemF0aW9uTWFwIGV4dGVuZHMgTmdMb2NhbGl6YXRpb24ge1xuICBnZXRQbHVyYWxDYXRlZ29yeSh2YWx1ZTogbnVtYmVyKTogc3RyaW5nIHtcbiAgICBpZiAodmFsdWUgPiAxICYmIHZhbHVlIDwgNCkge1xuICAgICAgcmV0dXJuICdmZXcnO1xuICAgIH0gZWxzZSBpZiAodmFsdWUgPj0gNCAmJiB2YWx1ZSA8IDEwKSB7XG4gICAgICByZXR1cm4gJ21hbnknO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gJ290aGVyJztcbiAgICB9XG4gIH1cbn1cblxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ3Rlc3QtY21wJywgZGlyZWN0aXZlczogW05nUGx1cmFsLCBOZ1BsdXJhbENhc2VdLCB0ZW1wbGF0ZTogJyd9KVxuY2xhc3MgVGVzdENvbXBvbmVudCB7XG4gIHN3aXRjaFZhbHVlOiBudW1iZXI7XG5cbiAgY29uc3RydWN0b3IoKSB7IHRoaXMuc3dpdGNoVmFsdWUgPSBudWxsOyB9XG59XG4iXX0=
 main(); 
