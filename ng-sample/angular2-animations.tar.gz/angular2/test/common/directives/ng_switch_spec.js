'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var core_1 = require('angular2/core');
var ng_switch_1 = require('angular2/src/common/directives/ng_switch');
function main() {
    testing_internal_1.describe('switch', function () {
        testing_internal_1.describe('switch value changes', function () {
            testing_internal_1.it('should switch amongst when values', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<div>' +
                    '<ul [ngSwitch]="switchValue">' +
                    '<template ngSwitchWhen="a"><li>when a</li></template>' +
                    '<template ngSwitchWhen="b"><li>when b</li></template>' +
                    '</ul></div>';
                tcb.overrideTemplate(TestComponent, template)
                    .createAsync(TestComponent)
                    .then(function (fixture) {
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('');
                    fixture.debugElement.componentInstance.switchValue = 'a';
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('when a');
                    fixture.debugElement.componentInstance.switchValue = 'b';
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('when b');
                    async.done();
                });
            }));
            testing_internal_1.it('should switch amongst when values with fallback to default', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<div>' +
                    '<ul [ngSwitch]="switchValue">' +
                    '<li template="ngSwitchWhen \'a\'">when a</li>' +
                    '<li template="ngSwitchDefault">when default</li>' +
                    '</ul></div>';
                tcb.overrideTemplate(TestComponent, template)
                    .createAsync(TestComponent)
                    .then(function (fixture) {
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('when default');
                    fixture.debugElement.componentInstance.switchValue = 'a';
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('when a');
                    fixture.debugElement.componentInstance.switchValue = 'b';
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('when default');
                    async.done();
                });
            }));
            testing_internal_1.it('should support multiple whens with the same value', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<div>' +
                    '<ul [ngSwitch]="switchValue">' +
                    '<template ngSwitchWhen="a"><li>when a1;</li></template>' +
                    '<template ngSwitchWhen="b"><li>when b1;</li></template>' +
                    '<template ngSwitchWhen="a"><li>when a2;</li></template>' +
                    '<template ngSwitchWhen="b"><li>when b2;</li></template>' +
                    '<template ngSwitchDefault><li>when default1;</li></template>' +
                    '<template ngSwitchDefault><li>when default2;</li></template>' +
                    '</ul></div>';
                tcb.overrideTemplate(TestComponent, template)
                    .createAsync(TestComponent)
                    .then(function (fixture) {
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement)
                        .toHaveText('when default1;when default2;');
                    fixture.debugElement.componentInstance.switchValue = 'a';
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('when a1;when a2;');
                    fixture.debugElement.componentInstance.switchValue = 'b';
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('when b1;when b2;');
                    async.done();
                });
            }));
        });
        testing_internal_1.describe('when values changes', function () {
            testing_internal_1.it('should switch amongst when values', testing_internal_1.inject([testing_internal_1.TestComponentBuilder, testing_internal_1.AsyncTestCompleter], function (tcb, async) {
                var template = '<div>' +
                    '<ul [ngSwitch]="switchValue">' +
                    '<template [ngSwitchWhen]="when1"><li>when 1;</li></template>' +
                    '<template [ngSwitchWhen]="when2"><li>when 2;</li></template>' +
                    '<template ngSwitchDefault><li>when default;</li></template>' +
                    '</ul></div>';
                tcb.overrideTemplate(TestComponent, template)
                    .createAsync(TestComponent)
                    .then(function (fixture) {
                    fixture.debugElement.componentInstance.when1 = 'a';
                    fixture.debugElement.componentInstance.when2 = 'b';
                    fixture.debugElement.componentInstance.switchValue = 'a';
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('when 1;');
                    fixture.debugElement.componentInstance.switchValue = 'b';
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('when 2;');
                    fixture.debugElement.componentInstance.switchValue = 'c';
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('when default;');
                    fixture.debugElement.componentInstance.when1 = 'c';
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('when 1;');
                    fixture.debugElement.componentInstance.when1 = 'd';
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('when default;');
                    async.done();
                });
            }));
        });
    });
}
exports.main = main;
var TestComponent = (function () {
    function TestComponent() {
        this.switchValue = null;
        this.when1 = null;
        this.when2 = null;
    }
    TestComponent = __decorate([
        core_1.Component({ selector: 'test-cmp', directives: [ng_switch_1.NgSwitch, ng_switch_1.NgSwitchWhen, ng_switch_1.NgSwitchDefault], template: '' }), 
        __metadata('design:paramtypes', [])
    ], TestComponent);
    return TestComponent;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmdfc3dpdGNoX3NwZWMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L2NvbW1vbi9kaXJlY3RpdmVzL25nX3N3aXRjaF9zcGVjLnRzIl0sIm5hbWVzIjpbIm1haW4iLCJUZXN0Q29tcG9uZW50IiwiVGVzdENvbXBvbmVudC5jb25zdHJ1Y3RvciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEsaUNBWU8sMkJBQTJCLENBQUMsQ0FBQTtBQUVuQyxxQkFBd0IsZUFBZSxDQUFDLENBQUE7QUFFeEMsMEJBQXNELDBDQUEwQyxDQUFDLENBQUE7QUFFakc7SUFDRUEsMkJBQVFBLENBQUNBLFFBQVFBLEVBQUVBO1FBQ2pCQSwyQkFBUUEsQ0FBQ0Esc0JBQXNCQSxFQUFFQTtZQUMvQkEscUJBQUVBLENBQUNBLG1DQUFtQ0EsRUFDbkNBLHlCQUFNQSxDQUFDQSxDQUFDQSx1Q0FBb0JBLEVBQUVBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsR0FBeUJBLEVBQUVBLEtBQUtBO2dCQUNsRkEsSUFBSUEsUUFBUUEsR0FBR0EsT0FBT0E7b0JBQ1BBLCtCQUErQkE7b0JBQy9CQSx1REFBdURBO29CQUN2REEsdURBQXVEQTtvQkFDdkRBLGFBQWFBLENBQUNBO2dCQUU3QkEsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxhQUFhQSxFQUFFQSxRQUFRQSxDQUFDQTtxQkFDeENBLFdBQVdBLENBQUNBLGFBQWFBLENBQUNBO3FCQUMxQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsT0FBT0E7b0JBQ1pBLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUN4QkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO29CQUUxREEsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxXQUFXQSxHQUFHQSxHQUFHQSxDQUFDQTtvQkFDekRBLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUN4QkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBO29CQUVoRUEsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxXQUFXQSxHQUFHQSxHQUFHQSxDQUFDQTtvQkFDekRBLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUN4QkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBO29CQUVoRUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSw0REFBNERBLEVBQzVEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtnQkFDbEZBLElBQUlBLFFBQVFBLEdBQUdBLE9BQU9BO29CQUNQQSwrQkFBK0JBO29CQUMvQkEsK0NBQStDQTtvQkFDL0NBLGtEQUFrREE7b0JBQ2xEQSxhQUFhQSxDQUFDQTtnQkFFN0JBLEdBQUdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsYUFBYUEsRUFBRUEsUUFBUUEsQ0FBQ0E7cUJBQ3hDQSxXQUFXQSxDQUFDQSxhQUFhQSxDQUFDQTtxQkFDMUJBLElBQUlBLENBQUNBLFVBQUNBLE9BQU9BO29CQUNaQSxPQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFDeEJBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQTtvQkFFdEVBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsV0FBV0EsR0FBR0EsR0FBR0EsQ0FBQ0E7b0JBQ3pEQSxPQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFDeEJBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtvQkFFaEVBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsV0FBV0EsR0FBR0EsR0FBR0EsQ0FBQ0E7b0JBQ3pEQSxPQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFDeEJBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQTtvQkFFdEVBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVQQSxxQkFBRUEsQ0FBQ0EsbURBQW1EQSxFQUNuREEseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxHQUF5QkEsRUFBRUEsS0FBS0E7Z0JBQ2xGQSxJQUFJQSxRQUFRQSxHQUFHQSxPQUFPQTtvQkFDUEEsK0JBQStCQTtvQkFDL0JBLHlEQUF5REE7b0JBQ3pEQSx5REFBeURBO29CQUN6REEseURBQXlEQTtvQkFDekRBLHlEQUF5REE7b0JBQ3pEQSw4REFBOERBO29CQUM5REEsOERBQThEQTtvQkFDOURBLGFBQWFBLENBQUNBO2dCQUU3QkEsR0FBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxhQUFhQSxFQUFFQSxRQUFRQSxDQUFDQTtxQkFDeENBLFdBQVdBLENBQUNBLGFBQWFBLENBQUNBO3FCQUMxQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsT0FBT0E7b0JBQ1pBLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUN4QkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBO3lCQUNyQ0EsVUFBVUEsQ0FBQ0EsOEJBQThCQSxDQUFDQSxDQUFDQTtvQkFFaERBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsV0FBV0EsR0FBR0EsR0FBR0EsQ0FBQ0E7b0JBQ3pEQSxPQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFDeEJBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxrQkFBa0JBLENBQUNBLENBQUNBO29CQUUxRUEsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxXQUFXQSxHQUFHQSxHQUFHQSxDQUFDQTtvQkFDekRBLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUN4QkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsQ0FBQ0E7b0JBRTFFQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEsMkJBQVFBLENBQUNBLHFCQUFxQkEsRUFBRUE7WUFDOUJBLHFCQUFFQSxDQUFDQSxtQ0FBbUNBLEVBQ25DQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsdUNBQW9CQSxFQUFFQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEdBQXlCQSxFQUFFQSxLQUFLQTtnQkFDbEZBLElBQUlBLFFBQVFBLEdBQUdBLE9BQU9BO29CQUNQQSwrQkFBK0JBO29CQUMvQkEsOERBQThEQTtvQkFDOURBLDhEQUE4REE7b0JBQzlEQSw2REFBNkRBO29CQUM3REEsYUFBYUEsQ0FBQ0E7Z0JBRTdCQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLGFBQWFBLEVBQUVBLFFBQVFBLENBQUNBO3FCQUN4Q0EsV0FBV0EsQ0FBQ0EsYUFBYUEsQ0FBQ0E7cUJBQzFCQSxJQUFJQSxDQUFDQSxVQUFDQSxPQUFPQTtvQkFDWkEsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxLQUFLQSxHQUFHQSxHQUFHQSxDQUFDQTtvQkFDbkRBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsS0FBS0EsR0FBR0EsR0FBR0EsQ0FBQ0E7b0JBQ25EQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLFdBQVdBLEdBQUdBLEdBQUdBLENBQUNBO29CQUN6REEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7b0JBRWpFQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLFdBQVdBLEdBQUdBLEdBQUdBLENBQUNBO29CQUN6REEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7b0JBRWpFQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLFdBQVdBLEdBQUdBLEdBQUdBLENBQUNBO29CQUN6REEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0E7b0JBRXZFQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLEtBQUtBLEdBQUdBLEdBQUdBLENBQUNBO29CQUNuREEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7b0JBRWpFQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxpQkFBaUJBLENBQUNBLEtBQUtBLEdBQUdBLEdBQUdBLENBQUNBO29CQUNuREEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0E7b0JBRXZFQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7QUFDTEEsQ0FBQ0E7QUEvSGUsWUFBSSxPQStIbkIsQ0FBQTtBQUVEO0lBT0VDO1FBQ0VDLElBQUlBLENBQUNBLFdBQVdBLEdBQUdBLElBQUlBLENBQUNBO1FBQ3hCQSxJQUFJQSxDQUFDQSxLQUFLQSxHQUFHQSxJQUFJQSxDQUFDQTtRQUNsQkEsSUFBSUEsQ0FBQ0EsS0FBS0EsR0FBR0EsSUFBSUEsQ0FBQ0E7SUFDcEJBLENBQUNBO0lBWEhEO1FBQUNBLGdCQUFTQSxDQUNOQSxFQUFDQSxRQUFRQSxFQUFFQSxVQUFVQSxFQUFFQSxVQUFVQSxFQUFFQSxDQUFDQSxvQkFBUUEsRUFBRUEsd0JBQVlBLEVBQUVBLDJCQUFlQSxDQUFDQSxFQUFFQSxRQUFRQSxFQUFFQSxFQUFFQSxFQUFDQSxDQUFDQTs7c0JBVy9GQTtJQUFEQSxvQkFBQ0E7QUFBREEsQ0FBQ0EsQUFaRCxJQVlDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXN5bmNUZXN0Q29tcGxldGVyLFxuICBUZXN0Q29tcG9uZW50QnVpbGRlcixcbiAgYmVmb3JlRWFjaCxcbiAgZGRlc2NyaWJlLFxuICBkZXNjcmliZSxcbiAgZWwsXG4gIGV4cGVjdCxcbiAgaWl0LFxuICBpbmplY3QsXG4gIGl0LFxuICB4aXQsXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5pbXBvcnQge0NvbXBvbmVudH0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5cbmltcG9ydCB7TmdTd2l0Y2gsIE5nU3dpdGNoV2hlbiwgTmdTd2l0Y2hEZWZhdWx0fSBmcm9tICdhbmd1bGFyMi9zcmMvY29tbW9uL2RpcmVjdGl2ZXMvbmdfc3dpdGNoJztcblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGRlc2NyaWJlKCdzd2l0Y2gnLCAoKSA9PiB7XG4gICAgZGVzY3JpYmUoJ3N3aXRjaCB2YWx1ZSBjaGFuZ2VzJywgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCBzd2l0Y2ggYW1vbmdzdCB3aGVuIHZhbHVlcycsXG4gICAgICAgICBpbmplY3QoW1Rlc3RDb21wb25lbnRCdWlsZGVyLCBBc3luY1Rlc3RDb21wbGV0ZXJdLCAodGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlciwgYXN5bmMpID0+IHtcbiAgICAgICAgICAgdmFyIHRlbXBsYXRlID0gJzxkaXY+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8dWwgW25nU3dpdGNoXT1cInN3aXRjaFZhbHVlXCI+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8dGVtcGxhdGUgbmdTd2l0Y2hXaGVuPVwiYVwiPjxsaT53aGVuIGE8L2xpPjwvdGVtcGxhdGU+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8dGVtcGxhdGUgbmdTd2l0Y2hXaGVuPVwiYlwiPjxsaT53aGVuIGI8L2xpPjwvdGVtcGxhdGU+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8L3VsPjwvZGl2Pic7XG5cbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoVGVzdENvbXBvbmVudCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoVGVzdENvbXBvbmVudClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnJyk7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2Uuc3dpdGNoVmFsdWUgPSAnYSc7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnd2hlbiBhJyk7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2Uuc3dpdGNoVmFsdWUgPSAnYic7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnd2hlbiBiJyk7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc3dpdGNoIGFtb25nc3Qgd2hlbiB2YWx1ZXMgd2l0aCBmYWxsYmFjayB0byBkZWZhdWx0JyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPGRpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzx1bCBbbmdTd2l0Y2hdPVwic3dpdGNoVmFsdWVcIj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzxsaSB0ZW1wbGF0ZT1cIm5nU3dpdGNoV2hlbiBcXCdhXFwnXCI+d2hlbiBhPC9saT4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzxsaSB0ZW1wbGF0ZT1cIm5nU3dpdGNoRGVmYXVsdFwiPndoZW4gZGVmYXVsdDwvbGk+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8L3VsPjwvZGl2Pic7XG5cbiAgICAgICAgICAgdGNiLm92ZXJyaWRlVGVtcGxhdGUoVGVzdENvbXBvbmVudCwgdGVtcGxhdGUpXG4gICAgICAgICAgICAgICAuY3JlYXRlQXN5bmMoVGVzdENvbXBvbmVudClcbiAgICAgICAgICAgICAgIC50aGVuKChmaXh0dXJlKSA9PiB7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnd2hlbiBkZWZhdWx0Jyk7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2Uuc3dpdGNoVmFsdWUgPSAnYSc7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnd2hlbiBhJyk7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2Uuc3dpdGNoVmFsdWUgPSAnYic7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnd2hlbiBkZWZhdWx0Jyk7XG5cbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCBtdWx0aXBsZSB3aGVucyB3aXRoIHRoZSBzYW1lIHZhbHVlJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPGRpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzx1bCBbbmdTd2l0Y2hdPVwic3dpdGNoVmFsdWVcIj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzx0ZW1wbGF0ZSBuZ1N3aXRjaFdoZW49XCJhXCI+PGxpPndoZW4gYTE7PC9saT48L3RlbXBsYXRlPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPHRlbXBsYXRlIG5nU3dpdGNoV2hlbj1cImJcIj48bGk+d2hlbiBiMTs8L2xpPjwvdGVtcGxhdGU+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8dGVtcGxhdGUgbmdTd2l0Y2hXaGVuPVwiYVwiPjxsaT53aGVuIGEyOzwvbGk+PC90ZW1wbGF0ZT4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzx0ZW1wbGF0ZSBuZ1N3aXRjaFdoZW49XCJiXCI+PGxpPndoZW4gYjI7PC9saT48L3RlbXBsYXRlPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPHRlbXBsYXRlIG5nU3dpdGNoRGVmYXVsdD48bGk+d2hlbiBkZWZhdWx0MTs8L2xpPjwvdGVtcGxhdGU+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8dGVtcGxhdGUgbmdTd2l0Y2hEZWZhdWx0PjxsaT53aGVuIGRlZmF1bHQyOzwvbGk+PC90ZW1wbGF0ZT4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzwvdWw+PC9kaXY+JztcblxuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShUZXN0Q29tcG9uZW50LCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhUZXN0Q29tcG9uZW50KVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KVxuICAgICAgICAgICAgICAgICAgICAgLnRvSGF2ZVRleHQoJ3doZW4gZGVmYXVsdDE7d2hlbiBkZWZhdWx0MjsnKTtcblxuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5zd2l0Y2hWYWx1ZSA9ICdhJztcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCd3aGVuIGExO3doZW4gYTI7Jyk7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2Uuc3dpdGNoVmFsdWUgPSAnYic7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnd2hlbiBiMTt3aGVuIGIyOycpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ3doZW4gdmFsdWVzIGNoYW5nZXMnLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIHN3aXRjaCBhbW9uZ3N0IHdoZW4gdmFsdWVzJyxcbiAgICAgICAgIGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIEFzeW5jVGVzdENvbXBsZXRlcl0sICh0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyLCBhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgdGVtcGxhdGUgPSAnPGRpdj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzx1bCBbbmdTd2l0Y2hdPVwic3dpdGNoVmFsdWVcIj4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzx0ZW1wbGF0ZSBbbmdTd2l0Y2hXaGVuXT1cIndoZW4xXCI+PGxpPndoZW4gMTs8L2xpPjwvdGVtcGxhdGU+JyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICc8dGVtcGxhdGUgW25nU3dpdGNoV2hlbl09XCJ3aGVuMlwiPjxsaT53aGVuIDI7PC9saT48L3RlbXBsYXRlPicgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnPHRlbXBsYXRlIG5nU3dpdGNoRGVmYXVsdD48bGk+d2hlbiBkZWZhdWx0OzwvbGk+PC90ZW1wbGF0ZT4nICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJzwvdWw+PC9kaXY+JztcblxuICAgICAgICAgICB0Y2Iub3ZlcnJpZGVUZW1wbGF0ZShUZXN0Q29tcG9uZW50LCB0ZW1wbGF0ZSlcbiAgICAgICAgICAgICAgIC5jcmVhdGVBc3luYyhUZXN0Q29tcG9uZW50KVxuICAgICAgICAgICAgICAgLnRoZW4oKGZpeHR1cmUpID0+IHtcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2Uud2hlbjEgPSAnYSc7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLndoZW4yID0gJ2InO1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5zd2l0Y2hWYWx1ZSA9ICdhJztcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCd3aGVuIDE7Jyk7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2Uuc3dpdGNoVmFsdWUgPSAnYic7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnd2hlbiAyOycpO1xuXG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGVidWdFbGVtZW50LmNvbXBvbmVudEluc3RhbmNlLnN3aXRjaFZhbHVlID0gJ2MnO1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ3doZW4gZGVmYXVsdDsnKTtcblxuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS53aGVuMSA9ICdjJztcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCd3aGVuIDE7Jyk7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZWJ1Z0VsZW1lbnQuY29tcG9uZW50SW5zdGFuY2Uud2hlbjEgPSAnZCc7XG4gICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnd2hlbiBkZWZhdWx0OycpO1xuXG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuICAgIH0pO1xuICB9KTtcbn1cblxuQENvbXBvbmVudChcbiAgICB7c2VsZWN0b3I6ICd0ZXN0LWNtcCcsIGRpcmVjdGl2ZXM6IFtOZ1N3aXRjaCwgTmdTd2l0Y2hXaGVuLCBOZ1N3aXRjaERlZmF1bHRdLCB0ZW1wbGF0ZTogJyd9KVxuY2xhc3MgVGVzdENvbXBvbmVudCB7XG4gIHN3aXRjaFZhbHVlOiBhbnk7XG4gIHdoZW4xOiBhbnk7XG4gIHdoZW4yOiBhbnk7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5zd2l0Y2hWYWx1ZSA9IG51bGw7XG4gICAgdGhpcy53aGVuMSA9IG51bGw7XG4gICAgdGhpcy53aGVuMiA9IG51bGw7XG4gIH1cbn1cbiJdfQ==
 main(); 
