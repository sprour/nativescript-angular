import { NgLocalization } from 'angular2/common';
export declare function main(): void;
export declare class TestLocalizationMap extends NgLocalization {
    getPluralCategory(value: number): string;
}
