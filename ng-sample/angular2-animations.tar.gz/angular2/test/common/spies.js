'use strict';var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var change_detector_ref_1 = require('angular2/src/core/change_detection/change_detector_ref');
var testing_internal_1 = require('angular2/testing_internal');
var SpyChangeDetectorRef = (function (_super) {
    __extends(SpyChangeDetectorRef, _super);
    function SpyChangeDetectorRef() {
        _super.call(this, change_detector_ref_1.ChangeDetectorRef);
        this.spy('markForCheck');
    }
    return SpyChangeDetectorRef;
})(testing_internal_1.SpyObject);
exports.SpyChangeDetectorRef = SpyChangeDetectorRef;
var SpyNgControl = (function (_super) {
    __extends(SpyNgControl, _super);
    function SpyNgControl() {
        _super.apply(this, arguments);
    }
    return SpyNgControl;
})(testing_internal_1.SpyObject);
exports.SpyNgControl = SpyNgControl;
var SpyValueAccessor = (function (_super) {
    __extends(SpyValueAccessor, _super);
    function SpyValueAccessor() {
        _super.apply(this, arguments);
    }
    return SpyValueAccessor;
})(testing_internal_1.SpyObject);
exports.SpyValueAccessor = SpyValueAccessor;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3BpZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L2NvbW1vbi9zcGllcy50cyJdLCJuYW1lcyI6WyJTcHlDaGFuZ2VEZXRlY3RvclJlZiIsIlNweUNoYW5nZURldGVjdG9yUmVmLmNvbnN0cnVjdG9yIiwiU3B5TmdDb250cm9sIiwiU3B5TmdDb250cm9sLmNvbnN0cnVjdG9yIiwiU3B5VmFsdWVBY2Nlc3NvciIsIlNweVZhbHVlQWNjZXNzb3IuY29uc3RydWN0b3IiXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsb0NBQWdDLHdEQUF3RCxDQUFDLENBQUE7QUFDekYsaUNBQStCLDJCQUEyQixDQUFDLENBQUE7QUFFM0Q7SUFBMENBLHdDQUFTQTtJQUNqREE7UUFDRUMsa0JBQU1BLHVDQUFpQkEsQ0FBQ0EsQ0FBQ0E7UUFDekJBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLGNBQWNBLENBQUNBLENBQUNBO0lBQzNCQSxDQUFDQTtJQUNIRCwyQkFBQ0E7QUFBREEsQ0FBQ0EsQUFMRCxFQUEwQyw0QkFBUyxFQUtsRDtBQUxZLDRCQUFvQix1QkFLaEMsQ0FBQTtBQUVEO0lBQWtDRSxnQ0FBU0E7SUFBM0NBO1FBQWtDQyw4QkFBU0E7SUFBRUEsQ0FBQ0E7SUFBREQsbUJBQUNBO0FBQURBLENBQUNBLEFBQTlDLEVBQWtDLDRCQUFTLEVBQUc7QUFBakMsb0JBQVksZUFBcUIsQ0FBQTtBQUU5QztJQUFzQ0Usb0NBQVNBO0lBQS9DQTtRQUFzQ0MsOEJBQVNBO0lBQUVBLENBQUNBO0lBQURELHVCQUFDQTtBQUFEQSxDQUFDQSxBQUFsRCxFQUFzQyw0QkFBUyxFQUFHO0FBQXJDLHdCQUFnQixtQkFBcUIsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q2hhbmdlRGV0ZWN0b3JSZWZ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2NoYW5nZV9kZXRlY3Rpb24vY2hhbmdlX2RldGVjdG9yX3JlZic7XG5pbXBvcnQge1NweU9iamVjdCwgcHJveHl9IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5leHBvcnQgY2xhc3MgU3B5Q2hhbmdlRGV0ZWN0b3JSZWYgZXh0ZW5kcyBTcHlPYmplY3Qge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcihDaGFuZ2VEZXRlY3RvclJlZik7XG4gICAgdGhpcy5zcHkoJ21hcmtGb3JDaGVjaycpO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBTcHlOZ0NvbnRyb2wgZXh0ZW5kcyBTcHlPYmplY3Qge31cblxuZXhwb3J0IGNsYXNzIFNweVZhbHVlQWNjZXNzb3IgZXh0ZW5kcyBTcHlPYmplY3Qge31cbiJdfQ==