'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var message_1 = require('angular2/src/i18n/message');
function main() {
    testing_internal_1.describe('Message', function () {
        testing_internal_1.describe("id", function () {
            testing_internal_1.it("should return a different id for messages with and without the meaning", function () {
                var m1 = new message_1.Message("content", "meaning", null);
                var m2 = new message_1.Message("content", null, null);
                testing_internal_1.expect(message_1.id(m1)).toEqual(message_1.id(m1));
                testing_internal_1.expect(message_1.id(m1)).not.toEqual(message_1.id(m2));
            });
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVzc2FnZV9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9pMThuL21lc3NhZ2Vfc3BlYy50cyJdLCJuYW1lcyI6WyJtYWluIl0sIm1hcHBpbmdzIjoiQUFBQSxpQ0FXTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLHdCQUEwQiwyQkFBMkIsQ0FBQyxDQUFBO0FBRXREO0lBQ0VBLDJCQUFRQSxDQUFDQSxTQUFTQSxFQUFFQTtRQUNsQkEsMkJBQVFBLENBQUNBLElBQUlBLEVBQUVBO1lBQ2JBLHFCQUFFQSxDQUFDQSx3RUFBd0VBLEVBQUVBO2dCQUMzRUEsSUFBSUEsRUFBRUEsR0FBR0EsSUFBSUEsaUJBQU9BLENBQUNBLFNBQVNBLEVBQUVBLFNBQVNBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO2dCQUNqREEsSUFBSUEsRUFBRUEsR0FBR0EsSUFBSUEsaUJBQU9BLENBQUNBLFNBQVNBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO2dCQUM1Q0EseUJBQU1BLENBQUNBLFlBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLFlBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO2dCQUMvQkEseUJBQU1BLENBQUNBLFlBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLE9BQU9BLENBQUNBLFlBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO1lBQ3JDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQVhlLFlBQUksT0FXbkIsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFzeW5jVGVzdENvbXBsZXRlcixcbiAgYmVmb3JlRWFjaCxcbiAgZGRlc2NyaWJlLFxuICBkZXNjcmliZSxcbiAgZXhwZWN0LFxuICBpaXQsXG4gIGluamVjdCxcbiAgaXQsXG4gIHhkZXNjcmliZSxcbiAgeGl0XG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5pbXBvcnQge01lc3NhZ2UsIGlkfSBmcm9tICdhbmd1bGFyMi9zcmMvaTE4bi9tZXNzYWdlJztcblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGRlc2NyaWJlKCdNZXNzYWdlJywgKCkgPT4ge1xuICAgIGRlc2NyaWJlKFwiaWRcIiwgKCkgPT4ge1xuICAgICAgaXQoXCJzaG91bGQgcmV0dXJuIGEgZGlmZmVyZW50IGlkIGZvciBtZXNzYWdlcyB3aXRoIGFuZCB3aXRob3V0IHRoZSBtZWFuaW5nXCIsICgpID0+IHtcbiAgICAgICAgbGV0IG0xID0gbmV3IE1lc3NhZ2UoXCJjb250ZW50XCIsIFwibWVhbmluZ1wiLCBudWxsKTtcbiAgICAgICAgbGV0IG0yID0gbmV3IE1lc3NhZ2UoXCJjb250ZW50XCIsIG51bGwsIG51bGwpO1xuICAgICAgICBleHBlY3QoaWQobTEpKS50b0VxdWFsKGlkKG0xKSk7XG4gICAgICAgIGV4cGVjdChpZChtMSkpLm5vdC50b0VxdWFsKGlkKG0yKSk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfSk7XG59XG4iXX0=
 main(); 
