export declare function main(): void;
