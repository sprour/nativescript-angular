'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var spies_1 = require('../spies');
var core_1 = require('angular2/core');
var common_dom_1 = require('angular2/platform/common_dom');
var router_1 = require('angular2/router');
var dom_adapter_1 = require('angular2/src/platform/dom/dom_adapter');
var instruction_1 = require('angular2/src/router/instruction');
var dummyInstruction = new instruction_1.ResolvedInstruction(new router_1.ComponentInstruction('detail', [], null, null, true, '0', null, 'Detail'), null, {});
function main() {
    testing_internal_1.describe('routerLink directive', function () {
        var tcb;
        testing_internal_1.beforeEachProviders(function () { return [
            core_1.provide(router_1.Location, { useValue: makeDummyLocation() }),
            core_1.provide(router_1.Router, { useValue: makeDummyRouter() })
        ]; });
        testing_internal_1.beforeEach(testing_internal_1.inject([testing_internal_1.TestComponentBuilder], function (tcBuilder) { tcb = tcBuilder; }));
        testing_internal_1.it('should update a[href] attribute', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            tcb.createAsync(TestComponent)
                .then(function (testComponent) {
                testComponent.detectChanges();
                var anchorElement = testComponent.debugElement.query(common_dom_1.By.css('a.detail-view')).nativeElement;
                testing_internal_1.expect(dom_adapter_1.DOM.getAttribute(anchorElement, 'href')).toEqual('detail');
                async.done();
            });
        }));
        testing_internal_1.it('should call router.navigate when a link is clicked', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter, router_1.Router], function (async, router) {
            tcb.createAsync(TestComponent)
                .then(function (testComponent) {
                testComponent.detectChanges();
                // TODO: shouldn't this be just 'click' rather than '^click'?
                testComponent.debugElement.query(common_dom_1.By.css('a.detail-view'))
                    .triggerEventHandler('click', null);
                testing_internal_1.expect(router.spy('navigateByInstruction')).toHaveBeenCalledWith(dummyInstruction);
                async.done();
            });
        }));
        testing_internal_1.it('should call router.navigate when a link is clicked if target is _self', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter, router_1.Router], function (async, router) {
            tcb.createAsync(TestComponent)
                .then(function (testComponent) {
                testComponent.detectChanges();
                testComponent.debugElement.query(common_dom_1.By.css('a.detail-view-self'))
                    .triggerEventHandler('click', null);
                testing_internal_1.expect(router.spy('navigateByInstruction')).toHaveBeenCalledWith(dummyInstruction);
                async.done();
            });
        }));
        testing_internal_1.it('should NOT call router.navigate when a link is clicked if target is set to other than _self', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter, router_1.Router], function (async, router) {
            tcb.createAsync(TestComponent)
                .then(function (testComponent) {
                testComponent.detectChanges();
                testComponent.debugElement.query(common_dom_1.By.css('a.detail-view-blank'))
                    .triggerEventHandler('click', null);
                testing_internal_1.expect(router.spy('navigateByInstruction')).not.toHaveBeenCalled();
                async.done();
            });
        }));
    });
}
exports.main = main;
var UserCmp = (function () {
    function UserCmp(params) {
        this.user = params.get('name');
    }
    UserCmp = __decorate([
        core_1.Component({ selector: 'user-cmp', template: "hello {{user}}" }), 
        __metadata('design:paramtypes', [router_1.RouteParams])
    ], UserCmp);
    return UserCmp;
})();
var TestComponent = (function () {
    function TestComponent() {
    }
    TestComponent = __decorate([
        core_1.Component({
            selector: 'test-component',
            template: "\n    <div>\n      <a [routerLink]=\"['/Detail']\"\n         class=\"detail-view\">\n           detail view\n      </a>\n      <a [routerLink]=\"['/Detail']\"\n         class=\"detail-view-self\"\n         target=\"_self\">\n           detail view with _self target\n      </a>\n      <a [routerLink]=\"['/Detail']\"\n         class=\"detail-view-blank\"\n         target=\"_blank\">\n           detail view with _blank target\n      </a>\n    </div>",
            directives: [router_1.RouterLink]
        }), 
        __metadata('design:paramtypes', [])
    ], TestComponent);
    return TestComponent;
})();
function makeDummyLocation() {
    var dl = new spies_1.SpyLocation();
    dl.spy('prepareExternalUrl').andCallFake(function (url) { return url; });
    return dl;
}
function makeDummyRouter() {
    var dr = new spies_1.SpyRouter();
    dr.spy('generate').andCallFake(function (routeParams) { return dummyInstruction; });
    dr.spy('isRouteActive').andCallFake(function (_) { return false; });
    dr.spy('navigateInstruction');
    return dr;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGVyX2xpbmtfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3Qvcm91dGVyL2RpcmVjdGl2ZXMvcm91dGVyX2xpbmtfc3BlYy50cyJdLCJuYW1lcyI6WyJtYWluIiwiVXNlckNtcCIsIlVzZXJDbXAuY29uc3RydWN0b3IiLCJUZXN0Q29tcG9uZW50IiwiVGVzdENvbXBvbmVudC5jb25zdHJ1Y3RvciIsIm1ha2VEdW1teUxvY2F0aW9uIiwibWFrZUR1bW15Um91dGVyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxpQ0FjTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLHNCQUFxQyxVQUFVLENBQUMsQ0FBQTtBQUVoRCxxQkFBaUMsZUFBZSxDQUFDLENBQUE7QUFDakQsMkJBQWlCLDhCQUE4QixDQUFDLENBQUE7QUFFaEQsdUJBU08saUJBQWlCLENBQUMsQ0FBQTtBQUV6Qiw0QkFBa0IsdUNBQXVDLENBQUMsQ0FBQTtBQUMxRCw0QkFBa0MsaUNBQWlDLENBQUMsQ0FBQTtBQUVwRSxJQUFJLGdCQUFnQixHQUFHLElBQUksaUNBQW1CLENBQzFDLElBQUksNkJBQW9CLENBQUMsUUFBUSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztBQUU3RjtJQUNFQSwyQkFBUUEsQ0FBQ0Esc0JBQXNCQSxFQUFFQTtRQUMvQixJQUFJLEdBQXlCLENBQUM7UUFFOUIsc0NBQW1CLENBQUMsY0FBTSxPQUFBO1lBQ3hCLGNBQU8sQ0FBQyxpQkFBUSxFQUFFLEVBQUMsUUFBUSxFQUFFLGlCQUFpQixFQUFFLEVBQUMsQ0FBQztZQUNsRCxjQUFPLENBQUMsZUFBTSxFQUFFLEVBQUMsUUFBUSxFQUFFLGVBQWUsRUFBRSxFQUFDLENBQUM7U0FDL0MsRUFIeUIsQ0FHekIsQ0FBQyxDQUFDO1FBRUgsNkJBQVUsQ0FBQyx5QkFBTSxDQUFDLENBQUMsdUNBQW9CLENBQUMsRUFBRSxVQUFDLFNBQVMsSUFBTyxHQUFHLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVoRixxQkFBRSxDQUFDLGlDQUFpQyxFQUFFLHlCQUFNLENBQUMsQ0FBQyxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsS0FBSztZQUVwRSxHQUFHLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQztpQkFDekIsSUFBSSxDQUFDLFVBQUMsYUFBYTtnQkFDbEIsYUFBYSxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUM5QixJQUFJLGFBQWEsR0FDYixhQUFhLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxlQUFFLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDO2dCQUM1RSx5QkFBTSxDQUFDLGlCQUFHLENBQUMsWUFBWSxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDbEUsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBR1AscUJBQUUsQ0FBQyxvREFBb0QsRUFDcEQseUJBQU0sQ0FBQyxDQUFDLHFDQUFrQixFQUFFLGVBQU0sQ0FBQyxFQUFFLFVBQUMsS0FBSyxFQUFFLE1BQU07WUFFakQsR0FBRyxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUM7aUJBQ3pCLElBQUksQ0FBQyxVQUFDLGFBQWE7Z0JBQ2xCLGFBQWEsQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDOUIsNkRBQTZEO2dCQUM3RCxhQUFhLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxlQUFFLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDO3FCQUNwRCxtQkFBbUIsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3hDLHlCQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztnQkFDbkYsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRVAscUJBQUUsQ0FBQyx1RUFBdUUsRUFDdkUseUJBQU0sQ0FBQyxDQUFDLHFDQUFrQixFQUFFLGVBQU0sQ0FBQyxFQUFFLFVBQUMsS0FBSyxFQUFFLE1BQU07WUFFakQsR0FBRyxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUM7aUJBQ3pCLElBQUksQ0FBQyxVQUFDLGFBQWE7Z0JBQ2xCLGFBQWEsQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDOUIsYUFBYSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsZUFBRSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO3FCQUN6RCxtQkFBbUIsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3hDLHlCQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztnQkFDbkYsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRVAscUJBQUUsQ0FBQyw2RkFBNkYsRUFDN0YseUJBQU0sQ0FBQyxDQUFDLHFDQUFrQixFQUFFLGVBQU0sQ0FBQyxFQUFFLFVBQUMsS0FBSyxFQUFFLE1BQU07WUFFakQsR0FBRyxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUM7aUJBQ3pCLElBQUksQ0FBQyxVQUFDLGFBQWE7Z0JBQ2xCLGFBQWEsQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDOUIsYUFBYSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsZUFBRSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO3FCQUMxRCxtQkFBbUIsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3hDLHlCQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBQ25FLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNmLENBQUMsQ0FBQyxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNULENBQUMsQ0FBQ0EsQ0FBQ0E7QUFDTEEsQ0FBQ0E7QUFoRWUsWUFBSSxPQWdFbkIsQ0FBQTtBQUVEO0lBR0VDLGlCQUFZQSxNQUFtQkE7UUFBSUMsSUFBSUEsQ0FBQ0EsSUFBSUEsR0FBR0EsTUFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFIdEVEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxVQUFVQSxFQUFFQSxRQUFRQSxFQUFFQSxnQkFBZ0JBLEVBQUNBLENBQUNBOztnQkFJN0RBO0lBQURBLGNBQUNBO0FBQURBLENBQUNBLEFBSkQsSUFJQztBQUVEO0lBQUFFO0lBc0JBQyxDQUFDQTtJQXRCREQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLGdCQUFnQkE7WUFDMUJBLFFBQVFBLEVBQUVBLG9jQWdCREE7WUFDVEEsVUFBVUEsRUFBRUEsQ0FBQ0EsbUJBQVVBLENBQUNBO1NBQ3pCQSxDQUFDQTs7c0JBRURBO0lBQURBLG9CQUFDQTtBQUFEQSxDQUFDQSxBQXRCRCxJQXNCQztBQUVEO0lBQ0VFLElBQUlBLEVBQUVBLEdBQUdBLElBQUlBLG1CQUFXQSxFQUFFQSxDQUFDQTtJQUMzQkEsRUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0Esb0JBQW9CQSxDQUFDQSxDQUFDQSxXQUFXQSxDQUFDQSxVQUFDQSxHQUFHQSxJQUFLQSxPQUFBQSxHQUFHQSxFQUFIQSxDQUFHQSxDQUFDQSxDQUFDQTtJQUN2REEsTUFBTUEsQ0FBQ0EsRUFBRUEsQ0FBQ0E7QUFDWkEsQ0FBQ0E7QUFFRDtJQUNFQyxJQUFJQSxFQUFFQSxHQUFHQSxJQUFJQSxpQkFBU0EsRUFBRUEsQ0FBQ0E7SUFDekJBLEVBQUVBLENBQUNBLEdBQUdBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBLFdBQVdBLENBQUNBLFVBQUNBLFdBQVdBLElBQUtBLE9BQUFBLGdCQUFnQkEsRUFBaEJBLENBQWdCQSxDQUFDQSxDQUFDQTtJQUNsRUEsRUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0EsV0FBV0EsQ0FBQ0EsVUFBQ0EsQ0FBQ0EsSUFBS0EsT0FBQUEsS0FBS0EsRUFBTEEsQ0FBS0EsQ0FBQ0EsQ0FBQ0E7SUFDbERBLEVBQUVBLENBQUNBLEdBQUdBLENBQUNBLHFCQUFxQkEsQ0FBQ0EsQ0FBQ0E7SUFDOUJBLE1BQU1BLENBQUNBLEVBQUVBLENBQUNBO0FBQ1pBLENBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXN5bmNUZXN0Q29tcGxldGVyLFxuICBiZWZvcmVFYWNoLFxuICBkZGVzY3JpYmUsXG4gIHhkZXNjcmliZSxcbiAgZGVzY3JpYmUsXG4gIGRpc3BhdGNoRXZlbnQsXG4gIGV4cGVjdCxcbiAgaWl0LFxuICBpbmplY3QsXG4gIGJlZm9yZUVhY2hQcm92aWRlcnMsXG4gIGl0LFxuICB4aXQsXG4gIFRlc3RDb21wb25lbnRCdWlsZGVyXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5pbXBvcnQge1NweVJvdXRlciwgU3B5TG9jYXRpb259IGZyb20gJy4uL3NwaWVzJztcblxuaW1wb3J0IHtwcm92aWRlLCBDb21wb25lbnR9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuaW1wb3J0IHtCeX0gZnJvbSAnYW5ndWxhcjIvcGxhdGZvcm0vY29tbW9uX2RvbSc7XG5cbmltcG9ydCB7XG4gIExvY2F0aW9uLFxuICBSb3V0ZXIsXG4gIFJvdXRlUmVnaXN0cnksXG4gIFJvdXRlckxpbmssXG4gIFJvdXRlck91dGxldCxcbiAgUm91dGUsXG4gIFJvdXRlUGFyYW1zLFxuICBDb21wb25lbnRJbnN0cnVjdGlvblxufSBmcm9tICdhbmd1bGFyMi9yb3V0ZXInO1xuXG5pbXBvcnQge0RPTX0gZnJvbSAnYW5ndWxhcjIvc3JjL3BsYXRmb3JtL2RvbS9kb21fYWRhcHRlcic7XG5pbXBvcnQge1Jlc29sdmVkSW5zdHJ1Y3Rpb259IGZyb20gJ2FuZ3VsYXIyL3NyYy9yb3V0ZXIvaW5zdHJ1Y3Rpb24nO1xuXG5sZXQgZHVtbXlJbnN0cnVjdGlvbiA9IG5ldyBSZXNvbHZlZEluc3RydWN0aW9uKFxuICAgIG5ldyBDb21wb25lbnRJbnN0cnVjdGlvbignZGV0YWlsJywgW10sIG51bGwsIG51bGwsIHRydWUsICcwJywgbnVsbCwgJ0RldGFpbCcpLCBudWxsLCB7fSk7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgncm91dGVyTGluayBkaXJlY3RpdmUnLCBmdW5jdGlvbigpIHtcbiAgICB2YXIgdGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlcjtcblxuICAgIGJlZm9yZUVhY2hQcm92aWRlcnMoKCkgPT4gW1xuICAgICAgcHJvdmlkZShMb2NhdGlvbiwge3VzZVZhbHVlOiBtYWtlRHVtbXlMb2NhdGlvbigpfSksXG4gICAgICBwcm92aWRlKFJvdXRlciwge3VzZVZhbHVlOiBtYWtlRHVtbXlSb3V0ZXIoKX0pXG4gICAgXSk7XG5cbiAgICBiZWZvcmVFYWNoKGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXJdLCAodGNCdWlsZGVyKSA9PiB7IHRjYiA9IHRjQnVpbGRlcjsgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCB1cGRhdGUgYVtocmVmXSBhdHRyaWJ1dGUnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuXG4gICAgICAgICB0Y2IuY3JlYXRlQXN5bmMoVGVzdENvbXBvbmVudClcbiAgICAgICAgICAgICAudGhlbigodGVzdENvbXBvbmVudCkgPT4ge1xuICAgICAgICAgICAgICAgdGVzdENvbXBvbmVudC5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICBsZXQgYW5jaG9yRWxlbWVudCA9XG4gICAgICAgICAgICAgICAgICAgdGVzdENvbXBvbmVudC5kZWJ1Z0VsZW1lbnQucXVlcnkoQnkuY3NzKCdhLmRldGFpbC12aWV3JykpLm5hdGl2ZUVsZW1lbnQ7XG4gICAgICAgICAgICAgICBleHBlY3QoRE9NLmdldEF0dHJpYnV0ZShhbmNob3JFbGVtZW50LCAnaHJlZicpKS50b0VxdWFsKCdkZXRhaWwnKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cblxuICAgIGl0KCdzaG91bGQgY2FsbCByb3V0ZXIubmF2aWdhdGUgd2hlbiBhIGxpbmsgaXMgY2xpY2tlZCcsXG4gICAgICAgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXIsIFJvdXRlcl0sIChhc3luYywgcm91dGVyKSA9PiB7XG5cbiAgICAgICAgIHRjYi5jcmVhdGVBc3luYyhUZXN0Q29tcG9uZW50KVxuICAgICAgICAgICAgIC50aGVuKCh0ZXN0Q29tcG9uZW50KSA9PiB7XG4gICAgICAgICAgICAgICB0ZXN0Q29tcG9uZW50LmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIC8vIFRPRE86IHNob3VsZG4ndCB0aGlzIGJlIGp1c3QgJ2NsaWNrJyByYXRoZXIgdGhhbiAnXmNsaWNrJz9cbiAgICAgICAgICAgICAgIHRlc3RDb21wb25lbnQuZGVidWdFbGVtZW50LnF1ZXJ5KEJ5LmNzcygnYS5kZXRhaWwtdmlldycpKVxuICAgICAgICAgICAgICAgICAgIC50cmlnZ2VyRXZlbnRIYW5kbGVyKCdjbGljaycsIG51bGwpO1xuICAgICAgICAgICAgICAgZXhwZWN0KHJvdXRlci5zcHkoJ25hdmlnYXRlQnlJbnN0cnVjdGlvbicpKS50b0hhdmVCZWVuQ2FsbGVkV2l0aChkdW1teUluc3RydWN0aW9uKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIGNhbGwgcm91dGVyLm5hdmlnYXRlIHdoZW4gYSBsaW5rIGlzIGNsaWNrZWQgaWYgdGFyZ2V0IGlzIF9zZWxmJyxcbiAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlciwgUm91dGVyXSwgKGFzeW5jLCByb3V0ZXIpID0+IHtcblxuICAgICAgICAgdGNiLmNyZWF0ZUFzeW5jKFRlc3RDb21wb25lbnQpXG4gICAgICAgICAgICAgLnRoZW4oKHRlc3RDb21wb25lbnQpID0+IHtcbiAgICAgICAgICAgICAgIHRlc3RDb21wb25lbnQuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgdGVzdENvbXBvbmVudC5kZWJ1Z0VsZW1lbnQucXVlcnkoQnkuY3NzKCdhLmRldGFpbC12aWV3LXNlbGYnKSlcbiAgICAgICAgICAgICAgICAgICAudHJpZ2dlckV2ZW50SGFuZGxlcignY2xpY2snLCBudWxsKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChyb3V0ZXIuc3B5KCduYXZpZ2F0ZUJ5SW5zdHJ1Y3Rpb24nKSkudG9IYXZlQmVlbkNhbGxlZFdpdGgoZHVtbXlJbnN0cnVjdGlvbik7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBOT1QgY2FsbCByb3V0ZXIubmF2aWdhdGUgd2hlbiBhIGxpbmsgaXMgY2xpY2tlZCBpZiB0YXJnZXQgaXMgc2V0IHRvIG90aGVyIHRoYW4gX3NlbGYnLFxuICAgICAgIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyLCBSb3V0ZXJdLCAoYXN5bmMsIHJvdXRlcikgPT4ge1xuXG4gICAgICAgICB0Y2IuY3JlYXRlQXN5bmMoVGVzdENvbXBvbmVudClcbiAgICAgICAgICAgICAudGhlbigodGVzdENvbXBvbmVudCkgPT4ge1xuICAgICAgICAgICAgICAgdGVzdENvbXBvbmVudC5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICB0ZXN0Q29tcG9uZW50LmRlYnVnRWxlbWVudC5xdWVyeShCeS5jc3MoJ2EuZGV0YWlsLXZpZXctYmxhbmsnKSlcbiAgICAgICAgICAgICAgICAgICAudHJpZ2dlckV2ZW50SGFuZGxlcignY2xpY2snLCBudWxsKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChyb3V0ZXIuc3B5KCduYXZpZ2F0ZUJ5SW5zdHJ1Y3Rpb24nKSkubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG4gIH0pO1xufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ3VzZXItY21wJywgdGVtcGxhdGU6IFwiaGVsbG8ge3t1c2VyfX1cIn0pXG5jbGFzcyBVc2VyQ21wIHtcbiAgdXNlcjogc3RyaW5nO1xuICBjb25zdHJ1Y3RvcihwYXJhbXM6IFJvdXRlUGFyYW1zKSB7IHRoaXMudXNlciA9IHBhcmFtcy5nZXQoJ25hbWUnKTsgfVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICd0ZXN0LWNvbXBvbmVudCcsXG4gIHRlbXBsYXRlOiBgXG4gICAgPGRpdj5cbiAgICAgIDxhIFtyb3V0ZXJMaW5rXT1cIlsnL0RldGFpbCddXCJcbiAgICAgICAgIGNsYXNzPVwiZGV0YWlsLXZpZXdcIj5cbiAgICAgICAgICAgZGV0YWlsIHZpZXdcbiAgICAgIDwvYT5cbiAgICAgIDxhIFtyb3V0ZXJMaW5rXT1cIlsnL0RldGFpbCddXCJcbiAgICAgICAgIGNsYXNzPVwiZGV0YWlsLXZpZXctc2VsZlwiXG4gICAgICAgICB0YXJnZXQ9XCJfc2VsZlwiPlxuICAgICAgICAgICBkZXRhaWwgdmlldyB3aXRoIF9zZWxmIHRhcmdldFxuICAgICAgPC9hPlxuICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWycvRGV0YWlsJ11cIlxuICAgICAgICAgY2xhc3M9XCJkZXRhaWwtdmlldy1ibGFua1wiXG4gICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIj5cbiAgICAgICAgICAgZGV0YWlsIHZpZXcgd2l0aCBfYmxhbmsgdGFyZ2V0XG4gICAgICA8L2E+XG4gICAgPC9kaXY+YCxcbiAgZGlyZWN0aXZlczogW1JvdXRlckxpbmtdXG59KVxuY2xhc3MgVGVzdENvbXBvbmVudCB7XG59XG5cbmZ1bmN0aW9uIG1ha2VEdW1teUxvY2F0aW9uKCkge1xuICB2YXIgZGwgPSBuZXcgU3B5TG9jYXRpb24oKTtcbiAgZGwuc3B5KCdwcmVwYXJlRXh0ZXJuYWxVcmwnKS5hbmRDYWxsRmFrZSgodXJsKSA9PiB1cmwpO1xuICByZXR1cm4gZGw7XG59XG5cbmZ1bmN0aW9uIG1ha2VEdW1teVJvdXRlcigpIHtcbiAgdmFyIGRyID0gbmV3IFNweVJvdXRlcigpO1xuICBkci5zcHkoJ2dlbmVyYXRlJykuYW5kQ2FsbEZha2UoKHJvdXRlUGFyYW1zKSA9PiBkdW1teUluc3RydWN0aW9uKTtcbiAgZHIuc3B5KCdpc1JvdXRlQWN0aXZlJykuYW5kQ2FsbEZha2UoKF8pID0+IGZhbHNlKTtcbiAgZHIuc3B5KCduYXZpZ2F0ZUluc3RydWN0aW9uJyk7XG4gIHJldHVybiBkcjtcbn1cbiJdfQ==
 main(); 
