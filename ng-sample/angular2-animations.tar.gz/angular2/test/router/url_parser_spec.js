'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var url_parser_1 = require('angular2/src/router/url_parser');
function main() {
    testing_internal_1.describe('ParsedUrl', function () {
        var urlParser;
        testing_internal_1.beforeEach(function () { urlParser = new url_parser_1.UrlParser(); });
        testing_internal_1.it('should work in a simple case', function () {
            var url = urlParser.parse('hello/there');
            testing_internal_1.expect(url.toString()).toEqual('hello/there');
        });
        testing_internal_1.it('should remove the leading slash', function () {
            var url = urlParser.parse('/hello/there');
            testing_internal_1.expect(url.toString()).toEqual('hello/there');
        });
        testing_internal_1.it('should parse an empty URL', function () {
            var url = urlParser.parse('');
            testing_internal_1.expect(url.toString()).toEqual('');
        });
        testing_internal_1.it('should work with a single aux route', function () {
            var url = urlParser.parse('hello/there(a)');
            testing_internal_1.expect(url.toString()).toEqual('hello/there(a)');
        });
        testing_internal_1.it('should work with multiple aux routes', function () {
            var url = urlParser.parse('hello/there(a//b)');
            testing_internal_1.expect(url.toString()).toEqual('hello/there(a//b)');
        });
        testing_internal_1.it('should work with children after an aux route', function () {
            var url = urlParser.parse('hello/there(a//b)/c/d');
            testing_internal_1.expect(url.toString()).toEqual('hello/there(a//b)/c/d');
        });
        testing_internal_1.it('should work when aux routes have children', function () {
            var url = urlParser.parse('hello(aa/bb//bb/cc)');
            testing_internal_1.expect(url.toString()).toEqual('hello(aa/bb//bb/cc)');
        });
        testing_internal_1.it('should parse an aux route with an aux route', function () {
            var url = urlParser.parse('hello(aa(bb))');
            testing_internal_1.expect(url.toString()).toEqual('hello(aa(bb))');
        });
        testing_internal_1.it('should simplify an empty aux route definition', function () {
            var url = urlParser.parse('hello()/there');
            testing_internal_1.expect(url.toString()).toEqual('hello/there');
        });
        testing_internal_1.it('should parse a key-value matrix param', function () {
            var url = urlParser.parse('hello/friend;name=bob');
            testing_internal_1.expect(url.toString()).toEqual('hello/friend;name=bob');
        });
        testing_internal_1.it('should parse multiple key-value matrix params', function () {
            var url = urlParser.parse('hello/there;greeting=hi;whats=up');
            testing_internal_1.expect(url.toString()).toEqual('hello/there;greeting=hi;whats=up');
        });
        testing_internal_1.it('should ignore matrix params on the first segment', function () {
            var url = urlParser.parse('profile;a=1/hi');
            testing_internal_1.expect(url.toString()).toEqual('profile/hi');
        });
        testing_internal_1.it('should parse a key-only matrix param', function () {
            var url = urlParser.parse('hello/there;hi');
            testing_internal_1.expect(url.toString()).toEqual('hello/there;hi');
        });
        testing_internal_1.it('should parse a URL with just a query param', function () {
            var url = urlParser.parse('?name=bob');
            testing_internal_1.expect(url.toString()).toEqual('?name=bob');
        });
        testing_internal_1.it('should parse a key-value query param', function () {
            var url = urlParser.parse('hello/friend?name=bob');
            testing_internal_1.expect(url.toString()).toEqual('hello/friend?name=bob');
        });
        testing_internal_1.it('should parse multiple key-value query params', function () {
            var url = urlParser.parse('hello/there?greeting=hi&whats=up');
            testing_internal_1.expect(url.params).toEqual({ 'greeting': 'hi', 'whats': 'up' });
            testing_internal_1.expect(url.toString()).toEqual('hello/there?greeting=hi&whats=up');
        });
        testing_internal_1.it('should parse a key-only query param', function () {
            var url = urlParser.parse('hello/there?hi');
            testing_internal_1.expect(url.toString()).toEqual('hello/there?hi');
        });
        testing_internal_1.it('should parse a route with matrix and query params', function () {
            var url = urlParser.parse('hello/there;sort=asc;unfiltered?hi&friend=true');
            testing_internal_1.expect(url.toString()).toEqual('hello/there;sort=asc;unfiltered?hi&friend=true');
        });
        testing_internal_1.it('should parse a route with matrix params and aux routes', function () {
            var url = urlParser.parse('hello/there;sort=asc(modal)');
            testing_internal_1.expect(url.toString()).toEqual('hello/there;sort=asc(modal)');
        });
        testing_internal_1.it('should parse an aux route with matrix params', function () {
            var url = urlParser.parse('hello/there(modal;sort=asc)');
            testing_internal_1.expect(url.toString()).toEqual('hello/there(modal;sort=asc)');
        });
        testing_internal_1.it('should parse a route with matrix params, aux routes, and query params', function () {
            var url = urlParser.parse('hello/there;sort=asc(modal)?friend=true');
            testing_internal_1.expect(url.toString()).toEqual('hello/there;sort=asc(modal)?friend=true');
        });
        testing_internal_1.it('should allow slashes within query parameters', function () {
            var url = urlParser.parse('hello?code=4/B8o0n_Y7XZTb-pVKBw5daZyGAUbMljyLf7uNgTy6ja8&scope=https://www.googleapis.com/auth/analytics');
            testing_internal_1.expect(url.toString())
                .toEqual('hello?code=4/B8o0n_Y7XZTb-pVKBw5daZyGAUbMljyLf7uNgTy6ja8&scope=https://www.googleapis.com/auth/analytics');
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXJsX3BhcnNlcl9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9yb3V0ZXIvdXJsX3BhcnNlcl9zcGVjLnRzIl0sIm5hbWVzIjpbIm1haW4iXSwibWFwcGluZ3MiOiJBQUFBLGlDQVVPLDJCQUEyQixDQUFDLENBQUE7QUFFbkMsMkJBQTZCLGdDQUFnQyxDQUFDLENBQUE7QUFHOUQ7SUFDRUEsMkJBQVFBLENBQUNBLFdBQVdBLEVBQUVBO1FBQ3BCQSxJQUFJQSxTQUFvQkEsQ0FBQ0E7UUFFekJBLDZCQUFVQSxDQUFDQSxjQUFRQSxTQUFTQSxHQUFHQSxJQUFJQSxzQkFBU0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFbkRBLHFCQUFFQSxDQUFDQSw4QkFBOEJBLEVBQUVBO1lBQ2pDQSxJQUFJQSxHQUFHQSxHQUFHQSxTQUFTQSxDQUFDQSxLQUFLQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtZQUN6Q0EseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLFFBQVFBLEVBQUVBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLGFBQWFBLENBQUNBLENBQUNBO1FBQ2hEQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSxxQkFBRUEsQ0FBQ0EsaUNBQWlDQSxFQUFFQTtZQUNwQ0EsSUFBSUEsR0FBR0EsR0FBR0EsU0FBU0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsY0FBY0EsQ0FBQ0EsQ0FBQ0E7WUFDMUNBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxRQUFRQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtRQUNoREEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLDJCQUEyQkEsRUFBRUE7WUFDOUJBLElBQUlBLEdBQUdBLEdBQUdBLFNBQVNBLENBQUNBLEtBQUtBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO1lBQzlCQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7UUFDckNBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLHFCQUFFQSxDQUFDQSxxQ0FBcUNBLEVBQUVBO1lBQ3hDQSxJQUFJQSxHQUFHQSxHQUFHQSxTQUFTQSxDQUFDQSxLQUFLQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBO1lBQzVDQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQTtRQUNuREEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLHNDQUFzQ0EsRUFBRUE7WUFDekNBLElBQUlBLEdBQUdBLEdBQUdBLFNBQVNBLENBQUNBLEtBQUtBLENBQUNBLG1CQUFtQkEsQ0FBQ0EsQ0FBQ0E7WUFDL0NBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxRQUFRQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxtQkFBbUJBLENBQUNBLENBQUNBO1FBQ3REQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSxxQkFBRUEsQ0FBQ0EsOENBQThDQSxFQUFFQTtZQUNqREEsSUFBSUEsR0FBR0EsR0FBR0EsU0FBU0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsdUJBQXVCQSxDQUFDQSxDQUFDQTtZQUNuREEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLFFBQVFBLEVBQUVBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0E7UUFDMURBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLHFCQUFFQSxDQUFDQSwyQ0FBMkNBLEVBQUVBO1lBQzlDQSxJQUFJQSxHQUFHQSxHQUFHQSxTQUFTQSxDQUFDQSxLQUFLQSxDQUFDQSxxQkFBcUJBLENBQUNBLENBQUNBO1lBQ2pEQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQTtRQUN4REEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLDZDQUE2Q0EsRUFBRUE7WUFDaERBLElBQUlBLEdBQUdBLEdBQUdBLFNBQVNBLENBQUNBLEtBQUtBLENBQUNBLGVBQWVBLENBQUNBLENBQUNBO1lBQzNDQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsZUFBZUEsQ0FBQ0EsQ0FBQ0E7UUFDbERBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLHFCQUFFQSxDQUFDQSwrQ0FBK0NBLEVBQUVBO1lBQ2xEQSxJQUFJQSxHQUFHQSxHQUFHQSxTQUFTQSxDQUFDQSxLQUFLQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQTtZQUMzQ0EseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLFFBQVFBLEVBQUVBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLGFBQWFBLENBQUNBLENBQUNBO1FBQ2hEQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSxxQkFBRUEsQ0FBQ0EsdUNBQXVDQSxFQUFFQTtZQUMxQ0EsSUFBSUEsR0FBR0EsR0FBR0EsU0FBU0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsdUJBQXVCQSxDQUFDQSxDQUFDQTtZQUNuREEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLFFBQVFBLEVBQUVBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0E7UUFDMURBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLHFCQUFFQSxDQUFDQSwrQ0FBK0NBLEVBQUVBO1lBQ2xEQSxJQUFJQSxHQUFHQSxHQUFHQSxTQUFTQSxDQUFDQSxLQUFLQSxDQUFDQSxrQ0FBa0NBLENBQUNBLENBQUNBO1lBQzlEQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0Esa0NBQWtDQSxDQUFDQSxDQUFDQTtRQUNyRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLGtEQUFrREEsRUFBRUE7WUFDckRBLElBQUlBLEdBQUdBLEdBQUdBLFNBQVNBLENBQUNBLEtBQUtBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0E7WUFDNUNBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxRQUFRQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQTtRQUMvQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLHNDQUFzQ0EsRUFBRUE7WUFDekNBLElBQUlBLEdBQUdBLEdBQUdBLFNBQVNBLENBQUNBLEtBQUtBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0E7WUFDNUNBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxRQUFRQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBO1FBQ25EQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSxxQkFBRUEsQ0FBQ0EsNENBQTRDQSxFQUFFQTtZQUMvQ0EsSUFBSUEsR0FBR0EsR0FBR0EsU0FBU0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsV0FBV0EsQ0FBQ0EsQ0FBQ0E7WUFDdkNBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxRQUFRQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQTtRQUM5Q0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLHNDQUFzQ0EsRUFBRUE7WUFDekNBLElBQUlBLEdBQUdBLEdBQUdBLFNBQVNBLENBQUNBLEtBQUtBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0E7WUFDbkRBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxRQUFRQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBO1FBQzFEQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSxxQkFBRUEsQ0FBQ0EsOENBQThDQSxFQUFFQTtZQUNqREEsSUFBSUEsR0FBR0EsR0FBR0EsU0FBU0EsQ0FBQ0EsS0FBS0EsQ0FBQ0Esa0NBQWtDQSxDQUFDQSxDQUFDQTtZQUM5REEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEVBQUNBLFVBQVVBLEVBQUVBLElBQUlBLEVBQUVBLE9BQU9BLEVBQUVBLElBQUlBLEVBQUNBLENBQUNBLENBQUNBO1lBQzlEQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0Esa0NBQWtDQSxDQUFDQSxDQUFDQTtRQUNyRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLHFDQUFxQ0EsRUFBRUE7WUFDeENBLElBQUlBLEdBQUdBLEdBQUdBLFNBQVNBLENBQUNBLEtBQUtBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0E7WUFDNUNBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxRQUFRQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBO1FBQ25EQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSxxQkFBRUEsQ0FBQ0EsbURBQW1EQSxFQUFFQTtZQUN0REEsSUFBSUEsR0FBR0EsR0FBR0EsU0FBU0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsZ0RBQWdEQSxDQUFDQSxDQUFDQTtZQUM1RUEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLFFBQVFBLEVBQUVBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLGdEQUFnREEsQ0FBQ0EsQ0FBQ0E7UUFDbkZBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLHFCQUFFQSxDQUFDQSx3REFBd0RBLEVBQUVBO1lBQzNEQSxJQUFJQSxHQUFHQSxHQUFHQSxTQUFTQSxDQUFDQSxLQUFLQSxDQUFDQSw2QkFBNkJBLENBQUNBLENBQUNBO1lBQ3pEQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsNkJBQTZCQSxDQUFDQSxDQUFDQTtRQUNoRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLDhDQUE4Q0EsRUFBRUE7WUFDakRBLElBQUlBLEdBQUdBLEdBQUdBLFNBQVNBLENBQUNBLEtBQUtBLENBQUNBLDZCQUE2QkEsQ0FBQ0EsQ0FBQ0E7WUFDekRBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxRQUFRQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSw2QkFBNkJBLENBQUNBLENBQUNBO1FBQ2hFQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSxxQkFBRUEsQ0FBQ0EsdUVBQXVFQSxFQUFFQTtZQUMxRUEsSUFBSUEsR0FBR0EsR0FBR0EsU0FBU0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EseUNBQXlDQSxDQUFDQSxDQUFDQTtZQUNyRUEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLFFBQVFBLEVBQUVBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLHlDQUF5Q0EsQ0FBQ0EsQ0FBQ0E7UUFDNUVBLENBQUNBLENBQUNBLENBQUNBO1FBQ0hBLHFCQUFFQSxDQUFDQSw4Q0FBOENBLEVBQUVBO1lBQ2pEQSxJQUFJQSxHQUFHQSxHQUFHQSxTQUFTQSxDQUFDQSxLQUFLQSxDQUNyQkEsMEdBQTBHQSxDQUFDQSxDQUFDQTtZQUNoSEEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLFFBQVFBLEVBQUVBLENBQUNBO2lCQUNqQkEsT0FBT0EsQ0FDSkEsMEdBQTBHQSxDQUFDQSxDQUFDQTtRQUN0SEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7QUFDTEEsQ0FBQ0E7QUF2SGUsWUFBSSxPQXVIbkIsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFzeW5jVGVzdENvbXBsZXRlcixcbiAgZGVzY3JpYmUsXG4gIGl0LFxuICBpaXQsXG4gIGRkZXNjcmliZSxcbiAgZXhwZWN0LFxuICBpbmplY3QsXG4gIGJlZm9yZUVhY2gsXG4gIFNweU9iamVjdFxufSBmcm9tICdhbmd1bGFyMi90ZXN0aW5nX2ludGVybmFsJztcblxuaW1wb3J0IHtVcmxQYXJzZXIsIFVybH0gZnJvbSAnYW5ndWxhcjIvc3JjL3JvdXRlci91cmxfcGFyc2VyJztcblxuXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpIHtcbiAgZGVzY3JpYmUoJ1BhcnNlZFVybCcsICgpID0+IHtcbiAgICB2YXIgdXJsUGFyc2VyOiBVcmxQYXJzZXI7XG5cbiAgICBiZWZvcmVFYWNoKCgpID0+IHsgdXJsUGFyc2VyID0gbmV3IFVybFBhcnNlcigpOyB9KTtcblxuICAgIGl0KCdzaG91bGQgd29yayBpbiBhIHNpbXBsZSBjYXNlJywgKCkgPT4ge1xuICAgICAgdmFyIHVybCA9IHVybFBhcnNlci5wYXJzZSgnaGVsbG8vdGhlcmUnKTtcbiAgICAgIGV4cGVjdCh1cmwudG9TdHJpbmcoKSkudG9FcXVhbCgnaGVsbG8vdGhlcmUnKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgcmVtb3ZlIHRoZSBsZWFkaW5nIHNsYXNoJywgKCkgPT4ge1xuICAgICAgdmFyIHVybCA9IHVybFBhcnNlci5wYXJzZSgnL2hlbGxvL3RoZXJlJyk7XG4gICAgICBleHBlY3QodXJsLnRvU3RyaW5nKCkpLnRvRXF1YWwoJ2hlbGxvL3RoZXJlJyk7XG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIHBhcnNlIGFuIGVtcHR5IFVSTCcsICgpID0+IHtcbiAgICAgIHZhciB1cmwgPSB1cmxQYXJzZXIucGFyc2UoJycpO1xuICAgICAgZXhwZWN0KHVybC50b1N0cmluZygpKS50b0VxdWFsKCcnKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgd29yayB3aXRoIGEgc2luZ2xlIGF1eCByb3V0ZScsICgpID0+IHtcbiAgICAgIHZhciB1cmwgPSB1cmxQYXJzZXIucGFyc2UoJ2hlbGxvL3RoZXJlKGEpJyk7XG4gICAgICBleHBlY3QodXJsLnRvU3RyaW5nKCkpLnRvRXF1YWwoJ2hlbGxvL3RoZXJlKGEpJyk7XG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIHdvcmsgd2l0aCBtdWx0aXBsZSBhdXggcm91dGVzJywgKCkgPT4ge1xuICAgICAgdmFyIHVybCA9IHVybFBhcnNlci5wYXJzZSgnaGVsbG8vdGhlcmUoYS8vYiknKTtcbiAgICAgIGV4cGVjdCh1cmwudG9TdHJpbmcoKSkudG9FcXVhbCgnaGVsbG8vdGhlcmUoYS8vYiknKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgd29yayB3aXRoIGNoaWxkcmVuIGFmdGVyIGFuIGF1eCByb3V0ZScsICgpID0+IHtcbiAgICAgIHZhciB1cmwgPSB1cmxQYXJzZXIucGFyc2UoJ2hlbGxvL3RoZXJlKGEvL2IpL2MvZCcpO1xuICAgICAgZXhwZWN0KHVybC50b1N0cmluZygpKS50b0VxdWFsKCdoZWxsby90aGVyZShhLy9iKS9jL2QnKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgd29yayB3aGVuIGF1eCByb3V0ZXMgaGF2ZSBjaGlsZHJlbicsICgpID0+IHtcbiAgICAgIHZhciB1cmwgPSB1cmxQYXJzZXIucGFyc2UoJ2hlbGxvKGFhL2JiLy9iYi9jYyknKTtcbiAgICAgIGV4cGVjdCh1cmwudG9TdHJpbmcoKSkudG9FcXVhbCgnaGVsbG8oYWEvYmIvL2JiL2NjKScpO1xuICAgIH0pO1xuXG4gICAgaXQoJ3Nob3VsZCBwYXJzZSBhbiBhdXggcm91dGUgd2l0aCBhbiBhdXggcm91dGUnLCAoKSA9PiB7XG4gICAgICB2YXIgdXJsID0gdXJsUGFyc2VyLnBhcnNlKCdoZWxsbyhhYShiYikpJyk7XG4gICAgICBleHBlY3QodXJsLnRvU3RyaW5nKCkpLnRvRXF1YWwoJ2hlbGxvKGFhKGJiKSknKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgc2ltcGxpZnkgYW4gZW1wdHkgYXV4IHJvdXRlIGRlZmluaXRpb24nLCAoKSA9PiB7XG4gICAgICB2YXIgdXJsID0gdXJsUGFyc2VyLnBhcnNlKCdoZWxsbygpL3RoZXJlJyk7XG4gICAgICBleHBlY3QodXJsLnRvU3RyaW5nKCkpLnRvRXF1YWwoJ2hlbGxvL3RoZXJlJyk7XG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIHBhcnNlIGEga2V5LXZhbHVlIG1hdHJpeCBwYXJhbScsICgpID0+IHtcbiAgICAgIHZhciB1cmwgPSB1cmxQYXJzZXIucGFyc2UoJ2hlbGxvL2ZyaWVuZDtuYW1lPWJvYicpO1xuICAgICAgZXhwZWN0KHVybC50b1N0cmluZygpKS50b0VxdWFsKCdoZWxsby9mcmllbmQ7bmFtZT1ib2InKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgcGFyc2UgbXVsdGlwbGUga2V5LXZhbHVlIG1hdHJpeCBwYXJhbXMnLCAoKSA9PiB7XG4gICAgICB2YXIgdXJsID0gdXJsUGFyc2VyLnBhcnNlKCdoZWxsby90aGVyZTtncmVldGluZz1oaTt3aGF0cz11cCcpO1xuICAgICAgZXhwZWN0KHVybC50b1N0cmluZygpKS50b0VxdWFsKCdoZWxsby90aGVyZTtncmVldGluZz1oaTt3aGF0cz11cCcpO1xuICAgIH0pO1xuXG4gICAgaXQoJ3Nob3VsZCBpZ25vcmUgbWF0cml4IHBhcmFtcyBvbiB0aGUgZmlyc3Qgc2VnbWVudCcsICgpID0+IHtcbiAgICAgIHZhciB1cmwgPSB1cmxQYXJzZXIucGFyc2UoJ3Byb2ZpbGU7YT0xL2hpJyk7XG4gICAgICBleHBlY3QodXJsLnRvU3RyaW5nKCkpLnRvRXF1YWwoJ3Byb2ZpbGUvaGknKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgcGFyc2UgYSBrZXktb25seSBtYXRyaXggcGFyYW0nLCAoKSA9PiB7XG4gICAgICB2YXIgdXJsID0gdXJsUGFyc2VyLnBhcnNlKCdoZWxsby90aGVyZTtoaScpO1xuICAgICAgZXhwZWN0KHVybC50b1N0cmluZygpKS50b0VxdWFsKCdoZWxsby90aGVyZTtoaScpO1xuICAgIH0pO1xuXG4gICAgaXQoJ3Nob3VsZCBwYXJzZSBhIFVSTCB3aXRoIGp1c3QgYSBxdWVyeSBwYXJhbScsICgpID0+IHtcbiAgICAgIHZhciB1cmwgPSB1cmxQYXJzZXIucGFyc2UoJz9uYW1lPWJvYicpO1xuICAgICAgZXhwZWN0KHVybC50b1N0cmluZygpKS50b0VxdWFsKCc/bmFtZT1ib2InKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgcGFyc2UgYSBrZXktdmFsdWUgcXVlcnkgcGFyYW0nLCAoKSA9PiB7XG4gICAgICB2YXIgdXJsID0gdXJsUGFyc2VyLnBhcnNlKCdoZWxsby9mcmllbmQ/bmFtZT1ib2InKTtcbiAgICAgIGV4cGVjdCh1cmwudG9TdHJpbmcoKSkudG9FcXVhbCgnaGVsbG8vZnJpZW5kP25hbWU9Ym9iJyk7XG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIHBhcnNlIG11bHRpcGxlIGtleS12YWx1ZSBxdWVyeSBwYXJhbXMnLCAoKSA9PiB7XG4gICAgICB2YXIgdXJsID0gdXJsUGFyc2VyLnBhcnNlKCdoZWxsby90aGVyZT9ncmVldGluZz1oaSZ3aGF0cz11cCcpO1xuICAgICAgZXhwZWN0KHVybC5wYXJhbXMpLnRvRXF1YWwoeydncmVldGluZyc6ICdoaScsICd3aGF0cyc6ICd1cCd9KTtcbiAgICAgIGV4cGVjdCh1cmwudG9TdHJpbmcoKSkudG9FcXVhbCgnaGVsbG8vdGhlcmU/Z3JlZXRpbmc9aGkmd2hhdHM9dXAnKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgcGFyc2UgYSBrZXktb25seSBxdWVyeSBwYXJhbScsICgpID0+IHtcbiAgICAgIHZhciB1cmwgPSB1cmxQYXJzZXIucGFyc2UoJ2hlbGxvL3RoZXJlP2hpJyk7XG4gICAgICBleHBlY3QodXJsLnRvU3RyaW5nKCkpLnRvRXF1YWwoJ2hlbGxvL3RoZXJlP2hpJyk7XG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIHBhcnNlIGEgcm91dGUgd2l0aCBtYXRyaXggYW5kIHF1ZXJ5IHBhcmFtcycsICgpID0+IHtcbiAgICAgIHZhciB1cmwgPSB1cmxQYXJzZXIucGFyc2UoJ2hlbGxvL3RoZXJlO3NvcnQ9YXNjO3VuZmlsdGVyZWQ/aGkmZnJpZW5kPXRydWUnKTtcbiAgICAgIGV4cGVjdCh1cmwudG9TdHJpbmcoKSkudG9FcXVhbCgnaGVsbG8vdGhlcmU7c29ydD1hc2M7dW5maWx0ZXJlZD9oaSZmcmllbmQ9dHJ1ZScpO1xuICAgIH0pO1xuXG4gICAgaXQoJ3Nob3VsZCBwYXJzZSBhIHJvdXRlIHdpdGggbWF0cml4IHBhcmFtcyBhbmQgYXV4IHJvdXRlcycsICgpID0+IHtcbiAgICAgIHZhciB1cmwgPSB1cmxQYXJzZXIucGFyc2UoJ2hlbGxvL3RoZXJlO3NvcnQ9YXNjKG1vZGFsKScpO1xuICAgICAgZXhwZWN0KHVybC50b1N0cmluZygpKS50b0VxdWFsKCdoZWxsby90aGVyZTtzb3J0PWFzYyhtb2RhbCknKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgcGFyc2UgYW4gYXV4IHJvdXRlIHdpdGggbWF0cml4IHBhcmFtcycsICgpID0+IHtcbiAgICAgIHZhciB1cmwgPSB1cmxQYXJzZXIucGFyc2UoJ2hlbGxvL3RoZXJlKG1vZGFsO3NvcnQ9YXNjKScpO1xuICAgICAgZXhwZWN0KHVybC50b1N0cmluZygpKS50b0VxdWFsKCdoZWxsby90aGVyZShtb2RhbDtzb3J0PWFzYyknKTtcbiAgICB9KTtcblxuICAgIGl0KCdzaG91bGQgcGFyc2UgYSByb3V0ZSB3aXRoIG1hdHJpeCBwYXJhbXMsIGF1eCByb3V0ZXMsIGFuZCBxdWVyeSBwYXJhbXMnLCAoKSA9PiB7XG4gICAgICB2YXIgdXJsID0gdXJsUGFyc2VyLnBhcnNlKCdoZWxsby90aGVyZTtzb3J0PWFzYyhtb2RhbCk/ZnJpZW5kPXRydWUnKTtcbiAgICAgIGV4cGVjdCh1cmwudG9TdHJpbmcoKSkudG9FcXVhbCgnaGVsbG8vdGhlcmU7c29ydD1hc2MobW9kYWwpP2ZyaWVuZD10cnVlJyk7XG4gICAgfSk7XG4gICAgaXQoJ3Nob3VsZCBhbGxvdyBzbGFzaGVzIHdpdGhpbiBxdWVyeSBwYXJhbWV0ZXJzJywgKCkgPT4ge1xuICAgICAgdmFyIHVybCA9IHVybFBhcnNlci5wYXJzZShcbiAgICAgICAgICAnaGVsbG8/Y29kZT00L0I4bzBuX1k3WFpUYi1wVktCdzVkYVp5R0FVYk1sanlMZjd1TmdUeTZqYTgmc2NvcGU9aHR0cHM6Ly93d3cuZ29vZ2xlYXBpcy5jb20vYXV0aC9hbmFseXRpY3MnKTtcbiAgICAgIGV4cGVjdCh1cmwudG9TdHJpbmcoKSlcbiAgICAgICAgICAudG9FcXVhbChcbiAgICAgICAgICAgICAgJ2hlbGxvP2NvZGU9NC9COG8wbl9ZN1haVGItcFZLQnc1ZGFaeUdBVWJNbGp5TGY3dU5nVHk2amE4JnNjb3BlPWh0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL2F1dGgvYW5hbHl0aWNzJyk7XG4gICAgfSk7XG4gIH0pO1xufVxuIl19
 main(); 
