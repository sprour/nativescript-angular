'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var core_1 = require('angular2/core');
var lang_1 = require('angular2/src/facade/lang');
var location_1 = require('angular2/src/router/location/location');
var location_strategy_1 = require('angular2/src/router/location/location_strategy');
var mock_location_strategy_1 = require('angular2/src/mock/mock_location_strategy');
function main() {
    testing_internal_1.describe('Location', function () {
        var locationStrategy, location;
        function makeLocation(baseHref, provider) {
            if (baseHref === void 0) { baseHref = '/my/app'; }
            if (provider === void 0) { provider = lang_1.CONST_EXPR([]); }
            locationStrategy = new mock_location_strategy_1.MockLocationStrategy();
            locationStrategy.internalBaseHref = baseHref;
            var injector = core_1.Injector.resolveAndCreate([location_1.Location, core_1.provide(location_strategy_1.LocationStrategy, { useValue: locationStrategy }), provider]);
            return location = injector.get(location_1.Location);
        }
        testing_internal_1.beforeEach(makeLocation);
        testing_internal_1.it('should not prepend urls with starting slash when an empty URL is provided', function () { testing_internal_1.expect(location.prepareExternalUrl('')).toEqual(locationStrategy.getBaseHref()); });
        testing_internal_1.it('should not prepend path with an extra slash when a baseHref has a trailing slash', function () {
            var location = makeLocation('/my/slashed/app/');
            testing_internal_1.expect(location.prepareExternalUrl('/page')).toEqual('/my/slashed/app/page');
        });
        testing_internal_1.it('should not append urls with leading slash on navigate', function () {
            location.go('/my/app/user/btford');
            testing_internal_1.expect(locationStrategy.path()).toEqual('/my/app/user/btford');
        });
        testing_internal_1.it('should normalize urls on popstate', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            locationStrategy.simulatePopState('/my/app/user/btford');
            location.subscribe(function (ev) {
                testing_internal_1.expect(ev['url']).toEqual('/user/btford');
                async.done();
            });
        }));
        testing_internal_1.it('should revert to the previous path when a back() operation is executed', function () {
            var locationStrategy = new mock_location_strategy_1.MockLocationStrategy();
            var location = new location_1.Location(locationStrategy);
            function assertUrl(path) { testing_internal_1.expect(location.path()).toEqual(path); }
            location.go('/ready');
            assertUrl('/ready');
            location.go('/ready/set');
            assertUrl('/ready/set');
            location.go('/ready/set/go');
            assertUrl('/ready/set/go');
            location.back();
            assertUrl('/ready/set');
            location.back();
            assertUrl('/ready');
        });
        testing_internal_1.it('should incorporate the provided query values into the location change', function () {
            var locationStrategy = new mock_location_strategy_1.MockLocationStrategy();
            var location = new location_1.Location(locationStrategy);
            location.go('/home', "key=value");
            testing_internal_1.expect(location.path()).toEqual("/home?key=value");
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9jYXRpb25fc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3Qvcm91dGVyL2xvY2F0aW9uL2xvY2F0aW9uX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiIsIm1haW4ubWFrZUxvY2F0aW9uIiwibWFpbi5hc3NlcnRVcmwiXSwibWFwcGluZ3MiOiJBQUFBLGlDQVlPLDJCQUEyQixDQUFDLENBQUE7QUFFbkMscUJBQWdDLGVBQWUsQ0FBQyxDQUFBO0FBQ2hELHFCQUF5QiwwQkFBMEIsQ0FBQyxDQUFBO0FBRXBELHlCQUF1Qix1Q0FBdUMsQ0FBQyxDQUFBO0FBQy9ELGtDQUE4QyxnREFBZ0QsQ0FBQyxDQUFBO0FBQy9GLHVDQUFtQywwQ0FBMEMsQ0FBQyxDQUFBO0FBRTlFO0lBQ0VBLDJCQUFRQSxDQUFDQSxVQUFVQSxFQUFFQTtRQUVuQkEsSUFBSUEsZ0JBQWdCQSxFQUFFQSxRQUFRQSxDQUFDQTtRQUUvQkEsc0JBQXNCQSxRQUE0QkEsRUFBRUEsUUFBOEJBO1lBQTVEQyx3QkFBNEJBLEdBQTVCQSxvQkFBNEJBO1lBQUVBLHdCQUE4QkEsR0FBOUJBLFdBQWdCQSxpQkFBVUEsQ0FBQ0EsRUFBRUEsQ0FBQ0E7WUFDaEZBLGdCQUFnQkEsR0FBR0EsSUFBSUEsNkNBQW9CQSxFQUFFQSxDQUFDQTtZQUM5Q0EsZ0JBQWdCQSxDQUFDQSxnQkFBZ0JBLEdBQUdBLFFBQVFBLENBQUNBO1lBQzdDQSxJQUFJQSxRQUFRQSxHQUFHQSxlQUFRQSxDQUFDQSxnQkFBZ0JBLENBQ3BDQSxDQUFDQSxtQkFBUUEsRUFBRUEsY0FBT0EsQ0FBQ0Esb0NBQWdCQSxFQUFFQSxFQUFDQSxRQUFRQSxFQUFFQSxnQkFBZ0JBLEVBQUNBLENBQUNBLEVBQUVBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBO1lBQ25GQSxNQUFNQSxDQUFDQSxRQUFRQSxHQUFHQSxRQUFRQSxDQUFDQSxHQUFHQSxDQUFDQSxtQkFBUUEsQ0FBQ0EsQ0FBQ0E7UUFDM0NBLENBQUNBO1FBRURELDZCQUFVQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQTtRQUV6QkEscUJBQUVBLENBQUNBLDJFQUEyRUEsRUFDM0VBLGNBQVFBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxrQkFBa0JBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLGdCQUFnQkEsQ0FBQ0EsV0FBV0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFL0ZBLHFCQUFFQSxDQUFDQSxrRkFBa0ZBLEVBQUVBO1lBQ3JGQSxJQUFJQSxRQUFRQSxHQUFHQSxZQUFZQSxDQUFDQSxrQkFBa0JBLENBQUNBLENBQUNBO1lBQ2hEQSx5QkFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxzQkFBc0JBLENBQUNBLENBQUNBO1FBQy9FQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSxxQkFBRUEsQ0FBQ0EsdURBQXVEQSxFQUFFQTtZQUMxREEsUUFBUUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQTtZQUNuQ0EseUJBQU1BLENBQUNBLGdCQUFnQkEsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQTtRQUNqRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEscUJBQUVBLENBQUNBLG1DQUFtQ0EsRUFBRUEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7WUFDdEVBLGdCQUFnQkEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxxQkFBcUJBLENBQUNBLENBQUNBO1lBQ3pEQSxRQUFRQSxDQUFDQSxTQUFTQSxDQUFDQSxVQUFDQSxFQUFFQTtnQkFDcEJBLHlCQUFNQSxDQUFDQSxFQUFFQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQTtnQkFDMUNBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUFBO1FBQ0pBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLHFCQUFFQSxDQUFDQSx3RUFBd0VBLEVBQUVBO1lBQzNFQSxJQUFJQSxnQkFBZ0JBLEdBQUdBLElBQUlBLDZDQUFvQkEsRUFBRUEsQ0FBQ0E7WUFDbERBLElBQUlBLFFBQVFBLEdBQUdBLElBQUlBLG1CQUFRQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBO1lBRTlDQSxtQkFBbUJBLElBQUlBLElBQUlFLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVuRUYsUUFBUUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0E7WUFDdEJBLFNBQVNBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBO1lBRXBCQSxRQUFRQSxDQUFDQSxFQUFFQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQTtZQUMxQkEsU0FBU0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0E7WUFFeEJBLFFBQVFBLENBQUNBLEVBQUVBLENBQUNBLGVBQWVBLENBQUNBLENBQUNBO1lBQzdCQSxTQUFTQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQTtZQUUzQkEsUUFBUUEsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7WUFDaEJBLFNBQVNBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBO1lBRXhCQSxRQUFRQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtZQUNoQkEsU0FBU0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0E7UUFDdEJBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLHFCQUFFQSxDQUFDQSx1RUFBdUVBLEVBQUVBO1lBQzFFQSxJQUFJQSxnQkFBZ0JBLEdBQUdBLElBQUlBLDZDQUFvQkEsRUFBRUEsQ0FBQ0E7WUFDbERBLElBQUlBLFFBQVFBLEdBQUdBLElBQUlBLG1CQUFRQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBO1lBRTlDQSxRQUFRQSxDQUFDQSxFQUFFQSxDQUFDQSxPQUFPQSxFQUFFQSxXQUFXQSxDQUFDQSxDQUFDQTtZQUNsQ0EseUJBQU1BLENBQUNBLFFBQVFBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0E7UUFDckRBLENBQUNBLENBQUNBLENBQUNBO0lBQ0xBLENBQUNBLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBbEVlLFlBQUksT0FrRW5CLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBc3luY1Rlc3RDb21wbGV0ZXIsXG4gIGRlc2NyaWJlLFxuICBwcm94eSxcbiAgaXQsXG4gIGlpdCxcbiAgZGRlc2NyaWJlLFxuICBleHBlY3QsXG4gIGluamVjdCxcbiAgYmVmb3JlRWFjaCxcbiAgYmVmb3JlRWFjaFByb3ZpZGVycyxcbiAgU3B5T2JqZWN0XG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5pbXBvcnQge0luamVjdG9yLCBwcm92aWRlfSBmcm9tICdhbmd1bGFyMi9jb3JlJztcbmltcG9ydCB7Q09OU1RfRVhQUn0gZnJvbSAnYW5ndWxhcjIvc3JjL2ZhY2FkZS9sYW5nJztcblxuaW1wb3J0IHtMb2NhdGlvbn0gZnJvbSAnYW5ndWxhcjIvc3JjL3JvdXRlci9sb2NhdGlvbi9sb2NhdGlvbic7XG5pbXBvcnQge0xvY2F0aW9uU3RyYXRlZ3ksIEFQUF9CQVNFX0hSRUZ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9yb3V0ZXIvbG9jYXRpb24vbG9jYXRpb25fc3RyYXRlZ3knO1xuaW1wb3J0IHtNb2NrTG9jYXRpb25TdHJhdGVneX0gZnJvbSAnYW5ndWxhcjIvc3JjL21vY2svbW9ja19sb2NhdGlvbl9zdHJhdGVneSc7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgnTG9jYXRpb24nLCAoKSA9PiB7XG5cbiAgICB2YXIgbG9jYXRpb25TdHJhdGVneSwgbG9jYXRpb247XG5cbiAgICBmdW5jdGlvbiBtYWtlTG9jYXRpb24oYmFzZUhyZWY6IHN0cmluZyA9ICcvbXkvYXBwJywgcHJvdmlkZXI6IGFueSA9IENPTlNUX0VYUFIoW10pKTogTG9jYXRpb24ge1xuICAgICAgbG9jYXRpb25TdHJhdGVneSA9IG5ldyBNb2NrTG9jYXRpb25TdHJhdGVneSgpO1xuICAgICAgbG9jYXRpb25TdHJhdGVneS5pbnRlcm5hbEJhc2VIcmVmID0gYmFzZUhyZWY7XG4gICAgICBsZXQgaW5qZWN0b3IgPSBJbmplY3Rvci5yZXNvbHZlQW5kQ3JlYXRlKFxuICAgICAgICAgIFtMb2NhdGlvbiwgcHJvdmlkZShMb2NhdGlvblN0cmF0ZWd5LCB7dXNlVmFsdWU6IGxvY2F0aW9uU3RyYXRlZ3l9KSwgcHJvdmlkZXJdKTtcbiAgICAgIHJldHVybiBsb2NhdGlvbiA9IGluamVjdG9yLmdldChMb2NhdGlvbik7XG4gICAgfVxuXG4gICAgYmVmb3JlRWFjaChtYWtlTG9jYXRpb24pO1xuXG4gICAgaXQoJ3Nob3VsZCBub3QgcHJlcGVuZCB1cmxzIHdpdGggc3RhcnRpbmcgc2xhc2ggd2hlbiBhbiBlbXB0eSBVUkwgaXMgcHJvdmlkZWQnLFxuICAgICAgICgpID0+IHsgZXhwZWN0KGxvY2F0aW9uLnByZXBhcmVFeHRlcm5hbFVybCgnJykpLnRvRXF1YWwobG9jYXRpb25TdHJhdGVneS5nZXRCYXNlSHJlZigpKTsgfSk7XG5cbiAgICBpdCgnc2hvdWxkIG5vdCBwcmVwZW5kIHBhdGggd2l0aCBhbiBleHRyYSBzbGFzaCB3aGVuIGEgYmFzZUhyZWYgaGFzIGEgdHJhaWxpbmcgc2xhc2gnLCAoKSA9PiB7XG4gICAgICBsZXQgbG9jYXRpb24gPSBtYWtlTG9jYXRpb24oJy9teS9zbGFzaGVkL2FwcC8nKTtcbiAgICAgIGV4cGVjdChsb2NhdGlvbi5wcmVwYXJlRXh0ZXJuYWxVcmwoJy9wYWdlJykpLnRvRXF1YWwoJy9teS9zbGFzaGVkL2FwcC9wYWdlJyk7XG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIG5vdCBhcHBlbmQgdXJscyB3aXRoIGxlYWRpbmcgc2xhc2ggb24gbmF2aWdhdGUnLCAoKSA9PiB7XG4gICAgICBsb2NhdGlvbi5nbygnL215L2FwcC91c2VyL2J0Zm9yZCcpO1xuICAgICAgZXhwZWN0KGxvY2F0aW9uU3RyYXRlZ3kucGF0aCgpKS50b0VxdWFsKCcvbXkvYXBwL3VzZXIvYnRmb3JkJyk7XG4gICAgfSk7XG5cbiAgICBpdCgnc2hvdWxkIG5vcm1hbGl6ZSB1cmxzIG9uIHBvcHN0YXRlJywgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgIGxvY2F0aW9uU3RyYXRlZ3kuc2ltdWxhdGVQb3BTdGF0ZSgnL215L2FwcC91c2VyL2J0Zm9yZCcpO1xuICAgICAgICAgbG9jYXRpb24uc3Vic2NyaWJlKChldikgPT4ge1xuICAgICAgICAgICBleHBlY3QoZXZbJ3VybCddKS50b0VxdWFsKCcvdXNlci9idGZvcmQnKTtcbiAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgfSlcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIHJldmVydCB0byB0aGUgcHJldmlvdXMgcGF0aCB3aGVuIGEgYmFjaygpIG9wZXJhdGlvbiBpcyBleGVjdXRlZCcsICgpID0+IHtcbiAgICAgIHZhciBsb2NhdGlvblN0cmF0ZWd5ID0gbmV3IE1vY2tMb2NhdGlvblN0cmF0ZWd5KCk7XG4gICAgICB2YXIgbG9jYXRpb24gPSBuZXcgTG9jYXRpb24obG9jYXRpb25TdHJhdGVneSk7XG5cbiAgICAgIGZ1bmN0aW9uIGFzc2VydFVybChwYXRoKSB7IGV4cGVjdChsb2NhdGlvbi5wYXRoKCkpLnRvRXF1YWwocGF0aCk7IH1cblxuICAgICAgbG9jYXRpb24uZ28oJy9yZWFkeScpO1xuICAgICAgYXNzZXJ0VXJsKCcvcmVhZHknKTtcblxuICAgICAgbG9jYXRpb24uZ28oJy9yZWFkeS9zZXQnKTtcbiAgICAgIGFzc2VydFVybCgnL3JlYWR5L3NldCcpO1xuXG4gICAgICBsb2NhdGlvbi5nbygnL3JlYWR5L3NldC9nbycpO1xuICAgICAgYXNzZXJ0VXJsKCcvcmVhZHkvc2V0L2dvJyk7XG5cbiAgICAgIGxvY2F0aW9uLmJhY2soKTtcbiAgICAgIGFzc2VydFVybCgnL3JlYWR5L3NldCcpO1xuXG4gICAgICBsb2NhdGlvbi5iYWNrKCk7XG4gICAgICBhc3NlcnRVcmwoJy9yZWFkeScpO1xuICAgIH0pO1xuXG4gICAgaXQoJ3Nob3VsZCBpbmNvcnBvcmF0ZSB0aGUgcHJvdmlkZWQgcXVlcnkgdmFsdWVzIGludG8gdGhlIGxvY2F0aW9uIGNoYW5nZScsICgpID0+IHtcbiAgICAgIHZhciBsb2NhdGlvblN0cmF0ZWd5ID0gbmV3IE1vY2tMb2NhdGlvblN0cmF0ZWd5KCk7XG4gICAgICB2YXIgbG9jYXRpb24gPSBuZXcgTG9jYXRpb24obG9jYXRpb25TdHJhdGVneSk7XG5cbiAgICAgIGxvY2F0aW9uLmdvKCcvaG9tZScsIFwia2V5PXZhbHVlXCIpO1xuICAgICAgZXhwZWN0KGxvY2F0aW9uLnBhdGgoKSkudG9FcXVhbChcIi9ob21lP2tleT12YWx1ZVwiKTtcbiAgICB9KTtcbiAgfSk7XG59XG4iXX0=
 main(); 
