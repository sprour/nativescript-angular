'use strict';var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var router_1 = require('angular2/router');
var testing_internal_1 = require('angular2/testing_internal');
var SpyRouter = (function (_super) {
    __extends(SpyRouter, _super);
    function SpyRouter() {
        _super.call(this, router_1.Router);
    }
    return SpyRouter;
})(testing_internal_1.SpyObject);
exports.SpyRouter = SpyRouter;
var SpyRouterOutlet = (function (_super) {
    __extends(SpyRouterOutlet, _super);
    function SpyRouterOutlet() {
        _super.call(this, router_1.RouterOutlet);
    }
    return SpyRouterOutlet;
})(testing_internal_1.SpyObject);
exports.SpyRouterOutlet = SpyRouterOutlet;
var SpyLocation = (function (_super) {
    __extends(SpyLocation, _super);
    function SpyLocation() {
        _super.call(this, router_1.Location);
    }
    return SpyLocation;
})(testing_internal_1.SpyObject);
exports.SpyLocation = SpyLocation;
var SpyPlatformLocation = (function (_super) {
    __extends(SpyPlatformLocation, _super);
    function SpyPlatformLocation() {
        _super.call(this, SpyPlatformLocation);
        this.pathname = null;
        this.search = null;
        this.hash = null;
    }
    return SpyPlatformLocation;
})(testing_internal_1.SpyObject);
exports.SpyPlatformLocation = SpyPlatformLocation;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3BpZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L3JvdXRlci9zcGllcy50cyJdLCJuYW1lcyI6WyJTcHlSb3V0ZXIiLCJTcHlSb3V0ZXIuY29uc3RydWN0b3IiLCJTcHlSb3V0ZXJPdXRsZXQiLCJTcHlSb3V0ZXJPdXRsZXQuY29uc3RydWN0b3IiLCJTcHlMb2NhdGlvbiIsIlNweUxvY2F0aW9uLmNvbnN0cnVjdG9yIiwiU3B5UGxhdGZvcm1Mb2NhdGlvbiIsIlNweVBsYXRmb3JtTG9jYXRpb24uY29uc3RydWN0b3IiXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsdUJBQStELGlCQUFpQixDQUFDLENBQUE7QUFDakYsaUNBQStCLDJCQUEyQixDQUFDLENBQUE7QUFFM0Q7SUFBK0JBLDZCQUFTQTtJQUN0Q0E7UUFBZ0JDLGtCQUFNQSxlQUFNQSxDQUFDQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUNsQ0QsZ0JBQUNBO0FBQURBLENBQUNBLEFBRkQsRUFBK0IsNEJBQVMsRUFFdkM7QUFGWSxpQkFBUyxZQUVyQixDQUFBO0FBRUQ7SUFBcUNFLG1DQUFTQTtJQUM1Q0E7UUFBZ0JDLGtCQUFNQSxxQkFBWUEsQ0FBQ0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFDeENELHNCQUFDQTtBQUFEQSxDQUFDQSxBQUZELEVBQXFDLDRCQUFTLEVBRTdDO0FBRlksdUJBQWUsa0JBRTNCLENBQUE7QUFFRDtJQUFpQ0UsK0JBQVNBO0lBQ3hDQTtRQUFnQkMsa0JBQU1BLGlCQUFRQSxDQUFDQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUNwQ0Qsa0JBQUNBO0FBQURBLENBQUNBLEFBRkQsRUFBaUMsNEJBQVMsRUFFekM7QUFGWSxtQkFBVyxjQUV2QixDQUFBO0FBRUQ7SUFBeUNFLHVDQUFTQTtJQUloREE7UUFBZ0JDLGtCQUFNQSxtQkFBbUJBLENBQUNBLENBQUNBO1FBSDNDQSxhQUFRQSxHQUFXQSxJQUFJQSxDQUFDQTtRQUN4QkEsV0FBTUEsR0FBV0EsSUFBSUEsQ0FBQ0E7UUFDdEJBLFNBQUlBLEdBQVdBLElBQUlBLENBQUNBO0lBQ3dCQSxDQUFDQTtJQUMvQ0QsMEJBQUNBO0FBQURBLENBQUNBLEFBTEQsRUFBeUMsNEJBQVMsRUFLakQ7QUFMWSwyQkFBbUIsc0JBSy9CLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1JvdXRlciwgUm91dGVyT3V0bGV0LCBMb2NhdGlvbiwgUGxhdGZvcm1Mb2NhdGlvbn0gZnJvbSAnYW5ndWxhcjIvcm91dGVyJztcbmltcG9ydCB7U3B5T2JqZWN0LCBwcm94eX0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmV4cG9ydCBjbGFzcyBTcHlSb3V0ZXIgZXh0ZW5kcyBTcHlPYmplY3Qge1xuICBjb25zdHJ1Y3RvcigpIHsgc3VwZXIoUm91dGVyKTsgfVxufVxuXG5leHBvcnQgY2xhc3MgU3B5Um91dGVyT3V0bGV0IGV4dGVuZHMgU3B5T2JqZWN0IHtcbiAgY29uc3RydWN0b3IoKSB7IHN1cGVyKFJvdXRlck91dGxldCk7IH1cbn1cblxuZXhwb3J0IGNsYXNzIFNweUxvY2F0aW9uIGV4dGVuZHMgU3B5T2JqZWN0IHtcbiAgY29uc3RydWN0b3IoKSB7IHN1cGVyKExvY2F0aW9uKTsgfVxufVxuXG5leHBvcnQgY2xhc3MgU3B5UGxhdGZvcm1Mb2NhdGlvbiBleHRlbmRzIFNweU9iamVjdCB7XG4gIHBhdGhuYW1lOiBzdHJpbmcgPSBudWxsO1xuICBzZWFyY2g6IHN0cmluZyA9IG51bGw7XG4gIGhhc2g6IHN0cmluZyA9IG51bGw7XG4gIGNvbnN0cnVjdG9yKCkgeyBzdXBlcihTcHlQbGF0Zm9ybUxvY2F0aW9uKTsgfVxufVxuIl19