'use strict';var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('angular2/core');
var lang_1 = require('angular2/src/facade/lang');
var exceptions_1 = require('angular2/src/facade/exceptions');
var testing_internal_1 = require('angular2/testing_internal');
var router_1 = require('angular2/src/router/router');
var router_2 = require('angular2/router');
var location_mock_1 = require('angular2/src/mock/location_mock');
var location_1 = require('angular2/src/router/location/location');
var route_registry_1 = require('angular2/src/router/route_registry');
var directive_resolver_1 = require('angular2/src/core/linker/directive_resolver');
var dom_adapter_1 = require('angular2/src/platform/dom/dom_adapter');
var testing_internal_2 = require('angular2/testing_internal');
exports.ComponentFixture = testing_internal_2.ComponentFixture;
/**
 * Router test helpers and fixtures
 */
var RootCmp = (function () {
    function RootCmp() {
    }
    RootCmp = __decorate([
        core_1.Component({
            selector: 'root-comp',
            template: "<router-outlet></router-outlet>",
            directives: [router_2.ROUTER_DIRECTIVES]
        }), 
        __metadata('design:paramtypes', [])
    ], RootCmp);
    return RootCmp;
})();
exports.RootCmp = RootCmp;
function compile(tcb, template) {
    if (template === void 0) { template = "<router-outlet></router-outlet>"; }
    return tcb.overrideTemplate(RootCmp, ('<div>' + template + '</div>')).createAsync(RootCmp);
}
exports.compile = compile;
exports.TEST_ROUTER_PROVIDERS = [
    route_registry_1.RouteRegistry,
    directive_resolver_1.DirectiveResolver,
    core_1.provide(location_1.Location, { useClass: location_mock_1.SpyLocation }),
    core_1.provide(router_2.ROUTER_PRIMARY_COMPONENT, { useValue: RootCmp }),
    core_1.provide(router_2.Router, { useClass: router_1.RootRouter })
];
function clickOnElement(anchorEl) {
    var dispatchedEvent = dom_adapter_1.DOM.createMouseEvent('click');
    dom_adapter_1.DOM.dispatchEvent(anchorEl, dispatchedEvent);
    return dispatchedEvent;
}
exports.clickOnElement = clickOnElement;
function getHref(elt) {
    return dom_adapter_1.DOM.getAttribute(elt, 'href');
}
exports.getHref = getHref;
/**
 * Router integration suite DSL
 */
var specNameBuilder = [];
// we add the specs themselves onto this map
exports.specs = {};
function describeRouter(description, fn, exclusive) {
    if (exclusive === void 0) { exclusive = false; }
    var specName = descriptionToSpecName(description);
    specNameBuilder.push(specName);
    if (exclusive) {
        testing_internal_1.ddescribe(description, fn);
    }
    else {
        testing_internal_1.describe(description, fn);
    }
    specNameBuilder.pop();
}
exports.describeRouter = describeRouter;
function ddescribeRouter(description, fn, exclusive) {
    if (exclusive === void 0) { exclusive = false; }
    describeRouter(description, fn, true);
}
exports.ddescribeRouter = ddescribeRouter;
function describeWithAndWithout(description, fn) {
    // the "without" case is usually simpler, so we opt to run this spec first
    describeWithout(description, fn);
    describeWith(description, fn);
}
exports.describeWithAndWithout = describeWithAndWithout;
function describeWith(description, fn) {
    var specName = 'with ' + description;
    specNameBuilder.push(specName);
    testing_internal_1.describe(specName, fn);
    specNameBuilder.pop();
}
exports.describeWith = describeWith;
function describeWithout(description, fn) {
    var specName = 'without ' + description;
    specNameBuilder.push(specName);
    testing_internal_1.describe(specName, fn);
    specNameBuilder.pop();
}
exports.describeWithout = describeWithout;
function descriptionToSpecName(description) {
    return spaceCaseToCamelCase(description);
}
// this helper looks up the suite registered from the "impl" folder in this directory
function itShouldRoute() {
    var specSuiteName = spaceCaseToCamelCase(specNameBuilder.join(' '));
    var spec = exports.specs[specSuiteName];
    if (lang_1.isBlank(spec)) {
        throw new exceptions_1.BaseException("Router integration spec suite \"" + specSuiteName + "\" was not found.");
    }
    else {
        // todo: remove spec from map, throw if there are extra left over??
        spec();
    }
}
exports.itShouldRoute = itShouldRoute;
function spaceCaseToCamelCase(str) {
    var words = str.split(' ');
    var first = words.shift();
    return first + words.map(title).join('');
}
function title(str) {
    return str[0].toUpperCase() + str.substring(1);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXRpbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3Qvcm91dGVyL2ludGVncmF0aW9uL3V0aWwudHMiXSwibmFtZXMiOlsiUm9vdENtcCIsIlJvb3RDbXAuY29uc3RydWN0b3IiLCJjb21waWxlIiwiY2xpY2tPbkVsZW1lbnQiLCJnZXRIcmVmIiwiZGVzY3JpYmVSb3V0ZXIiLCJkZGVzY3JpYmVSb3V0ZXIiLCJkZXNjcmliZVdpdGhBbmRXaXRob3V0IiwiZGVzY3JpYmVXaXRoIiwiZGVzY3JpYmVXaXRob3V0IiwiZGVzY3JpcHRpb25Ub1NwZWNOYW1lIiwiaXRTaG91bGRSb3V0ZSIsInNwYWNlQ2FzZVRvQ2FtZWxDYXNlIiwidGl0bGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLHFCQUEyQyxlQUFlLENBQUMsQ0FBQTtBQUMzRCxxQkFBNEIsMEJBQTBCLENBQUMsQ0FBQTtBQUN2RCwyQkFBNEIsZ0NBQWdDLENBQUMsQ0FBQTtBQUU3RCxpQ0FhTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLHVCQUF5Qiw0QkFBNEIsQ0FBQyxDQUFBO0FBQ3RELHVCQUFrRSxpQkFBaUIsQ0FBQyxDQUFBO0FBRXBGLDhCQUEwQixpQ0FBaUMsQ0FBQyxDQUFBO0FBQzVELHlCQUF1Qix1Q0FBdUMsQ0FBQyxDQUFBO0FBQy9ELCtCQUE0QixvQ0FBb0MsQ0FBQyxDQUFBO0FBQ2pFLG1DQUFnQyw2Q0FBNkMsQ0FBQyxDQUFBO0FBQzlFLDRCQUFrQix1Q0FBdUMsQ0FBQyxDQUFBO0FBQzFELGlDQUErQiwyQkFBMkIsQ0FBQztBQUFuRCwrREFBbUQ7QUFHM0Q7O0dBRUc7QUFFSDtJQUFBQTtJQU9BQyxDQUFDQTtJQVBERDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsV0FBV0E7WUFDckJBLFFBQVFBLEVBQUVBLGlDQUFpQ0E7WUFDM0NBLFVBQVVBLEVBQUVBLENBQUNBLDBCQUFpQkEsQ0FBQ0E7U0FDaENBLENBQUNBOztnQkFHREE7SUFBREEsY0FBQ0E7QUFBREEsQ0FBQ0EsQUFQRCxJQU9DO0FBRlksZUFBTyxVQUVuQixDQUFBO0FBRUQsaUJBQXdCLEdBQXlCLEVBQ3pCLFFBQW9EO0lBQXBERSx3QkFBb0RBLEdBQXBEQSw0Q0FBb0RBO0lBQzFFQSxNQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxnQkFBZ0JBLENBQUNBLE9BQU9BLEVBQUVBLENBQUNBLE9BQU9BLEdBQUdBLFFBQVFBLEdBQUdBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLFdBQVdBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO0FBQzdGQSxDQUFDQTtBQUhlLGVBQU8sVUFHdEIsQ0FBQTtBQUVVLDZCQUFxQixHQUFHO0lBQ2pDLDhCQUFhO0lBQ2Isc0NBQWlCO0lBQ2pCLGNBQU8sQ0FBQyxtQkFBUSxFQUFFLEVBQUMsUUFBUSxFQUFFLDJCQUFXLEVBQUMsQ0FBQztJQUMxQyxjQUFPLENBQUMsaUNBQXdCLEVBQUUsRUFBQyxRQUFRLEVBQUUsT0FBTyxFQUFDLENBQUM7SUFDdEQsY0FBTyxDQUFDLGVBQU0sRUFBRSxFQUFDLFFBQVEsRUFBRSxtQkFBVSxFQUFDLENBQUM7Q0FDeEMsQ0FBQztBQUVGLHdCQUErQixRQUFRO0lBQ3JDQyxJQUFJQSxlQUFlQSxHQUFHQSxpQkFBR0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtJQUNwREEsaUJBQUdBLENBQUNBLGFBQWFBLENBQUNBLFFBQVFBLEVBQUVBLGVBQWVBLENBQUNBLENBQUNBO0lBQzdDQSxNQUFNQSxDQUFDQSxlQUFlQSxDQUFDQTtBQUN6QkEsQ0FBQ0E7QUFKZSxzQkFBYyxpQkFJN0IsQ0FBQTtBQUVELGlCQUF3QixHQUFHO0lBQ3pCQyxNQUFNQSxDQUFDQSxpQkFBR0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsR0FBR0EsRUFBRUEsTUFBTUEsQ0FBQ0EsQ0FBQ0E7QUFDdkNBLENBQUNBO0FBRmUsZUFBTyxVQUV0QixDQUFBO0FBR0Q7O0dBRUc7QUFFSCxJQUFJLGVBQWUsR0FBRyxFQUFFLENBQUM7QUFFekIsNENBQTRDO0FBQ2pDLGFBQUssR0FBRyxFQUFFLENBQUM7QUFFdEIsd0JBQStCLFdBQW1CLEVBQUUsRUFBWSxFQUFFLFNBQWlCO0lBQWpCQyx5QkFBaUJBLEdBQWpCQSxpQkFBaUJBO0lBQ2pGQSxJQUFJQSxRQUFRQSxHQUFHQSxxQkFBcUJBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO0lBQ2xEQSxlQUFlQSxDQUFDQSxJQUFJQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtJQUMvQkEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDZEEsNEJBQVNBLENBQUNBLFdBQVdBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBO0lBQzdCQSxDQUFDQTtJQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtRQUNOQSwyQkFBUUEsQ0FBQ0EsV0FBV0EsRUFBRUEsRUFBRUEsQ0FBQ0EsQ0FBQ0E7SUFDNUJBLENBQUNBO0lBQ0RBLGVBQWVBLENBQUNBLEdBQUdBLEVBQUVBLENBQUNBO0FBQ3hCQSxDQUFDQTtBQVRlLHNCQUFjLGlCQVM3QixDQUFBO0FBRUQseUJBQWdDLFdBQW1CLEVBQUUsRUFBWSxFQUFFLFNBQWlCO0lBQWpCQyx5QkFBaUJBLEdBQWpCQSxpQkFBaUJBO0lBQ2xGQSxjQUFjQSxDQUFDQSxXQUFXQSxFQUFFQSxFQUFFQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtBQUN4Q0EsQ0FBQ0E7QUFGZSx1QkFBZSxrQkFFOUIsQ0FBQTtBQUVELGdDQUF1QyxXQUFtQixFQUFFLEVBQVk7SUFDdEVDLDBFQUEwRUE7SUFDMUVBLGVBQWVBLENBQUNBLFdBQVdBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBO0lBQ2pDQSxZQUFZQSxDQUFDQSxXQUFXQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQTtBQUNoQ0EsQ0FBQ0E7QUFKZSw4QkFBc0IseUJBSXJDLENBQUE7QUFFRCxzQkFBNkIsV0FBbUIsRUFBRSxFQUFZO0lBQzVEQyxJQUFJQSxRQUFRQSxHQUFHQSxPQUFPQSxHQUFHQSxXQUFXQSxDQUFDQTtJQUNyQ0EsZUFBZUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0E7SUFDL0JBLDJCQUFRQSxDQUFDQSxRQUFRQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQTtJQUN2QkEsZUFBZUEsQ0FBQ0EsR0FBR0EsRUFBRUEsQ0FBQ0E7QUFDeEJBLENBQUNBO0FBTGUsb0JBQVksZUFLM0IsQ0FBQTtBQUVELHlCQUFnQyxXQUFtQixFQUFFLEVBQVk7SUFDL0RDLElBQUlBLFFBQVFBLEdBQUdBLFVBQVVBLEdBQUdBLFdBQVdBLENBQUNBO0lBQ3hDQSxlQUFlQSxDQUFDQSxJQUFJQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtJQUMvQkEsMkJBQVFBLENBQUNBLFFBQVFBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBO0lBQ3ZCQSxlQUFlQSxDQUFDQSxHQUFHQSxFQUFFQSxDQUFDQTtBQUN4QkEsQ0FBQ0E7QUFMZSx1QkFBZSxrQkFLOUIsQ0FBQTtBQUVELCtCQUErQixXQUFtQjtJQUNoREMsTUFBTUEsQ0FBQ0Esb0JBQW9CQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQTtBQUMzQ0EsQ0FBQ0E7QUFFRCxxRkFBcUY7QUFDckY7SUFDRUMsSUFBSUEsYUFBYUEsR0FBR0Esb0JBQW9CQSxDQUFDQSxlQUFlQSxDQUFDQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUVwRUEsSUFBSUEsSUFBSUEsR0FBR0EsYUFBS0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7SUFDaENBLEVBQUVBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLElBQUlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ2xCQSxNQUFNQSxJQUFJQSwwQkFBYUEsQ0FBQ0EscUNBQWtDQSxhQUFhQSxzQkFBa0JBLENBQUNBLENBQUNBO0lBQzdGQSxDQUFDQTtJQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtRQUNOQSxtRUFBbUVBO1FBQ25FQSxJQUFJQSxFQUFFQSxDQUFDQTtJQUNUQSxDQUFDQTtBQUNIQSxDQUFDQTtBQVZlLHFCQUFhLGdCQVU1QixDQUFBO0FBRUQsOEJBQThCLEdBQVc7SUFDdkNDLElBQUlBLEtBQUtBLEdBQUdBLEdBQUdBLENBQUNBLEtBQUtBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO0lBQzNCQSxJQUFJQSxLQUFLQSxHQUFHQSxLQUFLQSxDQUFDQSxLQUFLQSxFQUFFQSxDQUFDQTtJQUMxQkEsTUFBTUEsQ0FBQ0EsS0FBS0EsR0FBR0EsS0FBS0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7QUFDM0NBLENBQUNBO0FBRUQsZUFBZSxHQUFXO0lBQ3hCQyxNQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxXQUFXQSxFQUFFQSxHQUFHQSxHQUFHQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUNqREEsQ0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge3Byb3ZpZGUsIFByb3ZpZGVyLCBDb21wb25lbnR9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuaW1wb3J0IHtUeXBlLCBpc0JsYW5rfSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2xhbmcnO1xuaW1wb3J0IHtCYXNlRXhjZXB0aW9ufSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2V4Y2VwdGlvbnMnO1xuXG5pbXBvcnQge1xuICBDb21wb25lbnRGaXh0dXJlLFxuICBBc3luY1Rlc3RDb21wbGV0ZXIsXG4gIFRlc3RDb21wb25lbnRCdWlsZGVyLFxuICBiZWZvcmVFYWNoLFxuICBkZGVzY3JpYmUsXG4gIHhkZXNjcmliZSxcbiAgZGVzY3JpYmUsXG4gIGVsLFxuICBpbmplY3QsXG4gIGJlZm9yZUVhY2hQcm92aWRlcnMsXG4gIGl0LFxuICB4aXRcbn0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmltcG9ydCB7Um9vdFJvdXRlcn0gZnJvbSAnYW5ndWxhcjIvc3JjL3JvdXRlci9yb3V0ZXInO1xuaW1wb3J0IHtSb3V0ZXIsIFJPVVRFUl9ESVJFQ1RJVkVTLCBST1VURVJfUFJJTUFSWV9DT01QT05FTlR9IGZyb20gJ2FuZ3VsYXIyL3JvdXRlcic7XG5cbmltcG9ydCB7U3B5TG9jYXRpb259IGZyb20gJ2FuZ3VsYXIyL3NyYy9tb2NrL2xvY2F0aW9uX21vY2snO1xuaW1wb3J0IHtMb2NhdGlvbn0gZnJvbSAnYW5ndWxhcjIvc3JjL3JvdXRlci9sb2NhdGlvbi9sb2NhdGlvbic7XG5pbXBvcnQge1JvdXRlUmVnaXN0cnl9IGZyb20gJ2FuZ3VsYXIyL3NyYy9yb3V0ZXIvcm91dGVfcmVnaXN0cnknO1xuaW1wb3J0IHtEaXJlY3RpdmVSZXNvbHZlcn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvbGlua2VyL2RpcmVjdGl2ZV9yZXNvbHZlcic7XG5pbXBvcnQge0RPTX0gZnJvbSAnYW5ndWxhcjIvc3JjL3BsYXRmb3JtL2RvbS9kb21fYWRhcHRlcic7XG5leHBvcnQge0NvbXBvbmVudEZpeHR1cmV9IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5cbi8qKlxuICogUm91dGVyIHRlc3QgaGVscGVycyBhbmQgZml4dHVyZXNcbiAqL1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdyb290LWNvbXAnLFxuICB0ZW1wbGF0ZTogYDxyb3V0ZXItb3V0bGV0Pjwvcm91dGVyLW91dGxldD5gLFxuICBkaXJlY3RpdmVzOiBbUk9VVEVSX0RJUkVDVElWRVNdXG59KVxuZXhwb3J0IGNsYXNzIFJvb3RDbXAge1xuICBuYW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjb21waWxlKHRjYjogVGVzdENvbXBvbmVudEJ1aWxkZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZTogc3RyaW5nID0gXCI8cm91dGVyLW91dGxldD48L3JvdXRlci1vdXRsZXQ+XCIpIHtcbiAgcmV0dXJuIHRjYi5vdmVycmlkZVRlbXBsYXRlKFJvb3RDbXAsICgnPGRpdj4nICsgdGVtcGxhdGUgKyAnPC9kaXY+JykpLmNyZWF0ZUFzeW5jKFJvb3RDbXApO1xufVxuXG5leHBvcnQgdmFyIFRFU1RfUk9VVEVSX1BST1ZJREVSUyA9IFtcbiAgUm91dGVSZWdpc3RyeSxcbiAgRGlyZWN0aXZlUmVzb2x2ZXIsXG4gIHByb3ZpZGUoTG9jYXRpb24sIHt1c2VDbGFzczogU3B5TG9jYXRpb259KSxcbiAgcHJvdmlkZShST1VURVJfUFJJTUFSWV9DT01QT05FTlQsIHt1c2VWYWx1ZTogUm9vdENtcH0pLFxuICBwcm92aWRlKFJvdXRlciwge3VzZUNsYXNzOiBSb290Um91dGVyfSlcbl07XG5cbmV4cG9ydCBmdW5jdGlvbiBjbGlja09uRWxlbWVudChhbmNob3JFbCkge1xuICB2YXIgZGlzcGF0Y2hlZEV2ZW50ID0gRE9NLmNyZWF0ZU1vdXNlRXZlbnQoJ2NsaWNrJyk7XG4gIERPTS5kaXNwYXRjaEV2ZW50KGFuY2hvckVsLCBkaXNwYXRjaGVkRXZlbnQpO1xuICByZXR1cm4gZGlzcGF0Y2hlZEV2ZW50O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0SHJlZihlbHQpIHtcbiAgcmV0dXJuIERPTS5nZXRBdHRyaWJ1dGUoZWx0LCAnaHJlZicpO1xufVxuXG5cbi8qKlxuICogUm91dGVyIGludGVncmF0aW9uIHN1aXRlIERTTFxuICovXG5cbnZhciBzcGVjTmFtZUJ1aWxkZXIgPSBbXTtcblxuLy8gd2UgYWRkIHRoZSBzcGVjcyB0aGVtc2VsdmVzIG9udG8gdGhpcyBtYXBcbmV4cG9ydCB2YXIgc3BlY3MgPSB7fTtcblxuZXhwb3J0IGZ1bmN0aW9uIGRlc2NyaWJlUm91dGVyKGRlc2NyaXB0aW9uOiBzdHJpbmcsIGZuOiBGdW5jdGlvbiwgZXhjbHVzaXZlID0gZmFsc2UpOiB2b2lkIHtcbiAgdmFyIHNwZWNOYW1lID0gZGVzY3JpcHRpb25Ub1NwZWNOYW1lKGRlc2NyaXB0aW9uKTtcbiAgc3BlY05hbWVCdWlsZGVyLnB1c2goc3BlY05hbWUpO1xuICBpZiAoZXhjbHVzaXZlKSB7XG4gICAgZGRlc2NyaWJlKGRlc2NyaXB0aW9uLCBmbik7XG4gIH0gZWxzZSB7XG4gICAgZGVzY3JpYmUoZGVzY3JpcHRpb24sIGZuKTtcbiAgfVxuICBzcGVjTmFtZUJ1aWxkZXIucG9wKCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZGVzY3JpYmVSb3V0ZXIoZGVzY3JpcHRpb246IHN0cmluZywgZm46IEZ1bmN0aW9uLCBleGNsdXNpdmUgPSBmYWxzZSk6IHZvaWQge1xuICBkZXNjcmliZVJvdXRlcihkZXNjcmlwdGlvbiwgZm4sIHRydWUpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZGVzY3JpYmVXaXRoQW5kV2l0aG91dChkZXNjcmlwdGlvbjogc3RyaW5nLCBmbjogRnVuY3Rpb24pOiB2b2lkIHtcbiAgLy8gdGhlIFwid2l0aG91dFwiIGNhc2UgaXMgdXN1YWxseSBzaW1wbGVyLCBzbyB3ZSBvcHQgdG8gcnVuIHRoaXMgc3BlYyBmaXJzdFxuICBkZXNjcmliZVdpdGhvdXQoZGVzY3JpcHRpb24sIGZuKTtcbiAgZGVzY3JpYmVXaXRoKGRlc2NyaXB0aW9uLCBmbik7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZXNjcmliZVdpdGgoZGVzY3JpcHRpb246IHN0cmluZywgZm46IEZ1bmN0aW9uKTogdm9pZCB7XG4gIHZhciBzcGVjTmFtZSA9ICd3aXRoICcgKyBkZXNjcmlwdGlvbjtcbiAgc3BlY05hbWVCdWlsZGVyLnB1c2goc3BlY05hbWUpO1xuICBkZXNjcmliZShzcGVjTmFtZSwgZm4pO1xuICBzcGVjTmFtZUJ1aWxkZXIucG9wKCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZXNjcmliZVdpdGhvdXQoZGVzY3JpcHRpb246IHN0cmluZywgZm46IEZ1bmN0aW9uKTogdm9pZCB7XG4gIHZhciBzcGVjTmFtZSA9ICd3aXRob3V0ICcgKyBkZXNjcmlwdGlvbjtcbiAgc3BlY05hbWVCdWlsZGVyLnB1c2goc3BlY05hbWUpO1xuICBkZXNjcmliZShzcGVjTmFtZSwgZm4pO1xuICBzcGVjTmFtZUJ1aWxkZXIucG9wKCk7XG59XG5cbmZ1bmN0aW9uIGRlc2NyaXB0aW9uVG9TcGVjTmFtZShkZXNjcmlwdGlvbjogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHNwYWNlQ2FzZVRvQ2FtZWxDYXNlKGRlc2NyaXB0aW9uKTtcbn1cblxuLy8gdGhpcyBoZWxwZXIgbG9va3MgdXAgdGhlIHN1aXRlIHJlZ2lzdGVyZWQgZnJvbSB0aGUgXCJpbXBsXCIgZm9sZGVyIGluIHRoaXMgZGlyZWN0b3J5XG5leHBvcnQgZnVuY3Rpb24gaXRTaG91bGRSb3V0ZSgpIHtcbiAgdmFyIHNwZWNTdWl0ZU5hbWUgPSBzcGFjZUNhc2VUb0NhbWVsQ2FzZShzcGVjTmFtZUJ1aWxkZXIuam9pbignICcpKTtcblxuICB2YXIgc3BlYyA9IHNwZWNzW3NwZWNTdWl0ZU5hbWVdO1xuICBpZiAoaXNCbGFuayhzcGVjKSkge1xuICAgIHRocm93IG5ldyBCYXNlRXhjZXB0aW9uKGBSb3V0ZXIgaW50ZWdyYXRpb24gc3BlYyBzdWl0ZSBcIiR7c3BlY1N1aXRlTmFtZX1cIiB3YXMgbm90IGZvdW5kLmApO1xuICB9IGVsc2Uge1xuICAgIC8vIHRvZG86IHJlbW92ZSBzcGVjIGZyb20gbWFwLCB0aHJvdyBpZiB0aGVyZSBhcmUgZXh0cmEgbGVmdCBvdmVyPz9cbiAgICBzcGVjKCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gc3BhY2VDYXNlVG9DYW1lbENhc2Uoc3RyOiBzdHJpbmcpOiBzdHJpbmcge1xuICB2YXIgd29yZHMgPSBzdHIuc3BsaXQoJyAnKTtcbiAgdmFyIGZpcnN0ID0gd29yZHMuc2hpZnQoKTtcbiAgcmV0dXJuIGZpcnN0ICsgd29yZHMubWFwKHRpdGxlKS5qb2luKCcnKTtcbn1cblxuZnVuY3Rpb24gdGl0bGUoc3RyOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gc3RyWzBdLnRvVXBwZXJDYXNlKCkgKyBzdHIuc3Vic3RyaW5nKDEpO1xufVxuIl19