'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var common_dom_1 = require('angular2/platform/common_dom');
var lang_1 = require('angular2/src/facade/lang');
var async_1 = require('angular2/src/facade/async');
var collection_1 = require('angular2/src/facade/collection');
var core_1 = require('angular2/core');
var location_mock_1 = require('angular2/src/mock/location_mock');
var router_1 = require('angular2/router');
var router_2 = require('angular2/src/router/router');
var dom_adapter_1 = require('angular2/src/platform/dom/dom_adapter');
var compiler_1 = require('angular2/compiler');
var router_link_transform_1 = require('angular2/src/router/directives/router_link_transform');
function main() {
    testing_internal_1.describe('routerLink directive', function () {
        var tcb;
        var fixture;
        var router;
        var location;
        testing_internal_1.beforeEachProviders(function () { return [
            router_1.RouteRegistry,
            core_1.DirectiveResolver,
            core_1.provide(router_1.Location, { useClass: location_mock_1.SpyLocation }),
            core_1.provide(router_1.ROUTER_PRIMARY_COMPONENT, { useValue: MyComp }),
            core_1.provide(router_1.Router, { useClass: router_2.RootRouter }),
            core_1.provide(compiler_1.TEMPLATE_TRANSFORMS, { useClass: router_link_transform_1.RouterLinkTransform, multi: true })
        ]; });
        testing_internal_1.beforeEach(testing_internal_1.inject([testing_internal_1.TestComponentBuilder, router_1.Router, router_1.Location], function (tcBuilder, rtr, loc) {
            tcb = tcBuilder;
            router = rtr;
            location = loc;
        }));
        function compile(template) {
            if (template === void 0) { template = "<router-outlet></router-outlet>"; }
            return tcb.overrideTemplate(MyComp, ('<div>' + template + '</div>'))
                .createAsync(MyComp)
                .then(function (tc) { fixture = tc; });
        }
        testing_internal_1.it('should generate absolute hrefs that include the base href', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            location.setBaseHref('/my/base');
            compile('<a href="hello" [routerLink]="[\'./User\']"></a>')
                .then(function (_) { return router.config([new router_1.Route({ path: '/user', component: UserCmp, name: 'User' })]); })
                .then(function (_) { return router.navigateByUrl('/a/b'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(getHref(fixture)).toEqual('/my/base/user');
                async.done();
            });
        }));
        testing_internal_1.it('should generate link hrefs without params', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            compile('<a href="hello" [routerLink]="[\'./User\']"></a>')
                .then(function (_) { return router.config([new router_1.Route({ path: '/user', component: UserCmp, name: 'User' })]); })
                .then(function (_) { return router.navigateByUrl('/a/b'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(getHref(fixture)).toEqual('/user');
                async.done();
            });
        }));
        testing_internal_1.it('should generate link hrefs with params', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            compile('<a href="hello" [routerLink]="[\'./User\', {name: name}]">{{name}}</a>')
                .then(function (_) { return router.config([new router_1.Route({ path: '/user/:name', component: UserCmp, name: 'User' })]); })
                .then(function (_) { return router.navigateByUrl('/a/b'); })
                .then(function (_) {
                fixture.debugElement.componentInstance.name = 'brian';
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('brian');
                testing_internal_1.expect(getHref(fixture)).toEqual('/user/brian');
                async.done();
            });
        }));
        testing_internal_1.it('should generate link hrefs from a child to its sibling', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            compile()
                .then(function (_) { return router.config([new router_1.Route({ path: '/page/:number', component: SiblingPageCmp, name: 'Page' })]); })
                .then(function (_) { return router.navigateByUrl('/page/1'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(getHref(fixture)).toEqual('/page/2');
                async.done();
            });
        }));
        testing_internal_1.it('should generate link hrefs from a child to its sibling with no leading slash', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            compile()
                .then(function (_) { return router.config([
                new router_1.Route({ path: '/page/:number', component: NoPrefixSiblingPageCmp, name: 'Page' })
            ]); })
                .then(function (_) { return router.navigateByUrl('/page/1'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(getHref(fixture)).toEqual('/page/2');
                async.done();
            });
        }));
        testing_internal_1.it('should generate link hrefs to a child with no leading slash', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            compile()
                .then(function (_) { return router.config([
                new router_1.Route({ path: '/book/:title/...', component: NoPrefixBookCmp, name: 'Book' })
            ]); })
                .then(function (_) { return router.navigateByUrl('/book/1984/page/1'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(getHref(fixture)).toEqual('/book/1984/page/100');
                async.done();
            });
        }));
        testing_internal_1.it('should throw when links without a leading slash are ambiguous', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            compile()
                .then(function (_) { return router.config([
                new router_1.Route({ path: '/book/:title/...', component: AmbiguousBookCmp, name: 'Book' })
            ]); })
                .then(function (_) { return router.navigateByUrl('/book/1984/page/1'); })
                .then(function (_) {
                var link = collection_1.ListWrapper.toJSON(['Book', { number: 100 }]);
                testing_internal_1.expect(function () { return fixture.detectChanges(); })
                    .toThrowErrorWith("Link \"" + link + "\" is ambiguous, use \"./\" or \"../\" to disambiguate.");
                async.done();
            });
        }));
        testing_internal_1.it('should generate link hrefs when asynchronously loaded', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            compile()
                .then(function (_) { return router.config([
                new router_1.AsyncRoute({
                    path: '/child-with-grandchild/...',
                    loader: parentCmpLoader,
                    name: 'ChildWithGrandchild'
                })
            ]); })
                .then(function (_) { return router.navigateByUrl('/child-with-grandchild/grandchild'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(getHref(fixture)).toEqual('/child-with-grandchild/grandchild');
                async.done();
            });
        }));
        testing_internal_1.it('should generate relative links preserving the existing parent route', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            compile()
                .then(function (_) { return router.config([new router_1.Route({ path: '/book/:title/...', component: BookCmp, name: 'Book' })]); })
                .then(function (_) { return router.navigateByUrl('/book/1984/page/1'); })
                .then(function (_) {
                fixture.detectChanges();
                // TODO(juliemr): This should be one By.css('book-cmp a') query, but the parse5
                // adapter
                // can't handle css child selectors.
                testing_internal_1.expect(dom_adapter_1.DOM.getAttribute(fixture.debugElement.query(common_dom_1.By.css('book-cmp'))
                    .query(common_dom_1.By.css('a'))
                    .nativeElement, 'href'))
                    .toEqual('/book/1984/page/100');
                testing_internal_1.expect(dom_adapter_1.DOM.getAttribute(fixture.debugElement.query(common_dom_1.By.css('page-cmp'))
                    .query(common_dom_1.By.css('a'))
                    .nativeElement, 'href'))
                    .toEqual('/book/1984/page/2');
                async.done();
            });
        }));
        testing_internal_1.it('should generate links to auxiliary routes', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            compile()
                .then(function (_) { return router.config([new router_1.Route({ path: '/...', component: AuxLinkCmp })]); })
                .then(function (_) { return router.navigateByUrl('/'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(getHref(fixture)).toEqual('/(aside)');
                async.done();
            });
        }));
        testing_internal_1.describe('router-link-active CSS class', function () {
            testing_internal_1.it('should be added to the associated element', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                router.config([
                    new router_1.Route({ path: '/child', component: HelloCmp, name: 'Child' }),
                    new router_1.Route({ path: '/better-child', component: Hello2Cmp, name: 'BetterChild' })
                ])
                    .then(function (_) { return compile("<a [routerLink]=\"['./Child']\" class=\"child-link\">Child</a>\n                                <a [routerLink]=\"['./BetterChild']\" class=\"better-child-link\">Better Child</a>\n                                <router-outlet></router-outlet>"); })
                    .then(function (_) {
                    var element = fixture.debugElement.nativeElement;
                    fixture.detectChanges();
                    var link1 = dom_adapter_1.DOM.querySelector(element, '.child-link');
                    var link2 = dom_adapter_1.DOM.querySelector(element, '.better-child-link');
                    testing_internal_1.expect(link1).not.toHaveCssClass('router-link-active');
                    testing_internal_1.expect(link2).not.toHaveCssClass('router-link-active');
                    router.subscribe(function (_) {
                        fixture.detectChanges();
                        testing_internal_1.expect(link1).not.toHaveCssClass('router-link-active');
                        testing_internal_1.expect(link2).toHaveCssClass('router-link-active');
                        async.done();
                    });
                    router.navigateByUrl('/better-child?extra=0');
                });
            }));
            testing_internal_1.it('should be added to links in child routes', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                router.config([
                    new router_1.Route({ path: '/child', component: HelloCmp, name: 'Child' }),
                    new router_1.Route({
                        path: '/child-with-grandchild/...',
                        component: ParentCmp,
                        name: 'ChildWithGrandchild'
                    })
                ])
                    .then(function (_) { return compile("<a [routerLink]=\"['./Child']\" class=\"child-link\">Child</a>\n                                <a [routerLink]=\"['./ChildWithGrandchild/Grandchild']\" class=\"child-with-grandchild-link\">Better Child</a>\n                                <router-outlet></router-outlet>"); })
                    .then(function (_) {
                    var element = fixture.debugElement.nativeElement;
                    fixture.detectChanges();
                    var link1 = dom_adapter_1.DOM.querySelector(element, '.child-link');
                    var link2 = dom_adapter_1.DOM.querySelector(element, '.child-with-grandchild-link');
                    testing_internal_1.expect(link1).not.toHaveCssClass('router-link-active');
                    testing_internal_1.expect(link2).not.toHaveCssClass('router-link-active');
                    router.subscribe(function (_) {
                        fixture.detectChanges();
                        testing_internal_1.expect(link1).not.toHaveCssClass('router-link-active');
                        testing_internal_1.expect(link2).toHaveCssClass('router-link-active');
                        var link3 = dom_adapter_1.DOM.querySelector(element, '.grandchild-link');
                        var link4 = dom_adapter_1.DOM.querySelector(element, '.better-grandchild-link');
                        testing_internal_1.expect(link3).toHaveCssClass('router-link-active');
                        testing_internal_1.expect(link4).not.toHaveCssClass('router-link-active');
                        async.done();
                    });
                    router.navigateByUrl('/child-with-grandchild/grandchild?extra=0');
                });
            }));
            testing_internal_1.describe('router link dsl', function () {
                testing_internal_1.it('should generate link hrefs with params', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile('<a href="hello" [routerLink]="route:./User(name: name)">{{name}}</a>')
                        .then(function (_) { return router.config([new router_1.Route({ path: '/user/:name', component: UserCmp, name: 'User' })]); })
                        .then(function (_) { return router.navigateByUrl('/a/b'); })
                        .then(function (_) {
                        fixture.debugElement.componentInstance.name = 'brian';
                        fixture.detectChanges();
                        testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('brian');
                        testing_internal_1.expect(getHref(fixture)).toEqual('/user/brian');
                        async.done();
                    });
                }));
            });
        });
        testing_internal_1.describe('when clicked', function () {
            var clickOnElement = function (view) {
                var anchorEl = fixture.debugElement.query(common_dom_1.By.css('a')).nativeElement;
                var dispatchedEvent = dom_adapter_1.DOM.createMouseEvent('click');
                dom_adapter_1.DOM.dispatchEvent(anchorEl, dispatchedEvent);
                return dispatchedEvent;
            };
            testing_internal_1.it('should navigate to link hrefs without params', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                compile('<a href="hello" [routerLink]="[\'./User\']"></a>')
                    .then(function (_) { return router.config([new router_1.Route({ path: '/user', component: UserCmp, name: 'User' })]); })
                    .then(function (_) { return router.navigateByUrl('/a/b'); })
                    .then(function (_) {
                    fixture.detectChanges();
                    var dispatchedEvent = clickOnElement(fixture);
                    testing_internal_1.expect(dom_adapter_1.DOM.isPrevented(dispatchedEvent)).toBe(true);
                    // router navigation is async.
                    router.subscribe(function (_) {
                        testing_internal_1.expect(location.urlChanges).toEqual(['/user']);
                        async.done();
                    });
                });
            }));
            testing_internal_1.it('should navigate to link hrefs in presence of base href', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                location.setBaseHref('/base');
                compile('<a href="hello" [routerLink]="[\'./User\']"></a>')
                    .then(function (_) { return router.config([new router_1.Route({ path: '/user', component: UserCmp, name: 'User' })]); })
                    .then(function (_) { return router.navigateByUrl('/a/b'); })
                    .then(function (_) {
                    fixture.detectChanges();
                    var dispatchedEvent = clickOnElement(fixture);
                    testing_internal_1.expect(dom_adapter_1.DOM.isPrevented(dispatchedEvent)).toBe(true);
                    // router navigation is async.
                    router.subscribe(function (_) {
                        testing_internal_1.expect(location.urlChanges).toEqual(['/base/user']);
                        async.done();
                    });
                });
            }));
        });
    });
}
exports.main = main;
function getHref(tc) {
    return dom_adapter_1.DOM.getAttribute(tc.debugElement.query(common_dom_1.By.css('a')).nativeElement, 'href');
}
var MyComp = (function () {
    function MyComp() {
    }
    MyComp = __decorate([
        core_1.Component({ selector: 'my-comp', template: '', directives: [router_1.ROUTER_DIRECTIVES] }), 
        __metadata('design:paramtypes', [])
    ], MyComp);
    return MyComp;
})();
var UserCmp = (function () {
    function UserCmp(params) {
        this.user = params.get('name');
    }
    UserCmp = __decorate([
        core_1.Component({ selector: 'user-cmp', template: "hello {{user}}" }), 
        __metadata('design:paramtypes', [router_1.RouteParams])
    ], UserCmp);
    return UserCmp;
})();
var SiblingPageCmp = (function () {
    function SiblingPageCmp(params) {
        this.pageNumber = lang_1.NumberWrapper.parseInt(params.get('number'), 10);
        this.nextPage = this.pageNumber + 1;
    }
    SiblingPageCmp = __decorate([
        core_1.Component({
            selector: 'page-cmp',
            template: "page #{{pageNumber}} | <a href=\"hello\" [routerLink]=\"['../Page', {number: nextPage}]\">next</a>",
            directives: [router_1.RouterLink]
        }), 
        __metadata('design:paramtypes', [router_1.RouteParams])
    ], SiblingPageCmp);
    return SiblingPageCmp;
})();
var NoPrefixSiblingPageCmp = (function () {
    function NoPrefixSiblingPageCmp(params) {
        this.pageNumber = lang_1.NumberWrapper.parseInt(params.get('number'), 10);
        this.nextPage = this.pageNumber + 1;
    }
    NoPrefixSiblingPageCmp = __decorate([
        core_1.Component({
            selector: 'page-cmp',
            template: "page #{{pageNumber}} | <a href=\"hello\" [routerLink]=\"['Page', {number: nextPage}]\">next</a>",
            directives: [router_1.RouterLink]
        }), 
        __metadata('design:paramtypes', [router_1.RouteParams])
    ], NoPrefixSiblingPageCmp);
    return NoPrefixSiblingPageCmp;
})();
var HelloCmp = (function () {
    function HelloCmp() {
    }
    HelloCmp = __decorate([
        core_1.Component({ selector: 'hello-cmp', template: 'hello' }), 
        __metadata('design:paramtypes', [])
    ], HelloCmp);
    return HelloCmp;
})();
var Hello2Cmp = (function () {
    function Hello2Cmp() {
    }
    Hello2Cmp = __decorate([
        core_1.Component({ selector: 'hello2-cmp', template: 'hello2' }), 
        __metadata('design:paramtypes', [])
    ], Hello2Cmp);
    return Hello2Cmp;
})();
function parentCmpLoader() {
    return async_1.PromiseWrapper.resolve(ParentCmp);
}
var ParentCmp = (function () {
    function ParentCmp() {
    }
    ParentCmp = __decorate([
        core_1.Component({
            selector: 'parent-cmp',
            template: "{ <a [routerLink]=\"['./Grandchild']\" class=\"grandchild-link\">Grandchild</a>\n               <a [routerLink]=\"['./BetterGrandchild']\" class=\"better-grandchild-link\">Better Grandchild</a>\n               <router-outlet></router-outlet> }",
            directives: router_1.ROUTER_DIRECTIVES
        }),
        router_1.RouteConfig([
            new router_1.Route({ path: '/grandchild', component: HelloCmp, name: 'Grandchild' }),
            new router_1.Route({ path: '/better-grandchild', component: Hello2Cmp, name: 'BetterGrandchild' })
        ]), 
        __metadata('design:paramtypes', [])
    ], ParentCmp);
    return ParentCmp;
})();
var BookCmp = (function () {
    function BookCmp(params) {
        this.title = params.get('title');
    }
    BookCmp = __decorate([
        core_1.Component({
            selector: 'book-cmp',
            template: "<a href=\"hello\" [routerLink]=\"['./Page', {number: 100}]\">{{title}}</a> |\n    <router-outlet></router-outlet>",
            directives: router_1.ROUTER_DIRECTIVES
        }),
        router_1.RouteConfig([new router_1.Route({ path: '/page/:number', component: SiblingPageCmp, name: 'Page' })]), 
        __metadata('design:paramtypes', [router_1.RouteParams])
    ], BookCmp);
    return BookCmp;
})();
var NoPrefixBookCmp = (function () {
    function NoPrefixBookCmp(params) {
        this.title = params.get('title');
    }
    NoPrefixBookCmp = __decorate([
        core_1.Component({
            selector: 'book-cmp',
            template: "<a href=\"hello\" [routerLink]=\"['Page', {number: 100}]\">{{title}}</a> |\n    <router-outlet></router-outlet>",
            directives: router_1.ROUTER_DIRECTIVES
        }),
        router_1.RouteConfig([new router_1.Route({ path: '/page/:number', component: SiblingPageCmp, name: 'Page' })]), 
        __metadata('design:paramtypes', [router_1.RouteParams])
    ], NoPrefixBookCmp);
    return NoPrefixBookCmp;
})();
var AmbiguousBookCmp = (function () {
    function AmbiguousBookCmp(params) {
        this.title = params.get('title');
    }
    AmbiguousBookCmp = __decorate([
        core_1.Component({
            selector: 'book-cmp',
            template: "<a href=\"hello\" [routerLink]=\"['Book', {number: 100}]\">{{title}}</a> |\n    <router-outlet></router-outlet>",
            directives: router_1.ROUTER_DIRECTIVES
        }),
        router_1.RouteConfig([new router_1.Route({ path: '/page/:number', component: SiblingPageCmp, name: 'Book' })]), 
        __metadata('design:paramtypes', [router_1.RouteParams])
    ], AmbiguousBookCmp);
    return AmbiguousBookCmp;
})();
var AuxLinkCmp = (function () {
    function AuxLinkCmp() {
    }
    AuxLinkCmp = __decorate([
        core_1.Component({
            selector: 'aux-cmp',
            template: "<a [routerLink]=\"['./Hello', [ 'Aside' ] ]\">aside</a> |\n    <router-outlet></router-outlet> | aside <router-outlet name=\"aside\"></router-outlet>",
            directives: router_1.ROUTER_DIRECTIVES
        }),
        router_1.RouteConfig([
            new router_1.Route({ path: '/', component: HelloCmp, name: 'Hello' }),
            new router_1.AuxRoute({ path: '/aside', component: Hello2Cmp, name: 'Aside' })
        ]), 
        __metadata('design:paramtypes', [])
    ], AuxLinkCmp);
    return AuxLinkCmp;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGVyX2xpbmtfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3Qvcm91dGVyL2ludGVncmF0aW9uL3JvdXRlcl9saW5rX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiIsImNvbXBpbGUiLCJnZXRIcmVmIiwiTXlDb21wIiwiTXlDb21wLmNvbnN0cnVjdG9yIiwiVXNlckNtcCIsIlVzZXJDbXAuY29uc3RydWN0b3IiLCJTaWJsaW5nUGFnZUNtcCIsIlNpYmxpbmdQYWdlQ21wLmNvbnN0cnVjdG9yIiwiTm9QcmVmaXhTaWJsaW5nUGFnZUNtcCIsIk5vUHJlZml4U2libGluZ1BhZ2VDbXAuY29uc3RydWN0b3IiLCJIZWxsb0NtcCIsIkhlbGxvQ21wLmNvbnN0cnVjdG9yIiwiSGVsbG8yQ21wIiwiSGVsbG8yQ21wLmNvbnN0cnVjdG9yIiwicGFyZW50Q21wTG9hZGVyIiwiUGFyZW50Q21wIiwiUGFyZW50Q21wLmNvbnN0cnVjdG9yIiwiQm9va0NtcCIsIkJvb2tDbXAuY29uc3RydWN0b3IiLCJOb1ByZWZpeEJvb2tDbXAiLCJOb1ByZWZpeEJvb2tDbXAuY29uc3RydWN0b3IiLCJBbWJpZ3VvdXNCb29rQ21wIiwiQW1iaWd1b3VzQm9va0NtcC5jb25zdHJ1Y3RvciIsIkF1eExpbmtDbXAiLCJBdXhMaW5rQ21wLmNvbnN0cnVjdG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxpQ0FpQk8sMkJBQTJCLENBQUMsQ0FBQTtBQUVuQywyQkFBaUIsOEJBQThCLENBQUMsQ0FBQTtBQUNoRCxxQkFBNEIsMEJBQTBCLENBQUMsQ0FBQTtBQUN2RCxzQkFBNkIsMkJBQTJCLENBQUMsQ0FBQTtBQUN6RCwyQkFBMEIsZ0NBQWdDLENBQUMsQ0FBQTtBQUUzRCxxQkFBb0QsZUFBZSxDQUFDLENBQUE7QUFFcEUsOEJBQTBCLGlDQUFpQyxDQUFDLENBQUE7QUFDNUQsdUJBYU8saUJBQWlCLENBQUMsQ0FBQTtBQUN6Qix1QkFBeUIsNEJBQTRCLENBQUMsQ0FBQTtBQUV0RCw0QkFBa0IsdUNBQXVDLENBQUMsQ0FBQTtBQUMxRCx5QkFBa0MsbUJBQW1CLENBQUMsQ0FBQTtBQUN0RCxzQ0FBa0Msc0RBQXNELENBQUMsQ0FBQTtBQUV6RjtJQUNFQSwyQkFBUUEsQ0FBQ0Esc0JBQXNCQSxFQUFFQTtRQUMvQixJQUFJLEdBQXlCLENBQUM7UUFDOUIsSUFBSSxPQUF5QixDQUFDO1FBQzlCLElBQUksTUFBYyxDQUFDO1FBQ25CLElBQUksUUFBa0IsQ0FBQztRQUV2QixzQ0FBbUIsQ0FBQyxjQUFNLE9BQUE7WUFDeEIsc0JBQWE7WUFDYix3QkFBaUI7WUFDakIsY0FBTyxDQUFDLGlCQUFRLEVBQUUsRUFBQyxRQUFRLEVBQUUsMkJBQVcsRUFBQyxDQUFDO1lBQzFDLGNBQU8sQ0FBQyxpQ0FBd0IsRUFBRSxFQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUMsQ0FBQztZQUNyRCxjQUFPLENBQUMsZUFBTSxFQUFFLEVBQUMsUUFBUSxFQUFFLG1CQUFVLEVBQUMsQ0FBQztZQUN2QyxjQUFPLENBQUMsOEJBQW1CLEVBQUUsRUFBQyxRQUFRLEVBQUUsMkNBQW1CLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBQyxDQUFDO1NBQzNFLEVBUHlCLENBT3pCLENBQUMsQ0FBQztRQUVILDZCQUFVLENBQUMseUJBQU0sQ0FBQyxDQUFDLHVDQUFvQixFQUFFLGVBQU0sRUFBRSxpQkFBUSxDQUFDLEVBQ3hDLFVBQUMsU0FBUyxFQUFFLEdBQVcsRUFBRSxHQUFhO1lBQ3BDLEdBQUcsR0FBRyxTQUFTLENBQUM7WUFDaEIsTUFBTSxHQUFHLEdBQUcsQ0FBQztZQUNiLFFBQVEsR0FBRyxHQUFHLENBQUM7UUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV0QixpQkFBaUIsUUFBb0Q7WUFBcERDLHdCQUFvREEsR0FBcERBLDRDQUFvREE7WUFDbkVBLE1BQU1BLENBQUNBLEdBQUdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0EsT0FBT0EsR0FBR0EsUUFBUUEsR0FBR0EsUUFBUUEsQ0FBQ0EsQ0FBQ0E7aUJBQy9EQSxXQUFXQSxDQUFDQSxNQUFNQSxDQUFDQTtpQkFDbkJBLElBQUlBLENBQUNBLFVBQUNBLEVBQUVBLElBQU9BLE9BQU9BLEdBQUdBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ3ZDQSxDQUFDQTtRQUVELHFCQUFFLENBQUMsMkRBQTJELEVBQzNELHlCQUFNLENBQUMsQ0FBQyxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsS0FBSztZQUNuQixRQUFTLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ2hELE9BQU8sQ0FBQyxrREFBa0QsQ0FBQztpQkFDdEQsSUFBSSxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsTUFBTSxDQUFDLE1BQU0sQ0FDaEIsQ0FBQyxJQUFJLGNBQUssQ0FBQyxFQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBRDVELENBQzRELENBQUM7aUJBQ3pFLElBQUksQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEVBQTVCLENBQTRCLENBQUM7aUJBQ3pDLElBQUksQ0FBQyxVQUFDLENBQUM7Z0JBQ04sT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUN4Qix5QkFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQztnQkFDbEQsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBR1AscUJBQUUsQ0FBQywyQ0FBMkMsRUFBRSx5QkFBTSxDQUFDLENBQUMscUNBQWtCLENBQUMsRUFBRSxVQUFDLEtBQUs7WUFDOUUsT0FBTyxDQUFDLGtEQUFrRCxDQUFDO2lCQUN0RCxJQUFJLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxNQUFNLENBQUMsTUFBTSxDQUNoQixDQUFDLElBQUksY0FBSyxDQUFDLEVBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFENUQsQ0FDNEQsQ0FBQztpQkFDekUsSUFBSSxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsTUFBTSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsRUFBNUIsQ0FBNEIsQ0FBQztpQkFDekMsSUFBSSxDQUFDLFVBQUMsQ0FBQztnQkFDTixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3hCLHlCQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMxQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDZixDQUFDLENBQUMsQ0FBQztRQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7UUFHUCxxQkFBRSxDQUFDLHdDQUF3QyxFQUFFLHlCQUFNLENBQUMsQ0FBQyxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsS0FBSztZQUMzRSxPQUFPLENBQUMsd0VBQXdFLENBQUM7aUJBQzVFLElBQUksQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLE1BQU0sQ0FBQyxNQUFNLENBQ2hCLENBQUMsSUFBSSxjQUFLLENBQUMsRUFBQyxJQUFJLEVBQUUsYUFBYSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBQyxDQUFDLENBQUMsQ0FBQyxFQURsRSxDQUNrRSxDQUFDO2lCQUMvRSxJQUFJLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxNQUFNLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxFQUE1QixDQUE0QixDQUFDO2lCQUN6QyxJQUFJLENBQUMsVUFBQyxDQUFDO2dCQUNOLE9BQU8sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQztnQkFDdEQsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUN4Qix5QkFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMvRCx5QkFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDaEQsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRVAscUJBQUUsQ0FBQyx3REFBd0QsRUFDeEQseUJBQU0sQ0FBQyxDQUFDLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxLQUFLO1lBQ2pDLE9BQU8sRUFBRTtpQkFDSixJQUFJLENBQ0QsVUFBQyxDQUFDLElBQUssT0FBQSxNQUFNLENBQUMsTUFBTSxDQUNoQixDQUFDLElBQUksY0FBSyxDQUFDLEVBQUMsSUFBSSxFQUFFLGVBQWUsRUFBRSxTQUFTLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFEM0UsQ0FDMkUsQ0FBQztpQkFDdEYsSUFBSSxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsTUFBTSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsRUFBL0IsQ0FBK0IsQ0FBQztpQkFDNUMsSUFBSSxDQUFDLFVBQUMsQ0FBQztnQkFDTixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3hCLHlCQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUM1QyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDZixDQUFDLENBQUMsQ0FBQztRQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFUCxxQkFBRSxDQUFDLDhFQUE4RSxFQUM5RSx5QkFBTSxDQUFDLENBQUMscUNBQWtCLENBQUMsRUFBRSxVQUFDLEtBQUs7WUFDakMsT0FBTyxFQUFFO2lCQUNKLElBQUksQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLE1BQU0sQ0FBQyxNQUFNLENBQUM7Z0JBQ3pCLElBQUksY0FBSyxDQUNMLEVBQUMsSUFBSSxFQUFFLGVBQWUsRUFBRSxTQUFTLEVBQUUsc0JBQXNCLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBQyxDQUFDO2FBQzlFLENBQUMsRUFIVyxDQUdYLENBQUM7aUJBQ0YsSUFBSSxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsTUFBTSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsRUFBL0IsQ0FBK0IsQ0FBQztpQkFDNUMsSUFBSSxDQUFDLFVBQUMsQ0FBQztnQkFDTixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3hCLHlCQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUM1QyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDZixDQUFDLENBQUMsQ0FBQztRQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFUCxxQkFBRSxDQUFDLDZEQUE2RCxFQUM3RCx5QkFBTSxDQUFDLENBQUMscUNBQWtCLENBQUMsRUFBRSxVQUFDLEtBQUs7WUFDakMsT0FBTyxFQUFFO2lCQUNKLElBQUksQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLE1BQU0sQ0FBQyxNQUFNLENBQUM7Z0JBQ3pCLElBQUksY0FBSyxDQUFDLEVBQUMsSUFBSSxFQUFFLGtCQUFrQixFQUFFLFNBQVMsRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBQyxDQUFDO2FBQ2hGLENBQUMsRUFGVyxDQUVYLENBQUM7aUJBQ0YsSUFBSSxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsTUFBTSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxFQUF6QyxDQUF5QyxDQUFDO2lCQUN0RCxJQUFJLENBQUMsVUFBQyxDQUFDO2dCQUNOLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDeEIseUJBQU0sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQztnQkFDeEQsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRVAscUJBQUUsQ0FBQywrREFBK0QsRUFDL0QseUJBQU0sQ0FBQyxDQUFDLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxLQUFLO1lBQ2pDLE9BQU8sRUFBRTtpQkFDSixJQUFJLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxNQUFNLENBQUMsTUFBTSxDQUFDO2dCQUN6QixJQUFJLGNBQUssQ0FBQyxFQUFDLElBQUksRUFBRSxrQkFBa0IsRUFBRSxTQUFTLEVBQUUsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBQyxDQUFDO2FBQ2pGLENBQUMsRUFGVyxDQUVYLENBQUM7aUJBQ0YsSUFBSSxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsTUFBTSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxFQUF6QyxDQUF5QyxDQUFDO2lCQUN0RCxJQUFJLENBQUMsVUFBQyxDQUFDO2dCQUNOLElBQUksSUFBSSxHQUFHLHdCQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUMsTUFBTSxFQUFFLEdBQUcsRUFBQyxDQUFDLENBQUMsQ0FBQztnQkFDdkQseUJBQU0sQ0FBQyxjQUFNLE9BQUEsT0FBTyxDQUFDLGFBQWEsRUFBRSxFQUF2QixDQUF1QixDQUFDO3FCQUNoQyxnQkFBZ0IsQ0FDYixZQUFTLElBQUksNERBQW9ELENBQUMsQ0FBQztnQkFDM0UsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRVAscUJBQUUsQ0FBQyx1REFBdUQsRUFDdkQseUJBQU0sQ0FBQyxDQUFDLHFDQUFrQixDQUFDLEVBQUUsVUFBQyxLQUFLO1lBQ2pDLE9BQU8sRUFBRTtpQkFDSixJQUFJLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxNQUFNLENBQUMsTUFBTSxDQUFDO2dCQUN6QixJQUFJLG1CQUFVLENBQUM7b0JBQ2IsSUFBSSxFQUFFLDRCQUE0QjtvQkFDbEMsTUFBTSxFQUFFLGVBQWU7b0JBQ3ZCLElBQUksRUFBRSxxQkFBcUI7aUJBQzVCLENBQUM7YUFDSCxDQUFDLEVBTlcsQ0FNWCxDQUFDO2lCQUNGLElBQUksQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLE1BQU0sQ0FBQyxhQUFhLENBQUMsbUNBQW1DLENBQUMsRUFBekQsQ0FBeUQsQ0FBQztpQkFDdEUsSUFBSSxDQUFDLFVBQUMsQ0FBQztnQkFDTixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3hCLHlCQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLG1DQUFtQyxDQUFDLENBQUM7Z0JBQ3RFLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNmLENBQUMsQ0FBQyxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVQLHFCQUFFLENBQUMscUVBQXFFLEVBQ3JFLHlCQUFNLENBQUMsQ0FBQyxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsS0FBSztZQUNqQyxPQUFPLEVBQUU7aUJBQ0osSUFBSSxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsTUFBTSxDQUFDLE1BQU0sQ0FDaEIsQ0FBQyxJQUFJLGNBQUssQ0FBQyxFQUFDLElBQUksRUFBRSxrQkFBa0IsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFEdkUsQ0FDdUUsQ0FBQztpQkFDcEYsSUFBSSxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsTUFBTSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxFQUF6QyxDQUF5QyxDQUFDO2lCQUN0RCxJQUFJLENBQUMsVUFBQyxDQUFDO2dCQUNOLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDeEIsK0VBQStFO2dCQUMvRSxVQUFVO2dCQUNWLG9DQUFvQztnQkFDcEMseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxlQUFFLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO3FCQUN6QyxLQUFLLENBQUMsZUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztxQkFDbEIsYUFBYSxFQUNsQixNQUFNLENBQUMsQ0FBQztxQkFDM0IsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUM7Z0JBRXBDLHlCQUFNLENBQUMsaUJBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsZUFBRSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQztxQkFDekMsS0FBSyxDQUFDLGVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7cUJBQ2xCLGFBQWEsRUFDbEIsTUFBTSxDQUFDLENBQUM7cUJBQzNCLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO2dCQUNsQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDZixDQUFDLENBQUMsQ0FBQztRQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFUCxxQkFBRSxDQUFDLDJDQUEyQyxFQUFFLHlCQUFNLENBQUMsQ0FBQyxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsS0FBSztZQUM5RSxPQUFPLEVBQUU7aUJBQ0osSUFBSSxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksY0FBSyxDQUFDLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQWpFLENBQWlFLENBQUM7aUJBQzlFLElBQUksQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLE1BQU0sQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEVBQXpCLENBQXlCLENBQUM7aUJBQ3RDLElBQUksQ0FBQyxVQUFDLENBQUM7Z0JBQ04sT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUN4Qix5QkFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDN0MsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBR1AsMkJBQVEsQ0FBQyw4QkFBOEIsRUFBRTtZQUN2QyxxQkFBRSxDQUFDLDJDQUEyQyxFQUFFLHlCQUFNLENBQUMsQ0FBQyxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsS0FBSztnQkFDOUUsTUFBTSxDQUFDLE1BQU0sQ0FBQztvQkFDTixJQUFJLGNBQUssQ0FBQyxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFDLENBQUM7b0JBQy9ELElBQUksY0FBSyxDQUFDLEVBQUMsSUFBSSxFQUFFLGVBQWUsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUMsQ0FBQztpQkFDOUUsQ0FBQztxQkFDSCxJQUFJLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxPQUFPLENBQUMscVBBRTRCLENBQUMsRUFGckMsQ0FFcUMsQ0FBQztxQkFDbEQsSUFBSSxDQUFDLFVBQUMsQ0FBQztvQkFDTixJQUFJLE9BQU8sR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQztvQkFFakQsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUV4QixJQUFJLEtBQUssR0FBRyxpQkFBRyxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDLENBQUM7b0JBQ3RELElBQUksS0FBSyxHQUFHLGlCQUFHLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO29CQUU3RCx5QkFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsQ0FBQztvQkFDdkQseUJBQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLG9CQUFvQixDQUFDLENBQUM7b0JBRXZELE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBQyxDQUFDO3dCQUNqQixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7d0JBRXhCLHlCQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO3dCQUN2RCx5QkFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO3dCQUVuRCxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2YsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsTUFBTSxDQUFDLGFBQWEsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO2dCQUNoRCxDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFUCxxQkFBRSxDQUFDLDBDQUEwQyxFQUFFLHlCQUFNLENBQUMsQ0FBQyxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsS0FBSztnQkFDN0UsTUFBTSxDQUFDLE1BQU0sQ0FBQztvQkFDTixJQUFJLGNBQUssQ0FBQyxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFDLENBQUM7b0JBQy9ELElBQUksY0FBSyxDQUFDO3dCQUNSLElBQUksRUFBRSw0QkFBNEI7d0JBQ2xDLFNBQVMsRUFBRSxTQUFTO3dCQUNwQixJQUFJLEVBQUUscUJBQXFCO3FCQUM1QixDQUFDO2lCQUNILENBQUM7cUJBQ0gsSUFBSSxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsT0FBTyxDQUFDLGlSQUU0QixDQUFDLEVBRnJDLENBRXFDLENBQUM7cUJBQ2xELElBQUksQ0FBQyxVQUFDLENBQUM7b0JBQ04sSUFBSSxPQUFPLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUM7b0JBRWpELE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFFeEIsSUFBSSxLQUFLLEdBQUcsaUJBQUcsQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxDQUFDO29CQUN0RCxJQUFJLEtBQUssR0FBRyxpQkFBRyxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsNkJBQTZCLENBQUMsQ0FBQztvQkFFdEUseUJBQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLG9CQUFvQixDQUFDLENBQUM7b0JBQ3ZELHlCQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO29CQUV2RCxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQUMsQ0FBQzt3QkFDakIsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO3dCQUV4Qix5QkFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsQ0FBQzt3QkFDdkQseUJBQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsQ0FBQzt3QkFFbkQsSUFBSSxLQUFLLEdBQUcsaUJBQUcsQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLGtCQUFrQixDQUFDLENBQUM7d0JBQzNELElBQUksS0FBSyxHQUFHLGlCQUFHLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSx5QkFBeUIsQ0FBQyxDQUFDO3dCQUVsRSx5QkFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO3dCQUNuRCx5QkFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsQ0FBQzt3QkFFdkQsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNmLENBQUMsQ0FBQyxDQUFDO29CQUNILE1BQU0sQ0FBQyxhQUFhLENBQUMsMkNBQTJDLENBQUMsQ0FBQztnQkFDcEUsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBR1AsMkJBQVEsQ0FBQyxpQkFBaUIsRUFBRTtnQkFDMUIscUJBQUUsQ0FBQyx3Q0FBd0MsRUFBRSx5QkFBTSxDQUFDLENBQUMscUNBQWtCLENBQUMsRUFBRSxVQUFDLEtBQUs7b0JBQzNFLE9BQU8sQ0FBQyxzRUFBc0UsQ0FBQzt5QkFDMUUsSUFBSSxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsTUFBTSxDQUFDLE1BQU0sQ0FDaEIsQ0FBQyxJQUFJLGNBQUssQ0FBQyxFQUFDLElBQUksRUFBRSxhQUFhLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBRGxFLENBQ2tFLENBQUM7eUJBQy9FLElBQUksQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEVBQTVCLENBQTRCLENBQUM7eUJBQ3pDLElBQUksQ0FBQyxVQUFDLENBQUM7d0JBQ04sT0FBTyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDO3dCQUN0RCxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7d0JBQ3hCLHlCQUFNLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7d0JBQy9ELHlCQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO3dCQUNoRCxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2YsQ0FBQyxDQUFDLENBQUM7Z0JBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNULENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCwyQkFBUSxDQUFDLGNBQWMsRUFBRTtZQUV2QixJQUFJLGNBQWMsR0FBRyxVQUFTLElBQUk7Z0JBQ2hDLElBQUksUUFBUSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLGVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0JBQ3JFLElBQUksZUFBZSxHQUFHLGlCQUFHLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ3BELGlCQUFHLENBQUMsYUFBYSxDQUFDLFFBQVEsRUFBRSxlQUFlLENBQUMsQ0FBQztnQkFDN0MsTUFBTSxDQUFDLGVBQWUsQ0FBQztZQUN6QixDQUFDLENBQUM7WUFFRixxQkFBRSxDQUFDLDhDQUE4QyxFQUFFLHlCQUFNLENBQUMsQ0FBQyxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsS0FBSztnQkFDakYsT0FBTyxDQUFDLGtEQUFrRCxDQUFDO3FCQUN0RCxJQUFJLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxNQUFNLENBQUMsTUFBTSxDQUNoQixDQUFDLElBQUksY0FBSyxDQUFDLEVBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFENUQsQ0FDNEQsQ0FBQztxQkFDekUsSUFBSSxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsTUFBTSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsRUFBNUIsQ0FBNEIsQ0FBQztxQkFDekMsSUFBSSxDQUFDLFVBQUMsQ0FBQztvQkFDTixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBRXhCLElBQUksZUFBZSxHQUFHLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDOUMseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFFcEQsOEJBQThCO29CQUM5QixNQUFNLENBQUMsU0FBUyxDQUFDLFVBQUMsQ0FBQzt3QkFDakIseUJBQU0sQ0FBZSxRQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzt3QkFDOUQsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNmLENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVQLHFCQUFFLENBQUMsd0RBQXdELEVBQ3hELHlCQUFNLENBQUMsQ0FBQyxxQ0FBa0IsQ0FBQyxFQUFFLFVBQUMsS0FBSztnQkFDbkIsUUFBUyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDN0MsT0FBTyxDQUFDLGtEQUFrRCxDQUFDO3FCQUN0RCxJQUFJLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxNQUFNLENBQUMsTUFBTSxDQUNoQixDQUFDLElBQUksY0FBSyxDQUFDLEVBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFENUQsQ0FDNEQsQ0FBQztxQkFDekUsSUFBSSxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsTUFBTSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsRUFBNUIsQ0FBNEIsQ0FBQztxQkFDekMsSUFBSSxDQUFDLFVBQUMsQ0FBQztvQkFDTixPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBR3hCLElBQUksZUFBZSxHQUFHLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDOUMseUJBQU0sQ0FBQyxpQkFBRyxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFFcEQsOEJBQThCO29CQUM5QixNQUFNLENBQUMsU0FBUyxDQUFDLFVBQUMsQ0FBQzt3QkFDakIseUJBQU0sQ0FBZSxRQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQzt3QkFDbkUsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNmLENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNULENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDRCxDQUFDQTtBQUNMQSxDQUFDQTtBQXhVZSxZQUFJLE9Bd1VuQixDQUFBO0FBRUQsaUJBQWlCLEVBQW9CO0lBQ25DRSxNQUFNQSxDQUFDQSxpQkFBR0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsZUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsYUFBYUEsRUFBRUEsTUFBTUEsQ0FBQ0EsQ0FBQ0E7QUFDcEZBLENBQUNBO0FBRUQ7SUFBQUM7SUFHQUMsQ0FBQ0E7SUFIREQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLFNBQVNBLEVBQUVBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUVBLFVBQVVBLEVBQUVBLENBQUNBLDBCQUFpQkEsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7O2VBRy9FQTtJQUFEQSxhQUFDQTtBQUFEQSxDQUFDQSxBQUhELElBR0M7QUFFRDtJQUdFRSxpQkFBWUEsTUFBbUJBO1FBQUlDLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLE1BQU1BLENBQUNBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBSHRFRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsVUFBVUEsRUFBRUEsUUFBUUEsRUFBRUEsZ0JBQWdCQSxFQUFDQSxDQUFDQTs7Z0JBSTdEQTtJQUFEQSxjQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFFRDtJQVNFRSx3QkFBWUEsTUFBbUJBO1FBQzdCQyxJQUFJQSxDQUFDQSxVQUFVQSxHQUFHQSxvQkFBYUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsRUFBRUEsRUFBRUEsQ0FBQ0EsQ0FBQ0E7UUFDbkVBLElBQUlBLENBQUNBLFFBQVFBLEdBQUdBLElBQUlBLENBQUNBLFVBQVVBLEdBQUdBLENBQUNBLENBQUNBO0lBQ3RDQSxDQUFDQTtJQVpIRDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsVUFBVUE7WUFDcEJBLFFBQVFBLEVBQ0pBLG9HQUFrR0E7WUFDdEdBLFVBQVVBLEVBQUVBLENBQUNBLG1CQUFVQSxDQUFDQTtTQUN6QkEsQ0FBQ0E7O3VCQVFEQTtJQUFEQSxxQkFBQ0E7QUFBREEsQ0FBQ0EsQUFiRCxJQWFDO0FBRUQ7SUFTRUUsZ0NBQVlBLE1BQW1CQTtRQUM3QkMsSUFBSUEsQ0FBQ0EsVUFBVUEsR0FBR0Esb0JBQWFBLENBQUNBLFFBQVFBLENBQUNBLE1BQU1BLENBQUNBLEdBQUdBLENBQUNBLFFBQVFBLENBQUNBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBO1FBQ25FQSxJQUFJQSxDQUFDQSxRQUFRQSxHQUFHQSxJQUFJQSxDQUFDQSxVQUFVQSxHQUFHQSxDQUFDQSxDQUFDQTtJQUN0Q0EsQ0FBQ0E7SUFaSEQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLFVBQVVBO1lBQ3BCQSxRQUFRQSxFQUNKQSxpR0FBK0ZBO1lBQ25HQSxVQUFVQSxFQUFFQSxDQUFDQSxtQkFBVUEsQ0FBQ0E7U0FDekJBLENBQUNBOzsrQkFRREE7SUFBREEsNkJBQUNBO0FBQURBLENBQUNBLEFBYkQsSUFhQztBQUVEO0lBQUFFO0lBRUFDLENBQUNBO0lBRkREO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxXQUFXQSxFQUFFQSxRQUFRQSxFQUFFQSxPQUFPQSxFQUFDQSxDQUFDQTs7aUJBRXJEQTtJQUFEQSxlQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUM7QUFFRDtJQUFBRTtJQUVBQyxDQUFDQTtJQUZERDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsWUFBWUEsRUFBRUEsUUFBUUEsRUFBRUEsUUFBUUEsRUFBQ0EsQ0FBQ0E7O2tCQUV2REE7SUFBREEsZ0JBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBQ0VFLE1BQU1BLENBQUNBLHNCQUFjQSxDQUFDQSxPQUFPQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQTtBQUMzQ0EsQ0FBQ0E7QUFFRDtJQUFBQztJQVlBQyxDQUFDQTtJQVpERDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsWUFBWUE7WUFDdEJBLFFBQVFBLEVBQUVBLHFQQUVxQ0E7WUFDL0NBLFVBQVVBLEVBQUVBLDBCQUFpQkE7U0FDOUJBLENBQUNBO1FBQ0RBLG9CQUFXQSxDQUFDQTtZQUNYQSxJQUFJQSxjQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxhQUFhQSxFQUFFQSxTQUFTQSxFQUFFQSxRQUFRQSxFQUFFQSxJQUFJQSxFQUFFQSxZQUFZQSxFQUFDQSxDQUFDQTtZQUN6RUEsSUFBSUEsY0FBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsb0JBQW9CQSxFQUFFQSxTQUFTQSxFQUFFQSxTQUFTQSxFQUFFQSxJQUFJQSxFQUFFQSxrQkFBa0JBLEVBQUNBLENBQUNBO1NBQ3hGQSxDQUFDQTs7a0JBRURBO0lBQURBLGdCQUFDQTtBQUFEQSxDQUFDQSxBQVpELElBWUM7QUFFRDtJQVNFRSxpQkFBWUEsTUFBbUJBO1FBQUlDLElBQUlBLENBQUNBLEtBQUtBLEdBQUdBLE1BQU1BLENBQUNBLEdBQUdBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBVHhFRDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsVUFBVUE7WUFDcEJBLFFBQVFBLEVBQUVBLG1IQUN3QkE7WUFDbENBLFVBQVVBLEVBQUVBLDBCQUFpQkE7U0FDOUJBLENBQUNBO1FBQ0RBLG9CQUFXQSxDQUFDQSxDQUFDQSxJQUFJQSxjQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxlQUFlQSxFQUFFQSxTQUFTQSxFQUFFQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxNQUFNQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTs7Z0JBSTFGQTtJQUFEQSxjQUFDQTtBQUFEQSxDQUFDQSxBQVZELElBVUM7QUFFRDtJQVNFRSx5QkFBWUEsTUFBbUJBO1FBQUlDLElBQUlBLENBQUNBLEtBQUtBLEdBQUdBLE1BQU1BLENBQUNBLEdBQUdBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBVHhFRDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsVUFBVUE7WUFDcEJBLFFBQVFBLEVBQUVBLGlIQUN3QkE7WUFDbENBLFVBQVVBLEVBQUVBLDBCQUFpQkE7U0FDOUJBLENBQUNBO1FBQ0RBLG9CQUFXQSxDQUFDQSxDQUFDQSxJQUFJQSxjQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxlQUFlQSxFQUFFQSxTQUFTQSxFQUFFQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxNQUFNQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTs7d0JBSTFGQTtJQUFEQSxzQkFBQ0E7QUFBREEsQ0FBQ0EsQUFWRCxJQVVDO0FBRUQ7SUFTRUUsMEJBQVlBLE1BQW1CQTtRQUFJQyxJQUFJQSxDQUFDQSxLQUFLQSxHQUFHQSxNQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtJQUFDQSxDQUFDQTtJQVR4RUQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLFVBQVVBO1lBQ3BCQSxRQUFRQSxFQUFFQSxpSEFDd0JBO1lBQ2xDQSxVQUFVQSxFQUFFQSwwQkFBaUJBO1NBQzlCQSxDQUFDQTtRQUNEQSxvQkFBV0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsY0FBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsZUFBZUEsRUFBRUEsU0FBU0EsRUFBRUEsY0FBY0EsRUFBRUEsSUFBSUEsRUFBRUEsTUFBTUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7O3lCQUkxRkE7SUFBREEsdUJBQUNBO0FBQURBLENBQUNBLEFBVkQsSUFVQztBQUVEO0lBQUFFO0lBWUFDLENBQUNBO0lBWkREO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxTQUFTQTtZQUNuQkEsUUFBUUEsRUFDSkEsdUpBQ21GQTtZQUN2RkEsVUFBVUEsRUFBRUEsMEJBQWlCQTtTQUM5QkEsQ0FBQ0E7UUFDREEsb0JBQVdBLENBQUNBO1lBQ1hBLElBQUlBLGNBQUtBLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLEdBQUdBLEVBQUVBLFNBQVNBLEVBQUVBLFFBQVFBLEVBQUVBLElBQUlBLEVBQUVBLE9BQU9BLEVBQUNBLENBQUNBO1lBQzFEQSxJQUFJQSxpQkFBUUEsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsUUFBUUEsRUFBRUEsU0FBU0EsRUFBRUEsU0FBU0EsRUFBRUEsSUFBSUEsRUFBRUEsT0FBT0EsRUFBQ0EsQ0FBQ0E7U0FDcEVBLENBQUNBOzttQkFFREE7SUFBREEsaUJBQUNBO0FBQURBLENBQUNBLEFBWkQsSUFZQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIENvbXBvbmVudEZpeHR1cmUsXG4gIEFzeW5jVGVzdENvbXBsZXRlcixcbiAgYmVmb3JlRWFjaCxcbiAgZGRlc2NyaWJlLFxuICB4ZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICBkaXNwYXRjaEV2ZW50LFxuICBleHBlY3QsXG4gIGlpdCxcbiAgaW5qZWN0LFxuICBiZWZvcmVFYWNoUHJvdmlkZXJzLFxuICBpdCxcbiAgeGl0LFxuICBUZXN0Q29tcG9uZW50QnVpbGRlcixcbiAgcHJveHksXG4gIFNweU9iamVjdFxufSBmcm9tICdhbmd1bGFyMi90ZXN0aW5nX2ludGVybmFsJztcblxuaW1wb3J0IHtCeX0gZnJvbSAnYW5ndWxhcjIvcGxhdGZvcm0vY29tbW9uX2RvbSc7XG5pbXBvcnQge051bWJlcldyYXBwZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvbGFuZyc7XG5pbXBvcnQge1Byb21pc2VXcmFwcGVyfSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2FzeW5jJztcbmltcG9ydCB7TGlzdFdyYXBwZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvY29sbGVjdGlvbic7XG5cbmltcG9ydCB7cHJvdmlkZSwgQ29tcG9uZW50LCBEaXJlY3RpdmVSZXNvbHZlcn0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5cbmltcG9ydCB7U3B5TG9jYXRpb259IGZyb20gJ2FuZ3VsYXIyL3NyYy9tb2NrL2xvY2F0aW9uX21vY2snO1xuaW1wb3J0IHtcbiAgTG9jYXRpb24sXG4gIFJvdXRlcixcbiAgUm91dGVSZWdpc3RyeSxcbiAgUm91dGVyTGluayxcbiAgUm91dGVyT3V0bGV0LFxuICBBc3luY1JvdXRlLFxuICBBdXhSb3V0ZSxcbiAgUm91dGUsXG4gIFJvdXRlUGFyYW1zLFxuICBSb3V0ZUNvbmZpZyxcbiAgUk9VVEVSX0RJUkVDVElWRVMsXG4gIFJPVVRFUl9QUklNQVJZX0NPTVBPTkVOVFxufSBmcm9tICdhbmd1bGFyMi9yb3V0ZXInO1xuaW1wb3J0IHtSb290Um91dGVyfSBmcm9tICdhbmd1bGFyMi9zcmMvcm91dGVyL3JvdXRlcic7XG5cbmltcG9ydCB7RE9NfSBmcm9tICdhbmd1bGFyMi9zcmMvcGxhdGZvcm0vZG9tL2RvbV9hZGFwdGVyJztcbmltcG9ydCB7VEVNUExBVEVfVFJBTlNGT1JNU30gZnJvbSAnYW5ndWxhcjIvY29tcGlsZXInO1xuaW1wb3J0IHtSb3V0ZXJMaW5rVHJhbnNmb3JtfSBmcm9tICdhbmd1bGFyMi9zcmMvcm91dGVyL2RpcmVjdGl2ZXMvcm91dGVyX2xpbmtfdHJhbnNmb3JtJztcblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGRlc2NyaWJlKCdyb3V0ZXJMaW5rIGRpcmVjdGl2ZScsIGZ1bmN0aW9uKCkge1xuICAgIHZhciB0Y2I6IFRlc3RDb21wb25lbnRCdWlsZGVyO1xuICAgIHZhciBmaXh0dXJlOiBDb21wb25lbnRGaXh0dXJlO1xuICAgIHZhciByb3V0ZXI6IFJvdXRlcjtcbiAgICB2YXIgbG9jYXRpb246IExvY2F0aW9uO1xuXG4gICAgYmVmb3JlRWFjaFByb3ZpZGVycygoKSA9PiBbXG4gICAgICBSb3V0ZVJlZ2lzdHJ5LFxuICAgICAgRGlyZWN0aXZlUmVzb2x2ZXIsXG4gICAgICBwcm92aWRlKExvY2F0aW9uLCB7dXNlQ2xhc3M6IFNweUxvY2F0aW9ufSksXG4gICAgICBwcm92aWRlKFJPVVRFUl9QUklNQVJZX0NPTVBPTkVOVCwge3VzZVZhbHVlOiBNeUNvbXB9KSxcbiAgICAgIHByb3ZpZGUoUm91dGVyLCB7dXNlQ2xhc3M6IFJvb3RSb3V0ZXJ9KSxcbiAgICAgIHByb3ZpZGUoVEVNUExBVEVfVFJBTlNGT1JNUywge3VzZUNsYXNzOiBSb3V0ZXJMaW5rVHJhbnNmb3JtLCBtdWx0aTogdHJ1ZX0pXG4gICAgXSk7XG5cbiAgICBiZWZvcmVFYWNoKGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIFJvdXRlciwgTG9jYXRpb25dLFxuICAgICAgICAgICAgICAgICAgICAgICh0Y0J1aWxkZXIsIHJ0cjogUm91dGVyLCBsb2M6IExvY2F0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0Y2IgPSB0Y0J1aWxkZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICByb3V0ZXIgPSBydHI7XG4gICAgICAgICAgICAgICAgICAgICAgICBsb2NhdGlvbiA9IGxvYztcbiAgICAgICAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICBmdW5jdGlvbiBjb21waWxlKHRlbXBsYXRlOiBzdHJpbmcgPSBcIjxyb3V0ZXItb3V0bGV0Pjwvcm91dGVyLW91dGxldD5cIikge1xuICAgICAgcmV0dXJuIHRjYi5vdmVycmlkZVRlbXBsYXRlKE15Q29tcCwgKCc8ZGl2PicgKyB0ZW1wbGF0ZSArICc8L2Rpdj4nKSlcbiAgICAgICAgICAuY3JlYXRlQXN5bmMoTXlDb21wKVxuICAgICAgICAgIC50aGVuKCh0YykgPT4geyBmaXh0dXJlID0gdGM7IH0pO1xuICAgIH1cblxuICAgIGl0KCdzaG91bGQgZ2VuZXJhdGUgYWJzb2x1dGUgaHJlZnMgdGhhdCBpbmNsdWRlIHRoZSBiYXNlIGhyZWYnLFxuICAgICAgIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICAoPFNweUxvY2F0aW9uPmxvY2F0aW9uKS5zZXRCYXNlSHJlZignL215L2Jhc2UnKTtcbiAgICAgICAgIGNvbXBpbGUoJzxhIGhyZWY9XCJoZWxsb1wiIFtyb3V0ZXJMaW5rXT1cIltcXCcuL1VzZXJcXCddXCI+PC9hPicpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJvdXRlci5jb25maWcoXG4gICAgICAgICAgICAgICAgICAgICAgIFtuZXcgUm91dGUoe3BhdGg6ICcvdXNlcicsIGNvbXBvbmVudDogVXNlckNtcCwgbmFtZTogJ1VzZXInfSldKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcm91dGVyLm5hdmlnYXRlQnlVcmwoJy9hL2InKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICBleHBlY3QoZ2V0SHJlZihmaXh0dXJlKSkudG9FcXVhbCgnL215L2Jhc2UvdXNlcicpO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuXG4gICAgaXQoJ3Nob3VsZCBnZW5lcmF0ZSBsaW5rIGhyZWZzIHdpdGhvdXQgcGFyYW1zJywgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgIGNvbXBpbGUoJzxhIGhyZWY9XCJoZWxsb1wiIFtyb3V0ZXJMaW5rXT1cIltcXCcuL1VzZXJcXCddXCI+PC9hPicpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJvdXRlci5jb25maWcoXG4gICAgICAgICAgICAgICAgICAgICAgIFtuZXcgUm91dGUoe3BhdGg6ICcvdXNlcicsIGNvbXBvbmVudDogVXNlckNtcCwgbmFtZTogJ1VzZXInfSldKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcm91dGVyLm5hdmlnYXRlQnlVcmwoJy9hL2InKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICBleHBlY3QoZ2V0SHJlZihmaXh0dXJlKSkudG9FcXVhbCgnL3VzZXInKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cblxuICAgIGl0KCdzaG91bGQgZ2VuZXJhdGUgbGluayBocmVmcyB3aXRoIHBhcmFtcycsIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICBjb21waWxlKCc8YSBocmVmPVwiaGVsbG9cIiBbcm91dGVyTGlua109XCJbXFwnLi9Vc2VyXFwnLCB7bmFtZTogbmFtZX1dXCI+e3tuYW1lfX08L2E+JylcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcm91dGVyLmNvbmZpZyhcbiAgICAgICAgICAgICAgICAgICAgICAgW25ldyBSb3V0ZSh7cGF0aDogJy91c2VyLzpuYW1lJywgY29tcG9uZW50OiBVc2VyQ21wLCBuYW1lOiAnVXNlcid9KV0pKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiByb3V0ZXIubmF2aWdhdGVCeVVybCgnL2EvYicpKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiB7XG4gICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5uYW1lID0gJ2JyaWFuJztcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ2JyaWFuJyk7XG4gICAgICAgICAgICAgICBleHBlY3QoZ2V0SHJlZihmaXh0dXJlKSkudG9FcXVhbCgnL3VzZXIvYnJpYW4nKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIGdlbmVyYXRlIGxpbmsgaHJlZnMgZnJvbSBhIGNoaWxkIHRvIGl0cyBzaWJsaW5nJyxcbiAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgY29tcGlsZSgpXG4gICAgICAgICAgICAgLnRoZW4oXG4gICAgICAgICAgICAgICAgIChfKSA9PiByb3V0ZXIuY29uZmlnKFxuICAgICAgICAgICAgICAgICAgICAgW25ldyBSb3V0ZSh7cGF0aDogJy9wYWdlLzpudW1iZXInLCBjb21wb25lbnQ6IFNpYmxpbmdQYWdlQ21wLCBuYW1lOiAnUGFnZSd9KV0pKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiByb3V0ZXIubmF2aWdhdGVCeVVybCgnL3BhZ2UvMScpKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiB7XG4gICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChnZXRIcmVmKGZpeHR1cmUpKS50b0VxdWFsKCcvcGFnZS8yJyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBnZW5lcmF0ZSBsaW5rIGhyZWZzIGZyb20gYSBjaGlsZCB0byBpdHMgc2libGluZyB3aXRoIG5vIGxlYWRpbmcgc2xhc2gnLFxuICAgICAgIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICBjb21waWxlKClcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcm91dGVyLmNvbmZpZyhbXG4gICAgICAgICAgICAgICBuZXcgUm91dGUoXG4gICAgICAgICAgICAgICAgICAge3BhdGg6ICcvcGFnZS86bnVtYmVyJywgY29tcG9uZW50OiBOb1ByZWZpeFNpYmxpbmdQYWdlQ21wLCBuYW1lOiAnUGFnZSd9KVxuICAgICAgICAgICAgIF0pKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiByb3V0ZXIubmF2aWdhdGVCeVVybCgnL3BhZ2UvMScpKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiB7XG4gICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChnZXRIcmVmKGZpeHR1cmUpKS50b0VxdWFsKCcvcGFnZS8yJyk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBnZW5lcmF0ZSBsaW5rIGhyZWZzIHRvIGEgY2hpbGQgd2l0aCBubyBsZWFkaW5nIHNsYXNoJyxcbiAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgY29tcGlsZSgpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJvdXRlci5jb25maWcoW1xuICAgICAgICAgICAgICAgbmV3IFJvdXRlKHtwYXRoOiAnL2Jvb2svOnRpdGxlLy4uLicsIGNvbXBvbmVudDogTm9QcmVmaXhCb29rQ21wLCBuYW1lOiAnQm9vayd9KVxuICAgICAgICAgICAgIF0pKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiByb3V0ZXIubmF2aWdhdGVCeVVybCgnL2Jvb2svMTk4NC9wYWdlLzEnKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICBleHBlY3QoZ2V0SHJlZihmaXh0dXJlKSkudG9FcXVhbCgnL2Jvb2svMTk4NC9wYWdlLzEwMCcpO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgdGhyb3cgd2hlbiBsaW5rcyB3aXRob3V0IGEgbGVhZGluZyBzbGFzaCBhcmUgYW1iaWd1b3VzJyxcbiAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgY29tcGlsZSgpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJvdXRlci5jb25maWcoW1xuICAgICAgICAgICAgICAgbmV3IFJvdXRlKHtwYXRoOiAnL2Jvb2svOnRpdGxlLy4uLicsIGNvbXBvbmVudDogQW1iaWd1b3VzQm9va0NtcCwgbmFtZTogJ0Jvb2snfSlcbiAgICAgICAgICAgICBdKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcm91dGVyLm5hdmlnYXRlQnlVcmwoJy9ib29rLzE5ODQvcGFnZS8xJykpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHtcbiAgICAgICAgICAgICAgIHZhciBsaW5rID0gTGlzdFdyYXBwZXIudG9KU09OKFsnQm9vaycsIHtudW1iZXI6IDEwMH1dKTtcbiAgICAgICAgICAgICAgIGV4cGVjdCgoKSA9PiBmaXh0dXJlLmRldGVjdENoYW5nZXMoKSlcbiAgICAgICAgICAgICAgICAgICAudG9UaHJvd0Vycm9yV2l0aChcbiAgICAgICAgICAgICAgICAgICAgICAgYExpbmsgXCIke2xpbmt9XCIgaXMgYW1iaWd1b3VzLCB1c2UgXCIuL1wiIG9yIFwiLi4vXCIgdG8gZGlzYW1iaWd1YXRlLmApO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgZ2VuZXJhdGUgbGluayBocmVmcyB3aGVuIGFzeW5jaHJvbm91c2x5IGxvYWRlZCcsXG4gICAgICAgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgIGNvbXBpbGUoKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiByb3V0ZXIuY29uZmlnKFtcbiAgICAgICAgICAgICAgIG5ldyBBc3luY1JvdXRlKHtcbiAgICAgICAgICAgICAgICAgcGF0aDogJy9jaGlsZC13aXRoLWdyYW5kY2hpbGQvLi4uJyxcbiAgICAgICAgICAgICAgICAgbG9hZGVyOiBwYXJlbnRDbXBMb2FkZXIsXG4gICAgICAgICAgICAgICAgIG5hbWU6ICdDaGlsZFdpdGhHcmFuZGNoaWxkJ1xuICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICBdKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcm91dGVyLm5hdmlnYXRlQnlVcmwoJy9jaGlsZC13aXRoLWdyYW5kY2hpbGQvZ3JhbmRjaGlsZCcpKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiB7XG4gICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChnZXRIcmVmKGZpeHR1cmUpKS50b0VxdWFsKCcvY2hpbGQtd2l0aC1ncmFuZGNoaWxkL2dyYW5kY2hpbGQnKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIGdlbmVyYXRlIHJlbGF0aXZlIGxpbmtzIHByZXNlcnZpbmcgdGhlIGV4aXN0aW5nIHBhcmVudCByb3V0ZScsXG4gICAgICAgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgIGNvbXBpbGUoKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiByb3V0ZXIuY29uZmlnKFxuICAgICAgICAgICAgICAgICAgICAgICBbbmV3IFJvdXRlKHtwYXRoOiAnL2Jvb2svOnRpdGxlLy4uLicsIGNvbXBvbmVudDogQm9va0NtcCwgbmFtZTogJ0Jvb2snfSldKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcm91dGVyLm5hdmlnYXRlQnlVcmwoJy9ib29rLzE5ODQvcGFnZS8xJykpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgLy8gVE9ETyhqdWxpZW1yKTogVGhpcyBzaG91bGQgYmUgb25lIEJ5LmNzcygnYm9vay1jbXAgYScpIHF1ZXJ5LCBidXQgdGhlIHBhcnNlNVxuICAgICAgICAgICAgICAgLy8gYWRhcHRlclxuICAgICAgICAgICAgICAgLy8gY2FuJ3QgaGFuZGxlIGNzcyBjaGlsZCBzZWxlY3RvcnMuXG4gICAgICAgICAgICAgICBleHBlY3QoRE9NLmdldEF0dHJpYnV0ZShmaXh0dXJlLmRlYnVnRWxlbWVudC5xdWVyeShCeS5jc3MoJ2Jvb2stY21wJykpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnF1ZXJ5KEJ5LmNzcygnYScpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5uYXRpdmVFbGVtZW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2hyZWYnKSlcbiAgICAgICAgICAgICAgICAgICAudG9FcXVhbCgnL2Jvb2svMTk4NC9wYWdlLzEwMCcpO1xuXG4gICAgICAgICAgICAgICBleHBlY3QoRE9NLmdldEF0dHJpYnV0ZShmaXh0dXJlLmRlYnVnRWxlbWVudC5xdWVyeShCeS5jc3MoJ3BhZ2UtY21wJykpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnF1ZXJ5KEJ5LmNzcygnYScpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5uYXRpdmVFbGVtZW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2hyZWYnKSlcbiAgICAgICAgICAgICAgICAgICAudG9FcXVhbCgnL2Jvb2svMTk4NC9wYWdlLzInKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIGdlbmVyYXRlIGxpbmtzIHRvIGF1eGlsaWFyeSByb3V0ZXMnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgY29tcGlsZSgpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJvdXRlci5jb25maWcoW25ldyBSb3V0ZSh7cGF0aDogJy8uLi4nLCBjb21wb25lbnQ6IEF1eExpbmtDbXB9KV0pKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiByb3V0ZXIubmF2aWdhdGVCeVVybCgnLycpKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiB7XG4gICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChnZXRIcmVmKGZpeHR1cmUpKS50b0VxdWFsKCcvKGFzaWRlKScpO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuXG4gICAgZGVzY3JpYmUoJ3JvdXRlci1saW5rLWFjdGl2ZSBDU1MgY2xhc3MnLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIGJlIGFkZGVkIHRvIHRoZSBhc3NvY2lhdGVkIGVsZW1lbnQnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICByb3V0ZXIuY29uZmlnKFtcbiAgICAgICAgICAgICAgICAgICBuZXcgUm91dGUoe3BhdGg6ICcvY2hpbGQnLCBjb21wb25lbnQ6IEhlbGxvQ21wLCBuYW1lOiAnQ2hpbGQnfSksXG4gICAgICAgICAgICAgICAgICAgbmV3IFJvdXRlKHtwYXRoOiAnL2JldHRlci1jaGlsZCcsIGNvbXBvbmVudDogSGVsbG8yQ21wLCBuYW1lOiAnQmV0dGVyQ2hpbGQnfSlcbiAgICAgICAgICAgICAgICAgXSlcbiAgICAgICAgICAgICAgIC50aGVuKChfKSA9PiBjb21waWxlKGA8YSBbcm91dGVyTGlua109XCJbJy4vQ2hpbGQnXVwiIGNsYXNzPVwiY2hpbGQtbGlua1wiPkNoaWxkPC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBbcm91dGVyTGlua109XCJbJy4vQmV0dGVyQ2hpbGQnXVwiIGNsYXNzPVwiYmV0dGVyLWNoaWxkLWxpbmtcIj5CZXR0ZXIgQ2hpbGQ8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxyb3V0ZXItb3V0bGV0Pjwvcm91dGVyLW91dGxldD5gKSlcbiAgICAgICAgICAgICAgIC50aGVuKChfKSA9PiB7XG4gICAgICAgICAgICAgICAgIHZhciBlbGVtZW50ID0gZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudDtcblxuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICB2YXIgbGluazEgPSBET00ucXVlcnlTZWxlY3RvcihlbGVtZW50LCAnLmNoaWxkLWxpbmsnKTtcbiAgICAgICAgICAgICAgICAgdmFyIGxpbmsyID0gRE9NLnF1ZXJ5U2VsZWN0b3IoZWxlbWVudCwgJy5iZXR0ZXItY2hpbGQtbGluaycpO1xuXG4gICAgICAgICAgICAgICAgIGV4cGVjdChsaW5rMSkubm90LnRvSGF2ZUNzc0NsYXNzKCdyb3V0ZXItbGluay1hY3RpdmUnKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGxpbmsyKS5ub3QudG9IYXZlQ3NzQ2xhc3MoJ3JvdXRlci1saW5rLWFjdGl2ZScpO1xuXG4gICAgICAgICAgICAgICAgIHJvdXRlci5zdWJzY3JpYmUoKF8pID0+IHtcbiAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICAgIGV4cGVjdChsaW5rMSkubm90LnRvSGF2ZUNzc0NsYXNzKCdyb3V0ZXItbGluay1hY3RpdmUnKTtcbiAgICAgICAgICAgICAgICAgICBleHBlY3QobGluazIpLnRvSGF2ZUNzc0NsYXNzKCdyb3V0ZXItbGluay1hY3RpdmUnKTtcblxuICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgIHJvdXRlci5uYXZpZ2F0ZUJ5VXJsKCcvYmV0dGVyLWNoaWxkP2V4dHJhPTAnKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIGJlIGFkZGVkIHRvIGxpbmtzIGluIGNoaWxkIHJvdXRlcycsIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICAgIHJvdXRlci5jb25maWcoW1xuICAgICAgICAgICAgICAgICAgIG5ldyBSb3V0ZSh7cGF0aDogJy9jaGlsZCcsIGNvbXBvbmVudDogSGVsbG9DbXAsIG5hbWU6ICdDaGlsZCd9KSxcbiAgICAgICAgICAgICAgICAgICBuZXcgUm91dGUoe1xuICAgICAgICAgICAgICAgICAgICAgcGF0aDogJy9jaGlsZC13aXRoLWdyYW5kY2hpbGQvLi4uJyxcbiAgICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudDogUGFyZW50Q21wLFxuICAgICAgICAgICAgICAgICAgICAgbmFtZTogJ0NoaWxkV2l0aEdyYW5kY2hpbGQnXG4gICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgXSlcbiAgICAgICAgICAgICAgIC50aGVuKChfKSA9PiBjb21waWxlKGA8YSBbcm91dGVyTGlua109XCJbJy4vQ2hpbGQnXVwiIGNsYXNzPVwiY2hpbGQtbGlua1wiPkNoaWxkPC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBbcm91dGVyTGlua109XCJbJy4vQ2hpbGRXaXRoR3JhbmRjaGlsZC9HcmFuZGNoaWxkJ11cIiBjbGFzcz1cImNoaWxkLXdpdGgtZ3JhbmRjaGlsZC1saW5rXCI+QmV0dGVyIENoaWxkPC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cm91dGVyLW91dGxldD48L3JvdXRlci1vdXRsZXQ+YCkpXG4gICAgICAgICAgICAgICAudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgICB2YXIgZWxlbWVudCA9IGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQ7XG5cbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgdmFyIGxpbmsxID0gRE9NLnF1ZXJ5U2VsZWN0b3IoZWxlbWVudCwgJy5jaGlsZC1saW5rJyk7XG4gICAgICAgICAgICAgICAgIHZhciBsaW5rMiA9IERPTS5xdWVyeVNlbGVjdG9yKGVsZW1lbnQsICcuY2hpbGQtd2l0aC1ncmFuZGNoaWxkLWxpbmsnKTtcblxuICAgICAgICAgICAgICAgICBleHBlY3QobGluazEpLm5vdC50b0hhdmVDc3NDbGFzcygncm91dGVyLWxpbmstYWN0aXZlJyk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChsaW5rMikubm90LnRvSGF2ZUNzc0NsYXNzKCdyb3V0ZXItbGluay1hY3RpdmUnKTtcblxuICAgICAgICAgICAgICAgICByb3V0ZXIuc3Vic2NyaWJlKChfKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG5cbiAgICAgICAgICAgICAgICAgICBleHBlY3QobGluazEpLm5vdC50b0hhdmVDc3NDbGFzcygncm91dGVyLWxpbmstYWN0aXZlJyk7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGxpbmsyKS50b0hhdmVDc3NDbGFzcygncm91dGVyLWxpbmstYWN0aXZlJyk7XG5cbiAgICAgICAgICAgICAgICAgICB2YXIgbGluazMgPSBET00ucXVlcnlTZWxlY3RvcihlbGVtZW50LCAnLmdyYW5kY2hpbGQtbGluaycpO1xuICAgICAgICAgICAgICAgICAgIHZhciBsaW5rNCA9IERPTS5xdWVyeVNlbGVjdG9yKGVsZW1lbnQsICcuYmV0dGVyLWdyYW5kY2hpbGQtbGluaycpO1xuXG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGxpbmszKS50b0hhdmVDc3NDbGFzcygncm91dGVyLWxpbmstYWN0aXZlJyk7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGxpbms0KS5ub3QudG9IYXZlQ3NzQ2xhc3MoJ3JvdXRlci1saW5rLWFjdGl2ZScpO1xuXG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgcm91dGVyLm5hdmlnYXRlQnlVcmwoJy9jaGlsZC13aXRoLWdyYW5kY2hpbGQvZ3JhbmRjaGlsZD9leHRyYT0wJyk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuXG4gICAgICBkZXNjcmliZSgncm91dGVyIGxpbmsgZHNsJywgKCkgPT4ge1xuICAgICAgICBpdCgnc2hvdWxkIGdlbmVyYXRlIGxpbmsgaHJlZnMgd2l0aCBwYXJhbXMnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICAgIGNvbXBpbGUoJzxhIGhyZWY9XCJoZWxsb1wiIFtyb3V0ZXJMaW5rXT1cInJvdXRlOi4vVXNlcihuYW1lOiBuYW1lKVwiPnt7bmFtZX19PC9hPicpXG4gICAgICAgICAgICAgICAgIC50aGVuKChfKSA9PiByb3V0ZXIuY29uZmlnKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgW25ldyBSb3V0ZSh7cGF0aDogJy91c2VyLzpuYW1lJywgY29tcG9uZW50OiBVc2VyQ21wLCBuYW1lOiAnVXNlcid9KV0pKVxuICAgICAgICAgICAgICAgICAudGhlbigoXykgPT4gcm91dGVyLm5hdmlnYXRlQnlVcmwoJy9hL2InKSlcbiAgICAgICAgICAgICAgICAgLnRoZW4oKF8pID0+IHtcbiAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRlYnVnRWxlbWVudC5jb21wb25lbnRJbnN0YW5jZS5uYW1lID0gJ2JyaWFuJztcbiAgICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgnYnJpYW4nKTtcbiAgICAgICAgICAgICAgICAgICBleHBlY3QoZ2V0SHJlZihmaXh0dXJlKSkudG9FcXVhbCgnL3VzZXIvYnJpYW4nKTtcbiAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICB9KSk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKCd3aGVuIGNsaWNrZWQnLCAoKSA9PiB7XG5cbiAgICAgIHZhciBjbGlja09uRWxlbWVudCA9IGZ1bmN0aW9uKHZpZXcpIHtcbiAgICAgICAgdmFyIGFuY2hvckVsID0gZml4dHVyZS5kZWJ1Z0VsZW1lbnQucXVlcnkoQnkuY3NzKCdhJykpLm5hdGl2ZUVsZW1lbnQ7XG4gICAgICAgIHZhciBkaXNwYXRjaGVkRXZlbnQgPSBET00uY3JlYXRlTW91c2VFdmVudCgnY2xpY2snKTtcbiAgICAgICAgRE9NLmRpc3BhdGNoRXZlbnQoYW5jaG9yRWwsIGRpc3BhdGNoZWRFdmVudCk7XG4gICAgICAgIHJldHVybiBkaXNwYXRjaGVkRXZlbnQ7XG4gICAgICB9O1xuXG4gICAgICBpdCgnc2hvdWxkIG5hdmlnYXRlIHRvIGxpbmsgaHJlZnMgd2l0aG91dCBwYXJhbXMnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICBjb21waWxlKCc8YSBocmVmPVwiaGVsbG9cIiBbcm91dGVyTGlua109XCJbXFwnLi9Vc2VyXFwnXVwiPjwvYT4nKVxuICAgICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJvdXRlci5jb25maWcoXG4gICAgICAgICAgICAgICAgICAgICAgICAgW25ldyBSb3V0ZSh7cGF0aDogJy91c2VyJywgY29tcG9uZW50OiBVc2VyQ21wLCBuYW1lOiAnVXNlcid9KV0pKVxuICAgICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJvdXRlci5uYXZpZ2F0ZUJ5VXJsKCcvYS9iJykpXG4gICAgICAgICAgICAgICAudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuICAgICAgICAgICAgICAgICB2YXIgZGlzcGF0Y2hlZEV2ZW50ID0gY2xpY2tPbkVsZW1lbnQoZml4dHVyZSk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChET00uaXNQcmV2ZW50ZWQoZGlzcGF0Y2hlZEV2ZW50KSkudG9CZSh0cnVlKTtcblxuICAgICAgICAgICAgICAgICAvLyByb3V0ZXIgbmF2aWdhdGlvbiBpcyBhc3luYy5cbiAgICAgICAgICAgICAgICAgcm91dGVyLnN1YnNjcmliZSgoXykgPT4ge1xuICAgICAgICAgICAgICAgICAgIGV4cGVjdCgoPFNweUxvY2F0aW9uPmxvY2F0aW9uKS51cmxDaGFuZ2VzKS50b0VxdWFsKFsnL3VzZXInXSk7XG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIG5hdmlnYXRlIHRvIGxpbmsgaHJlZnMgaW4gcHJlc2VuY2Ugb2YgYmFzZSBocmVmJyxcbiAgICAgICAgIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICAgICg8U3B5TG9jYXRpb24+bG9jYXRpb24pLnNldEJhc2VIcmVmKCcvYmFzZScpO1xuICAgICAgICAgICBjb21waWxlKCc8YSBocmVmPVwiaGVsbG9cIiBbcm91dGVyTGlua109XCJbXFwnLi9Vc2VyXFwnXVwiPjwvYT4nKVxuICAgICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJvdXRlci5jb25maWcoXG4gICAgICAgICAgICAgICAgICAgICAgICAgW25ldyBSb3V0ZSh7cGF0aDogJy91c2VyJywgY29tcG9uZW50OiBVc2VyQ21wLCBuYW1lOiAnVXNlcid9KV0pKVxuICAgICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJvdXRlci5uYXZpZ2F0ZUJ5VXJsKCcvYS9iJykpXG4gICAgICAgICAgICAgICAudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcblxuXG4gICAgICAgICAgICAgICAgIHZhciBkaXNwYXRjaGVkRXZlbnQgPSBjbGlja09uRWxlbWVudChmaXh0dXJlKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KERPTS5pc1ByZXZlbnRlZChkaXNwYXRjaGVkRXZlbnQpKS50b0JlKHRydWUpO1xuXG4gICAgICAgICAgICAgICAgIC8vIHJvdXRlciBuYXZpZ2F0aW9uIGlzIGFzeW5jLlxuICAgICAgICAgICAgICAgICByb3V0ZXIuc3Vic2NyaWJlKChfKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KCg8U3B5TG9jYXRpb24+bG9jYXRpb24pLnVybENoYW5nZXMpLnRvRXF1YWwoWycvYmFzZS91c2VyJ10pO1xuICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcbiAgICB9KTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIGdldEhyZWYodGM6IENvbXBvbmVudEZpeHR1cmUpIHtcbiAgcmV0dXJuIERPTS5nZXRBdHRyaWJ1dGUodGMuZGVidWdFbGVtZW50LnF1ZXJ5KEJ5LmNzcygnYScpKS5uYXRpdmVFbGVtZW50LCAnaHJlZicpO1xufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ215LWNvbXAnLCB0ZW1wbGF0ZTogJycsIGRpcmVjdGl2ZXM6IFtST1VURVJfRElSRUNUSVZFU119KVxuY2xhc3MgTXlDb21wIHtcbiAgbmFtZTtcbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICd1c2VyLWNtcCcsIHRlbXBsYXRlOiBcImhlbGxvIHt7dXNlcn19XCJ9KVxuY2xhc3MgVXNlckNtcCB7XG4gIHVzZXI6IHN0cmluZztcbiAgY29uc3RydWN0b3IocGFyYW1zOiBSb3V0ZVBhcmFtcykgeyB0aGlzLnVzZXIgPSBwYXJhbXMuZ2V0KCduYW1lJyk7IH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAncGFnZS1jbXAnLFxuICB0ZW1wbGF0ZTpcbiAgICAgIGBwYWdlICN7e3BhZ2VOdW1iZXJ9fSB8IDxhIGhyZWY9XCJoZWxsb1wiIFtyb3V0ZXJMaW5rXT1cIltcXCcuLi9QYWdlXFwnLCB7bnVtYmVyOiBuZXh0UGFnZX1dXCI+bmV4dDwvYT5gLFxuICBkaXJlY3RpdmVzOiBbUm91dGVyTGlua11cbn0pXG5jbGFzcyBTaWJsaW5nUGFnZUNtcCB7XG4gIHBhZ2VOdW1iZXI6IG51bWJlcjtcbiAgbmV4dFBhZ2U6IG51bWJlcjtcbiAgY29uc3RydWN0b3IocGFyYW1zOiBSb3V0ZVBhcmFtcykge1xuICAgIHRoaXMucGFnZU51bWJlciA9IE51bWJlcldyYXBwZXIucGFyc2VJbnQocGFyYW1zLmdldCgnbnVtYmVyJyksIDEwKTtcbiAgICB0aGlzLm5leHRQYWdlID0gdGhpcy5wYWdlTnVtYmVyICsgMTtcbiAgfVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdwYWdlLWNtcCcsXG4gIHRlbXBsYXRlOlxuICAgICAgYHBhZ2UgI3t7cGFnZU51bWJlcn19IHwgPGEgaHJlZj1cImhlbGxvXCIgW3JvdXRlckxpbmtdPVwiW1xcJ1BhZ2VcXCcsIHtudW1iZXI6IG5leHRQYWdlfV1cIj5uZXh0PC9hPmAsXG4gIGRpcmVjdGl2ZXM6IFtSb3V0ZXJMaW5rXVxufSlcbmNsYXNzIE5vUHJlZml4U2libGluZ1BhZ2VDbXAge1xuICBwYWdlTnVtYmVyOiBudW1iZXI7XG4gIG5leHRQYWdlOiBudW1iZXI7XG4gIGNvbnN0cnVjdG9yKHBhcmFtczogUm91dGVQYXJhbXMpIHtcbiAgICB0aGlzLnBhZ2VOdW1iZXIgPSBOdW1iZXJXcmFwcGVyLnBhcnNlSW50KHBhcmFtcy5nZXQoJ251bWJlcicpLCAxMCk7XG4gICAgdGhpcy5uZXh0UGFnZSA9IHRoaXMucGFnZU51bWJlciArIDE7XG4gIH1cbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdoZWxsby1jbXAnLCB0ZW1wbGF0ZTogJ2hlbGxvJ30pXG5jbGFzcyBIZWxsb0NtcCB7XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnaGVsbG8yLWNtcCcsIHRlbXBsYXRlOiAnaGVsbG8yJ30pXG5jbGFzcyBIZWxsbzJDbXAge1xufVxuXG5mdW5jdGlvbiBwYXJlbnRDbXBMb2FkZXIoKSB7XG4gIHJldHVybiBQcm9taXNlV3JhcHBlci5yZXNvbHZlKFBhcmVudENtcCk7XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ3BhcmVudC1jbXAnLFxuICB0ZW1wbGF0ZTogYHsgPGEgW3JvdXRlckxpbmtdPVwiWycuL0dyYW5kY2hpbGQnXVwiIGNsYXNzPVwiZ3JhbmRjaGlsZC1saW5rXCI+R3JhbmRjaGlsZDwvYT5cbiAgICAgICAgICAgICAgIDxhIFtyb3V0ZXJMaW5rXT1cIlsnLi9CZXR0ZXJHcmFuZGNoaWxkJ11cIiBjbGFzcz1cImJldHRlci1ncmFuZGNoaWxkLWxpbmtcIj5CZXR0ZXIgR3JhbmRjaGlsZDwvYT5cbiAgICAgICAgICAgICAgIDxyb3V0ZXItb3V0bGV0Pjwvcm91dGVyLW91dGxldD4gfWAsXG4gIGRpcmVjdGl2ZXM6IFJPVVRFUl9ESVJFQ1RJVkVTXG59KVxuQFJvdXRlQ29uZmlnKFtcbiAgbmV3IFJvdXRlKHtwYXRoOiAnL2dyYW5kY2hpbGQnLCBjb21wb25lbnQ6IEhlbGxvQ21wLCBuYW1lOiAnR3JhbmRjaGlsZCd9KSxcbiAgbmV3IFJvdXRlKHtwYXRoOiAnL2JldHRlci1ncmFuZGNoaWxkJywgY29tcG9uZW50OiBIZWxsbzJDbXAsIG5hbWU6ICdCZXR0ZXJHcmFuZGNoaWxkJ30pXG5dKVxuY2xhc3MgUGFyZW50Q21wIHtcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnYm9vay1jbXAnLFxuICB0ZW1wbGF0ZTogYDxhIGhyZWY9XCJoZWxsb1wiIFtyb3V0ZXJMaW5rXT1cIltcXCcuL1BhZ2VcXCcsIHtudW1iZXI6IDEwMH1dXCI+e3t0aXRsZX19PC9hPiB8XG4gICAgPHJvdXRlci1vdXRsZXQ+PC9yb3V0ZXItb3V0bGV0PmAsXG4gIGRpcmVjdGl2ZXM6IFJPVVRFUl9ESVJFQ1RJVkVTXG59KVxuQFJvdXRlQ29uZmlnKFtuZXcgUm91dGUoe3BhdGg6ICcvcGFnZS86bnVtYmVyJywgY29tcG9uZW50OiBTaWJsaW5nUGFnZUNtcCwgbmFtZTogJ1BhZ2UnfSldKVxuY2xhc3MgQm9va0NtcCB7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGNvbnN0cnVjdG9yKHBhcmFtczogUm91dGVQYXJhbXMpIHsgdGhpcy50aXRsZSA9IHBhcmFtcy5nZXQoJ3RpdGxlJyk7IH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnYm9vay1jbXAnLFxuICB0ZW1wbGF0ZTogYDxhIGhyZWY9XCJoZWxsb1wiIFtyb3V0ZXJMaW5rXT1cIltcXCdQYWdlXFwnLCB7bnVtYmVyOiAxMDB9XVwiPnt7dGl0bGV9fTwvYT4gfFxuICAgIDxyb3V0ZXItb3V0bGV0Pjwvcm91dGVyLW91dGxldD5gLFxuICBkaXJlY3RpdmVzOiBST1VURVJfRElSRUNUSVZFU1xufSlcbkBSb3V0ZUNvbmZpZyhbbmV3IFJvdXRlKHtwYXRoOiAnL3BhZ2UvOm51bWJlcicsIGNvbXBvbmVudDogU2libGluZ1BhZ2VDbXAsIG5hbWU6ICdQYWdlJ30pXSlcbmNsYXNzIE5vUHJlZml4Qm9va0NtcCB7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGNvbnN0cnVjdG9yKHBhcmFtczogUm91dGVQYXJhbXMpIHsgdGhpcy50aXRsZSA9IHBhcmFtcy5nZXQoJ3RpdGxlJyk7IH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnYm9vay1jbXAnLFxuICB0ZW1wbGF0ZTogYDxhIGhyZWY9XCJoZWxsb1wiIFtyb3V0ZXJMaW5rXT1cIltcXCdCb29rXFwnLCB7bnVtYmVyOiAxMDB9XVwiPnt7dGl0bGV9fTwvYT4gfFxuICAgIDxyb3V0ZXItb3V0bGV0Pjwvcm91dGVyLW91dGxldD5gLFxuICBkaXJlY3RpdmVzOiBST1VURVJfRElSRUNUSVZFU1xufSlcbkBSb3V0ZUNvbmZpZyhbbmV3IFJvdXRlKHtwYXRoOiAnL3BhZ2UvOm51bWJlcicsIGNvbXBvbmVudDogU2libGluZ1BhZ2VDbXAsIG5hbWU6ICdCb29rJ30pXSlcbmNsYXNzIEFtYmlndW91c0Jvb2tDbXAge1xuICB0aXRsZTogc3RyaW5nO1xuICBjb25zdHJ1Y3RvcihwYXJhbXM6IFJvdXRlUGFyYW1zKSB7IHRoaXMudGl0bGUgPSBwYXJhbXMuZ2V0KCd0aXRsZScpOyB9XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2F1eC1jbXAnLFxuICB0ZW1wbGF0ZTpcbiAgICAgIGA8YSBbcm91dGVyTGlua109XCJbXFwnLi9IZWxsb1xcJywgWyBcXCdBc2lkZVxcJyBdIF1cIj5hc2lkZTwvYT4gfFxuICAgIDxyb3V0ZXItb3V0bGV0Pjwvcm91dGVyLW91dGxldD4gfCBhc2lkZSA8cm91dGVyLW91dGxldCBuYW1lPVwiYXNpZGVcIj48L3JvdXRlci1vdXRsZXQ+YCxcbiAgZGlyZWN0aXZlczogUk9VVEVSX0RJUkVDVElWRVNcbn0pXG5AUm91dGVDb25maWcoW1xuICBuZXcgUm91dGUoe3BhdGg6ICcvJywgY29tcG9uZW50OiBIZWxsb0NtcCwgbmFtZTogJ0hlbGxvJ30pLFxuICBuZXcgQXV4Um91dGUoe3BhdGg6ICcvYXNpZGUnLCBjb21wb25lbnQ6IEhlbGxvMkNtcCwgbmFtZTogJ0FzaWRlJ30pXG5dKVxuY2xhc3MgQXV4TGlua0NtcCB7XG59XG4iXX0=
 main(); 
