'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var util_1 = require('./util');
var testing_internal_1 = require('angular2/testing_internal');
var sync_route_spec_impl_1 = require('./impl/sync_route_spec_impl');
function main() {
    testing_internal_1.describe('sync route spec', function () {
        testing_internal_1.beforeEachProviders(function () { return util_1.TEST_ROUTER_PROVIDERS; });
        sync_route_spec_impl_1.registerSpecs();
        util_1.describeRouter('sync routes', function () {
            util_1.describeWithout('children', function () { util_1.describeWithAndWithout('params', util_1.itShouldRoute); });
            util_1.describeWith('sync children', function () {
                util_1.describeWithout('default routes', function () { util_1.describeWithAndWithout('params', util_1.itShouldRoute); });
                util_1.describeWith('default routes', function () { util_1.describeWithout('params', util_1.itShouldRoute); });
            });
            util_1.describeWith('dynamic components', util_1.itShouldRoute);
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3luY19yb3V0ZV9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9yb3V0ZXIvaW50ZWdyYXRpb24vc3luY19yb3V0ZV9zcGVjLnRzIl0sIm5hbWVzIjpbIm1haW4iXSwibWFwcGluZ3MiOiJBQUFBLHFCQVFPLFFBQVEsQ0FBQyxDQUFBO0FBRWhCLGlDQUF1RCwyQkFBMkIsQ0FBQyxDQUFBO0FBRW5GLHFDQUE0Qiw2QkFBNkIsQ0FBQyxDQUFBO0FBRTFEO0lBQ0VBLDJCQUFRQSxDQUFDQSxpQkFBaUJBLEVBQUVBO1FBRTFCQSxzQ0FBbUJBLENBQUNBLGNBQU1BLE9BQUFBLDRCQUFxQkEsRUFBckJBLENBQXFCQSxDQUFDQSxDQUFDQTtRQUVqREEsb0NBQWFBLEVBQUVBLENBQUNBO1FBRWhCQSxxQkFBY0EsQ0FBQ0EsYUFBYUEsRUFBRUE7WUFDNUJBLHNCQUFlQSxDQUFDQSxVQUFVQSxFQUFFQSxjQUFRQSw2QkFBc0JBLENBQUNBLFFBQVFBLEVBQUVBLG9CQUFhQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUV4RkEsbUJBQVlBLENBQUNBLGVBQWVBLEVBQUVBO2dCQUM1QkEsc0JBQWVBLENBQUNBLGdCQUFnQkEsRUFDaEJBLGNBQVFBLDZCQUFzQkEsQ0FBQ0EsUUFBUUEsRUFBRUEsb0JBQWFBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUM1RUEsbUJBQVlBLENBQUNBLGdCQUFnQkEsRUFBRUEsY0FBUUEsc0JBQWVBLENBQUNBLFFBQVFBLEVBQUVBLG9CQUFhQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUV0RkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEsbUJBQVlBLENBQUNBLG9CQUFvQkEsRUFBRUEsb0JBQWFBLENBQUNBLENBQUNBO1FBQ3BEQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUVMQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQXJCZSxZQUFJLE9BcUJuQixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgZGVzY3JpYmVSb3V0ZXIsXG4gIGRkZXNjcmliZVJvdXRlcixcbiAgZGVzY3JpYmVXaXRoLFxuICBkZXNjcmliZVdpdGhvdXQsXG4gIGRlc2NyaWJlV2l0aEFuZFdpdGhvdXQsXG4gIGl0U2hvdWxkUm91dGUsXG4gIFRFU1RfUk9VVEVSX1BST1ZJREVSU1xufSBmcm9tICcuL3V0aWwnO1xuXG5pbXBvcnQge2JlZm9yZUVhY2hQcm92aWRlcnMsIGRlc2NyaWJlLCBkZGVzY3JpYmV9IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5pbXBvcnQge3JlZ2lzdGVyU3BlY3N9IGZyb20gJy4vaW1wbC9zeW5jX3JvdXRlX3NwZWNfaW1wbCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgnc3luYyByb3V0ZSBzcGVjJywgKCkgPT4ge1xuXG4gICAgYmVmb3JlRWFjaFByb3ZpZGVycygoKSA9PiBURVNUX1JPVVRFUl9QUk9WSURFUlMpO1xuXG4gICAgcmVnaXN0ZXJTcGVjcygpO1xuXG4gICAgZGVzY3JpYmVSb3V0ZXIoJ3N5bmMgcm91dGVzJywgKCkgPT4ge1xuICAgICAgZGVzY3JpYmVXaXRob3V0KCdjaGlsZHJlbicsICgpID0+IHsgZGVzY3JpYmVXaXRoQW5kV2l0aG91dCgncGFyYW1zJywgaXRTaG91bGRSb3V0ZSk7IH0pO1xuXG4gICAgICBkZXNjcmliZVdpdGgoJ3N5bmMgY2hpbGRyZW4nLCAoKSA9PiB7XG4gICAgICAgIGRlc2NyaWJlV2l0aG91dCgnZGVmYXVsdCByb3V0ZXMnLFxuICAgICAgICAgICAgICAgICAgICAgICAgKCkgPT4geyBkZXNjcmliZVdpdGhBbmRXaXRob3V0KCdwYXJhbXMnLCBpdFNob3VsZFJvdXRlKTsgfSk7XG4gICAgICAgIGRlc2NyaWJlV2l0aCgnZGVmYXVsdCByb3V0ZXMnLCAoKSA9PiB7IGRlc2NyaWJlV2l0aG91dCgncGFyYW1zJywgaXRTaG91bGRSb3V0ZSk7IH0pO1xuXG4gICAgICB9KTtcblxuICAgICAgZGVzY3JpYmVXaXRoKCdkeW5hbWljIGNvbXBvbmVudHMnLCBpdFNob3VsZFJvdXRlKTtcbiAgICB9KTtcblxuICB9KTtcbn1cbiJdfQ==
 main(); 
