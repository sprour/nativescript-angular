import { Provider } from 'angular2/core';
import { ComponentFixture, TestComponentBuilder } from 'angular2/testing_internal';
import { RouteRegistry } from 'angular2/src/router/route_registry';
import { DirectiveResolver } from 'angular2/src/core/linker/directive_resolver';
export { ComponentFixture } from 'angular2/testing_internal';
/**
 * Router test helpers and fixtures
 */
export declare class RootCmp {
    name: string;
}
export declare function compile(tcb: TestComponentBuilder, template?: string): Promise<ComponentFixture>;
export declare var TEST_ROUTER_PROVIDERS: (typeof RouteRegistry | typeof DirectiveResolver | Provider)[];
export declare function clickOnElement(anchorEl: any): any;
export declare function getHref(elt: any): string;
export declare var specs: {};
export declare function describeRouter(description: string, fn: Function, exclusive?: boolean): void;
export declare function ddescribeRouter(description: string, fn: Function, exclusive?: boolean): void;
export declare function describeWithAndWithout(description: string, fn: Function): void;
export declare function describeWith(description: string, fn: Function): void;
export declare function describeWithout(description: string, fn: Function): void;
export declare function itShouldRoute(): void;
