'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var util_1 = require('./util');
var testing_internal_1 = require('angular2/testing_internal');
var async_route_spec_impl_1 = require('./impl/async_route_spec_impl');
function main() {
    testing_internal_1.describe('async route spec', function () {
        testing_internal_1.beforeEachProviders(function () { return util_1.TEST_ROUTER_PROVIDERS; });
        async_route_spec_impl_1.registerSpecs();
        util_1.describeRouter('async routes', function () {
            util_1.describeWithout('children', function () {
                util_1.describeWith('route data', util_1.itShouldRoute);
                util_1.describeWithAndWithout('params', util_1.itShouldRoute);
            });
            util_1.describeWith('sync children', function () { util_1.describeWithAndWithout('default routes', util_1.itShouldRoute); });
            util_1.describeWith('async children', function () {
                util_1.describeWithAndWithout('params', function () { util_1.describeWithout('default routes', util_1.itShouldRoute); });
            });
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXN5bmNfcm91dGVfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3Qvcm91dGVyL2ludGVncmF0aW9uL2FzeW5jX3JvdXRlX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiJdLCJtYXBwaW5ncyI6IkFBQUEscUJBUU8sUUFBUSxDQUFDLENBQUE7QUFFaEIsaUNBQTRDLDJCQUEyQixDQUFDLENBQUE7QUFFeEUsc0NBQTRCLDhCQUE4QixDQUFDLENBQUE7QUFFM0Q7SUFDRUEsMkJBQVFBLENBQUNBLGtCQUFrQkEsRUFBRUE7UUFFM0JBLHNDQUFtQkEsQ0FBQ0EsY0FBTUEsT0FBQUEsNEJBQXFCQSxFQUFyQkEsQ0FBcUJBLENBQUNBLENBQUNBO1FBRWpEQSxxQ0FBYUEsRUFBRUEsQ0FBQ0E7UUFFaEJBLHFCQUFjQSxDQUFDQSxjQUFjQSxFQUFFQTtZQUM3QkEsc0JBQWVBLENBQUNBLFVBQVVBLEVBQUVBO2dCQUMxQkEsbUJBQVlBLENBQUNBLFlBQVlBLEVBQUVBLG9CQUFhQSxDQUFDQSxDQUFDQTtnQkFDMUNBLDZCQUFzQkEsQ0FBQ0EsUUFBUUEsRUFBRUEsb0JBQWFBLENBQUNBLENBQUNBO1lBQ2xEQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxtQkFBWUEsQ0FBQ0EsZUFBZUEsRUFDZkEsY0FBUUEsNkJBQXNCQSxDQUFDQSxnQkFBZ0JBLEVBQUVBLG9CQUFhQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVqRkEsbUJBQVlBLENBQUNBLGdCQUFnQkEsRUFBRUE7Z0JBQzdCQSw2QkFBc0JBLENBQUNBLFFBQVFBLEVBQ1JBLGNBQVFBLHNCQUFlQSxDQUFDQSxnQkFBZ0JBLEVBQUVBLG9CQUFhQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUN0RkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7QUFDTEEsQ0FBQ0E7QUF0QmUsWUFBSSxPQXNCbkIsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIGRlc2NyaWJlUm91dGVyLFxuICBkZGVzY3JpYmVSb3V0ZXIsXG4gIGRlc2NyaWJlV2l0aCxcbiAgZGVzY3JpYmVXaXRob3V0LFxuICBkZXNjcmliZVdpdGhBbmRXaXRob3V0LFxuICBpdFNob3VsZFJvdXRlLFxuICBURVNUX1JPVVRFUl9QUk9WSURFUlNcbn0gZnJvbSAnLi91dGlsJztcblxuaW1wb3J0IHtiZWZvcmVFYWNoUHJvdmlkZXJzLCBkZXNjcmliZX0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmltcG9ydCB7cmVnaXN0ZXJTcGVjc30gZnJvbSAnLi9pbXBsL2FzeW5jX3JvdXRlX3NwZWNfaW1wbCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgnYXN5bmMgcm91dGUgc3BlYycsICgpID0+IHtcblxuICAgIGJlZm9yZUVhY2hQcm92aWRlcnMoKCkgPT4gVEVTVF9ST1VURVJfUFJPVklERVJTKTtcblxuICAgIHJlZ2lzdGVyU3BlY3MoKTtcblxuICAgIGRlc2NyaWJlUm91dGVyKCdhc3luYyByb3V0ZXMnLCAoKSA9PiB7XG4gICAgICBkZXNjcmliZVdpdGhvdXQoJ2NoaWxkcmVuJywgKCkgPT4ge1xuICAgICAgICBkZXNjcmliZVdpdGgoJ3JvdXRlIGRhdGEnLCBpdFNob3VsZFJvdXRlKTtcbiAgICAgICAgZGVzY3JpYmVXaXRoQW5kV2l0aG91dCgncGFyYW1zJywgaXRTaG91bGRSb3V0ZSk7XG4gICAgICB9KTtcblxuICAgICAgZGVzY3JpYmVXaXRoKCdzeW5jIGNoaWxkcmVuJyxcbiAgICAgICAgICAgICAgICAgICAoKSA9PiB7IGRlc2NyaWJlV2l0aEFuZFdpdGhvdXQoJ2RlZmF1bHQgcm91dGVzJywgaXRTaG91bGRSb3V0ZSk7IH0pO1xuXG4gICAgICBkZXNjcmliZVdpdGgoJ2FzeW5jIGNoaWxkcmVuJywgKCkgPT4ge1xuICAgICAgICBkZXNjcmliZVdpdGhBbmRXaXRob3V0KCdwYXJhbXMnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICgpID0+IHsgZGVzY3JpYmVXaXRob3V0KCdkZWZhdWx0IHJvdXRlcycsIGl0U2hvdWxkUm91dGUpOyB9KTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9KTtcbn1cbiJdfQ==
 main(); 
