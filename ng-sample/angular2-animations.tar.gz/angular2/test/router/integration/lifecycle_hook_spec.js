'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var core_1 = require('angular2/core');
var lang_1 = require('angular2/src/facade/lang');
var async_1 = require('angular2/src/facade/async');
var router_1 = require('angular2/router');
var route_config_decorator_1 = require('angular2/src/router/route_config/route_config_decorator');
var lifecycle_annotations_1 = require('angular2/src/router/lifecycle/lifecycle_annotations');
var util_1 = require('./util');
var cmpInstanceCount;
var log;
var eventBus;
var completer;
function main() {
    testing_internal_1.describe('Router lifecycle hooks', function () {
        var tcb;
        var fixture;
        var rtr;
        testing_internal_1.beforeEachProviders(function () { return util_1.TEST_ROUTER_PROVIDERS; });
        testing_internal_1.beforeEach(testing_internal_1.inject([testing_internal_1.TestComponentBuilder, router_1.Router], function (tcBuilder, router) {
            tcb = tcBuilder;
            rtr = router;
            cmpInstanceCount = 0;
            log = [];
            eventBus = new async_1.EventEmitter();
        }));
        testing_internal_1.it('should call the routerOnActivate hook', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            util_1.compile(tcb)
                .then(function (rtc) { fixture = rtc; })
                .then(function (_) { return rtr.config([new route_config_decorator_1.Route({ path: '/...', component: LifecycleCmp })]); })
                .then(function (_) { return rtr.navigateByUrl('/on-activate'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('activate cmp');
                testing_internal_1.expect(log).toEqual(['activate: null -> /on-activate']);
                async.done();
            });
        }));
        testing_internal_1.it('should wait for a parent component\'s routerOnActivate hook to resolve before calling its child\'s', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            util_1.compile(tcb)
                .then(function (rtc) { fixture = rtc; })
                .then(function (_) { return rtr.config([new route_config_decorator_1.Route({ path: '/...', component: LifecycleCmp })]); })
                .then(function (_) {
                async_1.ObservableWrapper.subscribe(eventBus, function (ev) {
                    if (ev.startsWith('parent activate')) {
                        completer.resolve(true);
                    }
                });
                rtr.navigateByUrl('/parent-activate/child-activate')
                    .then(function (_) {
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('parent {activate cmp}');
                    testing_internal_1.expect(log).toEqual([
                        'parent activate: null -> /parent-activate',
                        'activate: null -> /child-activate'
                    ]);
                    async.done();
                });
            });
        }));
        testing_internal_1.it('should call the routerOnDeactivate hook', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            util_1.compile(tcb)
                .then(function (rtc) { fixture = rtc; })
                .then(function (_) { return rtr.config([new route_config_decorator_1.Route({ path: '/...', component: LifecycleCmp })]); })
                .then(function (_) { return rtr.navigateByUrl('/on-deactivate'); })
                .then(function (_) { return rtr.navigateByUrl('/a'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('A');
                testing_internal_1.expect(log).toEqual(['deactivate: /on-deactivate -> /a']);
                async.done();
            });
        }));
        testing_internal_1.it('should wait for a child component\'s routerOnDeactivate hook to resolve before calling its parent\'s', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            util_1.compile(tcb)
                .then(function (rtc) { fixture = rtc; })
                .then(function (_) { return rtr.config([new route_config_decorator_1.Route({ path: '/...', component: LifecycleCmp })]); })
                .then(function (_) { return rtr.navigateByUrl('/parent-deactivate/child-deactivate'); })
                .then(function (_) {
                async_1.ObservableWrapper.subscribe(eventBus, function (ev) {
                    if (ev.startsWith('deactivate')) {
                        completer.resolve(true);
                        fixture.detectChanges();
                        testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('parent {deactivate cmp}');
                    }
                });
                rtr.navigateByUrl('/a').then(function (_) {
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('A');
                    testing_internal_1.expect(log).toEqual([
                        'deactivate: /child-deactivate -> null',
                        'parent deactivate: /parent-deactivate -> /a'
                    ]);
                    async.done();
                });
            });
        }));
        testing_internal_1.it('should reuse a component when the routerCanReuse hook returns true', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            util_1.compile(tcb)
                .then(function (rtc) { fixture = rtc; })
                .then(function (_) { return rtr.config([new route_config_decorator_1.Route({ path: '/...', component: LifecycleCmp })]); })
                .then(function (_) { return rtr.navigateByUrl('/on-reuse/1/a'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(log).toEqual([]);
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('reuse {A}');
                testing_internal_1.expect(cmpInstanceCount).toBe(1);
            })
                .then(function (_) { return rtr.navigateByUrl('/on-reuse/2/b'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(log).toEqual(['reuse: /on-reuse/1 -> /on-reuse/2']);
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('reuse {B}');
                testing_internal_1.expect(cmpInstanceCount).toBe(1);
                async.done();
            });
        }));
        testing_internal_1.it('should not reuse a component when the routerCanReuse hook returns false', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            util_1.compile(tcb)
                .then(function (rtc) { fixture = rtc; })
                .then(function (_) { return rtr.config([new route_config_decorator_1.Route({ path: '/...', component: LifecycleCmp })]); })
                .then(function (_) { return rtr.navigateByUrl('/never-reuse/1/a'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(log).toEqual([]);
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('reuse {A}');
                testing_internal_1.expect(cmpInstanceCount).toBe(1);
            })
                .then(function (_) { return rtr.navigateByUrl('/never-reuse/2/b'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(log).toEqual([]);
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('reuse {B}');
                testing_internal_1.expect(cmpInstanceCount).toBe(2);
                async.done();
            });
        }));
        testing_internal_1.it('should navigate when routerCanActivate returns true', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            util_1.compile(tcb)
                .then(function (rtc) { fixture = rtc; })
                .then(function (_) { return rtr.config([new route_config_decorator_1.Route({ path: '/...', component: LifecycleCmp })]); })
                .then(function (_) {
                async_1.ObservableWrapper.subscribe(eventBus, function (ev) {
                    if (ev.startsWith('routerCanActivate')) {
                        completer.resolve(true);
                    }
                });
                rtr.navigateByUrl('/can-activate/a')
                    .then(function (_) {
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('routerCanActivate {A}');
                    testing_internal_1.expect(log).toEqual(['routerCanActivate: null -> /can-activate']);
                    async.done();
                });
            });
        }));
        testing_internal_1.it('should not navigate when routerCanActivate returns false', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            util_1.compile(tcb)
                .then(function (rtc) { fixture = rtc; })
                .then(function (_) { return rtr.config([new route_config_decorator_1.Route({ path: '/...', component: LifecycleCmp })]); })
                .then(function (_) {
                async_1.ObservableWrapper.subscribe(eventBus, function (ev) {
                    if (ev.startsWith('routerCanActivate')) {
                        completer.resolve(false);
                    }
                });
                rtr.navigateByUrl('/can-activate/a')
                    .then(function (_) {
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('');
                    testing_internal_1.expect(log).toEqual(['routerCanActivate: null -> /can-activate']);
                    async.done();
                });
            });
        }));
        testing_internal_1.it('should navigate away when routerCanDeactivate returns true', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            util_1.compile(tcb)
                .then(function (rtc) { fixture = rtc; })
                .then(function (_) { return rtr.config([new route_config_decorator_1.Route({ path: '/...', component: LifecycleCmp })]); })
                .then(function (_) { return rtr.navigateByUrl('/can-deactivate/a'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('routerCanDeactivate {A}');
                testing_internal_1.expect(log).toEqual([]);
                async_1.ObservableWrapper.subscribe(eventBus, function (ev) {
                    if (ev.startsWith('routerCanDeactivate')) {
                        completer.resolve(true);
                    }
                });
                rtr.navigateByUrl('/a').then(function (_) {
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('A');
                    testing_internal_1.expect(log).toEqual(['routerCanDeactivate: /can-deactivate -> /a']);
                    async.done();
                });
            });
        }));
        testing_internal_1.it('should not navigate away when routerCanDeactivate returns false', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            util_1.compile(tcb)
                .then(function (rtc) { fixture = rtc; })
                .then(function (_) { return rtr.config([new route_config_decorator_1.Route({ path: '/...', component: LifecycleCmp })]); })
                .then(function (_) { return rtr.navigateByUrl('/can-deactivate/a'); })
                .then(function (_) {
                fixture.detectChanges();
                testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('routerCanDeactivate {A}');
                testing_internal_1.expect(log).toEqual([]);
                async_1.ObservableWrapper.subscribe(eventBus, function (ev) {
                    if (ev.startsWith('routerCanDeactivate')) {
                        completer.resolve(false);
                    }
                });
                rtr.navigateByUrl('/a').then(function (_) {
                    fixture.detectChanges();
                    testing_internal_1.expect(fixture.debugElement.nativeElement).toHaveText('routerCanDeactivate {A}');
                    testing_internal_1.expect(log).toEqual(['routerCanDeactivate: /can-deactivate -> /a']);
                    async.done();
                });
            });
        }));
        testing_internal_1.it('should run activation and deactivation hooks in the correct order', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            util_1.compile(tcb)
                .then(function (rtc) { fixture = rtc; })
                .then(function (_) { return rtr.config([new route_config_decorator_1.Route({ path: '/...', component: LifecycleCmp })]); })
                .then(function (_) { return rtr.navigateByUrl('/activation-hooks/child'); })
                .then(function (_) {
                testing_internal_1.expect(log).toEqual([
                    'routerCanActivate child: null -> /child',
                    'routerCanActivate parent: null -> /activation-hooks',
                    'routerOnActivate parent: null -> /activation-hooks',
                    'routerOnActivate child: null -> /child'
                ]);
                log = [];
                return rtr.navigateByUrl('/a');
            })
                .then(function (_) {
                testing_internal_1.expect(log).toEqual([
                    'routerCanDeactivate parent: /activation-hooks -> /a',
                    'routerCanDeactivate child: /child -> null',
                    'routerOnDeactivate child: /child -> null',
                    'routerOnDeactivate parent: /activation-hooks -> /a'
                ]);
                async.done();
            });
        }));
        testing_internal_1.it('should only run reuse hooks when reusing', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            util_1.compile(tcb)
                .then(function (rtc) { fixture = rtc; })
                .then(function (_) { return rtr.config([new route_config_decorator_1.Route({ path: '/...', component: LifecycleCmp })]); })
                .then(function (_) { return rtr.navigateByUrl('/reuse-hooks/1'); })
                .then(function (_) {
                testing_internal_1.expect(log).toEqual([
                    'routerCanActivate: null -> /reuse-hooks/1',
                    'routerOnActivate: null -> /reuse-hooks/1'
                ]);
                async_1.ObservableWrapper.subscribe(eventBus, function (ev) {
                    if (ev.startsWith('routerCanReuse')) {
                        completer.resolve(true);
                    }
                });
                log = [];
                return rtr.navigateByUrl('/reuse-hooks/2');
            })
                .then(function (_) {
                testing_internal_1.expect(log).toEqual([
                    'routerCanReuse: /reuse-hooks/1 -> /reuse-hooks/2',
                    'routerOnReuse: /reuse-hooks/1 -> /reuse-hooks/2'
                ]);
                async.done();
            });
        }));
        testing_internal_1.it('should not run reuse hooks when not reusing', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            util_1.compile(tcb)
                .then(function (_) { return rtr.config([new route_config_decorator_1.Route({ path: '/...', component: LifecycleCmp })]); })
                .then(function (_) { return rtr.navigateByUrl('/reuse-hooks/1'); })
                .then(function (_) {
                testing_internal_1.expect(log).toEqual([
                    'routerCanActivate: null -> /reuse-hooks/1',
                    'routerOnActivate: null -> /reuse-hooks/1'
                ]);
                async_1.ObservableWrapper.subscribe(eventBus, function (ev) {
                    if (ev.startsWith('routerCanReuse')) {
                        completer.resolve(false);
                    }
                });
                log = [];
                return rtr.navigateByUrl('/reuse-hooks/2');
            })
                .then(function (_) {
                testing_internal_1.expect(log).toEqual([
                    'routerCanReuse: /reuse-hooks/1 -> /reuse-hooks/2',
                    'routerCanActivate: /reuse-hooks/1 -> /reuse-hooks/2',
                    'routerCanDeactivate: /reuse-hooks/1 -> /reuse-hooks/2',
                    'routerOnDeactivate: /reuse-hooks/1 -> /reuse-hooks/2',
                    'routerOnActivate: /reuse-hooks/1 -> /reuse-hooks/2'
                ]);
                async.done();
            });
        }));
    });
}
exports.main = main;
var A = (function () {
    function A() {
    }
    A = __decorate([
        core_1.Component({ selector: 'a-cmp', template: "A" }), 
        __metadata('design:paramtypes', [])
    ], A);
    return A;
})();
var B = (function () {
    function B() {
    }
    B = __decorate([
        core_1.Component({ selector: 'b-cmp', template: "B" }), 
        __metadata('design:paramtypes', [])
    ], B);
    return B;
})();
function logHook(name, next, prev) {
    var message = name + ': ' + (lang_1.isPresent(prev) ? ('/' + prev.urlPath) : 'null') + ' -> ' +
        (lang_1.isPresent(next) ? ('/' + next.urlPath) : 'null');
    log.push(message);
    async_1.ObservableWrapper.callEmit(eventBus, message);
}
var ActivateCmp = (function () {
    function ActivateCmp() {
    }
    ActivateCmp.prototype.routerOnActivate = function (next, prev) {
        logHook('activate', next, prev);
    };
    ActivateCmp = __decorate([
        core_1.Component({ selector: 'activate-cmp', template: 'activate cmp' }), 
        __metadata('design:paramtypes', [])
    ], ActivateCmp);
    return ActivateCmp;
})();
var ParentActivateCmp = (function () {
    function ParentActivateCmp() {
    }
    ParentActivateCmp.prototype.routerOnActivate = function (next, prev) {
        completer = async_1.PromiseWrapper.completer();
        logHook('parent activate', next, prev);
        return completer.promise;
    };
    ParentActivateCmp = __decorate([
        core_1.Component({
            selector: 'parent-activate-cmp',
            template: "parent {<router-outlet></router-outlet>}",
            directives: [router_1.RouterOutlet]
        }),
        route_config_decorator_1.RouteConfig([new route_config_decorator_1.Route({ path: '/child-activate', component: ActivateCmp })]), 
        __metadata('design:paramtypes', [])
    ], ParentActivateCmp);
    return ParentActivateCmp;
})();
var DeactivateCmp = (function () {
    function DeactivateCmp() {
    }
    DeactivateCmp.prototype.routerOnDeactivate = function (next, prev) {
        logHook('deactivate', next, prev);
    };
    DeactivateCmp = __decorate([
        core_1.Component({ selector: 'deactivate-cmp', template: 'deactivate cmp' }), 
        __metadata('design:paramtypes', [])
    ], DeactivateCmp);
    return DeactivateCmp;
})();
var WaitDeactivateCmp = (function () {
    function WaitDeactivateCmp() {
    }
    WaitDeactivateCmp.prototype.routerOnDeactivate = function (next, prev) {
        completer = async_1.PromiseWrapper.completer();
        logHook('deactivate', next, prev);
        return completer.promise;
    };
    WaitDeactivateCmp = __decorate([
        core_1.Component({ selector: 'deactivate-cmp', template: 'deactivate cmp' }), 
        __metadata('design:paramtypes', [])
    ], WaitDeactivateCmp);
    return WaitDeactivateCmp;
})();
var ParentDeactivateCmp = (function () {
    function ParentDeactivateCmp() {
    }
    ParentDeactivateCmp.prototype.routerOnDeactivate = function (next, prev) {
        logHook('parent deactivate', next, prev);
    };
    ParentDeactivateCmp = __decorate([
        core_1.Component({
            selector: 'parent-deactivate-cmp',
            template: "parent {<router-outlet></router-outlet>}",
            directives: [router_1.RouterOutlet]
        }),
        route_config_decorator_1.RouteConfig([new route_config_decorator_1.Route({ path: '/child-deactivate', component: WaitDeactivateCmp })]), 
        __metadata('design:paramtypes', [])
    ], ParentDeactivateCmp);
    return ParentDeactivateCmp;
})();
var ReuseCmp = (function () {
    function ReuseCmp() {
        cmpInstanceCount += 1;
    }
    ReuseCmp.prototype.routerCanReuse = function (next, prev) { return true; };
    ReuseCmp.prototype.routerOnReuse = function (next, prev) {
        logHook('reuse', next, prev);
    };
    ReuseCmp = __decorate([
        core_1.Component({
            selector: 'reuse-cmp',
            template: "reuse {<router-outlet></router-outlet>}",
            directives: [router_1.RouterOutlet]
        }),
        route_config_decorator_1.RouteConfig([new route_config_decorator_1.Route({ path: '/a', component: A }), new route_config_decorator_1.Route({ path: '/b', component: B })]), 
        __metadata('design:paramtypes', [])
    ], ReuseCmp);
    return ReuseCmp;
})();
var NeverReuseCmp = (function () {
    function NeverReuseCmp() {
        cmpInstanceCount += 1;
    }
    NeverReuseCmp.prototype.routerCanReuse = function (next, prev) { return false; };
    NeverReuseCmp.prototype.routerOnReuse = function (next, prev) {
        logHook('reuse', next, prev);
    };
    NeverReuseCmp = __decorate([
        core_1.Component({
            selector: 'never-reuse-cmp',
            template: "reuse {<router-outlet></router-outlet>}",
            directives: [router_1.RouterOutlet]
        }),
        route_config_decorator_1.RouteConfig([new route_config_decorator_1.Route({ path: '/a', component: A }), new route_config_decorator_1.Route({ path: '/b', component: B })]), 
        __metadata('design:paramtypes', [])
    ], NeverReuseCmp);
    return NeverReuseCmp;
})();
var CanActivateCmp = (function () {
    function CanActivateCmp() {
    }
    CanActivateCmp.routerCanActivate = function (next, prev) {
        completer = async_1.PromiseWrapper.completer();
        logHook('routerCanActivate', next, prev);
        return completer.promise;
    };
    CanActivateCmp = __decorate([
        core_1.Component({
            selector: 'can-activate-cmp',
            template: "routerCanActivate {<router-outlet></router-outlet>}",
            directives: [router_1.RouterOutlet]
        }),
        route_config_decorator_1.RouteConfig([new route_config_decorator_1.Route({ path: '/a', component: A }), new route_config_decorator_1.Route({ path: '/b', component: B })]),
        lifecycle_annotations_1.CanActivate(CanActivateCmp.routerCanActivate), 
        __metadata('design:paramtypes', [])
    ], CanActivateCmp);
    return CanActivateCmp;
})();
var CanDeactivateCmp = (function () {
    function CanDeactivateCmp() {
    }
    CanDeactivateCmp.prototype.routerCanDeactivate = function (next, prev) {
        completer = async_1.PromiseWrapper.completer();
        logHook('routerCanDeactivate', next, prev);
        return completer.promise;
    };
    CanDeactivateCmp = __decorate([
        core_1.Component({
            selector: 'can-deactivate-cmp',
            template: "routerCanDeactivate {<router-outlet></router-outlet>}",
            directives: [router_1.RouterOutlet]
        }),
        route_config_decorator_1.RouteConfig([new route_config_decorator_1.Route({ path: '/a', component: A }), new route_config_decorator_1.Route({ path: '/b', component: B })]), 
        __metadata('design:paramtypes', [])
    ], CanDeactivateCmp);
    return CanDeactivateCmp;
})();
var AllHooksChildCmp = (function () {
    function AllHooksChildCmp() {
    }
    AllHooksChildCmp.prototype.routerCanDeactivate = function (next, prev) {
        logHook('routerCanDeactivate child', next, prev);
        return true;
    };
    AllHooksChildCmp.prototype.routerOnDeactivate = function (next, prev) {
        logHook('routerOnDeactivate child', next, prev);
    };
    AllHooksChildCmp.routerCanActivate = function (next, prev) {
        logHook('routerCanActivate child', next, prev);
        return true;
    };
    AllHooksChildCmp.prototype.routerOnActivate = function (next, prev) {
        logHook('routerOnActivate child', next, prev);
    };
    AllHooksChildCmp = __decorate([
        core_1.Component({ selector: 'all-hooks-child-cmp', template: "child" }),
        lifecycle_annotations_1.CanActivate(AllHooksChildCmp.routerCanActivate), 
        __metadata('design:paramtypes', [])
    ], AllHooksChildCmp);
    return AllHooksChildCmp;
})();
var AllHooksParentCmp = (function () {
    function AllHooksParentCmp() {
    }
    AllHooksParentCmp.prototype.routerCanDeactivate = function (next, prev) {
        logHook('routerCanDeactivate parent', next, prev);
        return true;
    };
    AllHooksParentCmp.prototype.routerOnDeactivate = function (next, prev) {
        logHook('routerOnDeactivate parent', next, prev);
    };
    AllHooksParentCmp.routerCanActivate = function (next, prev) {
        logHook('routerCanActivate parent', next, prev);
        return true;
    };
    AllHooksParentCmp.prototype.routerOnActivate = function (next, prev) {
        logHook('routerOnActivate parent', next, prev);
    };
    AllHooksParentCmp = __decorate([
        core_1.Component({
            selector: 'all-hooks-parent-cmp',
            template: "<router-outlet></router-outlet>",
            directives: [router_1.RouterOutlet]
        }),
        route_config_decorator_1.RouteConfig([new route_config_decorator_1.Route({ path: '/child', component: AllHooksChildCmp })]),
        lifecycle_annotations_1.CanActivate(AllHooksParentCmp.routerCanActivate), 
        __metadata('design:paramtypes', [])
    ], AllHooksParentCmp);
    return AllHooksParentCmp;
})();
var ReuseHooksCmp = (function () {
    function ReuseHooksCmp() {
    }
    ReuseHooksCmp.prototype.routerCanReuse = function (next, prev) {
        completer = async_1.PromiseWrapper.completer();
        logHook('routerCanReuse', next, prev);
        return completer.promise;
    };
    ReuseHooksCmp.prototype.routerOnReuse = function (next, prev) {
        logHook('routerOnReuse', next, prev);
    };
    ReuseHooksCmp.prototype.routerCanDeactivate = function (next, prev) {
        logHook('routerCanDeactivate', next, prev);
        return true;
    };
    ReuseHooksCmp.prototype.routerOnDeactivate = function (next, prev) {
        logHook('routerOnDeactivate', next, prev);
    };
    ReuseHooksCmp.routerCanActivate = function (next, prev) {
        logHook('routerCanActivate', next, prev);
        return true;
    };
    ReuseHooksCmp.prototype.routerOnActivate = function (next, prev) {
        logHook('routerOnActivate', next, prev);
    };
    ReuseHooksCmp = __decorate([
        core_1.Component({ selector: 'reuse-hooks-cmp', template: 'reuse hooks cmp' }),
        lifecycle_annotations_1.CanActivate(ReuseHooksCmp.routerCanActivate), 
        __metadata('design:paramtypes', [])
    ], ReuseHooksCmp);
    return ReuseHooksCmp;
})();
var LifecycleCmp = (function () {
    function LifecycleCmp() {
    }
    LifecycleCmp = __decorate([
        core_1.Component({
            selector: 'lifecycle-cmp',
            template: "<router-outlet></router-outlet>",
            directives: [router_1.RouterOutlet]
        }),
        route_config_decorator_1.RouteConfig([
            new route_config_decorator_1.Route({ path: '/a', component: A }),
            new route_config_decorator_1.Route({ path: '/on-activate', component: ActivateCmp }),
            new route_config_decorator_1.Route({ path: '/parent-activate/...', component: ParentActivateCmp }),
            new route_config_decorator_1.Route({ path: '/on-deactivate', component: DeactivateCmp }),
            new route_config_decorator_1.Route({ path: '/parent-deactivate/...', component: ParentDeactivateCmp }),
            new route_config_decorator_1.Route({ path: '/on-reuse/:number/...', component: ReuseCmp }),
            new route_config_decorator_1.Route({ path: '/never-reuse/:number/...', component: NeverReuseCmp }),
            new route_config_decorator_1.Route({ path: '/can-activate/...', component: CanActivateCmp }),
            new route_config_decorator_1.Route({ path: '/can-deactivate/...', component: CanDeactivateCmp }),
            new route_config_decorator_1.Route({ path: '/activation-hooks/...', component: AllHooksParentCmp }),
            new route_config_decorator_1.Route({ path: '/reuse-hooks/:number', component: ReuseHooksCmp })
        ]), 
        __metadata('design:paramtypes', [])
    ], LifecycleCmp);
    return LifecycleCmp;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGlmZWN5Y2xlX2hvb2tfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3Qvcm91dGVyL2ludGVncmF0aW9uL2xpZmVjeWNsZV9ob29rX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiIsIkEiLCJBLmNvbnN0cnVjdG9yIiwiQiIsIkIuY29uc3RydWN0b3IiLCJsb2dIb29rIiwiQWN0aXZhdGVDbXAiLCJBY3RpdmF0ZUNtcC5jb25zdHJ1Y3RvciIsIkFjdGl2YXRlQ21wLnJvdXRlck9uQWN0aXZhdGUiLCJQYXJlbnRBY3RpdmF0ZUNtcCIsIlBhcmVudEFjdGl2YXRlQ21wLmNvbnN0cnVjdG9yIiwiUGFyZW50QWN0aXZhdGVDbXAucm91dGVyT25BY3RpdmF0ZSIsIkRlYWN0aXZhdGVDbXAiLCJEZWFjdGl2YXRlQ21wLmNvbnN0cnVjdG9yIiwiRGVhY3RpdmF0ZUNtcC5yb3V0ZXJPbkRlYWN0aXZhdGUiLCJXYWl0RGVhY3RpdmF0ZUNtcCIsIldhaXREZWFjdGl2YXRlQ21wLmNvbnN0cnVjdG9yIiwiV2FpdERlYWN0aXZhdGVDbXAucm91dGVyT25EZWFjdGl2YXRlIiwiUGFyZW50RGVhY3RpdmF0ZUNtcCIsIlBhcmVudERlYWN0aXZhdGVDbXAuY29uc3RydWN0b3IiLCJQYXJlbnREZWFjdGl2YXRlQ21wLnJvdXRlck9uRGVhY3RpdmF0ZSIsIlJldXNlQ21wIiwiUmV1c2VDbXAuY29uc3RydWN0b3IiLCJSZXVzZUNtcC5yb3V0ZXJDYW5SZXVzZSIsIlJldXNlQ21wLnJvdXRlck9uUmV1c2UiLCJOZXZlclJldXNlQ21wIiwiTmV2ZXJSZXVzZUNtcC5jb25zdHJ1Y3RvciIsIk5ldmVyUmV1c2VDbXAucm91dGVyQ2FuUmV1c2UiLCJOZXZlclJldXNlQ21wLnJvdXRlck9uUmV1c2UiLCJDYW5BY3RpdmF0ZUNtcCIsIkNhbkFjdGl2YXRlQ21wLmNvbnN0cnVjdG9yIiwiQ2FuQWN0aXZhdGVDbXAucm91dGVyQ2FuQWN0aXZhdGUiLCJDYW5EZWFjdGl2YXRlQ21wIiwiQ2FuRGVhY3RpdmF0ZUNtcC5jb25zdHJ1Y3RvciIsIkNhbkRlYWN0aXZhdGVDbXAucm91dGVyQ2FuRGVhY3RpdmF0ZSIsIkFsbEhvb2tzQ2hpbGRDbXAiLCJBbGxIb29rc0NoaWxkQ21wLmNvbnN0cnVjdG9yIiwiQWxsSG9va3NDaGlsZENtcC5yb3V0ZXJDYW5EZWFjdGl2YXRlIiwiQWxsSG9va3NDaGlsZENtcC5yb3V0ZXJPbkRlYWN0aXZhdGUiLCJBbGxIb29rc0NoaWxkQ21wLnJvdXRlckNhbkFjdGl2YXRlIiwiQWxsSG9va3NDaGlsZENtcC5yb3V0ZXJPbkFjdGl2YXRlIiwiQWxsSG9va3NQYXJlbnRDbXAiLCJBbGxIb29rc1BhcmVudENtcC5jb25zdHJ1Y3RvciIsIkFsbEhvb2tzUGFyZW50Q21wLnJvdXRlckNhbkRlYWN0aXZhdGUiLCJBbGxIb29rc1BhcmVudENtcC5yb3V0ZXJPbkRlYWN0aXZhdGUiLCJBbGxIb29rc1BhcmVudENtcC5yb3V0ZXJDYW5BY3RpdmF0ZSIsIkFsbEhvb2tzUGFyZW50Q21wLnJvdXRlck9uQWN0aXZhdGUiLCJSZXVzZUhvb2tzQ21wIiwiUmV1c2VIb29rc0NtcC5jb25zdHJ1Y3RvciIsIlJldXNlSG9va3NDbXAucm91dGVyQ2FuUmV1c2UiLCJSZXVzZUhvb2tzQ21wLnJvdXRlck9uUmV1c2UiLCJSZXVzZUhvb2tzQ21wLnJvdXRlckNhbkRlYWN0aXZhdGUiLCJSZXVzZUhvb2tzQ21wLnJvdXRlck9uRGVhY3RpdmF0ZSIsIlJldXNlSG9va3NDbXAucm91dGVyQ2FuQWN0aXZhdGUiLCJSZXVzZUhvb2tzQ21wLnJvdXRlck9uQWN0aXZhdGUiLCJMaWZlY3ljbGVDbXAiLCJMaWZlY3ljbGVDbXAuY29uc3RydWN0b3IiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLGlDQWVPLDJCQUEyQixDQUFDLENBQUE7QUFFbkMscUJBQW1ELGVBQWUsQ0FBQyxDQUFBO0FBQ25FLHFCQUF3QiwwQkFBMEIsQ0FBQyxDQUFBO0FBQ25ELHNCQUtPLDJCQUEyQixDQUFDLENBQUE7QUFFbkMsdUJBQTRELGlCQUFpQixDQUFDLENBQUE7QUFDOUUsdUNBTU8seURBQXlELENBQUMsQ0FBQTtBQVNqRSxzQ0FBMEIscURBQXFELENBQUMsQ0FBQTtBQUloRixxQkFBc0QsUUFBUSxDQUFDLENBQUE7QUFFL0QsSUFBSSxnQkFBZ0IsQ0FBQztBQUNyQixJQUFJLEdBQWEsQ0FBQztBQUNsQixJQUFJLFFBQTJCLENBQUM7QUFDaEMsSUFBSSxTQUFnQyxDQUFDO0FBRXJDO0lBQ0VBLDJCQUFRQSxDQUFDQSx3QkFBd0JBLEVBQUVBO1FBRWpDQSxJQUFJQSxHQUF5QkEsQ0FBQ0E7UUFDOUJBLElBQUlBLE9BQXlCQSxDQUFDQTtRQUM5QkEsSUFBSUEsR0FBV0EsQ0FBQ0E7UUFFaEJBLHNDQUFtQkEsQ0FBQ0EsY0FBTUEsT0FBQUEsNEJBQXFCQSxFQUFyQkEsQ0FBcUJBLENBQUNBLENBQUNBO1FBRWpEQSw2QkFBVUEsQ0FBQ0EseUJBQU1BLENBQUNBLENBQUNBLHVDQUFvQkEsRUFBRUEsZUFBTUEsQ0FBQ0EsRUFDOUJBLFVBQUNBLFNBQStCQSxFQUFFQSxNQUFjQTtZQUM5Q0EsR0FBR0EsR0FBR0EsU0FBU0EsQ0FBQ0E7WUFDaEJBLEdBQUdBLEdBQUdBLE1BQU1BLENBQUNBO1lBQ2JBLGdCQUFnQkEsR0FBR0EsQ0FBQ0EsQ0FBQ0E7WUFDckJBLEdBQUdBLEdBQUdBLEVBQUVBLENBQUNBO1lBQ1RBLFFBQVFBLEdBQUdBLElBQUlBLG9CQUFZQSxFQUFFQSxDQUFDQTtRQUNoQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFdEJBLHFCQUFFQSxDQUFDQSx1Q0FBdUNBLEVBQUVBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO1lBQzFFQSxjQUFPQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDUEEsSUFBSUEsQ0FBQ0EsVUFBQ0EsR0FBR0EsSUFBTUEsT0FBT0EsR0FBR0EsR0FBR0EsQ0FBQUEsQ0FBQUEsQ0FBQ0EsQ0FBQ0E7aUJBQzlCQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxHQUFHQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsTUFBTUEsRUFBRUEsU0FBU0EsRUFBRUEsWUFBWUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBaEVBLENBQWdFQSxDQUFDQTtpQkFDN0VBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBLElBQUtBLE9BQUFBLEdBQUdBLENBQUNBLGFBQWFBLENBQUNBLGNBQWNBLENBQUNBLEVBQWpDQSxDQUFpQ0EsQ0FBQ0E7aUJBQzlDQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQTtnQkFDTkEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7Z0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsY0FBY0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3RFQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsZ0NBQWdDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDeERBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLHFCQUFFQSxDQUFDQSxvR0FBb0dBLEVBQ3BHQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtZQUNqQ0EsY0FBT0EsQ0FBQ0EsR0FBR0EsQ0FBQ0E7aUJBQ1BBLElBQUlBLENBQUNBLFVBQUNBLEdBQUdBLElBQU1BLE9BQU9BLEdBQUdBLEdBQUdBLENBQUFBLENBQUFBLENBQUNBLENBQUNBO2lCQUM5QkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0EsSUFBS0EsT0FBQUEsR0FBR0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsOEJBQUtBLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLE1BQU1BLEVBQUVBLFNBQVNBLEVBQUVBLFlBQVlBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBLEVBQWhFQSxDQUFnRUEsQ0FBQ0E7aUJBQzdFQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQTtnQkFDTkEseUJBQWlCQSxDQUFDQSxTQUFTQSxDQUFTQSxRQUFRQSxFQUFFQSxVQUFDQSxFQUFFQTtvQkFDL0NBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLFVBQVVBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQ3JDQSxTQUFTQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtvQkFDMUJBLENBQUNBO2dCQUNIQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDSEEsR0FBR0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsaUNBQWlDQSxDQUFDQTtxQkFDL0NBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBO29CQUNOQSxPQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFDeEJBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBO29CQUMvRUEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBO3dCQUNsQkEsMkNBQTJDQTt3QkFDM0NBLG1DQUFtQ0E7cUJBQ3BDQSxDQUFDQSxDQUFDQTtvQkFDSEEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLHFCQUFFQSxDQUFDQSx5Q0FBeUNBLEVBQUVBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO1lBQzVFQSxjQUFPQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDUEEsSUFBSUEsQ0FBQ0EsVUFBQ0EsR0FBR0EsSUFBTUEsT0FBT0EsR0FBR0EsR0FBR0EsQ0FBQUEsQ0FBQUEsQ0FBQ0EsQ0FBQ0E7aUJBQzlCQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxHQUFHQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsTUFBTUEsRUFBRUEsU0FBU0EsRUFBRUEsWUFBWUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBaEVBLENBQWdFQSxDQUFDQTtpQkFDN0VBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBLElBQUtBLE9BQUFBLEdBQUdBLENBQUNBLGFBQWFBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsRUFBbkNBLENBQW1DQSxDQUFDQTtpQkFDaERBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBLElBQUtBLE9BQUFBLEdBQUdBLENBQUNBLGFBQWFBLENBQUNBLElBQUlBLENBQUNBLEVBQXZCQSxDQUF1QkEsQ0FBQ0E7aUJBQ3BDQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQTtnQkFDTkEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7Z0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzNEQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0Esa0NBQWtDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDMURBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLHFCQUFFQSxDQUFDQSxzR0FBc0dBLEVBQ3RHQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtZQUNqQ0EsY0FBT0EsQ0FBQ0EsR0FBR0EsQ0FBQ0E7aUJBQ1BBLElBQUlBLENBQUNBLFVBQUNBLEdBQUdBLElBQU1BLE9BQU9BLEdBQUdBLEdBQUdBLENBQUFBLENBQUFBLENBQUNBLENBQUNBO2lCQUM5QkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0EsSUFBS0EsT0FBQUEsR0FBR0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsOEJBQUtBLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLE1BQU1BLEVBQUVBLFNBQVNBLEVBQUVBLFlBQVlBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBLEVBQWhFQSxDQUFnRUEsQ0FBQ0E7aUJBQzdFQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxHQUFHQSxDQUFDQSxhQUFhQSxDQUFDQSxxQ0FBcUNBLENBQUNBLEVBQXhEQSxDQUF3REEsQ0FBQ0E7aUJBQ3JFQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQTtnQkFDTkEseUJBQWlCQSxDQUFDQSxTQUFTQSxDQUFTQSxRQUFRQSxFQUFFQSxVQUFDQSxFQUFFQTtvQkFDL0NBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLFVBQVVBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO3dCQUNoQ0EsU0FBU0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7d0JBQ3hCQSxPQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTt3QkFDeEJBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSx5QkFBeUJBLENBQUNBLENBQUNBO29CQUNuRkEsQ0FBQ0E7Z0JBQ0hBLENBQUNBLENBQUNBLENBQUNBO2dCQUNIQSxHQUFHQSxDQUFDQSxhQUFhQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQTtvQkFDN0JBLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUN4QkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO29CQUMzREEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBO3dCQUNsQkEsdUNBQXVDQTt3QkFDdkNBLDZDQUE2Q0E7cUJBQzlDQSxDQUFDQSxDQUFDQTtvQkFDSEEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ0xBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLHFCQUFFQSxDQUFDQSxvRUFBb0VBLEVBQ3BFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtZQUNqQ0EsY0FBT0EsQ0FBQ0EsR0FBR0EsQ0FBQ0E7aUJBQ1BBLElBQUlBLENBQUNBLFVBQUNBLEdBQUdBLElBQU1BLE9BQU9BLEdBQUdBLEdBQUdBLENBQUFBLENBQUFBLENBQUNBLENBQUNBO2lCQUM5QkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0EsSUFBS0EsT0FBQUEsR0FBR0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsOEJBQUtBLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLE1BQU1BLEVBQUVBLFNBQVNBLEVBQUVBLFlBQVlBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBLEVBQWhFQSxDQUFnRUEsQ0FBQ0E7aUJBQzdFQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxHQUFHQSxDQUFDQSxhQUFhQSxDQUFDQSxlQUFlQSxDQUFDQSxFQUFsQ0EsQ0FBa0NBLENBQUNBO2lCQUMvQ0EsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0E7Z0JBQ05BLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO2dCQUN4QkEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO2dCQUN4QkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO2dCQUNuRUEseUJBQU1BLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDbkNBLENBQUNBLENBQUNBO2lCQUNEQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxHQUFHQSxDQUFDQSxhQUFhQSxDQUFDQSxlQUFlQSxDQUFDQSxFQUFsQ0EsQ0FBa0NBLENBQUNBO2lCQUMvQ0EsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0E7Z0JBQ05BLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO2dCQUN4QkEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLG1DQUFtQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzNEQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ25FQSx5QkFBTUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDakNBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBR1BBLHFCQUFFQSxDQUFDQSx5RUFBeUVBLEVBQ3pFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtZQUNqQ0EsY0FBT0EsQ0FBQ0EsR0FBR0EsQ0FBQ0E7aUJBQ1BBLElBQUlBLENBQUNBLFVBQUNBLEdBQUdBLElBQU1BLE9BQU9BLEdBQUdBLEdBQUdBLENBQUFBLENBQUFBLENBQUNBLENBQUNBO2lCQUM5QkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0EsSUFBS0EsT0FBQUEsR0FBR0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsOEJBQUtBLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLE1BQU1BLEVBQUVBLFNBQVNBLEVBQUVBLFlBQVlBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBLEVBQWhFQSxDQUFnRUEsQ0FBQ0E7aUJBQzdFQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxHQUFHQSxDQUFDQSxhQUFhQSxDQUFDQSxrQkFBa0JBLENBQUNBLEVBQXJDQSxDQUFxQ0EsQ0FBQ0E7aUJBQ2xEQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQTtnQkFDTkEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7Z0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ25FQSx5QkFBTUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNuQ0EsQ0FBQ0EsQ0FBQ0E7aUJBQ0RBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBLElBQUtBLE9BQUFBLEdBQUdBLENBQUNBLGFBQWFBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsRUFBckNBLENBQXFDQSxDQUFDQTtpQkFDbERBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBO2dCQUNOQSxPQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtnQkFDeEJBLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtnQkFDeEJBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQTtnQkFDbkVBLHlCQUFNQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUNqQ0EsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7WUFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFHUEEscUJBQUVBLENBQUNBLHFEQUFxREEsRUFDckRBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO1lBQ2pDQSxjQUFPQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDUEEsSUFBSUEsQ0FBQ0EsVUFBQ0EsR0FBR0EsSUFBTUEsT0FBT0EsR0FBR0EsR0FBR0EsQ0FBQUEsQ0FBQUEsQ0FBQ0EsQ0FBQ0E7aUJBQzlCQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxHQUFHQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsTUFBTUEsRUFBRUEsU0FBU0EsRUFBRUEsWUFBWUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBaEVBLENBQWdFQSxDQUFDQTtpQkFDN0VBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBO2dCQUNOQSx5QkFBaUJBLENBQUNBLFNBQVNBLENBQVNBLFFBQVFBLEVBQUVBLFVBQUNBLEVBQUVBO29CQUMvQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDdkNBLFNBQVNBLENBQUNBLE9BQU9BLENBQUNBLElBQUlBLENBQUNBLENBQUNBO29CQUMxQkEsQ0FBQ0E7Z0JBQ0hBLENBQUNBLENBQUNBLENBQUNBO2dCQUNIQSxHQUFHQSxDQUFDQSxhQUFhQSxDQUFDQSxpQkFBaUJBLENBQUNBO3FCQUMvQkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0E7b0JBQ05BLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUN4QkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0E7b0JBQy9FQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsMENBQTBDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDbEVBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVQQSxxQkFBRUEsQ0FBQ0EsMERBQTBEQSxFQUMxREEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7WUFDakNBLGNBQU9BLENBQUNBLEdBQUdBLENBQUNBO2lCQUNQQSxJQUFJQSxDQUFDQSxVQUFDQSxHQUFHQSxJQUFNQSxPQUFPQSxHQUFHQSxHQUFHQSxDQUFBQSxDQUFBQSxDQUFDQSxDQUFDQTtpQkFDOUJBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBLElBQUtBLE9BQUFBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLElBQUlBLDhCQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxNQUFNQSxFQUFFQSxTQUFTQSxFQUFFQSxZQUFZQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFoRUEsQ0FBZ0VBLENBQUNBO2lCQUM3RUEsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0E7Z0JBQ05BLHlCQUFpQkEsQ0FBQ0EsU0FBU0EsQ0FBU0EsUUFBUUEsRUFBRUEsVUFBQ0EsRUFBRUE7b0JBQy9DQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxVQUFVQSxDQUFDQSxtQkFBbUJBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO3dCQUN2Q0EsU0FBU0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0E7b0JBQzNCQSxDQUFDQTtnQkFDSEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ0hBLEdBQUdBLENBQUNBLGFBQWFBLENBQUNBLGlCQUFpQkEsQ0FBQ0E7cUJBQy9CQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQTtvQkFDTkEsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7b0JBQ3hCQSx5QkFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7b0JBQzFEQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsMENBQTBDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDbEVBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVQQSxxQkFBRUEsQ0FBQ0EsNERBQTREQSxFQUM1REEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7WUFDakNBLGNBQU9BLENBQUNBLEdBQUdBLENBQUNBO2lCQUNQQSxJQUFJQSxDQUFDQSxVQUFDQSxHQUFHQSxJQUFNQSxPQUFPQSxHQUFHQSxHQUFHQSxDQUFBQSxDQUFBQSxDQUFDQSxDQUFDQTtpQkFDOUJBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBLElBQUtBLE9BQUFBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLElBQUlBLDhCQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxNQUFNQSxFQUFFQSxTQUFTQSxFQUFFQSxZQUFZQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFoRUEsQ0FBZ0VBLENBQUNBO2lCQUM3RUEsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0EsSUFBS0EsT0FBQUEsR0FBR0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxFQUF0Q0EsQ0FBc0NBLENBQUNBO2lCQUNuREEsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0E7Z0JBQ05BLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO2dCQUN4QkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLHlCQUF5QkEsQ0FBQ0EsQ0FBQ0E7Z0JBQ2pGQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7Z0JBRXhCQSx5QkFBaUJBLENBQUNBLFNBQVNBLENBQVNBLFFBQVFBLEVBQUVBLFVBQUNBLEVBQUVBO29CQUMvQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDekNBLFNBQVNBLENBQUNBLE9BQU9BLENBQUNBLElBQUlBLENBQUNBLENBQUNBO29CQUMxQkEsQ0FBQ0E7Z0JBQ0hBLENBQUNBLENBQUNBLENBQUNBO2dCQUVIQSxHQUFHQSxDQUFDQSxhQUFhQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQTtvQkFDN0JBLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBO29CQUN4QkEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO29CQUMzREEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLDRDQUE0Q0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ3BFQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFUEEscUJBQUVBLENBQUNBLGlFQUFpRUEsRUFDakVBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO1lBQ2pDQSxjQUFPQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDUEEsSUFBSUEsQ0FBQ0EsVUFBQ0EsR0FBR0EsSUFBTUEsT0FBT0EsR0FBR0EsR0FBR0EsQ0FBQUEsQ0FBQUEsQ0FBQ0EsQ0FBQ0E7aUJBQzlCQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxHQUFHQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsTUFBTUEsRUFBRUEsU0FBU0EsRUFBRUEsWUFBWUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBaEVBLENBQWdFQSxDQUFDQTtpQkFDN0VBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBLElBQUtBLE9BQUFBLEdBQUdBLENBQUNBLGFBQWFBLENBQUNBLG1CQUFtQkEsQ0FBQ0EsRUFBdENBLENBQXNDQSxDQUFDQTtpQkFDbkRBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBO2dCQUNOQSxPQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtnQkFDeEJBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSx5QkFBeUJBLENBQUNBLENBQUNBO2dCQUNqRkEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO2dCQUV4QkEseUJBQWlCQSxDQUFDQSxTQUFTQSxDQUFTQSxRQUFRQSxFQUFFQSxVQUFDQSxFQUFFQTtvQkFDL0NBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLFVBQVVBLENBQUNBLHFCQUFxQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQ3pDQSxTQUFTQSxDQUFDQSxPQUFPQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQTtvQkFDM0JBLENBQUNBO2dCQUNIQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFSEEsR0FBR0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0E7b0JBQzdCQSxPQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFDeEJBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxZQUFZQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSx5QkFBeUJBLENBQUNBLENBQUNBO29CQUNqRkEseUJBQU1BLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLDRDQUE0Q0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ3BFQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFHUEEscUJBQUVBLENBQUNBLG1FQUFtRUEsRUFDbkVBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO1lBQ2pDQSxjQUFPQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDUEEsSUFBSUEsQ0FBQ0EsVUFBQ0EsR0FBR0EsSUFBTUEsT0FBT0EsR0FBR0EsR0FBR0EsQ0FBQUEsQ0FBQUEsQ0FBQ0EsQ0FBQ0E7aUJBQzlCQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxHQUFHQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsTUFBTUEsRUFBRUEsU0FBU0EsRUFBRUEsWUFBWUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBaEVBLENBQWdFQSxDQUFDQTtpQkFDN0VBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBLElBQUtBLE9BQUFBLEdBQUdBLENBQUNBLGFBQWFBLENBQUNBLHlCQUF5QkEsQ0FBQ0EsRUFBNUNBLENBQTRDQSxDQUFDQTtpQkFDekRBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBO2dCQUNOQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0E7b0JBQ2xCQSx5Q0FBeUNBO29CQUN6Q0EscURBQXFEQTtvQkFDckRBLG9EQUFvREE7b0JBQ3BEQSx3Q0FBd0NBO2lCQUN6Q0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLEdBQUdBLEdBQUdBLEVBQUVBLENBQUNBO2dCQUNUQSxNQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxhQUFhQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtZQUNqQ0EsQ0FBQ0EsQ0FBQ0E7aUJBQ0RBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBO2dCQUNOQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0E7b0JBQ2xCQSxxREFBcURBO29CQUNyREEsMkNBQTJDQTtvQkFDM0NBLDBDQUEwQ0E7b0JBQzFDQSxvREFBb0RBO2lCQUNyREEsQ0FBQ0EsQ0FBQ0E7Z0JBQ0hBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBRVBBLHFCQUFFQSxDQUFDQSwwQ0FBMENBLEVBQUVBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO1lBQzdFQSxjQUFPQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDUEEsSUFBSUEsQ0FBQ0EsVUFBQ0EsR0FBR0EsSUFBTUEsT0FBT0EsR0FBR0EsR0FBR0EsQ0FBQUEsQ0FBQUEsQ0FBQ0EsQ0FBQ0E7aUJBQzlCQSxJQUFJQSxDQUFDQSxVQUFDQSxDQUFDQSxJQUFLQSxPQUFBQSxHQUFHQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsTUFBTUEsRUFBRUEsU0FBU0EsRUFBRUEsWUFBWUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBaEVBLENBQWdFQSxDQUFDQTtpQkFDN0VBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBLElBQUtBLE9BQUFBLEdBQUdBLENBQUNBLGFBQWFBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsRUFBbkNBLENBQW1DQSxDQUFDQTtpQkFDaERBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBO2dCQUNOQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0E7b0JBQ2xCQSwyQ0FBMkNBO29CQUMzQ0EsMENBQTBDQTtpQkFDM0NBLENBQUNBLENBQUNBO2dCQUVIQSx5QkFBaUJBLENBQUNBLFNBQVNBLENBQVNBLFFBQVFBLEVBQUVBLFVBQUNBLEVBQUVBO29CQUMvQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDcENBLFNBQVNBLENBQUNBLE9BQU9BLENBQUNBLElBQUlBLENBQUNBLENBQUNBO29CQUMxQkEsQ0FBQ0E7Z0JBQ0hBLENBQUNBLENBQUNBLENBQUNBO2dCQUdIQSxHQUFHQSxHQUFHQSxFQUFFQSxDQUFDQTtnQkFDVEEsTUFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQTtZQUM3Q0EsQ0FBQ0EsQ0FBQ0E7aUJBQ0RBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBO2dCQUNOQSx5QkFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0E7b0JBQ2xCQSxrREFBa0RBO29CQUNsREEsaURBQWlEQTtpQkFDbERBLENBQUNBLENBQUNBO2dCQUNIQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtZQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVQQSxxQkFBRUEsQ0FBQ0EsNkNBQTZDQSxFQUFFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtZQUNoRkEsY0FBT0EsQ0FBQ0EsR0FBR0EsQ0FBQ0E7aUJBQ1BBLElBQUlBLENBQUNBLFVBQUNBLENBQUNBLElBQUtBLE9BQUFBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLElBQUlBLDhCQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxNQUFNQSxFQUFFQSxTQUFTQSxFQUFFQSxZQUFZQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFoRUEsQ0FBZ0VBLENBQUNBO2lCQUM3RUEsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0EsSUFBS0EsT0FBQUEsR0FBR0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxFQUFuQ0EsQ0FBbUNBLENBQUNBO2lCQUNoREEsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0E7Z0JBQ05BLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQTtvQkFDbEJBLDJDQUEyQ0E7b0JBQzNDQSwwQ0FBMENBO2lCQUMzQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLHlCQUFpQkEsQ0FBQ0EsU0FBU0EsQ0FBU0EsUUFBUUEsRUFBRUEsVUFBQ0EsRUFBRUE7b0JBQy9DQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxVQUFVQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO3dCQUNwQ0EsU0FBU0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0E7b0JBQzNCQSxDQUFDQTtnQkFDSEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLEdBQUdBLEdBQUdBLEVBQUVBLENBQUNBO2dCQUNUQSxNQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxhQUFhQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBO1lBQzdDQSxDQUFDQSxDQUFDQTtpQkFDREEsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0E7Z0JBQ05BLHlCQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQTtvQkFDbEJBLGtEQUFrREE7b0JBQ2xEQSxxREFBcURBO29CQUNyREEsdURBQXVEQTtvQkFDdkRBLHNEQUFzREE7b0JBQ3REQSxvREFBb0RBO2lCQUNyREEsQ0FBQ0EsQ0FBQ0E7Z0JBQ0hBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO0lBQ1RBLENBQUNBLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBclVlLFlBQUksT0FxVW5CLENBQUE7QUFHRDtJQUFBQztJQUVBQyxDQUFDQTtJQUZERDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsT0FBT0EsRUFBRUEsUUFBUUEsRUFBRUEsR0FBR0EsRUFBQ0EsQ0FBQ0E7O1VBRTdDQTtJQUFEQSxRQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUM7QUFHRDtJQUFBRTtJQUVBQyxDQUFDQTtJQUZERDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsT0FBT0EsRUFBRUEsUUFBUUEsRUFBRUEsR0FBR0EsRUFBQ0EsQ0FBQ0E7O1VBRTdDQTtJQUFEQSxRQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUM7QUFHRCxpQkFBaUIsSUFBWSxFQUFFLElBQTBCLEVBQUUsSUFBMEI7SUFDbkZFLElBQUlBLE9BQU9BLEdBQUdBLElBQUlBLEdBQUdBLElBQUlBLEdBQUdBLENBQUNBLGdCQUFTQSxDQUFDQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxHQUFHQSxJQUFJQSxDQUFDQSxPQUFPQSxDQUFDQSxHQUFHQSxNQUFNQSxDQUFDQSxHQUFHQSxNQUFNQTtRQUN4RUEsQ0FBQ0EsZ0JBQVNBLENBQUNBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLEdBQUdBLEdBQUdBLElBQUlBLENBQUNBLE9BQU9BLENBQUNBLEdBQUdBLE1BQU1BLENBQUNBLENBQUNBO0lBQ2hFQSxHQUFHQSxDQUFDQSxJQUFJQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtJQUNsQkEseUJBQWlCQSxDQUFDQSxRQUFRQSxDQUFDQSxRQUFRQSxFQUFFQSxPQUFPQSxDQUFDQSxDQUFDQTtBQUNoREEsQ0FBQ0E7QUFFRDtJQUFBQztJQUtBQyxDQUFDQTtJQUhDRCxzQ0FBZ0JBLEdBQWhCQSxVQUFpQkEsSUFBMEJBLEVBQUVBLElBQTBCQTtRQUNyRUUsT0FBT0EsQ0FBQ0EsVUFBVUEsRUFBRUEsSUFBSUEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7SUFDbENBLENBQUNBO0lBSkhGO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxjQUFjQSxFQUFFQSxRQUFRQSxFQUFFQSxjQUFjQSxFQUFDQSxDQUFDQTs7b0JBSy9EQTtJQUFEQSxrQkFBQ0E7QUFBREEsQ0FBQ0EsQUFMRCxJQUtDO0FBRUQ7SUFBQUc7SUFZQUMsQ0FBQ0E7SUFMQ0QsNENBQWdCQSxHQUFoQkEsVUFBaUJBLElBQTBCQSxFQUFFQSxJQUEwQkE7UUFDckVFLFNBQVNBLEdBQUdBLHNCQUFjQSxDQUFDQSxTQUFTQSxFQUFFQSxDQUFDQTtRQUN2Q0EsT0FBT0EsQ0FBQ0EsaUJBQWlCQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtRQUN2Q0EsTUFBTUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsT0FBT0EsQ0FBQ0E7SUFDM0JBLENBQUNBO0lBWEhGO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxxQkFBcUJBO1lBQy9CQSxRQUFRQSxFQUFFQSwwQ0FBMENBO1lBQ3BEQSxVQUFVQSxFQUFFQSxDQUFDQSxxQkFBWUEsQ0FBQ0E7U0FDM0JBLENBQUNBO1FBQ0RBLG9DQUFXQSxDQUFDQSxDQUFDQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsaUJBQWlCQSxFQUFFQSxTQUFTQSxFQUFFQSxXQUFXQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTs7MEJBTzNFQTtJQUFEQSx3QkFBQ0E7QUFBREEsQ0FBQ0EsQUFaRCxJQVlDO0FBRUQ7SUFBQUc7SUFLQUMsQ0FBQ0E7SUFIQ0QsMENBQWtCQSxHQUFsQkEsVUFBbUJBLElBQTBCQSxFQUFFQSxJQUEwQkE7UUFDdkVFLE9BQU9BLENBQUNBLFlBQVlBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO0lBQ3BDQSxDQUFDQTtJQUpIRjtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsZ0JBQWdCQSxFQUFFQSxRQUFRQSxFQUFFQSxnQkFBZ0JBLEVBQUNBLENBQUNBOztzQkFLbkVBO0lBQURBLG9CQUFDQTtBQUFEQSxDQUFDQSxBQUxELElBS0M7QUFFRDtJQUFBRztJQU9BQyxDQUFDQTtJQUxDRCw4Q0FBa0JBLEdBQWxCQSxVQUFtQkEsSUFBMEJBLEVBQUVBLElBQTBCQTtRQUN2RUUsU0FBU0EsR0FBR0Esc0JBQWNBLENBQUNBLFNBQVNBLEVBQUVBLENBQUNBO1FBQ3ZDQSxPQUFPQSxDQUFDQSxZQUFZQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtRQUNsQ0EsTUFBTUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsT0FBT0EsQ0FBQ0E7SUFDM0JBLENBQUNBO0lBTkhGO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxnQkFBZ0JBLEVBQUVBLFFBQVFBLEVBQUVBLGdCQUFnQkEsRUFBQ0EsQ0FBQ0E7OzBCQU9uRUE7SUFBREEsd0JBQUNBO0FBQURBLENBQUNBLEFBUEQsSUFPQztBQUVEO0lBQUFHO0lBVUFDLENBQUNBO0lBSENELGdEQUFrQkEsR0FBbEJBLFVBQW1CQSxJQUEwQkEsRUFBRUEsSUFBMEJBO1FBQ3ZFRSxPQUFPQSxDQUFDQSxtQkFBbUJBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO0lBQzNDQSxDQUFDQTtJQVRIRjtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsdUJBQXVCQTtZQUNqQ0EsUUFBUUEsRUFBRUEsMENBQTBDQTtZQUNwREEsVUFBVUEsRUFBRUEsQ0FBQ0EscUJBQVlBLENBQUNBO1NBQzNCQSxDQUFDQTtRQUNEQSxvQ0FBV0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsOEJBQUtBLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLG1CQUFtQkEsRUFBRUEsU0FBU0EsRUFBRUEsaUJBQWlCQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTs7NEJBS25GQTtJQUFEQSwwQkFBQ0E7QUFBREEsQ0FBQ0EsQUFWRCxJQVVDO0FBRUQ7SUFRRUc7UUFBZ0JDLGdCQUFnQkEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFDeENELGlDQUFjQSxHQUFkQSxVQUFlQSxJQUEwQkEsRUFBRUEsSUFBMEJBLElBQUlFLE1BQU1BLENBQUNBLElBQUlBLENBQUNBLENBQUNBLENBQUNBO0lBQ3ZGRixnQ0FBYUEsR0FBYkEsVUFBY0EsSUFBMEJBLEVBQUVBLElBQTBCQTtRQUNsRUcsT0FBT0EsQ0FBQ0EsT0FBT0EsRUFBRUEsSUFBSUEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7SUFDL0JBLENBQUNBO0lBWkhIO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxXQUFXQTtZQUNyQkEsUUFBUUEsRUFBRUEseUNBQXlDQTtZQUNuREEsVUFBVUEsRUFBRUEsQ0FBQ0EscUJBQVlBLENBQUNBO1NBQzNCQSxDQUFDQTtRQUNEQSxvQ0FBV0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsOEJBQUtBLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLElBQUlBLEVBQUVBLFNBQVNBLEVBQUVBLENBQUNBLEVBQUNBLENBQUNBLEVBQUVBLElBQUlBLDhCQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxFQUFFQSxTQUFTQSxFQUFFQSxDQUFDQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTs7aUJBUTNGQTtJQUFEQSxlQUFDQTtBQUFEQSxDQUFDQSxBQWJELElBYUM7QUFFRDtJQVFFSTtRQUFnQkMsZ0JBQWdCQSxJQUFJQSxDQUFDQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUN4Q0Qsc0NBQWNBLEdBQWRBLFVBQWVBLElBQTBCQSxFQUFFQSxJQUEwQkEsSUFBSUUsTUFBTUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDeEZGLHFDQUFhQSxHQUFiQSxVQUFjQSxJQUEwQkEsRUFBRUEsSUFBMEJBO1FBQ2xFRyxPQUFPQSxDQUFDQSxPQUFPQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtJQUMvQkEsQ0FBQ0E7SUFaSEg7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLGlCQUFpQkE7WUFDM0JBLFFBQVFBLEVBQUVBLHlDQUF5Q0E7WUFDbkRBLFVBQVVBLEVBQUVBLENBQUNBLHFCQUFZQSxDQUFDQTtTQUMzQkEsQ0FBQ0E7UUFDREEsb0NBQVdBLENBQUNBLENBQUNBLElBQUlBLDhCQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxFQUFFQSxTQUFTQSxFQUFFQSxDQUFDQSxFQUFDQSxDQUFDQSxFQUFFQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsSUFBSUEsRUFBRUEsU0FBU0EsRUFBRUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7O3NCQVEzRkE7SUFBREEsb0JBQUNBO0FBQURBLENBQUNBLEFBYkQsSUFhQztBQUVEO0lBQUFJO0lBY0FDLENBQUNBO0lBTlFELGdDQUFpQkEsR0FBeEJBLFVBQXlCQSxJQUEwQkEsRUFDMUJBLElBQTBCQTtRQUNqREUsU0FBU0EsR0FBR0Esc0JBQWNBLENBQUNBLFNBQVNBLEVBQUVBLENBQUNBO1FBQ3ZDQSxPQUFPQSxDQUFDQSxtQkFBbUJBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO1FBQ3pDQSxNQUFNQSxDQUFDQSxTQUFTQSxDQUFDQSxPQUFPQSxDQUFDQTtJQUMzQkEsQ0FBQ0E7SUFiSEY7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLGtCQUFrQkE7WUFDNUJBLFFBQVFBLEVBQUVBLHFEQUFxREE7WUFDL0RBLFVBQVVBLEVBQUVBLENBQUNBLHFCQUFZQSxDQUFDQTtTQUMzQkEsQ0FBQ0E7UUFDREEsb0NBQVdBLENBQUNBLENBQUNBLElBQUlBLDhCQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxFQUFFQSxTQUFTQSxFQUFFQSxDQUFDQSxFQUFDQSxDQUFDQSxFQUFFQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsSUFBSUEsRUFBRUEsU0FBU0EsRUFBRUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDM0ZBLG1DQUFXQSxDQUFDQSxjQUFjQSxDQUFDQSxpQkFBaUJBLENBQUNBOzt1QkFRN0NBO0lBQURBLHFCQUFDQTtBQUFEQSxDQUFDQSxBQWRELElBY0M7QUFFRDtJQUFBRztJQVlBQyxDQUFDQTtJQUxDRCw4Q0FBbUJBLEdBQW5CQSxVQUFvQkEsSUFBMEJBLEVBQUVBLElBQTBCQTtRQUN4RUUsU0FBU0EsR0FBR0Esc0JBQWNBLENBQUNBLFNBQVNBLEVBQUVBLENBQUNBO1FBQ3ZDQSxPQUFPQSxDQUFDQSxxQkFBcUJBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO1FBQzNDQSxNQUFNQSxDQUFDQSxTQUFTQSxDQUFDQSxPQUFPQSxDQUFDQTtJQUMzQkEsQ0FBQ0E7SUFYSEY7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLG9CQUFvQkE7WUFDOUJBLFFBQVFBLEVBQUVBLHVEQUF1REE7WUFDakVBLFVBQVVBLEVBQUVBLENBQUNBLHFCQUFZQSxDQUFDQTtTQUMzQkEsQ0FBQ0E7UUFDREEsb0NBQVdBLENBQUNBLENBQUNBLElBQUlBLDhCQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxFQUFFQSxTQUFTQSxFQUFFQSxDQUFDQSxFQUFDQSxDQUFDQSxFQUFFQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsSUFBSUEsRUFBRUEsU0FBU0EsRUFBRUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7O3lCQU8zRkE7SUFBREEsdUJBQUNBO0FBQURBLENBQUNBLEFBWkQsSUFZQztBQUVEO0lBQUFHO0lBb0JBQyxDQUFDQTtJQWpCQ0QsOENBQW1CQSxHQUFuQkEsVUFBb0JBLElBQTBCQSxFQUFFQSxJQUEwQkE7UUFDeEVFLE9BQU9BLENBQUNBLDJCQUEyQkEsRUFBRUEsSUFBSUEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7UUFDakRBLE1BQU1BLENBQUNBLElBQUlBLENBQUNBO0lBQ2RBLENBQUNBO0lBRURGLDZDQUFrQkEsR0FBbEJBLFVBQW1CQSxJQUEwQkEsRUFBRUEsSUFBMEJBO1FBQ3ZFRyxPQUFPQSxDQUFDQSwwQkFBMEJBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO0lBQ2xEQSxDQUFDQTtJQUVNSCxrQ0FBaUJBLEdBQXhCQSxVQUF5QkEsSUFBMEJBLEVBQUVBLElBQTBCQTtRQUM3RUksT0FBT0EsQ0FBQ0EseUJBQXlCQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtRQUMvQ0EsTUFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0E7SUFDZEEsQ0FBQ0E7SUFFREosMkNBQWdCQSxHQUFoQkEsVUFBaUJBLElBQTBCQSxFQUFFQSxJQUEwQkE7UUFDckVLLE9BQU9BLENBQUNBLHdCQUF3QkEsRUFBRUEsSUFBSUEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7SUFDaERBLENBQUNBO0lBbkJITDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEscUJBQXFCQSxFQUFFQSxRQUFRQSxFQUFFQSxPQUFPQSxFQUFDQSxDQUFDQTtRQUMvREEsbUNBQVdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsaUJBQWlCQSxDQUFDQTs7eUJBbUIvQ0E7SUFBREEsdUJBQUNBO0FBQURBLENBQUNBLEFBcEJELElBb0JDO0FBRUQ7SUFBQU07SUEwQkFDLENBQUNBO0lBakJDRCwrQ0FBbUJBLEdBQW5CQSxVQUFvQkEsSUFBMEJBLEVBQUVBLElBQTBCQTtRQUN4RUUsT0FBT0EsQ0FBQ0EsNEJBQTRCQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtRQUNsREEsTUFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0E7SUFDZEEsQ0FBQ0E7SUFFREYsOENBQWtCQSxHQUFsQkEsVUFBbUJBLElBQTBCQSxFQUFFQSxJQUEwQkE7UUFDdkVHLE9BQU9BLENBQUNBLDJCQUEyQkEsRUFBRUEsSUFBSUEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7SUFDbkRBLENBQUNBO0lBRU1ILG1DQUFpQkEsR0FBeEJBLFVBQXlCQSxJQUEwQkEsRUFBRUEsSUFBMEJBO1FBQzdFSSxPQUFPQSxDQUFDQSwwQkFBMEJBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO1FBQ2hEQSxNQUFNQSxDQUFDQSxJQUFJQSxDQUFDQTtJQUNkQSxDQUFDQTtJQUVESiw0Q0FBZ0JBLEdBQWhCQSxVQUFpQkEsSUFBMEJBLEVBQUVBLElBQTBCQTtRQUNyRUssT0FBT0EsQ0FBQ0EseUJBQXlCQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtJQUNqREEsQ0FBQ0E7SUF6QkhMO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxzQkFBc0JBO1lBQ2hDQSxRQUFRQSxFQUFFQSxpQ0FBaUNBO1lBQzNDQSxVQUFVQSxFQUFFQSxDQUFDQSxxQkFBWUEsQ0FBQ0E7U0FDM0JBLENBQUNBO1FBQ0RBLG9DQUFXQSxDQUFDQSxDQUFDQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsUUFBUUEsRUFBRUEsU0FBU0EsRUFBRUEsZ0JBQWdCQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUN2RUEsbUNBQVdBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsaUJBQWlCQSxDQUFDQTs7MEJBb0JoREE7SUFBREEsd0JBQUNBO0FBQURBLENBQUNBLEFBMUJELElBMEJDO0FBRUQ7SUFBQU07SUE4QkFDLENBQUNBO0lBM0JDRCxzQ0FBY0EsR0FBZEEsVUFBZUEsSUFBMEJBLEVBQUVBLElBQTBCQTtRQUNuRUUsU0FBU0EsR0FBR0Esc0JBQWNBLENBQUNBLFNBQVNBLEVBQUVBLENBQUNBO1FBQ3ZDQSxPQUFPQSxDQUFDQSxnQkFBZ0JBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO1FBQ3RDQSxNQUFNQSxDQUFDQSxTQUFTQSxDQUFDQSxPQUFPQSxDQUFDQTtJQUMzQkEsQ0FBQ0E7SUFFREYscUNBQWFBLEdBQWJBLFVBQWNBLElBQTBCQSxFQUFFQSxJQUEwQkE7UUFDbEVHLE9BQU9BLENBQUNBLGVBQWVBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO0lBQ3ZDQSxDQUFDQTtJQUVESCwyQ0FBbUJBLEdBQW5CQSxVQUFvQkEsSUFBMEJBLEVBQUVBLElBQTBCQTtRQUN4RUksT0FBT0EsQ0FBQ0EscUJBQXFCQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtRQUMzQ0EsTUFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0E7SUFDZEEsQ0FBQ0E7SUFFREosMENBQWtCQSxHQUFsQkEsVUFBbUJBLElBQTBCQSxFQUFFQSxJQUEwQkE7UUFDdkVLLE9BQU9BLENBQUNBLG9CQUFvQkEsRUFBRUEsSUFBSUEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7SUFDNUNBLENBQUNBO0lBRU1MLCtCQUFpQkEsR0FBeEJBLFVBQXlCQSxJQUEwQkEsRUFBRUEsSUFBMEJBO1FBQzdFTSxPQUFPQSxDQUFDQSxtQkFBbUJBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO1FBQ3pDQSxNQUFNQSxDQUFDQSxJQUFJQSxDQUFDQTtJQUNkQSxDQUFDQTtJQUVETix3Q0FBZ0JBLEdBQWhCQSxVQUFpQkEsSUFBMEJBLEVBQUVBLElBQTBCQTtRQUNyRU8sT0FBT0EsQ0FBQ0Esa0JBQWtCQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtJQUMxQ0EsQ0FBQ0E7SUE3QkhQO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxpQkFBaUJBLEVBQUVBLFFBQVFBLEVBQUVBLGlCQUFpQkEsRUFBQ0EsQ0FBQ0E7UUFDckVBLG1DQUFXQSxDQUFDQSxhQUFhQSxDQUFDQSxpQkFBaUJBLENBQUNBOztzQkE2QjVDQTtJQUFEQSxvQkFBQ0E7QUFBREEsQ0FBQ0EsQUE5QkQsSUE4QkM7QUFFRDtJQUFBUTtJQW1CQUMsQ0FBQ0E7SUFuQkREO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxlQUFlQTtZQUN6QkEsUUFBUUEsRUFBRUEsaUNBQWlDQTtZQUMzQ0EsVUFBVUEsRUFBRUEsQ0FBQ0EscUJBQVlBLENBQUNBO1NBQzNCQSxDQUFDQTtRQUNEQSxvQ0FBV0EsQ0FBQ0E7WUFDWEEsSUFBSUEsOEJBQUtBLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLElBQUlBLEVBQUVBLFNBQVNBLEVBQUVBLENBQUNBLEVBQUNBLENBQUNBO1lBQ3JDQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsY0FBY0EsRUFBRUEsU0FBU0EsRUFBRUEsV0FBV0EsRUFBQ0EsQ0FBQ0E7WUFDekRBLElBQUlBLDhCQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxzQkFBc0JBLEVBQUVBLFNBQVNBLEVBQUVBLGlCQUFpQkEsRUFBQ0EsQ0FBQ0E7WUFDdkVBLElBQUlBLDhCQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxnQkFBZ0JBLEVBQUVBLFNBQVNBLEVBQUVBLGFBQWFBLEVBQUNBLENBQUNBO1lBQzdEQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsd0JBQXdCQSxFQUFFQSxTQUFTQSxFQUFFQSxtQkFBbUJBLEVBQUNBLENBQUNBO1lBQzNFQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsdUJBQXVCQSxFQUFFQSxTQUFTQSxFQUFFQSxRQUFRQSxFQUFDQSxDQUFDQTtZQUMvREEsSUFBSUEsOEJBQUtBLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLDBCQUEwQkEsRUFBRUEsU0FBU0EsRUFBRUEsYUFBYUEsRUFBQ0EsQ0FBQ0E7WUFDdkVBLElBQUlBLDhCQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxtQkFBbUJBLEVBQUVBLFNBQVNBLEVBQUVBLGNBQWNBLEVBQUNBLENBQUNBO1lBQ2pFQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEscUJBQXFCQSxFQUFFQSxTQUFTQSxFQUFFQSxnQkFBZ0JBLEVBQUNBLENBQUNBO1lBQ3JFQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsdUJBQXVCQSxFQUFFQSxTQUFTQSxFQUFFQSxpQkFBaUJBLEVBQUNBLENBQUNBO1lBQ3hFQSxJQUFJQSw4QkFBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsc0JBQXNCQSxFQUFFQSxTQUFTQSxFQUFFQSxhQUFhQSxFQUFDQSxDQUFDQTtTQUNwRUEsQ0FBQ0E7O3FCQUVEQTtJQUFEQSxtQkFBQ0E7QUFBREEsQ0FBQ0EsQUFuQkQsSUFtQkMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBDb21wb25lbnRGaXh0dXJlLFxuICBBc3luY1Rlc3RDb21wbGV0ZXIsXG4gIFRlc3RDb21wb25lbnRCdWlsZGVyLFxuICBiZWZvcmVFYWNoLFxuICBkZGVzY3JpYmUsXG4gIHhkZXNjcmliZSxcbiAgZGVzY3JpYmUsXG4gIGVsLFxuICBleHBlY3QsXG4gIGlpdCxcbiAgaW5qZWN0LFxuICBiZWZvcmVFYWNoUHJvdmlkZXJzLFxuICBpdCxcbiAgeGl0XG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5pbXBvcnQge3Byb3ZpZGUsIENvbXBvbmVudCwgSW5qZWN0b3IsIEluamVjdH0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5pbXBvcnQge2lzUHJlc2VudH0gZnJvbSAnYW5ndWxhcjIvc3JjL2ZhY2FkZS9sYW5nJztcbmltcG9ydCB7XG4gIFByb21pc2VXcmFwcGVyLFxuICBQcm9taXNlQ29tcGxldGVyLFxuICBFdmVudEVtaXR0ZXIsXG4gIE9ic2VydmFibGVXcmFwcGVyXG59IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvYXN5bmMnO1xuXG5pbXBvcnQge1JvdXRlciwgUm91dGVyT3V0bGV0LCBSb3V0ZXJMaW5rLCBSb3V0ZVBhcmFtc30gZnJvbSAnYW5ndWxhcjIvcm91dGVyJztcbmltcG9ydCB7XG4gIFJvdXRlQ29uZmlnLFxuICBSb3V0ZSxcbiAgQXV4Um91dGUsXG4gIEFzeW5jUm91dGUsXG4gIFJlZGlyZWN0XG59IGZyb20gJ2FuZ3VsYXIyL3NyYy9yb3V0ZXIvcm91dGVfY29uZmlnL3JvdXRlX2NvbmZpZ19kZWNvcmF0b3InO1xuXG5pbXBvcnQge1xuICBPbkFjdGl2YXRlLFxuICBPbkRlYWN0aXZhdGUsXG4gIE9uUmV1c2UsXG4gIENhbkRlYWN0aXZhdGUsXG4gIENhblJldXNlXG59IGZyb20gJ2FuZ3VsYXIyL3NyYy9yb3V0ZXIvaW50ZXJmYWNlcyc7XG5pbXBvcnQge0NhbkFjdGl2YXRlfSBmcm9tICdhbmd1bGFyMi9zcmMvcm91dGVyL2xpZmVjeWNsZS9saWZlY3ljbGVfYW5ub3RhdGlvbnMnO1xuaW1wb3J0IHtDb21wb25lbnRJbnN0cnVjdGlvbn0gZnJvbSAnYW5ndWxhcjIvc3JjL3JvdXRlci9pbnN0cnVjdGlvbic7XG5cblxuaW1wb3J0IHtURVNUX1JPVVRFUl9QUk9WSURFUlMsIFJvb3RDbXAsIGNvbXBpbGV9IGZyb20gJy4vdXRpbCc7XG5cbnZhciBjbXBJbnN0YW5jZUNvdW50O1xudmFyIGxvZzogc3RyaW5nW107XG52YXIgZXZlbnRCdXM6IEV2ZW50RW1pdHRlcjxhbnk+O1xudmFyIGNvbXBsZXRlcjogUHJvbWlzZUNvbXBsZXRlcjxhbnk+O1xuXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpIHtcbiAgZGVzY3JpYmUoJ1JvdXRlciBsaWZlY3ljbGUgaG9va3MnLCAoKSA9PiB7XG5cbiAgICB2YXIgdGNiOiBUZXN0Q29tcG9uZW50QnVpbGRlcjtcbiAgICB2YXIgZml4dHVyZTogQ29tcG9uZW50Rml4dHVyZTtcbiAgICB2YXIgcnRyOiBSb3V0ZXI7XG5cbiAgICBiZWZvcmVFYWNoUHJvdmlkZXJzKCgpID0+IFRFU1RfUk9VVEVSX1BST1ZJREVSUyk7XG5cbiAgICBiZWZvcmVFYWNoKGluamVjdChbVGVzdENvbXBvbmVudEJ1aWxkZXIsIFJvdXRlcl0sXG4gICAgICAgICAgICAgICAgICAgICAgKHRjQnVpbGRlcjogVGVzdENvbXBvbmVudEJ1aWxkZXIsIHJvdXRlcjogUm91dGVyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0Y2IgPSB0Y0J1aWxkZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICBydHIgPSByb3V0ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICBjbXBJbnN0YW5jZUNvdW50ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvZyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnRCdXMgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gICAgICAgICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBjYWxsIHRoZSByb3V0ZXJPbkFjdGl2YXRlIGhvb2snLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgY29tcGlsZSh0Y2IpXG4gICAgICAgICAgICAgLnRoZW4oKHJ0YykgPT4ge2ZpeHR1cmUgPSBydGN9KVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiBydHIuY29uZmlnKFtuZXcgUm91dGUoe3BhdGg6ICcvLi4uJywgY29tcG9uZW50OiBMaWZlY3ljbGVDbXB9KV0pKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiBydHIubmF2aWdhdGVCeVVybCgnL29uLWFjdGl2YXRlJykpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ2FjdGl2YXRlIGNtcCcpO1xuICAgICAgICAgICAgICAgZXhwZWN0KGxvZykudG9FcXVhbChbJ2FjdGl2YXRlOiBudWxsIC0+IC9vbi1hY3RpdmF0ZSddKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIHdhaXQgZm9yIGEgcGFyZW50IGNvbXBvbmVudFxcJ3Mgcm91dGVyT25BY3RpdmF0ZSBob29rIHRvIHJlc29sdmUgYmVmb3JlIGNhbGxpbmcgaXRzIGNoaWxkXFwncycsXG4gICAgICAgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgIGNvbXBpbGUodGNiKVxuICAgICAgICAgICAgIC50aGVuKChydGMpID0+IHtmaXh0dXJlID0gcnRjfSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcnRyLmNvbmZpZyhbbmV3IFJvdXRlKHtwYXRoOiAnLy4uLicsIGNvbXBvbmVudDogTGlmZWN5Y2xlQ21wfSldKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgT2JzZXJ2YWJsZVdyYXBwZXIuc3Vic2NyaWJlPHN0cmluZz4oZXZlbnRCdXMsIChldikgPT4ge1xuICAgICAgICAgICAgICAgICBpZiAoZXYuc3RhcnRzV2l0aCgncGFyZW50IGFjdGl2YXRlJykpIHtcbiAgICAgICAgICAgICAgICAgICBjb21wbGV0ZXIucmVzb2x2ZSh0cnVlKTtcbiAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICBydHIubmF2aWdhdGVCeVVybCgnL3BhcmVudC1hY3RpdmF0ZS9jaGlsZC1hY3RpdmF0ZScpXG4gICAgICAgICAgICAgICAgICAgLnRoZW4oKF8pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ3BhcmVudCB7YWN0aXZhdGUgY21wfScpO1xuICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGxvZykudG9FcXVhbChbXG4gICAgICAgICAgICAgICAgICAgICAgICdwYXJlbnQgYWN0aXZhdGU6IG51bGwgLT4gL3BhcmVudC1hY3RpdmF0ZScsXG4gICAgICAgICAgICAgICAgICAgICAgICdhY3RpdmF0ZTogbnVsbCAtPiAvY2hpbGQtYWN0aXZhdGUnXG4gICAgICAgICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIGNhbGwgdGhlIHJvdXRlck9uRGVhY3RpdmF0ZSBob29rJywgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgIGNvbXBpbGUodGNiKVxuICAgICAgICAgICAgIC50aGVuKChydGMpID0+IHtmaXh0dXJlID0gcnRjfSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcnRyLmNvbmZpZyhbbmV3IFJvdXRlKHtwYXRoOiAnLy4uLicsIGNvbXBvbmVudDogTGlmZWN5Y2xlQ21wfSldKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcnRyLm5hdmlnYXRlQnlVcmwoJy9vbi1kZWFjdGl2YXRlJykpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJ0ci5uYXZpZ2F0ZUJ5VXJsKCcvYScpKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiB7XG4gICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdBJyk7XG4gICAgICAgICAgICAgICBleHBlY3QobG9nKS50b0VxdWFsKFsnZGVhY3RpdmF0ZTogL29uLWRlYWN0aXZhdGUgLT4gL2EnXSk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCB3YWl0IGZvciBhIGNoaWxkIGNvbXBvbmVudFxcJ3Mgcm91dGVyT25EZWFjdGl2YXRlIGhvb2sgdG8gcmVzb2x2ZSBiZWZvcmUgY2FsbGluZyBpdHMgcGFyZW50XFwncycsXG4gICAgICAgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgIGNvbXBpbGUodGNiKVxuICAgICAgICAgICAgIC50aGVuKChydGMpID0+IHtmaXh0dXJlID0gcnRjfSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcnRyLmNvbmZpZyhbbmV3IFJvdXRlKHtwYXRoOiAnLy4uLicsIGNvbXBvbmVudDogTGlmZWN5Y2xlQ21wfSldKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcnRyLm5hdmlnYXRlQnlVcmwoJy9wYXJlbnQtZGVhY3RpdmF0ZS9jaGlsZC1kZWFjdGl2YXRlJykpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHtcbiAgICAgICAgICAgICAgIE9ic2VydmFibGVXcmFwcGVyLnN1YnNjcmliZTxzdHJpbmc+KGV2ZW50QnVzLCAoZXYpID0+IHtcbiAgICAgICAgICAgICAgICAgaWYgKGV2LnN0YXJ0c1dpdGgoJ2RlYWN0aXZhdGUnKSkge1xuICAgICAgICAgICAgICAgICAgIGNvbXBsZXRlci5yZXNvbHZlKHRydWUpO1xuICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdwYXJlbnQge2RlYWN0aXZhdGUgY21wfScpO1xuICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgIHJ0ci5uYXZpZ2F0ZUJ5VXJsKCcvYScpLnRoZW4oKF8pID0+IHtcbiAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdBJyk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChsb2cpLnRvRXF1YWwoW1xuICAgICAgICAgICAgICAgICAgICdkZWFjdGl2YXRlOiAvY2hpbGQtZGVhY3RpdmF0ZSAtPiBudWxsJyxcbiAgICAgICAgICAgICAgICAgICAncGFyZW50IGRlYWN0aXZhdGU6IC9wYXJlbnQtZGVhY3RpdmF0ZSAtPiAvYSdcbiAgICAgICAgICAgICAgICAgXSk7XG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgcmV1c2UgYSBjb21wb25lbnQgd2hlbiB0aGUgcm91dGVyQ2FuUmV1c2UgaG9vayByZXR1cm5zIHRydWUnLFxuICAgICAgIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICBjb21waWxlKHRjYilcbiAgICAgICAgICAgICAudGhlbigocnRjKSA9PiB7Zml4dHVyZSA9IHJ0Y30pXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJ0ci5jb25maWcoW25ldyBSb3V0ZSh7cGF0aDogJy8uLi4nLCBjb21wb25lbnQ6IExpZmVjeWNsZUNtcH0pXSkpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJ0ci5uYXZpZ2F0ZUJ5VXJsKCcvb24tcmV1c2UvMS9hJykpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KGxvZykudG9FcXVhbChbXSk7XG4gICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgncmV1c2Uge0F9Jyk7XG4gICAgICAgICAgICAgICBleHBlY3QoY21wSW5zdGFuY2VDb3VudCkudG9CZSgxKTtcbiAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiBydHIubmF2aWdhdGVCeVVybCgnL29uLXJldXNlLzIvYicpKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiB7XG4gICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChsb2cpLnRvRXF1YWwoWydyZXVzZTogL29uLXJldXNlLzEgLT4gL29uLXJldXNlLzInXSk7XG4gICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgncmV1c2Uge0J9Jyk7XG4gICAgICAgICAgICAgICBleHBlY3QoY21wSW5zdGFuY2VDb3VudCkudG9CZSgxKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cblxuICAgIGl0KCdzaG91bGQgbm90IHJldXNlIGEgY29tcG9uZW50IHdoZW4gdGhlIHJvdXRlckNhblJldXNlIGhvb2sgcmV0dXJucyBmYWxzZScsXG4gICAgICAgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgIGNvbXBpbGUodGNiKVxuICAgICAgICAgICAgIC50aGVuKChydGMpID0+IHtmaXh0dXJlID0gcnRjfSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcnRyLmNvbmZpZyhbbmV3IFJvdXRlKHtwYXRoOiAnLy4uLicsIGNvbXBvbmVudDogTGlmZWN5Y2xlQ21wfSldKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcnRyLm5hdmlnYXRlQnlVcmwoJy9uZXZlci1yZXVzZS8xL2EnKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICBleHBlY3QobG9nKS50b0VxdWFsKFtdKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdyZXVzZSB7QX0nKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChjbXBJbnN0YW5jZUNvdW50KS50b0JlKDEpO1xuICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJ0ci5uYXZpZ2F0ZUJ5VXJsKCcvbmV2ZXItcmV1c2UvMi9iJykpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KGxvZykudG9FcXVhbChbXSk7XG4gICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgncmV1c2Uge0J9Jyk7XG4gICAgICAgICAgICAgICBleHBlY3QoY21wSW5zdGFuY2VDb3VudCkudG9CZSgyKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cblxuICAgIGl0KCdzaG91bGQgbmF2aWdhdGUgd2hlbiByb3V0ZXJDYW5BY3RpdmF0ZSByZXR1cm5zIHRydWUnLFxuICAgICAgIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICBjb21waWxlKHRjYilcbiAgICAgICAgICAgICAudGhlbigocnRjKSA9PiB7Zml4dHVyZSA9IHJ0Y30pXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJ0ci5jb25maWcoW25ldyBSb3V0ZSh7cGF0aDogJy8uLi4nLCBjb21wb25lbnQ6IExpZmVjeWNsZUNtcH0pXSkpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHtcbiAgICAgICAgICAgICAgIE9ic2VydmFibGVXcmFwcGVyLnN1YnNjcmliZTxzdHJpbmc+KGV2ZW50QnVzLCAoZXYpID0+IHtcbiAgICAgICAgICAgICAgICAgaWYgKGV2LnN0YXJ0c1dpdGgoJ3JvdXRlckNhbkFjdGl2YXRlJykpIHtcbiAgICAgICAgICAgICAgICAgICBjb21wbGV0ZXIucmVzb2x2ZSh0cnVlKTtcbiAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICBydHIubmF2aWdhdGVCeVVybCgnL2Nhbi1hY3RpdmF0ZS9hJylcbiAgICAgICAgICAgICAgICAgICAudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgZml4dHVyZS5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgICAgICBleHBlY3QoZml4dHVyZS5kZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCkudG9IYXZlVGV4dCgncm91dGVyQ2FuQWN0aXZhdGUge0F9Jyk7XG4gICAgICAgICAgICAgICAgICAgICBleHBlY3QobG9nKS50b0VxdWFsKFsncm91dGVyQ2FuQWN0aXZhdGU6IG51bGwgLT4gL2Nhbi1hY3RpdmF0ZSddKTtcbiAgICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIG5vdCBuYXZpZ2F0ZSB3aGVuIHJvdXRlckNhbkFjdGl2YXRlIHJldHVybnMgZmFsc2UnLFxuICAgICAgIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICBjb21waWxlKHRjYilcbiAgICAgICAgICAgICAudGhlbigocnRjKSA9PiB7Zml4dHVyZSA9IHJ0Y30pXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJ0ci5jb25maWcoW25ldyBSb3V0ZSh7cGF0aDogJy8uLi4nLCBjb21wb25lbnQ6IExpZmVjeWNsZUNtcH0pXSkpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHtcbiAgICAgICAgICAgICAgIE9ic2VydmFibGVXcmFwcGVyLnN1YnNjcmliZTxzdHJpbmc+KGV2ZW50QnVzLCAoZXYpID0+IHtcbiAgICAgICAgICAgICAgICAgaWYgKGV2LnN0YXJ0c1dpdGgoJ3JvdXRlckNhbkFjdGl2YXRlJykpIHtcbiAgICAgICAgICAgICAgICAgICBjb21wbGV0ZXIucmVzb2x2ZShmYWxzZSk7XG4gICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgcnRyLm5hdmlnYXRlQnlVcmwoJy9jYW4tYWN0aXZhdGUvYScpXG4gICAgICAgICAgICAgICAgICAgLnRoZW4oKF8pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJycpO1xuICAgICAgICAgICAgICAgICAgICAgZXhwZWN0KGxvZykudG9FcXVhbChbJ3JvdXRlckNhbkFjdGl2YXRlOiBudWxsIC0+IC9jYW4tYWN0aXZhdGUnXSk7XG4gICAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBuYXZpZ2F0ZSBhd2F5IHdoZW4gcm91dGVyQ2FuRGVhY3RpdmF0ZSByZXR1cm5zIHRydWUnLFxuICAgICAgIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICBjb21waWxlKHRjYilcbiAgICAgICAgICAgICAudGhlbigocnRjKSA9PiB7Zml4dHVyZSA9IHJ0Y30pXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJ0ci5jb25maWcoW25ldyBSb3V0ZSh7cGF0aDogJy8uLi4nLCBjb21wb25lbnQ6IExpZmVjeWNsZUNtcH0pXSkpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJ0ci5uYXZpZ2F0ZUJ5VXJsKCcvY2FuLWRlYWN0aXZhdGUvYScpKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiB7XG4gICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgIGV4cGVjdChmaXh0dXJlLmRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50KS50b0hhdmVUZXh0KCdyb3V0ZXJDYW5EZWFjdGl2YXRlIHtBfScpO1xuICAgICAgICAgICAgICAgZXhwZWN0KGxvZykudG9FcXVhbChbXSk7XG5cbiAgICAgICAgICAgICAgIE9ic2VydmFibGVXcmFwcGVyLnN1YnNjcmliZTxzdHJpbmc+KGV2ZW50QnVzLCAoZXYpID0+IHtcbiAgICAgICAgICAgICAgICAgaWYgKGV2LnN0YXJ0c1dpdGgoJ3JvdXRlckNhbkRlYWN0aXZhdGUnKSkge1xuICAgICAgICAgICAgICAgICAgIGNvbXBsZXRlci5yZXNvbHZlKHRydWUpO1xuICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgcnRyLm5hdmlnYXRlQnlVcmwoJy9hJykudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ0EnKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGxvZykudG9FcXVhbChbJ3JvdXRlckNhbkRlYWN0aXZhdGU6IC9jYW4tZGVhY3RpdmF0ZSAtPiAvYSddKTtcbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBub3QgbmF2aWdhdGUgYXdheSB3aGVuIHJvdXRlckNhbkRlYWN0aXZhdGUgcmV0dXJucyBmYWxzZScsXG4gICAgICAgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgIGNvbXBpbGUodGNiKVxuICAgICAgICAgICAgIC50aGVuKChydGMpID0+IHtmaXh0dXJlID0gcnRjfSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcnRyLmNvbmZpZyhbbmV3IFJvdXRlKHtwYXRoOiAnLy4uLicsIGNvbXBvbmVudDogTGlmZWN5Y2xlQ21wfSldKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4gcnRyLm5hdmlnYXRlQnlVcmwoJy9jYW4tZGVhY3RpdmF0ZS9hJykpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHtcbiAgICAgICAgICAgICAgIGZpeHR1cmUuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ3JvdXRlckNhbkRlYWN0aXZhdGUge0F9Jyk7XG4gICAgICAgICAgICAgICBleHBlY3QobG9nKS50b0VxdWFsKFtdKTtcblxuICAgICAgICAgICAgICAgT2JzZXJ2YWJsZVdyYXBwZXIuc3Vic2NyaWJlPHN0cmluZz4oZXZlbnRCdXMsIChldikgPT4ge1xuICAgICAgICAgICAgICAgICBpZiAoZXYuc3RhcnRzV2l0aCgncm91dGVyQ2FuRGVhY3RpdmF0ZScpKSB7XG4gICAgICAgICAgICAgICAgICAgY29tcGxldGVyLnJlc29sdmUoZmFsc2UpO1xuICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgcnRyLm5hdmlnYXRlQnlVcmwoJy9hJykudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgICBmaXh0dXJlLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KGZpeHR1cmUuZGVidWdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQpLnRvSGF2ZVRleHQoJ3JvdXRlckNhbkRlYWN0aXZhdGUge0F9Jyk7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChsb2cpLnRvRXF1YWwoWydyb3V0ZXJDYW5EZWFjdGl2YXRlOiAvY2FuLWRlYWN0aXZhdGUgLT4gL2EnXSk7XG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuXG4gICAgaXQoJ3Nob3VsZCBydW4gYWN0aXZhdGlvbiBhbmQgZGVhY3RpdmF0aW9uIGhvb2tzIGluIHRoZSBjb3JyZWN0IG9yZGVyJyxcbiAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgY29tcGlsZSh0Y2IpXG4gICAgICAgICAgICAgLnRoZW4oKHJ0YykgPT4ge2ZpeHR1cmUgPSBydGN9KVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiBydHIuY29uZmlnKFtuZXcgUm91dGUoe3BhdGg6ICcvLi4uJywgY29tcG9uZW50OiBMaWZlY3ljbGVDbXB9KV0pKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiBydHIubmF2aWdhdGVCeVVybCgnL2FjdGl2YXRpb24taG9va3MvY2hpbGQnKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgZXhwZWN0KGxvZykudG9FcXVhbChbXG4gICAgICAgICAgICAgICAgICdyb3V0ZXJDYW5BY3RpdmF0ZSBjaGlsZDogbnVsbCAtPiAvY2hpbGQnLFxuICAgICAgICAgICAgICAgICAncm91dGVyQ2FuQWN0aXZhdGUgcGFyZW50OiBudWxsIC0+IC9hY3RpdmF0aW9uLWhvb2tzJyxcbiAgICAgICAgICAgICAgICAgJ3JvdXRlck9uQWN0aXZhdGUgcGFyZW50OiBudWxsIC0+IC9hY3RpdmF0aW9uLWhvb2tzJyxcbiAgICAgICAgICAgICAgICAgJ3JvdXRlck9uQWN0aXZhdGUgY2hpbGQ6IG51bGwgLT4gL2NoaWxkJ1xuICAgICAgICAgICAgICAgXSk7XG5cbiAgICAgICAgICAgICAgIGxvZyA9IFtdO1xuICAgICAgICAgICAgICAgcmV0dXJuIHJ0ci5uYXZpZ2F0ZUJ5VXJsKCcvYScpO1xuICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHtcbiAgICAgICAgICAgICAgIGV4cGVjdChsb2cpLnRvRXF1YWwoW1xuICAgICAgICAgICAgICAgICAncm91dGVyQ2FuRGVhY3RpdmF0ZSBwYXJlbnQ6IC9hY3RpdmF0aW9uLWhvb2tzIC0+IC9hJyxcbiAgICAgICAgICAgICAgICAgJ3JvdXRlckNhbkRlYWN0aXZhdGUgY2hpbGQ6IC9jaGlsZCAtPiBudWxsJyxcbiAgICAgICAgICAgICAgICAgJ3JvdXRlck9uRGVhY3RpdmF0ZSBjaGlsZDogL2NoaWxkIC0+IG51bGwnLFxuICAgICAgICAgICAgICAgICAncm91dGVyT25EZWFjdGl2YXRlIHBhcmVudDogL2FjdGl2YXRpb24taG9va3MgLT4gL2EnXG4gICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICB9KSk7XG5cbiAgICBpdCgnc2hvdWxkIG9ubHkgcnVuIHJldXNlIGhvb2tzIHdoZW4gcmV1c2luZycsIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICBjb21waWxlKHRjYilcbiAgICAgICAgICAgICAudGhlbigocnRjKSA9PiB7Zml4dHVyZSA9IHJ0Y30pXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJ0ci5jb25maWcoW25ldyBSb3V0ZSh7cGF0aDogJy8uLi4nLCBjb21wb25lbnQ6IExpZmVjeWNsZUNtcH0pXSkpXG4gICAgICAgICAgICAgLnRoZW4oKF8pID0+IHJ0ci5uYXZpZ2F0ZUJ5VXJsKCcvcmV1c2UtaG9va3MvMScpKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiB7XG4gICAgICAgICAgICAgICBleHBlY3QobG9nKS50b0VxdWFsKFtcbiAgICAgICAgICAgICAgICAgJ3JvdXRlckNhbkFjdGl2YXRlOiBudWxsIC0+IC9yZXVzZS1ob29rcy8xJyxcbiAgICAgICAgICAgICAgICAgJ3JvdXRlck9uQWN0aXZhdGU6IG51bGwgLT4gL3JldXNlLWhvb2tzLzEnXG4gICAgICAgICAgICAgICBdKTtcblxuICAgICAgICAgICAgICAgT2JzZXJ2YWJsZVdyYXBwZXIuc3Vic2NyaWJlPHN0cmluZz4oZXZlbnRCdXMsIChldikgPT4ge1xuICAgICAgICAgICAgICAgICBpZiAoZXYuc3RhcnRzV2l0aCgncm91dGVyQ2FuUmV1c2UnKSkge1xuICAgICAgICAgICAgICAgICAgIGNvbXBsZXRlci5yZXNvbHZlKHRydWUpO1xuICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICB9KTtcblxuXG4gICAgICAgICAgICAgICBsb2cgPSBbXTtcbiAgICAgICAgICAgICAgIHJldHVybiBydHIubmF2aWdhdGVCeVVybCgnL3JldXNlLWhvb2tzLzInKTtcbiAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiB7XG4gICAgICAgICAgICAgICBleHBlY3QobG9nKS50b0VxdWFsKFtcbiAgICAgICAgICAgICAgICAgJ3JvdXRlckNhblJldXNlOiAvcmV1c2UtaG9va3MvMSAtPiAvcmV1c2UtaG9va3MvMicsXG4gICAgICAgICAgICAgICAgICdyb3V0ZXJPblJldXNlOiAvcmV1c2UtaG9va3MvMSAtPiAvcmV1c2UtaG9va3MvMidcbiAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcblxuICAgIGl0KCdzaG91bGQgbm90IHJ1biByZXVzZSBob29rcyB3aGVuIG5vdCByZXVzaW5nJywgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgIGNvbXBpbGUodGNiKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiBydHIuY29uZmlnKFtuZXcgUm91dGUoe3BhdGg6ICcvLi4uJywgY29tcG9uZW50OiBMaWZlY3ljbGVDbXB9KV0pKVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiBydHIubmF2aWdhdGVCeVVybCgnL3JldXNlLWhvb2tzLzEnKSlcbiAgICAgICAgICAgICAudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgZXhwZWN0KGxvZykudG9FcXVhbChbXG4gICAgICAgICAgICAgICAgICdyb3V0ZXJDYW5BY3RpdmF0ZTogbnVsbCAtPiAvcmV1c2UtaG9va3MvMScsXG4gICAgICAgICAgICAgICAgICdyb3V0ZXJPbkFjdGl2YXRlOiBudWxsIC0+IC9yZXVzZS1ob29rcy8xJ1xuICAgICAgICAgICAgICAgXSk7XG5cbiAgICAgICAgICAgICAgIE9ic2VydmFibGVXcmFwcGVyLnN1YnNjcmliZTxzdHJpbmc+KGV2ZW50QnVzLCAoZXYpID0+IHtcbiAgICAgICAgICAgICAgICAgaWYgKGV2LnN0YXJ0c1dpdGgoJ3JvdXRlckNhblJldXNlJykpIHtcbiAgICAgICAgICAgICAgICAgICBjb21wbGV0ZXIucmVzb2x2ZShmYWxzZSk7XG4gICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICBsb2cgPSBbXTtcbiAgICAgICAgICAgICAgIHJldHVybiBydHIubmF2aWdhdGVCeVVybCgnL3JldXNlLWhvb2tzLzInKTtcbiAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgIC50aGVuKChfKSA9PiB7XG4gICAgICAgICAgICAgICBleHBlY3QobG9nKS50b0VxdWFsKFtcbiAgICAgICAgICAgICAgICAgJ3JvdXRlckNhblJldXNlOiAvcmV1c2UtaG9va3MvMSAtPiAvcmV1c2UtaG9va3MvMicsXG4gICAgICAgICAgICAgICAgICdyb3V0ZXJDYW5BY3RpdmF0ZTogL3JldXNlLWhvb2tzLzEgLT4gL3JldXNlLWhvb2tzLzInLFxuICAgICAgICAgICAgICAgICAncm91dGVyQ2FuRGVhY3RpdmF0ZTogL3JldXNlLWhvb2tzLzEgLT4gL3JldXNlLWhvb2tzLzInLFxuICAgICAgICAgICAgICAgICAncm91dGVyT25EZWFjdGl2YXRlOiAvcmV1c2UtaG9va3MvMSAtPiAvcmV1c2UtaG9va3MvMicsXG4gICAgICAgICAgICAgICAgICdyb3V0ZXJPbkFjdGl2YXRlOiAvcmV1c2UtaG9va3MvMSAtPiAvcmV1c2UtaG9va3MvMidcbiAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgIH0pO1xuICAgICAgIH0pKTtcbiAgfSk7XG59XG5cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdhLWNtcCcsIHRlbXBsYXRlOiBcIkFcIn0pXG5jbGFzcyBBIHtcbn1cblxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ2ItY21wJywgdGVtcGxhdGU6IFwiQlwifSlcbmNsYXNzIEIge1xufVxuXG5cbmZ1bmN0aW9uIGxvZ0hvb2sobmFtZTogc3RyaW5nLCBuZXh0OiBDb21wb25lbnRJbnN0cnVjdGlvbiwgcHJldjogQ29tcG9uZW50SW5zdHJ1Y3Rpb24pIHtcbiAgdmFyIG1lc3NhZ2UgPSBuYW1lICsgJzogJyArIChpc1ByZXNlbnQocHJldikgPyAoJy8nICsgcHJldi51cmxQYXRoKSA6ICdudWxsJykgKyAnIC0+ICcgK1xuICAgICAgICAgICAgICAgIChpc1ByZXNlbnQobmV4dCkgPyAoJy8nICsgbmV4dC51cmxQYXRoKSA6ICdudWxsJyk7XG4gIGxvZy5wdXNoKG1lc3NhZ2UpO1xuICBPYnNlcnZhYmxlV3JhcHBlci5jYWxsRW1pdChldmVudEJ1cywgbWVzc2FnZSk7XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnYWN0aXZhdGUtY21wJywgdGVtcGxhdGU6ICdhY3RpdmF0ZSBjbXAnfSlcbmNsYXNzIEFjdGl2YXRlQ21wIGltcGxlbWVudHMgT25BY3RpdmF0ZSB7XG4gIHJvdXRlck9uQWN0aXZhdGUobmV4dDogQ29tcG9uZW50SW5zdHJ1Y3Rpb24sIHByZXY6IENvbXBvbmVudEluc3RydWN0aW9uKSB7XG4gICAgbG9nSG9vaygnYWN0aXZhdGUnLCBuZXh0LCBwcmV2KTtcbiAgfVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdwYXJlbnQtYWN0aXZhdGUtY21wJyxcbiAgdGVtcGxhdGU6IGBwYXJlbnQgezxyb3V0ZXItb3V0bGV0Pjwvcm91dGVyLW91dGxldD59YCxcbiAgZGlyZWN0aXZlczogW1JvdXRlck91dGxldF1cbn0pXG5AUm91dGVDb25maWcoW25ldyBSb3V0ZSh7cGF0aDogJy9jaGlsZC1hY3RpdmF0ZScsIGNvbXBvbmVudDogQWN0aXZhdGVDbXB9KV0pXG5jbGFzcyBQYXJlbnRBY3RpdmF0ZUNtcCBpbXBsZW1lbnRzIE9uQWN0aXZhdGUge1xuICByb3V0ZXJPbkFjdGl2YXRlKG5leHQ6IENvbXBvbmVudEluc3RydWN0aW9uLCBwcmV2OiBDb21wb25lbnRJbnN0cnVjdGlvbik6IFByb21pc2U8YW55PiB7XG4gICAgY29tcGxldGVyID0gUHJvbWlzZVdyYXBwZXIuY29tcGxldGVyKCk7XG4gICAgbG9nSG9vaygncGFyZW50IGFjdGl2YXRlJywgbmV4dCwgcHJldik7XG4gICAgcmV0dXJuIGNvbXBsZXRlci5wcm9taXNlO1xuICB9XG59XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnZGVhY3RpdmF0ZS1jbXAnLCB0ZW1wbGF0ZTogJ2RlYWN0aXZhdGUgY21wJ30pXG5jbGFzcyBEZWFjdGl2YXRlQ21wIGltcGxlbWVudHMgT25EZWFjdGl2YXRlIHtcbiAgcm91dGVyT25EZWFjdGl2YXRlKG5leHQ6IENvbXBvbmVudEluc3RydWN0aW9uLCBwcmV2OiBDb21wb25lbnRJbnN0cnVjdGlvbikge1xuICAgIGxvZ0hvb2soJ2RlYWN0aXZhdGUnLCBuZXh0LCBwcmV2KTtcbiAgfVxufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ2RlYWN0aXZhdGUtY21wJywgdGVtcGxhdGU6ICdkZWFjdGl2YXRlIGNtcCd9KVxuY2xhc3MgV2FpdERlYWN0aXZhdGVDbXAgaW1wbGVtZW50cyBPbkRlYWN0aXZhdGUge1xuICByb3V0ZXJPbkRlYWN0aXZhdGUobmV4dDogQ29tcG9uZW50SW5zdHJ1Y3Rpb24sIHByZXY6IENvbXBvbmVudEluc3RydWN0aW9uKTogUHJvbWlzZTxhbnk+IHtcbiAgICBjb21wbGV0ZXIgPSBQcm9taXNlV3JhcHBlci5jb21wbGV0ZXIoKTtcbiAgICBsb2dIb29rKCdkZWFjdGl2YXRlJywgbmV4dCwgcHJldik7XG4gICAgcmV0dXJuIGNvbXBsZXRlci5wcm9taXNlO1xuICB9XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ3BhcmVudC1kZWFjdGl2YXRlLWNtcCcsXG4gIHRlbXBsYXRlOiBgcGFyZW50IHs8cm91dGVyLW91dGxldD48L3JvdXRlci1vdXRsZXQ+fWAsXG4gIGRpcmVjdGl2ZXM6IFtSb3V0ZXJPdXRsZXRdXG59KVxuQFJvdXRlQ29uZmlnKFtuZXcgUm91dGUoe3BhdGg6ICcvY2hpbGQtZGVhY3RpdmF0ZScsIGNvbXBvbmVudDogV2FpdERlYWN0aXZhdGVDbXB9KV0pXG5jbGFzcyBQYXJlbnREZWFjdGl2YXRlQ21wIGltcGxlbWVudHMgT25EZWFjdGl2YXRlIHtcbiAgcm91dGVyT25EZWFjdGl2YXRlKG5leHQ6IENvbXBvbmVudEluc3RydWN0aW9uLCBwcmV2OiBDb21wb25lbnRJbnN0cnVjdGlvbikge1xuICAgIGxvZ0hvb2soJ3BhcmVudCBkZWFjdGl2YXRlJywgbmV4dCwgcHJldik7XG4gIH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAncmV1c2UtY21wJyxcbiAgdGVtcGxhdGU6IGByZXVzZSB7PHJvdXRlci1vdXRsZXQ+PC9yb3V0ZXItb3V0bGV0Pn1gLFxuICBkaXJlY3RpdmVzOiBbUm91dGVyT3V0bGV0XVxufSlcbkBSb3V0ZUNvbmZpZyhbbmV3IFJvdXRlKHtwYXRoOiAnL2EnLCBjb21wb25lbnQ6IEF9KSwgbmV3IFJvdXRlKHtwYXRoOiAnL2InLCBjb21wb25lbnQ6IEJ9KV0pXG5jbGFzcyBSZXVzZUNtcCBpbXBsZW1lbnRzIE9uUmV1c2UsXG4gICAgQ2FuUmV1c2Uge1xuICBjb25zdHJ1Y3RvcigpIHsgY21wSW5zdGFuY2VDb3VudCArPSAxOyB9XG4gIHJvdXRlckNhblJldXNlKG5leHQ6IENvbXBvbmVudEluc3RydWN0aW9uLCBwcmV2OiBDb21wb25lbnRJbnN0cnVjdGlvbikgeyByZXR1cm4gdHJ1ZTsgfVxuICByb3V0ZXJPblJldXNlKG5leHQ6IENvbXBvbmVudEluc3RydWN0aW9uLCBwcmV2OiBDb21wb25lbnRJbnN0cnVjdGlvbikge1xuICAgIGxvZ0hvb2soJ3JldXNlJywgbmV4dCwgcHJldik7XG4gIH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbmV2ZXItcmV1c2UtY21wJyxcbiAgdGVtcGxhdGU6IGByZXVzZSB7PHJvdXRlci1vdXRsZXQ+PC9yb3V0ZXItb3V0bGV0Pn1gLFxuICBkaXJlY3RpdmVzOiBbUm91dGVyT3V0bGV0XVxufSlcbkBSb3V0ZUNvbmZpZyhbbmV3IFJvdXRlKHtwYXRoOiAnL2EnLCBjb21wb25lbnQ6IEF9KSwgbmV3IFJvdXRlKHtwYXRoOiAnL2InLCBjb21wb25lbnQ6IEJ9KV0pXG5jbGFzcyBOZXZlclJldXNlQ21wIGltcGxlbWVudHMgT25SZXVzZSxcbiAgICBDYW5SZXVzZSB7XG4gIGNvbnN0cnVjdG9yKCkgeyBjbXBJbnN0YW5jZUNvdW50ICs9IDE7IH1cbiAgcm91dGVyQ2FuUmV1c2UobmV4dDogQ29tcG9uZW50SW5zdHJ1Y3Rpb24sIHByZXY6IENvbXBvbmVudEluc3RydWN0aW9uKSB7IHJldHVybiBmYWxzZTsgfVxuICByb3V0ZXJPblJldXNlKG5leHQ6IENvbXBvbmVudEluc3RydWN0aW9uLCBwcmV2OiBDb21wb25lbnRJbnN0cnVjdGlvbikge1xuICAgIGxvZ0hvb2soJ3JldXNlJywgbmV4dCwgcHJldik7XG4gIH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY2FuLWFjdGl2YXRlLWNtcCcsXG4gIHRlbXBsYXRlOiBgcm91dGVyQ2FuQWN0aXZhdGUgezxyb3V0ZXItb3V0bGV0Pjwvcm91dGVyLW91dGxldD59YCxcbiAgZGlyZWN0aXZlczogW1JvdXRlck91dGxldF1cbn0pXG5AUm91dGVDb25maWcoW25ldyBSb3V0ZSh7cGF0aDogJy9hJywgY29tcG9uZW50OiBBfSksIG5ldyBSb3V0ZSh7cGF0aDogJy9iJywgY29tcG9uZW50OiBCfSldKVxuQENhbkFjdGl2YXRlKENhbkFjdGl2YXRlQ21wLnJvdXRlckNhbkFjdGl2YXRlKVxuY2xhc3MgQ2FuQWN0aXZhdGVDbXAge1xuICBzdGF0aWMgcm91dGVyQ2FuQWN0aXZhdGUobmV4dDogQ29tcG9uZW50SW5zdHJ1Y3Rpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBwcmV2OiBDb21wb25lbnRJbnN0cnVjdGlvbik6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIGNvbXBsZXRlciA9IFByb21pc2VXcmFwcGVyLmNvbXBsZXRlcigpO1xuICAgIGxvZ0hvb2soJ3JvdXRlckNhbkFjdGl2YXRlJywgbmV4dCwgcHJldik7XG4gICAgcmV0dXJuIGNvbXBsZXRlci5wcm9taXNlO1xuICB9XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2Nhbi1kZWFjdGl2YXRlLWNtcCcsXG4gIHRlbXBsYXRlOiBgcm91dGVyQ2FuRGVhY3RpdmF0ZSB7PHJvdXRlci1vdXRsZXQ+PC9yb3V0ZXItb3V0bGV0Pn1gLFxuICBkaXJlY3RpdmVzOiBbUm91dGVyT3V0bGV0XVxufSlcbkBSb3V0ZUNvbmZpZyhbbmV3IFJvdXRlKHtwYXRoOiAnL2EnLCBjb21wb25lbnQ6IEF9KSwgbmV3IFJvdXRlKHtwYXRoOiAnL2InLCBjb21wb25lbnQ6IEJ9KV0pXG5jbGFzcyBDYW5EZWFjdGl2YXRlQ21wIGltcGxlbWVudHMgQ2FuRGVhY3RpdmF0ZSB7XG4gIHJvdXRlckNhbkRlYWN0aXZhdGUobmV4dDogQ29tcG9uZW50SW5zdHJ1Y3Rpb24sIHByZXY6IENvbXBvbmVudEluc3RydWN0aW9uKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgY29tcGxldGVyID0gUHJvbWlzZVdyYXBwZXIuY29tcGxldGVyKCk7XG4gICAgbG9nSG9vaygncm91dGVyQ2FuRGVhY3RpdmF0ZScsIG5leHQsIHByZXYpO1xuICAgIHJldHVybiBjb21wbGV0ZXIucHJvbWlzZTtcbiAgfVxufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ2FsbC1ob29rcy1jaGlsZC1jbXAnLCB0ZW1wbGF0ZTogYGNoaWxkYH0pXG5AQ2FuQWN0aXZhdGUoQWxsSG9va3NDaGlsZENtcC5yb3V0ZXJDYW5BY3RpdmF0ZSlcbmNsYXNzIEFsbEhvb2tzQ2hpbGRDbXAgaW1wbGVtZW50cyBDYW5EZWFjdGl2YXRlLCBPbkRlYWN0aXZhdGUsIE9uQWN0aXZhdGUge1xuICByb3V0ZXJDYW5EZWFjdGl2YXRlKG5leHQ6IENvbXBvbmVudEluc3RydWN0aW9uLCBwcmV2OiBDb21wb25lbnRJbnN0cnVjdGlvbikge1xuICAgIGxvZ0hvb2soJ3JvdXRlckNhbkRlYWN0aXZhdGUgY2hpbGQnLCBuZXh0LCBwcmV2KTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIHJvdXRlck9uRGVhY3RpdmF0ZShuZXh0OiBDb21wb25lbnRJbnN0cnVjdGlvbiwgcHJldjogQ29tcG9uZW50SW5zdHJ1Y3Rpb24pIHtcbiAgICBsb2dIb29rKCdyb3V0ZXJPbkRlYWN0aXZhdGUgY2hpbGQnLCBuZXh0LCBwcmV2KTtcbiAgfVxuXG4gIHN0YXRpYyByb3V0ZXJDYW5BY3RpdmF0ZShuZXh0OiBDb21wb25lbnRJbnN0cnVjdGlvbiwgcHJldjogQ29tcG9uZW50SW5zdHJ1Y3Rpb24pIHtcbiAgICBsb2dIb29rKCdyb3V0ZXJDYW5BY3RpdmF0ZSBjaGlsZCcsIG5leHQsIHByZXYpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgcm91dGVyT25BY3RpdmF0ZShuZXh0OiBDb21wb25lbnRJbnN0cnVjdGlvbiwgcHJldjogQ29tcG9uZW50SW5zdHJ1Y3Rpb24pIHtcbiAgICBsb2dIb29rKCdyb3V0ZXJPbkFjdGl2YXRlIGNoaWxkJywgbmV4dCwgcHJldik7XG4gIH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnYWxsLWhvb2tzLXBhcmVudC1jbXAnLFxuICB0ZW1wbGF0ZTogYDxyb3V0ZXItb3V0bGV0Pjwvcm91dGVyLW91dGxldD5gLFxuICBkaXJlY3RpdmVzOiBbUm91dGVyT3V0bGV0XVxufSlcbkBSb3V0ZUNvbmZpZyhbbmV3IFJvdXRlKHtwYXRoOiAnL2NoaWxkJywgY29tcG9uZW50OiBBbGxIb29rc0NoaWxkQ21wfSldKVxuQENhbkFjdGl2YXRlKEFsbEhvb2tzUGFyZW50Q21wLnJvdXRlckNhbkFjdGl2YXRlKVxuY2xhc3MgQWxsSG9va3NQYXJlbnRDbXAgaW1wbGVtZW50cyBDYW5EZWFjdGl2YXRlLFxuICAgIE9uRGVhY3RpdmF0ZSwgT25BY3RpdmF0ZSB7XG4gIHJvdXRlckNhbkRlYWN0aXZhdGUobmV4dDogQ29tcG9uZW50SW5zdHJ1Y3Rpb24sIHByZXY6IENvbXBvbmVudEluc3RydWN0aW9uKSB7XG4gICAgbG9nSG9vaygncm91dGVyQ2FuRGVhY3RpdmF0ZSBwYXJlbnQnLCBuZXh0LCBwcmV2KTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIHJvdXRlck9uRGVhY3RpdmF0ZShuZXh0OiBDb21wb25lbnRJbnN0cnVjdGlvbiwgcHJldjogQ29tcG9uZW50SW5zdHJ1Y3Rpb24pIHtcbiAgICBsb2dIb29rKCdyb3V0ZXJPbkRlYWN0aXZhdGUgcGFyZW50JywgbmV4dCwgcHJldik7XG4gIH1cblxuICBzdGF0aWMgcm91dGVyQ2FuQWN0aXZhdGUobmV4dDogQ29tcG9uZW50SW5zdHJ1Y3Rpb24sIHByZXY6IENvbXBvbmVudEluc3RydWN0aW9uKSB7XG4gICAgbG9nSG9vaygncm91dGVyQ2FuQWN0aXZhdGUgcGFyZW50JywgbmV4dCwgcHJldik7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICByb3V0ZXJPbkFjdGl2YXRlKG5leHQ6IENvbXBvbmVudEluc3RydWN0aW9uLCBwcmV2OiBDb21wb25lbnRJbnN0cnVjdGlvbikge1xuICAgIGxvZ0hvb2soJ3JvdXRlck9uQWN0aXZhdGUgcGFyZW50JywgbmV4dCwgcHJldik7XG4gIH1cbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdyZXVzZS1ob29rcy1jbXAnLCB0ZW1wbGF0ZTogJ3JldXNlIGhvb2tzIGNtcCd9KVxuQENhbkFjdGl2YXRlKFJldXNlSG9va3NDbXAucm91dGVyQ2FuQWN0aXZhdGUpXG5jbGFzcyBSZXVzZUhvb2tzQ21wIGltcGxlbWVudHMgT25BY3RpdmF0ZSwgT25SZXVzZSwgT25EZWFjdGl2YXRlLCBDYW5SZXVzZSwgQ2FuRGVhY3RpdmF0ZSB7XG4gIHJvdXRlckNhblJldXNlKG5leHQ6IENvbXBvbmVudEluc3RydWN0aW9uLCBwcmV2OiBDb21wb25lbnRJbnN0cnVjdGlvbik6IFByb21pc2U8YW55PiB7XG4gICAgY29tcGxldGVyID0gUHJvbWlzZVdyYXBwZXIuY29tcGxldGVyKCk7XG4gICAgbG9nSG9vaygncm91dGVyQ2FuUmV1c2UnLCBuZXh0LCBwcmV2KTtcbiAgICByZXR1cm4gY29tcGxldGVyLnByb21pc2U7XG4gIH1cblxuICByb3V0ZXJPblJldXNlKG5leHQ6IENvbXBvbmVudEluc3RydWN0aW9uLCBwcmV2OiBDb21wb25lbnRJbnN0cnVjdGlvbikge1xuICAgIGxvZ0hvb2soJ3JvdXRlck9uUmV1c2UnLCBuZXh0LCBwcmV2KTtcbiAgfVxuXG4gIHJvdXRlckNhbkRlYWN0aXZhdGUobmV4dDogQ29tcG9uZW50SW5zdHJ1Y3Rpb24sIHByZXY6IENvbXBvbmVudEluc3RydWN0aW9uKSB7XG4gICAgbG9nSG9vaygncm91dGVyQ2FuRGVhY3RpdmF0ZScsIG5leHQsIHByZXYpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgcm91dGVyT25EZWFjdGl2YXRlKG5leHQ6IENvbXBvbmVudEluc3RydWN0aW9uLCBwcmV2OiBDb21wb25lbnRJbnN0cnVjdGlvbikge1xuICAgIGxvZ0hvb2soJ3JvdXRlck9uRGVhY3RpdmF0ZScsIG5leHQsIHByZXYpO1xuICB9XG5cbiAgc3RhdGljIHJvdXRlckNhbkFjdGl2YXRlKG5leHQ6IENvbXBvbmVudEluc3RydWN0aW9uLCBwcmV2OiBDb21wb25lbnRJbnN0cnVjdGlvbikge1xuICAgIGxvZ0hvb2soJ3JvdXRlckNhbkFjdGl2YXRlJywgbmV4dCwgcHJldik7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICByb3V0ZXJPbkFjdGl2YXRlKG5leHQ6IENvbXBvbmVudEluc3RydWN0aW9uLCBwcmV2OiBDb21wb25lbnRJbnN0cnVjdGlvbikge1xuICAgIGxvZ0hvb2soJ3JvdXRlck9uQWN0aXZhdGUnLCBuZXh0LCBwcmV2KTtcbiAgfVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdsaWZlY3ljbGUtY21wJyxcbiAgdGVtcGxhdGU6IGA8cm91dGVyLW91dGxldD48L3JvdXRlci1vdXRsZXQ+YCxcbiAgZGlyZWN0aXZlczogW1JvdXRlck91dGxldF1cbn0pXG5AUm91dGVDb25maWcoW1xuICBuZXcgUm91dGUoe3BhdGg6ICcvYScsIGNvbXBvbmVudDogQX0pLFxuICBuZXcgUm91dGUoe3BhdGg6ICcvb24tYWN0aXZhdGUnLCBjb21wb25lbnQ6IEFjdGl2YXRlQ21wfSksXG4gIG5ldyBSb3V0ZSh7cGF0aDogJy9wYXJlbnQtYWN0aXZhdGUvLi4uJywgY29tcG9uZW50OiBQYXJlbnRBY3RpdmF0ZUNtcH0pLFxuICBuZXcgUm91dGUoe3BhdGg6ICcvb24tZGVhY3RpdmF0ZScsIGNvbXBvbmVudDogRGVhY3RpdmF0ZUNtcH0pLFxuICBuZXcgUm91dGUoe3BhdGg6ICcvcGFyZW50LWRlYWN0aXZhdGUvLi4uJywgY29tcG9uZW50OiBQYXJlbnREZWFjdGl2YXRlQ21wfSksXG4gIG5ldyBSb3V0ZSh7cGF0aDogJy9vbi1yZXVzZS86bnVtYmVyLy4uLicsIGNvbXBvbmVudDogUmV1c2VDbXB9KSxcbiAgbmV3IFJvdXRlKHtwYXRoOiAnL25ldmVyLXJldXNlLzpudW1iZXIvLi4uJywgY29tcG9uZW50OiBOZXZlclJldXNlQ21wfSksXG4gIG5ldyBSb3V0ZSh7cGF0aDogJy9jYW4tYWN0aXZhdGUvLi4uJywgY29tcG9uZW50OiBDYW5BY3RpdmF0ZUNtcH0pLFxuICBuZXcgUm91dGUoe3BhdGg6ICcvY2FuLWRlYWN0aXZhdGUvLi4uJywgY29tcG9uZW50OiBDYW5EZWFjdGl2YXRlQ21wfSksXG4gIG5ldyBSb3V0ZSh7cGF0aDogJy9hY3RpdmF0aW9uLWhvb2tzLy4uLicsIGNvbXBvbmVudDogQWxsSG9va3NQYXJlbnRDbXB9KSxcbiAgbmV3IFJvdXRlKHtwYXRoOiAnL3JldXNlLWhvb2tzLzpudW1iZXInLCBjb21wb25lbnQ6IFJldXNlSG9va3NDbXB9KVxuXSlcbmNsYXNzIExpZmVjeWNsZUNtcCB7XG59XG4iXX0=
 main(); 
