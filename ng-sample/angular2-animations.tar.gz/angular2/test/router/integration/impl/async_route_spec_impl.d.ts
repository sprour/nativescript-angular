export declare function registerSpecs(): void;
