'use strict';var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('angular2/core');
var router_1 = require('angular2/router');
var async_1 = require('angular2/src/facade/async');
var lang_1 = require('angular2/src/facade/lang');
var dynamic_component_loader_1 = require('angular2/src/core/linker/dynamic_component_loader');
var element_ref_1 = require('angular2/src/core/linker/element_ref');
var GoodbyeCmp = (function () {
    function GoodbyeCmp() {
        this.farewell = 'goodbye';
    }
    GoodbyeCmp = __decorate([
        core_1.Component({ selector: 'goodbye-cmp', template: "{{farewell}}" }), 
        __metadata('design:paramtypes', [])
    ], GoodbyeCmp);
    return GoodbyeCmp;
})();
exports.GoodbyeCmp = GoodbyeCmp;
var HelloCmp = (function () {
    function HelloCmp() {
        this.greeting = 'hello';
    }
    HelloCmp = __decorate([
        core_1.Component({ selector: 'hello-cmp', template: "{{greeting}}" }), 
        __metadata('design:paramtypes', [])
    ], HelloCmp);
    return HelloCmp;
})();
exports.HelloCmp = HelloCmp;
function helloCmpLoader() {
    return async_1.PromiseWrapper.resolve(HelloCmp);
}
exports.helloCmpLoader = helloCmpLoader;
var UserCmp = (function () {
    function UserCmp(params) {
        this.user = params.get('name');
    }
    UserCmp = __decorate([
        core_1.Component({ selector: 'user-cmp', template: "hello {{user}}" }), 
        __metadata('design:paramtypes', [router_1.RouteParams])
    ], UserCmp);
    return UserCmp;
})();
exports.UserCmp = UserCmp;
function userCmpLoader() {
    return async_1.PromiseWrapper.resolve(UserCmp);
}
exports.userCmpLoader = userCmpLoader;
var ParentCmp = (function () {
    function ParentCmp() {
    }
    ParentCmp = __decorate([
        core_1.Component({
            selector: 'parent-cmp',
            template: "inner { <router-outlet></router-outlet> }",
            directives: [router_1.ROUTER_DIRECTIVES],
        }),
        router_1.RouteConfig([new router_1.Route({ path: '/b', component: HelloCmp, name: 'Child' })]), 
        __metadata('design:paramtypes', [])
    ], ParentCmp);
    return ParentCmp;
})();
exports.ParentCmp = ParentCmp;
function parentCmpLoader() {
    return async_1.PromiseWrapper.resolve(ParentCmp);
}
exports.parentCmpLoader = parentCmpLoader;
var AsyncParentCmp = (function () {
    function AsyncParentCmp() {
    }
    AsyncParentCmp = __decorate([
        core_1.Component({
            selector: 'parent-cmp',
            template: "inner { <router-outlet></router-outlet> }",
            directives: [router_1.ROUTER_DIRECTIVES],
        }),
        router_1.RouteConfig([new router_1.AsyncRoute({ path: '/b', loader: helloCmpLoader, name: 'Child' })]), 
        __metadata('design:paramtypes', [])
    ], AsyncParentCmp);
    return AsyncParentCmp;
})();
exports.AsyncParentCmp = AsyncParentCmp;
function asyncParentCmpLoader() {
    return async_1.PromiseWrapper.resolve(AsyncParentCmp);
}
exports.asyncParentCmpLoader = asyncParentCmpLoader;
var AsyncDefaultParentCmp = (function () {
    function AsyncDefaultParentCmp() {
    }
    AsyncDefaultParentCmp = __decorate([
        core_1.Component({
            selector: 'parent-cmp',
            template: "inner { <router-outlet></router-outlet> }",
            directives: [router_1.ROUTER_DIRECTIVES],
        }),
        router_1.RouteConfig([new router_1.AsyncRoute({ path: '/b', loader: helloCmpLoader, name: 'Child', useAsDefault: true })]), 
        __metadata('design:paramtypes', [])
    ], AsyncDefaultParentCmp);
    return AsyncDefaultParentCmp;
})();
exports.AsyncDefaultParentCmp = AsyncDefaultParentCmp;
function asyncDefaultParentCmpLoader() {
    return async_1.PromiseWrapper.resolve(AsyncDefaultParentCmp);
}
exports.asyncDefaultParentCmpLoader = asyncDefaultParentCmpLoader;
var ParentWithDefaultCmp = (function () {
    function ParentWithDefaultCmp() {
    }
    ParentWithDefaultCmp = __decorate([
        core_1.Component({
            selector: 'parent-cmp',
            template: "inner { <router-outlet></router-outlet> }",
            directives: [router_1.ROUTER_DIRECTIVES],
        }),
        router_1.RouteConfig([new router_1.Route({ path: '/b', component: HelloCmp, name: 'Child', useAsDefault: true })]), 
        __metadata('design:paramtypes', [])
    ], ParentWithDefaultCmp);
    return ParentWithDefaultCmp;
})();
exports.ParentWithDefaultCmp = ParentWithDefaultCmp;
function parentWithDefaultCmpLoader() {
    return async_1.PromiseWrapper.resolve(ParentWithDefaultCmp);
}
exports.parentWithDefaultCmpLoader = parentWithDefaultCmpLoader;
var TeamCmp = (function () {
    function TeamCmp(params) {
        this.id = params.get('id');
    }
    TeamCmp = __decorate([
        core_1.Component({
            selector: 'team-cmp',
            template: "team {{id}} | user { <router-outlet></router-outlet> }",
            directives: [router_1.ROUTER_DIRECTIVES],
        }),
        router_1.RouteConfig([new router_1.Route({ path: '/user/:name', component: UserCmp, name: 'User' })]), 
        __metadata('design:paramtypes', [router_1.RouteParams])
    ], TeamCmp);
    return TeamCmp;
})();
exports.TeamCmp = TeamCmp;
var AsyncTeamCmp = (function () {
    function AsyncTeamCmp(params) {
        this.id = params.get('id');
    }
    AsyncTeamCmp = __decorate([
        core_1.Component({
            selector: 'team-cmp',
            template: "team {{id}} | user { <router-outlet></router-outlet> }",
            directives: [router_1.ROUTER_DIRECTIVES],
        }),
        router_1.RouteConfig([new router_1.AsyncRoute({ path: '/user/:name', loader: userCmpLoader, name: 'User' })]), 
        __metadata('design:paramtypes', [router_1.RouteParams])
    ], AsyncTeamCmp);
    return AsyncTeamCmp;
})();
exports.AsyncTeamCmp = AsyncTeamCmp;
function asyncTeamLoader() {
    return async_1.PromiseWrapper.resolve(AsyncTeamCmp);
}
exports.asyncTeamLoader = asyncTeamLoader;
var RouteDataCmp = (function () {
    function RouteDataCmp(data) {
        this.myData = data.get('isAdmin');
    }
    RouteDataCmp = __decorate([
        core_1.Component({ selector: 'data-cmp', template: "{{myData}}" }), 
        __metadata('design:paramtypes', [router_1.RouteData])
    ], RouteDataCmp);
    return RouteDataCmp;
})();
exports.RouteDataCmp = RouteDataCmp;
function asyncRouteDataCmp() {
    return async_1.PromiseWrapper.resolve(RouteDataCmp);
}
exports.asyncRouteDataCmp = asyncRouteDataCmp;
var RedirectToParentCmp = (function () {
    function RedirectToParentCmp() {
    }
    RedirectToParentCmp = __decorate([
        core_1.Component({ selector: 'redirect-to-parent-cmp', template: 'redirect-to-parent' }),
        router_1.RouteConfig([new router_1.Redirect({ path: '/child-redirect', redirectTo: ['../HelloSib'] })]), 
        __metadata('design:paramtypes', [])
    ], RedirectToParentCmp);
    return RedirectToParentCmp;
})();
exports.RedirectToParentCmp = RedirectToParentCmp;
var DynamicLoaderCmp = (function () {
    function DynamicLoaderCmp(_dynamicComponentLoader, _elementRef) {
        this._dynamicComponentLoader = _dynamicComponentLoader;
        this._elementRef = _elementRef;
        this._componentRef = null;
    }
    DynamicLoaderCmp.prototype.onSomeAction = function () {
        var _this = this;
        if (lang_1.isPresent(this._componentRef)) {
            this._componentRef.dispose();
            this._componentRef = null;
        }
        return this._dynamicComponentLoader.loadIntoLocation(DynamicallyLoadedComponent, this._elementRef, 'viewport')
            .then(function (cmp) { _this._componentRef = cmp; });
    };
    DynamicLoaderCmp = __decorate([
        core_1.Component({ selector: 'dynamic-loader-cmp', template: "{ <div #viewport></div> }" }),
        router_1.RouteConfig([new router_1.Route({ path: '/', component: HelloCmp })]), 
        __metadata('design:paramtypes', [dynamic_component_loader_1.DynamicComponentLoader, element_ref_1.ElementRef])
    ], DynamicLoaderCmp);
    return DynamicLoaderCmp;
})();
exports.DynamicLoaderCmp = DynamicLoaderCmp;
var DynamicallyLoadedComponent = (function () {
    function DynamicallyLoadedComponent() {
    }
    DynamicallyLoadedComponent = __decorate([
        core_1.Component({
            selector: 'loaded-cmp',
            template: '<router-outlet></router-outlet>',
            directives: [router_1.ROUTER_DIRECTIVES]
        }), 
        __metadata('design:paramtypes', [])
    ], DynamicallyLoadedComponent);
    return DynamicallyLoadedComponent;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZml4dHVyZV9jb21wb25lbnRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9yb3V0ZXIvaW50ZWdyYXRpb24vaW1wbC9maXh0dXJlX2NvbXBvbmVudHMudHMiXSwibmFtZXMiOlsiR29vZGJ5ZUNtcCIsIkdvb2RieWVDbXAuY29uc3RydWN0b3IiLCJIZWxsb0NtcCIsIkhlbGxvQ21wLmNvbnN0cnVjdG9yIiwiaGVsbG9DbXBMb2FkZXIiLCJVc2VyQ21wIiwiVXNlckNtcC5jb25zdHJ1Y3RvciIsInVzZXJDbXBMb2FkZXIiLCJQYXJlbnRDbXAiLCJQYXJlbnRDbXAuY29uc3RydWN0b3IiLCJwYXJlbnRDbXBMb2FkZXIiLCJBc3luY1BhcmVudENtcCIsIkFzeW5jUGFyZW50Q21wLmNvbnN0cnVjdG9yIiwiYXN5bmNQYXJlbnRDbXBMb2FkZXIiLCJBc3luY0RlZmF1bHRQYXJlbnRDbXAiLCJBc3luY0RlZmF1bHRQYXJlbnRDbXAuY29uc3RydWN0b3IiLCJhc3luY0RlZmF1bHRQYXJlbnRDbXBMb2FkZXIiLCJQYXJlbnRXaXRoRGVmYXVsdENtcCIsIlBhcmVudFdpdGhEZWZhdWx0Q21wLmNvbnN0cnVjdG9yIiwicGFyZW50V2l0aERlZmF1bHRDbXBMb2FkZXIiLCJUZWFtQ21wIiwiVGVhbUNtcC5jb25zdHJ1Y3RvciIsIkFzeW5jVGVhbUNtcCIsIkFzeW5jVGVhbUNtcC5jb25zdHJ1Y3RvciIsImFzeW5jVGVhbUxvYWRlciIsIlJvdXRlRGF0YUNtcCIsIlJvdXRlRGF0YUNtcC5jb25zdHJ1Y3RvciIsImFzeW5jUm91dGVEYXRhQ21wIiwiUmVkaXJlY3RUb1BhcmVudENtcCIsIlJlZGlyZWN0VG9QYXJlbnRDbXAuY29uc3RydWN0b3IiLCJEeW5hbWljTG9hZGVyQ21wIiwiRHluYW1pY0xvYWRlckNtcC5jb25zdHJ1Y3RvciIsIkR5bmFtaWNMb2FkZXJDbXAub25Tb21lQWN0aW9uIiwiRHluYW1pY2FsbHlMb2FkZWRDb21wb25lbnQiLCJEeW5hbWljYWxseUxvYWRlZENvbXBvbmVudC5jb25zdHJ1Y3RvciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEscUJBQXdCLGVBQWUsQ0FBQyxDQUFBO0FBQ3hDLHVCQVFPLGlCQUFpQixDQUFDLENBQUE7QUFDekIsc0JBQTZCLDJCQUEyQixDQUFDLENBQUE7QUFDekQscUJBQXdCLDBCQUEwQixDQUFDLENBQUE7QUFDbkQseUNBR08sbURBQW1ELENBQUMsQ0FBQTtBQUMzRCw0QkFBeUIsc0NBQXNDLENBQUMsQ0FBQTtBQUVoRTtJQUdFQTtRQUFnQkMsSUFBSUEsQ0FBQ0EsUUFBUUEsR0FBR0EsU0FBU0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFIOUNEO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxhQUFhQSxFQUFFQSxRQUFRQSxFQUFFQSxjQUFjQSxFQUFDQSxDQUFDQTs7bUJBSTlEQTtJQUFEQSxpQkFBQ0E7QUFBREEsQ0FBQ0EsQUFKRCxJQUlDO0FBSFksa0JBQVUsYUFHdEIsQ0FBQTtBQUVEO0lBR0VFO1FBQWdCQyxJQUFJQSxDQUFDQSxRQUFRQSxHQUFHQSxPQUFPQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUg1Q0Q7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLFdBQVdBLEVBQUVBLFFBQVFBLEVBQUVBLGNBQWNBLEVBQUNBLENBQUNBOztpQkFJNURBO0lBQURBLGVBQUNBO0FBQURBLENBQUNBLEFBSkQsSUFJQztBQUhZLGdCQUFRLFdBR3BCLENBQUE7QUFFRDtJQUNFRSxNQUFNQSxDQUFDQSxzQkFBY0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0E7QUFDMUNBLENBQUNBO0FBRmUsc0JBQWMsaUJBRTdCLENBQUE7QUFHRDtJQUdFQyxpQkFBWUEsTUFBbUJBO1FBQUlDLElBQUlBLENBQUNBLElBQUlBLEdBQUdBLE1BQU1BLENBQUNBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBSHRFRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsVUFBVUEsRUFBRUEsUUFBUUEsRUFBRUEsZ0JBQWdCQSxFQUFDQSxDQUFDQTs7Z0JBSTdEQTtJQUFEQSxjQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFIWSxlQUFPLFVBR25CLENBQUE7QUFFRDtJQUNFRSxNQUFNQSxDQUFDQSxzQkFBY0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7QUFDekNBLENBQUNBO0FBRmUscUJBQWEsZ0JBRTVCLENBQUE7QUFHRDtJQUFBQztJQU9BQyxDQUFDQTtJQVBERDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsWUFBWUE7WUFDdEJBLFFBQVFBLEVBQUVBLDJDQUEyQ0E7WUFDckRBLFVBQVVBLEVBQUVBLENBQUNBLDBCQUFpQkEsQ0FBQ0E7U0FDaENBLENBQUNBO1FBQ0RBLG9CQUFXQSxDQUFDQSxDQUFDQSxJQUFJQSxjQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxFQUFFQSxTQUFTQSxFQUFFQSxRQUFRQSxFQUFFQSxJQUFJQSxFQUFFQSxPQUFPQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTs7a0JBRTFFQTtJQUFEQSxnQkFBQ0E7QUFBREEsQ0FBQ0EsQUFQRCxJQU9DO0FBRFksaUJBQVMsWUFDckIsQ0FBQTtBQUVEO0lBQ0VFLE1BQU1BLENBQUNBLHNCQUFjQSxDQUFDQSxPQUFPQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQTtBQUMzQ0EsQ0FBQ0E7QUFGZSx1QkFBZSxrQkFFOUIsQ0FBQTtBQUdEO0lBQUFDO0lBT0FDLENBQUNBO0lBUEREO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxZQUFZQTtZQUN0QkEsUUFBUUEsRUFBRUEsMkNBQTJDQTtZQUNyREEsVUFBVUEsRUFBRUEsQ0FBQ0EsMEJBQWlCQSxDQUFDQTtTQUNoQ0EsQ0FBQ0E7UUFDREEsb0JBQVdBLENBQUNBLENBQUNBLElBQUlBLG1CQUFVQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxFQUFFQSxNQUFNQSxFQUFFQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxPQUFPQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTs7dUJBRWxGQTtJQUFEQSxxQkFBQ0E7QUFBREEsQ0FBQ0EsQUFQRCxJQU9DO0FBRFksc0JBQWMsaUJBQzFCLENBQUE7QUFFRDtJQUNFRSxNQUFNQSxDQUFDQSxzQkFBY0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsY0FBY0EsQ0FBQ0EsQ0FBQ0E7QUFDaERBLENBQUNBO0FBRmUsNEJBQW9CLHVCQUVuQyxDQUFBO0FBRUQ7SUFBQUM7SUFRQUMsQ0FBQ0E7SUFSREQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLFlBQVlBO1lBQ3RCQSxRQUFRQSxFQUFFQSwyQ0FBMkNBO1lBQ3JEQSxVQUFVQSxFQUFFQSxDQUFDQSwwQkFBaUJBLENBQUNBO1NBQ2hDQSxDQUFDQTtRQUNEQSxvQkFBV0EsQ0FDUkEsQ0FBQ0EsSUFBSUEsbUJBQVVBLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLElBQUlBLEVBQUVBLE1BQU1BLEVBQUVBLGNBQWNBLEVBQUVBLElBQUlBLEVBQUVBLE9BQU9BLEVBQUVBLFlBQVlBLEVBQUVBLElBQUlBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBOzs4QkFFN0ZBO0lBQURBLDRCQUFDQTtBQUFEQSxDQUFDQSxBQVJELElBUUM7QUFEWSw2QkFBcUIsd0JBQ2pDLENBQUE7QUFFRDtJQUNFRSxNQUFNQSxDQUFDQSxzQkFBY0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQTtBQUN2REEsQ0FBQ0E7QUFGZSxtQ0FBMkIsOEJBRTFDLENBQUE7QUFHRDtJQUFBQztJQU9BQyxDQUFDQTtJQVBERDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsWUFBWUE7WUFDdEJBLFFBQVFBLEVBQUVBLDJDQUEyQ0E7WUFDckRBLFVBQVVBLEVBQUVBLENBQUNBLDBCQUFpQkEsQ0FBQ0E7U0FDaENBLENBQUNBO1FBQ0RBLG9CQUFXQSxDQUFDQSxDQUFDQSxJQUFJQSxjQUFLQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxFQUFFQSxTQUFTQSxFQUFFQSxRQUFRQSxFQUFFQSxJQUFJQSxFQUFFQSxPQUFPQSxFQUFFQSxZQUFZQSxFQUFFQSxJQUFJQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTs7NkJBRTlGQTtJQUFEQSwyQkFBQ0E7QUFBREEsQ0FBQ0EsQUFQRCxJQU9DO0FBRFksNEJBQW9CLHVCQUNoQyxDQUFBO0FBRUQ7SUFDRUUsTUFBTUEsQ0FBQ0Esc0JBQWNBLENBQUNBLE9BQU9BLENBQUNBLG9CQUFvQkEsQ0FBQ0EsQ0FBQ0E7QUFDdERBLENBQUNBO0FBRmUsa0NBQTBCLDZCQUV6QyxDQUFBO0FBR0Q7SUFRRUMsaUJBQVlBLE1BQW1CQTtRQUFJQyxJQUFJQSxDQUFDQSxFQUFFQSxHQUFHQSxNQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtJQUFDQSxDQUFDQTtJQVJsRUQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLFVBQVVBO1lBQ3BCQSxRQUFRQSxFQUFFQSx3REFBd0RBO1lBQ2xFQSxVQUFVQSxFQUFFQSxDQUFDQSwwQkFBaUJBLENBQUNBO1NBQ2hDQSxDQUFDQTtRQUNEQSxvQkFBV0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsY0FBS0EsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsYUFBYUEsRUFBRUEsU0FBU0EsRUFBRUEsT0FBT0EsRUFBRUEsSUFBSUEsRUFBRUEsTUFBTUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7O2dCQUlqRkE7SUFBREEsY0FBQ0E7QUFBREEsQ0FBQ0EsQUFURCxJQVNDO0FBSFksZUFBTyxVQUduQixDQUFBO0FBRUQ7SUFRRUUsc0JBQVlBLE1BQW1CQTtRQUFJQyxJQUFJQSxDQUFDQSxFQUFFQSxHQUFHQSxNQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtJQUFDQSxDQUFDQTtJQVJsRUQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLFVBQVVBO1lBQ3BCQSxRQUFRQSxFQUFFQSx3REFBd0RBO1lBQ2xFQSxVQUFVQSxFQUFFQSxDQUFDQSwwQkFBaUJBLENBQUNBO1NBQ2hDQSxDQUFDQTtRQUNEQSxvQkFBV0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsbUJBQVVBLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLGFBQWFBLEVBQUVBLE1BQU1BLEVBQUVBLGFBQWFBLEVBQUVBLElBQUlBLEVBQUVBLE1BQU1BLEVBQUNBLENBQUNBLENBQUNBLENBQUNBOztxQkFJekZBO0lBQURBLG1CQUFDQTtBQUFEQSxDQUFDQSxBQVRELElBU0M7QUFIWSxvQkFBWSxlQUd4QixDQUFBO0FBRUQ7SUFDRUUsTUFBTUEsQ0FBQ0Esc0JBQWNBLENBQUNBLE9BQU9BLENBQUNBLFlBQVlBLENBQUNBLENBQUNBO0FBQzlDQSxDQUFDQTtBQUZlLHVCQUFlLGtCQUU5QixDQUFBO0FBR0Q7SUFHRUMsc0JBQVlBLElBQWVBO1FBQUlDLElBQUlBLENBQUNBLE1BQU1BLEdBQUdBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBO0lBQUNBLENBQUNBO0lBSHJFRDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsVUFBVUEsRUFBRUEsUUFBUUEsRUFBRUEsWUFBWUEsRUFBQ0EsQ0FBQ0E7O3FCQUl6REE7SUFBREEsbUJBQUNBO0FBQURBLENBQUNBLEFBSkQsSUFJQztBQUhZLG9CQUFZLGVBR3hCLENBQUE7QUFFRDtJQUNFRSxNQUFNQSxDQUFDQSxzQkFBY0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0E7QUFDOUNBLENBQUNBO0FBRmUseUJBQWlCLG9CQUVoQyxDQUFBO0FBRUQ7SUFBQUM7SUFHQUMsQ0FBQ0E7SUFIREQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLHdCQUF3QkEsRUFBRUEsUUFBUUEsRUFBRUEsb0JBQW9CQSxFQUFDQSxDQUFDQTtRQUMvRUEsb0JBQVdBLENBQUNBLENBQUNBLElBQUlBLGlCQUFRQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxpQkFBaUJBLEVBQUVBLFVBQVVBLEVBQUVBLENBQUNBLGFBQWFBLENBQUNBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBOzs0QkFFbkZBO0lBQURBLDBCQUFDQTtBQUFEQSxDQUFDQSxBQUhELElBR0M7QUFEWSwyQkFBbUIsc0JBQy9CLENBQUE7QUFHRDtJQUlFRSwwQkFBb0JBLHVCQUErQ0EsRUFDL0NBLFdBQXVCQTtRQUR2QkMsNEJBQXVCQSxHQUF2QkEsdUJBQXVCQSxDQUF3QkE7UUFDL0NBLGdCQUFXQSxHQUFYQSxXQUFXQSxDQUFZQTtRQUZuQ0Esa0JBQWFBLEdBQWlCQSxJQUFJQSxDQUFDQTtJQUVHQSxDQUFDQTtJQUUvQ0QsdUNBQVlBLEdBQVpBO1FBQUFFLGlCQVFDQTtRQVBDQSxFQUFFQSxDQUFDQSxDQUFDQSxnQkFBU0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDbENBLElBQUlBLENBQUNBLGFBQWFBLENBQUNBLE9BQU9BLEVBQUVBLENBQUNBO1lBQzdCQSxJQUFJQSxDQUFDQSxhQUFhQSxHQUFHQSxJQUFJQSxDQUFDQTtRQUM1QkEsQ0FBQ0E7UUFDREEsTUFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsdUJBQXVCQSxDQUFDQSxnQkFBZ0JBLENBQUNBLDBCQUEwQkEsRUFDMUJBLElBQUlBLENBQUNBLFdBQVdBLEVBQUVBLFVBQVVBLENBQUNBO2FBQzdFQSxJQUFJQSxDQUFDQSxVQUFDQSxHQUFHQSxJQUFPQSxLQUFJQSxDQUFDQSxhQUFhQSxHQUFHQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUNwREEsQ0FBQ0E7SUFmSEY7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLG9CQUFvQkEsRUFBRUEsUUFBUUEsRUFBRUEsMkJBQTJCQSxFQUFDQSxDQUFDQTtRQUNsRkEsb0JBQVdBLENBQUNBLENBQUNBLElBQUlBLGNBQUtBLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLEdBQUdBLEVBQUVBLFNBQVNBLEVBQUVBLFFBQVFBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBOzt5QkFlMURBO0lBQURBLHVCQUFDQTtBQUFEQSxDQUFDQSxBQWhCRCxJQWdCQztBQWRZLHdCQUFnQixtQkFjNUIsQ0FBQTtBQUdEO0lBQUFHO0lBTUFDLENBQUNBO0lBTkREO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxZQUFZQTtZQUN0QkEsUUFBUUEsRUFBRUEsaUNBQWlDQTtZQUMzQ0EsVUFBVUEsRUFBRUEsQ0FBQ0EsMEJBQWlCQSxDQUFDQTtTQUNoQ0EsQ0FBQ0E7O21DQUVEQTtJQUFEQSxpQ0FBQ0E7QUFBREEsQ0FBQ0EsQUFORCxJQU1DIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnR9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuaW1wb3J0IHtcbiAgQXN5bmNSb3V0ZSxcbiAgUm91dGUsXG4gIFJlZGlyZWN0LFxuICBSb3V0ZUNvbmZpZyxcbiAgUm91dGVQYXJhbXMsXG4gIFJvdXRlRGF0YSxcbiAgUk9VVEVSX0RJUkVDVElWRVNcbn0gZnJvbSAnYW5ndWxhcjIvcm91dGVyJztcbmltcG9ydCB7UHJvbWlzZVdyYXBwZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvYXN5bmMnO1xuaW1wb3J0IHtpc1ByZXNlbnR9IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvbGFuZyc7XG5pbXBvcnQge1xuICBEeW5hbWljQ29tcG9uZW50TG9hZGVyLFxuICBDb21wb25lbnRSZWZcbn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvbGlua2VyL2R5bmFtaWNfY29tcG9uZW50X2xvYWRlcic7XG5pbXBvcnQge0VsZW1lbnRSZWZ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci9lbGVtZW50X3JlZic7XG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnZ29vZGJ5ZS1jbXAnLCB0ZW1wbGF0ZTogYHt7ZmFyZXdlbGx9fWB9KVxuZXhwb3J0IGNsYXNzIEdvb2RieWVDbXAge1xuICBmYXJld2VsbDogc3RyaW5nO1xuICBjb25zdHJ1Y3RvcigpIHsgdGhpcy5mYXJld2VsbCA9ICdnb29kYnllJzsgfVxufVxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ2hlbGxvLWNtcCcsIHRlbXBsYXRlOiBge3tncmVldGluZ319YH0pXG5leHBvcnQgY2xhc3MgSGVsbG9DbXAge1xuICBncmVldGluZzogc3RyaW5nO1xuICBjb25zdHJ1Y3RvcigpIHsgdGhpcy5ncmVldGluZyA9ICdoZWxsbyc7IH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGhlbGxvQ21wTG9hZGVyKCkge1xuICByZXR1cm4gUHJvbWlzZVdyYXBwZXIucmVzb2x2ZShIZWxsb0NtcCk7XG59XG5cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICd1c2VyLWNtcCcsIHRlbXBsYXRlOiBgaGVsbG8ge3t1c2VyfX1gfSlcbmV4cG9ydCBjbGFzcyBVc2VyQ21wIHtcbiAgdXNlcjogc3RyaW5nO1xuICBjb25zdHJ1Y3RvcihwYXJhbXM6IFJvdXRlUGFyYW1zKSB7IHRoaXMudXNlciA9IHBhcmFtcy5nZXQoJ25hbWUnKTsgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlckNtcExvYWRlcigpIHtcbiAgcmV0dXJuIFByb21pc2VXcmFwcGVyLnJlc29sdmUoVXNlckNtcCk7XG59XG5cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAncGFyZW50LWNtcCcsXG4gIHRlbXBsYXRlOiBgaW5uZXIgeyA8cm91dGVyLW91dGxldD48L3JvdXRlci1vdXRsZXQ+IH1gLFxuICBkaXJlY3RpdmVzOiBbUk9VVEVSX0RJUkVDVElWRVNdLFxufSlcbkBSb3V0ZUNvbmZpZyhbbmV3IFJvdXRlKHtwYXRoOiAnL2InLCBjb21wb25lbnQ6IEhlbGxvQ21wLCBuYW1lOiAnQ2hpbGQnfSldKVxuZXhwb3J0IGNsYXNzIFBhcmVudENtcCB7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJlbnRDbXBMb2FkZXIoKSB7XG4gIHJldHVybiBQcm9taXNlV3JhcHBlci5yZXNvbHZlKFBhcmVudENtcCk7XG59XG5cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAncGFyZW50LWNtcCcsXG4gIHRlbXBsYXRlOiBgaW5uZXIgeyA8cm91dGVyLW91dGxldD48L3JvdXRlci1vdXRsZXQ+IH1gLFxuICBkaXJlY3RpdmVzOiBbUk9VVEVSX0RJUkVDVElWRVNdLFxufSlcbkBSb3V0ZUNvbmZpZyhbbmV3IEFzeW5jUm91dGUoe3BhdGg6ICcvYicsIGxvYWRlcjogaGVsbG9DbXBMb2FkZXIsIG5hbWU6ICdDaGlsZCd9KV0pXG5leHBvcnQgY2xhc3MgQXN5bmNQYXJlbnRDbXAge1xufVxuXG5leHBvcnQgZnVuY3Rpb24gYXN5bmNQYXJlbnRDbXBMb2FkZXIoKSB7XG4gIHJldHVybiBQcm9taXNlV3JhcHBlci5yZXNvbHZlKEFzeW5jUGFyZW50Q21wKTtcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAncGFyZW50LWNtcCcsXG4gIHRlbXBsYXRlOiBgaW5uZXIgeyA8cm91dGVyLW91dGxldD48L3JvdXRlci1vdXRsZXQ+IH1gLFxuICBkaXJlY3RpdmVzOiBbUk9VVEVSX0RJUkVDVElWRVNdLFxufSlcbkBSb3V0ZUNvbmZpZyhcbiAgICBbbmV3IEFzeW5jUm91dGUoe3BhdGg6ICcvYicsIGxvYWRlcjogaGVsbG9DbXBMb2FkZXIsIG5hbWU6ICdDaGlsZCcsIHVzZUFzRGVmYXVsdDogdHJ1ZX0pXSlcbmV4cG9ydCBjbGFzcyBBc3luY0RlZmF1bHRQYXJlbnRDbXAge1xufVxuXG5leHBvcnQgZnVuY3Rpb24gYXN5bmNEZWZhdWx0UGFyZW50Q21wTG9hZGVyKCkge1xuICByZXR1cm4gUHJvbWlzZVdyYXBwZXIucmVzb2x2ZShBc3luY0RlZmF1bHRQYXJlbnRDbXApO1xufVxuXG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ3BhcmVudC1jbXAnLFxuICB0ZW1wbGF0ZTogYGlubmVyIHsgPHJvdXRlci1vdXRsZXQ+PC9yb3V0ZXItb3V0bGV0PiB9YCxcbiAgZGlyZWN0aXZlczogW1JPVVRFUl9ESVJFQ1RJVkVTXSxcbn0pXG5AUm91dGVDb25maWcoW25ldyBSb3V0ZSh7cGF0aDogJy9iJywgY29tcG9uZW50OiBIZWxsb0NtcCwgbmFtZTogJ0NoaWxkJywgdXNlQXNEZWZhdWx0OiB0cnVlfSldKVxuZXhwb3J0IGNsYXNzIFBhcmVudFdpdGhEZWZhdWx0Q21wIHtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcmVudFdpdGhEZWZhdWx0Q21wTG9hZGVyKCkge1xuICByZXR1cm4gUHJvbWlzZVdyYXBwZXIucmVzb2x2ZShQYXJlbnRXaXRoRGVmYXVsdENtcCk7XG59XG5cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAndGVhbS1jbXAnLFxuICB0ZW1wbGF0ZTogYHRlYW0ge3tpZH19IHwgdXNlciB7IDxyb3V0ZXItb3V0bGV0Pjwvcm91dGVyLW91dGxldD4gfWAsXG4gIGRpcmVjdGl2ZXM6IFtST1VURVJfRElSRUNUSVZFU10sXG59KVxuQFJvdXRlQ29uZmlnKFtuZXcgUm91dGUoe3BhdGg6ICcvdXNlci86bmFtZScsIGNvbXBvbmVudDogVXNlckNtcCwgbmFtZTogJ1VzZXInfSldKVxuZXhwb3J0IGNsYXNzIFRlYW1DbXAge1xuICBpZDogc3RyaW5nO1xuICBjb25zdHJ1Y3RvcihwYXJhbXM6IFJvdXRlUGFyYW1zKSB7IHRoaXMuaWQgPSBwYXJhbXMuZ2V0KCdpZCcpOyB9XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ3RlYW0tY21wJyxcbiAgdGVtcGxhdGU6IGB0ZWFtIHt7aWR9fSB8IHVzZXIgeyA8cm91dGVyLW91dGxldD48L3JvdXRlci1vdXRsZXQ+IH1gLFxuICBkaXJlY3RpdmVzOiBbUk9VVEVSX0RJUkVDVElWRVNdLFxufSlcbkBSb3V0ZUNvbmZpZyhbbmV3IEFzeW5jUm91dGUoe3BhdGg6ICcvdXNlci86bmFtZScsIGxvYWRlcjogdXNlckNtcExvYWRlciwgbmFtZTogJ1VzZXInfSldKVxuZXhwb3J0IGNsYXNzIEFzeW5jVGVhbUNtcCB7XG4gIGlkOiBzdHJpbmc7XG4gIGNvbnN0cnVjdG9yKHBhcmFtczogUm91dGVQYXJhbXMpIHsgdGhpcy5pZCA9IHBhcmFtcy5nZXQoJ2lkJyk7IH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGFzeW5jVGVhbUxvYWRlcigpIHtcbiAgcmV0dXJuIFByb21pc2VXcmFwcGVyLnJlc29sdmUoQXN5bmNUZWFtQ21wKTtcbn1cblxuXG5AQ29tcG9uZW50KHtzZWxlY3RvcjogJ2RhdGEtY21wJywgdGVtcGxhdGU6IGB7e215RGF0YX19YH0pXG5leHBvcnQgY2xhc3MgUm91dGVEYXRhQ21wIHtcbiAgbXlEYXRhOiBib29sZWFuO1xuICBjb25zdHJ1Y3RvcihkYXRhOiBSb3V0ZURhdGEpIHsgdGhpcy5teURhdGEgPSBkYXRhLmdldCgnaXNBZG1pbicpOyB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhc3luY1JvdXRlRGF0YUNtcCgpIHtcbiAgcmV0dXJuIFByb21pc2VXcmFwcGVyLnJlc29sdmUoUm91dGVEYXRhQ21wKTtcbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdyZWRpcmVjdC10by1wYXJlbnQtY21wJywgdGVtcGxhdGU6ICdyZWRpcmVjdC10by1wYXJlbnQnfSlcbkBSb3V0ZUNvbmZpZyhbbmV3IFJlZGlyZWN0KHtwYXRoOiAnL2NoaWxkLXJlZGlyZWN0JywgcmVkaXJlY3RUbzogWycuLi9IZWxsb1NpYiddfSldKVxuZXhwb3J0IGNsYXNzIFJlZGlyZWN0VG9QYXJlbnRDbXAge1xufVxuXG5cbkBDb21wb25lbnQoe3NlbGVjdG9yOiAnZHluYW1pYy1sb2FkZXItY21wJywgdGVtcGxhdGU6IGB7IDxkaXYgI3ZpZXdwb3J0PjwvZGl2PiB9YH0pXG5AUm91dGVDb25maWcoW25ldyBSb3V0ZSh7cGF0aDogJy8nLCBjb21wb25lbnQ6IEhlbGxvQ21wfSldKVxuZXhwb3J0IGNsYXNzIER5bmFtaWNMb2FkZXJDbXAge1xuICBwcml2YXRlIF9jb21wb25lbnRSZWY6IENvbXBvbmVudFJlZiA9IG51bGw7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgX2R5bmFtaWNDb21wb25lbnRMb2FkZXI6IER5bmFtaWNDb21wb25lbnRMb2FkZXIsXG4gICAgICAgICAgICAgIHByaXZhdGUgX2VsZW1lbnRSZWY6IEVsZW1lbnRSZWYpIHt9XG5cbiAgb25Tb21lQWN0aW9uKCk6IFByb21pc2U8YW55PiB7XG4gICAgaWYgKGlzUHJlc2VudCh0aGlzLl9jb21wb25lbnRSZWYpKSB7XG4gICAgICB0aGlzLl9jb21wb25lbnRSZWYuZGlzcG9zZSgpO1xuICAgICAgdGhpcy5fY29tcG9uZW50UmVmID0gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2R5bmFtaWNDb21wb25lbnRMb2FkZXIubG9hZEludG9Mb2NhdGlvbihEeW5hbWljYWxseUxvYWRlZENvbXBvbmVudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2VsZW1lbnRSZWYsICd2aWV3cG9ydCcpXG4gICAgICAgIC50aGVuKChjbXApID0+IHsgdGhpcy5fY29tcG9uZW50UmVmID0gY21wOyB9KTtcbiAgfVxufVxuXG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2xvYWRlZC1jbXAnLFxuICB0ZW1wbGF0ZTogJzxyb3V0ZXItb3V0bGV0Pjwvcm91dGVyLW91dGxldD4nLFxuICBkaXJlY3RpdmVzOiBbUk9VVEVSX0RJUkVDVElWRVNdXG59KVxuY2xhc3MgRHluYW1pY2FsbHlMb2FkZWRDb21wb25lbnQge1xufVxuIl19