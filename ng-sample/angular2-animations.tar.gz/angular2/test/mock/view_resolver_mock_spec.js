'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var lang_1 = require('angular2/src/facade/lang');
var view_resolver_mock_1 = require('angular2/src/mock/view_resolver_mock');
var metadata_1 = require('angular2/src/core/metadata');
var lang_2 = require('angular2/src/facade/lang');
function main() {
    testing_internal_1.describe('MockViewResolver', function () {
        var viewResolver;
        testing_internal_1.beforeEach(function () { viewResolver = new view_resolver_mock_1.MockViewResolver(); });
        testing_internal_1.describe('View overriding', function () {
            testing_internal_1.it('should fallback to the default ViewResolver when templates are not overridden', function () {
                var view = viewResolver.resolve(SomeComponent);
                testing_internal_1.expect(view.template).toEqual('template');
                testing_internal_1.expect(view.directives).toEqual([SomeDirective]);
            });
            testing_internal_1.it('should allow overriding the @View', function () {
                viewResolver.setView(SomeComponent, new metadata_1.ViewMetadata({ template: 'overridden template' }));
                var view = viewResolver.resolve(SomeComponent);
                testing_internal_1.expect(view.template).toEqual('overridden template');
                testing_internal_1.expect(lang_2.isBlank(view.directives)).toBe(true);
            });
            testing_internal_1.it('should not allow overriding a view after it has been resolved', function () {
                viewResolver.resolve(SomeComponent);
                testing_internal_1.expect(function () {
                    viewResolver.setView(SomeComponent, new metadata_1.ViewMetadata({ template: 'overridden template' }));
                })
                    .toThrowError("The component " + lang_1.stringify(SomeComponent) + " has already been compiled, its configuration can not be changed");
            });
        });
        testing_internal_1.describe('inline template definition overriding', function () {
            testing_internal_1.it('should allow overriding the default template', function () {
                viewResolver.setInlineTemplate(SomeComponent, 'overridden template');
                var view = viewResolver.resolve(SomeComponent);
                testing_internal_1.expect(view.template).toEqual('overridden template');
                testing_internal_1.expect(view.directives).toEqual([SomeDirective]);
            });
            testing_internal_1.it('should allow overriding an overridden @View', function () {
                viewResolver.setView(SomeComponent, new metadata_1.ViewMetadata({ template: 'overridden template' }));
                viewResolver.setInlineTemplate(SomeComponent, 'overridden template x 2');
                var view = viewResolver.resolve(SomeComponent);
                testing_internal_1.expect(view.template).toEqual('overridden template x 2');
            });
            testing_internal_1.it('should not allow overriding a view after it has been resolved', function () {
                viewResolver.resolve(SomeComponent);
                testing_internal_1.expect(function () { viewResolver.setInlineTemplate(SomeComponent, 'overridden template'); })
                    .toThrowError("The component " + lang_1.stringify(SomeComponent) + " has already been compiled, its configuration can not be changed");
            });
        });
        testing_internal_1.describe('Directive overriding', function () {
            testing_internal_1.it('should allow overriding a directive from the default view', function () {
                viewResolver.overrideViewDirective(SomeComponent, SomeDirective, SomeOtherDirective);
                var view = viewResolver.resolve(SomeComponent);
                testing_internal_1.expect(view.directives.length).toEqual(1);
                testing_internal_1.expect(view.directives[0]).toBe(SomeOtherDirective);
            });
            testing_internal_1.it('should allow overriding a directive from an overridden @View', function () {
                viewResolver.setView(SomeComponent, new metadata_1.ViewMetadata({ directives: [SomeOtherDirective] }));
                viewResolver.overrideViewDirective(SomeComponent, SomeOtherDirective, SomeComponent);
                var view = viewResolver.resolve(SomeComponent);
                testing_internal_1.expect(view.directives.length).toEqual(1);
                testing_internal_1.expect(view.directives[0]).toBe(SomeComponent);
            });
            testing_internal_1.it('should throw when the overridden directive is not present', function () {
                viewResolver.overrideViewDirective(SomeComponent, SomeOtherDirective, SomeDirective);
                testing_internal_1.expect(function () { viewResolver.resolve(SomeComponent); })
                    .toThrowError("Overriden directive " + lang_1.stringify(SomeOtherDirective) + " not found in the template of " + lang_1.stringify(SomeComponent));
            });
            testing_internal_1.it('should not allow overriding a directive after its view has been resolved', function () {
                viewResolver.resolve(SomeComponent);
                testing_internal_1.expect(function () {
                    viewResolver.overrideViewDirective(SomeComponent, SomeDirective, SomeOtherDirective);
                })
                    .toThrowError("The component " + lang_1.stringify(SomeComponent) + " has already been compiled, its configuration can not be changed");
            });
        });
    });
}
exports.main = main;
var SomeDirective = (function () {
    function SomeDirective() {
    }
    return SomeDirective;
})();
var SomeComponent = (function () {
    function SomeComponent() {
    }
    SomeComponent = __decorate([
        metadata_1.Component({
            selector: 'cmp',
            template: 'template',
            directives: [SomeDirective],
        }), 
        __metadata('design:paramtypes', [])
    ], SomeComponent);
    return SomeComponent;
})();
var SomeOtherDirective = (function () {
    function SomeOtherDirective() {
    }
    return SomeOtherDirective;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmlld19yZXNvbHZlcl9tb2NrX3NwZWMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L21vY2svdmlld19yZXNvbHZlcl9tb2NrX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiIsIlNvbWVEaXJlY3RpdmUiLCJTb21lRGlyZWN0aXZlLmNvbnN0cnVjdG9yIiwiU29tZUNvbXBvbmVudCIsIlNvbWVDb21wb25lbnQuY29uc3RydWN0b3IiLCJTb21lT3RoZXJEaXJlY3RpdmUiLCJTb21lT3RoZXJEaXJlY3RpdmUuY29uc3RydWN0b3IiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLGlDQVFPLDJCQUEyQixDQUFDLENBQUE7QUFFbkMscUJBQXdCLDBCQUEwQixDQUFDLENBQUE7QUFFbkQsbUNBQStCLHNDQUFzQyxDQUFDLENBQUE7QUFFdEUseUJBQXNDLDRCQUE0QixDQUFDLENBQUE7QUFFbkUscUJBQXNCLDBCQUEwQixDQUFDLENBQUE7QUFFakQ7SUFDRUEsMkJBQVFBLENBQUNBLGtCQUFrQkEsRUFBRUE7UUFDM0JBLElBQUlBLFlBQThCQSxDQUFDQTtRQUVuQ0EsNkJBQVVBLENBQUNBLGNBQVFBLFlBQVlBLEdBQUdBLElBQUlBLHFDQUFnQkEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFN0RBLDJCQUFRQSxDQUFDQSxpQkFBaUJBLEVBQUVBO1lBQzFCQSxxQkFBRUEsQ0FBQ0EsK0VBQStFQSxFQUFFQTtnQkFDbEZBLElBQUlBLElBQUlBLEdBQUdBLFlBQVlBLENBQUNBLE9BQU9BLENBQUNBLGFBQWFBLENBQUNBLENBQUNBO2dCQUMvQ0EseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLFVBQVVBLENBQUNBLENBQUNBO2dCQUMxQ0EseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLENBQUNBO1lBQ25EQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsbUNBQW1DQSxFQUFFQTtnQkFDdENBLFlBQVlBLENBQUNBLE9BQU9BLENBQUNBLGFBQWFBLEVBQUVBLElBQUlBLHVCQUFZQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxxQkFBcUJBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUN6RkEsSUFBSUEsSUFBSUEsR0FBR0EsWUFBWUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7Z0JBQy9DQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQTtnQkFDckRBLHlCQUFNQSxDQUFDQSxjQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtZQUU5Q0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLCtEQUErREEsRUFBRUE7Z0JBQ2xFQSxZQUFZQSxDQUFDQSxPQUFPQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtnQkFDcENBLHlCQUFNQSxDQUFDQTtvQkFDTEEsWUFBWUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsYUFBYUEsRUFBRUEsSUFBSUEsdUJBQVlBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLHFCQUFxQkEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzNGQSxDQUFDQSxDQUFDQTtxQkFDR0EsWUFBWUEsQ0FDVEEsbUJBQWlCQSxnQkFBU0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EscUVBQWtFQSxDQUFDQSxDQUFDQTtZQUN2SEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEsMkJBQVFBLENBQUNBLHVDQUF1Q0EsRUFBRUE7WUFDaERBLHFCQUFFQSxDQUFDQSw4Q0FBOENBLEVBQUVBO2dCQUNqREEsWUFBWUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxhQUFhQSxFQUFFQSxxQkFBcUJBLENBQUNBLENBQUNBO2dCQUNyRUEsSUFBSUEsSUFBSUEsR0FBR0EsWUFBWUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7Z0JBQy9DQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQTtnQkFDckRBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNuREEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDZDQUE2Q0EsRUFBRUE7Z0JBQ2hEQSxZQUFZQSxDQUFDQSxPQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxJQUFJQSx1QkFBWUEsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEscUJBQXFCQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDekZBLFlBQVlBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsYUFBYUEsRUFBRUEseUJBQXlCQSxDQUFDQSxDQUFDQTtnQkFDekVBLElBQUlBLElBQUlBLEdBQUdBLFlBQVlBLENBQUNBLE9BQU9BLENBQUNBLGFBQWFBLENBQUNBLENBQUNBO2dCQUMvQ0EseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLHlCQUF5QkEsQ0FBQ0EsQ0FBQ0E7WUFDM0RBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSwrREFBK0RBLEVBQUVBO2dCQUNsRUEsWUFBWUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3BDQSx5QkFBTUEsQ0FBQ0EsY0FBUUEsWUFBWUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxhQUFhQSxFQUFFQSxxQkFBcUJBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO3FCQUNsRkEsWUFBWUEsQ0FDVEEsbUJBQWlCQSxnQkFBU0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EscUVBQWtFQSxDQUFDQSxDQUFDQTtZQUN2SEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFHSEEsMkJBQVFBLENBQUNBLHNCQUFzQkEsRUFBRUE7WUFDL0JBLHFCQUFFQSxDQUFDQSwyREFBMkRBLEVBQUVBO2dCQUM5REEsWUFBWUEsQ0FBQ0EscUJBQXFCQSxDQUFDQSxhQUFhQSxFQUFFQSxhQUFhQSxFQUFFQSxrQkFBa0JBLENBQUNBLENBQUNBO2dCQUNyRkEsSUFBSUEsSUFBSUEsR0FBR0EsWUFBWUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7Z0JBQy9DQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzFDQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxDQUFDQTtZQUN0REEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDhEQUE4REEsRUFBRUE7Z0JBQ2pFQSxZQUFZQSxDQUFDQSxPQUFPQSxDQUFDQSxhQUFhQSxFQUFFQSxJQUFJQSx1QkFBWUEsQ0FBQ0EsRUFBQ0EsVUFBVUEsRUFBRUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDMUZBLFlBQVlBLENBQUNBLHFCQUFxQkEsQ0FBQ0EsYUFBYUEsRUFBRUEsa0JBQWtCQSxFQUFFQSxhQUFhQSxDQUFDQSxDQUFDQTtnQkFDckZBLElBQUlBLElBQUlBLEdBQUdBLFlBQVlBLENBQUNBLE9BQU9BLENBQUNBLGFBQWFBLENBQUNBLENBQUNBO2dCQUMvQ0EseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFVBQVVBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUMxQ0EseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBO1lBQ2pEQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsMkRBQTJEQSxFQUFFQTtnQkFDOURBLFlBQVlBLENBQUNBLHFCQUFxQkEsQ0FBQ0EsYUFBYUEsRUFBRUEsa0JBQWtCQSxFQUFFQSxhQUFhQSxDQUFDQSxDQUFDQTtnQkFDckZBLHlCQUFNQSxDQUFDQSxjQUFRQSxZQUFZQSxDQUFDQSxPQUFPQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtxQkFDakRBLFlBQVlBLENBQ1RBLHlCQUF1QkEsZ0JBQVNBLENBQUNBLGtCQUFrQkEsQ0FBQ0Esc0NBQWlDQSxnQkFBU0EsQ0FBQ0EsYUFBYUEsQ0FBR0EsQ0FBQ0EsQ0FBQ0E7WUFDM0hBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSwwRUFBMEVBLEVBQUVBO2dCQUM3RUEsWUFBWUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3BDQSx5QkFBTUEsQ0FBQ0E7b0JBQ0xBLFlBQVlBLENBQUNBLHFCQUFxQkEsQ0FBQ0EsYUFBYUEsRUFBRUEsYUFBYUEsRUFBRUEsa0JBQWtCQSxDQUFDQSxDQUFDQTtnQkFDdkZBLENBQUNBLENBQUNBO3FCQUNHQSxZQUFZQSxDQUNUQSxtQkFBaUJBLGdCQUFTQSxDQUFDQSxhQUFhQSxDQUFDQSxxRUFBa0VBLENBQUNBLENBQUNBO1lBQ3ZIQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQXhGZSxZQUFJLE9Bd0ZuQixDQUFBO0FBRUQ7SUFBQUM7SUFBcUJDLENBQUNBO0lBQURELG9CQUFDQTtBQUFEQSxDQUFDQSxBQUF0QixJQUFzQjtBQUV0QjtJQUFBRTtJQU1BQyxDQUFDQTtJQU5ERDtRQUFDQSxvQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsS0FBS0E7WUFDZkEsUUFBUUEsRUFBRUEsVUFBVUE7WUFDcEJBLFVBQVVBLEVBQUVBLENBQUNBLGFBQWFBLENBQUNBO1NBQzVCQSxDQUFDQTs7c0JBRURBO0lBQURBLG9CQUFDQTtBQUFEQSxDQUFDQSxBQU5ELElBTUM7QUFFRDtJQUFBRTtJQUEwQkMsQ0FBQ0E7SUFBREQseUJBQUNBO0FBQURBLENBQUNBLEFBQTNCLElBQTJCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgYmVmb3JlRWFjaCxcbiAgZGRlc2NyaWJlLFxuICBkZXNjcmliZSxcbiAgZWwsXG4gIGV4cGVjdCxcbiAgaWl0LFxuICBpdCxcbn0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmltcG9ydCB7c3RyaW5naWZ5fSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2xhbmcnO1xuXG5pbXBvcnQge01vY2tWaWV3UmVzb2x2ZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9tb2NrL3ZpZXdfcmVzb2x2ZXJfbW9jayc7XG5cbmltcG9ydCB7Q29tcG9uZW50LCBWaWV3TWV0YWRhdGF9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL21ldGFkYXRhJztcblxuaW1wb3J0IHtpc0JsYW5rfSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2xhbmcnO1xuXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpIHtcbiAgZGVzY3JpYmUoJ01vY2tWaWV3UmVzb2x2ZXInLCAoKSA9PiB7XG4gICAgdmFyIHZpZXdSZXNvbHZlcjogTW9ja1ZpZXdSZXNvbHZlcjtcblxuICAgIGJlZm9yZUVhY2goKCkgPT4geyB2aWV3UmVzb2x2ZXIgPSBuZXcgTW9ja1ZpZXdSZXNvbHZlcigpOyB9KTtcblxuICAgIGRlc2NyaWJlKCdWaWV3IG92ZXJyaWRpbmcnLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIGZhbGxiYWNrIHRvIHRoZSBkZWZhdWx0IFZpZXdSZXNvbHZlciB3aGVuIHRlbXBsYXRlcyBhcmUgbm90IG92ZXJyaWRkZW4nLCAoKSA9PiB7XG4gICAgICAgIHZhciB2aWV3ID0gdmlld1Jlc29sdmVyLnJlc29sdmUoU29tZUNvbXBvbmVudCk7XG4gICAgICAgIGV4cGVjdCh2aWV3LnRlbXBsYXRlKS50b0VxdWFsKCd0ZW1wbGF0ZScpO1xuICAgICAgICBleHBlY3Qodmlldy5kaXJlY3RpdmVzKS50b0VxdWFsKFtTb21lRGlyZWN0aXZlXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBhbGxvdyBvdmVycmlkaW5nIHRoZSBAVmlldycsICgpID0+IHtcbiAgICAgICAgdmlld1Jlc29sdmVyLnNldFZpZXcoU29tZUNvbXBvbmVudCwgbmV3IFZpZXdNZXRhZGF0YSh7dGVtcGxhdGU6ICdvdmVycmlkZGVuIHRlbXBsYXRlJ30pKTtcbiAgICAgICAgdmFyIHZpZXcgPSB2aWV3UmVzb2x2ZXIucmVzb2x2ZShTb21lQ29tcG9uZW50KTtcbiAgICAgICAgZXhwZWN0KHZpZXcudGVtcGxhdGUpLnRvRXF1YWwoJ292ZXJyaWRkZW4gdGVtcGxhdGUnKTtcbiAgICAgICAgZXhwZWN0KGlzQmxhbmsodmlldy5kaXJlY3RpdmVzKSkudG9CZSh0cnVlKTtcblxuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgbm90IGFsbG93IG92ZXJyaWRpbmcgYSB2aWV3IGFmdGVyIGl0IGhhcyBiZWVuIHJlc29sdmVkJywgKCkgPT4ge1xuICAgICAgICB2aWV3UmVzb2x2ZXIucmVzb2x2ZShTb21lQ29tcG9uZW50KTtcbiAgICAgICAgZXhwZWN0KCgpID0+IHtcbiAgICAgICAgICB2aWV3UmVzb2x2ZXIuc2V0VmlldyhTb21lQ29tcG9uZW50LCBuZXcgVmlld01ldGFkYXRhKHt0ZW1wbGF0ZTogJ292ZXJyaWRkZW4gdGVtcGxhdGUnfSkpO1xuICAgICAgICB9KVxuICAgICAgICAgICAgLnRvVGhyb3dFcnJvcihcbiAgICAgICAgICAgICAgICBgVGhlIGNvbXBvbmVudCAke3N0cmluZ2lmeShTb21lQ29tcG9uZW50KX0gaGFzIGFscmVhZHkgYmVlbiBjb21waWxlZCwgaXRzIGNvbmZpZ3VyYXRpb24gY2FuIG5vdCBiZSBjaGFuZ2VkYCk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKCdpbmxpbmUgdGVtcGxhdGUgZGVmaW5pdGlvbiBvdmVycmlkaW5nJywgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCBhbGxvdyBvdmVycmlkaW5nIHRoZSBkZWZhdWx0IHRlbXBsYXRlJywgKCkgPT4ge1xuICAgICAgICB2aWV3UmVzb2x2ZXIuc2V0SW5saW5lVGVtcGxhdGUoU29tZUNvbXBvbmVudCwgJ292ZXJyaWRkZW4gdGVtcGxhdGUnKTtcbiAgICAgICAgdmFyIHZpZXcgPSB2aWV3UmVzb2x2ZXIucmVzb2x2ZShTb21lQ29tcG9uZW50KTtcbiAgICAgICAgZXhwZWN0KHZpZXcudGVtcGxhdGUpLnRvRXF1YWwoJ292ZXJyaWRkZW4gdGVtcGxhdGUnKTtcbiAgICAgICAgZXhwZWN0KHZpZXcuZGlyZWN0aXZlcykudG9FcXVhbChbU29tZURpcmVjdGl2ZV0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgYWxsb3cgb3ZlcnJpZGluZyBhbiBvdmVycmlkZGVuIEBWaWV3JywgKCkgPT4ge1xuICAgICAgICB2aWV3UmVzb2x2ZXIuc2V0VmlldyhTb21lQ29tcG9uZW50LCBuZXcgVmlld01ldGFkYXRhKHt0ZW1wbGF0ZTogJ292ZXJyaWRkZW4gdGVtcGxhdGUnfSkpO1xuICAgICAgICB2aWV3UmVzb2x2ZXIuc2V0SW5saW5lVGVtcGxhdGUoU29tZUNvbXBvbmVudCwgJ292ZXJyaWRkZW4gdGVtcGxhdGUgeCAyJyk7XG4gICAgICAgIHZhciB2aWV3ID0gdmlld1Jlc29sdmVyLnJlc29sdmUoU29tZUNvbXBvbmVudCk7XG4gICAgICAgIGV4cGVjdCh2aWV3LnRlbXBsYXRlKS50b0VxdWFsKCdvdmVycmlkZGVuIHRlbXBsYXRlIHggMicpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgbm90IGFsbG93IG92ZXJyaWRpbmcgYSB2aWV3IGFmdGVyIGl0IGhhcyBiZWVuIHJlc29sdmVkJywgKCkgPT4ge1xuICAgICAgICB2aWV3UmVzb2x2ZXIucmVzb2x2ZShTb21lQ29tcG9uZW50KTtcbiAgICAgICAgZXhwZWN0KCgpID0+IHsgdmlld1Jlc29sdmVyLnNldElubGluZVRlbXBsYXRlKFNvbWVDb21wb25lbnQsICdvdmVycmlkZGVuIHRlbXBsYXRlJyk7IH0pXG4gICAgICAgICAgICAudG9UaHJvd0Vycm9yKFxuICAgICAgICAgICAgICAgIGBUaGUgY29tcG9uZW50ICR7c3RyaW5naWZ5KFNvbWVDb21wb25lbnQpfSBoYXMgYWxyZWFkeSBiZWVuIGNvbXBpbGVkLCBpdHMgY29uZmlndXJhdGlvbiBjYW4gbm90IGJlIGNoYW5nZWRgKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG5cbiAgICBkZXNjcmliZSgnRGlyZWN0aXZlIG92ZXJyaWRpbmcnLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIGFsbG93IG92ZXJyaWRpbmcgYSBkaXJlY3RpdmUgZnJvbSB0aGUgZGVmYXVsdCB2aWV3JywgKCkgPT4ge1xuICAgICAgICB2aWV3UmVzb2x2ZXIub3ZlcnJpZGVWaWV3RGlyZWN0aXZlKFNvbWVDb21wb25lbnQsIFNvbWVEaXJlY3RpdmUsIFNvbWVPdGhlckRpcmVjdGl2ZSk7XG4gICAgICAgIHZhciB2aWV3ID0gdmlld1Jlc29sdmVyLnJlc29sdmUoU29tZUNvbXBvbmVudCk7XG4gICAgICAgIGV4cGVjdCh2aWV3LmRpcmVjdGl2ZXMubGVuZ3RoKS50b0VxdWFsKDEpO1xuICAgICAgICBleHBlY3Qodmlldy5kaXJlY3RpdmVzWzBdKS50b0JlKFNvbWVPdGhlckRpcmVjdGl2ZSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBhbGxvdyBvdmVycmlkaW5nIGEgZGlyZWN0aXZlIGZyb20gYW4gb3ZlcnJpZGRlbiBAVmlldycsICgpID0+IHtcbiAgICAgICAgdmlld1Jlc29sdmVyLnNldFZpZXcoU29tZUNvbXBvbmVudCwgbmV3IFZpZXdNZXRhZGF0YSh7ZGlyZWN0aXZlczogW1NvbWVPdGhlckRpcmVjdGl2ZV19KSk7XG4gICAgICAgIHZpZXdSZXNvbHZlci5vdmVycmlkZVZpZXdEaXJlY3RpdmUoU29tZUNvbXBvbmVudCwgU29tZU90aGVyRGlyZWN0aXZlLCBTb21lQ29tcG9uZW50KTtcbiAgICAgICAgdmFyIHZpZXcgPSB2aWV3UmVzb2x2ZXIucmVzb2x2ZShTb21lQ29tcG9uZW50KTtcbiAgICAgICAgZXhwZWN0KHZpZXcuZGlyZWN0aXZlcy5sZW5ndGgpLnRvRXF1YWwoMSk7XG4gICAgICAgIGV4cGVjdCh2aWV3LmRpcmVjdGl2ZXNbMF0pLnRvQmUoU29tZUNvbXBvbmVudCk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCB0aHJvdyB3aGVuIHRoZSBvdmVycmlkZGVuIGRpcmVjdGl2ZSBpcyBub3QgcHJlc2VudCcsICgpID0+IHtcbiAgICAgICAgdmlld1Jlc29sdmVyLm92ZXJyaWRlVmlld0RpcmVjdGl2ZShTb21lQ29tcG9uZW50LCBTb21lT3RoZXJEaXJlY3RpdmUsIFNvbWVEaXJlY3RpdmUpO1xuICAgICAgICBleHBlY3QoKCkgPT4geyB2aWV3UmVzb2x2ZXIucmVzb2x2ZShTb21lQ29tcG9uZW50KTsgfSlcbiAgICAgICAgICAgIC50b1Rocm93RXJyb3IoXG4gICAgICAgICAgICAgICAgYE92ZXJyaWRlbiBkaXJlY3RpdmUgJHtzdHJpbmdpZnkoU29tZU90aGVyRGlyZWN0aXZlKX0gbm90IGZvdW5kIGluIHRoZSB0ZW1wbGF0ZSBvZiAke3N0cmluZ2lmeShTb21lQ29tcG9uZW50KX1gKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIG5vdCBhbGxvdyBvdmVycmlkaW5nIGEgZGlyZWN0aXZlIGFmdGVyIGl0cyB2aWV3IGhhcyBiZWVuIHJlc29sdmVkJywgKCkgPT4ge1xuICAgICAgICB2aWV3UmVzb2x2ZXIucmVzb2x2ZShTb21lQ29tcG9uZW50KTtcbiAgICAgICAgZXhwZWN0KCgpID0+IHtcbiAgICAgICAgICB2aWV3UmVzb2x2ZXIub3ZlcnJpZGVWaWV3RGlyZWN0aXZlKFNvbWVDb21wb25lbnQsIFNvbWVEaXJlY3RpdmUsIFNvbWVPdGhlckRpcmVjdGl2ZSk7XG4gICAgICAgIH0pXG4gICAgICAgICAgICAudG9UaHJvd0Vycm9yKFxuICAgICAgICAgICAgICAgIGBUaGUgY29tcG9uZW50ICR7c3RyaW5naWZ5KFNvbWVDb21wb25lbnQpfSBoYXMgYWxyZWFkeSBiZWVuIGNvbXBpbGVkLCBpdHMgY29uZmlndXJhdGlvbiBjYW4gbm90IGJlIGNoYW5nZWRgKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9KTtcbn1cblxuY2xhc3MgU29tZURpcmVjdGl2ZSB7fVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdjbXAnLFxuICB0ZW1wbGF0ZTogJ3RlbXBsYXRlJyxcbiAgZGlyZWN0aXZlczogW1NvbWVEaXJlY3RpdmVdLFxufSlcbmNsYXNzIFNvbWVDb21wb25lbnQge1xufVxuXG5jbGFzcyBTb21lT3RoZXJEaXJlY3RpdmUge31cbiJdfQ==
 main(); 
