'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var async_1 = require('angular2/src/facade/async');
var lang_1 = require('angular2/src/facade/lang');
var collection_1 = require('angular2/src/facade/collection');
var runtime_metadata_1 = require('angular2/src/compiler/runtime_metadata');
var template_compiler_1 = require('angular2/src/compiler/template_compiler');
var eval_module_1 = require('./eval_module');
var source_module_1 = require('angular2/src/compiler/source_module');
var xhr_1 = require('angular2/src/compiler/xhr');
var spies_1 = require('../core/spies');
var view_1 = require('angular2/src/core/metadata/view');
var change_detection_1 = require('angular2/src/core/change_detection/change_detection');
var core_1 = require('angular2/core');
var test_bindings_1 = require('./test_bindings');
var util_1 = require('angular2/src/compiler/util');
var core_2 = require('angular2/core');
// Attention: This path has to point to this test file!
var THIS_MODULE_ID = 'angular2/test/compiler/template_compiler_spec';
var THIS_MODULE_REF = source_module_1.moduleRef("package:" + THIS_MODULE_ID + util_1.MODULE_SUFFIX);
var REFLECTOR_MODULE_REF = source_module_1.moduleRef("package:angular2/src/core/reflection/reflection" + util_1.MODULE_SUFFIX);
var REFLECTION_CAPS_MODULE_REF = source_module_1.moduleRef("package:angular2/src/core/reflection/reflection_capabilities" + util_1.MODULE_SUFFIX);
function main() {
    // Dart's isolate support is broken, and these tests will be obsolote soon with
    // https://github.com/angular/angular/issues/6270
    if (lang_1.IS_DART) {
        return;
    }
    testing_internal_1.describe('TemplateCompiler', function () {
        var compiler;
        var runtimeMetadataResolver;
        testing_internal_1.beforeEachProviders(function () { return test_bindings_1.TEST_PROVIDERS; });
        testing_internal_1.beforeEach(testing_internal_1.inject([template_compiler_1.TemplateCompiler, runtime_metadata_1.RuntimeMetadataResolver], function (_compiler, _runtimeMetadataResolver) {
            compiler = _compiler;
            runtimeMetadataResolver = _runtimeMetadataResolver;
        }));
        testing_internal_1.describe('compile templates', function () {
            function runTests(compile) {
                testing_internal_1.it('should throw for non components', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    async_1.PromiseWrapper.catchError(async_1.PromiseWrapper.wrap(function () { return compile([NonComponent]); }), function (error) {
                        testing_internal_1.expect(error.message)
                            .toEqual("Could not compile '" + lang_1.stringify(NonComponent) + "' because it is not a component.");
                        async.done();
                    });
                }));
                testing_internal_1.it('should compile host components', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile([CompWithBindingsAndStylesAndPipes])
                        .then(function (humanizedView) {
                        testing_internal_1.expect(humanizedView['styles']).toEqual([]);
                        testing_internal_1.expect(humanizedView['elements']).toEqual(['<comp-a>']);
                        testing_internal_1.expect(humanizedView['pipes']).toEqual({});
                        testing_internal_1.expect(humanizedView['cd']).toEqual(['prop(title)=someHostValue']);
                        async.done();
                    });
                }));
                testing_internal_1.it('should compile nested components', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile([CompWithBindingsAndStylesAndPipes])
                        .then(function (humanizedView) {
                        var componentView = humanizedView['componentViews'][0];
                        testing_internal_1.expect(componentView['styles']).toEqual(['div {color: red}']);
                        testing_internal_1.expect(componentView['elements']).toEqual(['<a>']);
                        testing_internal_1.expect(componentView['pipes']).toEqual({ 'uppercase': lang_1.stringify(UpperCasePipe) });
                        testing_internal_1.expect(componentView['cd']).toEqual(['prop(href)=SOMECTXVALUE']);
                        async.done();
                    });
                }));
                testing_internal_1.it('should compile components at various nesting levels', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile([CompWith2NestedComps, Comp1, Comp2])
                        .then(function (humanizedView) {
                        testing_internal_1.expect(humanizedView['elements']).toEqual(['<comp-with-2nested>']);
                        testing_internal_1.expect(humanizedView['componentViews'][0]['elements'])
                            .toEqual(['<comp1>', '<comp2>']);
                        testing_internal_1.expect(humanizedView['componentViews'][0]['componentViews'][0]['elements'])
                            .toEqual(['<a>', '<comp2>']);
                        testing_internal_1.expect(humanizedView['componentViews'][0]['componentViews'][1]['elements'])
                            .toEqual(['<b>']);
                        async.done();
                    });
                }));
                testing_internal_1.it('should compile recursive components', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile([TreeComp])
                        .then(function (humanizedView) {
                        testing_internal_1.expect(humanizedView['elements']).toEqual(['<tree>']);
                        testing_internal_1.expect(humanizedView['componentViews'][0]['embeddedViews'][0]['elements'])
                            .toEqual(['<tree>']);
                        testing_internal_1.expect(humanizedView['componentViews'][0]['embeddedViews'][0]['componentViews'][0]['embeddedViews'][0]['elements'])
                            .toEqual(['<tree>']);
                        async.done();
                    });
                }));
                testing_internal_1.it('should compile embedded templates', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile([CompWithEmbeddedTemplate])
                        .then(function (humanizedView) {
                        var embeddedView = humanizedView['componentViews'][0]['embeddedViews'][0];
                        testing_internal_1.expect(embeddedView['elements']).toEqual(['<a>']);
                        testing_internal_1.expect(embeddedView['cd']).toEqual(['prop(href)=someEmbeddedValue']);
                        async.done();
                    });
                }));
                testing_internal_1.it('should dedup directives', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile([CompWithDupDirectives, TreeComp])
                        .then(function (humanizedView) {
                        testing_internal_1.expect(humanizedView['componentViews'][0]['componentViews'].length).toBe(1);
                        async.done();
                    });
                }));
            }
            testing_internal_1.describe('compileHostComponentRuntime', function () {
                function compile(components) {
                    return compiler.compileHostComponentRuntime(components[0])
                        .then(function (compiledHostTemplate) {
                        return humanizeViewFactory(compiledHostTemplate.viewFactory);
                    });
                }
                testing_internal_1.describe('no jit', function () {
                    testing_internal_1.beforeEachProviders(function () { return [
                        core_1.provide(change_detection_1.ChangeDetectorGenConfig, { useValue: new change_detection_1.ChangeDetectorGenConfig(true, false, false) })
                    ]; });
                    runTests(compile);
                });
                testing_internal_1.describe('jit', function () {
                    testing_internal_1.beforeEachProviders(function () { return [
                        core_1.provide(change_detection_1.ChangeDetectorGenConfig, { useValue: new change_detection_1.ChangeDetectorGenConfig(true, false, true) })
                    ]; });
                    runTests(compile);
                });
                testing_internal_1.it('should cache components for parallel requests', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter, xhr_1.XHR], function (async, xhr) {
                    // Expecting only one xhr...
                    xhr.expect('package:angular2/test/compiler/compUrl.html', '<a></a>');
                    async_1.PromiseWrapper.all([compile([CompWithTemplateUrl]), compile([CompWithTemplateUrl])])
                        .then(function (humanizedViews) {
                        testing_internal_1.expect(humanizedViews[0]['componentViews'][0]['elements']).toEqual(['<a>']);
                        testing_internal_1.expect(humanizedViews[1]['componentViews'][0]['elements']).toEqual(['<a>']);
                        async.done();
                    });
                    xhr.flush();
                }));
                testing_internal_1.it('should cache components for sequential requests', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter, xhr_1.XHR], function (async, xhr) {
                    // Expecting only one xhr...
                    xhr.expect('package:angular2/test/compiler/compUrl.html', '<a>');
                    compile([CompWithTemplateUrl])
                        .then(function (humanizedView0) {
                        return compile([CompWithTemplateUrl])
                            .then(function (humanizedView1) {
                            testing_internal_1.expect(humanizedView0['componentViews'][0]['elements']).toEqual(['<a>']);
                            testing_internal_1.expect(humanizedView1['componentViews'][0]['elements']).toEqual(['<a>']);
                            async.done();
                        });
                    });
                    xhr.flush();
                }));
                testing_internal_1.it('should allow to clear the cache', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter, xhr_1.XHR], function (async, xhr) {
                    xhr.expect('package:angular2/test/compiler/compUrl.html', '<a>');
                    compile([CompWithTemplateUrl])
                        .then(function (humanizedView) {
                        compiler.clearCache();
                        xhr.expect('package:angular2/test/compiler/compUrl.html', '<b>');
                        var result = compile([CompWithTemplateUrl]);
                        xhr.flush();
                        return result;
                    })
                        .then(function (humanizedView) {
                        testing_internal_1.expect(humanizedView['componentViews'][0]['elements']).toEqual(['<b>']);
                        async.done();
                    });
                    xhr.flush();
                }));
            });
            testing_internal_1.describe('compileTemplatesCodeGen', function () {
                function normalizeComponent(component) {
                    var compAndViewDirMetas = [runtimeMetadataResolver.getDirectiveMetadata(component)].concat(runtimeMetadataResolver.getViewDirectivesMetadata(component));
                    var upperCasePipeMeta = runtimeMetadataResolver.getPipeMetadata(UpperCasePipe);
                    upperCasePipeMeta.type.moduleUrl = "package:" + THIS_MODULE_ID + util_1.MODULE_SUFFIX;
                    return async_1.PromiseWrapper.all(compAndViewDirMetas.map(function (meta) { return compiler.normalizeDirectiveMetadata(meta); }))
                        .then(function (normalizedCompAndViewDirMetas) {
                        return new template_compiler_1.NormalizedComponentWithViewDirectives(normalizedCompAndViewDirMetas[0], normalizedCompAndViewDirMetas.slice(1), [upperCasePipeMeta]);
                    });
                }
                function compile(components) {
                    return async_1.PromiseWrapper.all(components.map(normalizeComponent))
                        .then(function (normalizedCompWithViewDirMetas) {
                        var sourceModule = compiler.compileTemplatesCodeGen(normalizedCompWithViewDirMetas);
                        var sourceWithImports = testableTemplateModule(sourceModule, normalizedCompWithViewDirMetas[0].component)
                            .getSourceWithImports();
                        return eval_module_1.evalModule(sourceWithImports.source, sourceWithImports.imports, null);
                    });
                }
                runTests(compile);
            });
        });
        testing_internal_1.describe('normalizeDirectiveMetadata', function () {
            testing_internal_1.it('should return the given DirectiveMetadata for non components', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                var meta = runtimeMetadataResolver.getDirectiveMetadata(NonComponent);
                compiler.normalizeDirectiveMetadata(meta).then(function (normMeta) {
                    testing_internal_1.expect(normMeta).toBe(meta);
                    async.done();
                });
            }));
            testing_internal_1.it('should normalize the template', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter, xhr_1.XHR], function (async, xhr) {
                xhr.expect('package:angular2/test/compiler/compUrl.html', 'loadedTemplate');
                compiler.normalizeDirectiveMetadata(runtimeMetadataResolver.getDirectiveMetadata(CompWithTemplateUrl))
                    .then(function (meta) {
                    testing_internal_1.expect(meta.template.template).toEqual('loadedTemplate');
                    async.done();
                });
                xhr.flush();
            }));
            testing_internal_1.it('should copy all the other fields', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                var meta = runtimeMetadataResolver.getDirectiveMetadata(CompWithBindingsAndStylesAndPipes);
                compiler.normalizeDirectiveMetadata(meta).then(function (normMeta) {
                    testing_internal_1.expect(normMeta.type).toEqual(meta.type);
                    testing_internal_1.expect(normMeta.isComponent).toEqual(meta.isComponent);
                    testing_internal_1.expect(normMeta.dynamicLoadable).toEqual(meta.dynamicLoadable);
                    testing_internal_1.expect(normMeta.selector).toEqual(meta.selector);
                    testing_internal_1.expect(normMeta.exportAs).toEqual(meta.exportAs);
                    testing_internal_1.expect(normMeta.changeDetection).toEqual(meta.changeDetection);
                    testing_internal_1.expect(normMeta.inputs).toEqual(meta.inputs);
                    testing_internal_1.expect(normMeta.outputs).toEqual(meta.outputs);
                    testing_internal_1.expect(normMeta.hostListeners).toEqual(meta.hostListeners);
                    testing_internal_1.expect(normMeta.hostProperties).toEqual(meta.hostProperties);
                    testing_internal_1.expect(normMeta.hostAttributes).toEqual(meta.hostAttributes);
                    testing_internal_1.expect(normMeta.lifecycleHooks).toEqual(meta.lifecycleHooks);
                    async.done();
                });
            }));
        });
        testing_internal_1.describe('compileStylesheetCodeGen', function () {
            testing_internal_1.it('should compile stylesheets into code', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                var cssText = 'div {color: red}';
                var sourceModule = compiler.compileStylesheetCodeGen('package:someModuleUrl', cssText)[0];
                var sourceWithImports = testableStylesModule(sourceModule).getSourceWithImports();
                eval_module_1.evalModule(sourceWithImports.source, sourceWithImports.imports, null)
                    .then(function (loadedCssText) {
                    testing_internal_1.expect(loadedCssText).toEqual([cssText]);
                    async.done();
                });
            }));
        });
    });
}
exports.main = main;
var UpperCasePipe = (function () {
    function UpperCasePipe() {
    }
    UpperCasePipe.prototype.transform = function (value, args) {
        if (args === void 0) { args = null; }
        return value.toUpperCase();
    };
    UpperCasePipe = __decorate([
        core_2.Pipe({ name: 'uppercase' }),
        core_2.Injectable(), 
        __metadata('design:paramtypes', [])
    ], UpperCasePipe);
    return UpperCasePipe;
})();
exports.UpperCasePipe = UpperCasePipe;
var CompWithBindingsAndStylesAndPipes = (function () {
    function CompWithBindingsAndStylesAndPipes() {
    }
    CompWithBindingsAndStylesAndPipes = __decorate([
        core_1.Component({
            selector: 'comp-a',
            host: { '[title]': '\'someHostValue\'' },
            moduleId: THIS_MODULE_ID,
            exportAs: 'someExportAs',
            template: '<a [href]="\'someCtxValue\' | uppercase"></a>',
            styles: ['div {color: red}'],
            encapsulation: view_1.ViewEncapsulation.None,
            pipes: [UpperCasePipe]
        }), 
        __metadata('design:paramtypes', [])
    ], CompWithBindingsAndStylesAndPipes);
    return CompWithBindingsAndStylesAndPipes;
})();
exports.CompWithBindingsAndStylesAndPipes = CompWithBindingsAndStylesAndPipes;
var TreeComp = (function () {
    function TreeComp() {
    }
    TreeComp = __decorate([
        core_1.Component({
            selector: 'tree',
            moduleId: THIS_MODULE_ID,
            template: '<template><tree></tree></template>',
            directives: [TreeComp],
            encapsulation: view_1.ViewEncapsulation.None
        }), 
        __metadata('design:paramtypes', [])
    ], TreeComp);
    return TreeComp;
})();
exports.TreeComp = TreeComp;
var CompWithDupDirectives = (function () {
    function CompWithDupDirectives() {
    }
    CompWithDupDirectives = __decorate([
        core_1.Component({
            selector: 'comp-wit-dup-tpl',
            moduleId: THIS_MODULE_ID,
            template: '<tree></tree>',
            directives: [TreeComp, TreeComp],
            encapsulation: view_1.ViewEncapsulation.None
        }), 
        __metadata('design:paramtypes', [])
    ], CompWithDupDirectives);
    return CompWithDupDirectives;
})();
exports.CompWithDupDirectives = CompWithDupDirectives;
var CompWithTemplateUrl = (function () {
    function CompWithTemplateUrl() {
    }
    CompWithTemplateUrl = __decorate([
        core_1.Component({
            selector: 'comp-url',
            moduleId: THIS_MODULE_ID,
            templateUrl: 'compUrl.html',
            encapsulation: view_1.ViewEncapsulation.None
        }), 
        __metadata('design:paramtypes', [])
    ], CompWithTemplateUrl);
    return CompWithTemplateUrl;
})();
exports.CompWithTemplateUrl = CompWithTemplateUrl;
var CompWithEmbeddedTemplate = (function () {
    function CompWithEmbeddedTemplate() {
    }
    CompWithEmbeddedTemplate = __decorate([
        core_1.Component({
            selector: 'comp-tpl',
            moduleId: THIS_MODULE_ID,
            template: '<template><a [href]="\'someEmbeddedValue\'"></a></template>',
            encapsulation: view_1.ViewEncapsulation.None
        }), 
        __metadata('design:paramtypes', [])
    ], CompWithEmbeddedTemplate);
    return CompWithEmbeddedTemplate;
})();
exports.CompWithEmbeddedTemplate = CompWithEmbeddedTemplate;
var NonComponent = (function () {
    function NonComponent() {
    }
    NonComponent = __decorate([
        core_1.Directive({ selector: 'plain' }), 
        __metadata('design:paramtypes', [])
    ], NonComponent);
    return NonComponent;
})();
exports.NonComponent = NonComponent;
var Comp2 = (function () {
    function Comp2() {
    }
    Comp2 = __decorate([
        core_1.Component({
            selector: 'comp2',
            moduleId: THIS_MODULE_ID,
            template: '<b></b>',
            encapsulation: view_1.ViewEncapsulation.None
        }), 
        __metadata('design:paramtypes', [])
    ], Comp2);
    return Comp2;
})();
exports.Comp2 = Comp2;
var Comp1 = (function () {
    function Comp1() {
    }
    Comp1 = __decorate([
        core_1.Component({
            selector: 'comp1',
            moduleId: THIS_MODULE_ID,
            template: '<a></a>, <comp2></comp2>',
            encapsulation: view_1.ViewEncapsulation.None,
            directives: [Comp2]
        }), 
        __metadata('design:paramtypes', [])
    ], Comp1);
    return Comp1;
})();
exports.Comp1 = Comp1;
var CompWith2NestedComps = (function () {
    function CompWith2NestedComps() {
    }
    CompWith2NestedComps = __decorate([
        core_1.Component({
            selector: 'comp-with-2nested',
            moduleId: THIS_MODULE_ID,
            template: '<comp1></comp1>, <comp2></comp2>',
            encapsulation: view_1.ViewEncapsulation.None,
            directives: [Comp1, Comp2]
        }), 
        __metadata('design:paramtypes', [])
    ], CompWith2NestedComps);
    return CompWith2NestedComps;
})();
exports.CompWith2NestedComps = CompWith2NestedComps;
function testableTemplateModule(sourceModule, normComp) {
    var testableSource = "\n  " + sourceModule.sourceWithModuleRefs + "\n  " + util_1.codeGenFnHeader(['_'], '_run') + "{\n    " + REFLECTOR_MODULE_REF + "reflector.reflectionCapabilities = new " + REFLECTION_CAPS_MODULE_REF + "ReflectionCapabilities();\n    return " + THIS_MODULE_REF + "humanizeViewFactory(hostViewFactory_" + normComp.type.name + ".viewFactory);\n  }\n  " + util_1.codeGenExportVariable('run') + "_run;";
    return new source_module_1.SourceModule(sourceModule.moduleUrl, testableSource);
}
function testableStylesModule(sourceModule) {
    var testableSource = sourceModule.sourceWithModuleRefs + "\n  " + util_1.codeGenValueFn(['_'], 'STYLES', '_run') + ";\n  " + util_1.codeGenExportVariable('run') + "_run;";
    return new source_module_1.SourceModule(sourceModule.moduleUrl, testableSource);
}
function humanizeView(view, cachedResults) {
    var result = cachedResults.get(view.proto);
    if (lang_1.isPresent(result)) {
        return result;
    }
    result = {};
    // fill the cache early to break cycles.
    cachedResults.set(view.proto, result);
    view.changeDetector.detectChanges();
    var pipes = {};
    if (lang_1.isPresent(view.proto.protoPipes)) {
        collection_1.StringMapWrapper.forEach(view.proto.protoPipes.config, function (pipeProvider, pipeName) {
            pipes[pipeName] = lang_1.stringify(pipeProvider.key.token);
        });
    }
    var componentViews = [];
    var embeddedViews = [];
    view.appElements.forEach(function (appElement) {
        if (lang_1.isPresent(appElement.componentView)) {
            componentViews.push(humanizeView(appElement.componentView, cachedResults));
        }
        else if (lang_1.isPresent(appElement.embeddedViewFactory)) {
            embeddedViews.push(humanizeViewFactory(appElement.embeddedViewFactory, appElement, cachedResults));
        }
    });
    result['styles'] = view.renderer.styles;
    result['elements'] = view.renderer.elements;
    result['pipes'] = pipes;
    result['cd'] = view.renderer.props;
    result['componentViews'] = componentViews;
    result['embeddedViews'] = embeddedViews;
    return result;
}
// Attention: read by eval!
function humanizeViewFactory(viewFactory, containerAppElement, cachedResults) {
    if (containerAppElement === void 0) { containerAppElement = null; }
    if (cachedResults === void 0) { cachedResults = null; }
    if (lang_1.isBlank(cachedResults)) {
        cachedResults = new Map();
    }
    var viewManager = new spies_1.SpyAppViewManager();
    viewManager.spy('createRenderComponentType')
        .andCallFake(function (encapsulation, styles) {
        return new core_1.RenderComponentType('someId', encapsulation, styles, null);
    });
    var view = viewFactory(new RecordingRenderer([]), viewManager, containerAppElement, [], null, null, null);
    return humanizeView(view, cachedResults);
}
exports.humanizeViewFactory = humanizeViewFactory;
var RecordingRenderer = (function (_super) {
    __extends(RecordingRenderer, _super);
    function RecordingRenderer(styles) {
        var _this = this;
        _super.call(this);
        this.styles = styles;
        this.props = [];
        this.elements = [];
        this.spy('renderComponent')
            .andCallFake(function (componentProto) { return new RecordingRenderer(componentProto.styles); });
        this.spy('setElementProperty')
            .andCallFake(function (el, prop, value) { _this.props.push("prop(" + prop + ")=" + value); });
        this.spy('createElement')
            .andCallFake(function (parent, elName) { _this.elements.push("<" + elName + ">"); });
    }
    return RecordingRenderer;
})(spies_1.SpyRenderer);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVtcGxhdGVfY29tcGlsZXJfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29tcGlsZXIvdGVtcGxhdGVfY29tcGlsZXJfc3BlYy50cyJdLCJuYW1lcyI6WyJtYWluIiwibWFpbi5ydW5UZXN0cyIsIm1haW4uY29tcGlsZSIsIm1haW4ubm9ybWFsaXplQ29tcG9uZW50IiwiVXBwZXJDYXNlUGlwZSIsIlVwcGVyQ2FzZVBpcGUuY29uc3RydWN0b3IiLCJVcHBlckNhc2VQaXBlLnRyYW5zZm9ybSIsIkNvbXBXaXRoQmluZGluZ3NBbmRTdHlsZXNBbmRQaXBlcyIsIkNvbXBXaXRoQmluZGluZ3NBbmRTdHlsZXNBbmRQaXBlcy5jb25zdHJ1Y3RvciIsIlRyZWVDb21wIiwiVHJlZUNvbXAuY29uc3RydWN0b3IiLCJDb21wV2l0aER1cERpcmVjdGl2ZXMiLCJDb21wV2l0aER1cERpcmVjdGl2ZXMuY29uc3RydWN0b3IiLCJDb21wV2l0aFRlbXBsYXRlVXJsIiwiQ29tcFdpdGhUZW1wbGF0ZVVybC5jb25zdHJ1Y3RvciIsIkNvbXBXaXRoRW1iZWRkZWRUZW1wbGF0ZSIsIkNvbXBXaXRoRW1iZWRkZWRUZW1wbGF0ZS5jb25zdHJ1Y3RvciIsIk5vbkNvbXBvbmVudCIsIk5vbkNvbXBvbmVudC5jb25zdHJ1Y3RvciIsIkNvbXAyIiwiQ29tcDIuY29uc3RydWN0b3IiLCJDb21wMSIsIkNvbXAxLmNvbnN0cnVjdG9yIiwiQ29tcFdpdGgyTmVzdGVkQ29tcHMiLCJDb21wV2l0aDJOZXN0ZWRDb21wcy5jb25zdHJ1Y3RvciIsInRlc3RhYmxlVGVtcGxhdGVNb2R1bGUiLCJ0ZXN0YWJsZVN0eWxlc01vZHVsZSIsImh1bWFuaXplVmlldyIsImh1bWFuaXplVmlld0ZhY3RvcnkiLCJSZWNvcmRpbmdSZW5kZXJlciIsIlJlY29yZGluZ1JlbmRlcmVyLmNvbnN0cnVjdG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFBLGlDQWFPLDJCQUEyQixDQUFDLENBQUE7QUFFbkMsc0JBQTZCLDJCQUEyQixDQUFDLENBQUE7QUFDekQscUJBQXFFLDBCQUEwQixDQUFDLENBQUE7QUFDaEcsMkJBS08sZ0NBQWdDLENBQUMsQ0FBQTtBQUN4QyxpQ0FBc0Msd0NBQXdDLENBQUMsQ0FBQTtBQUMvRSxrQ0FHTyx5Q0FBeUMsQ0FBQyxDQUFBO0FBRWpELDRCQUF5QixlQUFlLENBQUMsQ0FBQTtBQUN6Qyw4QkFBc0MscUNBQXFDLENBQUMsQ0FBQTtBQUM1RSxvQkFBa0IsMkJBQTJCLENBQUMsQ0FBQTtBQUU5QyxzQkFBOEQsZUFBZSxDQUFDLENBQUE7QUFDOUUscUJBQWdDLGlDQUFpQyxDQUFDLENBQUE7QUFHbEUsaUNBQThDLHFEQUFxRCxDQUFDLENBQUE7QUFFcEcscUJBQWlFLGVBQWUsQ0FBQyxDQUFBO0FBRWpGLDhCQUE2QixpQkFBaUIsQ0FBQyxDQUFBO0FBQy9DLHFCQUtPLDRCQUE0QixDQUFDLENBQUE7QUFDcEMscUJBQTRELGVBQWUsQ0FBQyxDQUFBO0FBRzVFLHVEQUF1RDtBQUN2RCxJQUFNLGNBQWMsR0FBRywrQ0FBK0MsQ0FBQztBQUN2RSxJQUFJLGVBQWUsR0FBRyx5QkFBUyxDQUFDLGFBQVcsY0FBYyxHQUFHLG9CQUFlLENBQUMsQ0FBQztBQUM3RSxJQUFJLG9CQUFvQixHQUNwQix5QkFBUyxDQUFDLG9EQUFrRCxvQkFBZSxDQUFDLENBQUM7QUFDakYsSUFBSSwwQkFBMEIsR0FDMUIseUJBQVMsQ0FBQyxpRUFBK0Qsb0JBQWUsQ0FBQyxDQUFDO0FBRTlGO0lBQ0VBLCtFQUErRUE7SUFDL0VBLGlEQUFpREE7SUFDakRBLEVBQUVBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLENBQUNBLENBQUNBO1FBQ1pBLE1BQU1BLENBQUNBO0lBQ1RBLENBQUNBO0lBQ0RBLDJCQUFRQSxDQUFDQSxrQkFBa0JBLEVBQUVBO1FBQzNCQSxJQUFJQSxRQUEwQkEsQ0FBQ0E7UUFDL0JBLElBQUlBLHVCQUFnREEsQ0FBQ0E7UUFFckRBLHNDQUFtQkEsQ0FBQ0EsY0FBTUEsT0FBQUEsOEJBQWNBLEVBQWRBLENBQWNBLENBQUNBLENBQUNBO1FBQzFDQSw2QkFBVUEsQ0FBQ0EseUJBQU1BLENBQUNBLENBQUNBLG9DQUFnQkEsRUFBRUEsMENBQXVCQSxDQUFDQSxFQUMzQ0EsVUFBQ0EsU0FBU0EsRUFBRUEsd0JBQXdCQTtZQUNsQ0EsUUFBUUEsR0FBR0EsU0FBU0EsQ0FBQ0E7WUFDckJBLHVCQUF1QkEsR0FBR0Esd0JBQXdCQSxDQUFDQTtRQUNyREEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFdEJBLDJCQUFRQSxDQUFDQSxtQkFBbUJBLEVBQUVBO1lBRTVCQSxrQkFBa0JBLE9BQStDQTtnQkFDL0RDLHFCQUFFQSxDQUFDQSxpQ0FBaUNBLEVBQUVBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO29CQUNwRUEsc0JBQWNBLENBQUNBLFVBQVVBLENBQ3JCQSxzQkFBY0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsY0FBTUEsT0FBQUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0EsRUFBdkJBLENBQXVCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTt3QkFDeERBLHlCQUFNQSxDQUFDQSxLQUFLQSxDQUFDQSxPQUFPQSxDQUFDQTs2QkFDaEJBLE9BQU9BLENBQ0pBLHdCQUFzQkEsZ0JBQVNBLENBQUNBLFlBQVlBLENBQUNBLHFDQUFrQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQ3pGQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtvQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUVQQSxxQkFBRUEsQ0FBQ0EsZ0NBQWdDQSxFQUFFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtvQkFDbkVBLE9BQU9BLENBQUNBLENBQUNBLGlDQUFpQ0EsQ0FBQ0EsQ0FBQ0E7eUJBQ3ZDQSxJQUFJQSxDQUFDQSxVQUFDQSxhQUFhQTt3QkFDbEJBLHlCQUFNQSxDQUFDQSxhQUFhQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTt3QkFDNUNBLHlCQUFNQSxDQUFDQSxhQUFhQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDeERBLHlCQUFNQSxDQUFDQSxhQUFhQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTt3QkFDM0NBLHlCQUFNQSxDQUFDQSxhQUFhQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSwyQkFBMkJBLENBQUNBLENBQUNBLENBQUNBO3dCQUNuRUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7b0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO2dCQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFUEEscUJBQUVBLENBQUNBLGtDQUFrQ0EsRUFBRUEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7b0JBQ3JFQSxPQUFPQSxDQUFDQSxDQUFDQSxpQ0FBaUNBLENBQUNBLENBQUNBO3lCQUN2Q0EsSUFBSUEsQ0FBQ0EsVUFBQ0EsYUFBYUE7d0JBQ2xCQSxJQUFJQSxhQUFhQSxHQUFHQSxhQUFhQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO3dCQUN2REEseUJBQU1BLENBQUNBLGFBQWFBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQzlEQSx5QkFBTUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQ25EQSx5QkFBTUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsRUFBQ0EsV0FBV0EsRUFBRUEsZ0JBQVNBLENBQUNBLGFBQWFBLENBQUNBLEVBQUNBLENBQUNBLENBQUNBO3dCQUNoRkEseUJBQU1BLENBQUNBLGFBQWFBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLHlCQUF5QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBRWpFQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtvQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUVQQSxxQkFBRUEsQ0FBQ0EscURBQXFEQSxFQUNyREEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7b0JBQ2pDQSxPQUFPQSxDQUFDQSxDQUFDQSxvQkFBb0JBLEVBQUVBLEtBQUtBLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBO3lCQUN4Q0EsSUFBSUEsQ0FBQ0EsVUFBQ0EsYUFBYUE7d0JBQ2xCQSx5QkFBTUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDbkVBLHlCQUFNQSxDQUFDQSxhQUFhQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBOzZCQUNqREEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsU0FBU0EsRUFBRUEsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQ3JDQSx5QkFBTUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBOzZCQUN0RUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsRUFBRUEsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQ2pDQSx5QkFBTUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBOzZCQUN0RUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBRXRCQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtvQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUVQQSxxQkFBRUEsQ0FBQ0EscUNBQXFDQSxFQUFFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtvQkFDeEVBLE9BQU9BLENBQUNBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBO3lCQUNkQSxJQUFJQSxDQUFDQSxVQUFDQSxhQUFhQTt3QkFDbEJBLHlCQUFNQSxDQUFDQSxhQUFhQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDdERBLHlCQUFNQSxDQUFDQSxhQUFhQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLGVBQWVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBOzZCQUNyRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQ3pCQSx5QkFBTUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQzFEQSxDQUFDQSxDQUFDQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQTs2QkFDbkRBLE9BQU9BLENBQUNBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBO3dCQUV6QkEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7b0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO2dCQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFUEEscUJBQUVBLENBQUNBLG1DQUFtQ0EsRUFBRUEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7b0JBQ3RFQSxPQUFPQSxDQUFDQSxDQUFDQSx3QkFBd0JBLENBQUNBLENBQUNBO3lCQUM5QkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsYUFBYUE7d0JBQ2xCQSxJQUFJQSxZQUFZQSxHQUFHQSxhQUFhQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLGVBQWVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO3dCQUMxRUEseUJBQU1BLENBQUNBLFlBQVlBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBO3dCQUNsREEseUJBQU1BLENBQUNBLFlBQVlBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLDhCQUE4QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBRXJFQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtvQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUVQQSxxQkFBRUEsQ0FBQ0EseUJBQXlCQSxFQUFFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtvQkFDNURBLE9BQU9BLENBQUNBLENBQUNBLHFCQUFxQkEsRUFBRUEsUUFBUUEsQ0FBQ0EsQ0FBQ0E7eUJBQ3JDQSxJQUFJQSxDQUFDQSxVQUFDQSxhQUFhQTt3QkFDbEJBLHlCQUFNQSxDQUFDQSxhQUFhQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQzVFQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtvQkFFZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBO1lBRURELDJCQUFRQSxDQUFDQSw2QkFBNkJBLEVBQUVBO2dCQUN0Q0EsaUJBQWlCQSxVQUFrQkE7b0JBQ2pDRSxNQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSwyQkFBMkJBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO3lCQUNyREEsSUFBSUEsQ0FBQ0EsVUFBQ0Esb0JBQW9CQTsrQkFDakJBLG1CQUFtQkEsQ0FBQ0Esb0JBQW9CQSxDQUFDQSxXQUFXQSxDQUFDQTtvQkFBckRBLENBQXFEQSxDQUFDQSxDQUFDQTtnQkFDdkVBLENBQUNBO2dCQUVERiwyQkFBUUEsQ0FBQ0EsUUFBUUEsRUFBRUE7b0JBQ2pCQSxzQ0FBbUJBLENBQUNBLGNBQU1BLE9BQUFBO3dCQUN4QkEsY0FBT0EsQ0FBQ0EsMENBQXVCQSxFQUN2QkEsRUFBQ0EsUUFBUUEsRUFBRUEsSUFBSUEsMENBQXVCQSxDQUFDQSxJQUFJQSxFQUFFQSxLQUFLQSxFQUFFQSxLQUFLQSxDQUFDQSxFQUFDQSxDQUFDQTtxQkFDckVBLEVBSHlCQSxDQUd6QkEsQ0FBQ0EsQ0FBQ0E7b0JBQ0hBLFFBQVFBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO2dCQUNwQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRUhBLDJCQUFRQSxDQUFDQSxLQUFLQSxFQUFFQTtvQkFDZEEsc0NBQW1CQSxDQUFDQSxjQUFNQSxPQUFBQTt3QkFDeEJBLGNBQU9BLENBQUNBLDBDQUF1QkEsRUFDdkJBLEVBQUNBLFFBQVFBLEVBQUVBLElBQUlBLDBDQUF1QkEsQ0FBQ0EsSUFBSUEsRUFBRUEsS0FBS0EsRUFBRUEsSUFBSUEsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7cUJBQ3BFQSxFQUh5QkEsQ0FHekJBLENBQUNBLENBQUNBO29CQUNIQSxRQUFRQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtnQkFDcEJBLENBQUNBLENBQUNBLENBQUNBO2dCQUVIQSxxQkFBRUEsQ0FBQ0EsK0NBQStDQSxFQUMvQ0EseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsRUFBRUEsU0FBR0EsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0EsRUFBRUEsR0FBWUE7b0JBQ3BEQSw0QkFBNEJBO29CQUM1QkEsR0FBR0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsNkNBQTZDQSxFQUFFQSxTQUFTQSxDQUFDQSxDQUFDQTtvQkFDckVBLHNCQUFjQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxtQkFBbUJBLENBQUNBLENBQUNBLEVBQUVBLE9BQU9BLENBQUNBLENBQUNBLG1CQUFtQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7eUJBQy9FQSxJQUFJQSxDQUFDQSxVQUFDQSxjQUFjQTt3QkFDbkJBLHlCQUFNQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBO3dCQUM1RUEseUJBQU1BLENBQUNBLGNBQWNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBRTVFQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtvQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ1BBLEdBQUdBLENBQUNBLEtBQUtBLEVBQUVBLENBQUNBO2dCQUNkQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFUEEscUJBQUVBLENBQUNBLGlEQUFpREEsRUFDakRBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLEVBQUVBLFNBQUdBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBLEVBQUVBLEdBQVlBO29CQUNwREEsNEJBQTRCQTtvQkFDNUJBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLDZDQUE2Q0EsRUFBRUEsS0FBS0EsQ0FBQ0EsQ0FBQ0E7b0JBQ2pFQSxPQUFPQSxDQUFDQSxDQUFDQSxtQkFBbUJBLENBQUNBLENBQUNBO3lCQUN6QkEsSUFBSUEsQ0FBQ0EsVUFBQ0EsY0FBY0E7d0JBQ25CQSxNQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxtQkFBbUJBLENBQUNBLENBQUNBOzZCQUNoQ0EsSUFBSUEsQ0FBQ0EsVUFBQ0EsY0FBY0E7NEJBQ25CQSx5QkFBTUEsQ0FBQ0EsY0FBY0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxDQUFDQTs0QkFDekVBLHlCQUFNQSxDQUFDQSxjQUFjQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBOzRCQUN6RUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7d0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO29CQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDUEEsR0FBR0EsQ0FBQ0EsS0FBS0EsRUFBRUEsQ0FBQ0E7Z0JBQ2RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUVQQSxxQkFBRUEsQ0FBQ0EsaUNBQWlDQSxFQUNqQ0EseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsRUFBRUEsU0FBR0EsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0EsRUFBRUEsR0FBWUE7b0JBQ3BEQSxHQUFHQSxDQUFDQSxNQUFNQSxDQUFDQSw2Q0FBNkNBLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBO29CQUNqRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxDQUFDQTt5QkFDekJBLElBQUlBLENBQUNBLFVBQUNBLGFBQWFBO3dCQUNsQkEsUUFBUUEsQ0FBQ0EsVUFBVUEsRUFBRUEsQ0FBQ0E7d0JBQ3RCQSxHQUFHQSxDQUFDQSxNQUFNQSxDQUFDQSw2Q0FBNkNBLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBO3dCQUNqRUEsSUFBSUEsTUFBTUEsR0FBR0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDNUNBLEdBQUdBLENBQUNBLEtBQUtBLEVBQUVBLENBQUNBO3dCQUNaQSxNQUFNQSxDQUFDQSxNQUFNQSxDQUFDQTtvQkFDaEJBLENBQUNBLENBQUNBO3lCQUNEQSxJQUFJQSxDQUFDQSxVQUFDQSxhQUFhQTt3QkFDbEJBLHlCQUFNQSxDQUFDQSxhQUFhQSxDQUFDQSxnQkFBZ0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBO3dCQUN4RUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7b0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO29CQUNQQSxHQUFHQSxDQUFDQSxLQUFLQSxFQUFFQSxDQUFDQTtnQkFDZEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEsMkJBQVFBLENBQUNBLHlCQUF5QkEsRUFBRUE7Z0JBQ2xDQSw0QkFDSUEsU0FBZUE7b0JBQ2pCRyxJQUFJQSxtQkFBbUJBLEdBQ25CQSxDQUFDQSx1QkFBdUJBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsQ0FDNURBLHVCQUF1QkEsQ0FBQ0EseUJBQXlCQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDdEVBLElBQUlBLGlCQUFpQkEsR0FBR0EsdUJBQXVCQSxDQUFDQSxlQUFlQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtvQkFDL0VBLGlCQUFpQkEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsU0FBU0EsR0FBR0EsYUFBV0EsY0FBY0EsR0FBR0Esb0JBQWVBLENBQUNBO29CQUMvRUEsTUFBTUEsQ0FBQ0Esc0JBQWNBLENBQUNBLEdBQUdBLENBQUNBLG1CQUFtQkEsQ0FBQ0EsR0FBR0EsQ0FDbkJBLFVBQUFBLElBQUlBLElBQUlBLE9BQUFBLFFBQVFBLENBQUNBLDBCQUEwQkEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsRUFBekNBLENBQXlDQSxDQUFDQSxDQUFDQTt5QkFDNUVBLElBQUlBLENBQUNBLFVBQUNBLDZCQUF5REE7K0JBQ3REQSxJQUFJQSx5REFBcUNBLENBQ3JDQSw2QkFBNkJBLENBQUNBLENBQUNBLENBQUNBLEVBQ2hDQSw2QkFBNkJBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0E7b0JBRmhFQSxDQUVnRUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ2xGQSxDQUFDQTtnQkFFREgsaUJBQWlCQSxVQUFrQkE7b0JBQ2pDRSxNQUFNQSxDQUFDQSxzQkFBY0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsVUFBVUEsQ0FBQ0EsR0FBR0EsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxDQUFDQTt5QkFDeERBLElBQUlBLENBQUNBLFVBQUNBLDhCQUF1RUE7d0JBQzVFQSxJQUFJQSxZQUFZQSxHQUFHQSxRQUFRQSxDQUFDQSx1QkFBdUJBLENBQUNBLDhCQUE4QkEsQ0FBQ0EsQ0FBQ0E7d0JBQ3BGQSxJQUFJQSxpQkFBaUJBLEdBQ2pCQSxzQkFBc0JBLENBQUNBLFlBQVlBLEVBQ1pBLDhCQUE4QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsU0FBU0EsQ0FBQ0E7NkJBQzlEQSxvQkFBb0JBLEVBQUVBLENBQUNBO3dCQUNoQ0EsTUFBTUEsQ0FBQ0Esd0JBQVVBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsTUFBTUEsRUFBRUEsaUJBQWlCQSxDQUFDQSxPQUFPQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtvQkFDL0VBLENBQUNBLENBQUNBLENBQUNBO2dCQUNUQSxDQUFDQTtnQkFFREYsUUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7WUFDcEJBLENBQUNBLENBQUNBLENBQUNBO1FBRUxBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLDJCQUFRQSxDQUFDQSw0QkFBNEJBLEVBQUVBO1lBQ3JDQSxxQkFBRUEsQ0FBQ0EsOERBQThEQSxFQUM5REEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7Z0JBQ2pDQSxJQUFJQSxJQUFJQSxHQUFHQSx1QkFBdUJBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3RFQSxRQUFRQSxDQUFDQSwwQkFBMEJBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLFVBQUFBLFFBQVFBO29CQUNyREEseUJBQU1BLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO29CQUM1QkEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ0xBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSwrQkFBK0JBLEVBQy9CQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxFQUFFQSxTQUFHQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQSxFQUFFQSxHQUFZQTtnQkFDcERBLEdBQUdBLENBQUNBLE1BQU1BLENBQUNBLDZDQUE2Q0EsRUFBRUEsZ0JBQWdCQSxDQUFDQSxDQUFDQTtnQkFDNUVBLFFBQVFBLENBQUNBLDBCQUEwQkEsQ0FDdkJBLHVCQUF1QkEsQ0FBQ0Esb0JBQW9CQSxDQUFDQSxtQkFBbUJBLENBQUNBLENBQUNBO3FCQUN6RUEsSUFBSUEsQ0FBQ0EsVUFBQ0EsSUFBOEJBO29CQUNuQ0EseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFFBQVFBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0E7b0JBQ3pEQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ1BBLEdBQUdBLENBQUNBLEtBQUtBLEVBQUVBLENBQUNBO1lBQ2RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSxrQ0FBa0NBLEVBQUVBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO2dCQUNyRUEsSUFBSUEsSUFBSUEsR0FDSkEsdUJBQXVCQSxDQUFDQSxvQkFBb0JBLENBQUNBLGlDQUFpQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3BGQSxRQUFRQSxDQUFDQSwwQkFBMEJBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLFVBQUNBLFFBQWtDQTtvQkFDaEZBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtvQkFDekNBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQTtvQkFDdkRBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQTtvQkFDL0RBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtvQkFDakRBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtvQkFDakRBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQTtvQkFDL0RBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTtvQkFDN0NBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtvQkFDL0NBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtvQkFDM0RBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQTtvQkFDN0RBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQTtvQkFDN0RBLHlCQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQTtvQkFDN0RBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNMQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsMEJBQTBCQSxFQUFFQTtZQUNuQ0EscUJBQUVBLENBQUNBLHNDQUFzQ0EsRUFBRUEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7Z0JBQ3pFQSxJQUFJQSxPQUFPQSxHQUFHQSxrQkFBa0JBLENBQUNBO2dCQUNqQ0EsSUFBSUEsWUFBWUEsR0FDWkEsUUFBUUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSx1QkFBdUJBLEVBQUVBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUMzRUEsSUFBSUEsaUJBQWlCQSxHQUFHQSxvQkFBb0JBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBLG9CQUFvQkEsRUFBRUEsQ0FBQ0E7Z0JBQ2xGQSx3QkFBVUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxNQUFNQSxFQUFFQSxpQkFBaUJBLENBQUNBLE9BQU9BLEVBQUVBLElBQUlBLENBQUNBO3FCQUNoRUEsSUFBSUEsQ0FBQ0EsVUFBQUEsYUFBYUE7b0JBQ2pCQSx5QkFBTUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ3pDQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7QUFDTEEsQ0FBQ0E7QUE1UWUsWUFBSSxPQTRRbkIsQ0FBQTtBQUdEO0lBQUFJO0lBSUFDLENBQUNBO0lBRENELGlDQUFTQSxHQUFUQSxVQUFVQSxLQUFhQSxFQUFFQSxJQUFrQkE7UUFBbEJFLG9CQUFrQkEsR0FBbEJBLFdBQWtCQTtRQUFZQSxNQUFNQSxDQUFDQSxLQUFLQSxDQUFDQSxXQUFXQSxFQUFFQSxDQUFDQTtJQUFDQSxDQUFDQTtJQUh0RkY7UUFBQ0EsV0FBSUEsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsV0FBV0EsRUFBQ0EsQ0FBQ0E7UUFDekJBLGlCQUFVQSxFQUFFQTs7c0JBR1pBO0lBQURBLG9CQUFDQTtBQUFEQSxDQUFDQSxBQUpELElBSUM7QUFGWSxxQkFBYSxnQkFFekIsQ0FBQTtBQUVEO0lBQUFHO0lBV0FDLENBQUNBO0lBWEREO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxRQUFRQTtZQUNsQkEsSUFBSUEsRUFBRUEsRUFBQ0EsU0FBU0EsRUFBRUEsbUJBQW1CQSxFQUFDQTtZQUN0Q0EsUUFBUUEsRUFBRUEsY0FBY0E7WUFDeEJBLFFBQVFBLEVBQUVBLGNBQWNBO1lBQ3hCQSxRQUFRQSxFQUFFQSwrQ0FBK0NBO1lBQ3pEQSxNQUFNQSxFQUFFQSxDQUFDQSxrQkFBa0JBLENBQUNBO1lBQzVCQSxhQUFhQSxFQUFFQSx3QkFBaUJBLENBQUNBLElBQUlBO1lBQ3JDQSxLQUFLQSxFQUFFQSxDQUFDQSxhQUFhQSxDQUFDQTtTQUN2QkEsQ0FBQ0E7OzBDQUVEQTtJQUFEQSx3Q0FBQ0E7QUFBREEsQ0FBQ0EsQUFYRCxJQVdDO0FBRFkseUNBQWlDLG9DQUM3QyxDQUFBO0FBRUQ7SUFBQUU7SUFRQUMsQ0FBQ0E7SUFSREQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLE1BQU1BO1lBQ2hCQSxRQUFRQSxFQUFFQSxjQUFjQTtZQUN4QkEsUUFBUUEsRUFBRUEsb0NBQW9DQTtZQUM5Q0EsVUFBVUEsRUFBRUEsQ0FBQ0EsUUFBUUEsQ0FBQ0E7WUFDdEJBLGFBQWFBLEVBQUVBLHdCQUFpQkEsQ0FBQ0EsSUFBSUE7U0FDdENBLENBQUNBOztpQkFFREE7SUFBREEsZUFBQ0E7QUFBREEsQ0FBQ0EsQUFSRCxJQVFDO0FBRFksZ0JBQVEsV0FDcEIsQ0FBQTtBQUVEO0lBQUFFO0lBUUFDLENBQUNBO0lBUkREO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxrQkFBa0JBO1lBQzVCQSxRQUFRQSxFQUFFQSxjQUFjQTtZQUN4QkEsUUFBUUEsRUFBRUEsZUFBZUE7WUFDekJBLFVBQVVBLEVBQUVBLENBQUNBLFFBQVFBLEVBQUVBLFFBQVFBLENBQUNBO1lBQ2hDQSxhQUFhQSxFQUFFQSx3QkFBaUJBLENBQUNBLElBQUlBO1NBQ3RDQSxDQUFDQTs7OEJBRURBO0lBQURBLDRCQUFDQTtBQUFEQSxDQUFDQSxBQVJELElBUUM7QUFEWSw2QkFBcUIsd0JBQ2pDLENBQUE7QUFFRDtJQUFBRTtJQU9BQyxDQUFDQTtJQVBERDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsVUFBVUE7WUFDcEJBLFFBQVFBLEVBQUVBLGNBQWNBO1lBQ3hCQSxXQUFXQSxFQUFFQSxjQUFjQTtZQUMzQkEsYUFBYUEsRUFBRUEsd0JBQWlCQSxDQUFDQSxJQUFJQTtTQUN0Q0EsQ0FBQ0E7OzRCQUVEQTtJQUFEQSwwQkFBQ0E7QUFBREEsQ0FBQ0EsQUFQRCxJQU9DO0FBRFksMkJBQW1CLHNCQUMvQixDQUFBO0FBRUQ7SUFBQUU7SUFPQUMsQ0FBQ0E7SUFQREQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLFVBQVVBO1lBQ3BCQSxRQUFRQSxFQUFFQSxjQUFjQTtZQUN4QkEsUUFBUUEsRUFBRUEsNkRBQTZEQTtZQUN2RUEsYUFBYUEsRUFBRUEsd0JBQWlCQSxDQUFDQSxJQUFJQTtTQUN0Q0EsQ0FBQ0E7O2lDQUVEQTtJQUFEQSwrQkFBQ0E7QUFBREEsQ0FBQ0EsQUFQRCxJQU9DO0FBRFksZ0NBQXdCLDJCQUNwQyxDQUFBO0FBR0Q7SUFBQUU7SUFFQUMsQ0FBQ0E7SUFGREQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLE9BQU9BLEVBQUNBLENBQUNBOztxQkFFOUJBO0lBQURBLG1CQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUM7QUFEWSxvQkFBWSxlQUN4QixDQUFBO0FBR0Q7SUFBQUU7SUFPQUMsQ0FBQ0E7SUFQREQ7UUFBQ0EsZ0JBQVNBLENBQUNBO1lBQ1RBLFFBQVFBLEVBQUVBLE9BQU9BO1lBQ2pCQSxRQUFRQSxFQUFFQSxjQUFjQTtZQUN4QkEsUUFBUUEsRUFBRUEsU0FBU0E7WUFDbkJBLGFBQWFBLEVBQUVBLHdCQUFpQkEsQ0FBQ0EsSUFBSUE7U0FDdENBLENBQUNBOztjQUVEQTtJQUFEQSxZQUFDQTtBQUFEQSxDQUFDQSxBQVBELElBT0M7QUFEWSxhQUFLLFFBQ2pCLENBQUE7QUFFRDtJQUFBRTtJQVFBQyxDQUFDQTtJQVJERDtRQUFDQSxnQkFBU0EsQ0FBQ0E7WUFDVEEsUUFBUUEsRUFBRUEsT0FBT0E7WUFDakJBLFFBQVFBLEVBQUVBLGNBQWNBO1lBQ3hCQSxRQUFRQSxFQUFFQSwwQkFBMEJBO1lBQ3BDQSxhQUFhQSxFQUFFQSx3QkFBaUJBLENBQUNBLElBQUlBO1lBQ3JDQSxVQUFVQSxFQUFFQSxDQUFDQSxLQUFLQSxDQUFDQTtTQUNwQkEsQ0FBQ0E7O2NBRURBO0lBQURBLFlBQUNBO0FBQURBLENBQUNBLEFBUkQsSUFRQztBQURZLGFBQUssUUFDakIsQ0FBQTtBQUVEO0lBQUFFO0lBUUFDLENBQUNBO0lBUkREO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxtQkFBbUJBO1lBQzdCQSxRQUFRQSxFQUFFQSxjQUFjQTtZQUN4QkEsUUFBUUEsRUFBRUEsa0NBQWtDQTtZQUM1Q0EsYUFBYUEsRUFBRUEsd0JBQWlCQSxDQUFDQSxJQUFJQTtZQUNyQ0EsVUFBVUEsRUFBRUEsQ0FBQ0EsS0FBS0EsRUFBRUEsS0FBS0EsQ0FBQ0E7U0FDM0JBLENBQUNBOzs2QkFFREE7SUFBREEsMkJBQUNBO0FBQURBLENBQUNBLEFBUkQsSUFRQztBQURZLDRCQUFvQix1QkFDaEMsQ0FBQTtBQUVELGdDQUFnQyxZQUEwQixFQUMxQixRQUFrQztJQUNoRUUsSUFBSUEsY0FBY0EsR0FBR0EsU0FDbkJBLFlBQVlBLENBQUNBLG9CQUFvQkEsWUFDakNBLHNCQUFlQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFFQSxNQUFNQSxDQUFDQSxlQUM1QkEsb0JBQW9CQSwrQ0FBMENBLDBCQUEwQkEsOENBQ2pGQSxlQUFlQSw0Q0FBdUNBLFFBQVFBLENBQUNBLElBQUlBLENBQUNBLElBQUlBLCtCQUVqRkEsNEJBQXFCQSxDQUFDQSxLQUFLQSxDQUFDQSxVQUFPQSxDQUFDQTtJQUN0Q0EsTUFBTUEsQ0FBQ0EsSUFBSUEsNEJBQVlBLENBQUNBLFlBQVlBLENBQUNBLFNBQVNBLEVBQUVBLGNBQWNBLENBQUNBLENBQUNBO0FBQ2xFQSxDQUFDQTtBQUVELDhCQUE4QixZQUEwQjtJQUN0REMsSUFBSUEsY0FBY0EsR0FBTUEsWUFBWUEsQ0FBQ0Esb0JBQW9CQSxZQUN2REEscUJBQWNBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLEVBQUVBLFFBQVFBLEVBQUVBLE1BQU1BLENBQUNBLGFBQ3ZDQSw0QkFBcUJBLENBQUNBLEtBQUtBLENBQUNBLFVBQU9BLENBQUNBO0lBQ3RDQSxNQUFNQSxDQUFDQSxJQUFJQSw0QkFBWUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsU0FBU0EsRUFBRUEsY0FBY0EsQ0FBQ0EsQ0FBQ0E7QUFDbEVBLENBQUNBO0FBRUQsc0JBQXNCLElBQWEsRUFBRSxhQUFxQztJQUN4RUMsSUFBSUEsTUFBTUEsR0FBR0EsYUFBYUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0E7SUFDM0NBLEVBQUVBLENBQUNBLENBQUNBLGdCQUFTQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUN0QkEsTUFBTUEsQ0FBQ0EsTUFBTUEsQ0FBQ0E7SUFDaEJBLENBQUNBO0lBQ0RBLE1BQU1BLEdBQUdBLEVBQUVBLENBQUNBO0lBQ1pBLHdDQUF3Q0E7SUFDeENBLGFBQWFBLENBQUNBLEdBQUdBLENBQUNBLElBQUlBLENBQUNBLEtBQUtBLEVBQUVBLE1BQU1BLENBQUNBLENBQUNBO0lBRXRDQSxJQUFJQSxDQUFDQSxjQUFjQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtJQUVwQ0EsSUFBSUEsS0FBS0EsR0FBR0EsRUFBRUEsQ0FBQ0E7SUFDZkEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsZ0JBQVNBLENBQUNBLElBQUlBLENBQUNBLEtBQUtBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ3JDQSw2QkFBZ0JBLENBQUNBLE9BQU9BLENBQUNBLElBQUlBLENBQUNBLEtBQUtBLENBQUNBLFVBQVVBLENBQUNBLE1BQU1BLEVBQUVBLFVBQUNBLFlBQVlBLEVBQUVBLFFBQVFBO1lBQzVFQSxLQUFLQSxDQUFDQSxRQUFRQSxDQUFDQSxHQUFHQSxnQkFBU0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0E7UUFDdERBLENBQUNBLENBQUNBLENBQUNBO0lBQ0xBLENBQUNBO0lBQ0RBLElBQUlBLGNBQWNBLEdBQUdBLEVBQUVBLENBQUNBO0lBQ3hCQSxJQUFJQSxhQUFhQSxHQUFHQSxFQUFFQSxDQUFDQTtJQUV2QkEsSUFBSUEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsVUFBQ0EsVUFBVUE7UUFDbENBLEVBQUVBLENBQUNBLENBQUNBLGdCQUFTQSxDQUFDQSxVQUFVQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUN4Q0EsY0FBY0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsYUFBYUEsRUFBRUEsYUFBYUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDN0VBLENBQUNBO1FBQUNBLElBQUlBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLGdCQUFTQSxDQUFDQSxVQUFVQSxDQUFDQSxtQkFBbUJBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ3JEQSxhQUFhQSxDQUFDQSxJQUFJQSxDQUNkQSxtQkFBbUJBLENBQUNBLFVBQVVBLENBQUNBLG1CQUFtQkEsRUFBRUEsVUFBVUEsRUFBRUEsYUFBYUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDdEZBLENBQUNBO0lBQ0hBLENBQUNBLENBQUNBLENBQUNBO0lBQ0hBLE1BQU1BLENBQUNBLFFBQVFBLENBQUNBLEdBQVNBLElBQUlBLENBQUNBLFFBQVNBLENBQUNBLE1BQU1BLENBQUNBO0lBQy9DQSxNQUFNQSxDQUFDQSxVQUFVQSxDQUFDQSxHQUFTQSxJQUFJQSxDQUFDQSxRQUFTQSxDQUFDQSxRQUFRQSxDQUFDQTtJQUNuREEsTUFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsR0FBR0EsS0FBS0EsQ0FBQ0E7SUFDeEJBLE1BQU1BLENBQUNBLElBQUlBLENBQUNBLEdBQVNBLElBQUlBLENBQUNBLFFBQVNBLENBQUNBLEtBQUtBLENBQUNBO0lBQzFDQSxNQUFNQSxDQUFDQSxnQkFBZ0JBLENBQUNBLEdBQUdBLGNBQWNBLENBQUNBO0lBQzFDQSxNQUFNQSxDQUFDQSxlQUFlQSxDQUFDQSxHQUFHQSxhQUFhQSxDQUFDQTtJQUN4Q0EsTUFBTUEsQ0FBQ0EsTUFBTUEsQ0FBQ0E7QUFDaEJBLENBQUNBO0FBRUQsMkJBQTJCO0FBQzNCLDZCQUNJLFdBQXFCLEVBQUUsbUJBQXNDLEVBQzdELGFBQTRDO0lBRHJCQyxtQ0FBc0NBLEdBQXRDQSwwQkFBc0NBO0lBQzdEQSw2QkFBNENBLEdBQTVDQSxvQkFBNENBO0lBQzlDQSxFQUFFQSxDQUFDQSxDQUFDQSxjQUFPQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUMzQkEsYUFBYUEsR0FBR0EsSUFBSUEsR0FBR0EsRUFBcUJBLENBQUNBO0lBQy9DQSxDQUFDQTtJQUNEQSxJQUFJQSxXQUFXQSxHQUFHQSxJQUFJQSx5QkFBaUJBLEVBQUVBLENBQUNBO0lBQzFDQSxXQUFXQSxDQUFDQSxHQUFHQSxDQUFDQSwyQkFBMkJBLENBQUNBO1NBQ3ZDQSxXQUFXQSxDQUFDQSxVQUFDQSxhQUFnQ0EsRUFBRUEsTUFBNkJBO1FBQzNFQSxNQUFNQSxDQUFDQSxJQUFJQSwwQkFBbUJBLENBQUNBLFFBQVFBLEVBQUVBLGFBQWFBLEVBQUVBLE1BQU1BLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO0lBQ3hFQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUNQQSxJQUFJQSxJQUFJQSxHQUFZQSxXQUFXQSxDQUFDQSxJQUFJQSxpQkFBaUJBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLFdBQVdBLEVBQUVBLG1CQUFtQkEsRUFBRUEsRUFBRUEsRUFDL0RBLElBQUlBLEVBQUVBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO0lBQ2xEQSxNQUFNQSxDQUFDQSxZQUFZQSxDQUFDQSxJQUFJQSxFQUFFQSxhQUFhQSxDQUFDQSxDQUFDQTtBQUMzQ0EsQ0FBQ0E7QUFkZSwyQkFBbUIsc0JBY2xDLENBQUE7QUFFRDtJQUFnQ0MscUNBQVdBO0lBSXpDQSwyQkFBbUJBLE1BQWdCQTtRQUpyQ0MsaUJBYUNBO1FBUkdBLGlCQUFPQSxDQUFDQTtRQURTQSxXQUFNQSxHQUFOQSxNQUFNQSxDQUFVQTtRQUhuQ0EsVUFBS0EsR0FBYUEsRUFBRUEsQ0FBQ0E7UUFDckJBLGFBQVFBLEdBQWFBLEVBQUVBLENBQUNBO1FBSXRCQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxpQkFBaUJBLENBQUNBO2FBQ3RCQSxXQUFXQSxDQUFDQSxVQUFDQSxjQUFjQSxJQUFLQSxPQUFBQSxJQUFJQSxpQkFBaUJBLENBQUNBLGNBQWNBLENBQUNBLE1BQU1BLENBQUNBLEVBQTVDQSxDQUE0Q0EsQ0FBQ0EsQ0FBQ0E7UUFDbkZBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLG9CQUFvQkEsQ0FBQ0E7YUFDekJBLFdBQVdBLENBQUNBLFVBQUNBLEVBQUVBLEVBQUVBLElBQUlBLEVBQUVBLEtBQUtBLElBQU9BLEtBQUlBLENBQUNBLEtBQUtBLENBQUNBLElBQUlBLENBQUNBLFVBQVFBLElBQUlBLFVBQUtBLEtBQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ3RGQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxlQUFlQSxDQUFDQTthQUNwQkEsV0FBV0EsQ0FBQ0EsVUFBQ0EsTUFBTUEsRUFBRUEsTUFBTUEsSUFBT0EsS0FBSUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsTUFBSUEsTUFBTUEsTUFBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDL0VBLENBQUNBO0lBQ0hELHdCQUFDQTtBQUFEQSxDQUFDQSxBQWJELEVBQWdDLG1CQUFXLEVBYTFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgZGRlc2NyaWJlLFxuICBkZXNjcmliZSxcbiAgeGRlc2NyaWJlLFxuICBpdCxcbiAgaWl0LFxuICB4aXQsXG4gIGV4cGVjdCxcbiAgYmVmb3JlRWFjaCxcbiAgYWZ0ZXJFYWNoLFxuICBBc3luY1Rlc3RDb21wbGV0ZXIsXG4gIGluamVjdCxcbiAgYmVmb3JlRWFjaFByb3ZpZGVyc1xufSBmcm9tICdhbmd1bGFyMi90ZXN0aW5nX2ludGVybmFsJztcblxuaW1wb3J0IHtQcm9taXNlV3JhcHBlcn0gZnJvbSAnYW5ndWxhcjIvc3JjL2ZhY2FkZS9hc3luYyc7XG5pbXBvcnQge1R5cGUsIGlzUHJlc2VudCwgaXNCbGFuaywgc3RyaW5naWZ5LCBpc1N0cmluZywgSVNfREFSVH0gZnJvbSAnYW5ndWxhcjIvc3JjL2ZhY2FkZS9sYW5nJztcbmltcG9ydCB7XG4gIE1hcFdyYXBwZXIsXG4gIFNldFdyYXBwZXIsXG4gIExpc3RXcmFwcGVyLFxuICBTdHJpbmdNYXBXcmFwcGVyXG59IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvY29sbGVjdGlvbic7XG5pbXBvcnQge1J1bnRpbWVNZXRhZGF0YVJlc29sdmVyfSBmcm9tICdhbmd1bGFyMi9zcmMvY29tcGlsZXIvcnVudGltZV9tZXRhZGF0YSc7XG5pbXBvcnQge1xuICBUZW1wbGF0ZUNvbXBpbGVyLFxuICBOb3JtYWxpemVkQ29tcG9uZW50V2l0aFZpZXdEaXJlY3RpdmVzXG59IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb21waWxlci90ZW1wbGF0ZV9jb21waWxlcic7XG5pbXBvcnQge0NvbXBpbGVEaXJlY3RpdmVNZXRhZGF0YX0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvbXBpbGVyL2RpcmVjdGl2ZV9tZXRhZGF0YSc7XG5pbXBvcnQge2V2YWxNb2R1bGV9IGZyb20gJy4vZXZhbF9tb2R1bGUnO1xuaW1wb3J0IHtTb3VyY2VNb2R1bGUsIG1vZHVsZVJlZn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvbXBpbGVyL3NvdXJjZV9tb2R1bGUnO1xuaW1wb3J0IHtYSFJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb21waWxlci94aHInO1xuaW1wb3J0IHtNb2NrWEhSfSBmcm9tICdhbmd1bGFyMi9zcmMvY29tcGlsZXIveGhyX21vY2snO1xuaW1wb3J0IHtTcHlSb290UmVuZGVyZXIsIFNweVJlbmRlcmVyLCBTcHlBcHBWaWV3TWFuYWdlcn0gZnJvbSAnLi4vY29yZS9zcGllcyc7XG5pbXBvcnQge1ZpZXdFbmNhcHN1bGF0aW9ufSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9tZXRhZGF0YS92aWV3JztcbmltcG9ydCB7QXBwVmlldywgQXBwUHJvdG9WaWV3fSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9saW5rZXIvdmlldyc7XG5pbXBvcnQge0FwcEVsZW1lbnR9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci9lbGVtZW50JztcbmltcG9ydCB7TG9jYWxzLCBDaGFuZ2VEZXRlY3RvckdlbkNvbmZpZ30gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvY2hhbmdlX2RldGVjdGlvbi9jaGFuZ2VfZGV0ZWN0aW9uJztcblxuaW1wb3J0IHtDb21wb25lbnQsIERpcmVjdGl2ZSwgcHJvdmlkZSwgUmVuZGVyQ29tcG9uZW50VHlwZX0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5cbmltcG9ydCB7VEVTVF9QUk9WSURFUlN9IGZyb20gJy4vdGVzdF9iaW5kaW5ncyc7XG5pbXBvcnQge1xuICBjb2RlR2VuVmFsdWVGbixcbiAgY29kZUdlbkZuSGVhZGVyLFxuICBjb2RlR2VuRXhwb3J0VmFyaWFibGUsXG4gIE1PRFVMRV9TVUZGSVhcbn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvbXBpbGVyL3V0aWwnO1xuaW1wb3J0IHtQaXBlVHJhbnNmb3JtLCBXcmFwcGVkVmFsdWUsIEluamVjdGFibGUsIFBpcGV9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xuXG5cbi8vIEF0dGVudGlvbjogVGhpcyBwYXRoIGhhcyB0byBwb2ludCB0byB0aGlzIHRlc3QgZmlsZSFcbmNvbnN0IFRISVNfTU9EVUxFX0lEID0gJ2FuZ3VsYXIyL3Rlc3QvY29tcGlsZXIvdGVtcGxhdGVfY29tcGlsZXJfc3BlYyc7XG52YXIgVEhJU19NT0RVTEVfUkVGID0gbW9kdWxlUmVmKGBwYWNrYWdlOiR7VEhJU19NT0RVTEVfSUR9JHtNT0RVTEVfU1VGRklYfWApO1xudmFyIFJFRkxFQ1RPUl9NT0RVTEVfUkVGID1cbiAgICBtb2R1bGVSZWYoYHBhY2thZ2U6YW5ndWxhcjIvc3JjL2NvcmUvcmVmbGVjdGlvbi9yZWZsZWN0aW9uJHtNT0RVTEVfU1VGRklYfWApO1xudmFyIFJFRkxFQ1RJT05fQ0FQU19NT0RVTEVfUkVGID1cbiAgICBtb2R1bGVSZWYoYHBhY2thZ2U6YW5ndWxhcjIvc3JjL2NvcmUvcmVmbGVjdGlvbi9yZWZsZWN0aW9uX2NhcGFiaWxpdGllcyR7TU9EVUxFX1NVRkZJWH1gKTtcblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIC8vIERhcnQncyBpc29sYXRlIHN1cHBvcnQgaXMgYnJva2VuLCBhbmQgdGhlc2UgdGVzdHMgd2lsbCBiZSBvYnNvbG90ZSBzb29uIHdpdGhcbiAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2FuZ3VsYXIvYW5ndWxhci9pc3N1ZXMvNjI3MFxuICBpZiAoSVNfREFSVCkge1xuICAgIHJldHVybjtcbiAgfVxuICBkZXNjcmliZSgnVGVtcGxhdGVDb21waWxlcicsICgpID0+IHtcbiAgICB2YXIgY29tcGlsZXI6IFRlbXBsYXRlQ29tcGlsZXI7XG4gICAgdmFyIHJ1bnRpbWVNZXRhZGF0YVJlc29sdmVyOiBSdW50aW1lTWV0YWRhdGFSZXNvbHZlcjtcblxuICAgIGJlZm9yZUVhY2hQcm92aWRlcnMoKCkgPT4gVEVTVF9QUk9WSURFUlMpO1xuICAgIGJlZm9yZUVhY2goaW5qZWN0KFtUZW1wbGF0ZUNvbXBpbGVyLCBSdW50aW1lTWV0YWRhdGFSZXNvbHZlcl0sXG4gICAgICAgICAgICAgICAgICAgICAgKF9jb21waWxlciwgX3J1bnRpbWVNZXRhZGF0YVJlc29sdmVyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb21waWxlciA9IF9jb21waWxlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJ1bnRpbWVNZXRhZGF0YVJlc29sdmVyID0gX3J1bnRpbWVNZXRhZGF0YVJlc29sdmVyO1xuICAgICAgICAgICAgICAgICAgICAgIH0pKTtcblxuICAgIGRlc2NyaWJlKCdjb21waWxlIHRlbXBsYXRlcycsICgpID0+IHtcblxuICAgICAgZnVuY3Rpb24gcnVuVGVzdHMoY29tcGlsZTogKGNvbXBvbmVudHM6IFR5cGVbXSkgPT4gUHJvbWlzZTxhbnlbXT4pIHtcbiAgICAgICAgaXQoJ3Nob3VsZCB0aHJvdyBmb3Igbm9uIGNvbXBvbmVudHMnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICAgIFByb21pc2VXcmFwcGVyLmNhdGNoRXJyb3IoXG4gICAgICAgICAgICAgICAgIFByb21pc2VXcmFwcGVyLndyYXAoKCkgPT4gY29tcGlsZShbTm9uQ29tcG9uZW50XSkpLCAoZXJyb3IpOiBhbnkgPT4ge1xuICAgICAgICAgICAgICAgICAgIGV4cGVjdChlcnJvci5tZXNzYWdlKVxuICAgICAgICAgICAgICAgICAgICAgICAudG9FcXVhbChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGBDb3VsZCBub3QgY29tcGlsZSAnJHtzdHJpbmdpZnkoTm9uQ29tcG9uZW50KX0nIGJlY2F1c2UgaXQgaXMgbm90IGEgY29tcG9uZW50LmApO1xuICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIGNvbXBpbGUgaG9zdCBjb21wb25lbnRzJywgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgICAgICBjb21waWxlKFtDb21wV2l0aEJpbmRpbmdzQW5kU3R5bGVzQW5kUGlwZXNdKVxuICAgICAgICAgICAgICAgICAudGhlbigoaHVtYW5pemVkVmlldykgPT4ge1xuICAgICAgICAgICAgICAgICAgIGV4cGVjdChodW1hbml6ZWRWaWV3WydzdHlsZXMnXSkudG9FcXVhbChbXSk7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGh1bWFuaXplZFZpZXdbJ2VsZW1lbnRzJ10pLnRvRXF1YWwoWyc8Y29tcC1hPiddKTtcbiAgICAgICAgICAgICAgICAgICBleHBlY3QoaHVtYW5pemVkVmlld1sncGlwZXMnXSkudG9FcXVhbCh7fSk7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGh1bWFuaXplZFZpZXdbJ2NkJ10pLnRvRXF1YWwoWydwcm9wKHRpdGxlKT1zb21lSG9zdFZhbHVlJ10pO1xuICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIGNvbXBpbGUgbmVzdGVkIGNvbXBvbmVudHMnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICAgIGNvbXBpbGUoW0NvbXBXaXRoQmluZGluZ3NBbmRTdHlsZXNBbmRQaXBlc10pXG4gICAgICAgICAgICAgICAgIC50aGVuKChodW1hbml6ZWRWaWV3KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgdmFyIGNvbXBvbmVudFZpZXcgPSBodW1hbml6ZWRWaWV3Wydjb21wb25lbnRWaWV3cyddWzBdO1xuICAgICAgICAgICAgICAgICAgIGV4cGVjdChjb21wb25lbnRWaWV3WydzdHlsZXMnXSkudG9FcXVhbChbJ2RpdiB7Y29sb3I6IHJlZH0nXSk7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGNvbXBvbmVudFZpZXdbJ2VsZW1lbnRzJ10pLnRvRXF1YWwoWyc8YT4nXSk7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGNvbXBvbmVudFZpZXdbJ3BpcGVzJ10pLnRvRXF1YWwoeyd1cHBlcmNhc2UnOiBzdHJpbmdpZnkoVXBwZXJDYXNlUGlwZSl9KTtcbiAgICAgICAgICAgICAgICAgICBleHBlY3QoY29tcG9uZW50Vmlld1snY2QnXSkudG9FcXVhbChbJ3Byb3AoaHJlZik9U09NRUNUWFZBTFVFJ10pO1xuXG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIGl0KCdzaG91bGQgY29tcGlsZSBjb21wb25lbnRzIGF0IHZhcmlvdXMgbmVzdGluZyBsZXZlbHMnLFxuICAgICAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICAgIGNvbXBpbGUoW0NvbXBXaXRoMk5lc3RlZENvbXBzLCBDb21wMSwgQ29tcDJdKVxuICAgICAgICAgICAgICAgICAudGhlbigoaHVtYW5pemVkVmlldykgPT4ge1xuICAgICAgICAgICAgICAgICAgIGV4cGVjdChodW1hbml6ZWRWaWV3WydlbGVtZW50cyddKS50b0VxdWFsKFsnPGNvbXAtd2l0aC0ybmVzdGVkPiddKTtcbiAgICAgICAgICAgICAgICAgICBleHBlY3QoaHVtYW5pemVkVmlld1snY29tcG9uZW50Vmlld3MnXVswXVsnZWxlbWVudHMnXSlcbiAgICAgICAgICAgICAgICAgICAgICAgLnRvRXF1YWwoWyc8Y29tcDE+JywgJzxjb21wMj4nXSk7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGh1bWFuaXplZFZpZXdbJ2NvbXBvbmVudFZpZXdzJ11bMF1bJ2NvbXBvbmVudFZpZXdzJ11bMF1bJ2VsZW1lbnRzJ10pXG4gICAgICAgICAgICAgICAgICAgICAgIC50b0VxdWFsKFsnPGE+JywgJzxjb21wMj4nXSk7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGh1bWFuaXplZFZpZXdbJ2NvbXBvbmVudFZpZXdzJ11bMF1bJ2NvbXBvbmVudFZpZXdzJ11bMV1bJ2VsZW1lbnRzJ10pXG4gICAgICAgICAgICAgICAgICAgICAgIC50b0VxdWFsKFsnPGI+J10pO1xuXG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIGl0KCdzaG91bGQgY29tcGlsZSByZWN1cnNpdmUgY29tcG9uZW50cycsIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgY29tcGlsZShbVHJlZUNvbXBdKVxuICAgICAgICAgICAgICAgICAudGhlbigoaHVtYW5pemVkVmlldykgPT4ge1xuICAgICAgICAgICAgICAgICAgIGV4cGVjdChodW1hbml6ZWRWaWV3WydlbGVtZW50cyddKS50b0VxdWFsKFsnPHRyZWU+J10pO1xuICAgICAgICAgICAgICAgICAgIGV4cGVjdChodW1hbml6ZWRWaWV3Wydjb21wb25lbnRWaWV3cyddWzBdWydlbWJlZGRlZFZpZXdzJ11bMF1bJ2VsZW1lbnRzJ10pXG4gICAgICAgICAgICAgICAgICAgICAgIC50b0VxdWFsKFsnPHRyZWU+J10pO1xuICAgICAgICAgICAgICAgICAgIGV4cGVjdChodW1hbml6ZWRWaWV3Wydjb21wb25lbnRWaWV3cyddWzBdWydlbWJlZGRlZFZpZXdzJ11bMF1bJ2NvbXBvbmVudFZpZXdzJ11cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFswXVsnZW1iZWRkZWRWaWV3cyddWzBdWydlbGVtZW50cyddKVxuICAgICAgICAgICAgICAgICAgICAgICAudG9FcXVhbChbJzx0cmVlPiddKTtcblxuICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIGNvbXBpbGUgZW1iZWRkZWQgdGVtcGxhdGVzJywgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgICAgICBjb21waWxlKFtDb21wV2l0aEVtYmVkZGVkVGVtcGxhdGVdKVxuICAgICAgICAgICAgICAgICAudGhlbigoaHVtYW5pemVkVmlldykgPT4ge1xuICAgICAgICAgICAgICAgICAgIHZhciBlbWJlZGRlZFZpZXcgPSBodW1hbml6ZWRWaWV3Wydjb21wb25lbnRWaWV3cyddWzBdWydlbWJlZGRlZFZpZXdzJ11bMF07XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGVtYmVkZGVkVmlld1snZWxlbWVudHMnXSkudG9FcXVhbChbJzxhPiddKTtcbiAgICAgICAgICAgICAgICAgICBleHBlY3QoZW1iZWRkZWRWaWV3WydjZCddKS50b0VxdWFsKFsncHJvcChocmVmKT1zb21lRW1iZWRkZWRWYWx1ZSddKTtcblxuICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIGRlZHVwIGRpcmVjdGl2ZXMnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICAgIGNvbXBpbGUoW0NvbXBXaXRoRHVwRGlyZWN0aXZlcywgVHJlZUNvbXBdKVxuICAgICAgICAgICAgICAgICAudGhlbigoaHVtYW5pemVkVmlldykgPT4ge1xuICAgICAgICAgICAgICAgICAgIGV4cGVjdChodW1hbml6ZWRWaWV3Wydjb21wb25lbnRWaWV3cyddWzBdWydjb21wb25lbnRWaWV3cyddLmxlbmd0aCkudG9CZSgxKTtcbiAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG5cbiAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0pKTtcbiAgICAgIH1cblxuICAgICAgZGVzY3JpYmUoJ2NvbXBpbGVIb3N0Q29tcG9uZW50UnVudGltZScsICgpID0+IHtcbiAgICAgICAgZnVuY3Rpb24gY29tcGlsZShjb21wb25lbnRzOiBUeXBlW10pOiBQcm9taXNlPGFueVtdPiB7XG4gICAgICAgICAgcmV0dXJuIGNvbXBpbGVyLmNvbXBpbGVIb3N0Q29tcG9uZW50UnVudGltZShjb21wb25lbnRzWzBdKVxuICAgICAgICAgICAgICAudGhlbigoY29tcGlsZWRIb3N0VGVtcGxhdGUpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICBodW1hbml6ZVZpZXdGYWN0b3J5KGNvbXBpbGVkSG9zdFRlbXBsYXRlLnZpZXdGYWN0b3J5KSk7XG4gICAgICAgIH1cblxuICAgICAgICBkZXNjcmliZSgnbm8gaml0JywgKCkgPT4ge1xuICAgICAgICAgIGJlZm9yZUVhY2hQcm92aWRlcnMoKCkgPT4gW1xuICAgICAgICAgICAgcHJvdmlkZShDaGFuZ2VEZXRlY3RvckdlbkNvbmZpZyxcbiAgICAgICAgICAgICAgICAgICAge3VzZVZhbHVlOiBuZXcgQ2hhbmdlRGV0ZWN0b3JHZW5Db25maWcodHJ1ZSwgZmFsc2UsIGZhbHNlKX0pXG4gICAgICAgICAgXSk7XG4gICAgICAgICAgcnVuVGVzdHMoY29tcGlsZSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGRlc2NyaWJlKCdqaXQnLCAoKSA9PiB7XG4gICAgICAgICAgYmVmb3JlRWFjaFByb3ZpZGVycygoKSA9PiBbXG4gICAgICAgICAgICBwcm92aWRlKENoYW5nZURldGVjdG9yR2VuQ29uZmlnLFxuICAgICAgICAgICAgICAgICAgICB7dXNlVmFsdWU6IG5ldyBDaGFuZ2VEZXRlY3RvckdlbkNvbmZpZyh0cnVlLCBmYWxzZSwgdHJ1ZSl9KVxuICAgICAgICAgIF0pO1xuICAgICAgICAgIHJ1blRlc3RzKGNvbXBpbGUpO1xuICAgICAgICB9KTtcblxuICAgICAgICBpdCgnc2hvdWxkIGNhY2hlIGNvbXBvbmVudHMgZm9yIHBhcmFsbGVsIHJlcXVlc3RzJyxcbiAgICAgICAgICAgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXIsIFhIUl0sIChhc3luYywgeGhyOiBNb2NrWEhSKSA9PiB7XG4gICAgICAgICAgICAgLy8gRXhwZWN0aW5nIG9ubHkgb25lIHhoci4uLlxuICAgICAgICAgICAgIHhoci5leHBlY3QoJ3BhY2thZ2U6YW5ndWxhcjIvdGVzdC9jb21waWxlci9jb21wVXJsLmh0bWwnLCAnPGE+PC9hPicpO1xuICAgICAgICAgICAgIFByb21pc2VXcmFwcGVyLmFsbChbY29tcGlsZShbQ29tcFdpdGhUZW1wbGF0ZVVybF0pLCBjb21waWxlKFtDb21wV2l0aFRlbXBsYXRlVXJsXSldKVxuICAgICAgICAgICAgICAgICAudGhlbigoaHVtYW5pemVkVmlld3MpID0+IHtcbiAgICAgICAgICAgICAgICAgICBleHBlY3QoaHVtYW5pemVkVmlld3NbMF1bJ2NvbXBvbmVudFZpZXdzJ11bMF1bJ2VsZW1lbnRzJ10pLnRvRXF1YWwoWyc8YT4nXSk7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KGh1bWFuaXplZFZpZXdzWzFdWydjb21wb25lbnRWaWV3cyddWzBdWydlbGVtZW50cyddKS50b0VxdWFsKFsnPGE+J10pO1xuXG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICB4aHIuZmx1c2goKTtcbiAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIGl0KCdzaG91bGQgY2FjaGUgY29tcG9uZW50cyBmb3Igc2VxdWVudGlhbCByZXF1ZXN0cycsXG4gICAgICAgICAgIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyLCBYSFJdLCAoYXN5bmMsIHhocjogTW9ja1hIUikgPT4ge1xuICAgICAgICAgICAgIC8vIEV4cGVjdGluZyBvbmx5IG9uZSB4aHIuLi5cbiAgICAgICAgICAgICB4aHIuZXhwZWN0KCdwYWNrYWdlOmFuZ3VsYXIyL3Rlc3QvY29tcGlsZXIvY29tcFVybC5odG1sJywgJzxhPicpO1xuICAgICAgICAgICAgIGNvbXBpbGUoW0NvbXBXaXRoVGVtcGxhdGVVcmxdKVxuICAgICAgICAgICAgICAgICAudGhlbigoaHVtYW5pemVkVmlldzApID0+IHtcbiAgICAgICAgICAgICAgICAgICByZXR1cm4gY29tcGlsZShbQ29tcFdpdGhUZW1wbGF0ZVVybF0pXG4gICAgICAgICAgICAgICAgICAgICAgIC50aGVuKChodW1hbml6ZWRWaWV3MSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChodW1hbml6ZWRWaWV3MFsnY29tcG9uZW50Vmlld3MnXVswXVsnZWxlbWVudHMnXSkudG9FcXVhbChbJzxhPiddKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICBleHBlY3QoaHVtYW5pemVkVmlldzFbJ2NvbXBvbmVudFZpZXdzJ11bMF1bJ2VsZW1lbnRzJ10pLnRvRXF1YWwoWyc8YT4nXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgeGhyLmZsdXNoKCk7XG4gICAgICAgICAgIH0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIGFsbG93IHRvIGNsZWFyIHRoZSBjYWNoZScsXG4gICAgICAgICAgIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyLCBYSFJdLCAoYXN5bmMsIHhocjogTW9ja1hIUikgPT4ge1xuICAgICAgICAgICAgIHhoci5leHBlY3QoJ3BhY2thZ2U6YW5ndWxhcjIvdGVzdC9jb21waWxlci9jb21wVXJsLmh0bWwnLCAnPGE+Jyk7XG4gICAgICAgICAgICAgY29tcGlsZShbQ29tcFdpdGhUZW1wbGF0ZVVybF0pXG4gICAgICAgICAgICAgICAgIC50aGVuKChodW1hbml6ZWRWaWV3KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgY29tcGlsZXIuY2xlYXJDYWNoZSgpO1xuICAgICAgICAgICAgICAgICAgIHhoci5leHBlY3QoJ3BhY2thZ2U6YW5ndWxhcjIvdGVzdC9jb21waWxlci9jb21wVXJsLmh0bWwnLCAnPGI+Jyk7XG4gICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdCA9IGNvbXBpbGUoW0NvbXBXaXRoVGVtcGxhdGVVcmxdKTtcbiAgICAgICAgICAgICAgICAgICB4aHIuZmx1c2goKTtcbiAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAudGhlbigoaHVtYW5pemVkVmlldykgPT4ge1xuICAgICAgICAgICAgICAgICAgIGV4cGVjdChodW1hbml6ZWRWaWV3Wydjb21wb25lbnRWaWV3cyddWzBdWydlbGVtZW50cyddKS50b0VxdWFsKFsnPGI+J10pO1xuICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgeGhyLmZsdXNoKCk7XG4gICAgICAgICAgIH0pKTtcbiAgICAgIH0pO1xuXG4gICAgICBkZXNjcmliZSgnY29tcGlsZVRlbXBsYXRlc0NvZGVHZW4nLCAoKSA9PiB7XG4gICAgICAgIGZ1bmN0aW9uIG5vcm1hbGl6ZUNvbXBvbmVudChcbiAgICAgICAgICAgIGNvbXBvbmVudDogVHlwZSk6IFByb21pc2U8Tm9ybWFsaXplZENvbXBvbmVudFdpdGhWaWV3RGlyZWN0aXZlcz4ge1xuICAgICAgICAgIHZhciBjb21wQW5kVmlld0Rpck1ldGFzID1cbiAgICAgICAgICAgICAgW3J1bnRpbWVNZXRhZGF0YVJlc29sdmVyLmdldERpcmVjdGl2ZU1ldGFkYXRhKGNvbXBvbmVudCldLmNvbmNhdChcbiAgICAgICAgICAgICAgICAgIHJ1bnRpbWVNZXRhZGF0YVJlc29sdmVyLmdldFZpZXdEaXJlY3RpdmVzTWV0YWRhdGEoY29tcG9uZW50KSk7XG4gICAgICAgICAgdmFyIHVwcGVyQ2FzZVBpcGVNZXRhID0gcnVudGltZU1ldGFkYXRhUmVzb2x2ZXIuZ2V0UGlwZU1ldGFkYXRhKFVwcGVyQ2FzZVBpcGUpO1xuICAgICAgICAgIHVwcGVyQ2FzZVBpcGVNZXRhLnR5cGUubW9kdWxlVXJsID0gYHBhY2thZ2U6JHtUSElTX01PRFVMRV9JRH0ke01PRFVMRV9TVUZGSVh9YDtcbiAgICAgICAgICByZXR1cm4gUHJvbWlzZVdyYXBwZXIuYWxsKGNvbXBBbmRWaWV3RGlyTWV0YXMubWFwKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGEgPT4gY29tcGlsZXIubm9ybWFsaXplRGlyZWN0aXZlTWV0YWRhdGEobWV0YSkpKVxuICAgICAgICAgICAgICAudGhlbigobm9ybWFsaXplZENvbXBBbmRWaWV3RGlyTWV0YXM6IENvbXBpbGVEaXJlY3RpdmVNZXRhZGF0YVtdKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgbmV3IE5vcm1hbGl6ZWRDb21wb25lbnRXaXRoVmlld0RpcmVjdGl2ZXMoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbm9ybWFsaXplZENvbXBBbmRWaWV3RGlyTWV0YXNbMF0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbm9ybWFsaXplZENvbXBBbmRWaWV3RGlyTWV0YXMuc2xpY2UoMSksIFt1cHBlckNhc2VQaXBlTWV0YV0pKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGNvbXBpbGUoY29tcG9uZW50czogVHlwZVtdKTogUHJvbWlzZTxhbnlbXT4ge1xuICAgICAgICAgIHJldHVybiBQcm9taXNlV3JhcHBlci5hbGwoY29tcG9uZW50cy5tYXAobm9ybWFsaXplQ29tcG9uZW50KSlcbiAgICAgICAgICAgICAgLnRoZW4oKG5vcm1hbGl6ZWRDb21wV2l0aFZpZXdEaXJNZXRhczogTm9ybWFsaXplZENvbXBvbmVudFdpdGhWaWV3RGlyZWN0aXZlc1tdKSA9PiB7XG4gICAgICAgICAgICAgICAgdmFyIHNvdXJjZU1vZHVsZSA9IGNvbXBpbGVyLmNvbXBpbGVUZW1wbGF0ZXNDb2RlR2VuKG5vcm1hbGl6ZWRDb21wV2l0aFZpZXdEaXJNZXRhcyk7XG4gICAgICAgICAgICAgICAgdmFyIHNvdXJjZVdpdGhJbXBvcnRzID1cbiAgICAgICAgICAgICAgICAgICAgdGVzdGFibGVUZW1wbGF0ZU1vZHVsZShzb3VyY2VNb2R1bGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbm9ybWFsaXplZENvbXBXaXRoVmlld0Rpck1ldGFzWzBdLmNvbXBvbmVudClcbiAgICAgICAgICAgICAgICAgICAgICAgIC5nZXRTb3VyY2VXaXRoSW1wb3J0cygpO1xuICAgICAgICAgICAgICAgIHJldHVybiBldmFsTW9kdWxlKHNvdXJjZVdpdGhJbXBvcnRzLnNvdXJjZSwgc291cmNlV2l0aEltcG9ydHMuaW1wb3J0cywgbnVsbCk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgcnVuVGVzdHMoY29tcGlsZSk7XG4gICAgICB9KTtcblxuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ25vcm1hbGl6ZURpcmVjdGl2ZU1ldGFkYXRhJywgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCByZXR1cm4gdGhlIGdpdmVuIERpcmVjdGl2ZU1ldGFkYXRhIGZvciBub24gY29tcG9uZW50cycsXG4gICAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgbWV0YSA9IHJ1bnRpbWVNZXRhZGF0YVJlc29sdmVyLmdldERpcmVjdGl2ZU1ldGFkYXRhKE5vbkNvbXBvbmVudCk7XG4gICAgICAgICAgIGNvbXBpbGVyLm5vcm1hbGl6ZURpcmVjdGl2ZU1ldGFkYXRhKG1ldGEpLnRoZW4obm9ybU1ldGEgPT4ge1xuICAgICAgICAgICAgIGV4cGVjdChub3JtTWV0YSkudG9CZShtZXRhKTtcbiAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIG5vcm1hbGl6ZSB0aGUgdGVtcGxhdGUnLFxuICAgICAgICAgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXIsIFhIUl0sIChhc3luYywgeGhyOiBNb2NrWEhSKSA9PiB7XG4gICAgICAgICAgIHhoci5leHBlY3QoJ3BhY2thZ2U6YW5ndWxhcjIvdGVzdC9jb21waWxlci9jb21wVXJsLmh0bWwnLCAnbG9hZGVkVGVtcGxhdGUnKTtcbiAgICAgICAgICAgY29tcGlsZXIubm9ybWFsaXplRGlyZWN0aXZlTWV0YWRhdGEoXG4gICAgICAgICAgICAgICAgICAgICAgIHJ1bnRpbWVNZXRhZGF0YVJlc29sdmVyLmdldERpcmVjdGl2ZU1ldGFkYXRhKENvbXBXaXRoVGVtcGxhdGVVcmwpKVxuICAgICAgICAgICAgICAgLnRoZW4oKG1ldGE6IENvbXBpbGVEaXJlY3RpdmVNZXRhZGF0YSkgPT4ge1xuICAgICAgICAgICAgICAgICBleHBlY3QobWV0YS50ZW1wbGF0ZS50ZW1wbGF0ZSkudG9FcXVhbCgnbG9hZGVkVGVtcGxhdGUnKTtcbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIHhoci5mbHVzaCgpO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBpdCgnc2hvdWxkIGNvcHkgYWxsIHRoZSBvdGhlciBmaWVsZHMnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICB2YXIgbWV0YSA9XG4gICAgICAgICAgICAgICBydW50aW1lTWV0YWRhdGFSZXNvbHZlci5nZXREaXJlY3RpdmVNZXRhZGF0YShDb21wV2l0aEJpbmRpbmdzQW5kU3R5bGVzQW5kUGlwZXMpO1xuICAgICAgICAgICBjb21waWxlci5ub3JtYWxpemVEaXJlY3RpdmVNZXRhZGF0YShtZXRhKS50aGVuKChub3JtTWV0YTogQ29tcGlsZURpcmVjdGl2ZU1ldGFkYXRhKSA9PiB7XG4gICAgICAgICAgICAgZXhwZWN0KG5vcm1NZXRhLnR5cGUpLnRvRXF1YWwobWV0YS50eXBlKTtcbiAgICAgICAgICAgICBleHBlY3Qobm9ybU1ldGEuaXNDb21wb25lbnQpLnRvRXF1YWwobWV0YS5pc0NvbXBvbmVudCk7XG4gICAgICAgICAgICAgZXhwZWN0KG5vcm1NZXRhLmR5bmFtaWNMb2FkYWJsZSkudG9FcXVhbChtZXRhLmR5bmFtaWNMb2FkYWJsZSk7XG4gICAgICAgICAgICAgZXhwZWN0KG5vcm1NZXRhLnNlbGVjdG9yKS50b0VxdWFsKG1ldGEuc2VsZWN0b3IpO1xuICAgICAgICAgICAgIGV4cGVjdChub3JtTWV0YS5leHBvcnRBcykudG9FcXVhbChtZXRhLmV4cG9ydEFzKTtcbiAgICAgICAgICAgICBleHBlY3Qobm9ybU1ldGEuY2hhbmdlRGV0ZWN0aW9uKS50b0VxdWFsKG1ldGEuY2hhbmdlRGV0ZWN0aW9uKTtcbiAgICAgICAgICAgICBleHBlY3Qobm9ybU1ldGEuaW5wdXRzKS50b0VxdWFsKG1ldGEuaW5wdXRzKTtcbiAgICAgICAgICAgICBleHBlY3Qobm9ybU1ldGEub3V0cHV0cykudG9FcXVhbChtZXRhLm91dHB1dHMpO1xuICAgICAgICAgICAgIGV4cGVjdChub3JtTWV0YS5ob3N0TGlzdGVuZXJzKS50b0VxdWFsKG1ldGEuaG9zdExpc3RlbmVycyk7XG4gICAgICAgICAgICAgZXhwZWN0KG5vcm1NZXRhLmhvc3RQcm9wZXJ0aWVzKS50b0VxdWFsKG1ldGEuaG9zdFByb3BlcnRpZXMpO1xuICAgICAgICAgICAgIGV4cGVjdChub3JtTWV0YS5ob3N0QXR0cmlidXRlcykudG9FcXVhbChtZXRhLmhvc3RBdHRyaWJ1dGVzKTtcbiAgICAgICAgICAgICBleHBlY3Qobm9ybU1ldGEubGlmZWN5Y2xlSG9va3MpLnRvRXF1YWwobWV0YS5saWZlY3ljbGVIb29rcyk7XG4gICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKCdjb21waWxlU3R5bGVzaGVldENvZGVHZW4nLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIGNvbXBpbGUgc3R5bGVzaGVldHMgaW50byBjb2RlJywgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgICAgdmFyIGNzc1RleHQgPSAnZGl2IHtjb2xvcjogcmVkfSc7XG4gICAgICAgICAgIHZhciBzb3VyY2VNb2R1bGUgPVxuICAgICAgICAgICAgICAgY29tcGlsZXIuY29tcGlsZVN0eWxlc2hlZXRDb2RlR2VuKCdwYWNrYWdlOnNvbWVNb2R1bGVVcmwnLCBjc3NUZXh0KVswXTtcbiAgICAgICAgICAgdmFyIHNvdXJjZVdpdGhJbXBvcnRzID0gdGVzdGFibGVTdHlsZXNNb2R1bGUoc291cmNlTW9kdWxlKS5nZXRTb3VyY2VXaXRoSW1wb3J0cygpO1xuICAgICAgICAgICBldmFsTW9kdWxlKHNvdXJjZVdpdGhJbXBvcnRzLnNvdXJjZSwgc291cmNlV2l0aEltcG9ydHMuaW1wb3J0cywgbnVsbClcbiAgICAgICAgICAgICAgIC50aGVuKGxvYWRlZENzc1RleHQgPT4ge1xuICAgICAgICAgICAgICAgICBleHBlY3QobG9hZGVkQ3NzVGV4dCkudG9FcXVhbChbY3NzVGV4dF0pO1xuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgfSkpO1xuICAgIH0pO1xuICB9KTtcbn1cblxuXG5AUGlwZSh7bmFtZTogJ3VwcGVyY2FzZSd9KVxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIFVwcGVyQ2FzZVBpcGUgaW1wbGVtZW50cyBQaXBlVHJhbnNmb3JtIHtcbiAgdHJhbnNmb3JtKHZhbHVlOiBzdHJpbmcsIGFyZ3M6IGFueVtdID0gbnVsbCk6IHN0cmluZyB7IHJldHVybiB2YWx1ZS50b1VwcGVyQ2FzZSgpOyB9XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2NvbXAtYScsXG4gIGhvc3Q6IHsnW3RpdGxlXSc6ICdcXCdzb21lSG9zdFZhbHVlXFwnJ30sXG4gIG1vZHVsZUlkOiBUSElTX01PRFVMRV9JRCxcbiAgZXhwb3J0QXM6ICdzb21lRXhwb3J0QXMnLFxuICB0ZW1wbGF0ZTogJzxhIFtocmVmXT1cIlxcJ3NvbWVDdHhWYWx1ZVxcJyB8IHVwcGVyY2FzZVwiPjwvYT4nLFxuICBzdHlsZXM6IFsnZGl2IHtjb2xvcjogcmVkfSddLFxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxuICBwaXBlczogW1VwcGVyQ2FzZVBpcGVdXG59KVxuZXhwb3J0IGNsYXNzIENvbXBXaXRoQmluZGluZ3NBbmRTdHlsZXNBbmRQaXBlcyB7XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ3RyZWUnLFxuICBtb2R1bGVJZDogVEhJU19NT0RVTEVfSUQsXG4gIHRlbXBsYXRlOiAnPHRlbXBsYXRlPjx0cmVlPjwvdHJlZT48L3RlbXBsYXRlPicsXG4gIGRpcmVjdGl2ZXM6IFtUcmVlQ29tcF0sXG4gIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmVcbn0pXG5leHBvcnQgY2xhc3MgVHJlZUNvbXAge1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdjb21wLXdpdC1kdXAtdHBsJyxcbiAgbW9kdWxlSWQ6IFRISVNfTU9EVUxFX0lELFxuICB0ZW1wbGF0ZTogJzx0cmVlPjwvdHJlZT4nLFxuICBkaXJlY3RpdmVzOiBbVHJlZUNvbXAsIFRyZWVDb21wXSxcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZVxufSlcbmV4cG9ydCBjbGFzcyBDb21wV2l0aER1cERpcmVjdGl2ZXMge1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdjb21wLXVybCcsXG4gIG1vZHVsZUlkOiBUSElTX01PRFVMRV9JRCxcbiAgdGVtcGxhdGVVcmw6ICdjb21wVXJsLmh0bWwnLFxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lXG59KVxuZXhwb3J0IGNsYXNzIENvbXBXaXRoVGVtcGxhdGVVcmwge1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdjb21wLXRwbCcsXG4gIG1vZHVsZUlkOiBUSElTX01PRFVMRV9JRCxcbiAgdGVtcGxhdGU6ICc8dGVtcGxhdGU+PGEgW2hyZWZdPVwiXFwnc29tZUVtYmVkZGVkVmFsdWVcXCdcIj48L2E+PC90ZW1wbGF0ZT4nLFxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lXG59KVxuZXhwb3J0IGNsYXNzIENvbXBXaXRoRW1iZWRkZWRUZW1wbGF0ZSB7XG59XG5cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdwbGFpbid9KVxuZXhwb3J0IGNsYXNzIE5vbkNvbXBvbmVudCB7XG59XG5cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY29tcDInLFxuICBtb2R1bGVJZDogVEhJU19NT0RVTEVfSUQsXG4gIHRlbXBsYXRlOiAnPGI+PC9iPicsXG4gIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmVcbn0pXG5leHBvcnQgY2xhc3MgQ29tcDIge1xufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdjb21wMScsXG4gIG1vZHVsZUlkOiBUSElTX01PRFVMRV9JRCxcbiAgdGVtcGxhdGU6ICc8YT48L2E+LCA8Y29tcDI+PC9jb21wMj4nLFxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxuICBkaXJlY3RpdmVzOiBbQ29tcDJdXG59KVxuZXhwb3J0IGNsYXNzIENvbXAxIHtcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY29tcC13aXRoLTJuZXN0ZWQnLFxuICBtb2R1bGVJZDogVEhJU19NT0RVTEVfSUQsXG4gIHRlbXBsYXRlOiAnPGNvbXAxPjwvY29tcDE+LCA8Y29tcDI+PC9jb21wMj4nLFxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxuICBkaXJlY3RpdmVzOiBbQ29tcDEsIENvbXAyXVxufSlcbmV4cG9ydCBjbGFzcyBDb21wV2l0aDJOZXN0ZWRDb21wcyB7XG59XG5cbmZ1bmN0aW9uIHRlc3RhYmxlVGVtcGxhdGVNb2R1bGUoc291cmNlTW9kdWxlOiBTb3VyY2VNb2R1bGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5vcm1Db21wOiBDb21waWxlRGlyZWN0aXZlTWV0YWRhdGEpOiBTb3VyY2VNb2R1bGUge1xuICB2YXIgdGVzdGFibGVTb3VyY2UgPSBgXG4gICR7c291cmNlTW9kdWxlLnNvdXJjZVdpdGhNb2R1bGVSZWZzfVxuICAke2NvZGVHZW5GbkhlYWRlcihbJ18nXSwgJ19ydW4nKX17XG4gICAgJHtSRUZMRUNUT1JfTU9EVUxFX1JFRn1yZWZsZWN0b3IucmVmbGVjdGlvbkNhcGFiaWxpdGllcyA9IG5ldyAke1JFRkxFQ1RJT05fQ0FQU19NT0RVTEVfUkVGfVJlZmxlY3Rpb25DYXBhYmlsaXRpZXMoKTtcbiAgICByZXR1cm4gJHtUSElTX01PRFVMRV9SRUZ9aHVtYW5pemVWaWV3RmFjdG9yeShob3N0Vmlld0ZhY3RvcnlfJHtub3JtQ29tcC50eXBlLm5hbWV9LnZpZXdGYWN0b3J5KTtcbiAgfVxuICAke2NvZGVHZW5FeHBvcnRWYXJpYWJsZSgncnVuJyl9X3J1bjtgO1xuICByZXR1cm4gbmV3IFNvdXJjZU1vZHVsZShzb3VyY2VNb2R1bGUubW9kdWxlVXJsLCB0ZXN0YWJsZVNvdXJjZSk7XG59XG5cbmZ1bmN0aW9uIHRlc3RhYmxlU3R5bGVzTW9kdWxlKHNvdXJjZU1vZHVsZTogU291cmNlTW9kdWxlKTogU291cmNlTW9kdWxlIHtcbiAgdmFyIHRlc3RhYmxlU291cmNlID0gYCR7c291cmNlTW9kdWxlLnNvdXJjZVdpdGhNb2R1bGVSZWZzfVxuICAke2NvZGVHZW5WYWx1ZUZuKFsnXyddLCAnU1RZTEVTJywgJ19ydW4nKX07XG4gICR7Y29kZUdlbkV4cG9ydFZhcmlhYmxlKCdydW4nKX1fcnVuO2A7XG4gIHJldHVybiBuZXcgU291cmNlTW9kdWxlKHNvdXJjZU1vZHVsZS5tb2R1bGVVcmwsIHRlc3RhYmxlU291cmNlKTtcbn1cblxuZnVuY3Rpb24gaHVtYW5pemVWaWV3KHZpZXc6IEFwcFZpZXcsIGNhY2hlZFJlc3VsdHM6IE1hcDxBcHBQcm90b1ZpZXcsIGFueT4pOiB7W2tleTogc3RyaW5nXTogYW55fSB7XG4gIHZhciByZXN1bHQgPSBjYWNoZWRSZXN1bHRzLmdldCh2aWV3LnByb3RvKTtcbiAgaWYgKGlzUHJlc2VudChyZXN1bHQpKSB7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICByZXN1bHQgPSB7fTtcbiAgLy8gZmlsbCB0aGUgY2FjaGUgZWFybHkgdG8gYnJlYWsgY3ljbGVzLlxuICBjYWNoZWRSZXN1bHRzLnNldCh2aWV3LnByb3RvLCByZXN1bHQpO1xuXG4gIHZpZXcuY2hhbmdlRGV0ZWN0b3IuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gIHZhciBwaXBlcyA9IHt9O1xuICBpZiAoaXNQcmVzZW50KHZpZXcucHJvdG8ucHJvdG9QaXBlcykpIHtcbiAgICBTdHJpbmdNYXBXcmFwcGVyLmZvckVhY2godmlldy5wcm90by5wcm90b1BpcGVzLmNvbmZpZywgKHBpcGVQcm92aWRlciwgcGlwZU5hbWUpID0+IHtcbiAgICAgIHBpcGVzW3BpcGVOYW1lXSA9IHN0cmluZ2lmeShwaXBlUHJvdmlkZXIua2V5LnRva2VuKTtcbiAgICB9KTtcbiAgfVxuICB2YXIgY29tcG9uZW50Vmlld3MgPSBbXTtcbiAgdmFyIGVtYmVkZGVkVmlld3MgPSBbXTtcblxuICB2aWV3LmFwcEVsZW1lbnRzLmZvckVhY2goKGFwcEVsZW1lbnQpID0+IHtcbiAgICBpZiAoaXNQcmVzZW50KGFwcEVsZW1lbnQuY29tcG9uZW50VmlldykpIHtcbiAgICAgIGNvbXBvbmVudFZpZXdzLnB1c2goaHVtYW5pemVWaWV3KGFwcEVsZW1lbnQuY29tcG9uZW50VmlldywgY2FjaGVkUmVzdWx0cykpO1xuICAgIH0gZWxzZSBpZiAoaXNQcmVzZW50KGFwcEVsZW1lbnQuZW1iZWRkZWRWaWV3RmFjdG9yeSkpIHtcbiAgICAgIGVtYmVkZGVkVmlld3MucHVzaChcbiAgICAgICAgICBodW1hbml6ZVZpZXdGYWN0b3J5KGFwcEVsZW1lbnQuZW1iZWRkZWRWaWV3RmFjdG9yeSwgYXBwRWxlbWVudCwgY2FjaGVkUmVzdWx0cykpO1xuICAgIH1cbiAgfSk7XG4gIHJlc3VsdFsnc3R5bGVzJ10gPSAoPGFueT52aWV3LnJlbmRlcmVyKS5zdHlsZXM7XG4gIHJlc3VsdFsnZWxlbWVudHMnXSA9ICg8YW55PnZpZXcucmVuZGVyZXIpLmVsZW1lbnRzO1xuICByZXN1bHRbJ3BpcGVzJ10gPSBwaXBlcztcbiAgcmVzdWx0WydjZCddID0gKDxhbnk+dmlldy5yZW5kZXJlcikucHJvcHM7XG4gIHJlc3VsdFsnY29tcG9uZW50Vmlld3MnXSA9IGNvbXBvbmVudFZpZXdzO1xuICByZXN1bHRbJ2VtYmVkZGVkVmlld3MnXSA9IGVtYmVkZGVkVmlld3M7XG4gIHJldHVybiByZXN1bHQ7XG59XG5cbi8vIEF0dGVudGlvbjogcmVhZCBieSBldmFsIVxuZXhwb3J0IGZ1bmN0aW9uIGh1bWFuaXplVmlld0ZhY3RvcnkoXG4gICAgdmlld0ZhY3Rvcnk6IEZ1bmN0aW9uLCBjb250YWluZXJBcHBFbGVtZW50OiBBcHBFbGVtZW50ID0gbnVsbCxcbiAgICBjYWNoZWRSZXN1bHRzOiBNYXA8QXBwUHJvdG9WaWV3LCBhbnk+ID0gbnVsbCk6IHtba2V5OiBzdHJpbmddOiBhbnl9IHtcbiAgaWYgKGlzQmxhbmsoY2FjaGVkUmVzdWx0cykpIHtcbiAgICBjYWNoZWRSZXN1bHRzID0gbmV3IE1hcDxBcHBQcm90b1ZpZXcsIGFueT4oKTtcbiAgfVxuICB2YXIgdmlld01hbmFnZXIgPSBuZXcgU3B5QXBwVmlld01hbmFnZXIoKTtcbiAgdmlld01hbmFnZXIuc3B5KCdjcmVhdGVSZW5kZXJDb21wb25lbnRUeXBlJylcbiAgICAgIC5hbmRDYWxsRmFrZSgoZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24sIHN0eWxlczogQXJyYXk8c3RyaW5nIHwgYW55W10+KSA9PiB7XG4gICAgICAgIHJldHVybiBuZXcgUmVuZGVyQ29tcG9uZW50VHlwZSgnc29tZUlkJywgZW5jYXBzdWxhdGlvbiwgc3R5bGVzLCBudWxsKTtcbiAgICAgIH0pO1xuICB2YXIgdmlldzogQXBwVmlldyA9IHZpZXdGYWN0b3J5KG5ldyBSZWNvcmRpbmdSZW5kZXJlcihbXSksIHZpZXdNYW5hZ2VyLCBjb250YWluZXJBcHBFbGVtZW50LCBbXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudWxsLCBudWxsLCBudWxsKTtcbiAgcmV0dXJuIGh1bWFuaXplVmlldyh2aWV3LCBjYWNoZWRSZXN1bHRzKTtcbn1cblxuY2xhc3MgUmVjb3JkaW5nUmVuZGVyZXIgZXh0ZW5kcyBTcHlSZW5kZXJlciB7XG4gIHByb3BzOiBzdHJpbmdbXSA9IFtdO1xuICBlbGVtZW50czogc3RyaW5nW10gPSBbXTtcblxuICBjb25zdHJ1Y3RvcihwdWJsaWMgc3R5bGVzOiBzdHJpbmdbXSkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5zcHkoJ3JlbmRlckNvbXBvbmVudCcpXG4gICAgICAgIC5hbmRDYWxsRmFrZSgoY29tcG9uZW50UHJvdG8pID0+IG5ldyBSZWNvcmRpbmdSZW5kZXJlcihjb21wb25lbnRQcm90by5zdHlsZXMpKTtcbiAgICB0aGlzLnNweSgnc2V0RWxlbWVudFByb3BlcnR5JylcbiAgICAgICAgLmFuZENhbGxGYWtlKChlbCwgcHJvcCwgdmFsdWUpID0+IHsgdGhpcy5wcm9wcy5wdXNoKGBwcm9wKCR7cHJvcH0pPSR7dmFsdWV9YCk7IH0pO1xuICAgIHRoaXMuc3B5KCdjcmVhdGVFbGVtZW50JylcbiAgICAgICAgLmFuZENhbGxGYWtlKChwYXJlbnQsIGVsTmFtZSkgPT4geyB0aGlzLmVsZW1lbnRzLnB1c2goYDwke2VsTmFtZX0+YCk7IH0pO1xuICB9XG59XG4iXX0=
 main(); 
