import { HtmlParseTreeResult } from 'angular2/src/compiler/html_parser';
import { ParseLocation } from 'angular2/src/compiler/parse_util';
export declare function humanizeDom(parseResult: HtmlParseTreeResult): any[];
export declare function humanizeDomSourceSpans(parseResult: HtmlParseTreeResult): any[];
export declare function humanizeLineColumn(location: ParseLocation): string;
