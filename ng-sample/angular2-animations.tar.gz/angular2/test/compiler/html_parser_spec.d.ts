import { ParseError } from 'angular2/src/compiler/parse_util';
export declare function main(): void;
export declare function humanizeErrors(errors: ParseError[]): any[];
