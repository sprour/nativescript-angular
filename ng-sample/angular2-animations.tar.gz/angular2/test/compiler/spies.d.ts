import { SpyObject } from 'angular2/testing_internal';
export declare class SpyXHR extends SpyObject {
    constructor();
}
export declare class SpyTemplateCompiler extends SpyObject {
    constructor();
}
