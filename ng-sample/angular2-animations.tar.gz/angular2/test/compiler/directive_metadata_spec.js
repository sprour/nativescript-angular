'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var directive_metadata_1 = require('angular2/src/compiler/directive_metadata');
var view_1 = require('angular2/src/core/metadata/view');
var change_detection_1 = require('angular2/src/core/change_detection');
var interfaces_1 = require('angular2/src/core/linker/interfaces');
function main() {
    testing_internal_1.describe('DirectiveMetadata', function () {
        var fullTypeMeta;
        var fullTemplateMeta;
        var fullDirectiveMeta;
        testing_internal_1.beforeEach(function () {
            var diDep = new directive_metadata_1.CompileDiDependencyMetadata({
                isAttribute: true,
                isSelf: true,
                isHost: true,
                isSkipSelf: true,
                isOptional: true,
                token: 'someToken',
                query: new directive_metadata_1.CompileQueryMetadata({ selectors: ['one'], descendants: true, first: true, propertyName: 'one' }),
                viewQuery: new directive_metadata_1.CompileQueryMetadata({ selectors: ['one'], descendants: true, first: true, propertyName: 'one' })
            });
            fullTypeMeta = new directive_metadata_1.CompileTypeMetadata({ name: 'SomeType', moduleUrl: 'someUrl', isHost: true, diDeps: [diDep] });
            fullTemplateMeta = new directive_metadata_1.CompileTemplateMetadata({
                encapsulation: view_1.ViewEncapsulation.Emulated,
                template: '<a></a>',
                templateUrl: 'someTemplateUrl',
                styles: ['someStyle'],
                styleUrls: ['someStyleUrl'],
                animations: {},
                ngContentSelectors: ['*']
            });
            fullDirectiveMeta = directive_metadata_1.CompileDirectiveMetadata.create({
                selector: 'someSelector',
                isComponent: true,
                dynamicLoadable: true,
                type: fullTypeMeta,
                template: fullTemplateMeta,
                changeDetection: change_detection_1.ChangeDetectionStrategy.Default,
                inputs: ['someProp'],
                outputs: ['someEvent'],
                host: { '(event1)': 'handler1', '[prop1]': 'expr1', 'attr1': 'attrValue2' },
                lifecycleHooks: [interfaces_1.LifecycleHooks.OnChanges],
                providers: [
                    new directive_metadata_1.CompileProviderMetadata({
                        token: 'token',
                        useClass: fullTypeMeta,
                        useExisting: new directive_metadata_1.CompileIdentifierMetadata({ name: 'someName' }),
                        useFactory: new directive_metadata_1.CompileFactoryMetadata({ name: 'someName', diDeps: [diDep] }),
                        useValue: 'someValue',
                    })
                ],
                viewProviders: [
                    new directive_metadata_1.CompileProviderMetadata({
                        token: 'token',
                        useClass: fullTypeMeta,
                        useExisting: new directive_metadata_1.CompileIdentifierMetadata({ name: 'someName' }),
                        useFactory: new directive_metadata_1.CompileFactoryMetadata({ name: 'someName', diDeps: [diDep] }),
                        useValue: 'someValue',
                    })
                ],
                queries: [
                    new directive_metadata_1.CompileQueryMetadata({ selectors: ['selector'], descendants: true, first: false, propertyName: 'prop' })
                ],
                viewQueries: [
                    new directive_metadata_1.CompileQueryMetadata({ selectors: ['selector'], descendants: true, first: false, propertyName: 'prop' })
                ]
            });
        });
        testing_internal_1.describe('CompileIdentifierMetadata', function () {
            testing_internal_1.it('should serialize with full data', function () {
                var full = new directive_metadata_1.CompileIdentifierMetadata({ name: 'name', moduleUrl: 'module', constConstructor: true, value: ['one', ['two']] });
                testing_internal_1.expect(directive_metadata_1.CompileIdentifierMetadata.fromJson(full.toJson())).toEqual(full);
            });
            testing_internal_1.it('should serialize with no data', function () {
                var empty = new directive_metadata_1.CompileIdentifierMetadata();
                testing_internal_1.expect(directive_metadata_1.CompileIdentifierMetadata.fromJson(empty.toJson())).toEqual(empty);
            });
        });
        testing_internal_1.describe('DirectiveMetadata', function () {
            testing_internal_1.it('should serialize with full data', function () {
                testing_internal_1.expect(directive_metadata_1.CompileDirectiveMetadata.fromJson(fullDirectiveMeta.toJson()))
                    .toEqual(fullDirectiveMeta);
            });
            testing_internal_1.it('should serialize with no data', function () {
                var empty = directive_metadata_1.CompileDirectiveMetadata.create();
                testing_internal_1.expect(directive_metadata_1.CompileDirectiveMetadata.fromJson(empty.toJson())).toEqual(empty);
            });
        });
        testing_internal_1.describe('TypeMetadata', function () {
            testing_internal_1.it('should serialize with full data', function () {
                testing_internal_1.expect(directive_metadata_1.CompileTypeMetadata.fromJson(fullTypeMeta.toJson())).toEqual(fullTypeMeta);
            });
            testing_internal_1.it('should serialize with no data', function () {
                var empty = new directive_metadata_1.CompileTypeMetadata();
                testing_internal_1.expect(directive_metadata_1.CompileTypeMetadata.fromJson(empty.toJson())).toEqual(empty);
            });
        });
        testing_internal_1.describe('TemplateMetadata', function () {
            testing_internal_1.it('should use ViewEncapsulation.Emulated by default', function () {
                testing_internal_1.expect(new directive_metadata_1.CompileTemplateMetadata({ encapsulation: null }).encapsulation)
                    .toBe(view_1.ViewEncapsulation.Emulated);
            });
            testing_internal_1.it('should serialize with full data', function () {
                testing_internal_1.expect(directive_metadata_1.CompileTemplateMetadata.fromJson(fullTemplateMeta.toJson()))
                    .toEqual(fullTemplateMeta);
            });
            testing_internal_1.it('should serialize with no data', function () {
                var empty = new directive_metadata_1.CompileTemplateMetadata();
                testing_internal_1.expect(directive_metadata_1.CompileTemplateMetadata.fromJson(empty.toJson())).toEqual(empty);
            });
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlyZWN0aXZlX21ldGFkYXRhX3NwZWMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L2NvbXBpbGVyL2RpcmVjdGl2ZV9tZXRhZGF0YV9zcGVjLnRzIl0sIm5hbWVzIjpbIm1haW4iXSwibWFwcGluZ3MiOiJBQUFBLGlDQVlPLDJCQUEyQixDQUFDLENBQUE7QUFFbkMsbUNBU08sMENBQTBDLENBQUMsQ0FBQTtBQUNsRCxxQkFBZ0MsaUNBQWlDLENBQUMsQ0FBQTtBQUNsRSxpQ0FBc0Msb0NBQW9DLENBQUMsQ0FBQTtBQUMzRSwyQkFBNkIscUNBQXFDLENBQUMsQ0FBQTtBQUVuRTtJQUNFQSwyQkFBUUEsQ0FBQ0EsbUJBQW1CQSxFQUFFQTtRQUM1QkEsSUFBSUEsWUFBaUNBLENBQUNBO1FBQ3RDQSxJQUFJQSxnQkFBeUNBLENBQUNBO1FBQzlDQSxJQUFJQSxpQkFBMkNBLENBQUNBO1FBRWhEQSw2QkFBVUEsQ0FBQ0E7WUFDVEEsSUFBSUEsS0FBS0EsR0FBR0EsSUFBSUEsZ0RBQTJCQSxDQUFDQTtnQkFDMUNBLFdBQVdBLEVBQUVBLElBQUlBO2dCQUNqQkEsTUFBTUEsRUFBRUEsSUFBSUE7Z0JBQ1pBLE1BQU1BLEVBQUVBLElBQUlBO2dCQUNaQSxVQUFVQSxFQUFFQSxJQUFJQTtnQkFDaEJBLFVBQVVBLEVBQUVBLElBQUlBO2dCQUNoQkEsS0FBS0EsRUFBRUEsV0FBV0E7Z0JBQ2xCQSxLQUFLQSxFQUFFQSxJQUFJQSx5Q0FBb0JBLENBQzNCQSxFQUFDQSxTQUFTQSxFQUFFQSxDQUFDQSxLQUFLQSxDQUFDQSxFQUFFQSxXQUFXQSxFQUFFQSxJQUFJQSxFQUFFQSxLQUFLQSxFQUFFQSxJQUFJQSxFQUFFQSxZQUFZQSxFQUFFQSxLQUFLQSxFQUFDQSxDQUFDQTtnQkFDOUVBLFNBQVNBLEVBQUVBLElBQUlBLHlDQUFvQkEsQ0FDL0JBLEVBQUNBLFNBQVNBLEVBQUVBLENBQUNBLEtBQUtBLENBQUNBLEVBQUVBLFdBQVdBLEVBQUVBLElBQUlBLEVBQUVBLEtBQUtBLEVBQUVBLElBQUlBLEVBQUVBLFlBQVlBLEVBQUVBLEtBQUtBLEVBQUNBLENBQUNBO2FBQy9FQSxDQUFDQSxDQUFDQTtZQUVIQSxZQUFZQSxHQUFHQSxJQUFJQSx3Q0FBbUJBLENBQ2xDQSxFQUFDQSxJQUFJQSxFQUFFQSxVQUFVQSxFQUFFQSxTQUFTQSxFQUFFQSxTQUFTQSxFQUFFQSxNQUFNQSxFQUFFQSxJQUFJQSxFQUFFQSxNQUFNQSxFQUFFQSxDQUFDQSxLQUFLQSxDQUFDQSxFQUFDQSxDQUFDQSxDQUFDQTtZQUM3RUEsZ0JBQWdCQSxHQUFHQSxJQUFJQSw0Q0FBdUJBLENBQUNBO2dCQUM3Q0EsYUFBYUEsRUFBRUEsd0JBQWlCQSxDQUFDQSxRQUFRQTtnQkFDekNBLFFBQVFBLEVBQUVBLFNBQVNBO2dCQUNuQkEsV0FBV0EsRUFBRUEsaUJBQWlCQTtnQkFDOUJBLE1BQU1BLEVBQUVBLENBQUNBLFdBQVdBLENBQUNBO2dCQUNyQkEsU0FBU0EsRUFBRUEsQ0FBQ0EsY0FBY0EsQ0FBQ0E7Z0JBQzNCQSxVQUFVQSxFQUFFQSxFQUFFQTtnQkFDZEEsa0JBQWtCQSxFQUFFQSxDQUFDQSxHQUFHQSxDQUFDQTthQUMxQkEsQ0FBQ0EsQ0FBQ0E7WUFDSEEsaUJBQWlCQSxHQUFHQSw2Q0FBd0JBLENBQUNBLE1BQU1BLENBQUNBO2dCQUNsREEsUUFBUUEsRUFBRUEsY0FBY0E7Z0JBQ3hCQSxXQUFXQSxFQUFFQSxJQUFJQTtnQkFDakJBLGVBQWVBLEVBQUVBLElBQUlBO2dCQUNyQkEsSUFBSUEsRUFBRUEsWUFBWUE7Z0JBQ2xCQSxRQUFRQSxFQUFFQSxnQkFBZ0JBO2dCQUMxQkEsZUFBZUEsRUFBRUEsMENBQXVCQSxDQUFDQSxPQUFPQTtnQkFDaERBLE1BQU1BLEVBQUVBLENBQUNBLFVBQVVBLENBQUNBO2dCQUNwQkEsT0FBT0EsRUFBRUEsQ0FBQ0EsV0FBV0EsQ0FBQ0E7Z0JBQ3RCQSxJQUFJQSxFQUFFQSxFQUFDQSxVQUFVQSxFQUFFQSxVQUFVQSxFQUFFQSxTQUFTQSxFQUFFQSxPQUFPQSxFQUFFQSxPQUFPQSxFQUFFQSxZQUFZQSxFQUFDQTtnQkFDekVBLGNBQWNBLEVBQUVBLENBQUNBLDJCQUFjQSxDQUFDQSxTQUFTQSxDQUFDQTtnQkFDMUNBLFNBQVNBLEVBQUVBO29CQUNUQSxJQUFJQSw0Q0FBdUJBLENBQUNBO3dCQUMxQkEsS0FBS0EsRUFBRUEsT0FBT0E7d0JBQ2RBLFFBQVFBLEVBQUVBLFlBQVlBO3dCQUN0QkEsV0FBV0EsRUFBRUEsSUFBSUEsOENBQXlCQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxVQUFVQSxFQUFDQSxDQUFDQTt3QkFDOURBLFVBQVVBLEVBQUVBLElBQUlBLDJDQUFzQkEsQ0FBQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsVUFBVUEsRUFBRUEsTUFBTUEsRUFBRUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsRUFBQ0EsQ0FBQ0E7d0JBQzNFQSxRQUFRQSxFQUFFQSxXQUFXQTtxQkFDdEJBLENBQUNBO2lCQUNIQTtnQkFDREEsYUFBYUEsRUFBRUE7b0JBQ2JBLElBQUlBLDRDQUF1QkEsQ0FBQ0E7d0JBQzFCQSxLQUFLQSxFQUFFQSxPQUFPQTt3QkFDZEEsUUFBUUEsRUFBRUEsWUFBWUE7d0JBQ3RCQSxXQUFXQSxFQUFFQSxJQUFJQSw4Q0FBeUJBLENBQUNBLEVBQUNBLElBQUlBLEVBQUVBLFVBQVVBLEVBQUNBLENBQUNBO3dCQUM5REEsVUFBVUEsRUFBRUEsSUFBSUEsMkNBQXNCQSxDQUFDQSxFQUFDQSxJQUFJQSxFQUFFQSxVQUFVQSxFQUFFQSxNQUFNQSxFQUFFQSxDQUFDQSxLQUFLQSxDQUFDQSxFQUFDQSxDQUFDQTt3QkFDM0VBLFFBQVFBLEVBQUVBLFdBQVdBO3FCQUN0QkEsQ0FBQ0E7aUJBQ0hBO2dCQUNEQSxPQUFPQSxFQUFFQTtvQkFDUEEsSUFBSUEseUNBQW9CQSxDQUNwQkEsRUFBQ0EsU0FBU0EsRUFBRUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsRUFBRUEsV0FBV0EsRUFBRUEsSUFBSUEsRUFBRUEsS0FBS0EsRUFBRUEsS0FBS0EsRUFBRUEsWUFBWUEsRUFBRUEsTUFBTUEsRUFBQ0EsQ0FBQ0E7aUJBQ3RGQTtnQkFDREEsV0FBV0EsRUFBRUE7b0JBQ1hBLElBQUlBLHlDQUFvQkEsQ0FDcEJBLEVBQUNBLFNBQVNBLEVBQUVBLENBQUNBLFVBQVVBLENBQUNBLEVBQUVBLFdBQVdBLEVBQUVBLElBQUlBLEVBQUVBLEtBQUtBLEVBQUVBLEtBQUtBLEVBQUVBLFlBQVlBLEVBQUVBLE1BQU1BLEVBQUNBLENBQUNBO2lCQUN0RkE7YUFDRkEsQ0FBQ0EsQ0FBQ0E7UUFFTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEsMkJBQVFBLENBQUNBLDJCQUEyQkEsRUFBRUE7WUFDcENBLHFCQUFFQSxDQUFDQSxpQ0FBaUNBLEVBQUVBO2dCQUNwQ0EsSUFBSUEsSUFBSUEsR0FBR0EsSUFBSUEsOENBQXlCQSxDQUNwQ0EsRUFBQ0EsSUFBSUEsRUFBRUEsTUFBTUEsRUFBRUEsU0FBU0EsRUFBRUEsUUFBUUEsRUFBRUEsZ0JBQWdCQSxFQUFFQSxJQUFJQSxFQUFFQSxLQUFLQSxFQUFFQSxDQUFDQSxLQUFLQSxFQUFFQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxFQUFDQSxDQUFDQSxDQUFDQTtnQkFDMUZBLHlCQUFNQSxDQUFDQSw4Q0FBeUJBLENBQUNBLFFBQVFBLENBQUNBLElBQUlBLENBQUNBLE1BQU1BLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLElBQUlBLENBQUNBLENBQUNBO1lBQzFFQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsK0JBQStCQSxFQUFFQTtnQkFDbENBLElBQUlBLEtBQUtBLEdBQUdBLElBQUlBLDhDQUF5QkEsRUFBRUEsQ0FBQ0E7Z0JBQzVDQSx5QkFBTUEsQ0FBQ0EsOENBQXlCQSxDQUFDQSxRQUFRQSxDQUFDQSxLQUFLQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQTtZQUM1RUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEsMkJBQVFBLENBQUNBLG1CQUFtQkEsRUFBRUE7WUFDNUJBLHFCQUFFQSxDQUFDQSxpQ0FBaUNBLEVBQUVBO2dCQUNwQ0EseUJBQU1BLENBQUNBLDZDQUF3QkEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQSxDQUFDQTtxQkFDaEVBLE9BQU9BLENBQUNBLGlCQUFpQkEsQ0FBQ0EsQ0FBQ0E7WUFDbENBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSwrQkFBK0JBLEVBQUVBO2dCQUNsQ0EsSUFBSUEsS0FBS0EsR0FBR0EsNkNBQXdCQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQTtnQkFDOUNBLHlCQUFNQSxDQUFDQSw2Q0FBd0JBLENBQUNBLFFBQVFBLENBQUNBLEtBQUtBLENBQUNBLE1BQU1BLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO1lBQzNFQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsY0FBY0EsRUFBRUE7WUFDdkJBLHFCQUFFQSxDQUFDQSxpQ0FBaUNBLEVBQUVBO2dCQUNwQ0EseUJBQU1BLENBQUNBLHdDQUFtQkEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0E7WUFDcEZBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSwrQkFBK0JBLEVBQUVBO2dCQUNsQ0EsSUFBSUEsS0FBS0EsR0FBR0EsSUFBSUEsd0NBQW1CQSxFQUFFQSxDQUFDQTtnQkFDdENBLHlCQUFNQSxDQUFDQSx3Q0FBbUJBLENBQUNBLFFBQVFBLENBQUNBLEtBQUtBLENBQUNBLE1BQU1BLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO1lBQ3RFQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0Esa0JBQWtCQSxFQUFFQTtZQUMzQkEscUJBQUVBLENBQUNBLGtEQUFrREEsRUFBRUE7Z0JBQ3JEQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsNENBQXVCQSxDQUFDQSxFQUFDQSxhQUFhQSxFQUFFQSxJQUFJQSxFQUFDQSxDQUFDQSxDQUFDQSxhQUFhQSxDQUFDQTtxQkFDbkVBLElBQUlBLENBQUNBLHdCQUFpQkEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0E7WUFDeENBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxpQ0FBaUNBLEVBQUVBO2dCQUNwQ0EseUJBQU1BLENBQUNBLDRDQUF1QkEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQSxDQUFDQTtxQkFDOURBLE9BQU9BLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0E7WUFDakNBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSwrQkFBK0JBLEVBQUVBO2dCQUNsQ0EsSUFBSUEsS0FBS0EsR0FBR0EsSUFBSUEsNENBQXVCQSxFQUFFQSxDQUFDQTtnQkFDMUNBLHlCQUFNQSxDQUFDQSw0Q0FBdUJBLENBQUNBLFFBQVFBLENBQUNBLEtBQUtBLENBQUNBLE1BQU1BLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEtBQUtBLENBQUNBLENBQUNBO1lBQzFFQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQTdIZSxZQUFJLE9BNkhuQixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXN5bmNUZXN0Q29tcGxldGVyLFxuICBiZWZvcmVFYWNoLFxuICBkZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICBlbCxcbiAgZXhwZWN0LFxuICBpaXQsXG4gIGluamVjdCxcbiAgaXQsXG4gIHhpdCxcbiAgVGVzdENvbXBvbmVudEJ1aWxkZXJcbn0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmltcG9ydCB7XG4gIENvbXBpbGVEaXJlY3RpdmVNZXRhZGF0YSxcbiAgQ29tcGlsZVR5cGVNZXRhZGF0YSxcbiAgQ29tcGlsZVRlbXBsYXRlTWV0YWRhdGEsXG4gIENvbXBpbGVQcm92aWRlck1ldGFkYXRhLFxuICBDb21waWxlRGlEZXBlbmRlbmN5TWV0YWRhdGEsXG4gIENvbXBpbGVRdWVyeU1ldGFkYXRhLFxuICBDb21waWxlSWRlbnRpZmllck1ldGFkYXRhLFxuICBDb21waWxlRmFjdG9yeU1ldGFkYXRhXG59IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb21waWxlci9kaXJlY3RpdmVfbWV0YWRhdGEnO1xuaW1wb3J0IHtWaWV3RW5jYXBzdWxhdGlvbn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvcmUvbWV0YWRhdGEvdmlldyc7XG5pbXBvcnQge0NoYW5nZURldGVjdGlvblN0cmF0ZWd5fSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9jaGFuZ2VfZGV0ZWN0aW9uJztcbmltcG9ydCB7TGlmZWN5Y2xlSG9va3N9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci9pbnRlcmZhY2VzJztcblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGRlc2NyaWJlKCdEaXJlY3RpdmVNZXRhZGF0YScsICgpID0+IHtcbiAgICB2YXIgZnVsbFR5cGVNZXRhOiBDb21waWxlVHlwZU1ldGFkYXRhO1xuICAgIHZhciBmdWxsVGVtcGxhdGVNZXRhOiBDb21waWxlVGVtcGxhdGVNZXRhZGF0YTtcbiAgICB2YXIgZnVsbERpcmVjdGl2ZU1ldGE6IENvbXBpbGVEaXJlY3RpdmVNZXRhZGF0YTtcblxuICAgIGJlZm9yZUVhY2goKCkgPT4ge1xuICAgICAgdmFyIGRpRGVwID0gbmV3IENvbXBpbGVEaURlcGVuZGVuY3lNZXRhZGF0YSh7XG4gICAgICAgIGlzQXR0cmlidXRlOiB0cnVlLFxuICAgICAgICBpc1NlbGY6IHRydWUsXG4gICAgICAgIGlzSG9zdDogdHJ1ZSxcbiAgICAgICAgaXNTa2lwU2VsZjogdHJ1ZSxcbiAgICAgICAgaXNPcHRpb25hbDogdHJ1ZSxcbiAgICAgICAgdG9rZW46ICdzb21lVG9rZW4nLFxuICAgICAgICBxdWVyeTogbmV3IENvbXBpbGVRdWVyeU1ldGFkYXRhKFxuICAgICAgICAgICAge3NlbGVjdG9yczogWydvbmUnXSwgZGVzY2VuZGFudHM6IHRydWUsIGZpcnN0OiB0cnVlLCBwcm9wZXJ0eU5hbWU6ICdvbmUnfSksXG4gICAgICAgIHZpZXdRdWVyeTogbmV3IENvbXBpbGVRdWVyeU1ldGFkYXRhKFxuICAgICAgICAgICAge3NlbGVjdG9yczogWydvbmUnXSwgZGVzY2VuZGFudHM6IHRydWUsIGZpcnN0OiB0cnVlLCBwcm9wZXJ0eU5hbWU6ICdvbmUnfSlcbiAgICAgIH0pO1xuXG4gICAgICBmdWxsVHlwZU1ldGEgPSBuZXcgQ29tcGlsZVR5cGVNZXRhZGF0YShcbiAgICAgICAgICB7bmFtZTogJ1NvbWVUeXBlJywgbW9kdWxlVXJsOiAnc29tZVVybCcsIGlzSG9zdDogdHJ1ZSwgZGlEZXBzOiBbZGlEZXBdfSk7XG4gICAgICBmdWxsVGVtcGxhdGVNZXRhID0gbmV3IENvbXBpbGVUZW1wbGF0ZU1ldGFkYXRhKHtcbiAgICAgICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uRW11bGF0ZWQsXG4gICAgICAgIHRlbXBsYXRlOiAnPGE+PC9hPicsXG4gICAgICAgIHRlbXBsYXRlVXJsOiAnc29tZVRlbXBsYXRlVXJsJyxcbiAgICAgICAgc3R5bGVzOiBbJ3NvbWVTdHlsZSddLFxuICAgICAgICBzdHlsZVVybHM6IFsnc29tZVN0eWxlVXJsJ10sXG4gICAgICAgIGFuaW1hdGlvbnM6IHt9LFxuICAgICAgICBuZ0NvbnRlbnRTZWxlY3RvcnM6IFsnKiddXG4gICAgICB9KTtcbiAgICAgIGZ1bGxEaXJlY3RpdmVNZXRhID0gQ29tcGlsZURpcmVjdGl2ZU1ldGFkYXRhLmNyZWF0ZSh7XG4gICAgICAgIHNlbGVjdG9yOiAnc29tZVNlbGVjdG9yJyxcbiAgICAgICAgaXNDb21wb25lbnQ6IHRydWUsXG4gICAgICAgIGR5bmFtaWNMb2FkYWJsZTogdHJ1ZSxcbiAgICAgICAgdHlwZTogZnVsbFR5cGVNZXRhLFxuICAgICAgICB0ZW1wbGF0ZTogZnVsbFRlbXBsYXRlTWV0YSxcbiAgICAgICAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5EZWZhdWx0LFxuICAgICAgICBpbnB1dHM6IFsnc29tZVByb3AnXSxcbiAgICAgICAgb3V0cHV0czogWydzb21lRXZlbnQnXSxcbiAgICAgICAgaG9zdDogeycoZXZlbnQxKSc6ICdoYW5kbGVyMScsICdbcHJvcDFdJzogJ2V4cHIxJywgJ2F0dHIxJzogJ2F0dHJWYWx1ZTInfSxcbiAgICAgICAgbGlmZWN5Y2xlSG9va3M6IFtMaWZlY3ljbGVIb29rcy5PbkNoYW5nZXNdLFxuICAgICAgICBwcm92aWRlcnM6IFtcbiAgICAgICAgICBuZXcgQ29tcGlsZVByb3ZpZGVyTWV0YWRhdGEoe1xuICAgICAgICAgICAgdG9rZW46ICd0b2tlbicsXG4gICAgICAgICAgICB1c2VDbGFzczogZnVsbFR5cGVNZXRhLFxuICAgICAgICAgICAgdXNlRXhpc3Rpbmc6IG5ldyBDb21waWxlSWRlbnRpZmllck1ldGFkYXRhKHtuYW1lOiAnc29tZU5hbWUnfSksXG4gICAgICAgICAgICB1c2VGYWN0b3J5OiBuZXcgQ29tcGlsZUZhY3RvcnlNZXRhZGF0YSh7bmFtZTogJ3NvbWVOYW1lJywgZGlEZXBzOiBbZGlEZXBdfSksXG4gICAgICAgICAgICB1c2VWYWx1ZTogJ3NvbWVWYWx1ZScsXG4gICAgICAgICAgfSlcbiAgICAgICAgXSxcbiAgICAgICAgdmlld1Byb3ZpZGVyczogW1xuICAgICAgICAgIG5ldyBDb21waWxlUHJvdmlkZXJNZXRhZGF0YSh7XG4gICAgICAgICAgICB0b2tlbjogJ3Rva2VuJyxcbiAgICAgICAgICAgIHVzZUNsYXNzOiBmdWxsVHlwZU1ldGEsXG4gICAgICAgICAgICB1c2VFeGlzdGluZzogbmV3IENvbXBpbGVJZGVudGlmaWVyTWV0YWRhdGEoe25hbWU6ICdzb21lTmFtZSd9KSxcbiAgICAgICAgICAgIHVzZUZhY3Rvcnk6IG5ldyBDb21waWxlRmFjdG9yeU1ldGFkYXRhKHtuYW1lOiAnc29tZU5hbWUnLCBkaURlcHM6IFtkaURlcF19KSxcbiAgICAgICAgICAgIHVzZVZhbHVlOiAnc29tZVZhbHVlJyxcbiAgICAgICAgICB9KVxuICAgICAgICBdLFxuICAgICAgICBxdWVyaWVzOiBbXG4gICAgICAgICAgbmV3IENvbXBpbGVRdWVyeU1ldGFkYXRhKFxuICAgICAgICAgICAgICB7c2VsZWN0b3JzOiBbJ3NlbGVjdG9yJ10sIGRlc2NlbmRhbnRzOiB0cnVlLCBmaXJzdDogZmFsc2UsIHByb3BlcnR5TmFtZTogJ3Byb3AnfSlcbiAgICAgICAgXSxcbiAgICAgICAgdmlld1F1ZXJpZXM6IFtcbiAgICAgICAgICBuZXcgQ29tcGlsZVF1ZXJ5TWV0YWRhdGEoXG4gICAgICAgICAgICAgIHtzZWxlY3RvcnM6IFsnc2VsZWN0b3InXSwgZGVzY2VuZGFudHM6IHRydWUsIGZpcnN0OiBmYWxzZSwgcHJvcGVydHlOYW1lOiAncHJvcCd9KVxuICAgICAgICBdXG4gICAgICB9KTtcblxuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ0NvbXBpbGVJZGVudGlmaWVyTWV0YWRhdGEnLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIHNlcmlhbGl6ZSB3aXRoIGZ1bGwgZGF0YScsICgpID0+IHtcbiAgICAgICAgbGV0IGZ1bGwgPSBuZXcgQ29tcGlsZUlkZW50aWZpZXJNZXRhZGF0YShcbiAgICAgICAgICAgIHtuYW1lOiAnbmFtZScsIG1vZHVsZVVybDogJ21vZHVsZScsIGNvbnN0Q29uc3RydWN0b3I6IHRydWUsIHZhbHVlOiBbJ29uZScsIFsndHdvJ11dfSk7XG4gICAgICAgIGV4cGVjdChDb21waWxlSWRlbnRpZmllck1ldGFkYXRhLmZyb21Kc29uKGZ1bGwudG9Kc29uKCkpKS50b0VxdWFsKGZ1bGwpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc2VyaWFsaXplIHdpdGggbm8gZGF0YScsICgpID0+IHtcbiAgICAgICAgbGV0IGVtcHR5ID0gbmV3IENvbXBpbGVJZGVudGlmaWVyTWV0YWRhdGEoKTtcbiAgICAgICAgZXhwZWN0KENvbXBpbGVJZGVudGlmaWVyTWV0YWRhdGEuZnJvbUpzb24oZW1wdHkudG9Kc29uKCkpKS50b0VxdWFsKGVtcHR5KTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ0RpcmVjdGl2ZU1ldGFkYXRhJywgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCBzZXJpYWxpemUgd2l0aCBmdWxsIGRhdGEnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdChDb21waWxlRGlyZWN0aXZlTWV0YWRhdGEuZnJvbUpzb24oZnVsbERpcmVjdGl2ZU1ldGEudG9Kc29uKCkpKVxuICAgICAgICAgICAgLnRvRXF1YWwoZnVsbERpcmVjdGl2ZU1ldGEpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc2VyaWFsaXplIHdpdGggbm8gZGF0YScsICgpID0+IHtcbiAgICAgICAgdmFyIGVtcHR5ID0gQ29tcGlsZURpcmVjdGl2ZU1ldGFkYXRhLmNyZWF0ZSgpO1xuICAgICAgICBleHBlY3QoQ29tcGlsZURpcmVjdGl2ZU1ldGFkYXRhLmZyb21Kc29uKGVtcHR5LnRvSnNvbigpKSkudG9FcXVhbChlbXB0eSk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKCdUeXBlTWV0YWRhdGEnLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIHNlcmlhbGl6ZSB3aXRoIGZ1bGwgZGF0YScsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KENvbXBpbGVUeXBlTWV0YWRhdGEuZnJvbUpzb24oZnVsbFR5cGVNZXRhLnRvSnNvbigpKSkudG9FcXVhbChmdWxsVHlwZU1ldGEpO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc2VyaWFsaXplIHdpdGggbm8gZGF0YScsICgpID0+IHtcbiAgICAgICAgdmFyIGVtcHR5ID0gbmV3IENvbXBpbGVUeXBlTWV0YWRhdGEoKTtcbiAgICAgICAgZXhwZWN0KENvbXBpbGVUeXBlTWV0YWRhdGEuZnJvbUpzb24oZW1wdHkudG9Kc29uKCkpKS50b0VxdWFsKGVtcHR5KTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ1RlbXBsYXRlTWV0YWRhdGEnLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIHVzZSBWaWV3RW5jYXBzdWxhdGlvbi5FbXVsYXRlZCBieSBkZWZhdWx0JywgKCkgPT4ge1xuICAgICAgICBleHBlY3QobmV3IENvbXBpbGVUZW1wbGF0ZU1ldGFkYXRhKHtlbmNhcHN1bGF0aW9uOiBudWxsfSkuZW5jYXBzdWxhdGlvbilcbiAgICAgICAgICAgIC50b0JlKFZpZXdFbmNhcHN1bGF0aW9uLkVtdWxhdGVkKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHNlcmlhbGl6ZSB3aXRoIGZ1bGwgZGF0YScsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KENvbXBpbGVUZW1wbGF0ZU1ldGFkYXRhLmZyb21Kc29uKGZ1bGxUZW1wbGF0ZU1ldGEudG9Kc29uKCkpKVxuICAgICAgICAgICAgLnRvRXF1YWwoZnVsbFRlbXBsYXRlTWV0YSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBzZXJpYWxpemUgd2l0aCBubyBkYXRhJywgKCkgPT4ge1xuICAgICAgICB2YXIgZW1wdHkgPSBuZXcgQ29tcGlsZVRlbXBsYXRlTWV0YWRhdGEoKTtcbiAgICAgICAgZXhwZWN0KENvbXBpbGVUZW1wbGF0ZU1ldGFkYXRhLmZyb21Kc29uKGVtcHR5LnRvSnNvbigpKSkudG9FcXVhbChlbXB0eSk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfSk7XG59XG4iXX0=
 main(); 
