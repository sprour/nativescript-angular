export declare function evalModule(moduleSource: string, imports: string[][], args: any[]): Promise<any>;
