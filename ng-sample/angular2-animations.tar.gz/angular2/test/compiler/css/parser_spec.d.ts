export declare function assertTokens(tokens: any, valuesArr: any): void;
export declare function main(): void;
