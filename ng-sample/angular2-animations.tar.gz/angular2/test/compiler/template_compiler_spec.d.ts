import { AppProtoView } from 'angular2/src/core/linker/view';
import { AppElement } from 'angular2/src/core/linker/element';
import { PipeTransform } from 'angular2/core';
export declare function main(): void;
export declare class UpperCasePipe implements PipeTransform {
    transform(value: string, args?: any[]): string;
}
export declare class CompWithBindingsAndStylesAndPipes {
}
export declare class TreeComp {
}
export declare class CompWithDupDirectives {
}
export declare class CompWithTemplateUrl {
}
export declare class CompWithEmbeddedTemplate {
}
export declare class NonComponent {
}
export declare class Comp2 {
}
export declare class Comp1 {
}
export declare class CompWith2NestedComps {
}
export declare function humanizeViewFactory(viewFactory: Function, containerAppElement?: AppElement, cachedResults?: Map<AppProtoView, any>): {
    [key: string]: any;
};
