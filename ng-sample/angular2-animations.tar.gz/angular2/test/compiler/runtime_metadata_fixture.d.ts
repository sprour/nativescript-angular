export declare class MalformedStylesComponent {
}
