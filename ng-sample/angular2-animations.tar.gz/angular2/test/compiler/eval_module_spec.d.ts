export declare var TEST_VALUE: number;
export declare function main(): void;
