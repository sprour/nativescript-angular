'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var runtime_animation_compiler_1 = require('angular2/src/compiler/animation/runtime_animation_compiler');
var animations_1 = require('angular2/src/core/metadata/animations');
function main() {
    testing_internal_1.describe('RuntimeAnimationCompiler', function () {
        var compiler = new runtime_animation_compiler_1.RuntimeAnimationCompiler();
        var compileAnimations = function (animations) {
            return compiler.compileAnimations(animations);
        };
        var compile = function (event, animation) {
            var animations = {};
            animations[event] = animation;
            return compileAnimations(animations);
        };
        testing_internal_1.it('should throw an exception containing all the inner animation parser errors', function () {
            var animation = animations_1.sequence([
                animations_1.style({ "color": "red" }),
                animations_1.animate({ "font-size": "100px" }, 1000),
                animations_1.style({ "color": "blue" }),
                animations_1.animate(null, 1000),
                animations_1.style({ "color": "gold" }),
            ]);
            var capturedErrorMessage;
            try {
                compile('ngEnter', animation);
            }
            catch (e) {
                capturedErrorMessage = e.message;
            }
            testing_internal_1.expect(capturedErrorMessage)
                .toMatchPattern(/Unable to parse the animation sequence for "ngEnter" due to the following errors/g);
            testing_internal_1.expect(capturedErrorMessage)
                .toMatchPattern(/- One or more pending style\(\.\.\.\) animations remain/g);
            testing_internal_1.expect(capturedErrorMessage)
                .toMatchPattern(/- "null" is not a valid key\/value style object/g);
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicnVudGltZV9hbmltYXRpb25fY29tcGlsZXJfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29tcGlsZXIvYW5pbWF0aW9uL3J1bnRpbWVfYW5pbWF0aW9uX2NvbXBpbGVyX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiJdLCJtYXBwaW5ncyI6IkFBQUEsaUNBc0JPLDJCQUEyQixDQUFDLENBQUE7QUFHbkMsMkNBQXVDLDREQUE0RCxDQUFDLENBQUE7QUFDcEcsMkJBQThDLHVDQUF1QyxDQUFDLENBQUE7QUFFdEY7SUFDRUEsMkJBQVFBLENBQUNBLDBCQUEwQkEsRUFBRUE7UUFDbkNBLElBQUlBLFFBQVFBLEdBQUdBLElBQUlBLHFEQUF3QkEsRUFBRUEsQ0FBQ0E7UUFFOUNBLElBQUlBLGlCQUFpQkEsR0FBR0EsVUFBQ0EsVUFBOENBO1lBQ3JFQSxNQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxpQkFBaUJBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBO1FBQ2hEQSxDQUFDQSxDQUFDQTtRQUVGQSxJQUFJQSxPQUFPQSxHQUFHQSxVQUFDQSxLQUFhQSxFQUFFQSxTQUE0QkE7WUFDeERBLElBQUlBLFVBQVVBLEdBQXVDQSxFQUFFQSxDQUFDQTtZQUN4REEsVUFBVUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsR0FBR0EsU0FBU0EsQ0FBQ0E7WUFDOUJBLE1BQU1BLENBQUNBLGlCQUFpQkEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0E7UUFDdkNBLENBQUNBLENBQUNBO1FBRUZBLHFCQUFFQSxDQUFDQSw0RUFBNEVBLEVBQUVBO1lBQy9FQSxJQUFJQSxTQUFTQSxHQUFHQSxxQkFBUUEsQ0FBQ0E7Z0JBQ3ZCQSxrQkFBS0EsQ0FBQ0EsRUFBQ0EsT0FBT0EsRUFBRUEsS0FBS0EsRUFBQ0EsQ0FBQ0E7Z0JBQ3ZCQSxvQkFBT0EsQ0FBQ0EsRUFBQ0EsV0FBV0EsRUFBRUEsT0FBT0EsRUFBQ0EsRUFBRUEsSUFBSUEsQ0FBQ0E7Z0JBQ3JDQSxrQkFBS0EsQ0FBQ0EsRUFBQ0EsT0FBT0EsRUFBRUEsTUFBTUEsRUFBQ0EsQ0FBQ0E7Z0JBQ3hCQSxvQkFBT0EsQ0FBQ0EsSUFBSUEsRUFBRUEsSUFBSUEsQ0FBQ0E7Z0JBQ25CQSxrQkFBS0EsQ0FBQ0EsRUFBQ0EsT0FBT0EsRUFBRUEsTUFBTUEsRUFBQ0EsQ0FBQ0E7YUFDekJBLENBQUNBLENBQUNBO1lBRUhBLElBQUlBLG9CQUE0QkEsQ0FBQ0E7WUFDakNBLElBQUlBLENBQUNBO2dCQUNIQSxPQUFPQSxDQUFDQSxTQUFTQSxFQUFFQSxTQUFTQSxDQUFDQSxDQUFDQTtZQUNoQ0EsQ0FBRUE7WUFBQUEsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ1hBLG9CQUFvQkEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0E7WUFDbkNBLENBQUNBO1lBRURBLHlCQUFNQSxDQUFDQSxvQkFBb0JBLENBQUNBO2lCQUN2QkEsY0FBY0EsQ0FDWEEsbUZBQW1GQSxDQUFDQSxDQUFDQTtZQUU3RkEseUJBQU1BLENBQUNBLG9CQUFvQkEsQ0FBQ0E7aUJBQ3ZCQSxjQUFjQSxDQUFDQSwwREFBMERBLENBQUNBLENBQUNBO1lBRWhGQSx5QkFBTUEsQ0FBQ0Esb0JBQW9CQSxDQUFDQTtpQkFDdkJBLGNBQWNBLENBQUNBLGtEQUFrREEsQ0FBQ0EsQ0FBQ0E7UUFDMUVBLENBQUNBLENBQUNBLENBQUNBO0lBQ0xBLENBQUNBLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBekNlLFlBQUksT0F5Q25CLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBc3luY1Rlc3RDb21wbGV0ZXIsXG4gIGJlZm9yZUVhY2gsXG4gIGRkZXNjcmliZSxcbiAgeGRlc2NyaWJlLFxuICBkZXNjcmliZSxcbiAgZWwsXG4gIGRpc3BhdGNoRXZlbnQsXG4gIGV4cGVjdCxcbiAgaWl0LFxuICBpbmplY3QsXG4gIGJlZm9yZUVhY2hQcm92aWRlcnMsXG4gIGl0LFxuICB4aXQsXG4gIGNvbnRhaW5zUmVnZXhwLFxuICBzdHJpbmdpZnlFbGVtZW50LFxuICBUZXN0Q29tcG9uZW50QnVpbGRlcixcbiAgZmFrZUFzeW5jLFxuICBjbGVhclBlbmRpbmdUaW1lcnMsXG4gIENvbXBvbmVudEZpeHR1cmUsXG4gIHRpY2ssXG4gIGZsdXNoTWljcm90YXNrcyxcbn0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5cbmltcG9ydCB7QW5pbWF0aW9uTWV0YWRhdGF9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL21ldGFkYXRhL2FuaW1hdGlvbnMnO1xuaW1wb3J0IHtSdW50aW1lQW5pbWF0aW9uQ29tcGlsZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb21waWxlci9hbmltYXRpb24vcnVudGltZV9hbmltYXRpb25fY29tcGlsZXInO1xuaW1wb3J0IHtzdHlsZSwgYW5pbWF0ZSwgZ3JvdXAsIHNlcXVlbmNlfSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9tZXRhZGF0YS9hbmltYXRpb25zJztcblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGRlc2NyaWJlKCdSdW50aW1lQW5pbWF0aW9uQ29tcGlsZXInLCAoKSA9PiB7XG4gICAgdmFyIGNvbXBpbGVyID0gbmV3IFJ1bnRpbWVBbmltYXRpb25Db21waWxlcigpO1xuXG4gICAgdmFyIGNvbXBpbGVBbmltYXRpb25zID0gKGFuaW1hdGlvbnM6IHtba2V5OiBzdHJpbmddOiBBbmltYXRpb25NZXRhZGF0YX0pID0+IHtcbiAgICAgIHJldHVybiBjb21waWxlci5jb21waWxlQW5pbWF0aW9ucyhhbmltYXRpb25zKTtcbiAgICB9O1xuXG4gICAgdmFyIGNvbXBpbGUgPSAoZXZlbnQ6IHN0cmluZywgYW5pbWF0aW9uOiBBbmltYXRpb25NZXRhZGF0YSkgPT4ge1xuICAgICAgdmFyIGFuaW1hdGlvbnM6IHtba2V5OiBzdHJpbmddOiBBbmltYXRpb25NZXRhZGF0YX0gPSB7fTtcbiAgICAgIGFuaW1hdGlvbnNbZXZlbnRdID0gYW5pbWF0aW9uO1xuICAgICAgcmV0dXJuIGNvbXBpbGVBbmltYXRpb25zKGFuaW1hdGlvbnMpO1xuICAgIH07XG5cbiAgICBpdCgnc2hvdWxkIHRocm93IGFuIGV4Y2VwdGlvbiBjb250YWluaW5nIGFsbCB0aGUgaW5uZXIgYW5pbWF0aW9uIHBhcnNlciBlcnJvcnMnLCAoKSA9PiB7XG4gICAgICB2YXIgYW5pbWF0aW9uID0gc2VxdWVuY2UoW1xuICAgICAgICBzdHlsZSh7XCJjb2xvclwiOiBcInJlZFwifSksXG4gICAgICAgIGFuaW1hdGUoe1wiZm9udC1zaXplXCI6IFwiMTAwcHhcIn0sIDEwMDApLFxuICAgICAgICBzdHlsZSh7XCJjb2xvclwiOiBcImJsdWVcIn0pLFxuICAgICAgICBhbmltYXRlKG51bGwsIDEwMDApLFxuICAgICAgICBzdHlsZSh7XCJjb2xvclwiOiBcImdvbGRcIn0pLFxuICAgICAgXSk7XG5cbiAgICAgIHZhciBjYXB0dXJlZEVycm9yTWVzc2FnZTogc3RyaW5nO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29tcGlsZSgnbmdFbnRlcicsIGFuaW1hdGlvbik7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNhcHR1cmVkRXJyb3JNZXNzYWdlID0gZS5tZXNzYWdlO1xuICAgICAgfVxuXG4gICAgICBleHBlY3QoY2FwdHVyZWRFcnJvck1lc3NhZ2UpXG4gICAgICAgICAgLnRvTWF0Y2hQYXR0ZXJuKFxuICAgICAgICAgICAgICAvVW5hYmxlIHRvIHBhcnNlIHRoZSBhbmltYXRpb24gc2VxdWVuY2UgZm9yIFwibmdFbnRlclwiIGR1ZSB0byB0aGUgZm9sbG93aW5nIGVycm9ycy9nKTtcblxuICAgICAgZXhwZWN0KGNhcHR1cmVkRXJyb3JNZXNzYWdlKVxuICAgICAgICAgIC50b01hdGNoUGF0dGVybigvLSBPbmUgb3IgbW9yZSBwZW5kaW5nIHN0eWxlXFwoXFwuXFwuXFwuXFwpIGFuaW1hdGlvbnMgcmVtYWluL2cpO1xuXG4gICAgICBleHBlY3QoY2FwdHVyZWRFcnJvck1lc3NhZ2UpXG4gICAgICAgICAgLnRvTWF0Y2hQYXR0ZXJuKC8tIFwibnVsbFwiIGlzIG5vdCBhIHZhbGlkIGtleVxcL3ZhbHVlIHN0eWxlIG9iamVjdC9nKTtcbiAgICB9KTtcbiAgfSk7XG59XG4iXX0=
 main(); 
