'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var lang_1 = require('angular2/src/facade/lang');
var eval_module_1 = require('./eval_module');
// This export is used by this test code
// when evaling the test module!
exports.TEST_VALUE = 23;
var THIS_MODULE_URL = "package:angular2/test/compiler/eval_module_spec" + (lang_1.IS_DART ? '.dart' : '.js');
function main() {
    // Dart's isolate support is broken, and these tests will be obsolote soon with
    // https://github.com/angular/angular/issues/6270
    if (lang_1.IS_DART) {
        return;
    }
    testing_internal_1.describe('evalModule', function () {
        testing_internal_1.it('should call the "run" function and allow to use imports', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            var moduleSource = lang_1.IS_DART ? testDartModule : testJsModule;
            eval_module_1.evalModule(moduleSource, [[THIS_MODULE_URL, 'tst']], [1])
                .then(function (value) {
                testing_internal_1.expect(value).toEqual([1, 23]);
                async.done();
            });
        }));
    });
}
exports.main = main;
var testDartModule = "\n  run(data) {\n\t  data.add(tst.TEST_VALUE);\n\t\treturn data;\n\t}\n";
var testJsModule = "\n  exports.run = function(data) {\n\t  data.push(tst.TEST_VALUE);\n\t\treturn data;\n\t}\n";
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXZhbF9tb2R1bGVfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29tcGlsZXIvZXZhbF9tb2R1bGVfc3BlYy50cyJdLCJuYW1lcyI6WyJtYWluIl0sIm1hcHBpbmdzIjoiQUFBQSxpQ0FZTywyQkFBMkIsQ0FBQyxDQUFBO0FBQ25DLHFCQUFzQiwwQkFBMEIsQ0FBQyxDQUFBO0FBRWpELDRCQUF5QixlQUFlLENBQUMsQ0FBQTtBQUV6Qyx3Q0FBd0M7QUFDeEMsZ0NBQWdDO0FBQ3JCLGtCQUFVLEdBQUcsRUFBRSxDQUFDO0FBRTNCLElBQU0sZUFBZSxHQUFHLHFEQUFrRCxjQUFPLEdBQUMsT0FBTyxHQUFDLEtBQUssQ0FBRSxDQUFDO0FBRWxHO0lBQ0VBLCtFQUErRUE7SUFDL0VBLGlEQUFpREE7SUFDakRBLEVBQUVBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLENBQUNBLENBQUNBO1FBQ1pBLE1BQU1BLENBQUNBO0lBQ1RBLENBQUNBO0lBQ0RBLDJCQUFRQSxDQUFDQSxZQUFZQSxFQUFFQTtRQUNyQkEscUJBQUVBLENBQUNBLHlEQUF5REEsRUFDekRBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO1lBQ2pDQSxJQUFJQSxZQUFZQSxHQUFHQSxjQUFPQSxHQUFHQSxjQUFjQSxHQUFHQSxZQUFZQSxDQUFDQTtZQUMzREEsd0JBQVVBLENBQUNBLFlBQVlBLEVBQUVBLENBQUNBLENBQUNBLGVBQWVBLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2lCQUNwREEsSUFBSUEsQ0FBQ0EsVUFBQ0EsS0FBS0E7Z0JBQ1ZBLHlCQUFNQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDL0JBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO0lBQ1RBLENBQUNBLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBakJlLFlBQUksT0FpQm5CLENBQUE7QUFFRCxJQUFJLGNBQWMsR0FBRyx5RUFLcEIsQ0FBQztBQUVGLElBQUksWUFBWSxHQUFHLDZGQUtsQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgZGRlc2NyaWJlLFxuICBkZXNjcmliZSxcbiAgeGRlc2NyaWJlLFxuICBpdCxcbiAgaWl0LFxuICB4aXQsXG4gIGV4cGVjdCxcbiAgYmVmb3JlRWFjaCxcbiAgYWZ0ZXJFYWNoLFxuICBBc3luY1Rlc3RDb21wbGV0ZXIsXG4gIGluamVjdFxufSBmcm9tICdhbmd1bGFyMi90ZXN0aW5nX2ludGVybmFsJztcbmltcG9ydCB7SVNfREFSVH0gZnJvbSAnYW5ndWxhcjIvc3JjL2ZhY2FkZS9sYW5nJztcblxuaW1wb3J0IHtldmFsTW9kdWxlfSBmcm9tICcuL2V2YWxfbW9kdWxlJztcblxuLy8gVGhpcyBleHBvcnQgaXMgdXNlZCBieSB0aGlzIHRlc3QgY29kZVxuLy8gd2hlbiBldmFsaW5nIHRoZSB0ZXN0IG1vZHVsZSFcbmV4cG9ydCB2YXIgVEVTVF9WQUxVRSA9IDIzO1xuXG5jb25zdCBUSElTX01PRFVMRV9VUkwgPSBgcGFja2FnZTphbmd1bGFyMi90ZXN0L2NvbXBpbGVyL2V2YWxfbW9kdWxlX3NwZWMke0lTX0RBUlQ/Jy5kYXJ0JzonLmpzJ31gO1xuXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpIHtcbiAgLy8gRGFydCdzIGlzb2xhdGUgc3VwcG9ydCBpcyBicm9rZW4sIGFuZCB0aGVzZSB0ZXN0cyB3aWxsIGJlIG9ic29sb3RlIHNvb24gd2l0aFxuICAvLyBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2lzc3Vlcy82MjcwXG4gIGlmIChJU19EQVJUKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGRlc2NyaWJlKCdldmFsTW9kdWxlJywgKCkgPT4ge1xuICAgIGl0KCdzaG91bGQgY2FsbCB0aGUgXCJydW5cIiBmdW5jdGlvbiBhbmQgYWxsb3cgdG8gdXNlIGltcG9ydHMnLFxuICAgICAgIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICB2YXIgbW9kdWxlU291cmNlID0gSVNfREFSVCA/IHRlc3REYXJ0TW9kdWxlIDogdGVzdEpzTW9kdWxlO1xuICAgICAgICAgZXZhbE1vZHVsZShtb2R1bGVTb3VyY2UsIFtbVEhJU19NT0RVTEVfVVJMLCAndHN0J11dLCBbMV0pXG4gICAgICAgICAgICAgLnRoZW4oKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICAgICBleHBlY3QodmFsdWUpLnRvRXF1YWwoWzEsIDIzXSk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuICB9KTtcbn1cblxudmFyIHRlc3REYXJ0TW9kdWxlID0gYFxuICBydW4oZGF0YSkge1xuXHQgIGRhdGEuYWRkKHRzdC5URVNUX1ZBTFVFKTtcblx0XHRyZXR1cm4gZGF0YTtcblx0fVxuYDtcblxudmFyIHRlc3RKc01vZHVsZSA9IGBcbiAgZXhwb3J0cy5ydW4gPSBmdW5jdGlvbihkYXRhKSB7XG5cdCAgZGF0YS5wdXNoKHRzdC5URVNUX1ZBTFVFKTtcblx0XHRyZXR1cm4gZGF0YTtcblx0fVxuYDtcbiJdfQ==
 main(); 
