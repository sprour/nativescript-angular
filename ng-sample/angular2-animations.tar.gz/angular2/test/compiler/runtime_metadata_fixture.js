'use strict';var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('angular2/core');
var MalformedStylesComponent = (function () {
    function MalformedStylesComponent() {
    }
    MalformedStylesComponent = __decorate([
        core_1.Component({ styles: ('foo'), template: '' }), 
        __metadata('design:paramtypes', [])
    ], MalformedStylesComponent);
    return MalformedStylesComponent;
})();
exports.MalformedStylesComponent = MalformedStylesComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicnVudGltZV9tZXRhZGF0YV9maXh0dXJlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb21waWxlci9ydW50aW1lX21ldGFkYXRhX2ZpeHR1cmUudHMiXSwibmFtZXMiOlsiTWFsZm9ybWVkU3R5bGVzQ29tcG9uZW50IiwiTWFsZm9ybWVkU3R5bGVzQ29tcG9uZW50LmNvbnN0cnVjdG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxxQkFBd0IsZUFBZSxDQUFDLENBQUE7QUFFeEM7SUFBQUE7SUFFQUMsQ0FBQ0E7SUFGREQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLE1BQU1BLEVBQU1BLENBQUNBLEtBQUtBLENBQUNBLEVBQUVBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOztpQ0FFOUNBO0lBQURBLCtCQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUM7QUFEWSxnQ0FBd0IsMkJBQ3BDLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudH0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5cbkBDb21wb25lbnQoe3N0eWxlczo8YW55PignZm9vJyksIHRlbXBsYXRlOiAnJ30pXG5leHBvcnQgY2xhc3MgTWFsZm9ybWVkU3R5bGVzQ29tcG9uZW50IHtcbn1cbiJdfQ==