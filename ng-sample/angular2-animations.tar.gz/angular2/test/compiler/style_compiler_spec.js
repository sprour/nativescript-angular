'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var di_1 = require('angular2/src/core/di');
var spies_1 = require('./spies');
var xhr_1 = require('angular2/src/compiler/xhr');
var exceptions_1 = require('angular2/src/facade/exceptions');
var lang_1 = require('angular2/src/facade/lang');
var async_1 = require('angular2/src/facade/async');
var eval_module_1 = require('./eval_module');
var style_compiler_1 = require('angular2/src/compiler/style_compiler');
var directive_metadata_1 = require('angular2/src/compiler/directive_metadata');
var source_module_1 = require('angular2/src/compiler/source_module');
var view_1 = require('angular2/src/core/metadata/view');
var test_bindings_1 = require('./test_bindings');
var util_1 = require('angular2/src/compiler/util');
// Attention: These module names have to correspond to real modules!
var MODULE_URL = "package:angular2/test/compiler/style_compiler_spec" + util_1.MODULE_SUFFIX;
var IMPORT_ABS_STYLESHEET_URL = "package:angular2/test/compiler/style_compiler_import.css";
var IMPORT_REL_STYLESHEET_URL = './style_compiler_import.css';
// Note: Not a real module, only used via mocks.
var IMPORT_ABS_STYLESHEET_URL_WITH_IMPORT = "package:angular2/test/compiler/style_compiler_transitive_import.css";
function main() {
    // Dart's isolate support is broken, and these tests will be obsolote soon with
    // https://github.com/angular/angular/issues/6270
    if (lang_1.IS_DART) {
        return;
    }
    testing_internal_1.describe('StyleCompiler', function () {
        var xhr;
        testing_internal_1.beforeEachProviders(function () {
            xhr = new spies_1.SpyXHR();
            return [test_bindings_1.TEST_PROVIDERS, di_1.provide(xhr_1.XHR, { useValue: xhr })];
        });
        var compiler;
        testing_internal_1.beforeEach(testing_internal_1.inject([style_compiler_1.StyleCompiler], function (_compiler) { compiler = _compiler; }));
        testing_internal_1.describe('compileComponentRuntime', function () {
            var xhrUrlResults;
            var xhrCount;
            testing_internal_1.beforeEach(function () {
                xhrCount = 0;
                xhrUrlResults = {};
                xhrUrlResults[IMPORT_ABS_STYLESHEET_URL] = 'span {color: blue}';
                xhrUrlResults[IMPORT_ABS_STYLESHEET_URL_WITH_IMPORT] =
                    "a {color: green}@import " + IMPORT_REL_STYLESHEET_URL + ";";
            });
            function compile(styles, styleAbsUrls, encapsulation) {
                // Note: Can't use MockXHR as the xhr is called recursively,
                // so we can't trigger flush.
                xhr.spy('get').andCallFake(function (url) {
                    var response = xhrUrlResults[url];
                    xhrCount++;
                    if (lang_1.isBlank(response)) {
                        throw new exceptions_1.BaseException("Unexpected url " + url);
                    }
                    return async_1.PromiseWrapper.resolve(response);
                });
                return compiler.compileComponentRuntime(new directive_metadata_1.CompileTemplateMetadata({ styles: styles, styleUrls: styleAbsUrls, encapsulation: encapsulation }));
            }
            testing_internal_1.describe('no shim', function () {
                var encapsulation = view_1.ViewEncapsulation.None;
                testing_internal_1.it('should compile plain css rules', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile(['div {color: red}', 'span {color: blue}'], [], encapsulation)
                        .then(function (styles) {
                        testing_internal_1.expect(styles).toEqual(['div {color: red}', 'span {color: blue}']);
                        async.done();
                    });
                }));
                testing_internal_1.it('should allow to import rules', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile(['div {color: red}'], [IMPORT_ABS_STYLESHEET_URL], encapsulation)
                        .then(function (styles) {
                        testing_internal_1.expect(styles).toEqual(['div {color: red}', ['span {color: blue}']]);
                        async.done();
                    });
                }));
                testing_internal_1.it('should allow to import rules transitively', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile(['div {color: red}'], [IMPORT_ABS_STYLESHEET_URL_WITH_IMPORT], encapsulation)
                        .then(function (styles) {
                        testing_internal_1.expect(styles)
                            .toEqual(['div {color: red}', ['a {color: green}', ['span {color: blue}']]]);
                        async.done();
                    });
                }));
            });
            testing_internal_1.describe('with shim', function () {
                var encapsulation = view_1.ViewEncapsulation.Emulated;
                testing_internal_1.it('should compile plain css rules', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile(['div {\ncolor: red;\n}', 'span {\ncolor: blue;\n}'], [], encapsulation)
                        .then(function (styles) {
                        compareStyles(styles, [
                            'div[_ngcontent-%COMP%] {\ncolor: red;\n}',
                            'span[_ngcontent-%COMP%] {\ncolor: blue;\n}'
                        ]);
                        async.done();
                    });
                }));
                testing_internal_1.it('should allow to import rules', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile(['div {\ncolor: red;\n}'], [IMPORT_ABS_STYLESHEET_URL], encapsulation)
                        .then(function (styles) {
                        compareStyles(styles, [
                            'div[_ngcontent-%COMP%] {\ncolor: red;\n}',
                            ['span[_ngcontent-%COMP%] {color: blue}']
                        ]);
                        async.done();
                    });
                }));
                testing_internal_1.it('should allow to import rules transitively', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile(['div {\ncolor: red;\n}'], [IMPORT_ABS_STYLESHEET_URL_WITH_IMPORT], encapsulation)
                        .then(function (styles) {
                        compareStyles(styles, [
                            'div[_ngcontent-%COMP%] {\ncolor: red;\n}',
                            [
                                'a[_ngcontent-%COMP%] {color: green}',
                                ['span[_ngcontent-%COMP%] {color: blue}']
                            ]
                        ]);
                        async.done();
                    });
                }));
            });
            testing_internal_1.it('should cache stylesheets for parallel requests', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                async_1.PromiseWrapper.all([
                    compile([], [IMPORT_ABS_STYLESHEET_URL], view_1.ViewEncapsulation.None),
                    compile([], [IMPORT_ABS_STYLESHEET_URL], view_1.ViewEncapsulation.None)
                ])
                    .then(function (styleArrays) {
                    testing_internal_1.expect(styleArrays[0]).toEqual([['span {color: blue}']]);
                    testing_internal_1.expect(styleArrays[1]).toEqual([['span {color: blue}']]);
                    testing_internal_1.expect(xhrCount).toBe(1);
                    async.done();
                });
            }));
            testing_internal_1.it('should cache stylesheets for serial requests', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                compile([], [IMPORT_ABS_STYLESHEET_URL], view_1.ViewEncapsulation.None)
                    .then(function (styles0) {
                    xhrUrlResults[IMPORT_ABS_STYLESHEET_URL] = 'span {color: black}';
                    return compile([], [IMPORT_ABS_STYLESHEET_URL], view_1.ViewEncapsulation.None)
                        .then(function (styles1) {
                        testing_internal_1.expect(styles0).toEqual([['span {color: blue}']]);
                        testing_internal_1.expect(styles1).toEqual([['span {color: blue}']]);
                        testing_internal_1.expect(xhrCount).toBe(1);
                        async.done();
                    });
                });
            }));
            testing_internal_1.it('should allow to clear the cache', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                compile([], [IMPORT_ABS_STYLESHEET_URL], view_1.ViewEncapsulation.None)
                    .then(function (_) {
                    compiler.clearCache();
                    xhrUrlResults[IMPORT_ABS_STYLESHEET_URL] = 'span {color: black}';
                    return compile([], [IMPORT_ABS_STYLESHEET_URL], view_1.ViewEncapsulation.None);
                })
                    .then(function (styles) {
                    testing_internal_1.expect(xhrCount).toBe(2);
                    testing_internal_1.expect(styles).toEqual([['span {color: black}']]);
                    async.done();
                });
            }));
        });
        testing_internal_1.describe('compileComponentCodeGen', function () {
            function compile(styles, styleAbsUrls, encapsulation) {
                var sourceExpression = compiler.compileComponentCodeGen(new directive_metadata_1.CompileTemplateMetadata({ styles: styles, styleUrls: styleAbsUrls, encapsulation: encapsulation }));
                var sourceWithImports = testableExpression(sourceExpression).getSourceWithImports();
                return eval_module_1.evalModule(sourceWithImports.source, sourceWithImports.imports, null);
            }
            ;
            testing_internal_1.describe('no shim', function () {
                var encapsulation = view_1.ViewEncapsulation.None;
                testing_internal_1.it('should compile plain css rules', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile(['div {color: red}', 'span {color: blue}'], [], encapsulation)
                        .then(function (styles) {
                        testing_internal_1.expect(styles).toEqual(['div {color: red}', 'span {color: blue}']);
                        async.done();
                    });
                }));
                testing_internal_1.it('should compile css rules with newlines and quotes', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile(['div\n{"color": \'red\'}'], [], encapsulation)
                        .then(function (styles) {
                        testing_internal_1.expect(styles).toEqual(['div\n{"color": \'red\'}']);
                        async.done();
                    });
                }));
                testing_internal_1.it('should allow to import rules', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile(['div {color: red}'], [IMPORT_ABS_STYLESHEET_URL], encapsulation)
                        .then(function (styles) {
                        testing_internal_1.expect(styles).toEqual(['div {color: red}', ['span {color: blue}']]);
                        async.done();
                    });
                }), 1000);
            });
            testing_internal_1.describe('with shim', function () {
                var encapsulation = view_1.ViewEncapsulation.Emulated;
                testing_internal_1.it('should compile plain css ruless', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile(['div {\ncolor: red;\n}', 'span {\ncolor: blue;\n}'], [], encapsulation)
                        .then(function (styles) {
                        compareStyles(styles, [
                            'div[_ngcontent-%COMP%] {\ncolor: red;\n}',
                            'span[_ngcontent-%COMP%] {\ncolor: blue;\n}'
                        ]);
                        async.done();
                    });
                }));
                testing_internal_1.it('should allow to import rules', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                    compile(['div {color: red}'], [IMPORT_ABS_STYLESHEET_URL], encapsulation)
                        .then(function (styles) {
                        compareStyles(styles, [
                            'div[_ngcontent-%COMP%] {color: red}',
                            ['span[_ngcontent-%COMP%] {\ncolor: blue;\n}']
                        ]);
                        async.done();
                    });
                }), 1000);
            });
        });
        testing_internal_1.describe('compileStylesheetCodeGen', function () {
            function compile(style) {
                var sourceModules = compiler.compileStylesheetCodeGen(MODULE_URL, style);
                return async_1.PromiseWrapper.all(sourceModules.map(function (sourceModule) {
                    var sourceWithImports = testableModule(sourceModule).getSourceWithImports();
                    return eval_module_1.evalModule(sourceWithImports.source, sourceWithImports.imports, null);
                }));
            }
            testing_internal_1.it('should compile plain css rules', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                compile('div {color: red;}')
                    .then(function (stylesAndShimStyles) {
                    var expected = [['div {color: red;}'], ['div[_ngcontent-%COMP%] {color: red;}']];
                    compareStyles(stylesAndShimStyles[0], expected[0]);
                    compareStyles(stylesAndShimStyles[1], expected[1]);
                    async.done();
                });
            }));
            testing_internal_1.it('should allow to import rules with relative paths', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
                compile("div {color: red}@import " + IMPORT_REL_STYLESHEET_URL + ";")
                    .then(function (stylesAndShimStyles) {
                    var expected = [
                        ['div {color: red}', ['span {color: blue}']],
                        [
                            'div[_ngcontent-%COMP%] {color: red}',
                            ['span[_ngcontent-%COMP%] {\ncolor: blue;\n}']
                        ]
                    ];
                    compareStyles(stylesAndShimStyles[0], expected[0]);
                    compareStyles(stylesAndShimStyles[1], expected[1]);
                    async.done();
                });
            }));
        });
    });
}
exports.main = main;
function testableExpression(source) {
    var testableSource = source.declarations.join('\n') + "\n  " + util_1.codeGenValueFn(['_'], source.expression, '_run') + ";\n  " + util_1.codeGenExportVariable('run') + "_run;";
    return new source_module_1.SourceModule(null, testableSource);
}
function testableModule(sourceModule) {
    var testableSource = sourceModule.sourceWithModuleRefs + "\n  " + util_1.codeGenValueFn(['_'], 'STYLES', '_run') + ";\n  " + util_1.codeGenExportVariable('run') + "_run;";
    return new source_module_1.SourceModule(sourceModule.moduleUrl, testableSource);
}
// Needed for Android browsers which add an extra space at the end of some lines
function compareStyles(styles, expectedStyles) {
    testing_internal_1.expect(styles.length).toEqual(expectedStyles.length);
    for (var i = 0; i < styles.length; i++) {
        var style = styles[i];
        if (lang_1.isArray(style)) {
            compareStyles(style, expectedStyles[i]);
        }
        else {
            testing_internal_1.expect(lang_1.StringWrapper.replaceAll(style, /\s+\n/g, '\n')).toEqual(expectedStyles[i]);
        }
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3R5bGVfY29tcGlsZXJfc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRpZmZpbmdfcGx1Z2luX3dyYXBwZXItb3V0cHV0X3BhdGgtWXE4dXhYWUMudG1wL2FuZ3VsYXIyL3Rlc3QvY29tcGlsZXIvc3R5bGVfY29tcGlsZXJfc3BlYy50cyJdLCJuYW1lcyI6WyJtYWluIiwibWFpbi5jb21waWxlIiwidGVzdGFibGVFeHByZXNzaW9uIiwidGVzdGFibGVNb2R1bGUiLCJjb21wYXJlU3R5bGVzIl0sIm1hcHBpbmdzIjoiQUFBQSxpQ0FhTywyQkFBMkIsQ0FBQyxDQUFBO0FBQ25DLG1CQUFzQixzQkFBc0IsQ0FBQyxDQUFBO0FBQzdDLHNCQUFxQixTQUFTLENBQUMsQ0FBQTtBQUMvQixvQkFBa0IsMkJBQTJCLENBQUMsQ0FBQTtBQUM5QywyQkFBOEMsZ0NBQWdDLENBQUMsQ0FBQTtBQUUvRSxxQkFPTywwQkFBMEIsQ0FBQyxDQUFBO0FBQ2xDLHNCQUE2QiwyQkFBMkIsQ0FBQyxDQUFBO0FBQ3pELDRCQUF5QixlQUFlLENBQUMsQ0FBQTtBQUN6QywrQkFBNEIsc0NBQXNDLENBQUMsQ0FBQTtBQUNuRSxtQ0FJTywwQ0FBMEMsQ0FBQyxDQUFBO0FBQ2xELDhCQUE2QyxxQ0FBcUMsQ0FBQyxDQUFBO0FBQ25GLHFCQUFnQyxpQ0FBaUMsQ0FBQyxDQUFBO0FBQ2xFLDhCQUE2QixpQkFBaUIsQ0FBQyxDQUFBO0FBQy9DLHFCQUFtRSw0QkFBNEIsQ0FBQyxDQUFBO0FBRWhHLG9FQUFvRTtBQUNwRSxJQUFJLFVBQVUsR0FBRyx1REFBcUQsb0JBQWUsQ0FBQztBQUN0RixJQUFJLHlCQUF5QixHQUFHLDBEQUEwRCxDQUFDO0FBQzNGLElBQUkseUJBQXlCLEdBQUcsNkJBQTZCLENBQUM7QUFDOUQsZ0RBQWdEO0FBQ2hELElBQUkscUNBQXFDLEdBQ3JDLHFFQUFxRSxDQUFDO0FBRTFFO0lBQ0VBLCtFQUErRUE7SUFDL0VBLGlEQUFpREE7SUFDakRBLEVBQUVBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLENBQUNBLENBQUNBO1FBQ1pBLE1BQU1BLENBQUNBO0lBQ1RBLENBQUNBO0lBQ0RBLDJCQUFRQSxDQUFDQSxlQUFlQSxFQUFFQTtRQUN4QkEsSUFBSUEsR0FBV0EsQ0FBQ0E7UUFFaEJBLHNDQUFtQkEsQ0FBQ0E7WUFDbEJBLEdBQUdBLEdBQVFBLElBQUlBLGNBQU1BLEVBQUVBLENBQUNBO1lBQ3hCQSxNQUFNQSxDQUFDQSxDQUFDQSw4QkFBY0EsRUFBRUEsWUFBT0EsQ0FBQ0EsU0FBR0EsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsR0FBR0EsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDekRBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLElBQUlBLFFBQXVCQSxDQUFDQTtRQUU1QkEsNkJBQVVBLENBQUNBLHlCQUFNQSxDQUFDQSxDQUFDQSw4QkFBYUEsQ0FBQ0EsRUFBRUEsVUFBQ0EsU0FBU0EsSUFBT0EsUUFBUUEsR0FBR0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFOUVBLDJCQUFRQSxDQUFDQSx5QkFBeUJBLEVBQUVBO1lBQ2xDQSxJQUFJQSxhQUFhQSxDQUFDQTtZQUNsQkEsSUFBSUEsUUFBUUEsQ0FBQ0E7WUFFYkEsNkJBQVVBLENBQUNBO2dCQUNUQSxRQUFRQSxHQUFHQSxDQUFDQSxDQUFDQTtnQkFDYkEsYUFBYUEsR0FBR0EsRUFBRUEsQ0FBQ0E7Z0JBQ25CQSxhQUFhQSxDQUFDQSx5QkFBeUJBLENBQUNBLEdBQUdBLG9CQUFvQkEsQ0FBQ0E7Z0JBQ2hFQSxhQUFhQSxDQUFDQSxxQ0FBcUNBLENBQUNBO29CQUNoREEsNkJBQTJCQSx5QkFBeUJBLE1BQUdBLENBQUNBO1lBQzlEQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxpQkFBaUJBLE1BQWdCQSxFQUFFQSxZQUFzQkEsRUFDeENBLGFBQWdDQTtnQkFDL0NDLDREQUE0REE7Z0JBQzVEQSw2QkFBNkJBO2dCQUM3QkEsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsV0FBV0EsQ0FBQ0EsVUFBQ0EsR0FBR0E7b0JBQzdCQSxJQUFJQSxRQUFRQSxHQUFHQSxhQUFhQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtvQkFDbENBLFFBQVFBLEVBQUVBLENBQUNBO29CQUNYQSxFQUFFQSxDQUFDQSxDQUFDQSxjQUFPQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDdEJBLE1BQU1BLElBQUlBLDBCQUFhQSxDQUFDQSxvQkFBa0JBLEdBQUtBLENBQUNBLENBQUNBO29CQUNuREEsQ0FBQ0E7b0JBQ0RBLE1BQU1BLENBQUNBLHNCQUFjQSxDQUFDQSxPQUFPQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtnQkFDMUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUNIQSxNQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSx1QkFBdUJBLENBQUNBLElBQUlBLDRDQUF1QkEsQ0FDL0RBLEVBQUNBLE1BQU1BLEVBQUVBLE1BQU1BLEVBQUVBLFNBQVNBLEVBQUVBLFlBQVlBLEVBQUVBLGFBQWFBLEVBQUVBLGFBQWFBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ2hGQSxDQUFDQTtZQUVERCwyQkFBUUEsQ0FBQ0EsU0FBU0EsRUFBRUE7Z0JBQ2xCQSxJQUFJQSxhQUFhQSxHQUFHQSx3QkFBaUJBLENBQUNBLElBQUlBLENBQUNBO2dCQUUzQ0EscUJBQUVBLENBQUNBLGdDQUFnQ0EsRUFBRUEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7b0JBQ25FQSxPQUFPQSxDQUFDQSxDQUFDQSxrQkFBa0JBLEVBQUVBLG9CQUFvQkEsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsYUFBYUEsQ0FBQ0E7eUJBQ2pFQSxJQUFJQSxDQUFDQSxVQUFBQSxNQUFNQTt3QkFDVkEseUJBQU1BLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLGtCQUFrQkEsRUFBRUEsb0JBQW9CQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDbkVBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO29CQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRVBBLHFCQUFFQSxDQUFDQSw4QkFBOEJBLEVBQUVBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO29CQUNqRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxFQUFFQSxDQUFDQSx5QkFBeUJBLENBQUNBLEVBQUVBLGFBQWFBLENBQUNBO3lCQUNwRUEsSUFBSUEsQ0FBQ0EsVUFBQUEsTUFBTUE7d0JBQ1ZBLHlCQUFNQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxrQkFBa0JBLEVBQUVBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQ3JFQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtvQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUVQQSxxQkFBRUEsQ0FBQ0EsMkNBQTJDQSxFQUFFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtvQkFDOUVBLE9BQU9BLENBQUNBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsRUFBRUEsQ0FBQ0EscUNBQXFDQSxDQUFDQSxFQUFFQSxhQUFhQSxDQUFDQTt5QkFDaEZBLElBQUlBLENBQUNBLFVBQUFBLE1BQU1BO3dCQUNWQSx5QkFBTUEsQ0FBQ0EsTUFBTUEsQ0FBQ0E7NkJBQ1RBLE9BQU9BLENBQUNBLENBQUNBLGtCQUFrQkEsRUFBRUEsQ0FBQ0Esa0JBQWtCQSxFQUFFQSxDQUFDQSxvQkFBb0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO3dCQUNqRkEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7b0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO2dCQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSwyQkFBUUEsQ0FBQ0EsV0FBV0EsRUFBRUE7Z0JBQ3BCQSxJQUFJQSxhQUFhQSxHQUFHQSx3QkFBaUJBLENBQUNBLFFBQVFBLENBQUNBO2dCQUUvQ0EscUJBQUVBLENBQUNBLGdDQUFnQ0EsRUFBRUEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7b0JBQ25FQSxPQUFPQSxDQUFDQSxDQUFDQSx1QkFBdUJBLEVBQUVBLHlCQUF5QkEsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsYUFBYUEsQ0FBQ0E7eUJBQzNFQSxJQUFJQSxDQUFDQSxVQUFBQSxNQUFNQTt3QkFDVkEsYUFBYUEsQ0FBQ0EsTUFBTUEsRUFBRUE7NEJBQ3BCQSwwQ0FBMENBOzRCQUMxQ0EsNENBQTRDQTt5QkFDN0NBLENBQUNBLENBQUNBO3dCQUNIQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtvQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUVQQSxxQkFBRUEsQ0FBQ0EsOEJBQThCQSxFQUFFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtvQkFDakVBLE9BQU9BLENBQUNBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsRUFBRUEsQ0FBQ0EseUJBQXlCQSxDQUFDQSxFQUFFQSxhQUFhQSxDQUFDQTt5QkFDekVBLElBQUlBLENBQUNBLFVBQUFBLE1BQU1BO3dCQUNWQSxhQUFhQSxDQUFDQSxNQUFNQSxFQUFFQTs0QkFDcEJBLDBDQUEwQ0E7NEJBQzFDQSxDQUFDQSx1Q0FBdUNBLENBQUNBO3lCQUMxQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQ0hBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO29CQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRVBBLHFCQUFFQSxDQUFDQSwyQ0FBMkNBLEVBQUVBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO29CQUM5RUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsdUJBQXVCQSxDQUFDQSxFQUFFQSxDQUFDQSxxQ0FBcUNBLENBQUNBLEVBQ2xFQSxhQUFhQSxDQUFDQTt5QkFDakJBLElBQUlBLENBQUNBLFVBQUFBLE1BQU1BO3dCQUNWQSxhQUFhQSxDQUFDQSxNQUFNQSxFQUFFQTs0QkFDcEJBLDBDQUEwQ0E7NEJBQzFDQTtnQ0FDRUEscUNBQXFDQTtnQ0FDckNBLENBQUNBLHVDQUF1Q0EsQ0FBQ0E7NkJBQzFDQTt5QkFDRkEsQ0FBQ0EsQ0FBQ0E7d0JBQ0hBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO29CQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLGdEQUFnREEsRUFBRUEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7Z0JBQ25GQSxzQkFBY0EsQ0FBQ0EsR0FBR0EsQ0FBQ0E7b0JBQ0hBLE9BQU9BLENBQUNBLEVBQUVBLEVBQUVBLENBQUNBLHlCQUF5QkEsQ0FBQ0EsRUFBRUEsd0JBQWlCQSxDQUFDQSxJQUFJQSxDQUFDQTtvQkFDaEVBLE9BQU9BLENBQUNBLEVBQUVBLEVBQUVBLENBQUNBLHlCQUF5QkEsQ0FBQ0EsRUFBRUEsd0JBQWlCQSxDQUFDQSxJQUFJQSxDQUFDQTtpQkFDakVBLENBQUNBO3FCQUNYQSxJQUFJQSxDQUFDQSxVQUFDQSxXQUFXQTtvQkFDaEJBLHlCQUFNQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxvQkFBb0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUN6REEseUJBQU1BLENBQUNBLFdBQVdBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ3pEQSx5QkFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ3pCQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFUEEscUJBQUVBLENBQUNBLDhDQUE4Q0EsRUFBRUEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7Z0JBQ2pGQSxPQUFPQSxDQUFDQSxFQUFFQSxFQUFFQSxDQUFDQSx5QkFBeUJBLENBQUNBLEVBQUVBLHdCQUFpQkEsQ0FBQ0EsSUFBSUEsQ0FBQ0E7cUJBQzNEQSxJQUFJQSxDQUFDQSxVQUFDQSxPQUFPQTtvQkFDWkEsYUFBYUEsQ0FBQ0EseUJBQXlCQSxDQUFDQSxHQUFHQSxxQkFBcUJBLENBQUNBO29CQUNqRUEsTUFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsRUFBRUEsRUFBRUEsQ0FBQ0EseUJBQXlCQSxDQUFDQSxFQUFFQSx3QkFBaUJBLENBQUNBLElBQUlBLENBQUNBO3lCQUNsRUEsSUFBSUEsQ0FBQ0EsVUFBQ0EsT0FBT0E7d0JBQ1pBLHlCQUFNQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxvQkFBb0JBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO3dCQUNsREEseUJBQU1BLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQ2xEQSx5QkFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQ3pCQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtvQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ1RBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSxpQ0FBaUNBLEVBQUVBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO2dCQUNwRUEsT0FBT0EsQ0FBQ0EsRUFBRUEsRUFBRUEsQ0FBQ0EseUJBQXlCQSxDQUFDQSxFQUFFQSx3QkFBaUJBLENBQUNBLElBQUlBLENBQUNBO3FCQUMzREEsSUFBSUEsQ0FBQ0EsVUFBQ0EsQ0FBQ0E7b0JBQ05BLFFBQVFBLENBQUNBLFVBQVVBLEVBQUVBLENBQUNBO29CQUN0QkEsYUFBYUEsQ0FBQ0EseUJBQXlCQSxDQUFDQSxHQUFHQSxxQkFBcUJBLENBQUNBO29CQUNqRUEsTUFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsRUFBRUEsRUFBRUEsQ0FBQ0EseUJBQXlCQSxDQUFDQSxFQUFFQSx3QkFBaUJBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO2dCQUMxRUEsQ0FBQ0EsQ0FBQ0E7cUJBQ0RBLElBQUlBLENBQUNBLFVBQUNBLE1BQU1BO29CQUNYQSx5QkFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ3pCQSx5QkFBTUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDbERBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO2dCQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EseUJBQXlCQSxFQUFFQTtZQUNsQ0EsaUJBQWlCQSxNQUFnQkEsRUFBRUEsWUFBc0JBLEVBQ3hDQSxhQUFnQ0E7Z0JBQy9DQyxJQUFJQSxnQkFBZ0JBLEdBQUdBLFFBQVFBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsSUFBSUEsNENBQXVCQSxDQUMvRUEsRUFBQ0EsTUFBTUEsRUFBRUEsTUFBTUEsRUFBRUEsU0FBU0EsRUFBRUEsWUFBWUEsRUFBRUEsYUFBYUEsRUFBRUEsYUFBYUEsRUFBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzlFQSxJQUFJQSxpQkFBaUJBLEdBQUdBLGtCQUFrQkEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQSxvQkFBb0JBLEVBQUVBLENBQUNBO2dCQUNwRkEsTUFBTUEsQ0FBQ0Esd0JBQVVBLENBQUNBLGlCQUFpQkEsQ0FBQ0EsTUFBTUEsRUFBRUEsaUJBQWlCQSxDQUFDQSxPQUFPQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtZQUMvRUEsQ0FBQ0E7WUFBQUQsQ0FBQ0E7WUFFRkEsMkJBQVFBLENBQUNBLFNBQVNBLEVBQUVBO2dCQUNsQkEsSUFBSUEsYUFBYUEsR0FBR0Esd0JBQWlCQSxDQUFDQSxJQUFJQSxDQUFDQTtnQkFFM0NBLHFCQUFFQSxDQUFDQSxnQ0FBZ0NBLEVBQUVBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO29CQUNuRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0Esa0JBQWtCQSxFQUFFQSxvQkFBb0JBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLGFBQWFBLENBQUNBO3lCQUNqRUEsSUFBSUEsQ0FBQ0EsVUFBQUEsTUFBTUE7d0JBQ1ZBLHlCQUFNQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxrQkFBa0JBLEVBQUVBLG9CQUFvQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQ25FQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtvQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUVQQSxxQkFBRUEsQ0FBQ0EsbURBQW1EQSxFQUNuREEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7b0JBQ2pDQSxPQUFPQSxDQUFDQSxDQUFDQSx5QkFBeUJBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLGFBQWFBLENBQUNBO3lCQUNsREEsSUFBSUEsQ0FBQ0EsVUFBQUEsTUFBTUE7d0JBQ1ZBLHlCQUFNQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSx5QkFBeUJBLENBQUNBLENBQUNBLENBQUNBO3dCQUNwREEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7b0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO2dCQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFUEEscUJBQUVBLENBQUNBLDhCQUE4QkEsRUFBRUEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7b0JBQ2pFQSxPQUFPQSxDQUFDQSxDQUFDQSxrQkFBa0JBLENBQUNBLEVBQUVBLENBQUNBLHlCQUF5QkEsQ0FBQ0EsRUFBRUEsYUFBYUEsQ0FBQ0E7eUJBQ3BFQSxJQUFJQSxDQUFDQSxVQUFBQSxNQUFNQTt3QkFDVkEseUJBQU1BLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLGtCQUFrQkEsRUFBRUEsQ0FBQ0Esb0JBQW9CQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDckVBLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO29CQUNmQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDVEEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7WUFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEsMkJBQVFBLENBQUNBLFdBQVdBLEVBQUVBO2dCQUNwQkEsSUFBSUEsYUFBYUEsR0FBR0Esd0JBQWlCQSxDQUFDQSxRQUFRQSxDQUFDQTtnQkFFL0NBLHFCQUFFQSxDQUFDQSxpQ0FBaUNBLEVBQUVBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO29CQUNwRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsdUJBQXVCQSxFQUFFQSx5QkFBeUJBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLGFBQWFBLENBQUNBO3lCQUMzRUEsSUFBSUEsQ0FBQ0EsVUFBQUEsTUFBTUE7d0JBQ1ZBLGFBQWFBLENBQUNBLE1BQU1BLEVBQUVBOzRCQUNwQkEsMENBQTBDQTs0QkFDMUNBLDRDQUE0Q0E7eUJBQzdDQSxDQUFDQSxDQUFDQTt3QkFDSEEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7b0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO2dCQUNUQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFUEEscUJBQUVBLENBQUNBLDhCQUE4QkEsRUFBRUEseUJBQU1BLENBQUNBLENBQUNBLHFDQUFrQkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsS0FBS0E7b0JBQ2pFQSxPQUFPQSxDQUFDQSxDQUFDQSxrQkFBa0JBLENBQUNBLEVBQUVBLENBQUNBLHlCQUF5QkEsQ0FBQ0EsRUFBRUEsYUFBYUEsQ0FBQ0E7eUJBQ3BFQSxJQUFJQSxDQUFDQSxVQUFBQSxNQUFNQTt3QkFDVkEsYUFBYUEsQ0FBQ0EsTUFBTUEsRUFBRUE7NEJBQ3BCQSxxQ0FBcUNBOzRCQUNyQ0EsQ0FBQ0EsNENBQTRDQSxDQUFDQTt5QkFDL0NBLENBQUNBLENBQUNBO3dCQUNIQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtvQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ1RBLENBQUNBLENBQUNBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBO1lBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1FBQ0xBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLDJCQUFRQSxDQUFDQSwwQkFBMEJBLEVBQUVBO1lBQ25DQSxpQkFBaUJBLEtBQWFBO2dCQUM1QkMsSUFBSUEsYUFBYUEsR0FBR0EsUUFBUUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSxVQUFVQSxFQUFFQSxLQUFLQSxDQUFDQSxDQUFDQTtnQkFDekVBLE1BQU1BLENBQUNBLHNCQUFjQSxDQUFDQSxHQUFHQSxDQUFDQSxhQUFhQSxDQUFDQSxHQUFHQSxDQUFDQSxVQUFBQSxZQUFZQTtvQkFDdERBLElBQUlBLGlCQUFpQkEsR0FBR0EsY0FBY0EsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0Esb0JBQW9CQSxFQUFFQSxDQUFDQTtvQkFDNUVBLE1BQU1BLENBQUNBLHdCQUFVQSxDQUFDQSxpQkFBaUJBLENBQUNBLE1BQU1BLEVBQUVBLGlCQUFpQkEsQ0FBQ0EsT0FBT0EsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7Z0JBQy9FQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNOQSxDQUFDQTtZQUVERCxxQkFBRUEsQ0FBQ0EsZ0NBQWdDQSxFQUFFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtnQkFDbkVBLE9BQU9BLENBQUNBLG1CQUFtQkEsQ0FBQ0E7cUJBQ3ZCQSxJQUFJQSxDQUFDQSxVQUFBQSxtQkFBbUJBO29CQUN2QkEsSUFBSUEsUUFBUUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxFQUFFQSxDQUFDQSxzQ0FBc0NBLENBQUNBLENBQUNBLENBQUNBO29CQUNqRkEsYUFBYUEsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDbkRBLGFBQWFBLENBQUNBLG1CQUFtQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ25EQSxLQUFLQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQTtnQkFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFUEEscUJBQUVBLENBQUNBLGtEQUFrREEsRUFDbERBLHlCQUFNQSxDQUFDQSxDQUFDQSxxQ0FBa0JBLENBQUNBLEVBQUVBLFVBQUNBLEtBQUtBO2dCQUNqQ0EsT0FBT0EsQ0FBQ0EsNkJBQTJCQSx5QkFBeUJBLE1BQUdBLENBQUNBO3FCQUMzREEsSUFBSUEsQ0FBQ0EsVUFBQUEsbUJBQW1CQTtvQkFDdkJBLElBQUlBLFFBQVFBLEdBQUdBO3dCQUNiQSxDQUFDQSxrQkFBa0JBLEVBQUVBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsQ0FBQ0E7d0JBQzVDQTs0QkFDRUEscUNBQXFDQTs0QkFDckNBLENBQUNBLDRDQUE0Q0EsQ0FBQ0E7eUJBQy9DQTtxQkFDRkEsQ0FBQ0E7b0JBQ0ZBLGFBQWFBLENBQUNBLG1CQUFtQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ25EQSxhQUFhQSxDQUFDQSxtQkFBbUJBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUNuREEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0JBQ2ZBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBO0lBQ0xBLENBQUNBLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBcFFlLFlBQUksT0FvUW5CLENBQUE7QUFHRCw0QkFBNEIsTUFBd0I7SUFDbERFLElBQUlBLGNBQWNBLEdBQU1BLE1BQU1BLENBQUNBLFlBQVlBLENBQUNBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLFlBQ3BEQSxxQkFBY0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBRUEsTUFBTUEsQ0FBQ0EsVUFBVUEsRUFBRUEsTUFBTUEsQ0FBQ0EsYUFDaERBLDRCQUFxQkEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsVUFBT0EsQ0FBQ0E7SUFDdENBLE1BQU1BLENBQUNBLElBQUlBLDRCQUFZQSxDQUFDQSxJQUFJQSxFQUFFQSxjQUFjQSxDQUFDQSxDQUFDQTtBQUNoREEsQ0FBQ0E7QUFFRCx3QkFBd0IsWUFBMEI7SUFDaERDLElBQUlBLGNBQWNBLEdBQU1BLFlBQVlBLENBQUNBLG9CQUFvQkEsWUFDdkRBLHFCQUFjQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFFQSxRQUFRQSxFQUFFQSxNQUFNQSxDQUFDQSxhQUN2Q0EsNEJBQXFCQSxDQUFDQSxLQUFLQSxDQUFDQSxVQUFPQSxDQUFDQTtJQUN0Q0EsTUFBTUEsQ0FBQ0EsSUFBSUEsNEJBQVlBLENBQUNBLFlBQVlBLENBQUNBLFNBQVNBLEVBQUVBLGNBQWNBLENBQUNBLENBQUNBO0FBQ2xFQSxDQUFDQTtBQUVELGdGQUFnRjtBQUNoRix1QkFBdUIsTUFBNkIsRUFBRSxjQUFxQztJQUN6RkMseUJBQU1BLENBQUNBLE1BQU1BLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLGNBQWNBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO0lBQ3JEQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFFQSxDQUFDQSxHQUFHQSxNQUFNQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQSxFQUFFQSxFQUFFQSxDQUFDQTtRQUN2Q0EsSUFBSUEsS0FBS0EsR0FBR0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDdEJBLEVBQUVBLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ25CQSxhQUFhQSxDQUFRQSxLQUFLQSxFQUFTQSxjQUFjQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUN4REEsQ0FBQ0E7UUFBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7WUFDTkEseUJBQU1BLENBQUNBLG9CQUFhQSxDQUFDQSxVQUFVQSxDQUFTQSxLQUFLQSxFQUFFQSxRQUFRQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUM3RkEsQ0FBQ0E7SUFDSEEsQ0FBQ0E7QUFDSEEsQ0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBkZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICB4ZGVzY3JpYmUsXG4gIGl0LFxuICBpaXQsXG4gIHhpdCxcbiAgZXhwZWN0LFxuICBiZWZvcmVFYWNoLFxuICBhZnRlckVhY2gsXG4gIEFzeW5jVGVzdENvbXBsZXRlcixcbiAgaW5qZWN0LFxuICBiZWZvcmVFYWNoUHJvdmlkZXJzXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuaW1wb3J0IHtwcm92aWRlfSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9kaSc7XG5pbXBvcnQge1NweVhIUn0gZnJvbSAnLi9zcGllcyc7XG5pbXBvcnQge1hIUn0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvbXBpbGVyL3hocic7XG5pbXBvcnQge0Jhc2VFeGNlcHRpb24sIFdyYXBwZWRFeGNlcHRpb259IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvZXhjZXB0aW9ucyc7XG5cbmltcG9ydCB7XG4gIENPTlNUX0VYUFIsXG4gIGlzUHJlc2VudCxcbiAgaXNCbGFuayxcbiAgU3RyaW5nV3JhcHBlcixcbiAgaXNBcnJheSxcbiAgSVNfREFSVFxufSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2xhbmcnO1xuaW1wb3J0IHtQcm9taXNlV3JhcHBlcn0gZnJvbSAnYW5ndWxhcjIvc3JjL2ZhY2FkZS9hc3luYyc7XG5pbXBvcnQge2V2YWxNb2R1bGV9IGZyb20gJy4vZXZhbF9tb2R1bGUnO1xuaW1wb3J0IHtTdHlsZUNvbXBpbGVyfSBmcm9tICdhbmd1bGFyMi9zcmMvY29tcGlsZXIvc3R5bGVfY29tcGlsZXInO1xuaW1wb3J0IHtcbiAgQ29tcGlsZURpcmVjdGl2ZU1ldGFkYXRhLFxuICBDb21waWxlVGVtcGxhdGVNZXRhZGF0YSxcbiAgQ29tcGlsZVR5cGVNZXRhZGF0YVxufSBmcm9tICdhbmd1bGFyMi9zcmMvY29tcGlsZXIvZGlyZWN0aXZlX21ldGFkYXRhJztcbmltcG9ydCB7U291cmNlRXhwcmVzc2lvbiwgU291cmNlTW9kdWxlfSBmcm9tICdhbmd1bGFyMi9zcmMvY29tcGlsZXIvc291cmNlX21vZHVsZSc7XG5pbXBvcnQge1ZpZXdFbmNhcHN1bGF0aW9ufSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9tZXRhZGF0YS92aWV3JztcbmltcG9ydCB7VEVTVF9QUk9WSURFUlN9IGZyb20gJy4vdGVzdF9iaW5kaW5ncyc7XG5pbXBvcnQge2NvZGVHZW5WYWx1ZUZuLCBjb2RlR2VuRXhwb3J0VmFyaWFibGUsIE1PRFVMRV9TVUZGSVh9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb21waWxlci91dGlsJztcblxuLy8gQXR0ZW50aW9uOiBUaGVzZSBtb2R1bGUgbmFtZXMgaGF2ZSB0byBjb3JyZXNwb25kIHRvIHJlYWwgbW9kdWxlcyFcbnZhciBNT0RVTEVfVVJMID0gYHBhY2thZ2U6YW5ndWxhcjIvdGVzdC9jb21waWxlci9zdHlsZV9jb21waWxlcl9zcGVjJHtNT0RVTEVfU1VGRklYfWA7XG52YXIgSU1QT1JUX0FCU19TVFlMRVNIRUVUX1VSTCA9IGBwYWNrYWdlOmFuZ3VsYXIyL3Rlc3QvY29tcGlsZXIvc3R5bGVfY29tcGlsZXJfaW1wb3J0LmNzc2A7XG52YXIgSU1QT1JUX1JFTF9TVFlMRVNIRUVUX1VSTCA9ICcuL3N0eWxlX2NvbXBpbGVyX2ltcG9ydC5jc3MnO1xuLy8gTm90ZTogTm90IGEgcmVhbCBtb2R1bGUsIG9ubHkgdXNlZCB2aWEgbW9ja3MuXG52YXIgSU1QT1JUX0FCU19TVFlMRVNIRUVUX1VSTF9XSVRIX0lNUE9SVCA9XG4gICAgYHBhY2thZ2U6YW5ndWxhcjIvdGVzdC9jb21waWxlci9zdHlsZV9jb21waWxlcl90cmFuc2l0aXZlX2ltcG9ydC5jc3NgO1xuXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpIHtcbiAgLy8gRGFydCdzIGlzb2xhdGUgc3VwcG9ydCBpcyBicm9rZW4sIGFuZCB0aGVzZSB0ZXN0cyB3aWxsIGJlIG9ic29sb3RlIHNvb24gd2l0aFxuICAvLyBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2lzc3Vlcy82MjcwXG4gIGlmIChJU19EQVJUKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGRlc2NyaWJlKCdTdHlsZUNvbXBpbGVyJywgKCkgPT4ge1xuICAgIHZhciB4aHI6IFNweVhIUjtcblxuICAgIGJlZm9yZUVhY2hQcm92aWRlcnMoKCkgPT4ge1xuICAgICAgeGhyID0gPGFueT5uZXcgU3B5WEhSKCk7XG4gICAgICByZXR1cm4gW1RFU1RfUFJPVklERVJTLCBwcm92aWRlKFhIUiwge3VzZVZhbHVlOiB4aHJ9KV07XG4gICAgfSk7XG5cbiAgICB2YXIgY29tcGlsZXI6IFN0eWxlQ29tcGlsZXI7XG5cbiAgICBiZWZvcmVFYWNoKGluamVjdChbU3R5bGVDb21waWxlcl0sIChfY29tcGlsZXIpID0+IHsgY29tcGlsZXIgPSBfY29tcGlsZXI7IH0pKTtcblxuICAgIGRlc2NyaWJlKCdjb21waWxlQ29tcG9uZW50UnVudGltZScsICgpID0+IHtcbiAgICAgIHZhciB4aHJVcmxSZXN1bHRzO1xuICAgICAgdmFyIHhockNvdW50O1xuXG4gICAgICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICAgICAgeGhyQ291bnQgPSAwO1xuICAgICAgICB4aHJVcmxSZXN1bHRzID0ge307XG4gICAgICAgIHhoclVybFJlc3VsdHNbSU1QT1JUX0FCU19TVFlMRVNIRUVUX1VSTF0gPSAnc3BhbiB7Y29sb3I6IGJsdWV9JztcbiAgICAgICAgeGhyVXJsUmVzdWx0c1tJTVBPUlRfQUJTX1NUWUxFU0hFRVRfVVJMX1dJVEhfSU1QT1JUXSA9XG4gICAgICAgICAgICBgYSB7Y29sb3I6IGdyZWVufUBpbXBvcnQgJHtJTVBPUlRfUkVMX1NUWUxFU0hFRVRfVVJMfTtgO1xuICAgICAgfSk7XG5cbiAgICAgIGZ1bmN0aW9uIGNvbXBpbGUoc3R5bGVzOiBzdHJpbmdbXSwgc3R5bGVBYnNVcmxzOiBzdHJpbmdbXSxcbiAgICAgICAgICAgICAgICAgICAgICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24pOiBQcm9taXNlPHN0cmluZ1tdPiB7XG4gICAgICAgIC8vIE5vdGU6IENhbid0IHVzZSBNb2NrWEhSIGFzIHRoZSB4aHIgaXMgY2FsbGVkIHJlY3Vyc2l2ZWx5LFxuICAgICAgICAvLyBzbyB3ZSBjYW4ndCB0cmlnZ2VyIGZsdXNoLlxuICAgICAgICB4aHIuc3B5KCdnZXQnKS5hbmRDYWxsRmFrZSgodXJsKSA9PiB7XG4gICAgICAgICAgdmFyIHJlc3BvbnNlID0geGhyVXJsUmVzdWx0c1t1cmxdO1xuICAgICAgICAgIHhockNvdW50Kys7XG4gICAgICAgICAgaWYgKGlzQmxhbmsocmVzcG9uc2UpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgQmFzZUV4Y2VwdGlvbihgVW5leHBlY3RlZCB1cmwgJHt1cmx9YCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBQcm9taXNlV3JhcHBlci5yZXNvbHZlKHJlc3BvbnNlKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBjb21waWxlci5jb21waWxlQ29tcG9uZW50UnVudGltZShuZXcgQ29tcGlsZVRlbXBsYXRlTWV0YWRhdGEoXG4gICAgICAgICAgICB7c3R5bGVzOiBzdHlsZXMsIHN0eWxlVXJsczogc3R5bGVBYnNVcmxzLCBlbmNhcHN1bGF0aW9uOiBlbmNhcHN1bGF0aW9ufSkpO1xuICAgICAgfVxuXG4gICAgICBkZXNjcmliZSgnbm8gc2hpbScsICgpID0+IHtcbiAgICAgICAgdmFyIGVuY2Fwc3VsYXRpb24gPSBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lO1xuXG4gICAgICAgIGl0KCdzaG91bGQgY29tcGlsZSBwbGFpbiBjc3MgcnVsZXMnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICAgIGNvbXBpbGUoWydkaXYge2NvbG9yOiByZWR9JywgJ3NwYW4ge2NvbG9yOiBibHVlfSddLCBbXSwgZW5jYXBzdWxhdGlvbilcbiAgICAgICAgICAgICAgICAgLnRoZW4oc3R5bGVzID0+IHtcbiAgICAgICAgICAgICAgICAgICBleHBlY3Qoc3R5bGVzKS50b0VxdWFsKFsnZGl2IHtjb2xvcjogcmVkfScsICdzcGFuIHtjb2xvcjogYmx1ZX0nXSk7XG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIGl0KCdzaG91bGQgYWxsb3cgdG8gaW1wb3J0IHJ1bGVzJywgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgICAgICBjb21waWxlKFsnZGl2IHtjb2xvcjogcmVkfSddLCBbSU1QT1JUX0FCU19TVFlMRVNIRUVUX1VSTF0sIGVuY2Fwc3VsYXRpb24pXG4gICAgICAgICAgICAgICAgIC50aGVuKHN0eWxlcyA9PiB7XG4gICAgICAgICAgICAgICAgICAgZXhwZWN0KHN0eWxlcykudG9FcXVhbChbJ2RpdiB7Y29sb3I6IHJlZH0nLCBbJ3NwYW4ge2NvbG9yOiBibHVlfSddXSk7XG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIGl0KCdzaG91bGQgYWxsb3cgdG8gaW1wb3J0IHJ1bGVzIHRyYW5zaXRpdmVseScsIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgY29tcGlsZShbJ2RpdiB7Y29sb3I6IHJlZH0nXSwgW0lNUE9SVF9BQlNfU1RZTEVTSEVFVF9VUkxfV0lUSF9JTVBPUlRdLCBlbmNhcHN1bGF0aW9uKVxuICAgICAgICAgICAgICAgICAudGhlbihzdHlsZXMgPT4ge1xuICAgICAgICAgICAgICAgICAgIGV4cGVjdChzdHlsZXMpXG4gICAgICAgICAgICAgICAgICAgICAgIC50b0VxdWFsKFsnZGl2IHtjb2xvcjogcmVkfScsIFsnYSB7Y29sb3I6IGdyZWVufScsIFsnc3BhbiB7Y29sb3I6IGJsdWV9J11dXSk7XG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgfSkpO1xuICAgICAgfSk7XG5cbiAgICAgIGRlc2NyaWJlKCd3aXRoIHNoaW0nLCAoKSA9PiB7XG4gICAgICAgIHZhciBlbmNhcHN1bGF0aW9uID0gVmlld0VuY2Fwc3VsYXRpb24uRW11bGF0ZWQ7XG5cbiAgICAgICAgaXQoJ3Nob3VsZCBjb21waWxlIHBsYWluIGNzcyBydWxlcycsIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgY29tcGlsZShbJ2RpdiB7XFxuY29sb3I6IHJlZDtcXG59JywgJ3NwYW4ge1xcbmNvbG9yOiBibHVlO1xcbn0nXSwgW10sIGVuY2Fwc3VsYXRpb24pXG4gICAgICAgICAgICAgICAgIC50aGVuKHN0eWxlcyA9PiB7XG4gICAgICAgICAgICAgICAgICAgY29tcGFyZVN0eWxlcyhzdHlsZXMsIFtcbiAgICAgICAgICAgICAgICAgICAgICdkaXZbX25nY29udGVudC0lQ09NUCVdIHtcXG5jb2xvcjogcmVkO1xcbn0nLFxuICAgICAgICAgICAgICAgICAgICAgJ3NwYW5bX25nY29udGVudC0lQ09NUCVdIHtcXG5jb2xvcjogYmx1ZTtcXG59J1xuICAgICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIGFsbG93IHRvIGltcG9ydCBydWxlcycsIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgY29tcGlsZShbJ2RpdiB7XFxuY29sb3I6IHJlZDtcXG59J10sIFtJTVBPUlRfQUJTX1NUWUxFU0hFRVRfVVJMXSwgZW5jYXBzdWxhdGlvbilcbiAgICAgICAgICAgICAgICAgLnRoZW4oc3R5bGVzID0+IHtcbiAgICAgICAgICAgICAgICAgICBjb21wYXJlU3R5bGVzKHN0eWxlcywgW1xuICAgICAgICAgICAgICAgICAgICAgJ2Rpdltfbmdjb250ZW50LSVDT01QJV0ge1xcbmNvbG9yOiByZWQ7XFxufScsXG4gICAgICAgICAgICAgICAgICAgICBbJ3NwYW5bX25nY29udGVudC0lQ09NUCVdIHtjb2xvcjogYmx1ZX0nXVxuICAgICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIGFsbG93IHRvIGltcG9ydCBydWxlcyB0cmFuc2l0aXZlbHknLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICAgIGNvbXBpbGUoWydkaXYge1xcbmNvbG9yOiByZWQ7XFxufSddLCBbSU1QT1JUX0FCU19TVFlMRVNIRUVUX1VSTF9XSVRIX0lNUE9SVF0sXG4gICAgICAgICAgICAgICAgICAgICBlbmNhcHN1bGF0aW9uKVxuICAgICAgICAgICAgICAgICAudGhlbihzdHlsZXMgPT4ge1xuICAgICAgICAgICAgICAgICAgIGNvbXBhcmVTdHlsZXMoc3R5bGVzLCBbXG4gICAgICAgICAgICAgICAgICAgICAnZGl2W19uZ2NvbnRlbnQtJUNPTVAlXSB7XFxuY29sb3I6IHJlZDtcXG59JyxcbiAgICAgICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgICAgICAgJ2FbX25nY29udGVudC0lQ09NUCVdIHtjb2xvcjogZ3JlZW59JyxcbiAgICAgICAgICAgICAgICAgICAgICAgWydzcGFuW19uZ2NvbnRlbnQtJUNPTVAlXSB7Y29sb3I6IGJsdWV9J11cbiAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICB9KSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBjYWNoZSBzdHlsZXNoZWV0cyBmb3IgcGFyYWxsZWwgcmVxdWVzdHMnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICBQcm9taXNlV3JhcHBlci5hbGwoW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcGlsZShbXSwgW0lNUE9SVF9BQlNfU1RZTEVTSEVFVF9VUkxdLCBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBpbGUoW10sIFtJTVBPUlRfQUJTX1NUWUxFU0hFRVRfVVJMXSwgVmlld0VuY2Fwc3VsYXRpb24uTm9uZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICBdKVxuICAgICAgICAgICAgICAgLnRoZW4oKHN0eWxlQXJyYXlzKSA9PiB7XG4gICAgICAgICAgICAgICAgIGV4cGVjdChzdHlsZUFycmF5c1swXSkudG9FcXVhbChbWydzcGFuIHtjb2xvcjogYmx1ZX0nXV0pO1xuICAgICAgICAgICAgICAgICBleHBlY3Qoc3R5bGVBcnJheXNbMV0pLnRvRXF1YWwoW1snc3BhbiB7Y29sb3I6IGJsdWV9J11dKTtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KHhockNvdW50KS50b0JlKDEpO1xuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBjYWNoZSBzdHlsZXNoZWV0cyBmb3Igc2VyaWFsIHJlcXVlc3RzJywgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgICAgY29tcGlsZShbXSwgW0lNUE9SVF9BQlNfU1RZTEVTSEVFVF9VUkxdLCBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lKVxuICAgICAgICAgICAgICAgLnRoZW4oKHN0eWxlczApID0+IHtcbiAgICAgICAgICAgICAgICAgeGhyVXJsUmVzdWx0c1tJTVBPUlRfQUJTX1NUWUxFU0hFRVRfVVJMXSA9ICdzcGFuIHtjb2xvcjogYmxhY2t9JztcbiAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbXBpbGUoW10sIFtJTVBPUlRfQUJTX1NUWUxFU0hFRVRfVVJMXSwgVmlld0VuY2Fwc3VsYXRpb24uTm9uZSlcbiAgICAgICAgICAgICAgICAgICAgIC50aGVuKChzdHlsZXMxKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChzdHlsZXMwKS50b0VxdWFsKFtbJ3NwYW4ge2NvbG9yOiBibHVlfSddXSk7XG4gICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdChzdHlsZXMxKS50b0VxdWFsKFtbJ3NwYW4ge2NvbG9yOiBibHVlfSddXSk7XG4gICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdCh4aHJDb3VudCkudG9CZSgxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCBhbGxvdyB0byBjbGVhciB0aGUgY2FjaGUnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICBjb21waWxlKFtdLCBbSU1QT1JUX0FCU19TVFlMRVNIRUVUX1VSTF0sIFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUpXG4gICAgICAgICAgICAgICAudGhlbigoXykgPT4ge1xuICAgICAgICAgICAgICAgICBjb21waWxlci5jbGVhckNhY2hlKCk7XG4gICAgICAgICAgICAgICAgIHhoclVybFJlc3VsdHNbSU1QT1JUX0FCU19TVFlMRVNIRUVUX1VSTF0gPSAnc3BhbiB7Y29sb3I6IGJsYWNrfSc7XG4gICAgICAgICAgICAgICAgIHJldHVybiBjb21waWxlKFtdLCBbSU1QT1JUX0FCU19TVFlMRVNIRUVUX1VSTF0sIFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUpO1xuICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgIC50aGVuKChzdHlsZXMpID0+IHtcbiAgICAgICAgICAgICAgICAgZXhwZWN0KHhockNvdW50KS50b0JlKDIpO1xuICAgICAgICAgICAgICAgICBleHBlY3Qoc3R5bGVzKS50b0VxdWFsKFtbJ3NwYW4ge2NvbG9yOiBibGFja30nXV0pO1xuICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICB9KTtcbiAgICAgICAgIH0pKTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKCdjb21waWxlQ29tcG9uZW50Q29kZUdlbicsICgpID0+IHtcbiAgICAgIGZ1bmN0aW9uIGNvbXBpbGUoc3R5bGVzOiBzdHJpbmdbXSwgc3R5bGVBYnNVcmxzOiBzdHJpbmdbXSxcbiAgICAgICAgICAgICAgICAgICAgICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24pOiBQcm9taXNlPHN0cmluZ1tdPiB7XG4gICAgICAgIHZhciBzb3VyY2VFeHByZXNzaW9uID0gY29tcGlsZXIuY29tcGlsZUNvbXBvbmVudENvZGVHZW4obmV3IENvbXBpbGVUZW1wbGF0ZU1ldGFkYXRhKFxuICAgICAgICAgICAge3N0eWxlczogc3R5bGVzLCBzdHlsZVVybHM6IHN0eWxlQWJzVXJscywgZW5jYXBzdWxhdGlvbjogZW5jYXBzdWxhdGlvbn0pKTtcbiAgICAgICAgdmFyIHNvdXJjZVdpdGhJbXBvcnRzID0gdGVzdGFibGVFeHByZXNzaW9uKHNvdXJjZUV4cHJlc3Npb24pLmdldFNvdXJjZVdpdGhJbXBvcnRzKCk7XG4gICAgICAgIHJldHVybiBldmFsTW9kdWxlKHNvdXJjZVdpdGhJbXBvcnRzLnNvdXJjZSwgc291cmNlV2l0aEltcG9ydHMuaW1wb3J0cywgbnVsbCk7XG4gICAgICB9O1xuXG4gICAgICBkZXNjcmliZSgnbm8gc2hpbScsICgpID0+IHtcbiAgICAgICAgdmFyIGVuY2Fwc3VsYXRpb24gPSBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lO1xuXG4gICAgICAgIGl0KCdzaG91bGQgY29tcGlsZSBwbGFpbiBjc3MgcnVsZXMnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICAgIGNvbXBpbGUoWydkaXYge2NvbG9yOiByZWR9JywgJ3NwYW4ge2NvbG9yOiBibHVlfSddLCBbXSwgZW5jYXBzdWxhdGlvbilcbiAgICAgICAgICAgICAgICAgLnRoZW4oc3R5bGVzID0+IHtcbiAgICAgICAgICAgICAgICAgICBleHBlY3Qoc3R5bGVzKS50b0VxdWFsKFsnZGl2IHtjb2xvcjogcmVkfScsICdzcGFuIHtjb2xvcjogYmx1ZX0nXSk7XG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIGl0KCdzaG91bGQgY29tcGlsZSBjc3MgcnVsZXMgd2l0aCBuZXdsaW5lcyBhbmQgcXVvdGVzJyxcbiAgICAgICAgICAgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgICAgICBjb21waWxlKFsnZGl2XFxue1wiY29sb3JcIjogXFwncmVkXFwnfSddLCBbXSwgZW5jYXBzdWxhdGlvbilcbiAgICAgICAgICAgICAgICAgLnRoZW4oc3R5bGVzID0+IHtcbiAgICAgICAgICAgICAgICAgICBleHBlY3Qoc3R5bGVzKS50b0VxdWFsKFsnZGl2XFxue1wiY29sb3JcIjogXFwncmVkXFwnfSddKTtcbiAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgaXQoJ3Nob3VsZCBhbGxvdyB0byBpbXBvcnQgcnVsZXMnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICAgIGNvbXBpbGUoWydkaXYge2NvbG9yOiByZWR9J10sIFtJTVBPUlRfQUJTX1NUWUxFU0hFRVRfVVJMXSwgZW5jYXBzdWxhdGlvbilcbiAgICAgICAgICAgICAgICAgLnRoZW4oc3R5bGVzID0+IHtcbiAgICAgICAgICAgICAgICAgICBleHBlY3Qoc3R5bGVzKS50b0VxdWFsKFsnZGl2IHtjb2xvcjogcmVkfScsIFsnc3BhbiB7Y29sb3I6IGJsdWV9J11dKTtcbiAgICAgICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICB9KSwgMTAwMCk7XG4gICAgICB9KTtcblxuICAgICAgZGVzY3JpYmUoJ3dpdGggc2hpbScsICgpID0+IHtcbiAgICAgICAgdmFyIGVuY2Fwc3VsYXRpb24gPSBWaWV3RW5jYXBzdWxhdGlvbi5FbXVsYXRlZDtcblxuICAgICAgICBpdCgnc2hvdWxkIGNvbXBpbGUgcGxhaW4gY3NzIHJ1bGVzcycsIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgY29tcGlsZShbJ2RpdiB7XFxuY29sb3I6IHJlZDtcXG59JywgJ3NwYW4ge1xcbmNvbG9yOiBibHVlO1xcbn0nXSwgW10sIGVuY2Fwc3VsYXRpb24pXG4gICAgICAgICAgICAgICAgIC50aGVuKHN0eWxlcyA9PiB7XG4gICAgICAgICAgICAgICAgICAgY29tcGFyZVN0eWxlcyhzdHlsZXMsIFtcbiAgICAgICAgICAgICAgICAgICAgICdkaXZbX25nY29udGVudC0lQ09NUCVdIHtcXG5jb2xvcjogcmVkO1xcbn0nLFxuICAgICAgICAgICAgICAgICAgICAgJ3NwYW5bX25nY29udGVudC0lQ09NUCVdIHtcXG5jb2xvcjogYmx1ZTtcXG59J1xuICAgICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0pKTtcblxuICAgICAgICBpdCgnc2hvdWxkIGFsbG93IHRvIGltcG9ydCBydWxlcycsIGluamVjdChbQXN5bmNUZXN0Q29tcGxldGVyXSwgKGFzeW5jKSA9PiB7XG4gICAgICAgICAgICAgY29tcGlsZShbJ2RpdiB7Y29sb3I6IHJlZH0nXSwgW0lNUE9SVF9BQlNfU1RZTEVTSEVFVF9VUkxdLCBlbmNhcHN1bGF0aW9uKVxuICAgICAgICAgICAgICAgICAudGhlbihzdHlsZXMgPT4ge1xuICAgICAgICAgICAgICAgICAgIGNvbXBhcmVTdHlsZXMoc3R5bGVzLCBbXG4gICAgICAgICAgICAgICAgICAgICAnZGl2W19uZ2NvbnRlbnQtJUNPTVAlXSB7Y29sb3I6IHJlZH0nLFxuICAgICAgICAgICAgICAgICAgICAgWydzcGFuW19uZ2NvbnRlbnQtJUNPTVAlXSB7XFxuY29sb3I6IGJsdWU7XFxufSddXG4gICAgICAgICAgICAgICAgICAgXSk7XG4gICAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgfSksIDEwMDApO1xuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICBkZXNjcmliZSgnY29tcGlsZVN0eWxlc2hlZXRDb2RlR2VuJywgKCkgPT4ge1xuICAgICAgZnVuY3Rpb24gY29tcGlsZShzdHlsZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmdbXVtdPiB7XG4gICAgICAgIHZhciBzb3VyY2VNb2R1bGVzID0gY29tcGlsZXIuY29tcGlsZVN0eWxlc2hlZXRDb2RlR2VuKE1PRFVMRV9VUkwsIHN0eWxlKTtcbiAgICAgICAgcmV0dXJuIFByb21pc2VXcmFwcGVyLmFsbChzb3VyY2VNb2R1bGVzLm1hcChzb3VyY2VNb2R1bGUgPT4ge1xuICAgICAgICAgIHZhciBzb3VyY2VXaXRoSW1wb3J0cyA9IHRlc3RhYmxlTW9kdWxlKHNvdXJjZU1vZHVsZSkuZ2V0U291cmNlV2l0aEltcG9ydHMoKTtcbiAgICAgICAgICByZXR1cm4gZXZhbE1vZHVsZShzb3VyY2VXaXRoSW1wb3J0cy5zb3VyY2UsIHNvdXJjZVdpdGhJbXBvcnRzLmltcG9ydHMsIG51bGwpO1xuICAgICAgICB9KSk7XG4gICAgICB9XG5cbiAgICAgIGl0KCdzaG91bGQgY29tcGlsZSBwbGFpbiBjc3MgcnVsZXMnLCBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgICBjb21waWxlKCdkaXYge2NvbG9yOiByZWQ7fScpXG4gICAgICAgICAgICAgICAudGhlbihzdHlsZXNBbmRTaGltU3R5bGVzID0+IHtcbiAgICAgICAgICAgICAgICAgdmFyIGV4cGVjdGVkID0gW1snZGl2IHtjb2xvcjogcmVkO30nXSwgWydkaXZbX25nY29udGVudC0lQ09NUCVdIHtjb2xvcjogcmVkO30nXV07XG4gICAgICAgICAgICAgICAgIGNvbXBhcmVTdHlsZXMoc3R5bGVzQW5kU2hpbVN0eWxlc1swXSwgZXhwZWN0ZWRbMF0pO1xuICAgICAgICAgICAgICAgICBjb21wYXJlU3R5bGVzKHN0eWxlc0FuZFNoaW1TdHlsZXNbMV0sIGV4cGVjdGVkWzFdKTtcbiAgICAgICAgICAgICAgICAgYXN5bmMuZG9uZSgpO1xuICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgYWxsb3cgdG8gaW1wb3J0IHJ1bGVzIHdpdGggcmVsYXRpdmUgcGF0aHMnLFxuICAgICAgICAgaW5qZWN0KFtBc3luY1Rlc3RDb21wbGV0ZXJdLCAoYXN5bmMpID0+IHtcbiAgICAgICAgICAgY29tcGlsZShgZGl2IHtjb2xvcjogcmVkfUBpbXBvcnQgJHtJTVBPUlRfUkVMX1NUWUxFU0hFRVRfVVJMfTtgKVxuICAgICAgICAgICAgICAgLnRoZW4oc3R5bGVzQW5kU2hpbVN0eWxlcyA9PiB7XG4gICAgICAgICAgICAgICAgIHZhciBleHBlY3RlZCA9IFtcbiAgICAgICAgICAgICAgICAgICBbJ2RpdiB7Y29sb3I6IHJlZH0nLCBbJ3NwYW4ge2NvbG9yOiBibHVlfSddXSxcbiAgICAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICAgICAnZGl2W19uZ2NvbnRlbnQtJUNPTVAlXSB7Y29sb3I6IHJlZH0nLFxuICAgICAgICAgICAgICAgICAgICAgWydzcGFuW19uZ2NvbnRlbnQtJUNPTVAlXSB7XFxuY29sb3I6IGJsdWU7XFxufSddXG4gICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICBdO1xuICAgICAgICAgICAgICAgICBjb21wYXJlU3R5bGVzKHN0eWxlc0FuZFNoaW1TdHlsZXNbMF0sIGV4cGVjdGVkWzBdKTtcbiAgICAgICAgICAgICAgICAgY29tcGFyZVN0eWxlcyhzdHlsZXNBbmRTaGltU3R5bGVzWzFdLCBleHBlY3RlZFsxXSk7XG4gICAgICAgICAgICAgICAgIGFzeW5jLmRvbmUoKTtcbiAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgfSkpO1xuICAgIH0pO1xuICB9KTtcbn1cblxuXG5mdW5jdGlvbiB0ZXN0YWJsZUV4cHJlc3Npb24oc291cmNlOiBTb3VyY2VFeHByZXNzaW9uKTogU291cmNlTW9kdWxlIHtcbiAgdmFyIHRlc3RhYmxlU291cmNlID0gYCR7c291cmNlLmRlY2xhcmF0aW9ucy5qb2luKCdcXG4nKX1cbiAgJHtjb2RlR2VuVmFsdWVGbihbJ18nXSwgc291cmNlLmV4cHJlc3Npb24sICdfcnVuJyl9O1xuICAke2NvZGVHZW5FeHBvcnRWYXJpYWJsZSgncnVuJyl9X3J1bjtgO1xuICByZXR1cm4gbmV3IFNvdXJjZU1vZHVsZShudWxsLCB0ZXN0YWJsZVNvdXJjZSk7XG59XG5cbmZ1bmN0aW9uIHRlc3RhYmxlTW9kdWxlKHNvdXJjZU1vZHVsZTogU291cmNlTW9kdWxlKTogU291cmNlTW9kdWxlIHtcbiAgdmFyIHRlc3RhYmxlU291cmNlID0gYCR7c291cmNlTW9kdWxlLnNvdXJjZVdpdGhNb2R1bGVSZWZzfVxuICAke2NvZGVHZW5WYWx1ZUZuKFsnXyddLCAnU1RZTEVTJywgJ19ydW4nKX07XG4gICR7Y29kZUdlbkV4cG9ydFZhcmlhYmxlKCdydW4nKX1fcnVuO2A7XG4gIHJldHVybiBuZXcgU291cmNlTW9kdWxlKHNvdXJjZU1vZHVsZS5tb2R1bGVVcmwsIHRlc3RhYmxlU291cmNlKTtcbn1cblxuLy8gTmVlZGVkIGZvciBBbmRyb2lkIGJyb3dzZXJzIHdoaWNoIGFkZCBhbiBleHRyYSBzcGFjZSBhdCB0aGUgZW5kIG9mIHNvbWUgbGluZXNcbmZ1bmN0aW9uIGNvbXBhcmVTdHlsZXMoc3R5bGVzOiBBcnJheTxzdHJpbmcgfCBhbnlbXT4sIGV4cGVjdGVkU3R5bGVzOiBBcnJheTxzdHJpbmcgfCBhbnlbXT4pIHtcbiAgZXhwZWN0KHN0eWxlcy5sZW5ndGgpLnRvRXF1YWwoZXhwZWN0ZWRTdHlsZXMubGVuZ3RoKTtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBzdHlsZXMubGVuZ3RoOyBpKyspIHtcbiAgICB2YXIgc3R5bGUgPSBzdHlsZXNbaV07XG4gICAgaWYgKGlzQXJyYXkoc3R5bGUpKSB7XG4gICAgICBjb21wYXJlU3R5bGVzKDxhbnlbXT5zdHlsZSwgPGFueVtdPmV4cGVjdGVkU3R5bGVzW2ldKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZXhwZWN0KFN0cmluZ1dyYXBwZXIucmVwbGFjZUFsbCg8c3RyaW5nPnN0eWxlLCAvXFxzK1xcbi9nLCAnXFxuJykpLnRvRXF1YWwoZXhwZWN0ZWRTdHlsZXNbaV0pO1xuICAgIH1cbiAgfVxufVxuIl19
 main(); 
