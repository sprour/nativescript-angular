export declare const STYLES: string[];
