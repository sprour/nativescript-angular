'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var lang_1 = require('angular2/src/facade/lang');
var runtime_metadata_1 = require('angular2/src/compiler/runtime_metadata');
var interfaces_1 = require('angular2/src/core/linker/interfaces');
var core_1 = require('angular2/core');
var test_bindings_1 = require('./test_bindings');
var util_1 = require('angular2/src/compiler/util');
var lang_2 = require('angular2/src/facade/lang');
var platform_directives_and_pipes_1 = require('angular2/src/core/platform_directives_and_pipes');
var runtime_metadata_fixture_1 = require('./runtime_metadata_fixture');
function main() {
    testing_internal_1.describe('RuntimeMetadataResolver', function () {
        testing_internal_1.beforeEachProviders(function () { return test_bindings_1.TEST_PROVIDERS; });
        testing_internal_1.describe('getMetadata', function () {
            testing_internal_1.it('should read metadata', testing_internal_1.inject([runtime_metadata_1.RuntimeMetadataResolver], function (resolver) {
                var meta = resolver.getDirectiveMetadata(ComponentWithEverything);
                testing_internal_1.expect(meta.selector).toEqual('someSelector');
                testing_internal_1.expect(meta.exportAs).toEqual('someExportAs');
                testing_internal_1.expect(meta.isComponent).toBe(true);
                testing_internal_1.expect(meta.dynamicLoadable).toBe(true);
                testing_internal_1.expect(meta.type.runtime).toBe(ComponentWithEverything);
                testing_internal_1.expect(meta.type.name).toEqual(lang_1.stringify(ComponentWithEverything));
                testing_internal_1.expect(meta.type.moduleUrl).toEqual("package:someModuleId" + util_1.MODULE_SUFFIX);
                testing_internal_1.expect(meta.lifecycleHooks).toEqual(interfaces_1.LIFECYCLE_HOOKS_VALUES);
                testing_internal_1.expect(meta.changeDetection).toBe(core_1.ChangeDetectionStrategy.CheckAlways);
                testing_internal_1.expect(meta.inputs).toEqual({ 'someProp': 'someProp' });
                testing_internal_1.expect(meta.outputs).toEqual({ 'someEvent': 'someEvent' });
                testing_internal_1.expect(meta.hostListeners).toEqual({ 'someHostListener': 'someHostListenerExpr' });
                testing_internal_1.expect(meta.hostProperties).toEqual({ 'someHostProp': 'someHostPropExpr' });
                testing_internal_1.expect(meta.hostAttributes).toEqual({ 'someHostAttr': 'someHostAttrValue' });
                testing_internal_1.expect(meta.template.encapsulation).toBe(core_1.ViewEncapsulation.Emulated);
                testing_internal_1.expect(meta.template.styles).toEqual(['someStyle']);
                testing_internal_1.expect(meta.template.styleUrls).toEqual(['someStyleUrl']);
                testing_internal_1.expect(meta.template.template).toEqual('someTemplate');
                testing_internal_1.expect(meta.template.templateUrl).toEqual('someTemplateUrl');
            }));
            testing_internal_1.it('should use the moduleUrl from the reflector if none is given', testing_internal_1.inject([runtime_metadata_1.RuntimeMetadataResolver], function (resolver) {
                var value = resolver.getDirectiveMetadata(ComponentWithoutModuleId).type.moduleUrl;
                var expectedEndValue = lang_2.IS_DART ? 'test/compiler/runtime_metadata_spec.dart' : './';
                testing_internal_1.expect(value.endsWith(expectedEndValue)).toBe(true);
            }));
            testing_internal_1.it('should throw when metadata is incorrectly typed', testing_internal_1.inject([runtime_metadata_1.RuntimeMetadataResolver], function (resolver) {
                if (!lang_2.IS_DART) {
                    testing_internal_1.expect(function () { return resolver.getDirectiveMetadata(runtime_metadata_fixture_1.MalformedStylesComponent); })
                        .toThrowError("Expected 'styles' to be an array of strings.");
                }
            }));
        });
        testing_internal_1.describe('getViewDirectivesMetadata', function () {
            testing_internal_1.it('should return the directive metadatas', testing_internal_1.inject([runtime_metadata_1.RuntimeMetadataResolver], function (resolver) {
                testing_internal_1.expect(resolver.getViewDirectivesMetadata(ComponentWithEverything))
                    .toContain(resolver.getDirectiveMetadata(SomeDirective));
            }));
            testing_internal_1.describe("platform directives", function () {
                testing_internal_1.beforeEachProviders(function () { return [core_1.provide(platform_directives_and_pipes_1.PLATFORM_DIRECTIVES, { useValue: [ADirective], multi: true })]; });
                testing_internal_1.it('should include platform directives when available', testing_internal_1.inject([runtime_metadata_1.RuntimeMetadataResolver], function (resolver) {
                    testing_internal_1.expect(resolver.getViewDirectivesMetadata(ComponentWithEverything))
                        .toContain(resolver.getDirectiveMetadata(ADirective));
                    testing_internal_1.expect(resolver.getViewDirectivesMetadata(ComponentWithEverything))
                        .toContain(resolver.getDirectiveMetadata(SomeDirective));
                }));
            });
        });
    });
}
exports.main = main;
var ADirective = (function () {
    function ADirective() {
    }
    ADirective = __decorate([
        core_1.Directive({ selector: 'a-directive' }), 
        __metadata('design:paramtypes', [])
    ], ADirective);
    return ADirective;
})();
var SomeDirective = (function () {
    function SomeDirective() {
    }
    SomeDirective = __decorate([
        core_1.Directive({ selector: 'someSelector' }), 
        __metadata('design:paramtypes', [])
    ], SomeDirective);
    return SomeDirective;
})();
var ComponentWithoutModuleId = (function () {
    function ComponentWithoutModuleId() {
    }
    ComponentWithoutModuleId = __decorate([
        core_1.Component({ selector: 'someComponent', template: '' }), 
        __metadata('design:paramtypes', [])
    ], ComponentWithoutModuleId);
    return ComponentWithoutModuleId;
})();
var ComponentWithEverything = (function () {
    function ComponentWithEverything() {
    }
    ComponentWithEverything.prototype.ngOnChanges = function (changes) { };
    ComponentWithEverything.prototype.ngOnInit = function () { };
    ComponentWithEverything.prototype.ngDoCheck = function () { };
    ComponentWithEverything.prototype.ngOnDestroy = function () { };
    ComponentWithEverything.prototype.ngAfterContentInit = function () { };
    ComponentWithEverything.prototype.ngAfterContentChecked = function () { };
    ComponentWithEverything.prototype.ngAfterViewInit = function () { };
    ComponentWithEverything.prototype.ngAfterViewChecked = function () { };
    ComponentWithEverything = __decorate([
        core_1.Component({
            selector: 'someSelector',
            inputs: ['someProp'],
            outputs: ['someEvent'],
            host: {
                '[someHostProp]': 'someHostPropExpr',
                '(someHostListener)': 'someHostListenerExpr',
                'someHostAttr': 'someHostAttrValue'
            },
            exportAs: 'someExportAs',
            moduleId: 'someModuleId',
            changeDetection: core_1.ChangeDetectionStrategy.CheckAlways,
            template: 'someTemplate',
            templateUrl: 'someTemplateUrl',
            encapsulation: core_1.ViewEncapsulation.Emulated,
            styles: ['someStyle'],
            styleUrls: ['someStyleUrl'],
            directives: [SomeDirective]
        }), 
        __metadata('design:paramtypes', [])
    ], ComponentWithEverything);
    return ComponentWithEverything;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicnVudGltZV9tZXRhZGF0YV9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb21waWxlci9ydW50aW1lX21ldGFkYXRhX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiIsIkFEaXJlY3RpdmUiLCJBRGlyZWN0aXZlLmNvbnN0cnVjdG9yIiwiU29tZURpcmVjdGl2ZSIsIlNvbWVEaXJlY3RpdmUuY29uc3RydWN0b3IiLCJDb21wb25lbnRXaXRob3V0TW9kdWxlSWQiLCJDb21wb25lbnRXaXRob3V0TW9kdWxlSWQuY29uc3RydWN0b3IiLCJDb21wb25lbnRXaXRoRXZlcnl0aGluZyIsIkNvbXBvbmVudFdpdGhFdmVyeXRoaW5nLmNvbnN0cnVjdG9yIiwiQ29tcG9uZW50V2l0aEV2ZXJ5dGhpbmcubmdPbkNoYW5nZXMiLCJDb21wb25lbnRXaXRoRXZlcnl0aGluZy5uZ09uSW5pdCIsIkNvbXBvbmVudFdpdGhFdmVyeXRoaW5nLm5nRG9DaGVjayIsIkNvbXBvbmVudFdpdGhFdmVyeXRoaW5nLm5nT25EZXN0cm95IiwiQ29tcG9uZW50V2l0aEV2ZXJ5dGhpbmcubmdBZnRlckNvbnRlbnRJbml0IiwiQ29tcG9uZW50V2l0aEV2ZXJ5dGhpbmcubmdBZnRlckNvbnRlbnRDaGVja2VkIiwiQ29tcG9uZW50V2l0aEV2ZXJ5dGhpbmcubmdBZnRlclZpZXdJbml0IiwiQ29tcG9uZW50V2l0aEV2ZXJ5dGhpbmcubmdBZnRlclZpZXdDaGVja2VkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxpQ0FhTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLHFCQUF3QiwwQkFBMEIsQ0FBQyxDQUFBO0FBQ25ELGlDQUFzQyx3Q0FBd0MsQ0FBQyxDQUFBO0FBQy9FLDJCQUFxRCxxQ0FBcUMsQ0FBQyxDQUFBO0FBQzNGLHFCQWVPLGVBQWUsQ0FBQyxDQUFBO0FBRXZCLDhCQUE2QixpQkFBaUIsQ0FBQyxDQUFBO0FBQy9DLHFCQUE0Qiw0QkFBNEIsQ0FBQyxDQUFBO0FBQ3pELHFCQUFzQiwwQkFBMEIsQ0FBQyxDQUFBO0FBQ2pELDhDQUFrQyxpREFBaUQsQ0FBQyxDQUFBO0FBQ3BGLHlDQUF1Qyw0QkFBNEIsQ0FBQyxDQUFBO0FBRXBFO0lBQ0VBLDJCQUFRQSxDQUFDQSx5QkFBeUJBLEVBQUVBO1FBQ2xDQSxzQ0FBbUJBLENBQUNBLGNBQU1BLE9BQUFBLDhCQUFjQSxFQUFkQSxDQUFjQSxDQUFDQSxDQUFDQTtRQUUxQ0EsMkJBQVFBLENBQUNBLGFBQWFBLEVBQUVBO1lBQ3RCQSxxQkFBRUEsQ0FBQ0Esc0JBQXNCQSxFQUN0QkEseUJBQU1BLENBQUNBLENBQUNBLDBDQUF1QkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsUUFBaUNBO2dCQUNsRUEsSUFBSUEsSUFBSUEsR0FBR0EsUUFBUUEsQ0FBQ0Esb0JBQW9CQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBO2dCQUNsRUEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLGNBQWNBLENBQUNBLENBQUNBO2dCQUM5Q0EseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLGNBQWNBLENBQUNBLENBQUNBO2dCQUM5Q0EseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO2dCQUNwQ0EseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLGVBQWVBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO2dCQUN4Q0EseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLElBQUlBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3hEQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsZ0JBQVNBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ25FQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EseUJBQXVCQSxvQkFBZUEsQ0FBQ0EsQ0FBQ0E7Z0JBQzVFQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsY0FBY0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsbUNBQXNCQSxDQUFDQSxDQUFDQTtnQkFDNURBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxlQUFlQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSw4QkFBdUJBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO2dCQUN2RUEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEVBQUNBLFVBQVVBLEVBQUVBLFVBQVVBLEVBQUNBLENBQUNBLENBQUNBO2dCQUN0REEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEVBQUNBLFdBQVdBLEVBQUVBLFdBQVdBLEVBQUNBLENBQUNBLENBQUNBO2dCQUN6REEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLGFBQWFBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEVBQUNBLGtCQUFrQkEsRUFBRUEsc0JBQXNCQSxFQUFDQSxDQUFDQSxDQUFDQTtnQkFDakZBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxFQUFDQSxjQUFjQSxFQUFFQSxrQkFBa0JBLEVBQUNBLENBQUNBLENBQUNBO2dCQUMxRUEseUJBQU1BLENBQUNBLElBQUlBLENBQUNBLGNBQWNBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLEVBQUNBLGNBQWNBLEVBQUVBLG1CQUFtQkEsRUFBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzNFQSx5QkFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0Esd0JBQWlCQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtnQkFDckVBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxRQUFRQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDcERBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxRQUFRQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDMURBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxRQUFRQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxjQUFjQSxDQUFDQSxDQUFDQTtnQkFDdkRBLHlCQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxRQUFRQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxpQkFBaUJBLENBQUNBLENBQUNBO1lBQy9EQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVQQSxxQkFBRUEsQ0FBQ0EsOERBQThEQSxFQUM5REEseUJBQU1BLENBQUNBLENBQUNBLDBDQUF1QkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsUUFBaUNBO2dCQUNsRUEsSUFBSUEsS0FBS0EsR0FDTEEsUUFBUUEsQ0FBQ0Esb0JBQW9CQSxDQUFDQSx3QkFBd0JBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLFNBQVNBLENBQUNBO2dCQUMzRUEsSUFBSUEsZ0JBQWdCQSxHQUFHQSxjQUFPQSxHQUFHQSwwQ0FBMENBLEdBQUdBLElBQUlBLENBQUNBO2dCQUNuRkEseUJBQU1BLENBQUNBLEtBQUtBLENBQUNBLFFBQVFBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7WUFDdERBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLHFCQUFFQSxDQUFDQSxpREFBaURBLEVBQ2pEQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EsMENBQXVCQSxDQUFDQSxFQUFFQSxVQUFDQSxRQUFpQ0E7Z0JBQ2xFQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxjQUFPQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDYkEseUJBQU1BLENBQUNBLGNBQU1BLE9BQUFBLFFBQVFBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsbURBQXdCQSxDQUFDQSxFQUF2REEsQ0FBdURBLENBQUNBO3lCQUNoRUEsWUFBWUEsQ0FBQ0EsOENBQThDQSxDQUFDQSxDQUFDQTtnQkFDcEVBLENBQUNBO1lBQ0hBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ1RBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLDJCQUFRQSxDQUFDQSwyQkFBMkJBLEVBQUVBO1lBRXBDQSxxQkFBRUEsQ0FBQ0EsdUNBQXVDQSxFQUN2Q0EseUJBQU1BLENBQUNBLENBQUNBLDBDQUF1QkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsUUFBaUNBO2dCQUNsRUEseUJBQU1BLENBQUNBLFFBQVFBLENBQUNBLHlCQUF5QkEsQ0FBQ0EsdUJBQXVCQSxDQUFDQSxDQUFDQTtxQkFDOURBLFNBQVNBLENBQUNBLFFBQVFBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDL0RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBRVBBLDJCQUFRQSxDQUFDQSxxQkFBcUJBLEVBQUVBO2dCQUM5QkEsc0NBQW1CQSxDQUNmQSxjQUFNQSxPQUFBQSxDQUFDQSxjQUFPQSxDQUFDQSxtREFBbUJBLEVBQUVBLEVBQUNBLFFBQVFBLEVBQUVBLENBQUNBLFVBQVVBLENBQUNBLEVBQUVBLEtBQUtBLEVBQUVBLElBQUlBLEVBQUNBLENBQUNBLENBQUNBLEVBQXJFQSxDQUFxRUEsQ0FBQ0EsQ0FBQ0E7Z0JBRWpGQSxxQkFBRUEsQ0FBQ0EsbURBQW1EQSxFQUNuREEseUJBQU1BLENBQUNBLENBQUNBLDBDQUF1QkEsQ0FBQ0EsRUFBRUEsVUFBQ0EsUUFBaUNBO29CQUNsRUEseUJBQU1BLENBQUNBLFFBQVFBLENBQUNBLHlCQUF5QkEsQ0FBQ0EsdUJBQXVCQSxDQUFDQSxDQUFDQTt5QkFDOURBLFNBQVNBLENBQUNBLFFBQVFBLENBQUNBLG9CQUFvQkEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQzFEQSx5QkFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EseUJBQXlCQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBO3lCQUM5REEsU0FBU0EsQ0FBQ0EsUUFBUUEsQ0FBQ0Esb0JBQW9CQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDL0RBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBO1FBQ0xBLENBQUNBLENBQUNBLENBQUNBO0lBRUxBLENBQUNBLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBckVlLFlBQUksT0FxRW5CLENBQUE7QUFFRDtJQUFBQztJQUVBQyxDQUFDQTtJQUZERDtRQUFDQSxnQkFBU0EsQ0FBQ0EsRUFBQ0EsUUFBUUEsRUFBRUEsYUFBYUEsRUFBQ0EsQ0FBQ0E7O21CQUVwQ0E7SUFBREEsaUJBQUNBO0FBQURBLENBQUNBLEFBRkQsSUFFQztBQUVEO0lBQUFFO0lBRUFDLENBQUNBO0lBRkREO1FBQUNBLGdCQUFTQSxDQUFDQSxFQUFDQSxRQUFRQSxFQUFFQSxjQUFjQSxFQUFDQSxDQUFDQTs7c0JBRXJDQTtJQUFEQSxvQkFBQ0E7QUFBREEsQ0FBQ0EsQUFGRCxJQUVDO0FBRUQ7SUFBQUU7SUFFQUMsQ0FBQ0E7SUFGREQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLGVBQWVBLEVBQUVBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOztpQ0FFcERBO0lBQURBLCtCQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUM7QUFFRDtJQUFBRTtJQThCQUMsQ0FBQ0E7SUFSQ0QsNkNBQVdBLEdBQVhBLFVBQVlBLE9BQXNDQSxJQUFTRSxDQUFDQTtJQUM1REYsMENBQVFBLEdBQVJBLGNBQWtCRyxDQUFDQTtJQUNuQkgsMkNBQVNBLEdBQVRBLGNBQW1CSSxDQUFDQTtJQUNwQkosNkNBQVdBLEdBQVhBLGNBQXFCSyxDQUFDQTtJQUN0Qkwsb0RBQWtCQSxHQUFsQkEsY0FBNEJNLENBQUNBO0lBQzdCTix1REFBcUJBLEdBQXJCQSxjQUErQk8sQ0FBQ0E7SUFDaENQLGlEQUFlQSxHQUFmQSxjQUF5QlEsQ0FBQ0E7SUFDMUJSLG9EQUFrQkEsR0FBbEJBLGNBQTRCUyxDQUFDQTtJQTdCL0JUO1FBQUNBLGdCQUFTQSxDQUFDQTtZQUNUQSxRQUFRQSxFQUFFQSxjQUFjQTtZQUN4QkEsTUFBTUEsRUFBRUEsQ0FBQ0EsVUFBVUEsQ0FBQ0E7WUFDcEJBLE9BQU9BLEVBQUVBLENBQUNBLFdBQVdBLENBQUNBO1lBQ3RCQSxJQUFJQSxFQUFFQTtnQkFDSkEsZ0JBQWdCQSxFQUFFQSxrQkFBa0JBO2dCQUNwQ0Esb0JBQW9CQSxFQUFFQSxzQkFBc0JBO2dCQUM1Q0EsY0FBY0EsRUFBRUEsbUJBQW1CQTthQUNwQ0E7WUFDREEsUUFBUUEsRUFBRUEsY0FBY0E7WUFDeEJBLFFBQVFBLEVBQUVBLGNBQWNBO1lBQ3hCQSxlQUFlQSxFQUFFQSw4QkFBdUJBLENBQUNBLFdBQVdBO1lBQ3BEQSxRQUFRQSxFQUFFQSxjQUFjQTtZQUN4QkEsV0FBV0EsRUFBRUEsaUJBQWlCQTtZQUM5QkEsYUFBYUEsRUFBRUEsd0JBQWlCQSxDQUFDQSxRQUFRQTtZQUN6Q0EsTUFBTUEsRUFBRUEsQ0FBQ0EsV0FBV0EsQ0FBQ0E7WUFDckJBLFNBQVNBLEVBQUVBLENBQUNBLGNBQWNBLENBQUNBO1lBQzNCQSxVQUFVQSxFQUFFQSxDQUFDQSxhQUFhQSxDQUFDQTtTQUM1QkEsQ0FBQ0E7O2dDQVlEQTtJQUFEQSw4QkFBQ0E7QUFBREEsQ0FBQ0EsQUE5QkQsSUE4QkMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBkZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICB4ZGVzY3JpYmUsXG4gIGl0LFxuICBpaXQsXG4gIHhpdCxcbiAgZXhwZWN0LFxuICBiZWZvcmVFYWNoLFxuICBhZnRlckVhY2gsXG4gIEFzeW5jVGVzdENvbXBsZXRlcixcbiAgaW5qZWN0LFxuICBiZWZvcmVFYWNoUHJvdmlkZXJzXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5pbXBvcnQge3N0cmluZ2lmeX0gZnJvbSAnYW5ndWxhcjIvc3JjL2ZhY2FkZS9sYW5nJztcbmltcG9ydCB7UnVudGltZU1ldGFkYXRhUmVzb2x2ZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb21waWxlci9ydW50aW1lX21ldGFkYXRhJztcbmltcG9ydCB7TGlmZWN5Y2xlSG9va3MsIExJRkVDWUNMRV9IT09LU19WQUxVRVN9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci9pbnRlcmZhY2VzJztcbmltcG9ydCB7XG4gIENvbXBvbmVudCxcbiAgRGlyZWN0aXZlLFxuICBWaWV3RW5jYXBzdWxhdGlvbixcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIE9uQ2hhbmdlcyxcbiAgT25Jbml0LFxuICBEb0NoZWNrLFxuICBPbkRlc3Ryb3ksXG4gIEFmdGVyQ29udGVudEluaXQsXG4gIEFmdGVyQ29udGVudENoZWNrZWQsXG4gIEFmdGVyVmlld0luaXQsXG4gIEFmdGVyVmlld0NoZWNrZWQsXG4gIFNpbXBsZUNoYW5nZSxcbiAgcHJvdmlkZVxufSBmcm9tICdhbmd1bGFyMi9jb3JlJztcblxuaW1wb3J0IHtURVNUX1BST1ZJREVSU30gZnJvbSAnLi90ZXN0X2JpbmRpbmdzJztcbmltcG9ydCB7TU9EVUxFX1NVRkZJWH0gZnJvbSAnYW5ndWxhcjIvc3JjL2NvbXBpbGVyL3V0aWwnO1xuaW1wb3J0IHtJU19EQVJUfSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2xhbmcnO1xuaW1wb3J0IHtQTEFURk9STV9ESVJFQ1RJVkVTfSBmcm9tICdhbmd1bGFyMi9zcmMvY29yZS9wbGF0Zm9ybV9kaXJlY3RpdmVzX2FuZF9waXBlcyc7XG5pbXBvcnQge01hbGZvcm1lZFN0eWxlc0NvbXBvbmVudH0gZnJvbSAnLi9ydW50aW1lX21ldGFkYXRhX2ZpeHR1cmUnO1xuXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpIHtcbiAgZGVzY3JpYmUoJ1J1bnRpbWVNZXRhZGF0YVJlc29sdmVyJywgKCkgPT4ge1xuICAgIGJlZm9yZUVhY2hQcm92aWRlcnMoKCkgPT4gVEVTVF9QUk9WSURFUlMpO1xuXG4gICAgZGVzY3JpYmUoJ2dldE1ldGFkYXRhJywgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCByZWFkIG1ldGFkYXRhJyxcbiAgICAgICAgIGluamVjdChbUnVudGltZU1ldGFkYXRhUmVzb2x2ZXJdLCAocmVzb2x2ZXI6IFJ1bnRpbWVNZXRhZGF0YVJlc29sdmVyKSA9PiB7XG4gICAgICAgICAgIHZhciBtZXRhID0gcmVzb2x2ZXIuZ2V0RGlyZWN0aXZlTWV0YWRhdGEoQ29tcG9uZW50V2l0aEV2ZXJ5dGhpbmcpO1xuICAgICAgICAgICBleHBlY3QobWV0YS5zZWxlY3RvcikudG9FcXVhbCgnc29tZVNlbGVjdG9yJyk7XG4gICAgICAgICAgIGV4cGVjdChtZXRhLmV4cG9ydEFzKS50b0VxdWFsKCdzb21lRXhwb3J0QXMnKTtcbiAgICAgICAgICAgZXhwZWN0KG1ldGEuaXNDb21wb25lbnQpLnRvQmUodHJ1ZSk7XG4gICAgICAgICAgIGV4cGVjdChtZXRhLmR5bmFtaWNMb2FkYWJsZSkudG9CZSh0cnVlKTtcbiAgICAgICAgICAgZXhwZWN0KG1ldGEudHlwZS5ydW50aW1lKS50b0JlKENvbXBvbmVudFdpdGhFdmVyeXRoaW5nKTtcbiAgICAgICAgICAgZXhwZWN0KG1ldGEudHlwZS5uYW1lKS50b0VxdWFsKHN0cmluZ2lmeShDb21wb25lbnRXaXRoRXZlcnl0aGluZykpO1xuICAgICAgICAgICBleHBlY3QobWV0YS50eXBlLm1vZHVsZVVybCkudG9FcXVhbChgcGFja2FnZTpzb21lTW9kdWxlSWQke01PRFVMRV9TVUZGSVh9YCk7XG4gICAgICAgICAgIGV4cGVjdChtZXRhLmxpZmVjeWNsZUhvb2tzKS50b0VxdWFsKExJRkVDWUNMRV9IT09LU19WQUxVRVMpO1xuICAgICAgICAgICBleHBlY3QobWV0YS5jaGFuZ2VEZXRlY3Rpb24pLnRvQmUoQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuQ2hlY2tBbHdheXMpO1xuICAgICAgICAgICBleHBlY3QobWV0YS5pbnB1dHMpLnRvRXF1YWwoeydzb21lUHJvcCc6ICdzb21lUHJvcCd9KTtcbiAgICAgICAgICAgZXhwZWN0KG1ldGEub3V0cHV0cykudG9FcXVhbCh7J3NvbWVFdmVudCc6ICdzb21lRXZlbnQnfSk7XG4gICAgICAgICAgIGV4cGVjdChtZXRhLmhvc3RMaXN0ZW5lcnMpLnRvRXF1YWwoeydzb21lSG9zdExpc3RlbmVyJzogJ3NvbWVIb3N0TGlzdGVuZXJFeHByJ30pO1xuICAgICAgICAgICBleHBlY3QobWV0YS5ob3N0UHJvcGVydGllcykudG9FcXVhbCh7J3NvbWVIb3N0UHJvcCc6ICdzb21lSG9zdFByb3BFeHByJ30pO1xuICAgICAgICAgICBleHBlY3QobWV0YS5ob3N0QXR0cmlidXRlcykudG9FcXVhbCh7J3NvbWVIb3N0QXR0cic6ICdzb21lSG9zdEF0dHJWYWx1ZSd9KTtcbiAgICAgICAgICAgZXhwZWN0KG1ldGEudGVtcGxhdGUuZW5jYXBzdWxhdGlvbikudG9CZShWaWV3RW5jYXBzdWxhdGlvbi5FbXVsYXRlZCk7XG4gICAgICAgICAgIGV4cGVjdChtZXRhLnRlbXBsYXRlLnN0eWxlcykudG9FcXVhbChbJ3NvbWVTdHlsZSddKTtcbiAgICAgICAgICAgZXhwZWN0KG1ldGEudGVtcGxhdGUuc3R5bGVVcmxzKS50b0VxdWFsKFsnc29tZVN0eWxlVXJsJ10pO1xuICAgICAgICAgICBleHBlY3QobWV0YS50ZW1wbGF0ZS50ZW1wbGF0ZSkudG9FcXVhbCgnc29tZVRlbXBsYXRlJyk7XG4gICAgICAgICAgIGV4cGVjdChtZXRhLnRlbXBsYXRlLnRlbXBsYXRlVXJsKS50b0VxdWFsKCdzb21lVGVtcGxhdGVVcmwnKTtcbiAgICAgICAgIH0pKTtcblxuICAgICAgaXQoJ3Nob3VsZCB1c2UgdGhlIG1vZHVsZVVybCBmcm9tIHRoZSByZWZsZWN0b3IgaWYgbm9uZSBpcyBnaXZlbicsXG4gICAgICAgICBpbmplY3QoW1J1bnRpbWVNZXRhZGF0YVJlc29sdmVyXSwgKHJlc29sdmVyOiBSdW50aW1lTWV0YWRhdGFSZXNvbHZlcikgPT4ge1xuICAgICAgICAgICB2YXIgdmFsdWU6IHN0cmluZyA9XG4gICAgICAgICAgICAgICByZXNvbHZlci5nZXREaXJlY3RpdmVNZXRhZGF0YShDb21wb25lbnRXaXRob3V0TW9kdWxlSWQpLnR5cGUubW9kdWxlVXJsO1xuICAgICAgICAgICB2YXIgZXhwZWN0ZWRFbmRWYWx1ZSA9IElTX0RBUlQgPyAndGVzdC9jb21waWxlci9ydW50aW1lX21ldGFkYXRhX3NwZWMuZGFydCcgOiAnLi8nO1xuICAgICAgICAgICBleHBlY3QodmFsdWUuZW5kc1dpdGgoZXhwZWN0ZWRFbmRWYWx1ZSkpLnRvQmUodHJ1ZSk7XG4gICAgICAgICB9KSk7XG5cbiAgICAgIGl0KCdzaG91bGQgdGhyb3cgd2hlbiBtZXRhZGF0YSBpcyBpbmNvcnJlY3RseSB0eXBlZCcsXG4gICAgICAgICBpbmplY3QoW1J1bnRpbWVNZXRhZGF0YVJlc29sdmVyXSwgKHJlc29sdmVyOiBSdW50aW1lTWV0YWRhdGFSZXNvbHZlcikgPT4ge1xuICAgICAgICAgICBpZiAoIUlTX0RBUlQpIHtcbiAgICAgICAgICAgICBleHBlY3QoKCkgPT4gcmVzb2x2ZXIuZ2V0RGlyZWN0aXZlTWV0YWRhdGEoTWFsZm9ybWVkU3R5bGVzQ29tcG9uZW50KSlcbiAgICAgICAgICAgICAgICAgLnRvVGhyb3dFcnJvcihgRXhwZWN0ZWQgJ3N0eWxlcycgdG8gYmUgYW4gYXJyYXkgb2Ygc3RyaW5ncy5gKTtcbiAgICAgICAgICAgfVxuICAgICAgICAgfSkpO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ2dldFZpZXdEaXJlY3RpdmVzTWV0YWRhdGEnLCAoKSA9PiB7XG5cbiAgICAgIGl0KCdzaG91bGQgcmV0dXJuIHRoZSBkaXJlY3RpdmUgbWV0YWRhdGFzJyxcbiAgICAgICAgIGluamVjdChbUnVudGltZU1ldGFkYXRhUmVzb2x2ZXJdLCAocmVzb2x2ZXI6IFJ1bnRpbWVNZXRhZGF0YVJlc29sdmVyKSA9PiB7XG4gICAgICAgICAgIGV4cGVjdChyZXNvbHZlci5nZXRWaWV3RGlyZWN0aXZlc01ldGFkYXRhKENvbXBvbmVudFdpdGhFdmVyeXRoaW5nKSlcbiAgICAgICAgICAgICAgIC50b0NvbnRhaW4ocmVzb2x2ZXIuZ2V0RGlyZWN0aXZlTWV0YWRhdGEoU29tZURpcmVjdGl2ZSkpO1xuICAgICAgICAgfSkpO1xuXG4gICAgICBkZXNjcmliZShcInBsYXRmb3JtIGRpcmVjdGl2ZXNcIiwgKCkgPT4ge1xuICAgICAgICBiZWZvcmVFYWNoUHJvdmlkZXJzKFxuICAgICAgICAgICAgKCkgPT4gW3Byb3ZpZGUoUExBVEZPUk1fRElSRUNUSVZFUywge3VzZVZhbHVlOiBbQURpcmVjdGl2ZV0sIG11bHRpOiB0cnVlfSldKTtcblxuICAgICAgICBpdCgnc2hvdWxkIGluY2x1ZGUgcGxhdGZvcm0gZGlyZWN0aXZlcyB3aGVuIGF2YWlsYWJsZScsXG4gICAgICAgICAgIGluamVjdChbUnVudGltZU1ldGFkYXRhUmVzb2x2ZXJdLCAocmVzb2x2ZXI6IFJ1bnRpbWVNZXRhZGF0YVJlc29sdmVyKSA9PiB7XG4gICAgICAgICAgICAgZXhwZWN0KHJlc29sdmVyLmdldFZpZXdEaXJlY3RpdmVzTWV0YWRhdGEoQ29tcG9uZW50V2l0aEV2ZXJ5dGhpbmcpKVxuICAgICAgICAgICAgICAgICAudG9Db250YWluKHJlc29sdmVyLmdldERpcmVjdGl2ZU1ldGFkYXRhKEFEaXJlY3RpdmUpKTtcbiAgICAgICAgICAgICBleHBlY3QocmVzb2x2ZXIuZ2V0Vmlld0RpcmVjdGl2ZXNNZXRhZGF0YShDb21wb25lbnRXaXRoRXZlcnl0aGluZykpXG4gICAgICAgICAgICAgICAgIC50b0NvbnRhaW4ocmVzb2x2ZXIuZ2V0RGlyZWN0aXZlTWV0YWRhdGEoU29tZURpcmVjdGl2ZSkpO1xuICAgICAgICAgICB9KSk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICB9KTtcbn1cblxuQERpcmVjdGl2ZSh7c2VsZWN0b3I6ICdhLWRpcmVjdGl2ZSd9KVxuY2xhc3MgQURpcmVjdGl2ZSB7XG59XG5cbkBEaXJlY3RpdmUoe3NlbGVjdG9yOiAnc29tZVNlbGVjdG9yJ30pXG5jbGFzcyBTb21lRGlyZWN0aXZlIHtcbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdzb21lQ29tcG9uZW50JywgdGVtcGxhdGU6ICcnfSlcbmNsYXNzIENvbXBvbmVudFdpdGhvdXRNb2R1bGVJZCB7XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ3NvbWVTZWxlY3RvcicsXG4gIGlucHV0czogWydzb21lUHJvcCddLFxuICBvdXRwdXRzOiBbJ3NvbWVFdmVudCddLFxuICBob3N0OiB7XG4gICAgJ1tzb21lSG9zdFByb3BdJzogJ3NvbWVIb3N0UHJvcEV4cHInLFxuICAgICcoc29tZUhvc3RMaXN0ZW5lciknOiAnc29tZUhvc3RMaXN0ZW5lckV4cHInLFxuICAgICdzb21lSG9zdEF0dHInOiAnc29tZUhvc3RBdHRyVmFsdWUnXG4gIH0sXG4gIGV4cG9ydEFzOiAnc29tZUV4cG9ydEFzJyxcbiAgbW9kdWxlSWQ6ICdzb21lTW9kdWxlSWQnLFxuICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5LkNoZWNrQWx3YXlzLFxuICB0ZW1wbGF0ZTogJ3NvbWVUZW1wbGF0ZScsXG4gIHRlbXBsYXRlVXJsOiAnc29tZVRlbXBsYXRlVXJsJyxcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uRW11bGF0ZWQsXG4gIHN0eWxlczogWydzb21lU3R5bGUnXSxcbiAgc3R5bGVVcmxzOiBbJ3NvbWVTdHlsZVVybCddLFxuICBkaXJlY3RpdmVzOiBbU29tZURpcmVjdGl2ZV1cbn0pXG5jbGFzcyBDb21wb25lbnRXaXRoRXZlcnl0aGluZyBpbXBsZW1lbnRzIE9uQ2hhbmdlcyxcbiAgICBPbkluaXQsIERvQ2hlY2ssIE9uRGVzdHJveSwgQWZ0ZXJDb250ZW50SW5pdCwgQWZ0ZXJDb250ZW50Q2hlY2tlZCwgQWZ0ZXJWaWV3SW5pdCxcbiAgICBBZnRlclZpZXdDaGVja2VkIHtcbiAgbmdPbkNoYW5nZXMoY2hhbmdlczoge1trZXk6IHN0cmluZ106IFNpbXBsZUNoYW5nZX0pOiB2b2lkIHt9XG4gIG5nT25Jbml0KCk6IHZvaWQge31cbiAgbmdEb0NoZWNrKCk6IHZvaWQge31cbiAgbmdPbkRlc3Ryb3koKTogdm9pZCB7fVxuICBuZ0FmdGVyQ29udGVudEluaXQoKTogdm9pZCB7fVxuICBuZ0FmdGVyQ29udGVudENoZWNrZWQoKTogdm9pZCB7fVxuICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7fVxuICBuZ0FmdGVyVmlld0NoZWNrZWQoKTogdm9pZCB7fVxufVxuIl19
 main(); 
