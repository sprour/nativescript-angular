'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var testing_internal_1 = require('angular2/testing_internal');
var core_1 = require('angular2/core');
var async_1 = require('angular2/src/facade/async');
var spies_1 = require('./spies');
var compiler_1 = require('angular2/src/compiler/compiler');
var runtime_compiler_1 = require('angular2/src/compiler/runtime_compiler');
var view_1 = require('angular2/src/core/linker/view');
function main() {
    testing_internal_1.describe('RuntimeCompiler', function () {
        var compiler;
        var templateCompilerSpy;
        var someHostViewFactory;
        testing_internal_1.beforeEachProviders(function () {
            templateCompilerSpy = new spies_1.SpyTemplateCompiler();
            someHostViewFactory = new view_1.HostViewFactory(null, null);
            templateCompilerSpy.spy('compileHostComponentRuntime')
                .andReturn(async_1.PromiseWrapper.resolve(someHostViewFactory));
            return [core_1.provide(compiler_1.TemplateCompiler, { useValue: templateCompilerSpy })];
        });
        testing_internal_1.beforeEach(testing_internal_1.inject([runtime_compiler_1.RuntimeCompiler], function (_compiler) { compiler = _compiler; }));
        testing_internal_1.it('compileInHost should compile the template via TemplateCompiler', testing_internal_1.inject([testing_internal_1.AsyncTestCompleter], function (async) {
            compiler.compileInHost(SomeComponent)
                .then(function (hostViewFactoryRef) {
                testing_internal_1.expect(hostViewFactoryRef.internalHostViewFactory).toBe(someHostViewFactory);
                async.done();
            });
        }));
        testing_internal_1.it('should clear the cache', function () {
            compiler.clearCache();
            testing_internal_1.expect(templateCompilerSpy.spy('clearCache')).toHaveBeenCalled();
        });
    });
}
exports.main = main;
var SomeComponent = (function () {
    function SomeComponent() {
    }
    SomeComponent = __decorate([
        core_1.Component({ selector: 'some-comp', template: '' }), 
        __metadata('design:paramtypes', [])
    ], SomeComponent);
    return SomeComponent;
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicnVudGltZV9jb21waWxlcl9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb21waWxlci9ydW50aW1lX2NvbXBpbGVyX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiIsIlNvbWVDb21wb25lbnQiLCJTb21lQ29tcG9uZW50LmNvbnN0cnVjdG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxpQ0FhTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLHFCQUFpQyxlQUFlLENBQUMsQ0FBQTtBQUNqRCxzQkFBNkIsMkJBQTJCLENBQUMsQ0FBQTtBQUN6RCxzQkFBa0MsU0FBUyxDQUFDLENBQUE7QUFDNUMseUJBQStCLGdDQUFnQyxDQUFDLENBQUE7QUFDaEUsaUNBQWdELHdDQUF3QyxDQUFDLENBQUE7QUFDekYscUJBQThCLCtCQUErQixDQUFDLENBQUE7QUFFOUQ7SUFDRUEsMkJBQVFBLENBQUNBLGlCQUFpQkEsRUFBRUE7UUFDMUJBLElBQUlBLFFBQTBCQSxDQUFDQTtRQUMvQkEsSUFBSUEsbUJBQW1CQSxDQUFDQTtRQUN4QkEsSUFBSUEsbUJBQW1CQSxDQUFDQTtRQUV4QkEsc0NBQW1CQSxDQUFDQTtZQUNsQkEsbUJBQW1CQSxHQUFHQSxJQUFJQSwyQkFBbUJBLEVBQUVBLENBQUNBO1lBQ2hEQSxtQkFBbUJBLEdBQUdBLElBQUlBLHNCQUFlQSxDQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtZQUN0REEsbUJBQW1CQSxDQUFDQSxHQUFHQSxDQUFDQSw2QkFBNkJBLENBQUNBO2lCQUNqREEsU0FBU0EsQ0FBQ0Esc0JBQWNBLENBQUNBLE9BQU9BLENBQUNBLG1CQUFtQkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDNURBLE1BQU1BLENBQUNBLENBQUNBLGNBQU9BLENBQUNBLDJCQUFnQkEsRUFBRUEsRUFBQ0EsUUFBUUEsRUFBRUEsbUJBQW1CQSxFQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUN0RUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEsNkJBQVVBLENBQUNBLHlCQUFNQSxDQUFDQSxDQUFDQSxrQ0FBZUEsQ0FBQ0EsRUFBRUEsVUFBQ0EsU0FBU0EsSUFBT0EsUUFBUUEsR0FBR0EsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFaEZBLHFCQUFFQSxDQUFDQSxnRUFBZ0VBLEVBQ2hFQSx5QkFBTUEsQ0FBQ0EsQ0FBQ0EscUNBQWtCQSxDQUFDQSxFQUFFQSxVQUFDQSxLQUFLQTtZQUNqQ0EsUUFBUUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsYUFBYUEsQ0FBQ0E7aUJBQ2hDQSxJQUFJQSxDQUFDQSxVQUFDQSxrQkFBa0JBO2dCQUN2QkEseUJBQU1BLENBQUNBLGtCQUFrQkEsQ0FBQ0EsdUJBQXVCQSxDQUFDQSxDQUFDQSxJQUFJQSxDQUFDQSxtQkFBbUJBLENBQUNBLENBQUNBO2dCQUM3RUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7WUFDZkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFUEEscUJBQUVBLENBQUNBLHdCQUF3QkEsRUFBRUE7WUFDM0JBLFFBQVFBLENBQUNBLFVBQVVBLEVBQUVBLENBQUNBO1lBQ3RCQSx5QkFBTUEsQ0FBQ0EsbUJBQW1CQSxDQUFDQSxHQUFHQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQSxDQUFDQSxnQkFBZ0JBLEVBQUVBLENBQUNBO1FBQ25FQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQTlCZSxZQUFJLE9BOEJuQixDQUFBO0FBRUQ7SUFBQUM7SUFFQUMsQ0FBQ0E7SUFGREQ7UUFBQ0EsZ0JBQVNBLENBQUNBLEVBQUNBLFFBQVFBLEVBQUVBLFdBQVdBLEVBQUVBLFFBQVFBLEVBQUVBLEVBQUVBLEVBQUNBLENBQUNBOztzQkFFaERBO0lBQURBLG9CQUFDQTtBQUFEQSxDQUFDQSxBQUZELElBRUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBkZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICB4ZGVzY3JpYmUsXG4gIGl0LFxuICBpaXQsXG4gIHhpdCxcbiAgZXhwZWN0LFxuICBiZWZvcmVFYWNoLFxuICBhZnRlckVhY2gsXG4gIEFzeW5jVGVzdENvbXBsZXRlcixcbiAgaW5qZWN0LFxuICBiZWZvcmVFYWNoUHJvdmlkZXJzXG59IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5pbXBvcnQge0NvbXBvbmVudCwgcHJvdmlkZX0gZnJvbSAnYW5ndWxhcjIvY29yZSc7XG5pbXBvcnQge1Byb21pc2VXcmFwcGVyfSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2FzeW5jJztcbmltcG9ydCB7U3B5VGVtcGxhdGVDb21waWxlcn0gZnJvbSAnLi9zcGllcyc7XG5pbXBvcnQge1RlbXBsYXRlQ29tcGlsZXJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb21waWxlci9jb21waWxlcic7XG5pbXBvcnQge1J1bnRpbWVDb21waWxlciwgUnVudGltZUNvbXBpbGVyX30gZnJvbSAnYW5ndWxhcjIvc3JjL2NvbXBpbGVyL3J1bnRpbWVfY29tcGlsZXInO1xuaW1wb3J0IHtIb3N0Vmlld0ZhY3Rvcnl9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL2xpbmtlci92aWV3JztcblxuZXhwb3J0IGZ1bmN0aW9uIG1haW4oKSB7XG4gIGRlc2NyaWJlKCdSdW50aW1lQ29tcGlsZXInLCAoKSA9PiB7XG4gICAgdmFyIGNvbXBpbGVyOiBSdW50aW1lQ29tcGlsZXJfO1xuICAgIHZhciB0ZW1wbGF0ZUNvbXBpbGVyU3B5O1xuICAgIHZhciBzb21lSG9zdFZpZXdGYWN0b3J5O1xuXG4gICAgYmVmb3JlRWFjaFByb3ZpZGVycygoKSA9PiB7XG4gICAgICB0ZW1wbGF0ZUNvbXBpbGVyU3B5ID0gbmV3IFNweVRlbXBsYXRlQ29tcGlsZXIoKTtcbiAgICAgIHNvbWVIb3N0Vmlld0ZhY3RvcnkgPSBuZXcgSG9zdFZpZXdGYWN0b3J5KG51bGwsIG51bGwpO1xuICAgICAgdGVtcGxhdGVDb21waWxlclNweS5zcHkoJ2NvbXBpbGVIb3N0Q29tcG9uZW50UnVudGltZScpXG4gICAgICAgICAgLmFuZFJldHVybihQcm9taXNlV3JhcHBlci5yZXNvbHZlKHNvbWVIb3N0Vmlld0ZhY3RvcnkpKTtcbiAgICAgIHJldHVybiBbcHJvdmlkZShUZW1wbGF0ZUNvbXBpbGVyLCB7dXNlVmFsdWU6IHRlbXBsYXRlQ29tcGlsZXJTcHl9KV07XG4gICAgfSk7XG5cbiAgICBiZWZvcmVFYWNoKGluamVjdChbUnVudGltZUNvbXBpbGVyXSwgKF9jb21waWxlcikgPT4geyBjb21waWxlciA9IF9jb21waWxlcjsgfSkpO1xuXG4gICAgaXQoJ2NvbXBpbGVJbkhvc3Qgc2hvdWxkIGNvbXBpbGUgdGhlIHRlbXBsYXRlIHZpYSBUZW1wbGF0ZUNvbXBpbGVyJyxcbiAgICAgICBpbmplY3QoW0FzeW5jVGVzdENvbXBsZXRlcl0sIChhc3luYykgPT4ge1xuICAgICAgICAgY29tcGlsZXIuY29tcGlsZUluSG9zdChTb21lQ29tcG9uZW50KVxuICAgICAgICAgICAgIC50aGVuKChob3N0Vmlld0ZhY3RvcnlSZWYpID0+IHtcbiAgICAgICAgICAgICAgIGV4cGVjdChob3N0Vmlld0ZhY3RvcnlSZWYuaW50ZXJuYWxIb3N0Vmlld0ZhY3RvcnkpLnRvQmUoc29tZUhvc3RWaWV3RmFjdG9yeSk7XG4gICAgICAgICAgICAgICBhc3luYy5kb25lKCk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgfSkpO1xuXG4gICAgaXQoJ3Nob3VsZCBjbGVhciB0aGUgY2FjaGUnLCAoKSA9PiB7XG4gICAgICBjb21waWxlci5jbGVhckNhY2hlKCk7XG4gICAgICBleHBlY3QodGVtcGxhdGVDb21waWxlclNweS5zcHkoJ2NsZWFyQ2FjaGUnKSkudG9IYXZlQmVlbkNhbGxlZCgpO1xuICAgIH0pO1xuICB9KTtcbn1cblxuQENvbXBvbmVudCh7c2VsZWN0b3I6ICdzb21lLWNvbXAnLCB0ZW1wbGF0ZTogJyd9KVxuY2xhc3MgU29tZUNvbXBvbmVudCB7XG59XG4iXX0=
 main(); 
