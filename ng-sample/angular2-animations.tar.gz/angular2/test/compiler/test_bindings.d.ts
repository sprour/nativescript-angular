import { Provider } from 'angular2/src/core/di';
export declare var TEST_PROVIDERS: Provider[];
