'use strict';var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var xhr_1 = require('angular2/src/compiler/xhr');
var template_compiler_1 = require('angular2/src/compiler/template_compiler');
var testing_internal_1 = require('angular2/testing_internal');
var SpyXHR = (function (_super) {
    __extends(SpyXHR, _super);
    function SpyXHR() {
        _super.call(this, xhr_1.XHR);
    }
    return SpyXHR;
})(testing_internal_1.SpyObject);
exports.SpyXHR = SpyXHR;
var SpyTemplateCompiler = (function (_super) {
    __extends(SpyTemplateCompiler, _super);
    function SpyTemplateCompiler() {
        _super.call(this, template_compiler_1.TemplateCompiler);
    }
    return SpyTemplateCompiler;
})(testing_internal_1.SpyObject);
exports.SpyTemplateCompiler = SpyTemplateCompiler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3BpZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L2NvbXBpbGVyL3NwaWVzLnRzIl0sIm5hbWVzIjpbIlNweVhIUiIsIlNweVhIUi5jb25zdHJ1Y3RvciIsIlNweVRlbXBsYXRlQ29tcGlsZXIiLCJTcHlUZW1wbGF0ZUNvbXBpbGVyLmNvbnN0cnVjdG9yIl0sIm1hcHBpbmdzIjoiOzs7OztBQUFBLG9CQUFrQiwyQkFBMkIsQ0FBQyxDQUFBO0FBQzlDLGtDQUErQix5Q0FBeUMsQ0FBQyxDQUFBO0FBRXpFLGlDQUErQiwyQkFBMkIsQ0FBQyxDQUFBO0FBRTNEO0lBQTRCQSwwQkFBU0E7SUFDbkNBO1FBQWdCQyxrQkFBTUEsU0FBR0EsQ0FBQ0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFDL0JELGFBQUNBO0FBQURBLENBQUNBLEFBRkQsRUFBNEIsNEJBQVMsRUFFcEM7QUFGWSxjQUFNLFNBRWxCLENBQUE7QUFFRDtJQUF5Q0UsdUNBQVNBO0lBQ2hEQTtRQUFnQkMsa0JBQU1BLG9DQUFnQkEsQ0FBQ0EsQ0FBQ0E7SUFBQ0EsQ0FBQ0E7SUFDNUNELDBCQUFDQTtBQUFEQSxDQUFDQSxBQUZELEVBQXlDLDRCQUFTLEVBRWpEO0FBRlksMkJBQW1CLHNCQUUvQixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtYSFJ9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb21waWxlci94aHInO1xuaW1wb3J0IHtUZW1wbGF0ZUNvbXBpbGVyfSBmcm9tICdhbmd1bGFyMi9zcmMvY29tcGlsZXIvdGVtcGxhdGVfY29tcGlsZXInO1xuXG5pbXBvcnQge1NweU9iamVjdCwgcHJveHl9IGZyb20gJ2FuZ3VsYXIyL3Rlc3RpbmdfaW50ZXJuYWwnO1xuXG5leHBvcnQgY2xhc3MgU3B5WEhSIGV4dGVuZHMgU3B5T2JqZWN0IHtcbiAgY29uc3RydWN0b3IoKSB7IHN1cGVyKFhIUik7IH1cbn1cblxuZXhwb3J0IGNsYXNzIFNweVRlbXBsYXRlQ29tcGlsZXIgZXh0ZW5kcyBTcHlPYmplY3Qge1xuICBjb25zdHJ1Y3RvcigpIHsgc3VwZXIoVGVtcGxhdGVDb21waWxlcik7IH1cbn0iXX0=