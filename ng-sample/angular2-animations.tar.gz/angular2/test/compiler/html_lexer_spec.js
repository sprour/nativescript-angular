'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
var exceptions_1 = require('angular2/src/facade/exceptions');
var html_lexer_1 = require('angular2/src/compiler/html_lexer');
var parse_util_1 = require('angular2/src/compiler/parse_util');
function main() {
    testing_internal_1.describe('HtmlLexer', function () {
        testing_internal_1.describe('line/column numbers', function () {
            testing_internal_1.it('should work without newlines', function () {
                testing_internal_1.expect(tokenizeAndHumanizeLineColumn('<t>a</t>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, '0:0'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END, '0:2'],
                    [html_lexer_1.HtmlTokenType.TEXT, '0:3'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, '0:4'],
                    [html_lexer_1.HtmlTokenType.EOF, '0:8']
                ]);
            });
            testing_internal_1.it('should work with one newline', function () {
                testing_internal_1.expect(tokenizeAndHumanizeLineColumn('<t>\na</t>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, '0:0'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END, '0:2'],
                    [html_lexer_1.HtmlTokenType.TEXT, '0:3'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, '1:1'],
                    [html_lexer_1.HtmlTokenType.EOF, '1:5']
                ]);
            });
            testing_internal_1.it('should work with multiple newlines', function () {
                testing_internal_1.expect(tokenizeAndHumanizeLineColumn('<t\n>\na</t>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, '0:0'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END, '1:0'],
                    [html_lexer_1.HtmlTokenType.TEXT, '1:1'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, '2:1'],
                    [html_lexer_1.HtmlTokenType.EOF, '2:5']
                ]);
            });
            testing_internal_1.it('should work with CR and LF', function () {
                testing_internal_1.expect(tokenizeAndHumanizeLineColumn('<t\n>\r\na\r</t>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, '0:0'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END, '1:0'],
                    [html_lexer_1.HtmlTokenType.TEXT, '1:1'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, '2:1'],
                    [html_lexer_1.HtmlTokenType.EOF, '2:5']
                ]);
            });
        });
        testing_internal_1.describe('comments', function () {
            testing_internal_1.it('should parse comments', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<!--t\ne\rs\r\nt-->'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.COMMENT_START],
                    [html_lexer_1.HtmlTokenType.RAW_TEXT, 't\ne\ns\nt'],
                    [html_lexer_1.HtmlTokenType.COMMENT_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should store the locations', function () {
                testing_internal_1.expect(tokenizeAndHumanizeSourceSpans('<!--t\ne\rs\r\nt-->'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.COMMENT_START, '<!--'],
                    [html_lexer_1.HtmlTokenType.RAW_TEXT, 't\ne\rs\r\nt'],
                    [html_lexer_1.HtmlTokenType.COMMENT_END, '-->'],
                    [html_lexer_1.HtmlTokenType.EOF, '']
                ]);
            });
            testing_internal_1.it('should report <!- without -', function () {
                testing_internal_1.expect(tokenizeAndHumanizeErrors('<!-a'))
                    .toEqual([[html_lexer_1.HtmlTokenType.COMMENT_START, 'Unexpected character "a"', '0:3']]);
            });
            testing_internal_1.it('should report missing end comment', function () {
                testing_internal_1.expect(tokenizeAndHumanizeErrors('<!--'))
                    .toEqual([[html_lexer_1.HtmlTokenType.RAW_TEXT, 'Unexpected character "EOF"', '0:4']]);
            });
        });
        testing_internal_1.describe('doctype', function () {
            testing_internal_1.it('should parse doctypes', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<!doctype html>'))
                    .toEqual([[html_lexer_1.HtmlTokenType.DOC_TYPE, 'doctype html'], [html_lexer_1.HtmlTokenType.EOF]]);
            });
            testing_internal_1.it('should store the locations', function () {
                testing_internal_1.expect(tokenizeAndHumanizeSourceSpans('<!doctype html>'))
                    .toEqual([[html_lexer_1.HtmlTokenType.DOC_TYPE, '<!doctype html>'], [html_lexer_1.HtmlTokenType.EOF, '']]);
            });
            testing_internal_1.it('should report missing end doctype', function () {
                testing_internal_1.expect(tokenizeAndHumanizeErrors('<!'))
                    .toEqual([[html_lexer_1.HtmlTokenType.DOC_TYPE, 'Unexpected character "EOF"', '0:2']]);
            });
        });
        testing_internal_1.describe('CDATA', function () {
            testing_internal_1.it('should parse CDATA', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<![CDATA[t\ne\rs\r\nt]]>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.CDATA_START],
                    [html_lexer_1.HtmlTokenType.RAW_TEXT, 't\ne\ns\nt'],
                    [html_lexer_1.HtmlTokenType.CDATA_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should store the locations', function () {
                testing_internal_1.expect(tokenizeAndHumanizeSourceSpans('<![CDATA[t\ne\rs\r\nt]]>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.CDATA_START, '<![CDATA['],
                    [html_lexer_1.HtmlTokenType.RAW_TEXT, 't\ne\rs\r\nt'],
                    [html_lexer_1.HtmlTokenType.CDATA_END, ']]>'],
                    [html_lexer_1.HtmlTokenType.EOF, '']
                ]);
            });
            testing_internal_1.it('should report <![ without CDATA[', function () {
                testing_internal_1.expect(tokenizeAndHumanizeErrors('<![a'))
                    .toEqual([[html_lexer_1.HtmlTokenType.CDATA_START, 'Unexpected character "a"', '0:3']]);
            });
            testing_internal_1.it('should report missing end cdata', function () {
                testing_internal_1.expect(tokenizeAndHumanizeErrors('<![CDATA['))
                    .toEqual([[html_lexer_1.HtmlTokenType.RAW_TEXT, 'Unexpected character "EOF"', '0:9']]);
            });
        });
        testing_internal_1.describe('open tags', function () {
            testing_internal_1.it('should parse open tags without prefix', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<test>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 'test'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should parse namespace prefix', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<ns1:test>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, 'ns1', 'test'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should parse void tags', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<test/>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 'test'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END_VOID],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should allow whitespace after the tag name', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<test >'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 'test'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should store the locations', function () {
                testing_internal_1.expect(tokenizeAndHumanizeSourceSpans('<test>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, '<test'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END, '>'],
                    [html_lexer_1.HtmlTokenType.EOF, '']
                ]);
            });
        });
        testing_internal_1.describe('attributes', function () {
            testing_internal_1.it('should parse attributes without prefix', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<t a>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 't'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, null, 'a'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should parse attributes with prefix', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<t ns1:a>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 't'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, 'ns1', 'a'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should parse attributes whose prefix is not valid', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<t (ns1:a)>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 't'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, null, '(ns1:a)'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should parse attributes with single quote value', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts("<t a='b'>"))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 't'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, null, 'a'],
                    [html_lexer_1.HtmlTokenType.ATTR_VALUE, 'b'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should parse attributes with double quote value', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<t a="b">'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 't'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, null, 'a'],
                    [html_lexer_1.HtmlTokenType.ATTR_VALUE, 'b'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should parse attributes with unquoted value', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<t a=b>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 't'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, null, 'a'],
                    [html_lexer_1.HtmlTokenType.ATTR_VALUE, 'b'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should allow whitespace', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<t a = b >'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 't'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, null, 'a'],
                    [html_lexer_1.HtmlTokenType.ATTR_VALUE, 'b'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should parse attributes with entities in values', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<t a="&#65;&#x41;">'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 't'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, null, 'a'],
                    [html_lexer_1.HtmlTokenType.ATTR_VALUE, 'AA'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should not decode entities without trailing ";"', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<t a="&amp" b="c&&d">'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 't'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, null, 'a'],
                    [html_lexer_1.HtmlTokenType.ATTR_VALUE, '&amp'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, null, 'b'],
                    [html_lexer_1.HtmlTokenType.ATTR_VALUE, 'c&&d'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should parse attributes with "&" in values', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('<t a="b && c &">'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 't'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, null, 'a'],
                    [html_lexer_1.HtmlTokenType.ATTR_VALUE, 'b && c &'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should parse values with CR and LF', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts("<t a='t\ne\rs\r\nt'>"))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 't'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, null, 'a'],
                    [html_lexer_1.HtmlTokenType.ATTR_VALUE, 't\ne\ns\nt'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should store the locations', function () {
                testing_internal_1.expect(tokenizeAndHumanizeSourceSpans('<t a=b>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, '<t'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, 'a'],
                    [html_lexer_1.HtmlTokenType.ATTR_VALUE, 'b'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END, '>'],
                    [html_lexer_1.HtmlTokenType.EOF, '']
                ]);
            });
        });
        testing_internal_1.describe('closing tags', function () {
            testing_internal_1.it('should parse closing tags without prefix', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('</test>'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TAG_CLOSE, null, 'test'], [html_lexer_1.HtmlTokenType.EOF]]);
            });
            testing_internal_1.it('should parse closing tags with prefix', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('</ns1:test>'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TAG_CLOSE, 'ns1', 'test'], [html_lexer_1.HtmlTokenType.EOF]]);
            });
            testing_internal_1.it('should allow whitespace', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('</ test >'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TAG_CLOSE, null, 'test'], [html_lexer_1.HtmlTokenType.EOF]]);
            });
            testing_internal_1.it('should store the locations', function () {
                testing_internal_1.expect(tokenizeAndHumanizeSourceSpans('</test>'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TAG_CLOSE, '</test>'], [html_lexer_1.HtmlTokenType.EOF, '']]);
            });
            testing_internal_1.it('should report missing name after </', function () {
                testing_internal_1.expect(tokenizeAndHumanizeErrors('</'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TAG_CLOSE, 'Unexpected character "EOF"', '0:2']]);
            });
            testing_internal_1.it('should report missing >', function () {
                testing_internal_1.expect(tokenizeAndHumanizeErrors('</test'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TAG_CLOSE, 'Unexpected character "EOF"', '0:6']]);
            });
        });
        testing_internal_1.describe('entities', function () {
            testing_internal_1.it('should parse named entities', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('a&amp;b'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TEXT, 'a&b'], [html_lexer_1.HtmlTokenType.EOF]]);
            });
            testing_internal_1.it('should parse hexadecimal entities', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('&#x41;&#X41;'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TEXT, 'AA'], [html_lexer_1.HtmlTokenType.EOF]]);
            });
            testing_internal_1.it('should parse decimal entities', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('&#65;'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TEXT, 'A'], [html_lexer_1.HtmlTokenType.EOF]]);
            });
            testing_internal_1.it('should store the locations', function () {
                testing_internal_1.expect(tokenizeAndHumanizeSourceSpans('a&amp;b'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TEXT, 'a&amp;b'], [html_lexer_1.HtmlTokenType.EOF, '']]);
            });
            testing_internal_1.it('should report malformed/unknown entities', function () {
                testing_internal_1.expect(tokenizeAndHumanizeErrors('&tbo;'))
                    .toEqual([
                    [
                        html_lexer_1.HtmlTokenType.TEXT,
                        'Unknown entity "tbo" - use the "&#<decimal>;" or  "&#x<hex>;" syntax',
                        '0:0'
                    ]
                ]);
                testing_internal_1.expect(tokenizeAndHumanizeErrors('&#asdf;'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TEXT, 'Unexpected character "s"', '0:3']]);
                testing_internal_1.expect(tokenizeAndHumanizeErrors('&#xasdf;'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TEXT, 'Unexpected character "s"', '0:4']]);
                testing_internal_1.expect(tokenizeAndHumanizeErrors('&#xABC'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TEXT, 'Unexpected character "EOF"', '0:6']]);
            });
        });
        testing_internal_1.describe('regular text', function () {
            testing_internal_1.it('should parse text', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('a'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TEXT, 'a'], [html_lexer_1.HtmlTokenType.EOF]]);
            });
            testing_internal_1.it('should handle CR & LF', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('t\ne\rs\r\nt'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TEXT, 't\ne\ns\nt'], [html_lexer_1.HtmlTokenType.EOF]]);
            });
            testing_internal_1.it('should parse entities', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('a&amp;b'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TEXT, 'a&b'], [html_lexer_1.HtmlTokenType.EOF]]);
            });
            testing_internal_1.it('should parse text starting with "&"', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('a && b &'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TEXT, 'a && b &'], [html_lexer_1.HtmlTokenType.EOF]]);
            });
            testing_internal_1.it('should store the locations', function () {
                testing_internal_1.expect(tokenizeAndHumanizeSourceSpans('a'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TEXT, 'a'], [html_lexer_1.HtmlTokenType.EOF, '']]);
            });
            testing_internal_1.it('should allow "<" in text nodes', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('{{ a < b ? c : d }}'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TEXT, '{{ a < b ? c : d }}'], [html_lexer_1.HtmlTokenType.EOF]]);
                testing_internal_1.expect(tokenizeAndHumanizeSourceSpans('<p>a<b</p>'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, '<p'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END, '>'],
                    [html_lexer_1.HtmlTokenType.TEXT, 'a<b'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, '</p>'],
                    [html_lexer_1.HtmlTokenType.EOF, ''],
                ]);
                testing_internal_1.expect(tokenizeAndHumanizeParts('< a>'))
                    .toEqual([[html_lexer_1.HtmlTokenType.TEXT, '< a>'], [html_lexer_1.HtmlTokenType.EOF]]);
            });
            // TODO(vicb): make the lexer aware of Angular expressions
            // see https://github.com/angular/angular/issues/5679
            testing_internal_1.it('should parse valid start tag in interpolation', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts('{{ a <b && c > d }}'))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TEXT, '{{ a '],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 'b'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, null, '&&'],
                    [html_lexer_1.HtmlTokenType.ATTR_NAME, null, 'c'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.TEXT, ' d }}'],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
        });
        testing_internal_1.describe('raw text', function () {
            testing_internal_1.it('should parse text', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts("<script>t\ne\rs\r\nt</script>"))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 'script'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.RAW_TEXT, 't\ne\ns\nt'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, null, 'script'],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should not detect entities', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts("<script>&amp;</SCRIPT>"))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 'script'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.RAW_TEXT, '&amp;'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, null, 'script'],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should ignore other opening tags', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts("<script>a<div></script>"))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 'script'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.RAW_TEXT, 'a<div>'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, null, 'script'],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should ignore other closing tags', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts("<script>a</test></script>"))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 'script'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.RAW_TEXT, 'a</test>'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, null, 'script'],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should store the locations', function () {
                testing_internal_1.expect(tokenizeAndHumanizeSourceSpans("<script>a</script>"))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, '<script'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END, '>'],
                    [html_lexer_1.HtmlTokenType.RAW_TEXT, 'a'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, '</script>'],
                    [html_lexer_1.HtmlTokenType.EOF, '']
                ]);
            });
        });
        testing_internal_1.describe('escapable raw text', function () {
            testing_internal_1.it('should parse text', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts("<title>t\ne\rs\r\nt</title>"))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 'title'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.ESCAPABLE_RAW_TEXT, 't\ne\ns\nt'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, null, 'title'],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should detect entities', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts("<title>&amp;</title>"))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 'title'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.ESCAPABLE_RAW_TEXT, '&'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, null, 'title'],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should ignore other opening tags', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts("<title>a<div></title>"))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 'title'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.ESCAPABLE_RAW_TEXT, 'a<div>'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, null, 'title'],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should ignore other closing tags', function () {
                testing_internal_1.expect(tokenizeAndHumanizeParts("<title>a</test></title>"))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, null, 'title'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END],
                    [html_lexer_1.HtmlTokenType.ESCAPABLE_RAW_TEXT, 'a</test>'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, null, 'title'],
                    [html_lexer_1.HtmlTokenType.EOF]
                ]);
            });
            testing_internal_1.it('should store the locations', function () {
                testing_internal_1.expect(tokenizeAndHumanizeSourceSpans("<title>a</title>"))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, '<title'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END, '>'],
                    [html_lexer_1.HtmlTokenType.ESCAPABLE_RAW_TEXT, 'a'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, '</title>'],
                    [html_lexer_1.HtmlTokenType.EOF, '']
                ]);
            });
        });
        testing_internal_1.describe('errors', function () {
            testing_internal_1.it('should include 2 lines of context in message', function () {
                var src = "111\n222\n333\nE\n444\n555\n666\n";
                var file = new parse_util_1.ParseSourceFile(src, 'file://');
                var location = new parse_util_1.ParseLocation(file, 12, 123, 456);
                var span = new parse_util_1.ParseSourceSpan(location, location);
                var error = new html_lexer_1.HtmlTokenError('**ERROR**', null, span);
                testing_internal_1.expect(error.toString())
                    .toEqual("**ERROR** (\"\n222\n333\n[ERROR ->]E\n444\n555\n\"): file://@123:456");
            });
        });
        testing_internal_1.describe('unicode characters', function () {
            testing_internal_1.it('should support unicode characters', function () {
                testing_internal_1.expect(tokenizeAndHumanizeSourceSpans("<p>\u0130</p>"))
                    .toEqual([
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_START, '<p'],
                    [html_lexer_1.HtmlTokenType.TAG_OPEN_END, '>'],
                    [html_lexer_1.HtmlTokenType.TEXT, 'İ'],
                    [html_lexer_1.HtmlTokenType.TAG_CLOSE, '</p>'],
                    [html_lexer_1.HtmlTokenType.EOF, '']
                ]);
            });
        });
    });
}
exports.main = main;
function tokenizeWithoutErrors(input) {
    var tokenizeResult = html_lexer_1.tokenizeHtml(input, 'someUrl');
    if (tokenizeResult.errors.length > 0) {
        var errorString = tokenizeResult.errors.join('\n');
        throw new exceptions_1.BaseException("Unexpected parse errors:\n" + errorString);
    }
    return tokenizeResult.tokens;
}
function tokenizeAndHumanizeParts(input) {
    return tokenizeWithoutErrors(input).map(function (token) { return [token.type].concat(token.parts); });
}
function tokenizeAndHumanizeSourceSpans(input) {
    return tokenizeWithoutErrors(input).map(function (token) { return [token.type, token.sourceSpan.toString()]; });
}
function humanizeLineColumn(location) {
    return location.line + ":" + location.col;
}
function tokenizeAndHumanizeLineColumn(input) {
    return tokenizeWithoutErrors(input)
        .map(function (token) { return [token.type, humanizeLineColumn(token.sourceSpan.start)]; });
}
function tokenizeAndHumanizeErrors(input) {
    return html_lexer_1.tokenizeHtml(input, 'someUrl')
        .errors.map(function (tokenError) { return [
        tokenError.tokenType,
        tokenError.msg,
        humanizeLineColumn(tokenError.span.start)
    ]; });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaHRtbF9sZXhlcl9zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC1ZcTh1eFhZQy50bXAvYW5ndWxhcjIvdGVzdC9jb21waWxlci9odG1sX2xleGVyX3NwZWMudHMiXSwibmFtZXMiOlsibWFpbiIsInRva2VuaXplV2l0aG91dEVycm9ycyIsInRva2VuaXplQW5kSHVtYW5pemVQYXJ0cyIsInRva2VuaXplQW5kSHVtYW5pemVTb3VyY2VTcGFucyIsImh1bWFuaXplTGluZUNvbHVtbiIsInRva2VuaXplQW5kSHVtYW5pemVMaW5lQ29sdW1uIiwidG9rZW5pemVBbmRIdW1hbml6ZUVycm9ycyJdLCJtYXBwaW5ncyI6IkFBQUEsaUNBU08sMkJBQTJCLENBQUMsQ0FBQTtBQUNuQywyQkFBNEIsZ0NBQWdDLENBQUMsQ0FBQTtBQUU3RCwyQkFLTyxrQ0FBa0MsQ0FBQyxDQUFBO0FBQzFDLDJCQUE4RCxrQ0FBa0MsQ0FBQyxDQUFBO0FBRWpHO0lBQ0VBLDJCQUFRQSxDQUFDQSxXQUFXQSxFQUFFQTtRQUNwQkEsMkJBQVFBLENBQUNBLHFCQUFxQkEsRUFBRUE7WUFDOUJBLHFCQUFFQSxDQUFDQSw4QkFBOEJBLEVBQUVBO2dCQUNqQ0EseUJBQU1BLENBQUNBLDZCQUE2QkEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0E7cUJBQzVDQSxPQUFPQSxDQUFDQTtvQkFDUEEsQ0FBQ0EsMEJBQWFBLENBQUNBLGNBQWNBLEVBQUVBLEtBQUtBLENBQUNBO29CQUNyQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFlBQVlBLEVBQUVBLEtBQUtBLENBQUNBO29CQUNuQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLElBQUlBLEVBQUVBLEtBQUtBLENBQUNBO29CQUMzQkEsQ0FBQ0EsMEJBQWFBLENBQUNBLFNBQVNBLEVBQUVBLEtBQUtBLENBQUNBO29CQUNoQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLEVBQUVBLEtBQUtBLENBQUNBO2lCQUMzQkEsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDhCQUE4QkEsRUFBRUE7Z0JBQ2pDQSx5QkFBTUEsQ0FBQ0EsNkJBQTZCQSxDQUFDQSxZQUFZQSxDQUFDQSxDQUFDQTtxQkFDOUNBLE9BQU9BLENBQUNBO29CQUNQQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsY0FBY0EsRUFBRUEsS0FBS0EsQ0FBQ0E7b0JBQ3JDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsWUFBWUEsRUFBRUEsS0FBS0EsQ0FBQ0E7b0JBQ25DQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsSUFBSUEsRUFBRUEsS0FBS0EsQ0FBQ0E7b0JBQzNCQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsU0FBU0EsRUFBRUEsS0FBS0EsQ0FBQ0E7b0JBQ2hDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsRUFBRUEsS0FBS0EsQ0FBQ0E7aUJBQzNCQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0Esb0NBQW9DQSxFQUFFQTtnQkFDdkNBLHlCQUFNQSxDQUFDQSw2QkFBNkJBLENBQUNBLGNBQWNBLENBQUNBLENBQUNBO3FCQUNoREEsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxLQUFLQSxDQUFDQTtvQkFDckNBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxFQUFFQSxLQUFLQSxDQUFDQTtvQkFDbkNBLENBQUNBLDBCQUFhQSxDQUFDQSxJQUFJQSxFQUFFQSxLQUFLQSxDQUFDQTtvQkFDM0JBLENBQUNBLDBCQUFhQSxDQUFDQSxTQUFTQSxFQUFFQSxLQUFLQSxDQUFDQTtvQkFDaENBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxFQUFFQSxLQUFLQSxDQUFDQTtpQkFDM0JBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSw0QkFBNEJBLEVBQUVBO2dCQUMvQkEseUJBQU1BLENBQUNBLDZCQUE2QkEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxDQUFDQTtxQkFDcERBLE9BQU9BLENBQUNBO29CQUNQQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsY0FBY0EsRUFBRUEsS0FBS0EsQ0FBQ0E7b0JBQ3JDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsWUFBWUEsRUFBRUEsS0FBS0EsQ0FBQ0E7b0JBQ25DQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsSUFBSUEsRUFBRUEsS0FBS0EsQ0FBQ0E7b0JBQzNCQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsU0FBU0EsRUFBRUEsS0FBS0EsQ0FBQ0E7b0JBQ2hDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsRUFBRUEsS0FBS0EsQ0FBQ0E7aUJBQzNCQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsVUFBVUEsRUFBRUE7WUFDbkJBLHFCQUFFQSxDQUFDQSx1QkFBdUJBLEVBQUVBO2dCQUMxQkEseUJBQU1BLENBQUNBLHdCQUF3QkEsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQTtxQkFDbERBLE9BQU9BLENBQUNBO29CQUNQQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsYUFBYUEsQ0FBQ0E7b0JBQzdCQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsUUFBUUEsRUFBRUEsWUFBWUEsQ0FBQ0E7b0JBQ3RDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsV0FBV0EsQ0FBQ0E7b0JBQzNCQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsQ0FBQ0E7aUJBQ3BCQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsNEJBQTRCQSxFQUM1QkE7Z0JBQU9BLHlCQUFNQSxDQUFDQSw4QkFBOEJBLENBQUNBLHFCQUFxQkEsQ0FBQ0EsQ0FBQ0E7cUJBQ3hEQSxPQUFPQSxDQUFDQTtvQkFDUEEsQ0FBQ0EsMEJBQWFBLENBQUNBLGFBQWFBLEVBQUVBLE1BQU1BLENBQUNBO29CQUNyQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFFBQVFBLEVBQUVBLGNBQWNBLENBQUNBO29CQUN4Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFdBQVdBLEVBQUVBLEtBQUtBLENBQUNBO29CQUNsQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLEVBQUVBLEVBQUVBLENBQUNBO2lCQUN4QkEsQ0FBQ0EsQ0FBQUE7WUFBQUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFbkJBLHFCQUFFQSxDQUFDQSw2QkFBNkJBLEVBQUVBO2dCQUNoQ0EseUJBQU1BLENBQUNBLHlCQUF5QkEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7cUJBQ3BDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsYUFBYUEsRUFBRUEsMEJBQTBCQSxFQUFFQSxLQUFLQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNuRkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLG1DQUFtQ0EsRUFBRUE7Z0JBQ3RDQSx5QkFBTUEsQ0FBQ0EseUJBQXlCQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTtxQkFDcENBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLDBCQUFhQSxDQUFDQSxRQUFRQSxFQUFFQSw0QkFBNEJBLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ2hGQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsU0FBU0EsRUFBRUE7WUFDbEJBLHFCQUFFQSxDQUFDQSx1QkFBdUJBLEVBQUVBO2dCQUMxQkEseUJBQU1BLENBQUNBLHdCQUF3QkEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQTtxQkFDOUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLDBCQUFhQSxDQUFDQSxRQUFRQSxFQUFFQSxjQUFjQSxDQUFDQSxFQUFFQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDaEZBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSw0QkFBNEJBLEVBQUVBO2dCQUMvQkEseUJBQU1BLENBQUNBLDhCQUE4QkEsQ0FBQ0EsaUJBQWlCQSxDQUFDQSxDQUFDQTtxQkFDcERBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLDBCQUFhQSxDQUFDQSxRQUFRQSxFQUFFQSxpQkFBaUJBLENBQUNBLEVBQUVBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUN2RkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLG1DQUFtQ0EsRUFBRUE7Z0JBQ3RDQSx5QkFBTUEsQ0FBQ0EseUJBQXlCQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtxQkFDbENBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLDBCQUFhQSxDQUFDQSxRQUFRQSxFQUFFQSw0QkFBNEJBLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ2hGQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsT0FBT0EsRUFBRUE7WUFDaEJBLHFCQUFFQSxDQUFDQSxvQkFBb0JBLEVBQUVBO2dCQUN2QkEseUJBQU1BLENBQUNBLHdCQUF3QkEsQ0FBQ0EsMEJBQTBCQSxDQUFDQSxDQUFDQTtxQkFDdkRBLE9BQU9BLENBQUNBO29CQUNQQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsV0FBV0EsQ0FBQ0E7b0JBQzNCQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsUUFBUUEsRUFBRUEsWUFBWUEsQ0FBQ0E7b0JBQ3RDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsU0FBU0EsQ0FBQ0E7b0JBQ3pCQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsQ0FBQ0E7aUJBQ3BCQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsNEJBQTRCQSxFQUFFQTtnQkFDL0JBLHlCQUFNQSxDQUFDQSw4QkFBOEJBLENBQUNBLDBCQUEwQkEsQ0FBQ0EsQ0FBQ0E7cUJBQzdEQSxPQUFPQSxDQUFDQTtvQkFDUEEsQ0FBQ0EsMEJBQWFBLENBQUNBLFdBQVdBLEVBQUVBLFdBQVdBLENBQUNBO29CQUN4Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFFBQVFBLEVBQUVBLGNBQWNBLENBQUNBO29CQUN4Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFNBQVNBLEVBQUVBLEtBQUtBLENBQUNBO29CQUNoQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLEVBQUVBLEVBQUVBLENBQUNBO2lCQUN4QkEsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLGtDQUFrQ0EsRUFBRUE7Z0JBQ3JDQSx5QkFBTUEsQ0FBQ0EseUJBQXlCQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTtxQkFDcENBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLDBCQUFhQSxDQUFDQSxXQUFXQSxFQUFFQSwwQkFBMEJBLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ2pGQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsaUNBQWlDQSxFQUFFQTtnQkFDcENBLHlCQUFNQSxDQUFDQSx5QkFBeUJBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO3FCQUN6Q0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFFBQVFBLEVBQUVBLDRCQUE0QkEsRUFBRUEsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDaEZBLENBQUNBLENBQUNBLENBQUNBO1FBQ0xBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLDJCQUFRQSxDQUFDQSxXQUFXQSxFQUFFQTtZQUNwQkEscUJBQUVBLENBQUNBLHVDQUF1Q0EsRUFBRUE7Z0JBQzFDQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtxQkFDckNBLE9BQU9BLENBQUNBO29CQUNQQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsY0FBY0EsRUFBRUEsSUFBSUEsRUFBRUEsTUFBTUEsQ0FBQ0E7b0JBQzVDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsWUFBWUEsQ0FBQ0E7b0JBQzVCQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsQ0FBQ0E7aUJBQ3BCQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsK0JBQStCQSxFQUFFQTtnQkFDbENBLHlCQUFNQSxDQUFDQSx3QkFBd0JBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBO3FCQUN6Q0EsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxLQUFLQSxFQUFFQSxNQUFNQSxDQUFDQTtvQkFDN0NBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxDQUFDQTtvQkFDNUJBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDcEJBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSx3QkFBd0JBLEVBQUVBO2dCQUMzQkEseUJBQU1BLENBQUNBLHdCQUF3QkEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7cUJBQ3RDQSxPQUFPQSxDQUFDQTtvQkFDUEEsQ0FBQ0EsMEJBQWFBLENBQUNBLGNBQWNBLEVBQUVBLElBQUlBLEVBQUVBLE1BQU1BLENBQUNBO29CQUM1Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLGlCQUFpQkEsQ0FBQ0E7b0JBQ2pDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsQ0FBQ0E7aUJBQ3BCQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsNENBQTRDQSxFQUFFQTtnQkFDL0NBLHlCQUFNQSxDQUFDQSx3QkFBd0JBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBO3FCQUN0Q0EsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxNQUFNQSxDQUFDQTtvQkFDNUNBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxDQUFDQTtvQkFDNUJBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDcEJBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSw0QkFBNEJBLEVBQUVBO2dCQUMvQkEseUJBQU1BLENBQUNBLDhCQUE4QkEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0E7cUJBQzNDQSxPQUFPQSxDQUFDQTtvQkFDUEEsQ0FBQ0EsMEJBQWFBLENBQUNBLGNBQWNBLEVBQUVBLE9BQU9BLENBQUNBO29CQUN2Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFlBQVlBLEVBQUVBLEdBQUdBLENBQUNBO29CQUNqQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLEVBQUVBLEVBQUVBLENBQUNBO2lCQUN4QkEsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEsMkJBQVFBLENBQUNBLFlBQVlBLEVBQUVBO1lBQ3JCQSxxQkFBRUEsQ0FBQ0Esd0NBQXdDQSxFQUFFQTtnQkFDM0NBLHlCQUFNQSxDQUFDQSx3QkFBd0JBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO3FCQUNwQ0EsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDekNBLENBQUNBLDBCQUFhQSxDQUFDQSxTQUFTQSxFQUFFQSxJQUFJQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDcENBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxDQUFDQTtvQkFDNUJBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDcEJBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxxQ0FBcUNBLEVBQUVBO2dCQUN4Q0EseUJBQU1BLENBQUNBLHdCQUF3QkEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsQ0FBQ0E7cUJBQ3hDQSxPQUFPQSxDQUFDQTtvQkFDUEEsQ0FBQ0EsMEJBQWFBLENBQUNBLGNBQWNBLEVBQUVBLElBQUlBLEVBQUVBLEdBQUdBLENBQUNBO29CQUN6Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFNBQVNBLEVBQUVBLEtBQUtBLEVBQUVBLEdBQUdBLENBQUNBO29CQUNyQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFlBQVlBLENBQUNBO29CQUM1QkEsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLENBQUNBO2lCQUNwQkEsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLG1EQUFtREEsRUFBRUE7Z0JBQ3REQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtxQkFDMUNBLE9BQU9BLENBQUNBO29CQUNQQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsY0FBY0EsRUFBRUEsSUFBSUEsRUFBRUEsR0FBR0EsQ0FBQ0E7b0JBQ3pDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsU0FBU0EsRUFBRUEsSUFBSUEsRUFBRUEsU0FBU0EsQ0FBQ0E7b0JBQzFDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsWUFBWUEsQ0FBQ0E7b0JBQzVCQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsQ0FBQ0E7aUJBQ3BCQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsaURBQWlEQSxFQUFFQTtnQkFDcERBLHlCQUFNQSxDQUFDQSx3QkFBd0JBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO3FCQUN4Q0EsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDekNBLENBQUNBLDBCQUFhQSxDQUFDQSxTQUFTQSxFQUFFQSxJQUFJQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDcENBLENBQUNBLDBCQUFhQSxDQUFDQSxVQUFVQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDL0JBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxDQUFDQTtvQkFDNUJBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDcEJBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxpREFBaURBLEVBQUVBO2dCQUNwREEseUJBQU1BLENBQUNBLHdCQUF3QkEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsQ0FBQ0E7cUJBQ3hDQSxPQUFPQSxDQUFDQTtvQkFDUEEsQ0FBQ0EsMEJBQWFBLENBQUNBLGNBQWNBLEVBQUVBLElBQUlBLEVBQUVBLEdBQUdBLENBQUNBO29CQUN6Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFNBQVNBLEVBQUVBLElBQUlBLEVBQUVBLEdBQUdBLENBQUNBO29CQUNwQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFVBQVVBLEVBQUVBLEdBQUdBLENBQUNBO29CQUMvQkEsQ0FBQ0EsMEJBQWFBLENBQUNBLFlBQVlBLENBQUNBO29CQUM1QkEsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLENBQUNBO2lCQUNwQkEsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDZDQUE2Q0EsRUFBRUE7Z0JBQ2hEQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQTtxQkFDdENBLE9BQU9BLENBQUNBO29CQUNQQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsY0FBY0EsRUFBRUEsSUFBSUEsRUFBRUEsR0FBR0EsQ0FBQ0E7b0JBQ3pDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsU0FBU0EsRUFBRUEsSUFBSUEsRUFBRUEsR0FBR0EsQ0FBQ0E7b0JBQ3BDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsVUFBVUEsRUFBRUEsR0FBR0EsQ0FBQ0E7b0JBQy9CQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsWUFBWUEsQ0FBQ0E7b0JBQzVCQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsQ0FBQ0E7aUJBQ3BCQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EseUJBQXlCQSxFQUFFQTtnQkFDNUJBLHlCQUFNQSxDQUFDQSx3QkFBd0JBLENBQUNBLFlBQVlBLENBQUNBLENBQUNBO3FCQUN6Q0EsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDekNBLENBQUNBLDBCQUFhQSxDQUFDQSxTQUFTQSxFQUFFQSxJQUFJQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDcENBLENBQUNBLDBCQUFhQSxDQUFDQSxVQUFVQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDL0JBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxDQUFDQTtvQkFDNUJBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDcEJBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxpREFBaURBLEVBQUVBO2dCQUNwREEseUJBQU1BLENBQUNBLHdCQUF3QkEsQ0FBQ0EscUJBQXFCQSxDQUFDQSxDQUFDQTtxQkFDbERBLE9BQU9BLENBQUNBO29CQUNQQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsY0FBY0EsRUFBRUEsSUFBSUEsRUFBRUEsR0FBR0EsQ0FBQ0E7b0JBQ3pDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsU0FBU0EsRUFBRUEsSUFBSUEsRUFBRUEsR0FBR0EsQ0FBQ0E7b0JBQ3BDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsVUFBVUEsRUFBRUEsSUFBSUEsQ0FBQ0E7b0JBQ2hDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsWUFBWUEsQ0FBQ0E7b0JBQzVCQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsQ0FBQ0E7aUJBQ3BCQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsaURBQWlEQSxFQUFFQTtnQkFDcERBLHlCQUFNQSxDQUFDQSx3QkFBd0JBLENBQUNBLHVCQUF1QkEsQ0FBQ0EsQ0FBQ0E7cUJBQ3BEQSxPQUFPQSxDQUFDQTtvQkFDUEEsQ0FBQ0EsMEJBQWFBLENBQUNBLGNBQWNBLEVBQUVBLElBQUlBLEVBQUVBLEdBQUdBLENBQUNBO29CQUN6Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFNBQVNBLEVBQUVBLElBQUlBLEVBQUVBLEdBQUdBLENBQUNBO29CQUNwQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFVBQVVBLEVBQUVBLE1BQU1BLENBQUNBO29CQUNsQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFNBQVNBLEVBQUVBLElBQUlBLEVBQUVBLEdBQUdBLENBQUNBO29CQUNwQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFVBQVVBLEVBQUVBLE1BQU1BLENBQUNBO29CQUNsQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFlBQVlBLENBQUNBO29CQUM1QkEsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLENBQUNBO2lCQUNwQkEsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDRDQUE0Q0EsRUFBRUE7Z0JBQy9DQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSxrQkFBa0JBLENBQUNBLENBQUNBO3FCQUMvQ0EsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDekNBLENBQUNBLDBCQUFhQSxDQUFDQSxTQUFTQSxFQUFFQSxJQUFJQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDcENBLENBQUNBLDBCQUFhQSxDQUFDQSxVQUFVQSxFQUFFQSxVQUFVQSxDQUFDQTtvQkFDdENBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxDQUFDQTtvQkFDNUJBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDcEJBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxvQ0FBb0NBLEVBQUVBO2dCQUN2Q0EseUJBQU1BLENBQUNBLHdCQUF3QkEsQ0FBQ0Esc0JBQXNCQSxDQUFDQSxDQUFDQTtxQkFDbkRBLE9BQU9BLENBQUNBO29CQUNQQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsY0FBY0EsRUFBRUEsSUFBSUEsRUFBRUEsR0FBR0EsQ0FBQ0E7b0JBQ3pDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsU0FBU0EsRUFBRUEsSUFBSUEsRUFBRUEsR0FBR0EsQ0FBQ0E7b0JBQ3BDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsVUFBVUEsRUFBRUEsWUFBWUEsQ0FBQ0E7b0JBQ3hDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsWUFBWUEsQ0FBQ0E7b0JBQzVCQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsQ0FBQ0E7aUJBQ3BCQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsNEJBQTRCQSxFQUFFQTtnQkFDL0JBLHlCQUFNQSxDQUFDQSw4QkFBOEJBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBO3FCQUM1Q0EsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxJQUFJQSxDQUFDQTtvQkFDcENBLENBQUNBLDBCQUFhQSxDQUFDQSxTQUFTQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDOUJBLENBQUNBLDBCQUFhQSxDQUFDQSxVQUFVQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDL0JBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDakNBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxFQUFFQSxFQUFFQSxDQUFDQTtpQkFDeEJBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBO1FBRUxBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLDJCQUFRQSxDQUFDQSxjQUFjQSxFQUFFQTtZQUN2QkEscUJBQUVBLENBQUNBLDBDQUEwQ0EsRUFBRUE7Z0JBQzdDQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQTtxQkFDdENBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLDBCQUFhQSxDQUFDQSxTQUFTQSxFQUFFQSxJQUFJQSxFQUFFQSxNQUFNQSxDQUFDQSxFQUFFQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDL0VBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSx1Q0FBdUNBLEVBQUVBO2dCQUMxQ0EseUJBQU1BLENBQUNBLHdCQUF3QkEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7cUJBQzFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsU0FBU0EsRUFBRUEsS0FBS0EsRUFBRUEsTUFBTUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ2hGQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EseUJBQXlCQSxFQUFFQTtnQkFDNUJBLHlCQUFNQSxDQUFDQSx3QkFBd0JBLENBQUNBLFdBQVdBLENBQUNBLENBQUNBO3FCQUN4Q0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFNBQVNBLEVBQUVBLElBQUlBLEVBQUVBLE1BQU1BLENBQUNBLEVBQUVBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUMvRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDRCQUE0QkEsRUFBRUE7Z0JBQy9CQSx5QkFBTUEsQ0FBQ0EsOEJBQThCQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQTtxQkFDNUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLDBCQUFhQSxDQUFDQSxTQUFTQSxFQUFFQSxTQUFTQSxDQUFDQSxFQUFFQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsRUFBRUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDaEZBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxxQ0FBcUNBLEVBQUVBO2dCQUN4Q0EseUJBQU1BLENBQUNBLHlCQUF5QkEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7cUJBQ2xDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsU0FBU0EsRUFBRUEsNEJBQTRCQSxFQUFFQSxLQUFLQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNqRkEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLHlCQUF5QkEsRUFBRUE7Z0JBQzVCQSx5QkFBTUEsQ0FBQ0EseUJBQXlCQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtxQkFDdENBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLDBCQUFhQSxDQUFDQSxTQUFTQSxFQUFFQSw0QkFBNEJBLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ2pGQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsVUFBVUEsRUFBRUE7WUFDbkJBLHFCQUFFQSxDQUFDQSw2QkFBNkJBLEVBQUVBO2dCQUNoQ0EseUJBQU1BLENBQUNBLHdCQUF3QkEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7cUJBQ3RDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsSUFBSUEsRUFBRUEsS0FBS0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ25FQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsbUNBQW1DQSxFQUFFQTtnQkFDdENBLHlCQUFNQSxDQUFDQSx3QkFBd0JBLENBQUNBLGNBQWNBLENBQUNBLENBQUNBO3FCQUMzQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLEVBQUVBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNsRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLCtCQUErQkEsRUFBRUE7Z0JBQ2xDQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtxQkFDcENBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLDBCQUFhQSxDQUFDQSxJQUFJQSxFQUFFQSxHQUFHQSxDQUFDQSxFQUFFQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDakVBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSw0QkFBNEJBLEVBQUVBO2dCQUMvQkEseUJBQU1BLENBQUNBLDhCQUE4QkEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7cUJBQzVDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsSUFBSUEsRUFBRUEsU0FBU0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQzNFQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsMENBQTBDQSxFQUFFQTtnQkFDN0NBLHlCQUFNQSxDQUFDQSx5QkFBeUJBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO3FCQUNyQ0EsT0FBT0EsQ0FBQ0E7b0JBQ1BBO3dCQUNFQSwwQkFBYUEsQ0FBQ0EsSUFBSUE7d0JBQ2xCQSxzRUFBc0VBO3dCQUN0RUEsS0FBS0E7cUJBQ05BO2lCQUNGQSxDQUFDQSxDQUFDQTtnQkFDUEEseUJBQU1BLENBQUNBLHlCQUF5QkEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7cUJBQ3ZDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsSUFBSUEsRUFBRUEsMEJBQTBCQSxFQUFFQSxLQUFLQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDeEVBLHlCQUFNQSxDQUFDQSx5QkFBeUJBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBO3FCQUN4Q0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLElBQUlBLEVBQUVBLDBCQUEwQkEsRUFBRUEsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBRXhFQSx5QkFBTUEsQ0FBQ0EseUJBQXlCQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtxQkFDdENBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLDBCQUFhQSxDQUFDQSxJQUFJQSxFQUFFQSw0QkFBNEJBLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQzVFQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0EsY0FBY0EsRUFBRUE7WUFDdkJBLHFCQUFFQSxDQUFDQSxtQkFBbUJBLEVBQUVBO2dCQUN0QkEseUJBQU1BLENBQUNBLHdCQUF3QkEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7cUJBQ2hDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsSUFBSUEsRUFBRUEsR0FBR0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ2pFQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsdUJBQXVCQSxFQUFFQTtnQkFDMUJBLHlCQUFNQSxDQUFDQSx3QkFBd0JBLENBQUNBLGNBQWNBLENBQUNBLENBQUNBO3FCQUMzQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLElBQUlBLEVBQUVBLFlBQVlBLENBQUNBLEVBQUVBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUMxRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLHVCQUF1QkEsRUFBRUE7Z0JBQzFCQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQTtxQkFDdENBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLDBCQUFhQSxDQUFDQSxJQUFJQSxFQUFFQSxLQUFLQSxDQUFDQSxFQUFFQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDbkVBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSxxQ0FBcUNBLEVBQUVBO2dCQUN4Q0EseUJBQU1BLENBQUNBLHdCQUF3QkEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0E7cUJBQ3ZDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsSUFBSUEsRUFBRUEsVUFBVUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQ3hFQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0EsNEJBQTRCQSxFQUFFQTtnQkFDL0JBLHlCQUFNQSxDQUFDQSw4QkFBOEJBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO3FCQUN0Q0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLElBQUlBLEVBQUVBLEdBQUdBLENBQUNBLEVBQUVBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNyRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLGdDQUFnQ0EsRUFBRUE7Z0JBQ25DQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSxxQkFBcUJBLENBQUNBLENBQUNBO3FCQUNsREEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLElBQUlBLEVBQUVBLHFCQUFxQkEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUVqRkEseUJBQU1BLENBQUNBLDhCQUE4QkEsQ0FBQ0EsWUFBWUEsQ0FBQ0EsQ0FBQ0E7cUJBQy9DQSxPQUFPQSxDQUFDQTtvQkFDUEEsQ0FBQ0EsMEJBQWFBLENBQUNBLGNBQWNBLEVBQUVBLElBQUlBLENBQUNBO29CQUNwQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFlBQVlBLEVBQUVBLEdBQUdBLENBQUNBO29CQUNqQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLElBQUlBLEVBQUVBLEtBQUtBLENBQUNBO29CQUMzQkEsQ0FBQ0EsMEJBQWFBLENBQUNBLFNBQVNBLEVBQUVBLE1BQU1BLENBQUNBO29CQUNqQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLEVBQUVBLEVBQUVBLENBQUNBO2lCQUN4QkEsQ0FBQ0EsQ0FBQ0E7Z0JBRVBBLHlCQUFNQSxDQUFDQSx3QkFBd0JBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO3FCQUNuQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLElBQUlBLEVBQUVBLE1BQU1BLENBQUNBLEVBQUVBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNwRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEsMERBQTBEQTtZQUMxREEscURBQXFEQTtZQUNyREEscUJBQUVBLENBQUNBLCtDQUErQ0EsRUFBRUE7Z0JBQ2xEQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSxxQkFBcUJBLENBQUNBLENBQUNBO3FCQUNsREEsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxJQUFJQSxFQUFFQSxPQUFPQSxDQUFDQTtvQkFDN0JBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDekNBLENBQUNBLDBCQUFhQSxDQUFDQSxTQUFTQSxFQUFFQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQTtvQkFDckNBLENBQUNBLDBCQUFhQSxDQUFDQSxTQUFTQSxFQUFFQSxJQUFJQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDcENBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxDQUFDQTtvQkFDNUJBLENBQUNBLDBCQUFhQSxDQUFDQSxJQUFJQSxFQUFFQSxPQUFPQSxDQUFDQTtvQkFDN0JBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDcEJBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBO1FBRUxBLENBQUNBLENBQUNBLENBQUNBO1FBRUhBLDJCQUFRQSxDQUFDQSxVQUFVQSxFQUFFQTtZQUNuQkEscUJBQUVBLENBQUNBLG1CQUFtQkEsRUFBRUE7Z0JBQ3RCQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSwrQkFBK0JBLENBQUNBLENBQUNBO3FCQUM1REEsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxRQUFRQSxDQUFDQTtvQkFDOUNBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxDQUFDQTtvQkFDNUJBLENBQUNBLDBCQUFhQSxDQUFDQSxRQUFRQSxFQUFFQSxZQUFZQSxDQUFDQTtvQkFDdENBLENBQUNBLDBCQUFhQSxDQUFDQSxTQUFTQSxFQUFFQSxJQUFJQSxFQUFFQSxRQUFRQSxDQUFDQTtvQkFDekNBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDcEJBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSw0QkFBNEJBLEVBQUVBO2dCQUMvQkEseUJBQU1BLENBQUNBLHdCQUF3QkEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSxDQUFDQTtxQkFDckRBLE9BQU9BLENBQUNBO29CQUNQQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsY0FBY0EsRUFBRUEsSUFBSUEsRUFBRUEsUUFBUUEsQ0FBQ0E7b0JBQzlDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsWUFBWUEsQ0FBQ0E7b0JBQzVCQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsUUFBUUEsRUFBRUEsT0FBT0EsQ0FBQ0E7b0JBQ2pDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsU0FBU0EsRUFBRUEsSUFBSUEsRUFBRUEsUUFBUUEsQ0FBQ0E7b0JBQ3pDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsQ0FBQ0E7aUJBQ3BCQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVIQSxxQkFBRUEsQ0FBQ0Esa0NBQWtDQSxFQUFFQTtnQkFDckNBLHlCQUFNQSxDQUFDQSx3QkFBd0JBLENBQUNBLHlCQUF5QkEsQ0FBQ0EsQ0FBQ0E7cUJBQ3REQSxPQUFPQSxDQUFDQTtvQkFDUEEsQ0FBQ0EsMEJBQWFBLENBQUNBLGNBQWNBLEVBQUVBLElBQUlBLEVBQUVBLFFBQVFBLENBQUNBO29CQUM5Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFlBQVlBLENBQUNBO29CQUM1QkEsQ0FBQ0EsMEJBQWFBLENBQUNBLFFBQVFBLEVBQUVBLFFBQVFBLENBQUNBO29CQUNsQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFNBQVNBLEVBQUVBLElBQUlBLEVBQUVBLFFBQVFBLENBQUNBO29CQUN6Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLENBQUNBO2lCQUNwQkEsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLGtDQUFrQ0EsRUFBRUE7Z0JBQ3JDQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSwyQkFBMkJBLENBQUNBLENBQUNBO3FCQUN4REEsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxRQUFRQSxDQUFDQTtvQkFDOUNBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxDQUFDQTtvQkFDNUJBLENBQUNBLDBCQUFhQSxDQUFDQSxRQUFRQSxFQUFFQSxVQUFVQSxDQUFDQTtvQkFDcENBLENBQUNBLDBCQUFhQSxDQUFDQSxTQUFTQSxFQUFFQSxJQUFJQSxFQUFFQSxRQUFRQSxDQUFDQTtvQkFDekNBLENBQUNBLDBCQUFhQSxDQUFDQSxHQUFHQSxDQUFDQTtpQkFDcEJBLENBQUNBLENBQUNBO1lBQ1RBLENBQUNBLENBQUNBLENBQUNBO1lBRUhBLHFCQUFFQSxDQUFDQSw0QkFBNEJBLEVBQUVBO2dCQUMvQkEseUJBQU1BLENBQUNBLDhCQUE4QkEsQ0FBQ0Esb0JBQW9CQSxDQUFDQSxDQUFDQTtxQkFDdkRBLE9BQU9BLENBQUNBO29CQUNQQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsY0FBY0EsRUFBRUEsU0FBU0EsQ0FBQ0E7b0JBQ3pDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsWUFBWUEsRUFBRUEsR0FBR0EsQ0FBQ0E7b0JBQ2pDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsUUFBUUEsRUFBRUEsR0FBR0EsQ0FBQ0E7b0JBQzdCQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsU0FBU0EsRUFBRUEsV0FBV0EsQ0FBQ0E7b0JBQ3RDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsRUFBRUEsRUFBRUEsQ0FBQ0E7aUJBQ3hCQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0Esb0JBQW9CQSxFQUFFQTtZQUM3QkEscUJBQUVBLENBQUNBLG1CQUFtQkEsRUFBRUE7Z0JBQ3RCQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSw2QkFBNkJBLENBQUNBLENBQUNBO3FCQUMxREEsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxPQUFPQSxDQUFDQTtvQkFDN0NBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxDQUFDQTtvQkFDNUJBLENBQUNBLDBCQUFhQSxDQUFDQSxrQkFBa0JBLEVBQUVBLFlBQVlBLENBQUNBO29CQUNoREEsQ0FBQ0EsMEJBQWFBLENBQUNBLFNBQVNBLEVBQUVBLElBQUlBLEVBQUVBLE9BQU9BLENBQUNBO29CQUN4Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLENBQUNBO2lCQUNwQkEsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLHdCQUF3QkEsRUFBRUE7Z0JBQzNCQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSxzQkFBc0JBLENBQUNBLENBQUNBO3FCQUNuREEsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxPQUFPQSxDQUFDQTtvQkFDN0NBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxDQUFDQTtvQkFDNUJBLENBQUNBLDBCQUFhQSxDQUFDQSxrQkFBa0JBLEVBQUVBLEdBQUdBLENBQUNBO29CQUN2Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFNBQVNBLEVBQUVBLElBQUlBLEVBQUVBLE9BQU9BLENBQUNBO29CQUN4Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLENBQUNBO2lCQUNwQkEsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLGtDQUFrQ0EsRUFBRUE7Z0JBQ3JDQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSx1QkFBdUJBLENBQUNBLENBQUNBO3FCQUNwREEsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxPQUFPQSxDQUFDQTtvQkFDN0NBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxDQUFDQTtvQkFDNUJBLENBQUNBLDBCQUFhQSxDQUFDQSxrQkFBa0JBLEVBQUVBLFFBQVFBLENBQUNBO29CQUM1Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFNBQVNBLEVBQUVBLElBQUlBLEVBQUVBLE9BQU9BLENBQUNBO29CQUN4Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLENBQUNBO2lCQUNwQkEsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLGtDQUFrQ0EsRUFBRUE7Z0JBQ3JDQSx5QkFBTUEsQ0FBQ0Esd0JBQXdCQSxDQUFDQSx5QkFBeUJBLENBQUNBLENBQUNBO3FCQUN0REEsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxJQUFJQSxFQUFFQSxPQUFPQSxDQUFDQTtvQkFDN0NBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxDQUFDQTtvQkFDNUJBLENBQUNBLDBCQUFhQSxDQUFDQSxrQkFBa0JBLEVBQUVBLFVBQVVBLENBQUNBO29CQUM5Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFNBQVNBLEVBQUVBLElBQUlBLEVBQUVBLE9BQU9BLENBQUNBO29CQUN4Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLENBQUNBO2lCQUNwQkEsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFFSEEscUJBQUVBLENBQUNBLDRCQUE0QkEsRUFBRUE7Z0JBQy9CQSx5QkFBTUEsQ0FBQ0EsOEJBQThCQSxDQUFDQSxrQkFBa0JBLENBQUNBLENBQUNBO3FCQUNyREEsT0FBT0EsQ0FBQ0E7b0JBQ1BBLENBQUNBLDBCQUFhQSxDQUFDQSxjQUFjQSxFQUFFQSxRQUFRQSxDQUFDQTtvQkFDeENBLENBQUNBLDBCQUFhQSxDQUFDQSxZQUFZQSxFQUFFQSxHQUFHQSxDQUFDQTtvQkFDakNBLENBQUNBLDBCQUFhQSxDQUFDQSxrQkFBa0JBLEVBQUVBLEdBQUdBLENBQUNBO29CQUN2Q0EsQ0FBQ0EsMEJBQWFBLENBQUNBLFNBQVNBLEVBQUVBLFVBQVVBLENBQUNBO29CQUNyQ0EsQ0FBQ0EsMEJBQWFBLENBQUNBLEdBQUdBLEVBQUVBLEVBQUVBLENBQUNBO2lCQUN4QkEsQ0FBQ0EsQ0FBQ0E7WUFDVEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFTEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7UUFFSEEsMkJBQVFBLENBQUNBLFFBQVFBLEVBQUVBO1lBQ2pCQSxxQkFBRUEsQ0FBQ0EsOENBQThDQSxFQUFFQTtnQkFDakRBLElBQUlBLEdBQUdBLEdBQUdBLG1DQUFtQ0EsQ0FBQ0E7Z0JBQzlDQSxJQUFJQSxJQUFJQSxHQUFHQSxJQUFJQSw0QkFBZUEsQ0FBQ0EsR0FBR0EsRUFBRUEsU0FBU0EsQ0FBQ0EsQ0FBQ0E7Z0JBQy9DQSxJQUFJQSxRQUFRQSxHQUFHQSxJQUFJQSwwQkFBYUEsQ0FBQ0EsSUFBSUEsRUFBRUEsRUFBRUEsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3JEQSxJQUFJQSxJQUFJQSxHQUFHQSxJQUFJQSw0QkFBZUEsQ0FBQ0EsUUFBUUEsRUFBRUEsUUFBUUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ25EQSxJQUFJQSxLQUFLQSxHQUFHQSxJQUFJQSwyQkFBY0EsQ0FBQ0EsV0FBV0EsRUFBRUEsSUFBSUEsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ3hEQSx5QkFBTUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsUUFBUUEsRUFBRUEsQ0FBQ0E7cUJBQ25CQSxPQUFPQSxDQUFDQSxzRUFBb0VBLENBQUNBLENBQUNBO1lBQ3JGQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUVIQSwyQkFBUUEsQ0FBQ0Esb0JBQW9CQSxFQUFFQTtZQUM3QkEscUJBQUVBLENBQUNBLG1DQUFtQ0EsRUFBRUE7Z0JBQ3RDQSx5QkFBTUEsQ0FBQ0EsOEJBQThCQSxDQUFDQSxlQUFVQSxDQUFDQSxDQUFDQTtxQkFDN0NBLE9BQU9BLENBQUNBO29CQUNQQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsY0FBY0EsRUFBRUEsSUFBSUEsQ0FBQ0E7b0JBQ3BDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsWUFBWUEsRUFBRUEsR0FBR0EsQ0FBQ0E7b0JBQ2pDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsSUFBSUEsRUFBRUEsR0FBR0EsQ0FBQ0E7b0JBQ3pCQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsU0FBU0EsRUFBRUEsTUFBTUEsQ0FBQ0E7b0JBQ2pDQSxDQUFDQSwwQkFBYUEsQ0FBQ0EsR0FBR0EsRUFBRUEsRUFBRUEsQ0FBQ0E7aUJBQ3hCQSxDQUFDQSxDQUFDQTtZQUNUQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNMQSxDQUFDQSxDQUFDQSxDQUFDQTtJQUVMQSxDQUFDQSxDQUFDQSxDQUFDQTtBQUNMQSxDQUFDQTtBQXhrQmUsWUFBSSxPQXdrQm5CLENBQUE7QUFFRCwrQkFBK0IsS0FBYTtJQUMxQ0MsSUFBSUEsY0FBY0EsR0FBR0EseUJBQVlBLENBQUNBLEtBQUtBLEVBQUVBLFNBQVNBLENBQUNBLENBQUNBO0lBQ3BEQSxFQUFFQSxDQUFDQSxDQUFDQSxjQUFjQSxDQUFDQSxNQUFNQSxDQUFDQSxNQUFNQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtRQUNyQ0EsSUFBSUEsV0FBV0EsR0FBR0EsY0FBY0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7UUFDbkRBLE1BQU1BLElBQUlBLDBCQUFhQSxDQUFDQSwrQkFBNkJBLFdBQWFBLENBQUNBLENBQUNBO0lBQ3RFQSxDQUFDQTtJQUNEQSxNQUFNQSxDQUFDQSxjQUFjQSxDQUFDQSxNQUFNQSxDQUFDQTtBQUMvQkEsQ0FBQ0E7QUFFRCxrQ0FBa0MsS0FBYTtJQUM3Q0MsTUFBTUEsQ0FBQ0EscUJBQXFCQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxVQUFBQSxLQUFLQSxJQUFJQSxPQUFBQSxDQUFNQSxLQUFLQSxDQUFDQSxJQUFJQSxDQUFDQSxDQUFDQSxNQUFNQSxDQUFDQSxLQUFLQSxDQUFDQSxLQUFLQSxDQUFDQSxFQUFyQ0EsQ0FBcUNBLENBQUNBLENBQUNBO0FBQzFGQSxDQUFDQTtBQUVELHdDQUF3QyxLQUFhO0lBQ25EQyxNQUFNQSxDQUFDQSxxQkFBcUJBLENBQUNBLEtBQUtBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLFVBQUFBLEtBQUtBLElBQUlBLE9BQUFBLENBQU1BLEtBQUtBLENBQUNBLElBQUlBLEVBQUVBLEtBQUtBLENBQUNBLFVBQVVBLENBQUNBLFFBQVFBLEVBQUVBLENBQUNBLEVBQTlDQSxDQUE4Q0EsQ0FBQ0EsQ0FBQ0E7QUFDbkdBLENBQUNBO0FBRUQsNEJBQTRCLFFBQXVCO0lBQ2pEQyxNQUFNQSxDQUFJQSxRQUFRQSxDQUFDQSxJQUFJQSxTQUFJQSxRQUFRQSxDQUFDQSxHQUFLQSxDQUFDQTtBQUM1Q0EsQ0FBQ0E7QUFFRCx1Q0FBdUMsS0FBYTtJQUNsREMsTUFBTUEsQ0FBQ0EscUJBQXFCQSxDQUFDQSxLQUFLQSxDQUFDQTtTQUM5QkEsR0FBR0EsQ0FBQ0EsVUFBQUEsS0FBS0EsSUFBSUEsT0FBQUEsQ0FBTUEsS0FBS0EsQ0FBQ0EsSUFBSUEsRUFBRUEsa0JBQWtCQSxDQUFDQSxLQUFLQSxDQUFDQSxVQUFVQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxFQUE3REEsQ0FBNkRBLENBQUNBLENBQUNBO0FBQ25GQSxDQUFDQTtBQUVELG1DQUFtQyxLQUFhO0lBQzlDQyxNQUFNQSxDQUFDQSx5QkFBWUEsQ0FBQ0EsS0FBS0EsRUFBRUEsU0FBU0EsQ0FBQ0E7U0FDaENBLE1BQU1BLENBQUNBLEdBQUdBLENBQUNBLFVBQUFBLFVBQVVBLElBQUlBLE9BQUFBO1FBQ25CQSxVQUFVQSxDQUFDQSxTQUFTQTtRQUN6QkEsVUFBVUEsQ0FBQ0EsR0FBR0E7UUFDZEEsa0JBQWtCQSxDQUFDQSxVQUFVQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQTtLQUMxQ0EsRUFKeUJBLENBSXpCQSxDQUFDQSxDQUFDQTtBQUNUQSxDQUFDQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIGRkZXNjcmliZSxcbiAgZGVzY3JpYmUsXG4gIGl0LFxuICBpaXQsXG4gIHhpdCxcbiAgZXhwZWN0LFxuICBiZWZvcmVFYWNoLFxuICBhZnRlckVhY2hcbn0gZnJvbSAnYW5ndWxhcjIvdGVzdGluZ19pbnRlcm5hbCc7XG5pbXBvcnQge0Jhc2VFeGNlcHRpb259IGZyb20gJ2FuZ3VsYXIyL3NyYy9mYWNhZGUvZXhjZXB0aW9ucyc7XG5cbmltcG9ydCB7XG4gIHRva2VuaXplSHRtbCxcbiAgSHRtbFRva2VuLFxuICBIdG1sVG9rZW5UeXBlLFxuICBIdG1sVG9rZW5FcnJvclxufSBmcm9tICdhbmd1bGFyMi9zcmMvY29tcGlsZXIvaHRtbF9sZXhlcic7XG5pbXBvcnQge1BhcnNlU291cmNlU3BhbiwgUGFyc2VMb2NhdGlvbiwgUGFyc2VTb3VyY2VGaWxlfSBmcm9tICdhbmd1bGFyMi9zcmMvY29tcGlsZXIvcGFyc2VfdXRpbCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluKCkge1xuICBkZXNjcmliZSgnSHRtbExleGVyJywgKCkgPT4ge1xuICAgIGRlc2NyaWJlKCdsaW5lL2NvbHVtbiBudW1iZXJzJywgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCB3b3JrIHdpdGhvdXQgbmV3bGluZXMnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplTGluZUNvbHVtbignPHQ+YTwvdD4nKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fU1RBUlQsICcwOjAnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fRU5ELCAnMDoyJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRFWFQsICcwOjMnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX0NMT1NFLCAnMDo0J10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkVPRiwgJzA6OCddXG4gICAgICAgICAgICBdKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHdvcmsgd2l0aCBvbmUgbmV3bGluZScsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVMaW5lQ29sdW1uKCc8dD5cXG5hPC90PicpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1xuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9TVEFSVCwgJzA6MCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9FTkQsICcwOjInXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEVYVCwgJzA6MyddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfQ0xPU0UsICcxOjEnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuRU9GLCAnMTo1J11cbiAgICAgICAgICAgIF0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgd29yayB3aXRoIG11bHRpcGxlIG5ld2xpbmVzJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZUxpbmVDb2x1bW4oJzx0XFxuPlxcbmE8L3Q+JykpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX1NUQVJULCAnMDowJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORCwgJzE6MCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5URVhULCAnMToxJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19DTE9TRSwgJzI6MSddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0YsICcyOjUnXVxuICAgICAgICAgICAgXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCB3b3JrIHdpdGggQ1IgYW5kIExGJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZUxpbmVDb2x1bW4oJzx0XFxuPlxcclxcbmFcXHI8L3Q+JykpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX1NUQVJULCAnMDowJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORCwgJzE6MCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5URVhULCAnMToxJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19DTE9TRSwgJzI6MSddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0YsICcyOjUnXVxuICAgICAgICAgICAgXSk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKCdjb21tZW50cycsICgpID0+IHtcbiAgICAgIGl0KCdzaG91bGQgcGFyc2UgY29tbWVudHMnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoJzwhLS10XFxuZVxccnNcXHJcXG50LS0+JykpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkNPTU1FTlRfU1RBUlRdLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5SQVdfVEVYVCwgJ3RcXG5lXFxuc1xcbnQnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuQ09NTUVOVF9FTkRdLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0ZdXG4gICAgICAgICAgICBdKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHN0b3JlIHRoZSBsb2NhdGlvbnMnLFxuICAgICAgICAgKCkgPT4ge2V4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplU291cmNlU3BhbnMoJzwhLS10XFxuZVxccnNcXHJcXG50LS0+JykpXG4gICAgICAgICAgICAgICAgICAgIC50b0VxdWFsKFtcbiAgICAgICAgICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5DT01NRU5UX1NUQVJULCAnPCEtLSddLFxuICAgICAgICAgICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlJBV19URVhULCAndFxcbmVcXHJzXFxyXFxudCddLFxuICAgICAgICAgICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkNPTU1FTlRfRU5ELCAnLS0+J10sXG4gICAgICAgICAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuRU9GLCAnJ11cbiAgICAgICAgICAgICAgICAgICAgXSl9KTtcblxuICAgICAgaXQoJ3Nob3VsZCByZXBvcnQgPCEtIHdpdGhvdXQgLScsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVFcnJvcnMoJzwhLWEnKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtbSHRtbFRva2VuVHlwZS5DT01NRU5UX1NUQVJULCAnVW5leHBlY3RlZCBjaGFyYWN0ZXIgXCJhXCInLCAnMDozJ11dKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHJlcG9ydCBtaXNzaW5nIGVuZCBjb21tZW50JywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZUVycm9ycygnPCEtLScpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1tIdG1sVG9rZW5UeXBlLlJBV19URVhULCAnVW5leHBlY3RlZCBjaGFyYWN0ZXIgXCJFT0ZcIicsICcwOjQnXV0pO1xuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICBkZXNjcmliZSgnZG9jdHlwZScsICgpID0+IHtcbiAgICAgIGl0KCdzaG91bGQgcGFyc2UgZG9jdHlwZXMnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoJzwhZG9jdHlwZSBodG1sPicpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1tIdG1sVG9rZW5UeXBlLkRPQ19UWVBFLCAnZG9jdHlwZSBodG1sJ10sIFtIdG1sVG9rZW5UeXBlLkVPRl1dKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHN0b3JlIHRoZSBsb2NhdGlvbnMnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplU291cmNlU3BhbnMoJzwhZG9jdHlwZSBodG1sPicpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1tIdG1sVG9rZW5UeXBlLkRPQ19UWVBFLCAnPCFkb2N0eXBlIGh0bWw+J10sIFtIdG1sVG9rZW5UeXBlLkVPRiwgJyddXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCByZXBvcnQgbWlzc2luZyBlbmQgZG9jdHlwZScsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVFcnJvcnMoJzwhJykpXG4gICAgICAgICAgICAudG9FcXVhbChbW0h0bWxUb2tlblR5cGUuRE9DX1RZUEUsICdVbmV4cGVjdGVkIGNoYXJhY3RlciBcIkVPRlwiJywgJzA6MiddXSk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIGRlc2NyaWJlKCdDREFUQScsICgpID0+IHtcbiAgICAgIGl0KCdzaG91bGQgcGFyc2UgQ0RBVEEnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoJzwhW0NEQVRBW3RcXG5lXFxyc1xcclxcbnRdXT4nKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuQ0RBVEFfU1RBUlRdLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5SQVdfVEVYVCwgJ3RcXG5lXFxuc1xcbnQnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuQ0RBVEFfRU5EXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuRU9GXVxuICAgICAgICAgICAgXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdG9yZSB0aGUgbG9jYXRpb25zJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZVNvdXJjZVNwYW5zKCc8IVtDREFUQVt0XFxuZVxccnNcXHJcXG50XV0+JykpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkNEQVRBX1NUQVJULCAnPCFbQ0RBVEFbJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlJBV19URVhULCAndFxcbmVcXHJzXFxyXFxudCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5DREFUQV9FTkQsICddXT4nXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuRU9GLCAnJ11cbiAgICAgICAgICAgIF0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcmVwb3J0IDwhWyB3aXRob3V0IENEQVRBWycsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVFcnJvcnMoJzwhW2EnKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtbSHRtbFRva2VuVHlwZS5DREFUQV9TVEFSVCwgJ1VuZXhwZWN0ZWQgY2hhcmFjdGVyIFwiYVwiJywgJzA6MyddXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCByZXBvcnQgbWlzc2luZyBlbmQgY2RhdGEnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplRXJyb3JzKCc8IVtDREFUQVsnKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtbSHRtbFRva2VuVHlwZS5SQVdfVEVYVCwgJ1VuZXhwZWN0ZWQgY2hhcmFjdGVyIFwiRU9GXCInLCAnMDo5J11dKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ29wZW4gdGFncycsICgpID0+IHtcbiAgICAgIGl0KCdzaG91bGQgcGFyc2Ugb3BlbiB0YWdzIHdpdGhvdXQgcHJlZml4JywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZVBhcnRzKCc8dGVzdD4nKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fU1RBUlQsIG51bGwsICd0ZXN0J10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORF0sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkVPRl1cbiAgICAgICAgICAgIF0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcGFyc2UgbmFtZXNwYWNlIHByZWZpeCcsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVQYXJ0cygnPG5zMTp0ZXN0PicpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1xuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9TVEFSVCwgJ25zMScsICd0ZXN0J10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORF0sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkVPRl1cbiAgICAgICAgICAgIF0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcGFyc2Ugdm9pZCB0YWdzJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZVBhcnRzKCc8dGVzdC8+JykpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX1NUQVJULCBudWxsLCAndGVzdCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9FTkRfVk9JRF0sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkVPRl1cbiAgICAgICAgICAgIF0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgYWxsb3cgd2hpdGVzcGFjZSBhZnRlciB0aGUgdGFnIG5hbWUnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoJzx0ZXN0ID4nKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fU1RBUlQsIG51bGwsICd0ZXN0J10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORF0sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkVPRl1cbiAgICAgICAgICAgIF0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc3RvcmUgdGhlIGxvY2F0aW9ucycsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVTb3VyY2VTcGFucygnPHRlc3Q+JykpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX1NUQVJULCAnPHRlc3QnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fRU5ELCAnPiddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0YsICcnXVxuICAgICAgICAgICAgXSk7XG4gICAgICB9KTtcblxuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ2F0dHJpYnV0ZXMnLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIHBhcnNlIGF0dHJpYnV0ZXMgd2l0aG91dCBwcmVmaXgnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoJzx0IGE+JykpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX1NUQVJULCBudWxsLCAndCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5BVFRSX05BTUUsIG51bGwsICdhJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORF0sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkVPRl1cbiAgICAgICAgICAgIF0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcGFyc2UgYXR0cmlidXRlcyB3aXRoIHByZWZpeCcsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVQYXJ0cygnPHQgbnMxOmE+JykpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX1NUQVJULCBudWxsLCAndCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5BVFRSX05BTUUsICduczEnLCAnYSddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9FTkRdLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0ZdXG4gICAgICAgICAgICBdKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHBhcnNlIGF0dHJpYnV0ZXMgd2hvc2UgcHJlZml4IGlzIG5vdCB2YWxpZCcsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVQYXJ0cygnPHQgKG5zMTphKT4nKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fU1RBUlQsIG51bGwsICd0J10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkFUVFJfTkFNRSwgbnVsbCwgJyhuczE6YSknXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fRU5EXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuRU9GXVxuICAgICAgICAgICAgXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBwYXJzZSBhdHRyaWJ1dGVzIHdpdGggc2luZ2xlIHF1b3RlIHZhbHVlJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZVBhcnRzKFwiPHQgYT0nYic+XCIpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1xuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9TVEFSVCwgbnVsbCwgJ3QnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuQVRUUl9OQU1FLCBudWxsLCAnYSddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5BVFRSX1ZBTFVFLCAnYiddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9FTkRdLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0ZdXG4gICAgICAgICAgICBdKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHBhcnNlIGF0dHJpYnV0ZXMgd2l0aCBkb3VibGUgcXVvdGUgdmFsdWUnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoJzx0IGE9XCJiXCI+JykpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX1NUQVJULCBudWxsLCAndCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5BVFRSX05BTUUsIG51bGwsICdhJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkFUVFJfVkFMVUUsICdiJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORF0sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkVPRl1cbiAgICAgICAgICAgIF0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcGFyc2UgYXR0cmlidXRlcyB3aXRoIHVucXVvdGVkIHZhbHVlJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZVBhcnRzKCc8dCBhPWI+JykpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX1NUQVJULCBudWxsLCAndCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5BVFRSX05BTUUsIG51bGwsICdhJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkFUVFJfVkFMVUUsICdiJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORF0sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkVPRl1cbiAgICAgICAgICAgIF0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgYWxsb3cgd2hpdGVzcGFjZScsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVQYXJ0cygnPHQgYSA9IGIgPicpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1xuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9TVEFSVCwgbnVsbCwgJ3QnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuQVRUUl9OQU1FLCBudWxsLCAnYSddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5BVFRSX1ZBTFVFLCAnYiddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9FTkRdLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0ZdXG4gICAgICAgICAgICBdKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHBhcnNlIGF0dHJpYnV0ZXMgd2l0aCBlbnRpdGllcyBpbiB2YWx1ZXMnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoJzx0IGE9XCImIzY1OyYjeDQxO1wiPicpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1xuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9TVEFSVCwgbnVsbCwgJ3QnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuQVRUUl9OQU1FLCBudWxsLCAnYSddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5BVFRSX1ZBTFVFLCAnQUEnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fRU5EXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuRU9GXVxuICAgICAgICAgICAgXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBub3QgZGVjb2RlIGVudGl0aWVzIHdpdGhvdXQgdHJhaWxpbmcgXCI7XCInLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoJzx0IGE9XCImYW1wXCIgYj1cImMmJmRcIj4nKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fU1RBUlQsIG51bGwsICd0J10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkFUVFJfTkFNRSwgbnVsbCwgJ2EnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuQVRUUl9WQUxVRSwgJyZhbXAnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuQVRUUl9OQU1FLCBudWxsLCAnYiddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5BVFRSX1ZBTFVFLCAnYyYmZCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9FTkRdLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0ZdXG4gICAgICAgICAgICBdKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHBhcnNlIGF0dHJpYnV0ZXMgd2l0aCBcIiZcIiBpbiB2YWx1ZXMnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoJzx0IGE9XCJiICYmIGMgJlwiPicpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1xuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9TVEFSVCwgbnVsbCwgJ3QnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuQVRUUl9OQU1FLCBudWxsLCAnYSddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5BVFRSX1ZBTFVFLCAnYiAmJiBjICYnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fRU5EXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuRU9GXVxuICAgICAgICAgICAgXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBwYXJzZSB2YWx1ZXMgd2l0aCBDUiBhbmQgTEYnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoXCI8dCBhPSd0XFxuZVxccnNcXHJcXG50Jz5cIikpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX1NUQVJULCBudWxsLCAndCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5BVFRSX05BTUUsIG51bGwsICdhJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkFUVFJfVkFMVUUsICd0XFxuZVxcbnNcXG50J10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORF0sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkVPRl1cbiAgICAgICAgICAgIF0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc3RvcmUgdGhlIGxvY2F0aW9ucycsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVTb3VyY2VTcGFucygnPHQgYT1iPicpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1xuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9TVEFSVCwgJzx0J10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkFUVFJfTkFNRSwgJ2EnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuQVRUUl9WQUxVRSwgJ2InXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fRU5ELCAnPiddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0YsICcnXVxuICAgICAgICAgICAgXSk7XG4gICAgICB9KTtcblxuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ2Nsb3NpbmcgdGFncycsICgpID0+IHtcbiAgICAgIGl0KCdzaG91bGQgcGFyc2UgY2xvc2luZyB0YWdzIHdpdGhvdXQgcHJlZml4JywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZVBhcnRzKCc8L3Rlc3Q+JykpXG4gICAgICAgICAgICAudG9FcXVhbChbW0h0bWxUb2tlblR5cGUuVEFHX0NMT1NFLCBudWxsLCAndGVzdCddLCBbSHRtbFRva2VuVHlwZS5FT0ZdXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBwYXJzZSBjbG9zaW5nIHRhZ3Mgd2l0aCBwcmVmaXgnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoJzwvbnMxOnRlc3Q+JykpXG4gICAgICAgICAgICAudG9FcXVhbChbW0h0bWxUb2tlblR5cGUuVEFHX0NMT1NFLCAnbnMxJywgJ3Rlc3QnXSwgW0h0bWxUb2tlblR5cGUuRU9GXV0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgYWxsb3cgd2hpdGVzcGFjZScsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVQYXJ0cygnPC8gdGVzdCA+JykpXG4gICAgICAgICAgICAudG9FcXVhbChbW0h0bWxUb2tlblR5cGUuVEFHX0NMT1NFLCBudWxsLCAndGVzdCddLCBbSHRtbFRva2VuVHlwZS5FT0ZdXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdG9yZSB0aGUgbG9jYXRpb25zJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZVNvdXJjZVNwYW5zKCc8L3Rlc3Q+JykpXG4gICAgICAgICAgICAudG9FcXVhbChbW0h0bWxUb2tlblR5cGUuVEFHX0NMT1NFLCAnPC90ZXN0PiddLCBbSHRtbFRva2VuVHlwZS5FT0YsICcnXV0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcmVwb3J0IG1pc3NpbmcgbmFtZSBhZnRlciA8LycsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVFcnJvcnMoJzwvJykpXG4gICAgICAgICAgICAudG9FcXVhbChbW0h0bWxUb2tlblR5cGUuVEFHX0NMT1NFLCAnVW5leHBlY3RlZCBjaGFyYWN0ZXIgXCJFT0ZcIicsICcwOjInXV0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcmVwb3J0IG1pc3NpbmcgPicsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVFcnJvcnMoJzwvdGVzdCcpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1tIdG1sVG9rZW5UeXBlLlRBR19DTE9TRSwgJ1VuZXhwZWN0ZWQgY2hhcmFjdGVyIFwiRU9GXCInLCAnMDo2J11dKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ2VudGl0aWVzJywgKCkgPT4ge1xuICAgICAgaXQoJ3Nob3VsZCBwYXJzZSBuYW1lZCBlbnRpdGllcycsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVQYXJ0cygnYSZhbXA7YicpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1tIdG1sVG9rZW5UeXBlLlRFWFQsICdhJmInXSwgW0h0bWxUb2tlblR5cGUuRU9GXV0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcGFyc2UgaGV4YWRlY2ltYWwgZW50aXRpZXMnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoJyYjeDQxOyYjWDQxOycpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1tIdG1sVG9rZW5UeXBlLlRFWFQsICdBQSddLCBbSHRtbFRva2VuVHlwZS5FT0ZdXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBwYXJzZSBkZWNpbWFsIGVudGl0aWVzJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZVBhcnRzKCcmIzY1OycpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1tIdG1sVG9rZW5UeXBlLlRFWFQsICdBJ10sIFtIdG1sVG9rZW5UeXBlLkVPRl1dKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHN0b3JlIHRoZSBsb2NhdGlvbnMnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplU291cmNlU3BhbnMoJ2EmYW1wO2InKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtbSHRtbFRva2VuVHlwZS5URVhULCAnYSZhbXA7YiddLCBbSHRtbFRva2VuVHlwZS5FT0YsICcnXV0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcmVwb3J0IG1hbGZvcm1lZC91bmtub3duIGVudGl0aWVzJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZUVycm9ycygnJnRibzsnKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtcbiAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgIEh0bWxUb2tlblR5cGUuVEVYVCxcbiAgICAgICAgICAgICAgICAnVW5rbm93biBlbnRpdHkgXCJ0Ym9cIiAtIHVzZSB0aGUgXCImIzxkZWNpbWFsPjtcIiBvciAgXCImI3g8aGV4PjtcIiBzeW50YXgnLFxuICAgICAgICAgICAgICAgICcwOjAnXG4gICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIF0pO1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZUVycm9ycygnJiNhc2RmOycpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1tIdG1sVG9rZW5UeXBlLlRFWFQsICdVbmV4cGVjdGVkIGNoYXJhY3RlciBcInNcIicsICcwOjMnXV0pO1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZUVycm9ycygnJiN4YXNkZjsnKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtbSHRtbFRva2VuVHlwZS5URVhULCAnVW5leHBlY3RlZCBjaGFyYWN0ZXIgXCJzXCInLCAnMDo0J11dKTtcblxuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZUVycm9ycygnJiN4QUJDJykpXG4gICAgICAgICAgICAudG9FcXVhbChbW0h0bWxUb2tlblR5cGUuVEVYVCwgJ1VuZXhwZWN0ZWQgY2hhcmFjdGVyIFwiRU9GXCInLCAnMDo2J11dKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ3JlZ3VsYXIgdGV4dCcsICgpID0+IHtcbiAgICAgIGl0KCdzaG91bGQgcGFyc2UgdGV4dCcsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVQYXJ0cygnYScpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1tIdG1sVG9rZW5UeXBlLlRFWFQsICdhJ10sIFtIdG1sVG9rZW5UeXBlLkVPRl1dKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIGhhbmRsZSBDUiAmIExGJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZVBhcnRzKCd0XFxuZVxccnNcXHJcXG50JykpXG4gICAgICAgICAgICAudG9FcXVhbChbW0h0bWxUb2tlblR5cGUuVEVYVCwgJ3RcXG5lXFxuc1xcbnQnXSwgW0h0bWxUb2tlblR5cGUuRU9GXV0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgcGFyc2UgZW50aXRpZXMnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoJ2EmYW1wO2InKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtbSHRtbFRva2VuVHlwZS5URVhULCAnYSZiJ10sIFtIdG1sVG9rZW5UeXBlLkVPRl1dKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIHBhcnNlIHRleHQgc3RhcnRpbmcgd2l0aCBcIiZcIicsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVQYXJ0cygnYSAmJiBiICYnKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtbSHRtbFRva2VuVHlwZS5URVhULCAnYSAmJiBiICYnXSwgW0h0bWxUb2tlblR5cGUuRU9GXV0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgc3RvcmUgdGhlIGxvY2F0aW9ucycsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVTb3VyY2VTcGFucygnYScpKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1tIdG1sVG9rZW5UeXBlLlRFWFQsICdhJ10sIFtIdG1sVG9rZW5UeXBlLkVPRiwgJyddXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBhbGxvdyBcIjxcIiBpbiB0ZXh0IG5vZGVzJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZVBhcnRzKCd7eyBhIDwgYiA/IGMgOiBkIH19JykpXG4gICAgICAgICAgICAudG9FcXVhbChbW0h0bWxUb2tlblR5cGUuVEVYVCwgJ3t7IGEgPCBiID8gYyA6IGQgfX0nXSwgW0h0bWxUb2tlblR5cGUuRU9GXV0pO1xuXG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplU291cmNlU3BhbnMoJzxwPmE8YjwvcD4nKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fU1RBUlQsICc8cCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9FTkQsICc+J10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRFWFQsICdhPGInXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX0NMT1NFLCAnPC9wPiddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0YsICcnXSxcbiAgICAgICAgICAgIF0pO1xuXG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoJzwgYT4nKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtbSHRtbFRva2VuVHlwZS5URVhULCAnPCBhPiddLCBbSHRtbFRva2VuVHlwZS5FT0ZdXSk7XG4gICAgICB9KTtcblxuICAgICAgLy8gVE9ETyh2aWNiKTogbWFrZSB0aGUgbGV4ZXIgYXdhcmUgb2YgQW5ndWxhciBleHByZXNzaW9uc1xuICAgICAgLy8gc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvaXNzdWVzLzU2NzlcbiAgICAgIGl0KCdzaG91bGQgcGFyc2UgdmFsaWQgc3RhcnQgdGFnIGluIGludGVycG9sYXRpb24nLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoJ3t7IGEgPGIgJiYgYyA+IGQgfX0nKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEVYVCwgJ3t7IGEgJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX1NUQVJULCBudWxsLCAnYiddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5BVFRSX05BTUUsIG51bGwsICcmJiddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5BVFRSX05BTUUsIG51bGwsICdjJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORF0sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRFWFQsICcgZCB9fSddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0ZdXG4gICAgICAgICAgICBdKTtcbiAgICAgIH0pO1xuXG4gICAgfSk7XG5cbiAgICBkZXNjcmliZSgncmF3IHRleHQnLCAoKSA9PiB7XG4gICAgICBpdCgnc2hvdWxkIHBhcnNlIHRleHQnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoYDxzY3JpcHQ+dFxcbmVcXHJzXFxyXFxudDwvc2NyaXB0PmApKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1xuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9TVEFSVCwgbnVsbCwgJ3NjcmlwdCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9FTkRdLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5SQVdfVEVYVCwgJ3RcXG5lXFxuc1xcbnQnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX0NMT1NFLCBudWxsLCAnc2NyaXB0J10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkVPRl1cbiAgICAgICAgICAgIF0pO1xuICAgICAgfSk7XG5cbiAgICAgIGl0KCdzaG91bGQgbm90IGRldGVjdCBlbnRpdGllcycsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVQYXJ0cyhgPHNjcmlwdD4mYW1wOzwvU0NSSVBUPmApKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1xuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9TVEFSVCwgbnVsbCwgJ3NjcmlwdCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9FTkRdLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5SQVdfVEVYVCwgJyZhbXA7J10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19DTE9TRSwgbnVsbCwgJ3NjcmlwdCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0ZdXG4gICAgICAgICAgICBdKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIGlnbm9yZSBvdGhlciBvcGVuaW5nIHRhZ3MnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoYDxzY3JpcHQ+YTxkaXY+PC9zY3JpcHQ+YCkpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX1NUQVJULCBudWxsLCAnc2NyaXB0J10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORF0sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlJBV19URVhULCAnYTxkaXY+J10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19DTE9TRSwgbnVsbCwgJ3NjcmlwdCddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0ZdXG4gICAgICAgICAgICBdKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIGlnbm9yZSBvdGhlciBjbG9zaW5nIHRhZ3MnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoYDxzY3JpcHQ+YTwvdGVzdD48L3NjcmlwdD5gKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fU1RBUlQsIG51bGwsICdzY3JpcHQnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fRU5EXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuUkFXX1RFWFQsICdhPC90ZXN0PiddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfQ0xPU0UsIG51bGwsICdzY3JpcHQnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuRU9GXVxuICAgICAgICAgICAgXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdG9yZSB0aGUgbG9jYXRpb25zJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZVNvdXJjZVNwYW5zKGA8c2NyaXB0PmE8L3NjcmlwdD5gKSlcbiAgICAgICAgICAgIC50b0VxdWFsKFtcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fU1RBUlQsICc8c2NyaXB0J10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORCwgJz4nXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuUkFXX1RFWFQsICdhJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19DTE9TRSwgJzwvc2NyaXB0PiddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0YsICcnXVxuICAgICAgICAgICAgXSk7XG4gICAgICB9KTtcblxuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ2VzY2FwYWJsZSByYXcgdGV4dCcsICgpID0+IHtcbiAgICAgIGl0KCdzaG91bGQgcGFyc2UgdGV4dCcsICgpID0+IHtcbiAgICAgICAgZXhwZWN0KHRva2VuaXplQW5kSHVtYW5pemVQYXJ0cyhgPHRpdGxlPnRcXG5lXFxyc1xcclxcbnQ8L3RpdGxlPmApKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1xuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9TVEFSVCwgbnVsbCwgJ3RpdGxlJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORF0sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkVTQ0FQQUJMRV9SQVdfVEVYVCwgJ3RcXG5lXFxuc1xcbnQnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX0NMT1NFLCBudWxsLCAndGl0bGUnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuRU9GXVxuICAgICAgICAgICAgXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBkZXRlY3QgZW50aXRpZXMnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoYDx0aXRsZT4mYW1wOzwvdGl0bGU+YCkpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX1NUQVJULCBudWxsLCAndGl0bGUnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fRU5EXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuRVNDQVBBQkxFX1JBV19URVhULCAnJiddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfQ0xPU0UsIG51bGwsICd0aXRsZSddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0ZdXG4gICAgICAgICAgICBdKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIGlnbm9yZSBvdGhlciBvcGVuaW5nIHRhZ3MnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoYDx0aXRsZT5hPGRpdj48L3RpdGxlPmApKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1xuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9TVEFSVCwgbnVsbCwgJ3RpdGxlJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORF0sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLkVTQ0FQQUJMRV9SQVdfVEVYVCwgJ2E8ZGl2PiddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfQ0xPU0UsIG51bGwsICd0aXRsZSddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0ZdXG4gICAgICAgICAgICBdKTtcbiAgICAgIH0pO1xuXG4gICAgICBpdCgnc2hvdWxkIGlnbm9yZSBvdGhlciBjbG9zaW5nIHRhZ3MnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoYDx0aXRsZT5hPC90ZXN0PjwvdGl0bGU+YCkpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX1NUQVJULCBudWxsLCAndGl0bGUnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX09QRU5fRU5EXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuRVNDQVBBQkxFX1JBV19URVhULCAnYTwvdGVzdD4nXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEFHX0NMT1NFLCBudWxsLCAndGl0bGUnXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuRU9GXVxuICAgICAgICAgICAgXSk7XG4gICAgICB9KTtcblxuICAgICAgaXQoJ3Nob3VsZCBzdG9yZSB0aGUgbG9jYXRpb25zJywgKCkgPT4ge1xuICAgICAgICBleHBlY3QodG9rZW5pemVBbmRIdW1hbml6ZVNvdXJjZVNwYW5zKGA8dGl0bGU+YTwvdGl0bGU+YCkpXG4gICAgICAgICAgICAudG9FcXVhbChbXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX1NUQVJULCAnPHRpdGxlJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORCwgJz4nXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuRVNDQVBBQkxFX1JBV19URVhULCAnYSddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfQ0xPU0UsICc8L3RpdGxlPiddLFxuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5FT0YsICcnXVxuICAgICAgICAgICAgXSk7XG4gICAgICB9KTtcblxuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ2Vycm9ycycsICgpID0+IHtcbiAgICAgIGl0KCdzaG91bGQgaW5jbHVkZSAyIGxpbmVzIG9mIGNvbnRleHQgaW4gbWVzc2FnZScsICgpID0+IHtcbiAgICAgICAgbGV0IHNyYyA9IFwiMTExXFxuMjIyXFxuMzMzXFxuRVxcbjQ0NFxcbjU1NVxcbjY2NlxcblwiO1xuICAgICAgICBsZXQgZmlsZSA9IG5ldyBQYXJzZVNvdXJjZUZpbGUoc3JjLCAnZmlsZTovLycpO1xuICAgICAgICBsZXQgbG9jYXRpb24gPSBuZXcgUGFyc2VMb2NhdGlvbihmaWxlLCAxMiwgMTIzLCA0NTYpO1xuICAgICAgICBsZXQgc3BhbiA9IG5ldyBQYXJzZVNvdXJjZVNwYW4obG9jYXRpb24sIGxvY2F0aW9uKTtcbiAgICAgICAgbGV0IGVycm9yID0gbmV3IEh0bWxUb2tlbkVycm9yKCcqKkVSUk9SKionLCBudWxsLCBzcGFuKTtcbiAgICAgICAgZXhwZWN0KGVycm9yLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAudG9FcXVhbChgKipFUlJPUioqIChcIlxcbjIyMlxcbjMzM1xcbltFUlJPUiAtPl1FXFxuNDQ0XFxuNTU1XFxuXCIpOiBmaWxlOi8vQDEyMzo0NTZgKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZGVzY3JpYmUoJ3VuaWNvZGUgY2hhcmFjdGVycycsICgpID0+IHtcbiAgICAgIGl0KCdzaG91bGQgc3VwcG9ydCB1bmljb2RlIGNoYXJhY3RlcnMnLCAoKSA9PiB7XG4gICAgICAgIGV4cGVjdCh0b2tlbml6ZUFuZEh1bWFuaXplU291cmNlU3BhbnMoYDxwPsSwPC9wPmApKVxuICAgICAgICAgICAgLnRvRXF1YWwoW1xuICAgICAgICAgICAgICBbSHRtbFRva2VuVHlwZS5UQUdfT1BFTl9TVEFSVCwgJzxwJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19PUEVOX0VORCwgJz4nXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuVEVYVCwgJ8SwJ10sXG4gICAgICAgICAgICAgIFtIdG1sVG9rZW5UeXBlLlRBR19DTE9TRSwgJzwvcD4nXSxcbiAgICAgICAgICAgICAgW0h0bWxUb2tlblR5cGUuRU9GLCAnJ11cbiAgICAgICAgICAgIF0pO1xuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHRva2VuaXplV2l0aG91dEVycm9ycyhpbnB1dDogc3RyaW5nKTogSHRtbFRva2VuW10ge1xuICB2YXIgdG9rZW5pemVSZXN1bHQgPSB0b2tlbml6ZUh0bWwoaW5wdXQsICdzb21lVXJsJyk7XG4gIGlmICh0b2tlbml6ZVJlc3VsdC5lcnJvcnMubGVuZ3RoID4gMCkge1xuICAgIHZhciBlcnJvclN0cmluZyA9IHRva2VuaXplUmVzdWx0LmVycm9ycy5qb2luKCdcXG4nKTtcbiAgICB0aHJvdyBuZXcgQmFzZUV4Y2VwdGlvbihgVW5leHBlY3RlZCBwYXJzZSBlcnJvcnM6XFxuJHtlcnJvclN0cmluZ31gKTtcbiAgfVxuICByZXR1cm4gdG9rZW5pemVSZXN1bHQudG9rZW5zO1xufVxuXG5mdW5jdGlvbiB0b2tlbml6ZUFuZEh1bWFuaXplUGFydHMoaW5wdXQ6IHN0cmluZyk6IGFueVtdIHtcbiAgcmV0dXJuIHRva2VuaXplV2l0aG91dEVycm9ycyhpbnB1dCkubWFwKHRva2VuID0+IFs8YW55PnRva2VuLnR5cGVdLmNvbmNhdCh0b2tlbi5wYXJ0cykpO1xufVxuXG5mdW5jdGlvbiB0b2tlbml6ZUFuZEh1bWFuaXplU291cmNlU3BhbnMoaW5wdXQ6IHN0cmluZyk6IGFueVtdIHtcbiAgcmV0dXJuIHRva2VuaXplV2l0aG91dEVycm9ycyhpbnB1dCkubWFwKHRva2VuID0+IFs8YW55PnRva2VuLnR5cGUsIHRva2VuLnNvdXJjZVNwYW4udG9TdHJpbmcoKV0pO1xufVxuXG5mdW5jdGlvbiBodW1hbml6ZUxpbmVDb2x1bW4obG9jYXRpb246IFBhcnNlTG9jYXRpb24pOiBzdHJpbmcge1xuICByZXR1cm4gYCR7bG9jYXRpb24ubGluZX06JHtsb2NhdGlvbi5jb2x9YDtcbn1cblxuZnVuY3Rpb24gdG9rZW5pemVBbmRIdW1hbml6ZUxpbmVDb2x1bW4oaW5wdXQ6IHN0cmluZyk6IGFueVtdIHtcbiAgcmV0dXJuIHRva2VuaXplV2l0aG91dEVycm9ycyhpbnB1dClcbiAgICAgIC5tYXAodG9rZW4gPT4gWzxhbnk+dG9rZW4udHlwZSwgaHVtYW5pemVMaW5lQ29sdW1uKHRva2VuLnNvdXJjZVNwYW4uc3RhcnQpXSk7XG59XG5cbmZ1bmN0aW9uIHRva2VuaXplQW5kSHVtYW5pemVFcnJvcnMoaW5wdXQ6IHN0cmluZyk6IGFueVtdIHtcbiAgcmV0dXJuIHRva2VuaXplSHRtbChpbnB1dCwgJ3NvbWVVcmwnKVxuICAgICAgLmVycm9ycy5tYXAodG9rZW5FcnJvciA9PiBbXG4gICAgICAgIDxhbnk+dG9rZW5FcnJvci50b2tlblR5cGUsXG4gICAgICAgIHRva2VuRXJyb3IubXNnLFxuICAgICAgICBodW1hbml6ZUxpbmVDb2x1bW4odG9rZW5FcnJvci5zcGFuLnN0YXJ0KVxuICAgICAgXSk7XG59XG4iXX0=
 main(); 
