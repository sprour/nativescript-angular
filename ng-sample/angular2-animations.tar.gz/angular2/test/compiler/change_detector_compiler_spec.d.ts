export declare function main(): void;
export declare function testChangeDetector(changeDetectorFactory: Function): string[];
