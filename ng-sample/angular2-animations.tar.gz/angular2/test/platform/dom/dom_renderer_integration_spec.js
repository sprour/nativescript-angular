'use strict';var parse5Adapter = require('angular2/src/platform/server/parse5_adapter');
parse5Adapter.Parse5DomAdapter.makeCurrent();var testing_internal_1 = require('angular2/testing_internal');
// import {MapWrapper} from 'angular2/src/facade/collection';
// import {DOM} from 'angular2/src/platform/dom/dom_adapter';
// import {DomTestbed, TestRootView, elRef} from './dom_testbed';
// import {
//   ViewDefinition,
//   RenderDirectiveMetadata,
//   RenderViewRef,
//   ViewEncapsulation
// } from 'angular2/src/core/render/api';
function main() {
    testing_internal_1.describe('DomRenderer integration', function () {
        testing_internal_1.it('should work', function () {
            // TODO
        });
    });
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZG9tX3JlbmRlcmVyX2ludGVncmF0aW9uX3NwZWMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkaWZmaW5nX3BsdWdpbl93cmFwcGVyLW91dHB1dF9wYXRoLVlxOHV4WFlDLnRtcC9hbmd1bGFyMi90ZXN0L3BsYXRmb3JtL2RvbS9kb21fcmVuZGVyZXJfaW50ZWdyYXRpb25fc3BlYy50cyJdLCJuYW1lcyI6WyJtYWluIl0sIm1hcHBpbmdzIjoiQUFBQSxpQ0FhTywyQkFBMkIsQ0FBQyxDQUFBO0FBRW5DLDZEQUE2RDtBQUM3RCw2REFBNkQ7QUFFN0QsaUVBQWlFO0FBRWpFLFdBQVc7QUFDWCxvQkFBb0I7QUFDcEIsNkJBQTZCO0FBQzdCLG1CQUFtQjtBQUNuQixzQkFBc0I7QUFDdEIseUNBQXlDO0FBRXpDO0lBQ0VBLDJCQUFRQSxDQUFDQSx5QkFBeUJBLEVBQUVBO1FBQ2xDQSxxQkFBRUEsQ0FBQ0EsYUFBYUEsRUFBRUE7WUFDSUEsT0FBT0E7UUFDWEEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7SUFDdkJBLENBQUNBLENBQUNBLENBQUNBO0FBQ0xBLENBQUNBO0FBTmUsWUFBSSxPQU1uQixDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXN5bmNUZXN0Q29tcGxldGVyLFxuICBiZWZvcmVFYWNoLFxuICBkZGVzY3JpYmUsXG4gIGRlc2NyaWJlLFxuICBlbCxcbiAgZXhwZWN0LFxuICBpaXQsXG4gIGluamVjdCxcbiAgaXQsXG4gIHhpdCxcbiAgYmVmb3JlRWFjaFByb3ZpZGVycyxcbiAgU3B5T2JqZWN0LFxufSBmcm9tICdhbmd1bGFyMi90ZXN0aW5nX2ludGVybmFsJztcblxuLy8gaW1wb3J0IHtNYXBXcmFwcGVyfSBmcm9tICdhbmd1bGFyMi9zcmMvZmFjYWRlL2NvbGxlY3Rpb24nO1xuLy8gaW1wb3J0IHtET019IGZyb20gJ2FuZ3VsYXIyL3NyYy9wbGF0Zm9ybS9kb20vZG9tX2FkYXB0ZXInO1xuXG4vLyBpbXBvcnQge0RvbVRlc3RiZWQsIFRlc3RSb290VmlldywgZWxSZWZ9IGZyb20gJy4vZG9tX3Rlc3RiZWQnO1xuXG4vLyBpbXBvcnQge1xuLy8gICBWaWV3RGVmaW5pdGlvbixcbi8vICAgUmVuZGVyRGlyZWN0aXZlTWV0YWRhdGEsXG4vLyAgIFJlbmRlclZpZXdSZWYsXG4vLyAgIFZpZXdFbmNhcHN1bGF0aW9uXG4vLyB9IGZyb20gJ2FuZ3VsYXIyL3NyYy9jb3JlL3JlbmRlci9hcGknO1xuXG5leHBvcnQgZnVuY3Rpb24gbWFpbigpIHtcbiAgZGVzY3JpYmUoJ0RvbVJlbmRlcmVyIGludGVncmF0aW9uJywgKCkgPT4ge1xuICAgIGl0KCdzaG91bGQgd29yaycsICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gVE9ET1xuICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICB9KTtcbn1cbiJdfQ==
 main(); 
