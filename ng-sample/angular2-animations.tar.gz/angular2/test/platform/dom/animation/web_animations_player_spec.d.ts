import { DomAnimatePlayer } from 'angular2/src/platform/dom/animation/dom_animate_player';
export declare class MockDomAnimatePlayer implements DomAnimatePlayer {
    captures: {
        [key: string]: any[];
    };
    private _position;
    private _onfinish;
    _capture(method: string, data: any): void;
    cancel(): void;
    play(): void;
    pause(): void;
    finish(): void;
    onfinish: () => void;
    position: number;
}
export declare function main(): void;
