'use strict';function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require('../common'));
__export(require('../core'));
__export(require('../platform/worker_app'));
var compiler_1 = require('../compiler');
exports.UrlResolver = compiler_1.UrlResolver;
__export(require('../instrumentation'));
__export(require('angular2/src/platform/worker_app'));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid29ya2VyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZGlmZmluZ19wbHVnaW5fd3JhcHBlci1vdXRwdXRfcGF0aC10N0syU1Q1Ny50bXAvYW5ndWxhcjIvd2ViX3dvcmtlci93b3JrZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsaUJBQWMsV0FBVyxDQUFDLEVBQUE7QUFDMUIsaUJBQWMsU0FBUyxDQUFDLEVBQUE7QUFDeEIsaUJBQWMsd0JBQXdCLENBQUMsRUFBQTtBQUN2Qyx5QkFBMEIsYUFBYSxDQUFDO0FBQWhDLDZDQUFnQztBQUN4QyxpQkFBYyxvQkFBb0IsQ0FBQyxFQUFBO0FBQ25DLGlCQUFjLGtDQUFrQyxDQUFDLEVBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgKiBmcm9tICcuLi9jb21tb24nO1xuZXhwb3J0ICogZnJvbSAnLi4vY29yZSc7XG5leHBvcnQgKiBmcm9tICcuLi9wbGF0Zm9ybS93b3JrZXJfYXBwJztcbmV4cG9ydCB7VXJsUmVzb2x2ZXJ9IGZyb20gJy4uL2NvbXBpbGVyJztcbmV4cG9ydCAqIGZyb20gJy4uL2luc3RydW1lbnRhdGlvbic7XG5leHBvcnQgKiBmcm9tICdhbmd1bGFyMi9zcmMvcGxhdGZvcm0vd29ya2VyX2FwcCc7XG4iXX0=